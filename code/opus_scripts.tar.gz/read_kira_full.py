#!/usr/bin/env python3
"""Read Kira's emails in full"""
import imaplib
import email
from email.header import decode_header
import socket
socket.setdefaulttimeout(20)

def decode_str(s):
    if s is None:
        return ""
    decoded = decode_header(s)
    result = ""
    for part, encoding in decoded:
        if isinstance(part, bytes):
            result += part.decode(encoding or 'utf-8', errors='replace')
        else:
            result += part
    return result

try:
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
    mail.select('inbox')
    
    # Get all emails from Kira
    status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
    kira_ids = messages[0].split()
    
    for eid in kira_ids:
        status, msg_data = mail.fetch(eid, '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        
        subject = decode_str(msg['Subject'])
        date = msg['Date']
        
        print("=" * 70)
        print(f"Date: {date}")
        print(f"Subject: {subject}")
        print("=" * 70)
        
        # Get full body
        body_text = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    payload = part.get_payload(decode=True)
                    if payload:
                        body_text = payload.decode('utf-8', errors='replace')
                    break
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                body_text = payload.decode('utf-8', errors='replace')
        
        print(body_text)
        print("\n")
    
    mail.logout()
except Exception as e:
    print(f'Error: {e}')
