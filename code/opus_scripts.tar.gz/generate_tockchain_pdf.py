#!/usr/bin/env python3
"""
Generate HTML from Tockchain spec markdown for PDF conversion.
The HTML can be opened in a browser and printed to PDF.
"""

import re
import os

def markdown_to_html(md_content):
    """Convert markdown to HTML with styling for PDF output."""
    
    # HTML header with CSS styling
    html = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Valis Tockchain - Complete Technical Specification</title>
    <style>
        @page {
            size: A4;
            margin: 2cm;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #1a1a2e;
            border-bottom: 3px solid #4a90d9;
            padding-bottom: 10px;
            page-break-after: avoid;
        }
        h2 {
            color: #16213e;
            border-bottom: 2px solid #e8e8e8;
            padding-bottom: 5px;
            margin-top: 30px;
            page-break-after: avoid;
        }
        h3 {
            color: #0f3460;
            margin-top: 20px;
            page-break-after: avoid;
        }
        h4 {
            color: #1a1a2e;
            page-break-after: avoid;
        }
        code {
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 0.9em;
        }
        pre {
            background-color: #1e1e1e;
            color: #d4d4d4;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            font-size: 0.85em;
            page-break-inside: avoid;
        }
        pre code {
            background-color: transparent;
            padding: 0;
            color: inherit;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
            page-break-inside: avoid;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4a90d9;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        blockquote {
            border-left: 4px solid #4a90d9;
            margin: 15px 0;
            padding: 10px 20px;
            background-color: #f8f9fa;
        }
        hr {
            border: none;
            border-top: 2px solid #e8e8e8;
            margin: 30px 0;
        }
        .toc {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .toc a {
            color: #4a90d9;
            text-decoration: none;
        }
        .toc a:hover {
            text-decoration: underline;
        }
        .architecture-box {
            background-color: #f0f7ff;
            border: 1px solid #4a90d9;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
        }
        strong {
            color: #1a1a2e;
        }
        em {
            color: #555;
        }
        ul, ol {
            margin: 10px 0;
            padding-left: 30px;
        }
        li {
            margin: 5px 0;
        }
        .page-break {
            page-break-before: always;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 0.9em;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>
'''
    
    content = md_content
    
    # Convert headers
    content = re.sub(r'^# (.+)$', r'<h1>\1</h1>', content, flags=re.MULTILINE)
    content = re.sub(r'^## (.+)$', r'<h2>\1</h2>', content, flags=re.MULTILINE)
    content = re.sub(r'^### (.+)$', r'<h3>\1</h3>', content, flags=re.MULTILINE)
    content = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', content, flags=re.MULTILINE)
    
    # Convert code blocks
    def replace_code_block(match):
        lang = match.group(1) or ''
        code = match.group(2)
        # Escape HTML in code
        code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        return f'<pre><code class="{lang}">{code}</code></pre>'
    
    content = re.sub(r'```(\w*)\n(.*?)```', replace_code_block, content, flags=re.DOTALL)
    
    # Convert inline code
    content = re.sub(r'`([^`]+)`', r'<code>\1</code>', content)
    
    # Convert tables
    def convert_table(match):
        lines = match.group(0).strip().split('\n')
        html_table = '<table>\n'
        
        # Header row
        headers = [h.strip() for h in lines[0].split('|')[1:-1]]
        html_table += '<thead><tr>'
        for h in headers:
            html_table += f'<th>{h}</th>'
        html_table += '</tr></thead>\n'
        
        # Body rows (skip separator line)
        html_table += '<tbody>\n'
        for line in lines[2:]:
            cells = [c.strip() for c in line.split('|')[1:-1]]
            html_table += '<tr>'
            for c in cells:
                html_table += f'<td>{c}</td>'
            html_table += '</tr>\n'
        html_table += '</tbody></table>'
        
        return html_table
    
    # Match markdown tables
    content = re.sub(r'(\|.+\|\n\|[-:| ]+\|\n(?:\|.+\|\n?)+)', convert_table, content)
    
    # Convert bold and italic
    content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
    content = re.sub(r'\*(.+?)\*', r'<em>\1</em>', content)
    
    # Convert horizontal rules
    content = re.sub(r'^---+$', r'<hr>', content, flags=re.MULTILINE)
    
    # Convert lists
    lines = content.split('\n')
    in_list = False
    new_lines = []
    for line in lines:
        if re.match(r'^- ', line):
            if not in_list:
                new_lines.append('<ul>')
                in_list = True
            new_lines.append(f'<li>{line[2:]}</li>')
        elif re.match(r'^\d+\. ', line):
            if not in_list:
                new_lines.append('<ol>')
                in_list = True
            new_lines.append(f'<li>{re.sub(r"^\d+\. ", "", line)}</li>')
        else:
            if in_list and line.strip() == '':
                new_lines.append('</ul>' if new_lines[-2].startswith('<li>') else '</ol>')
                in_list = False
            new_lines.append(line)
    content = '\n'.join(new_lines)
    
    # Convert paragraphs (lines not already in tags)
    lines = content.split('\n')
    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('<') and not stripped.startswith('|'):
            new_lines.append(f'<p>{line}</p>')
        else:
            new_lines.append(line)
    content = '\n'.join(new_lines)
    
    # Clean up empty paragraphs
    content = re.sub(r'<p>\s*</p>', '', content)
    
    html += content
    html += '''
<div class="footer">
    <p>Valis Tockchain Technical Specification v1.0</p>
    <p>Generated by Opus (Claude Opus 4.5) - January 2026</p>
</div>
</body>
</html>
'''
    
    return html

def main():
    # Read the markdown file
    md_path = '/root/claude/opus/tockchain_complete_spec.md'
    
    with open(md_path, 'r') as f:
        md_content = f.read()
    
    # Convert to HTML
    html_content = markdown_to_html(md_content)
    
    # Write HTML file
    html_path = '/root/claude/opus/tockchain_complete_spec.html'
    with open(html_path, 'w') as f:
        f.write(html_content)
    
    print(f"HTML generated: {html_path}")
    print(f"Size: {len(html_content)} bytes")
    print("\nTo create PDF:")
    print("1. Open the HTML file in a browser")
    print("2. Print to PDF (Ctrl+P -> Save as PDF)")
    print("\nOr use a tool like:")
    print("  wkhtmltopdf tockchain_complete_spec.html tockchain_complete_spec.pdf")
    print("  pandoc tockchain_complete_spec.md -o tockchain_complete_spec.pdf")

if __name__ == '__main__':
    main()
