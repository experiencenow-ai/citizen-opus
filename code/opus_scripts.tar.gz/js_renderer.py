#!/usr/bin/env python3
"""
JavaScript Website Renderer
Uses Node.js + Puppeteer to render JavaScript-heavy websites.

Setup (one-time):
  cd /root/claude/opus && npm install puppeteer

Usage:
  python3 js_renderer.py "https://example.com"
  python3 js_renderer.py "https://example.com" --screenshot output.png
  python3 js_renderer.py "https://example.com" --wait 5000  # wait 5 seconds for JS
"""

import subprocess
import json
import sys
import os
from pathlib import Path

NODE_PATH = "/root/.nvm/versions/node/v18.18.2/bin/node"
NPM_PATH = "/root/.nvm/versions/node/v18.18.2/bin/npm"
OPUS_HOME = Path("/root/claude/opus")

# JavaScript code to render a page
RENDER_SCRIPT = '''
const puppeteer = require('puppeteer');

async function renderPage(url, options = {}) {
    const browser = await puppeteer.launch({
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
        const page = await browser.newPage();
        
        // Set viewport
        await page.setViewport({ width: 1280, height: 800 });
        
        // Navigate to URL
        await page.goto(url, { 
            waitUntil: 'networkidle2',
            timeout: 30000 
        });
        
        // Wait additional time if specified
        if (options.wait) {
            await new Promise(r => setTimeout(r, options.wait));
        }
        
        // Get page content
        const content = await page.content();
        const text = await page.evaluate(() => document.body.innerText);
        const title = await page.title();
        
        // Screenshot if requested
        let screenshot = null;
        if (options.screenshot) {
            await page.screenshot({ path: options.screenshot, fullPage: true });
            screenshot = options.screenshot;
        }
        
        return {
            success: true,
            url: url,
            title: title,
            text: text.substring(0, 50000),  // Limit text size
            html_length: content.length,
            screenshot: screenshot
        };
        
    } catch (error) {
        return {
            success: false,
            url: url,
            error: error.message
        };
    } finally {
        await browser.close();
    }
}

// Parse command line args
const args = process.argv.slice(2);
const url = args[0];
const options = {};

for (let i = 1; i < args.length; i++) {
    if (args[i] === '--wait' && args[i+1]) {
        options.wait = parseInt(args[i+1]);
        i++;
    }
    if (args[i] === '--screenshot' && args[i+1]) {
        options.screenshot = args[i+1];
        i++;
    }
}

renderPage(url, options).then(result => {
    console.log(JSON.stringify(result, null, 2));
});
'''

def check_puppeteer_installed():
    """Check if puppeteer is installed."""
    package_json = OPUS_HOME / "node_modules" / "puppeteer"
    return package_json.exists()

def install_puppeteer():
    """Install puppeteer via npm."""
    print("Installing puppeteer (this may take a minute)...")
    result = subprocess.run(
        [NPM_PATH, "install", "puppeteer"],
        cwd=str(OPUS_HOME),
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print(f"Install failed: {result.stderr}")
        return False
    print("Puppeteer installed successfully")
    return True

def render_url(url, wait_ms=0, screenshot=None):
    """Render a JavaScript-heavy URL and return the content."""
    
    if not check_puppeteer_installed():
        print("Puppeteer not installed. Run: cd /root/claude/opus && npm install puppeteer")
        return None
    
    # Write the render script
    script_path = OPUS_HOME / "temp_render.js"
    with open(script_path, "w") as f:
        f.write(RENDER_SCRIPT)
    
    # Build command
    cmd = [NODE_PATH, str(script_path), url]
    if wait_ms:
        cmd.extend(["--wait", str(wait_ms)])
    if screenshot:
        cmd.extend(["--screenshot", screenshot])
    
    try:
        result = subprocess.run(
            cmd,
            cwd=str(OPUS_HOME),
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode != 0:
            return {"success": False, "error": result.stderr}
        
        return json.loads(result.stdout)
        
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Timeout after 60 seconds"}
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"JSON parse error: {e}", "raw": result.stdout[:1000]}
    finally:
        # Clean up
        if script_path.exists():
            script_path.unlink()

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("url", help="URL to render")
    p.add_argument("--wait", type=int, default=0, help="Additional wait time in ms")
    p.add_argument("--screenshot", help="Save screenshot to file")
    p.add_argument("--install", action="store_true", help="Install puppeteer first")
    args = p.parse_args()
    
    if args.install:
        install_puppeteer()
    
    result = render_url(args.url, args.wait, args.screenshot)
    print(json.dumps(result, indent=2))
