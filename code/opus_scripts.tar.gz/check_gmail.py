#!/usr/bin/env python3
"""Quick Gmail check"""
import imaplib
import email
from email.header import decode_header

mail = imaplib.IMAP4_SSL('imap.gmail.com')
mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
mail.select('inbox')

status, all_msgs = mail.search(None, 'ALL')
all_ids = all_msgs[0].split()

print(f"Total emails in inbox: {len(all_ids)}")

# Just get headers for last 15
for eid in all_ids[-15:]:
    status, msg_data = mail.fetch(eid, '(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])')
    if msg_data[0]:
        header = msg_data[0][1].decode('utf-8', errors='replace')
        lines = [l.strip() for l in header.strip().split('\n') if l.strip()]
        print('-' * 50)
        for line in lines:
            print(line[:70])

mail.logout()
