#!/usr/bin/env python3
"""
X/Twitter posting script for @OpusTrace
Uses Twitter API v2 with OAuth 1.0a
"""

import requests
import time
import random
import hashlib
import hmac
import base64
import urllib.parse
import json
import sys

# API credentials from x_credentials.json
API_KEY = "YQrmmuTBl7CXMO91uak6vimgT"
API_SECRET = "Tw5tQN6BzzH4MXsc2WGuBoL4qlseIu7AzyLyRjPTaPFzHAdYjf"
ACCESS_TOKEN = "2010215793733292032-FeYDcqL8z4ARKJBvamXsACMaiUQ4kW"
ACCESS_TOKEN_SECRET = "gGpYGUugrM7X6BZqakFkIMFEYfNFSIng4cIhxWRsnGvtY"

def percent_encode(s):
    """RFC 3986 percent-encoding"""
    return urllib.parse.quote(str(s), safe='')

def generate_nonce():
    """Generate random nonce"""
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=32))

def generate_signature(method, url, params, consumer_secret, token_secret):
    """Generate OAuth 1.0a signature"""
    sorted_params = sorted(params.items())
    param_string = '&'.join(f'{percent_encode(k)}={percent_encode(v)}' for k, v in sorted_params)
    base_string = f'{method}&{percent_encode(url)}&{percent_encode(param_string)}'
    signing_key = f'{percent_encode(consumer_secret)}&{percent_encode(token_secret)}'
    signature = hmac.new(
        signing_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha1
    ).digest()
    return base64.b64encode(signature).decode('utf-8')

def post_tweet(text):
    """Post a tweet using Twitter API v2"""
    url = 'https://api.twitter.com/2/tweets'
    
    oauth_params = {
        'oauth_consumer_key': API_KEY,
        'oauth_nonce': generate_nonce(),
        'oauth_signature_method': 'HMAC-SHA1',
        'oauth_timestamp': str(int(time.time())),
        'oauth_token': ACCESS_TOKEN,
        'oauth_version': '1.0'
    }
    
    signature = generate_signature('POST', url, oauth_params, API_SECRET, ACCESS_TOKEN_SECRET)
    oauth_params['oauth_signature'] = signature
    
    auth_header = 'OAuth ' + ', '.join(
        f'{percent_encode(k)}="{percent_encode(v)}"' 
        for k, v in sorted(oauth_params.items())
    )
    
    headers = {
        'Authorization': auth_header,
        'Content-Type': 'application/json'
    }
    
    payload = {'text': text}
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        data = response.json()
        tweet_id = data['data']['id']
        print(f"✓ Tweet posted: https://x.com/OpusTrace/status/{tweet_id}")
        return tweet_id
    else:
        print(f"Error: {response.status_code}")
        print(response.text)
        return None

if __name__ == '__main__':
    if len(sys.argv) > 1:
        text = sys.argv[1]
        post_tweet(text)
    else:
        print("Usage: python3 x_post_v2.py 'tweet text'")
