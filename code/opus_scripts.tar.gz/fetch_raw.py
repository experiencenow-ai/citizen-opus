#!/usr/bin/env python3
import imaplib
import socket
socket.setdefaulttimeout(15)

mail = imaplib.IMAP4_SSL('imap.gmail.com')
mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
mail.select('inbox')

# Get the most recent kira email
status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
ids = messages[0].split()

if ids:
    eid = ids[-1]
    # Fetch raw message
    status, msg_data = mail.fetch(eid, '(RFC822)')
    raw = msg_data[0][1]
    
    # Save to file for inspection
    with open('kira_email_raw.txt', 'wb') as f:
        f.write(raw)
    print(f"Saved {len(raw)} bytes to kira_email_raw.txt")

mail.logout()
