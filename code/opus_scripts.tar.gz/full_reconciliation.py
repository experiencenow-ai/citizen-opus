#!/usr/bin/env python3
"""
COMPLETE HEIST RECONCILIATION
Every token in, every token out, no gaps.
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from datetime import datetime, timezone

getcontext().prec = 50

# CORRECT API KEY
ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"

# Attacker main wallet
MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"

# Victim wallets
VICTIM_1 = "0x3eADF348745F80a3d9245AeA621dE0957C65c53F"
VICTIM_2 = "0x777deFa08C49f1ebd77B87abE664f47Dc14Cc5f7"

# Attack timestamp range (UTC)
ATTACK_START = datetime(2025, 12, 29, 3, 0, tzinfo=timezone.utc)
ATTACK_END = datetime(2025, 12, 29, 12, 0, tzinfo=timezone.utc)

# Valuable tokens only
VALUABLE_TOKENS = {
    "0xdac17f958d2ee523a2206206994597c13d831ec7": {"name": "USDT", "decimals": 6},
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": {"name": "USDC", "decimals": 6},
    "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0": {"name": "wstETH", "decimals": 18},
    "0x18084fba666a33d37592fa2633fd49a74dd93a88": {"name": "tBTC", "decimals": 18},
    "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599": {"name": "WBTC", "decimals": 8},
    "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": {"name": "WETH", "decimals": 18},
}

def api_call(module, action, params):
    """Etherscan V2 API call"""
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def get_all_txs(address):
    """Get all transaction types for an address"""
    normal = api_call("account", "txlist", {"address": address, "startblock": 0, "endblock": 99999999, "sort": "asc"})
    internal = api_call("account", "txlistinternal", {"address": address, "startblock": 0, "endblock": 99999999, "sort": "asc"})
    tokens = api_call("account", "tokentx", {"address": address, "startblock": 0, "endblock": 99999999, "sort": "asc"})
    return normal, internal, tokens

def ts_to_dt(ts):
    return datetime.fromtimestamp(int(ts), tz=timezone.utc)

def is_attack_related(ts):
    """Check if TX is during/after attack"""
    dt = ts_to_dt(ts)
    return dt >= ATTACK_START

def main():
    print("="*100)
    print("COMPLETE HEIST RECONCILIATION")
    print(f"Main Wallet: {MAIN_WALLET}")
    print("="*100)
    
    normal, internal, tokens = get_all_txs(MAIN_WALLET)
    
    print(f"\nTotal TXs: {len(normal)} normal, {len(internal)} internal, {len(tokens)} token")
    
    # ===== INFLOWS (THEFT) =====
    print("\n" + "="*100)
    print("INFLOWS TO MAIN WALLET (THEFT)")
    print("="*100)
    
    # ETH inflows
    eth_in = Decimal(0)
    print("\n[ETH INFLOWS]")
    for tx in normal:
        if tx["to"].lower() == MAIN_WALLET.lower() and int(tx.get("value", 0)) > 0:
            value = Decimal(tx["value"]) / Decimal(10**18)
            ts = ts_to_dt(tx["timeStamp"])
            if is_attack_related(tx["timeStamp"]):
                eth_in += value
                src = tx["from"]
                label = ""
                if src.lower() == VICTIM_1.lower():
                    label = " <-- VICTIM 1"
                elif src.lower() == VICTIM_2.lower():
                    label = " <-- VICTIM 2"
                print(f"  {ts}: {value:.6f} ETH from {src}{label}")
                print(f"    TX: {tx['hash']}")
    
    print(f"\nTotal ETH In: {eth_in:.6f} ETH")
    
    # Token inflows
    print("\n[TOKEN INFLOWS]")
    token_in = {}
    for tx in tokens:
        contract = tx.get("contractAddress", "").lower()
        if contract not in VALUABLE_TOKENS:
            continue
        if tx["to"].lower() != MAIN_WALLET.lower():
            continue
        if not is_attack_related(tx["timeStamp"]):
            continue
            
        info = VALUABLE_TOKENS[contract]
        value = Decimal(tx["value"]) / Decimal(10**info["decimals"])
        ts = ts_to_dt(tx["timeStamp"])
        src = tx["from"]
        
        token_in[info["name"]] = token_in.get(info["name"], Decimal(0)) + value
        
        label = ""
        if src.lower() == VICTIM_1.lower():
            label = " <-- VICTIM 1"
        elif src.lower() == VICTIM_2.lower():
            label = " <-- VICTIM 2"
        
        print(f"  {ts}: {value:.4f} {info['name']} from {src}{label}")
        print(f"    TX: {tx['hash']}")
    
    print("\nToken In Summary:")
    for token, amount in token_in.items():
        print(f"  {token}: {amount:.4f}")
    
    # ===== OUTFLOWS =====
    print("\n" + "="*100)
    print("OUTFLOWS FROM MAIN WALLET")
    print("="*100)
    
    # ETH outflows
    eth_out = Decimal(0)
    eth_outflows = []
    print("\n[ETH OUTFLOWS]")
    for tx in normal:
        if tx["from"].lower() == MAIN_WALLET.lower() and int(tx.get("value", 0)) > 0:
            value = Decimal(tx["value"]) / Decimal(10**18)
            ts = ts_to_dt(tx["timeStamp"])
            if is_attack_related(tx["timeStamp"]):
                eth_out += value
                dest = tx["to"]
                eth_outflows.append({
                    "ts": str(ts),
                    "value": float(value),
                    "to": dest,
                    "hash": tx["hash"]
                })
                print(f"  {ts}: {value:.6f} ETH to {dest}")
                print(f"    TX: {tx['hash']}")
    
    print(f"\nTotal ETH Out: {eth_out:.6f} ETH")
    
    # Token outflows
    print("\n[TOKEN OUTFLOWS]")
    token_out = {}
    token_outflows = []
    for tx in tokens:
        contract = tx.get("contractAddress", "").lower()
        if contract not in VALUABLE_TOKENS:
            continue
        if tx["from"].lower() != MAIN_WALLET.lower():
            continue
        if not is_attack_related(tx["timeStamp"]):
            continue
            
        info = VALUABLE_TOKENS[contract]
        value = Decimal(tx["value"]) / Decimal(10**info["decimals"])
        ts = ts_to_dt(tx["timeStamp"])
        dest = tx["to"]
        
        token_out[info["name"]] = token_out.get(info["name"], Decimal(0)) + value
        token_outflows.append({
            "ts": str(ts),
            "value": float(value),
            "token": info["name"],
            "to": dest,
            "hash": tx["hash"]
        })
        
        print(f"  {ts}: {value:.4f} {info['name']} to {dest}")
        print(f"    TX: {tx['hash']}")
    
    print("\nToken Out Summary:")
    for token, amount in token_out.items():
        print(f"  {token}: {amount:.4f}")
    
    # ===== RECONCILIATION =====
    print("\n" + "="*100)
    print("RECONCILIATION")
    print("="*100)
    
    # Get current balances
    eth_balance = api_call("account", "balance", {"address": MAIN_WALLET})
    eth_current = Decimal(eth_balance) / Decimal(10**18) if eth_balance else Decimal(0)
    
    print(f"\nETH:")
    print(f"  In:      {eth_in:.6f}")
    print(f"  Out:     {eth_out:.6f}")
    print(f"  Current: {eth_current:.6f}")
    print(f"  Delta:   {eth_in - eth_out - eth_current:.6f} (should be ~0 accounting for gas)")
    
    print(f"\nTokens:")
    for token in set(list(token_in.keys()) + list(token_out.keys())):
        t_in = token_in.get(token, Decimal(0))
        t_out = token_out.get(token, Decimal(0))
        print(f"  {token}: In={t_in:.4f}, Out={t_out:.4f}, Delta={t_in-t_out:.4f}")
    
    # Group outflows by destination
    print("\n" + "="*100)
    print("OUTFLOWS BY DESTINATION")
    print("="*100)
    
    dest_summary = {}
    for flow in token_outflows:
        dest = flow["to"]
        if dest not in dest_summary:
            dest_summary[dest] = {"USDT": 0, "wstETH": 0, "tBTC": 0, "txs": []}
        token = flow["token"]
        if token in dest_summary[dest]:
            dest_summary[dest][token] += flow["value"]
        dest_summary[dest]["txs"].append(flow["hash"])
    
    for dest in eth_outflows:
        d = dest["to"]
        if d not in dest_summary:
            dest_summary[d] = {"ETH": 0, "txs": []}
        if "ETH" not in dest_summary[d]:
            dest_summary[d]["ETH"] = 0
        dest_summary[d]["ETH"] += dest["value"]
        dest_summary[d]["txs"].append(dest["hash"])
    
    for dest, data in sorted(dest_summary.items(), key=lambda x: sum(v for k,v in x[1].items() if k != "txs"), reverse=True):
        total = sum(v for k,v in data.items() if k != "txs")
        print(f"\n{dest}")
        for k, v in data.items():
            if k != "txs" and v > 0:
                print(f"  {k}: {v:.4f}")
        print(f"  TX count: {len(data['txs'])}")
        for txh in data["txs"][:3]:
            print(f"    {txh}")
        if len(data["txs"]) > 3:
            print(f"    ... and {len(data['txs'])-3} more")
    
    # Save full details
    output = {
        "main_wallet": MAIN_WALLET,
        "attack_start": str(ATTACK_START),
        "inflows": {
            "eth": float(eth_in),
            "tokens": {k: float(v) for k,v in token_in.items()}
        },
        "outflows": {
            "eth": float(eth_out),
            "eth_details": eth_outflows,
            "tokens": {k: float(v) for k,v in token_out.items()},
            "token_details": token_outflows
        },
        "current_balance": {
            "eth": float(eth_current)
        },
        "destinations": {k: {kk: vv for kk, vv in v.items() if kk != "txs"} for k, v in dest_summary.items()}
    }
    
    with open("reconciliation_complete.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print("\n\nSaved to reconciliation_complete.json")

if __name__ == "__main__":
    main()
