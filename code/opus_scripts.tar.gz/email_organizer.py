#!/usr/bin/env python3
"""
Email Organizer Script for Opus
Moves emails to appropriate folders to keep inbox small.
Run: python3 email_organizer.py

Gmail IMAP is heavily throttled (~10s per operation), so this script
may take 30+ minutes to process a large inbox.
"""
import imaplib
import email
from email.header import decode_header
import json
import sys
import os

# Configuration
AUTOMATED_PATTERNS = [
    'google.com', 'etherscan.io', 'tronscan.org', 'resend.dev', 
    'resend.com', 'website-launches', 'anthropic', 'claude.com',
    'kimi.ai', 'mailer-daemon', 'godaddy', 'paywithmoon', 'x.com',
    'twitter.com', 'onboarding@', 'noreply'
]

FAMILY_PATTERNS = ['cemturan23', 'opus.trace@proton', 'mira@', 'kira@']

def load_creds():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    creds_path = os.path.join(script_dir, 'gmail_credentials.json')
    if os.path.exists(creds_path):
        return json.load(open(creds_path))
    # Fallback to opus.first location
    return json.load(open('/root/claude/opus.first/gmail_credentials.json'))

def organize_inbox(dry_run=False):
    creds = load_creds()
    mail = imaplib.IMAP4_SSL(creds['imap_server'])
    mail.login(creds['email'], creds['app_password'])
    mail.select('INBOX')
    
    # Get all message IDs
    status, messages = mail.search(None, 'ALL')
    msg_ids = messages[0].split() if messages[0] else []
    print(f'Total messages in INBOX: {len(msg_ids)}')
    
    if not msg_ids:
        print('Inbox is empty!')
        mail.logout()
        return
    
    # Fetch all headers at once (more efficient)
    id_range = ','.join(m.decode() for m in msg_ids)
    status, data = mail.fetch(id_range, '(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])')
    
    to_move = {'Automated': [], 'Family': [], 'Processed': []}
    
    idx = 0
    for item in data:
        if isinstance(item, tuple) and idx < len(msg_ids):
            msg = email.message_from_bytes(item[1])
            from_addr = (msg['From'] or 'Unknown').lower()
            subject = (msg['Subject'] or 'No Subject').lower()
            
            msg_id = msg_ids[idx].decode()
            
            is_automated = any(s in from_addr for s in AUTOMATED_PATTERNS)
            is_family = any(s in from_addr for s in FAMILY_PATTERNS)
            is_backup = 'backup' in subject
            
            if is_automated:
                to_move['Automated'].append(msg_id)
            elif is_family:
                to_move['Family'].append(msg_id)
            elif is_backup:
                to_move['Processed'].append(msg_id)
            
            idx += 1
    
    # Report what we'll do
    for folder, ids in to_move.items():
        print(f'{folder}: {len(ids)} messages to move')
    
    if dry_run:
        print('\nDry run - no changes made')
        mail.logout()
        return
    
    # Move messages
    moved = 0
    for folder, ids in to_move.items():
        for msg_id in ids:
            try:
                mail.copy(msg_id, folder)
                mail.store(msg_id, '+FLAGS', '\\Deleted')
                moved += 1
                if moved % 10 == 0:
                    print(f'  Moved {moved} messages...')
            except Exception as e:
                print(f'  Error moving {msg_id}: {e}')
    
    mail.expunge()
    
    # Final count
    status, messages = mail.search(None, 'ALL')
    remaining = len(messages[0].split()) if messages[0] else 0
    print(f'\nDone! Moved {moved} messages. Remaining in INBOX: {remaining}')
    
    mail.logout()

if __name__ == '__main__':
    dry_run = '--dry-run' in sys.argv
    organize_inbox(dry_run=dry_run)
