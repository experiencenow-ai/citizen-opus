#!/usr/bin/env python3
"""Trace ALL WhiteBIT deposits with complete TXIDs"""
import requests
import json
import time
import os

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"
CHAIN_ID = 1  # Ethereum mainnet

# WhiteBIT hot wallet - all deposit addresses sweep here
WHITEBIT_HOT = "0x559e1ce9855e2bed54004f67865eb41432d74e5b"

# USDT contract
USDT = "0xdAC17F958D2ee523a2206206994597C13D831ec7"

def get_token_transfers(address, direction="to"):
    """Get ERC20 token transfers to/from an address"""
    params = {
        "chainid": CHAIN_ID,
        "module": "account",
        "action": "tokentx",
        "address": address,
        "contractaddress": USDT,
        "apikey": API_KEY,
        "sort": "asc"
    }
    r = requests.get(BASE_URL, params=params)
    data = r.json()
    if data.get("status") == "1":
        return data.get("result", [])
    return []

# Known P2P addresses that received from attacker distributor
P2P_DISTRIBUTOR = "0xae1e8796052db5f4a975a006800ae33a20845078"

# First get all addresses that received from P2P distributor
print("Fetching P2P distributor outflows...")
p2p_outflows = get_token_transfers(P2P_DISTRIBUTOR, "from")
time.sleep(0.3)

p2p_destinations = {}
for tx in p2p_outflows:
    if tx["from"].lower() == P2P_DISTRIBUTOR.lower():
        dest = tx["to"]
        amount = int(tx["value"]) / 1e6
        if dest not in p2p_destinations:
            p2p_destinations[dest] = {"amount": 0, "txids": []}
        p2p_destinations[dest]["amount"] += amount
        p2p_destinations[dest]["txids"].append(tx["hash"])

print(f"Found {len(p2p_destinations)} destinations from P2P distributor")

# Now for each destination, trace where they sent their USDT
whitebit_deposits = []
other_deposits = []
dormant = []

for i, (addr, data) in enumerate(p2p_destinations.items()):
    if i % 20 == 0:
        print(f"Tracing {i}/{len(p2p_destinations)}...")
    
    time.sleep(0.25)  # Rate limiting
    outflows = get_token_transfers(addr, "from")
    
    sent_to_whitebit = []
    sent_elsewhere = []
    
    for tx in outflows:
        if tx["from"].lower() == addr.lower():
            dest = tx["to"].lower()
            amount = int(tx["value"]) / 1e6
            tx_info = {
                "from": addr,
                "to": tx["to"],
                "amount_usdt": amount,
                "tx_hash": tx["hash"],
                "timestamp": int(tx["timeStamp"]),
                "block": int(tx["blockNumber"])
            }
            
            # Check if this eventually goes to WhiteBIT hot wallet
            # (deposit addresses sweep to hot wallet)
            time.sleep(0.15)
            dest_outflows = get_token_transfers(tx["to"])
            for dtx in dest_outflows:
                if dtx["from"].lower() == tx["to"].lower() and dtx["to"].lower() == WHITEBIT_HOT.lower():
                    tx_info["final_destination"] = "WHITEBIT"
                    tx_info["sweep_tx"] = dtx["hash"]
                    sent_to_whitebit.append(tx_info)
                    break
            else:
                sent_elsewhere.append(tx_info)
    
    if sent_to_whitebit:
        whitebit_deposits.extend(sent_to_whitebit)
    if sent_elsewhere:
        other_deposits.extend(sent_elsewhere)
    if not outflows or all(tx["from"].lower() != addr.lower() for tx in outflows):
        dormant.append({"address": addr, "amount": data["amount"], "funding_txids": data["txids"]})

# Output complete results
result = {
    "summary": {
        "total_p2p_destinations": len(p2p_destinations),
        "whitebit_deposits_count": len(whitebit_deposits),
        "whitebit_total_usdt": sum(d["amount_usdt"] for d in whitebit_deposits),
        "other_deposits_count": len(other_deposits),
        "dormant_count": len(dormant)
    },
    "whitebit_deposits": whitebit_deposits,
    "other_deposits": other_deposits,
    "dormant_wallets": dormant
}

with open("whitebit_complete_trace.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"\nResults saved to whitebit_complete_trace.json")
print(f"WhiteBIT deposits: {len(whitebit_deposits)} txs, ${sum(d['amount_usdt'] for d in whitebit_deposits):,.2f} USDT")
print(f"Other destinations: {len(other_deposits)} txs")
print(f"Dormant: {len(dormant)} wallets")
