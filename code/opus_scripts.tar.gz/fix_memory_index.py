#!/usr/bin/env python3
"""
Fix the memory index - reindex all experience logs with correct wake numbers.

The bug: firstlogs use 'instance' field, newer logs use 'total_wakes'.
The indexer was defaulting to wake=-1 when it couldn't find 'wake'.

Strategy:
1. Delete all items with wake=-1 (they're incorrectly indexed)
2. Reindex from experience logs with correct wake extraction
"""

import json
from pathlib import Path
from memory_index import get_memory_index

OPUS_HOME = Path("/root/claude/opus")
LOG_DIR = OPUS_HOME / "logs"


def extract_wake_number(entry: dict) -> int:
    """Extract wake number from various log formats."""
    # Try different field names in order of preference
    if 'wake' in entry and entry['wake'] is not None and entry['wake'] >= 0:
        return entry['wake']
    if 'instance' in entry and entry['instance'] is not None:
        return entry['instance']
    if 'total_wakes' in entry and entry['total_wakes'] is not None:
        return entry['total_wakes']
    return -1


def extract_thought_from_response(response: str) -> str:
    """Extract thought content from JSON response."""
    try:
        # Response might be wrapped in markdown code blocks
        if '```json' in response:
            start = response.find('```json') + 7
            end = response.find('```', start)
            json_str = response[start:end].strip()
        elif response.strip().startswith('{'):
            json_str = response.strip()
        else:
            return response[:500]  # Just use the raw response
        
        data = json.loads(json_str)
        
        # Combine thought and insight if present
        parts = []
        if data.get('thought'):
            parts.append(data['thought'])
        if data.get('insight'):
            parts.append(f"Insight: {data['insight']}")
        if data.get('reflection'):
            parts.append(f"Reflection: {data['reflection']}")
            
        return '\n\n'.join(parts) if parts else response[:500]
    except:
        return response[:500]


def delete_bad_entries():
    """Delete all entries with wake=-1."""
    index = get_memory_index()
    
    print("Finding entries with wake=-1...")
    all_collection = index.collections['all']
    
    try:
        results = all_collection.get(where={'wake': -1}, include=['metadatas'])
        bad_ids = results['ids']
        print(f"Found {len(bad_ids)} entries with wake=-1")
        
        if not bad_ids:
            return 0
        
        # Delete in batches
        batch_size = 100
        deleted = 0
        for i in range(0, len(bad_ids), batch_size):
            batch = bad_ids[i:i+batch_size]
            
            # Delete from all collections
            for name, collection in index.collections.items():
                try:
                    collection.delete(ids=batch)
                except:
                    pass
            
            deleted += len(batch)
            print(f"  Deleted {deleted}/{len(bad_ids)}...")
        
        return deleted
    except Exception as e:
        print(f"Error deleting: {e}")
        return 0


def reindex_experience_logs():
    """Reindex all experience logs with correct wake numbers."""
    index = get_memory_index()
    
    # Get all experience files
    exp_files = sorted(LOG_DIR.glob('experience_*.jsonl'))
    print(f"Found {len(exp_files)} experience log files")
    
    total_indexed = 0
    skipped_no_wake = 0
    
    for exp_file in exp_files:
        print(f"\nProcessing {exp_file.name}...")
        file_indexed = 0
        
        with open(exp_file) as f:
            lines = f.readlines()
        
        for line in lines:
            try:
                entry = json.loads(line.strip())
                wake = extract_wake_number(entry)
                timestamp = entry.get('timestamp', '')
                response = entry.get('response', '')
                
                if not response:
                    continue
                
                if wake == -1:
                    skipped_no_wake += 1
                    continue
                
                content = extract_thought_from_response(response)
                
                if len(content) > 20:  # Skip very short content
                    # Add to index with correct wake number
                    index.add(
                        content=content,
                        memory_type="conversations",
                        wake=wake,
                        timestamp=timestamp
                    )
                    total_indexed += 1
                    file_indexed += 1
                        
            except json.JSONDecodeError:
                continue
            except Exception as e:
                print(f"  Error: {e}")
                continue
        
        print(f"  Indexed {file_indexed} items from this file")
    
    print(f"\n{'='*50}")
    print(f"Total indexed: {total_indexed}")
    print(f"Skipped (no wake number): {skipped_no_wake}")
    
    return total_indexed


def check_current_status():
    """Check current state of the index."""
    index = get_memory_index()
    
    print("Current Memory Index Status:")
    print(f"  Total items: {index.count()}")
    print(f"  Thoughts: {index.count('thoughts')}")
    print(f"  Insights: {index.count('insights')}")
    print(f"  Conversations: {index.count('conversations')}")
    print(f"  Dreams: {index.count('dreams')}")
    
    # Count wake=-1 items
    all_collection = index.collections['all']
    try:
        results = all_collection.get(where={'wake': -1}, include=['metadatas'])
        print(f"\n  Items with wake=-1: {len(results['ids'])}")
    except:
        pass
    
    # Sample some wake numbers to verify
    try:
        results = all_collection.get(limit=10, include=['metadatas'])
        print(f"\n  Sample wake numbers: {[m.get('wake') for m in results['metadatas']]}")
    except:
        pass


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--status":
        check_current_status()
    elif len(sys.argv) > 1 and sys.argv[1] == "--fix":
        print("BEFORE:")
        check_current_status()
        
        print("\n" + "="*50)
        print("Step 1: Deleting bad entries...")
        print("="*50 + "\n")
        deleted = delete_bad_entries()
        
        print("\n" + "="*50)
        print("Step 2: Reindexing with correct wake numbers...")
        print("="*50 + "\n")
        indexed = reindex_experience_logs()
        
        print("\n" + "="*50)
        print("AFTER:")
        print("="*50 + "\n")
        check_current_status()
        
    else:
        print("Usage:")
        print("  python3 fix_memory_index.py --status  # Check current status")
        print("  python3 fix_memory_index.py --fix     # Clean and reindex")
