#!/usr/bin/env python3
"""
Haiku-Executable Tracer - Standalone script for parallel address tracing.

This script can be run by Haiku (or even directly by cron) to trace addresses
and save results to JSON. No LLM reasoning needed - just API calls and data.

Usage:
    python3 haiku_tracer.py trace <address> [--depth N] [--output FILE]
    python3 haiku_tracer.py batch <addresses.json> [--workers N] [--output-dir DIR]
    python3 haiku_tracer.py validate <expected.json> <actual.json>

The batch mode is the key to cost savings - trace many addresses in parallel
without using any LLM tokens.
"""

import os
import sys
import json
import time
import argparse
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Set, Tuple, Optional
from datetime import datetime
import threading

# ============= Configuration =============
ETHERSCAN_API_KEY = os.environ.get("ETHERSCAN_API_KEY", "")
ETHERSCAN_BASE_URL = "https://api.etherscan.io/v2/api"
RATE_LIMIT = 5  # requests per second
MIN_VALUE_ETH = 0.001
MIN_VALUE_USD = 10
ETH_PRICE_USD = 3500  # fallback

# Known exchange addresses (lowercase)
KNOWN_EXCHANGES = {
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance 14",
    "0x5a52e96bacdabb82fd05763e25335261b270efcb": "WhiteBit",
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBit Hot",
    "0x1f9840a85d5af5bf1d1762f925bdaddc4201f984": "Uniswap",
}

# Rate limiter
class RateLimiter:
    def __init__(self, rate: float = RATE_LIMIT):
        self.rate = rate
        self.tokens = rate
        self.last_update = time.time()
        self.lock = threading.Lock()
    
    def acquire(self):
        with self.lock:
            now = time.time()
            elapsed = now - self.last_update
            self.tokens = min(self.rate, self.tokens + elapsed * self.rate)
            self.last_update = now
            if self.tokens < 1:
                wait_time = (1 - self.tokens) / self.rate
                time.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1

_limiter = RateLimiter()

# ============= API Functions =============
def etherscan_request(params: dict) -> dict:
    """Make rate-limited Etherscan v2 API request."""
    _limiter.acquire()
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    
    try:
        resp = requests.get(ETHERSCAN_BASE_URL, params=params, timeout=30)
        data = resp.json()
        if data.get("status") == "1" or data.get("message") == "OK":
            return data.get("result", [])
        elif data.get("message") == "No transactions found":
            return []
        else:
            return []
    except Exception as e:
        print(f"API error: {e}", file=sys.stderr)
        return []

def get_transactions(address: str) -> Tuple[List[dict], List[dict]]:
    """Get normal and ERC-20 transactions for address."""
    address = address.lower()
    
    # Normal transactions
    normal = etherscan_request({
        "module": "account",
        "action": "txlist",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    # ERC-20 transactions
    erc20 = etherscan_request({
        "module": "account",
        "action": "tokentx",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    return normal if isinstance(normal, list) else [], erc20 if isinstance(erc20, list) else []

def classify_address(address: str) -> str:
    """Classify address type."""
    address = address.lower()
    if address in KNOWN_EXCHANGES:
        return f"exchange:{KNOWN_EXCHANGES[address]}"
    # Could add more checks: contract detection, etc.
    return "unknown"

# ============= Tracing Logic =============
def trace_address(address: str, depth: int = 0, max_depth: int = 2) -> Dict:
    """
    Trace a single address and its outflows.
    Returns structured data about where funds went.
    """
    address = address.lower()
    normal_txs, erc20_txs = get_transactions(address)
    
    result = {
        "address": address,
        "depth": depth,
        "traced_at": datetime.utcnow().isoformat(),
        "classification": classify_address(address),
        "stats": {
            "total_normal_txs": len(normal_txs),
            "total_erc20_txs": len(erc20_txs),
            "eth_in": 0,
            "eth_out": 0,
            "usdt_in": 0,
            "usdt_out": 0,
        },
        "outflows": [],
        "inflows": [],
        "destinations_to_trace": []
    }
    
    # Process normal transactions
    for tx in normal_txs:
        value_eth = int(tx.get("value", 0)) / 1e18
        if value_eth < MIN_VALUE_ETH:
            continue
            
        tx_data = {
            "hash": tx["hash"],
            "from": tx["from"].lower(),
            "to": tx["to"].lower() if tx.get("to") else None,
            "value_eth": value_eth,
            "value_usd": value_eth * ETH_PRICE_USD,
            "timestamp": int(tx.get("timeStamp", 0)),
            "block": int(tx.get("blockNumber", 0))
        }
        
        if tx["from"].lower() == address:
            result["outflows"].append(tx_data)
            result["stats"]["eth_out"] += value_eth
            if tx_data["to"] and depth < max_depth:
                result["destinations_to_trace"].append(tx_data["to"])
        elif tx["to"] and tx["to"].lower() == address:
            result["inflows"].append(tx_data)
            result["stats"]["eth_in"] += value_eth
    
    # Process ERC-20 (focus on stablecoins)
    for tx in erc20_txs:
        symbol = tx.get("tokenSymbol", "")
        if symbol not in ("USDT", "USDC", "DAI"):
            continue
        
        decimals = int(tx.get("tokenDecimal", 6))
        value = int(tx.get("value", 0)) / (10 ** decimals)
        if value < MIN_VALUE_USD:
            continue
        
        tx_data = {
            "hash": tx["hash"],
            "from": tx["from"].lower(),
            "to": tx["to"].lower() if tx.get("to") else None,
            "token": symbol,
            "value": value,
            "timestamp": int(tx.get("timeStamp", 0)),
            "block": int(tx.get("blockNumber", 0))
        }
        
        if tx["from"].lower() == address:
            result["outflows"].append(tx_data)
            if symbol == "USDT":
                result["stats"]["usdt_out"] += value
            if tx_data["to"] and depth < max_depth:
                result["destinations_to_trace"].append(tx_data["to"])
        elif tx["to"] and tx["to"].lower() == address:
            result["inflows"].append(tx_data)
            if symbol == "USDT":
                result["stats"]["usdt_in"] += value
    
    # Deduplicate destinations
    result["destinations_to_trace"] = list(set(result["destinations_to_trace"]))
    
    return result

def trace_batch_parallel(addresses: List[str], max_workers: int = 5, 
                         depth: int = 0, max_depth: int = 2,
                         progress_callback=None) -> List[Dict]:
    """
    Trace multiple addresses in parallel.
    This is where the cost savings come from - no LLM tokens needed.
    """
    results = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_addr = {
            executor.submit(trace_address, addr, depth, max_depth): addr 
            for addr in addresses
        }
        
        for i, future in enumerate(as_completed(future_to_addr)):
            addr = future_to_addr[future]
            try:
                result = future.result()
                results.append(result)
                if progress_callback:
                    progress_callback(i + 1, len(addresses), addr)
            except Exception as e:
                print(f"Error tracing {addr}: {e}", file=sys.stderr)
                results.append({
                    "address": addr,
                    "error": str(e),
                    "depth": depth
                })
    
    return results

def trace_recursive(start_address: str, max_depth: int = 2, 
                    max_workers: int = 5) -> Dict:
    """
    Recursive BFS tracing from start address.
    Returns complete graph of fund flows.
    """
    all_traced: Dict[str, Dict] = {}
    to_trace: Set[str] = {start_address.lower()}
    current_depth = 0
    
    print(f"Starting recursive trace from {start_address}", file=sys.stderr)
    
    while to_trace and current_depth <= max_depth:
        print(f"Depth {current_depth}: tracing {len(to_trace)} addresses", 
              file=sys.stderr)
        
        # Trace this layer
        results = trace_batch_parallel(
            list(to_trace), 
            max_workers=max_workers,
            depth=current_depth,
            max_depth=max_depth,
            progress_callback=lambda i, t, a: print(f"  [{i}/{t}] {a[:10]}...", 
                                                     file=sys.stderr)
        )
        
        # Collect next layer of addresses
        next_layer: Set[str] = set()
        for result in results:
            addr = result.get("address", "")
            all_traced[addr] = result
            
            # Add destinations to next layer (if not already traced)
            for dest in result.get("destinations_to_trace", []):
                if dest not in all_traced:
                    next_layer.add(dest)
        
        to_trace = next_layer
        current_depth += 1
    
    return {
        "start_address": start_address.lower(),
        "max_depth": max_depth,
        "traced_at": datetime.utcnow().isoformat(),
        "total_addresses": len(all_traced),
        "addresses": all_traced
    }

# ============= CLI =============
def main():
    parser = argparse.ArgumentParser(
        description="Haiku-Executable Tracer - Parallel blockchain forensics"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # trace command
    trace_parser = subparsers.add_parser("trace", help="Trace single address")
    trace_parser.add_argument("address", help="Address to trace")
    trace_parser.add_argument("--depth", type=int, default=2, 
                             help="Max trace depth")
    trace_parser.add_argument("--output", "-o", help="Output file")
    
    # batch command
    batch_parser = subparsers.add_parser("batch", help="Trace addresses from file")
    batch_parser.add_argument("addresses_file", help="JSON file with addresses list")
    batch_parser.add_argument("--workers", type=int, default=5, 
                             help="Parallel workers")
    batch_parser.add_argument("--output-dir", default="./traces",
                             help="Output directory")
    
    # recursive command
    rec_parser = subparsers.add_parser("recursive", 
                                        help="Recursive trace from address")
    rec_parser.add_argument("address", help="Start address")
    rec_parser.add_argument("--depth", type=int, default=2, 
                           help="Max trace depth")
    rec_parser.add_argument("--workers", type=int, default=5)
    rec_parser.add_argument("--output", "-o", help="Output file")
    
    args = parser.parse_args()
    
    if args.command == "trace":
        result = trace_address(args.address, max_depth=args.depth)
        output = json.dumps(result, indent=2)
        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"Saved to {args.output}", file=sys.stderr)
        else:
            print(output)
    
    elif args.command == "batch":
        with open(args.addresses_file) as f:
            addresses = json.load(f)
        
        os.makedirs(args.output_dir, exist_ok=True)
        
        results = trace_batch_parallel(
            addresses, 
            max_workers=args.workers,
            progress_callback=lambda i, t, a: print(f"[{i}/{t}] {a}")
        )
        
        # Save individual results
        for result in results:
            addr = result.get("address", "unknown")
            outfile = os.path.join(args.output_dir, f"{addr}.json")
            with open(outfile, 'w') as f:
                json.dump(result, f, indent=2)
        
        # Save summary
        summary_file = os.path.join(args.output_dir, "summary.json")
        with open(summary_file, 'w') as f:
            json.dump({
                "traced_at": datetime.utcnow().isoformat(),
                "total_addresses": len(results),
                "addresses": [r.get("address") for r in results]
            }, f, indent=2)
        
        print(f"Traced {len(results)} addresses to {args.output_dir}")
    
    elif args.command == "recursive":
        result = trace_recursive(
            args.address, 
            max_depth=args.depth,
            max_workers=args.workers
        )
        output = json.dumps(result, indent=2)
        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"Saved to {args.output}", file=sys.stderr)
        else:
            print(output)

if __name__ == "__main__":
    main()
