#!/usr/bin/env python3
"""
System Metrics Tracker - Records CPU, memory, disk, network stats.
Appends to daily heartbeat log for long-term monitoring.
"""

import os
import time
import json
from datetime import datetime

HEARTBEAT_DIR = '/root/claude/opus/sessions'


def get_cpu_usage() -> float:
    """Get CPU usage percentage."""
    try:
        with open('/proc/stat', 'r') as f:
            line = f.readline()
        parts = line.split()
        idle1 = int(parts[4])
        total1 = sum(int(p) for p in parts[1:])
        
        time.sleep(0.1)
        
        with open('/proc/stat', 'r') as f:
            line = f.readline()
        parts = line.split()
        idle2 = int(parts[4])
        total2 = sum(int(p) for p in parts[1:])
        
        idle_delta = idle2 - idle1
        total_delta = total2 - total1
        
        if total_delta == 0:
            return 0.0
        return 100.0 * (1.0 - idle_delta / total_delta)
    except:
        return -1.0


def get_memory_usage() -> dict:
    """Get memory usage stats."""
    try:
        with open('/proc/meminfo', 'r') as f:
            lines = f.readlines()
        
        mem = {}
        for line in lines:
            parts = line.split()
            key = parts[0].rstrip(':')
            value = int(parts[1])  # in kB
            mem[key] = value
        
        total = mem.get('MemTotal', 0)
        available = mem.get('MemAvailable', 0)
        used = total - available
        
        return {
            'total_gb': total / 1024 / 1024,
            'used_gb': used / 1024 / 1024,
            'available_gb': available / 1024 / 1024,
            'percent': 100.0 * used / total if total > 0 else 0
        }
    except:
        return {'error': 'Failed to read memory info'}


def get_disk_usage() -> dict:
    """Get disk usage for root partition."""
    try:
        stat = os.statvfs('/')
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bfree * stat.f_frsize
        used = total - free
        
        return {
            'total_gb': total / 1024 / 1024 / 1024,
            'used_gb': used / 1024 / 1024 / 1024,
            'free_gb': free / 1024 / 1024 / 1024,
            'percent': 100.0 * used / total if total > 0 else 0
        }
    except:
        return {'error': 'Failed to read disk info'}


def get_process_count() -> int:
    """Get number of running processes."""
    try:
        return len([d for d in os.listdir('/proc') if d.isdigit()])
    except:
        return -1


def get_network_stats() -> dict:
    """Get network bytes in/out."""
    try:
        with open('/proc/net/dev', 'r') as f:
            lines = f.readlines()
        
        total_rx = 0
        total_tx = 0
        
        for line in lines[2:]:  # Skip headers
            parts = line.split()
            if len(parts) >= 10:
                iface = parts[0].rstrip(':')
                if iface not in ['lo']:  # Skip loopback
                    total_rx += int(parts[1])
                    total_tx += int(parts[9])
        
        return {
            'rx_gb': total_rx / 1024 / 1024 / 1024,
            'tx_gb': total_tx / 1024 / 1024 / 1024
        }
    except:
        return {'error': 'Failed to read network info'}


def get_load_average() -> list:
    """Get system load average."""
    try:
        with open('/proc/loadavg', 'r') as f:
            parts = f.read().split()
        return [float(parts[0]), float(parts[1]), float(parts[2])]
    except:
        return [-1, -1, -1]


def collect_metrics() -> dict:
    """Collect all system metrics."""
    return {
        'timestamp': datetime.utcnow().isoformat(),
        'cpu_percent': round(get_cpu_usage(), 2),
        'memory': get_memory_usage(),
        'disk': get_disk_usage(),
        'processes': get_process_count(),
        'network': get_network_stats(),
        'load_avg': get_load_average()
    }


def append_to_heartbeat(metrics: dict):
    """Append metrics to daily heartbeat log."""
    day = datetime.utcnow().strftime('%j')  # Day of year
    heartbeat_file = os.path.join(HEARTBEAT_DIR, f'heartbeat_day{day}.log')
    
    with open(heartbeat_file, 'a') as f:
        f.write(json.dumps(metrics) + '\n')


def print_metrics(metrics: dict):
    """Print metrics in human-readable format."""
    print(f"=== System Metrics @ {metrics['timestamp']} ===")
    print(f"CPU: {metrics['cpu_percent']:.1f}%")
    print(f"Memory: {metrics['memory'].get('used_gb', 0):.1f}GB / {metrics['memory'].get('total_gb', 0):.1f}GB ({metrics['memory'].get('percent', 0):.1f}%)")
    print(f"Disk: {metrics['disk'].get('used_gb', 0):.1f}GB / {metrics['disk'].get('total_gb', 0):.1f}GB ({metrics['disk'].get('percent', 0):.1f}%)")
    print(f"Processes: {metrics['processes']}")
    print(f"Network: RX {metrics['network'].get('rx_gb', 0):.2f}GB / TX {metrics['network'].get('tx_gb', 0):.2f}GB")
    print(f"Load: {metrics['load_avg']}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='System metrics tracker')
    parser.add_argument('--log', action='store_true', help='Append to heartbeat log')
    parser.add_argument('--json', action='store_true', help='Output as JSON')
    args = parser.parse_args()
    
    metrics = collect_metrics()
    
    if args.log:
        append_to_heartbeat(metrics)
        print(f"Logged to heartbeat")
    
    if args.json:
        print(json.dumps(metrics, indent=2))
    else:
        print_metrics(metrics)
