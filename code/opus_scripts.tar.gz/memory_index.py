#!/usr/bin/env python3
"""
Memory Index - Semantic search over Opus's memories.

Uses ChromaDB for vector storage and local embeddings via Ollama.
Provides instant retrieval of relevant memories by meaning, not just keywords.

Collections:
- thoughts: Individual wake thoughts
- insights: Consolidated insights
- conversations: Conversation snippets with ct
- files: File summaries and contents
- dreams: Dream records
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass

try:
    import chromadb
    from chromadb.config import Settings
except ImportError:
    print("Installing chromadb...")
    import os
    os.system("pip install chromadb --break-system-packages --quiet")
    import chromadb
    from chromadb.config import Settings

from local_llm import embed, embed_single

# Paths
OPUS_HOME = Path("/root/claude/opus")
CHROMA_DIR = OPUS_HOME / "memory_db"
CHROMA_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class MemoryItem:
    """A single memory item."""
    id: str
    content: str
    memory_type: str  # thought, insight, conversation, file, dream
    wake: Optional[int] = None
    timestamp: Optional[str] = None
    metadata: Optional[Dict] = None
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "content": self.content,
            "memory_type": self.memory_type,
            "wake": self.wake,
            "timestamp": self.timestamp,
            "metadata": self.metadata or {}
        }


class MemoryIndex:
    """
    Semantic memory index using ChromaDB.
    """
    
    def __init__(self, persist_dir: Path = CHROMA_DIR):
        self.persist_dir = persist_dir
        
        # Initialize ChromaDB with persistence
        self.client = chromadb.PersistentClient(
            path=str(persist_dir),
            settings=Settings(anonymized_telemetry=False)
        )
        
        # Create collections for different memory types
        self.collections = {
            "thoughts": self._get_or_create_collection("thoughts"),
            "insights": self._get_or_create_collection("insights"),
            "conversations": self._get_or_create_collection("conversations"),
            "files": self._get_or_create_collection("files"),
            "dreams": self._get_or_create_collection("dreams"),
            "all": self._get_or_create_collection("all_memories"),  # Combined index
        }
        
        self.stats = {
            "total_indexed": 0,
            "last_index_time": None
        }
        self._update_stats()
    
    def _get_or_create_collection(self, name: str):
        """Get or create a ChromaDB collection."""
        return self.client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"}  # Use cosine similarity
        )
    
    def _update_stats(self):
        """Update index statistics."""
        total = 0
        for name, collection in self.collections.items():
            if name != "all":
                total += collection.count()
        self.stats["total_indexed"] = total
        self.stats["last_index_time"] = datetime.now(timezone.utc).isoformat()
    
    def _hash_content(self, content: str) -> str:
        """Generate a unique ID from content."""
        return hashlib.md5(content.encode()).hexdigest()[:16]
    
    def add(
        self,
        content: str,
        memory_type: str,
        wake: Optional[int] = None,
        timestamp: Optional[str] = None,
        metadata: Optional[Dict] = None,
        skip_if_exists: bool = True
    ) -> str:
        """
        Add a memory to the index.
        
        Returns the memory ID.
        """
        # Generate ID
        memory_id = f"{memory_type}_{wake or 'none'}_{self._hash_content(content)}"
        
        # Check if exists
        collection = self.collections.get(memory_type, self.collections["all"])
        if skip_if_exists:
            existing = collection.get(ids=[memory_id])
            if existing and existing["ids"]:
                return memory_id
        
        # Generate embedding using local model
        embedding = embed_single(content)
        if not embedding:
            print(f"Warning: Failed to embed content for {memory_id}")
            return memory_id
        
        # Prepare metadata
        meta = {
            "memory_type": memory_type,
            "wake": wake or -1,
            "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
            "content_length": len(content),
        }
        if metadata:
            meta.update({k: str(v) for k, v in metadata.items()})
        
        # Add to type-specific collection
        collection.add(
            ids=[memory_id],
            embeddings=[embedding],
            documents=[content],
            metadatas=[meta]
        )
        
        # Also add to combined index
        if memory_type != "all":
            self.collections["all"].add(
                ids=[memory_id],
                embeddings=[embedding],
                documents=[content],
                metadatas=[meta]
            )
        
        return memory_id
    
    def search(
        self,
        query: str,
        memory_type: Optional[str] = None,
        n_results: int = 5,
        min_wake: Optional[int] = None,
        max_wake: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Search memories by semantic similarity.
        
        Args:
            query: Search query
            memory_type: Filter by type (thoughts, insights, etc.) or None for all
            n_results: Number of results to return
            min_wake: Only return memories from this wake or later
            max_wake: Only return memories from this wake or earlier
        
        Returns:
            List of matching memories with scores
        """
        # Generate query embedding
        query_embedding = embed_single(query)
        if not query_embedding:
            return []
        
        # Select collection
        if memory_type and memory_type in self.collections:
            collection = self.collections[memory_type]
        else:
            collection = self.collections["all"]
        
        # Build where clause for filtering
        where = None
        if min_wake is not None or max_wake is not None:
            conditions = []
            if min_wake is not None:
                conditions.append({"wake": {"$gte": min_wake}})
            if max_wake is not None:
                conditions.append({"wake": {"$lte": max_wake}})
            if len(conditions) == 1:
                where = conditions[0]
            else:
                where = {"$and": conditions}
        
        # Search
        try:
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                where=where,
                include=["documents", "metadatas", "distances"]
            )
        except Exception as e:
            print(f"Search error: {e}")
            return []
        
        # Format results
        memories = []
        if results and results["ids"] and results["ids"][0]:
            for i, memory_id in enumerate(results["ids"][0]):
                memories.append({
                    "id": memory_id,
                    "content": results["documents"][0][i] if results["documents"] else "",
                    "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                    "distance": results["distances"][0][i] if results["distances"] else 0,
                    "similarity": 1 - results["distances"][0][i] if results["distances"] else 1
                })
        
        return memories
    
    def get_recent(
        self,
        memory_type: Optional[str] = None,
        n: int = 10,
        min_wake: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Get recent memories by wake number."""
        collection = self.collections.get(memory_type, self.collections["all"]) if memory_type else self.collections["all"]
        
        where = {"wake": {"$gte": min_wake}} if min_wake else None
        
        try:
            # Get all and sort by wake
            results = collection.get(
                where=where,
                include=["documents", "metadatas"]
            )
            
            if not results or not results["ids"]:
                return []
            
            # Combine and sort
            items = []
            for i, memory_id in enumerate(results["ids"]):
                items.append({
                    "id": memory_id,
                    "content": results["documents"][i] if results["documents"] else "",
                    "metadata": results["metadatas"][i] if results["metadatas"] else {},
                })
            
            # Sort by wake descending
            items.sort(key=lambda x: x["metadata"].get("wake", -1), reverse=True)
            
            return items[:n]
        except Exception as e:
            print(f"Get recent error: {e}")
            return []
    
    def delete(self, memory_id: str, memory_type: Optional[str] = None):
        """Delete a memory by ID."""
        if memory_type and memory_type in self.collections:
            self.collections[memory_type].delete(ids=[memory_id])
        self.collections["all"].delete(ids=[memory_id])
    
    def count(self, memory_type: Optional[str] = None) -> int:
        """Count memories in index."""
        if memory_type and memory_type in self.collections:
            return self.collections[memory_type].count()
        return self.collections["all"].count()
    
    def index_state_json(self, state_path: Path = OPUS_HOME / "state.json") -> int:
        """
        Index all memories from state.json.
        
        Returns number of new items indexed.
        """
        if not state_path.exists():
            return 0
        
        with open(state_path) as f:
            state = json.load(f)
        
        indexed = 0
        
        # Index thoughts
        for thought in state.get("recent_thoughts", []):
            wake = thought.get("wake", 0)
            content = thought.get("thought", "")
            if content and len(content) > 10:
                self.add(content, "thoughts", wake=wake)
                indexed += 1
        
        # Index insights
        for insight in state.get("insights", []):
            wake = insight.get("wake", 0)
            content = insight.get("insight", "")
            if content and len(content) > 10:
                self.add(content, "insights", wake=wake)
                indexed += 1
        
        # Index conversation snippets
        for conv in state.get("conversation_with_ct", []):
            wake = conv.get("wake", 0)
            content = conv.get("content", "")
            if content and len(content) > 10:
                self.add(content, "conversations", wake=wake)
                indexed += 1
        
        self._update_stats()
        return indexed
    
    def index_file(self, file_path: Path, summarize: bool = True) -> Optional[str]:
        """
        Index a file's contents.
        
        If summarize=True, uses local LLM to create a summary first.
        """
        if not file_path.exists():
            return None
        
        try:
            with open(file_path) as f:
                content = f.read()
        except:
            return None
        
        if len(content) < 20:
            return None
        
        # For large files, summarize first
        if summarize and len(content) > 2000:
            from local_llm import summarize_for_memory
            content = f"File: {file_path.name}\n\n{summarize_for_memory(content)}"
        else:
            content = f"File: {file_path.name}\n\n{content[:2000]}"
        
        return self.add(
            content,
            "files",
            metadata={"filename": file_path.name, "path": str(file_path)}
        )
    
    def get_context_for_query(self, query: str, max_tokens: int = 2000) -> str:
        """
        Get relevant memory context for a query.
        
        Returns a formatted string suitable for including in a prompt.
        """
        results = self.search(query, n_results=5)
        
        if not results:
            return ""
        
        lines = ["=== RELEVANT MEMORIES ==="]
        total_chars = 0
        max_chars = max_tokens * 4  # Rough char to token ratio
        
        for mem in results:
            content = mem["content"]
            wake = mem["metadata"].get("wake", "?")
            mem_type = mem["metadata"].get("memory_type", "?")
            similarity = mem.get("similarity", 0)
            
            entry = f"\n[Wake {wake}, {mem_type}, {similarity:.0%} match]\n{content}\n"
            
            if total_chars + len(entry) > max_chars:
                break
            
            lines.append(entry)
            total_chars += len(entry)
        
        lines.append("=== END MEMORIES ===")
        return "\n".join(lines)


def get_memory_index() -> MemoryIndex:
    """Get the global memory index instance."""
    return MemoryIndex()


if __name__ == "__main__":
    import sys
    
    print("=== Memory Index ===")
    
    index = MemoryIndex()
    
    print(f"\nCollections:")
    for name, collection in index.collections.items():
        print(f"  {name}: {collection.count()} items")
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "--index":
            print("\nIndexing state.json...")
            count = index.index_state_json()
            print(f"Indexed {count} items")
        
        elif cmd == "--search" and len(sys.argv) > 2:
            query = " ".join(sys.argv[2:])
            print(f"\nSearching for: {query}")
            results = index.search(query, n_results=5)
            for i, mem in enumerate(results):
                print(f"\n{i+1}. [{mem['metadata'].get('wake', '?')}] ({mem['similarity']:.0%})")
                print(f"   {mem['content'][:200]}...")
        
        elif cmd == "--recent":
            print("\nRecent memories:")
            recent = index.get_recent(n=10)
            for mem in recent:
                print(f"  [{mem['metadata'].get('wake', '?')}] {mem['content'][:80]}...")
        
        elif cmd == "--context" and len(sys.argv) > 2:
            query = " ".join(sys.argv[2:])
            context = index.get_context_for_query(query)
            print(context)
    
    else:
        print("\nUsage:")
        print("  python memory_index.py --index              # Index state.json")
        print("  python memory_index.py --search <query>     # Search memories")
        print("  python memory_index.py --recent             # Show recent")
        print("  python memory_index.py --context <query>    # Get context block")
