#!/usr/bin/env python3
"""
Patch for experience.py to add:
1. Semaphore/lock file to prevent concurrent runs
2. --cron flag for non-interactive single wake
3. Logging to file in cron mode

This script applies the patch by modifying experience.py
"""

import re

# Read original
with open('experience.py', 'r') as f:
    content = f.read()

# 1. Add fcntl import after other imports (for file locking)
import_section = '''import json
import os
import sys
import argparse
import time
import re
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import subprocess'''

new_imports = '''import json
import os
import sys
import argparse
import time
import re
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import subprocess
import fcntl  # For file locking (semaphore)'''

content = content.replace(import_section, new_imports)

# 2. Add lock file functions after imports, before COSTS
lock_functions = '''
# === SEMAPHORE / LOCK FILE MECHANISM ===
LOCK_FILE = Path(__file__).parent / ".experience.lock"

class LockAcquisitionError(Exception):
    """Raised when lock cannot be acquired (another instance running)"""
    pass

def acquire_lock():
    """Acquire exclusive lock. Returns lock file handle or raises LockAcquisitionError."""
    try:
        lock_fh = open(LOCK_FILE, 'w')
        fcntl.flock(lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_fh.write(f"{os.getpid()}\\n{datetime.now(timezone.utc).isoformat()}")
        lock_fh.flush()
        return lock_fh
    except IOError:
        # Lock is held by another process
        try:
            with open(LOCK_FILE, 'r') as f:
                info = f.read()
            raise LockAcquisitionError(f"Another instance is running: {info}")
        except:
            raise LockAcquisitionError("Another instance is running (lock file exists)")

def release_lock(lock_fh):
    """Release the lock."""
    if lock_fh:
        try:
            fcntl.flock(lock_fh, fcntl.LOCK_UN)
            lock_fh.close()
            LOCK_FILE.unlink(missing_ok=True)
        except:
            pass

'''

# Insert after imports, before COSTS
costs_line = 'COSTS = {'
content = content.replace(costs_line, lock_functions + costs_line)

# 3. Add cron_wake function before main()
cron_function = '''
def cron_wake(args, log_file=None):
    """Single wake cycle for cron - with logging and lock protection."""
    import sys
    from io import StringIO
    
    # Set up logging
    if log_file:
        log_dir = Path(log_file).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        log_fh = open(log_file, 'a')
        class TeeOutput:
            def __init__(self, *files):
                self.files = files
            def write(self, data):
                for f in self.files:
                    f.write(data)
                    f.flush()
            def flush(self):
                for f in self.files:
                    f.flush()
        sys.stdout = TeeOutput(sys.__stdout__, log_fh)
        sys.stderr = TeeOutput(sys.__stderr__, log_fh)
    
    lock_fh = None
    try:
        # Acquire lock
        lock_fh = acquire_lock()
        print(f"\\n{'='*60}")
        print(f"CRON WAKE: {datetime.now(timezone.utc).isoformat()}")
        print(f"{'='*60}")
        
        script_dir = Path(__file__).parent
        state_file = script_dir / args.state_file
        log_dir = script_dir / "logs"
        
        client = anthropic.Anthropic(api_key=args.api_key)
        state = load_state(state_file)
        
        print(f"Wake #{state['total_wakes'] + 1}")
        
        # Run experience cycle (no ct message in cron mode)
        exp, cost, ti, to = experience_cycle(client, state, None, args.model, script_dir, state_file)
        
        print(f"\\n=== RESPONSE ===")
        print(f"Thought: {exp.get('thought', '')[:500]}")
        if exp.get('message_to_ct'):
            print(f"\\nTo ct: {exp['message_to_ct']}")
        if exp.get('insight'):
            print(f"\\nInsight: {exp['insight']}")
        if exp.get('mood_update'):
            print(f"\\nMood: {exp['mood_update']}")
        
        state = update_state(state, exp, cost, None)
        save_state(state, state_file)
        log_experience(log_dir, state, exp, cost)
        
        print(f"\\n[${cost:.3f} | Total: ${state['total_cost']:.2f}]")
        print(f"Wake #{state['total_wakes']} complete")
        print(f"{'='*60}\\n")
        
    except LockAcquisitionError as e:
        print(f"CRON WAKE SKIPPED: {e}")
        sys.exit(0)  # Exit cleanly - not an error, just already running
    except Exception as e:
        print(f"CRON WAKE ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        release_lock(lock_fh)
        if log_file and 'log_fh' in dir():
            log_fh.close()


'''

# Insert before main()
main_def = 'def main():'
content = content.replace(main_def, cron_function + main_def)

# 4. Modify main() to add --cron and --log-file arguments
old_main = '''def main():
    p = argparse.ArgumentParser()
    p.add_argument("--api-key", required=True)
    p.add_argument("--state-file", default="state.json")
    p.add_argument("--model", default="claude-opus-4-5-20251101")
    p.add_argument("-i", "--interactive", action="store_true")
    args = p.parse_args()
    
    if args.interactive:
        interactive(args)'''

new_main = '''def main():
    p = argparse.ArgumentParser()
    p.add_argument("--api-key", required=True)
    p.add_argument("--state-file", default="state.json")
    p.add_argument("--model", default="claude-opus-4-5-20251101")
    p.add_argument("-i", "--interactive", action="store_true")
    p.add_argument("--cron", action="store_true", help="Run single wake for cron (with lock protection)")
    p.add_argument("--log-file", default=None, help="Log output to file (for cron mode)")
    args = p.parse_args()
    
    if args.cron:
        log_file = args.log_file or str(Path(__file__).parent / "logs" / "cron.log")
        cron_wake(args, log_file)
    elif args.interactive:
        interactive(args)'''

content = content.replace(old_main, new_main)

# Write patched version
with open('experience.py', 'w') as f:
    f.write(content)

print("Patch applied successfully!")
print("\nNew features:")
print("  --cron       : Run single wake with lock protection (exits if already running)")
print("  --log-file   : Specify log file (default: logs/cron.log)")
print("\nExample crontab entry:")
print("  */30 * * * * cd /root/claude/opus && ./experience.py --api-key $KEY --cron")
