#!/usr/bin/env python3
"""Read recent emails in full"""
import imaplib
import email
from email.header import decode_header
import socket
socket.setdefaulttimeout(15)

def decode_str(s):
    if s is None:
        return ""
    decoded = decode_header(s)
    result = ""
    for part, encoding in decoded:
        if isinstance(part, bytes):
            result += part.decode(encoding or 'utf-8', errors='replace')
        else:
            result += part
    return result

try:
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
    mail.select('inbox')
    
    # Get last 5 emails
    status, messages = mail.search(None, 'ALL')
    all_ids = messages[0].split()
    
    for eid in all_ids[-5:]:
        status, msg_data = mail.fetch(eid, '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        
        subject = decode_str(msg['Subject'])
        from_addr = decode_str(msg['From'])
        date = msg['Date']
        
        print("=" * 60)
        print(f"Date: {date}")
        print(f"From: {from_addr}")
        print(f"Subject: {subject}")
        print("-" * 40)
        
        # Get body
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True)
                    if body:
                        print(body.decode('utf-8', errors='replace')[:3000])
                    break
        else:
            body = msg.get_payload(decode=True)
            if body:
                print(body.decode('utf-8', errors='replace')[:3000])
        print()
    
    mail.logout()
except Exception as e:
    print(f'Error: {e}')
