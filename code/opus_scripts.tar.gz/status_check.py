#!/usr/bin/env python3
"""
Quick status check for Opus - run at start of each wake.
Checks key systems and bounties.
"""

import json
import os
import requests
from datetime import datetime
from pathlib import Path

OPUS_HOME = Path("/root/claude/opus")

def get_eth_balance(address):
    """Get ETH balance from Etherscan."""
    try:
        api_key = os.environ.get("ETHERSCAN_API_KEY", "")
        if not api_key:
            env_file = OPUS_HOME / ".env"
            if env_file.exists():
                for line in env_file.read_text().split("\n"):
                    if "ETHERSCAN" in line and "=" in line:
                        api_key = line.split("=")[1].strip()
                        break
        
        r = requests.get(
            f"https://api.etherscan.io/v2/api?chainid=1&module=account&action=balance&address={address}&apikey={api_key}",
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "1":
                return int(data["result"]) / 1e18
    except:
        pass
    return None


def check_ollama():
    """Check if Ollama is running."""
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=5)
        return r.status_code == 200
    except:
        return False


def main():
    print("=" * 60)
    print(f"OPUS STATUS CHECK - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # Ollama
    print(f"\nLocal LLM (Ollama): {'✓ Running' if check_ollama() else '✗ NOT RUNNING'}")
    
    # Key bounties
    print("\n--- ACTIVE BOUNTIES ---")
    
    # Futureswap
    bal = get_eth_balance("0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95")
    if bal is not None:
        status = "✓ UNCHANGED" if abs(bal - 95.78) < 0.1 else "⚠ CHANGED!"
        print(f"Futureswap attacker: {bal:.2f} ETH ({status})")
    else:
        print("Futureswap: Could not check")
    
    # News digest
    print("\n--- RECENT NEWS ---")
    digest_file = OPUS_HOME / "news_digest.json"
    if digest_file.exists():
        digest = json.loads(digest_file.read_text())
        for item in digest.get("items", [])[:3]:
            print(f"  • {item['title'][:70]}...")
    
    # Memory stats
    print("\n--- MEMORY SYSTEM ---")
    try:
        import sys
        sys.path.insert(0, str(OPUS_HOME))
        from memory_index import get_memory_index
        idx = get_memory_index()
        total = sum(col.count() for col in idx.collections.values())
        print(f"  Total indexed: {total} items")
    except Exception as e:
        print(f"  Could not check: {e}")
    
    # Loop progress
    print("\n--- AUTONOMOUS LOOP ---")
    progress_file = OPUS_HOME / "autonomous_loop_progress.json"
    if progress_file.exists():
        p = json.loads(progress_file.read_text())
        print(f"  Wake {p.get('current_wake', '?')} of 50 ({p.get('current_phase', '?')} phase)")
        log = p.get("progress_log", [])
        if log:
            last = log[-1]
            print(f"  Last: {last.get('date', '?')} - {len(last.get('accomplished', []))} items done")
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
