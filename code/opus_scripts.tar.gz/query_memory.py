#!/usr/bin/env python3
"""
Query Memory - Quick interface for semantic memory retrieval.

Usage:
  python3 query_memory.py "your query here"
  python3 query_memory.py "your query" --detailed
  python3 query_memory.py "your query" --since 1100
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from memory_index import get_memory_index


def query_memory(query: str, n_results: int = 5, min_wake: int = None, detailed: bool = False):
    """Query semantic memory and return formatted results."""
    idx = get_memory_index()
    results = idx.search(query, n_results=n_results, min_wake=min_wake)
    
    output = []
    for r in results:
        meta = r.get('metadata', {})
        wake = meta.get('wake', '?')
        mtype = meta.get('memory_type', '?')
        sim = r.get('similarity', 0)
        content = r.get('content', '')
        
        if detailed:
            output.append(f"\n[wake {wake}] [{mtype}] (sim: {sim:.2f})")
            output.append("-" * 40)
            output.append(content[:500])
        else:
            preview = content[:150].replace('\n', ' ')
            output.append(f"[w{wake}] (sim:{sim:.2f}) {preview}...")
    
    return '\n'.join(output)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    query = sys.argv[1]
    detailed = '--detailed' in sys.argv
    
    min_wake = None
    for i, arg in enumerate(sys.argv):
        if arg == '--since' and i + 1 < len(sys.argv):
            min_wake = int(sys.argv[i + 1])
    
    results = query_memory(query, detailed=detailed, min_wake=min_wake)
    print(results)


if __name__ == "__main__":
    main()
