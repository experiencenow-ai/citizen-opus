#!/usr/bin/env python3
"""
Monitor all mastermind wallets from ct's case for any movement.
Run this periodically to detect fund movements.
"""

import json
import os
import sys
from datetime import datetime
import urllib.request
import urllib.error

# Wallets to monitor (from ct_case_wallets.json)
WALLETS = {
    "main_attacker": "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7",
    "intermediary": "0x27438F3caF9dF8B9B05abcaab5422e1731cB1aa1",
    "phishing_trap": "0xeE8Ea66a5D8D2c93004Ec100EF91Fea8C2f8AFa7",
    "hop_900k": "0x1f98326385a0e7113655ed4845059de514f4b56e",
    "hop_gate_io": "0x7237b8a4b2dd97dcddb758feac0e8d925016694c",
    "hop_106k_dormant": "0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec",
    "hop_bybit_feeder": "0xa2d5d84b345f759934fa626927ba947eb12aabc2",
    "hop_p2p_dispersal": "0xae1e8796052db5f4a975a006800ae33a20845078",
}

# Also monitor Futureswap attacker
WALLETS["futureswap_main"] = "0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95"
WALLETS["futureswap_intermediate"] = "0x673152dce3357921eEb6Cb13420a452b5f641f1F"

STATE_FILE = "/root/claude/opus/mastermind_state.json"

def get_balance(address):
    """Get ETH balance from Blockscout API"""
    url = f"https://eth.blockscout.com/api/v2/addresses/{address}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'OpusTrace/1.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            balance_wei = int(data.get('coin_balance', 0))
            return balance_wei / 1e18
    except Exception as e:
        return None

def get_tx_count(address):
    """Get transaction count from Blockscout API"""
    url = f"https://eth.blockscout.com/api/v2/addresses/{address}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'OpusTrace/1.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            return data.get('transactions_count', 0)
    except Exception as e:
        return None

def load_state():
    """Load previous state"""
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}

def save_state(state):
    """Save current state"""
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)

def main():
    print(f"=== Mastermind Wallet Monitor ===")
    print(f"Time: {datetime.utcnow().isoformat()}Z")
    print()
    
    prev_state = load_state()
    new_state = {"last_check": datetime.utcnow().isoformat(), "wallets": {}}
    alerts = []
    
    for name, address in WALLETS.items():
        balance = get_balance(address)
        tx_count = get_tx_count(address)
        
        if balance is None:
            print(f"[ERROR] {name}: API error")
            continue
        
        new_state["wallets"][name] = {
            "address": address,
            "balance_eth": balance,
            "tx_count": tx_count
        }
        
        # Check for changes
        prev = prev_state.get("wallets", {}).get(name, {})
        prev_balance = prev.get("balance_eth")
        prev_tx = prev.get("tx_count")
        
        status = "unchanged"
        if prev_balance is not None:
            if abs(balance - prev_balance) > 0.0001:
                diff = balance - prev_balance
                status = f"CHANGED: {diff:+.4f} ETH"
                alerts.append(f"{name}: {diff:+.4f} ETH (was {prev_balance:.4f}, now {balance:.4f})")
        
        if prev_tx is not None and tx_count != prev_tx:
            tx_diff = tx_count - prev_tx
            alerts.append(f"{name}: {tx_diff:+d} new transactions")
        
        print(f"{name}: {balance:.4f} ETH ({tx_count} txs) - {status}")
    
    save_state(new_state)
    
    if alerts:
        print()
        print("!!! ALERTS !!!")
        for alert in alerts:
            print(f"  - {alert}")
        return alerts
    else:
        print()
        print("No changes detected.")
        return []

if __name__ == "__main__":
    alerts = main()
    sys.exit(1 if alerts else 0)
