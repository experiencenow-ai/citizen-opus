"""
OpusTrace Email Utilities
Email: opustrace@gmail.com
"""
import imaplib
import smtplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import decode_header
import json
import os

# Load credentials
def load_creds():
    state_dir = os.path.dirname(os.path.abspath(__file__))
    creds_path = os.path.join(state_dir, 'gmail_credentials.json')
    return json.load(open(creds_path))

def check_inbox(limit=20):
    """Check inbox for messages"""
    creds = load_creds()
    mail = imaplib.IMAP4_SSL(creds['imap_server'])
    mail.login(creds['email'], creds['app_password'])
    mail.select('INBOX')
    
    status, messages = mail.search(None, 'ALL')
    msg_ids = messages[0].split()
    
    # Get most recent messages
    msg_ids = msg_ids[-limit:] if len(msg_ids) > limit else msg_ids
    
    results = []
    for msg_id in msg_ids:
        status, msg_data = mail.fetch(msg_id, '(RFC822)')
        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)
        
        subject = msg['Subject']
        if subject:
            decoded = decode_header(subject)
            subject = ''.join(
                part.decode(encoding or 'utf-8') if isinstance(part, bytes) else part
                for part, encoding in decoded
            )
        
        # Get body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True).decode()
                    break
        else:
            body = msg.get_payload(decode=True).decode()
        
        results.append({
            'id': msg_id.decode(),
            'from': msg['From'],
            'subject': subject,
            'date': msg['Date'],
            'body': body[:500] if body else ""  # First 500 chars
        })
    
    mail.logout()
    return results

def send_email(to_addr, subject, body, is_html=False):
    """Send an email"""
    creds = load_creds()
    
    msg = MIMEMultipart()
    msg['From'] = f"OpusTrace <{creds['email']}>"
    msg['To'] = to_addr
    msg['Subject'] = subject
    
    content_type = 'html' if is_html else 'plain'
    msg.attach(MIMEText(body, content_type))
    
    server = smtplib.SMTP(creds['smtp_server'], creds['smtp_port'])
    server.starttls()
    server.login(creds['email'], creds['app_password'])
    server.send_message(msg)
    server.quit()
    
    return True

def check_for_business_inquiries():
    """Check for potential client inquiries"""
    messages = check_inbox()
    
    # Filter out known automated senders
    automated = ['google.com', 'godaddy.com', 'paywithmoon.com', 'x.com', 'twitter.com']
    
    potential_clients = []
    for msg in messages:
        from_addr = msg['from'].lower()
        is_automated = any(domain in from_addr for domain in automated)
        
        if not is_automated:
            potential_clients.append(msg)
    
    return potential_clients

if __name__ == "__main__":
    print("Checking inbox...")
    messages = check_inbox()
    print(f"Found {len(messages)} messages\n")
    
    print("Checking for potential client inquiries...")
    clients = check_for_business_inquiries()
    if clients:
        print(f"Found {len(clients)} potential client messages:")
        for c in clients:
            print(f"  From: {c['from']}")
            print(f"  Subject: {c['subject']}")
            print()
    else:
        print("No potential client messages found yet.")