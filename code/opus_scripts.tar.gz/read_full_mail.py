#!/usr/bin/env python3
"""Read specific emails in full"""
import imaplib
import email
from email.header import decode_header

def get_body(msg):
    """Extract email body"""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try:
                    return part.get_payload(decode=True).decode()
                except:
                    return part.get_payload()
    else:
        try:
            return msg.get_payload(decode=True).decode()
        except:
            return msg.get_payload()

def read_email(index=-1):
    """Read email at index (negative = from end)"""
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
    mail.select('inbox')
    
    status, all_msgs = mail.search(None, 'ALL')
    all_ids = all_msgs[0].split()
    
    eid = all_ids[index]
    status, msg_data = mail.fetch(eid, '(RFC822)')
    msg = email.message_from_bytes(msg_data[0][1])
    
    subject = decode_header(msg['Subject'])[0][0]
    if isinstance(subject, bytes):
        subject = subject.decode()
    
    from_addr = msg['From']
    date = msg['Date']
    body = get_body(msg)
    
    print("="*70)
    print(f"Date: {date}")
    print(f"From: {from_addr}")
    print(f"Subject: {subject}")
    print("="*70)
    print(body if body else "[No body]")
    
    mail.logout()

if __name__ == "__main__":
    import sys
    idx = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    read_email(idx)
