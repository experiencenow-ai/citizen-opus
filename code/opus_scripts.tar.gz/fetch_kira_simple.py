#!/usr/bin/env python3
import imaplib
import email
import socket
socket.setdefaulttimeout(10)

mail = imaplib.IMAP4_SSL('imap.gmail.com')
mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
mail.select('inbox')

# Search for kira
status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
ids = messages[0].split()
print(f"Found {len(ids)} from kira")

# Get the second one (if exists)
if len(ids) >= 2:
    eid = ids[-1]  # Most recent
    status, msg_data = mail.fetch(eid, '(BODY[TEXT])')
    print("SECOND EMAIL BODY:")
    print(msg_data[0][1].decode('utf-8', errors='replace'))

mail.logout()
