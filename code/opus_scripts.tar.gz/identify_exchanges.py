#!/usr/bin/env python3
"""
Identify which destination addresses are exchange deposits
by checking if they sweep to known hot wallets
"""

import requests
import json
import time
from decimal import Decimal

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Known exchange hot wallets
KNOWN_HOT_WALLETS = {
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io",
    
    # Bybit  
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot",
    
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    
    # KuCoin
    "0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91": "KuCoin",
    
    # WhiteBIT
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    
    # Bitget
    "0x97b9d2102a9a65a26e1ee82d59e42d1b73b68689": "Bitget",
    "0x0639556f03714a74a5feeaf5736a4a64ff70d206": "Bitget",
}

# Large destinations to check
CHECK_ADDRESSES = [
    ("0x7237b8a4b2dd97dcddb758feac0e8d925016694c", 691000, "Largest - likely Gate.io"),
    ("0x63aabab8bc31c4f360ae6c7cf78f67f118f2154c", 136350, "Second - from HOP1"),
    ("0x525254e58c25d9ac127c63af9a9830f7e5a91a0b", 35300, "Third - from HOP1"),
    ("0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e", 28280, "From main wallet"),
    ("0xb685760ebd368a891f27ae547391f4e2a289895b", 59500, "From P2P dist"),
]

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def check_exchange(address, amount, note):
    """Check where this address sent funds to identify exchange"""
    print(f"\n{'='*80}")
    print(f"Address: {address}")
    print(f"Amount: ${amount:,}")
    print(f"Note: {note}")
    print(f"{'='*80}")
    
    # Get USDT outflows
    token_txs = api_call("account", "tokentx", {
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    current = api_call("account", "tokenbalance", {"contractaddress": USDT_CONTRACT, "address": address})
    balance = Decimal(current) / Decimal(10**6) if current else Decimal(0)
    
    print(f"Current balance: ${balance:,.2f}")
    
    outflows_to = {}
    for tx in token_txs:
        if tx["from"].lower() != address.lower():
            continue
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue
        dest = tx["to"].lower()
        outflows_to[dest] = outflows_to.get(dest, 0) + float(value)
    
    if outflows_to:
        print("\nOutflows to:")
        for dest, amt in sorted(outflows_to.items(), key=lambda x: x[1], reverse=True)[:5]:
            exchange = KNOWN_HOT_WALLETS.get(dest, "Unknown")
            print(f"  {dest}: ${amt:,.2f} -> {exchange}")
    else:
        print("No outflows - likely EXCHANGE DEPOSIT ADDRESS")
        # Check if it receives then sweeps
        
    return {
        "address": address,
        "amount_received": amount,
        "current_balance": float(balance),
        "outflows": outflows_to
    }

def main():
    print("IDENTIFYING EXCHANGE DEPOSIT ADDRESSES")
    print("="*80)
    
    results = []
    for addr, amt, note in CHECK_ADDRESSES:
        result = check_exchange(addr, amt, note)
        results.append(result)
    
    print("\n\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    for r in results:
        if r["current_balance"] == 0 and not r["outflows"]:
            print(f"\n{r['address']}")
            print(f"  EXCHANGE DEPOSIT - ${r['amount_received']:,} (swept to hot wallet)")
        elif r["outflows"]:
            total_out = sum(r["outflows"].values())
            print(f"\n{r['address']}")
            print(f"  Routing wallet - ${r['amount_received']:,} in, ${total_out:,.0f} out")

if __name__ == "__main__":
    main()
