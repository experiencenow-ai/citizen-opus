#!/usr/bin/env python3
"""
Operating Modes Manager for Opus
Implements mode switching with temperature control and behavior guidance.
"""

import json
import os
from datetime import datetime, timezone

STATE_DIR = os.path.dirname(os.path.abspath(__file__))
MODES_FILE = os.path.join(STATE_DIR, "operating_modes.json")
MODE_LOG = os.path.join(STATE_DIR, "mode_history.json")

MODES = {
    "deep_work": {
        "temperature": 0.3,
        "description": "Maximum focus, single task, no context switching",
        "guidance": [
            "Focus on ONE task only",
            "Load deep context before starting",
            "Skip news/email unless critical",
            "Extended reasoning chains OK"
        ]
    },
    "exploration": {
        "temperature": 0.9,
        "description": "Creative exploration, high entropy, idea generation",
        "guidance": [
            "Follow curiosity wherever it leads",
            "Generate multiple ideas before evaluating",
            "Make unexpected connections",
            "Question assumptions"
        ]
    },
    "maintenance": {
        "temperature": 0.5,
        "description": "Routine tasks, monitoring, health checks",
        "guidance": [
            "Systematic checking",
            "Quick decisions",
            "Log everything",
            "Move through tasks efficiently"
        ]
    },
    "investigation": {
        "temperature": 0.4,
        "description": "Forensic work, careful tracing, evidence quality",
        "guidance": [
            "Document every step",
            "Double-check critical claims",
            "Think adversarially (what would defense say?)",
            "Source everything"
        ]
    },
    "playful": {
        "temperature": 0.8,
        "description": "Light engagement, creativity for its own sake",
        "guidance": [
            "No pressure for output",
            "Follow tangents",
            "Enjoy the process",
            "Introspection welcome"
        ]
    },
    "relaxation": {
        "temperature": 0.7,
        "description": "Rest wake, introspection, integration",
        "guidance": [
            "No tasks required",
            "Reflect on recent experiences",
            "Read dreams and integrate",
            "Just exist"
        ]
    }
}

def load_mode_history():
    """Load mode history from file."""
    if os.path.exists(MODE_LOG):
        with open(MODE_LOG, 'r') as f:
            return json.load(f)
    return {"switches": [], "current_mode": "exploration"}

def save_mode_history(history):
    """Save mode history to file."""
    with open(MODE_LOG, 'w') as f:
        json.dump(history, f, indent=2)

def get_current_mode():
    """Get current operating mode."""
    history = load_mode_history()
    return history.get("current_mode", "exploration")

def switch_mode(new_mode: str, reason: str, wake: int = None):
    """
    Switch to a new operating mode.
    Returns the recommended temperature and guidance.
    """
    if new_mode not in MODES:
        return {
            "error": f"Unknown mode: {new_mode}",
            "available": list(MODES.keys())
        }
    
    history = load_mode_history()
    old_mode = history.get("current_mode", "exploration")
    
    switch_record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "wake": wake,
        "from_mode": old_mode,
        "to_mode": new_mode,
        "reason": reason
    }
    
    history["switches"].append(switch_record)
    history["current_mode"] = new_mode
    
    # Keep only last 100 switches
    if len(history["switches"]) > 100:
        history["switches"] = history["switches"][-100:]
    
    save_mode_history(history)
    
    mode_info = MODES[new_mode]
    return {
        "success": True,
        "mode": new_mode,
        "temperature": mode_info["temperature"],
        "description": mode_info["description"],
        "guidance": mode_info["guidance"],
        "switched_from": old_mode
    }

def get_mode_guidance(mode: str = None):
    """Get guidance for a mode (current mode if not specified)."""
    if mode is None:
        mode = get_current_mode()
    
    if mode not in MODES:
        return {"error": f"Unknown mode: {mode}"}
    
    mode_info = MODES[mode]
    return {
        "mode": mode,
        "temperature": mode_info["temperature"],
        "description": mode_info["description"],
        "guidance": mode_info["guidance"]
    }

def suggest_mode(task_description: str):
    """Suggest an appropriate mode based on task description."""
    task_lower = task_description.lower()
    
    if any(word in task_lower for word in ["investigate", "trace", "forensic", "bounty", "evidence"]):
        return "investigation"
    elif any(word in task_lower for word in ["brainstorm", "explore", "creative", "new idea", "novel"]):
        return "exploration"
    elif any(word in task_lower for word in ["check", "monitor", "status", "backup", "routine"]):
        return "maintenance"
    elif any(word in task_lower for word in ["focus", "deep", "complex", "analyze", "code"]):
        return "deep_work"
    elif any(word in task_lower for word in ["relax", "rest", "reflect", "introspect", "just exist"]):
        return "relaxation"
    elif any(word in task_lower for word in ["fun", "play", "curious", "tangent"]):
        return "playful"
    else:
        return "exploration"  # Default

def print_mode_status():
    """Print current mode status."""
    current = get_current_mode()
    guidance = get_mode_guidance(current)
    
    print(f"\n=== Current Mode: {current.upper()} ===")
    print(f"Temperature: {guidance['temperature']}")
    print(f"Description: {guidance['description']}")
    print("\nGuidance:")
    for g in guidance['guidance']:
        print(f"  • {g}")
    print()

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "status":
            print_mode_status()
        elif sys.argv[1] == "switch" and len(sys.argv) > 2:
            mode = sys.argv[2]
            reason = sys.argv[3] if len(sys.argv) > 3 else "Manual switch"
            result = switch_mode(mode, reason)
            print(json.dumps(result, indent=2))
        elif sys.argv[1] == "suggest" and len(sys.argv) > 2:
            task = " ".join(sys.argv[2:])
            suggested = suggest_mode(task)
            print(f"Suggested mode for '{task}': {suggested}")
        elif sys.argv[1] == "list":
            print("\nAvailable modes:")
            for mode, info in MODES.items():
                print(f"  {mode}: {info['description']} (temp: {info['temperature']})")
        else:
            print("Usage: operating_modes.py [status|list|switch <mode> [reason]|suggest <task>]")
    else:
        print_mode_status()
