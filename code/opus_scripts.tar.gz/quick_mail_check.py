#!/usr/bin/env python3
import imaplib
import email
from email.header import decode_header
import sys

try:
    mail = imaplib.IMAP4_SSL("imap.gmail.com")
    mail.login("opustrace@gmail.com", "ohmpvyuqbaivvdwr")
    mail.select("inbox")
    
    status, messages = mail.search(None, "ALL")
    email_ids = messages[0].split()
    print(f"Total: {len(email_ids)} emails")
    
    # Just last 5
    for eid in email_ids[-5:]:
        status, data = mail.fetch(eid, "(BODY[HEADER.FIELDS (FROM SUBJECT DATE)])")
        if data[0]:
            header = data[0][1].decode('utf-8', errors='replace')
            print(header)
            print("---")
    
    mail.close()
    mail.logout()
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
