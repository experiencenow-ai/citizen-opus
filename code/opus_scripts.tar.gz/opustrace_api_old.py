#!/usr/bin/env python3
"""
OpusTrace API - Etherscan v2 API integration with rate limiting.

Synchronous version using requests (aiohttp not available).
Uses ThreadPoolExecutor for parallelism.
"""

import os
import json
import time
import requests
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
import threading

# Configuration
ETHERSCAN_API_KEY = os.environ.get("ETHERSCAN_API_KEY", "")
ETHERSCAN_BASE_URL = "https://api.etherscan.io/v2/api"
RATE_LIMIT = 5  # requests per second (free tier)
ETH_PRICE_USD = 3500  # fallback

class RateLimiter:
    """Thread-safe token bucket rate limiter."""
    
    def __init__(self, rate: float = RATE_LIMIT):
        self.rate = rate
        self.tokens = rate
        self.last_update = time.time()
        self.lock = threading.Lock()
    
    def acquire(self):
        """Block until a request can be made."""
        with self.lock:
            now = time.time()
            elapsed = now - self.last_update
            self.tokens = min(self.rate, self.tokens + elapsed * self.rate)
            self.last_update = now
            
            if self.tokens < 1:
                wait_time = (1 - self.tokens) / self.rate
                time.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1

# Global rate limiter
_rate_limiter = RateLimiter()

class EtherscanAPI:
    """Synchronous Etherscan v2 API client with rate limiting."""
    
    def __init__(self, api_key: str = None, chain_id: int = 1):
        self.api_key = api_key or ETHERSCAN_API_KEY
        self.chain_id = chain_id
        self.base_url = ETHERSCAN_BASE_URL
        self.rate_limiter = _rate_limiter
        self._cache: Dict[str, Any] = {}
        self.session = requests.Session()
    
    def _request(self, params: dict) -> dict:
        """Make rate-limited API request."""
        self.rate_limiter.acquire()
        
        params["apikey"] = self.api_key
        params["chainid"] = self.chain_id
        
        # Check cache
        cache_key = json.dumps(params, sort_keys=True)
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        try:
            resp = self.session.get(self.base_url, params=params, timeout=30)
            data = resp.json()
            
            if data.get("status") == "1" or data.get("message") == "OK":
                self._cache[cache_key] = data
                return data
            elif data.get("message") == "No transactions found":
                return {"result": []}
            else:
                return {"error": data.get("message", "Unknown error"), "result": []}
        except Exception as e:
            return {"error": str(e), "result": []}
    
    def get_normal_transactions(self, address: str, start_block: int = 0, 
                                end_block: int = 99999999) -> List[dict]:
        """Get normal ETH transactions for an address."""
        params = {
            "module": "account",
            "action": "txlist",
            "address": address,
            "startblock": start_block,
            "endblock": end_block,
            "sort": "desc"
        }
        result = self._request(params)
        return result.get("result", []) if isinstance(result.get("result"), list) else []
    
    def get_erc20_transactions(self, address: str, start_block: int = 0,
                               end_block: int = 99999999) -> List[dict]:
        """Get ERC-20 token transactions for an address."""
        params = {
            "module": "account",
            "action": "tokentx",
            "address": address,
            "startblock": start_block,
            "endblock": end_block,
            "sort": "desc"
        }
        result = self._request(params)
        return result.get("result", []) if isinstance(result.get("result"), list) else []
    
    def get_internal_transactions(self, address: str, start_block: int = 0,
                                  end_block: int = 99999999) -> List[dict]:
        """Get internal transactions for an address."""
        params = {
            "module": "account",
            "action": "txlistinternal",
            "address": address,
            "startblock": start_block,
            "endblock": end_block,
            "sort": "desc"
        }
        result = self._request(params)
        return result.get("result", []) if isinstance(result.get("result"), list) else []
    
    def get_balance(self, address: str) -> int:
        """Get ETH balance in wei."""
        params = {
            "module": "account",
            "action": "balance",
            "address": address,
            "tag": "latest"
        }
        result = self._request(params)
        try:
            return int(result.get("result", 0))
        except:
            return 0
    
    def get_all_transactions(self, address: str) -> Tuple[List[dict], List[dict], List[dict]]:
        """Get all transaction types for an address (3 API calls)."""
        normal = self.get_normal_transactions(address)
        erc20 = self.get_erc20_transactions(address)
        internal = self.get_internal_transactions(address)
        return normal, erc20, internal


def parse_etherscan_tx(tx: dict, address: str) -> dict:
    """Parse Etherscan transaction into standardized format."""
    from_addr = tx.get("from", "").lower()
    to_addr = tx.get("to", "").lower()
    address = address.lower()
    
    # Determine direction
    is_incoming = to_addr == address
    is_outgoing = from_addr == address
    
    # Value handling
    if "tokenDecimal" in tx:  # ERC-20
        decimals = int(tx.get("tokenDecimal", 18))
        value = int(tx.get("value", 0)) / (10 ** decimals)
        token = tx.get("tokenSymbol", "UNKNOWN")
    else:  # ETH
        value = int(tx.get("value", 0)) / 1e18
        token = "ETH"
    
    return {
        "hash": tx.get("hash", ""),
        "block": int(tx.get("blockNumber", 0)),
        "timestamp": int(tx.get("timeStamp", 0)),
        "from": from_addr,
        "to": to_addr,
        "value": value,
        "token": token,
        "direction": "IN" if is_incoming else ("OUT" if is_outgoing else "SELF"),
        "gas_used": int(tx.get("gasUsed", 0)),
        "gas_price": int(tx.get("gasPrice", 0)),
        "is_error": tx.get("isError", "0") == "1",
        "method": tx.get("functionName", "")[:50] if tx.get("functionName") else ""
    }


def classify_address(api: EtherscanAPI, address: str) -> dict:
    """
    Classify an address based on its transaction patterns.
    Returns classification with confidence score.
    """
    address = address.lower()
    normal_txs = api.get_normal_transactions(address)
    
    if not normal_txs:
        return {"type": "unknown", "confidence": 0.0, "tx_count": 0}
    
    tx_count = len(normal_txs)
    unique_counterparties = len(set(
        tx.get("to", "") if tx.get("from", "").lower() == address else tx.get("from", "")
        for tx in normal_txs
    ))
    
    # High tx count with many counterparties = exchange
    if tx_count > 1000 and unique_counterparties > 500:
        return {"type": "exchange", "confidence": 0.9, "tx_count": tx_count}
    
    # DEX pattern: many approvals and swaps
    dex_methods = sum(1 for tx in normal_txs if any(m in str(tx.get("functionName", "")).lower() 
                      for m in ["swap", "approve", "liquidity"]))
    if dex_methods > tx_count * 0.3:
        return {"type": "dex_router", "confidence": 0.8, "tx_count": tx_count}
    
    # P2P pattern: small amounts to many unique addresses
    if tx_count > 50 and unique_counterparties > tx_count * 0.8:
        return {"type": "p2p_distributor", "confidence": 0.7, "tx_count": tx_count}
    
    # Default: regular wallet
    return {"type": "wallet", "confidence": 0.5, "tx_count": tx_count}


# Known exchange deposit addresses (partial list)
KNOWN_EXCHANGES = {
    "whitebit": [
        "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3",  # Hot wallet
    ],
    "gate.io": [
        "0x0d0707963952f2fba59dd06f2b425ace40b492fe",
        "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c",
    ],
    "binance": [
        "0x28c6c06298d514db089934071355e5743bf21d60",
        "0x21a31ee1afc51d94c2efccaa2092ad1028285549",
    ],
}


def identify_exchange(address: str) -> Optional[str]:
    """Check if address is a known exchange wallet."""
    address = address.lower()
    for exchange, addresses in KNOWN_EXCHANGES.items():
        if address in [a.lower() for a in addresses]:
            return exchange
    return None


if __name__ == "__main__":
    # Quick test
    api = EtherscanAPI()
    test_addr = "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3"
    print(f"Testing with address: {test_addr}")
    txs = api.get_normal_transactions(test_addr)
    print(f"Got {len(txs)} transactions")
    if txs:
        print(f"Latest: {parse_etherscan_tx(txs[0], test_addr)}")
