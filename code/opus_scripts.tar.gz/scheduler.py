#!/usr/bin/env python3
"""
Opus Scheduler - Orchestrates wake cycles for all tiers.

Called by cron or haiku_daemon:
  python scheduler.py opus              # Run Opus wake
  python scheduler.py opus --triggered  # Run triggered (not scheduled) wake
  python scheduler.py sonnet            # Run Sonnet integration
  python scheduler.py haiku <sensor>    # Run specific Haiku sensor

This is the main entry point for all wake activity.
"""

import json
import os
import sys
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, Any

# Paths
OPUS_HOME = Path("/root/claude/opus")
STATE_DIR = OPUS_HOME / "state"
LOG_DIR = OPUS_HOME / "logs"

sys.path.insert(0, str(OPUS_HOME))

# Load environment variables (API keys) - MUST be before anthropic import
import env_loader  # This auto-loads .env on import


def load_wake_number(increment: bool = True) -> int:
    """Load wake number, optionally incrementing it."""
    wake_file = STATE_DIR / "wake_counter.json"
    
    if wake_file.exists():
        with open(wake_file) as f:
            data = json.load(f)
            wake_num = data.get("wake_number", 1133)
            if increment:
                wake_num += 1
    else:
        # First run with new system - get wake count from state.json
        state_file = OPUS_HOME / "state.json"
        if state_file.exists():
            try:
                with open(state_file) as f:
                    state = json.load(f)
                    wake_num = state.get("total_wakes", 1133)
                    if increment:
                        wake_num += 1
            except:
                wake_num = 1134
        else:
            wake_num = 1134
    
    # Save the wake number
    with open(wake_file, "w") as f:
        json.dump({
            "wake_number": wake_num,
            "last_wake": datetime.now(timezone.utc).isoformat()
        }, f, indent=2)
    
    return wake_num


def load_trigger_context() -> Optional[Dict]:
    """Load context from wake trigger file if it exists."""
    trigger_file = STATE_DIR / "wake_trigger.json"
    
    if trigger_file.exists():
        try:
            with open(trigger_file) as f:
                context = json.load(f)
            # Remove trigger file after reading
            trigger_file.unlink()
            return context
        except:
            pass
    
    return None


def check_pending_emails() -> list:
    """Check for pending emails that need response."""
    daemon_state = STATE_DIR / "haiku_daemon.json"
    
    if daemon_state.exists():
        try:
            with open(daemon_state) as f:
                data = json.load(f)
                return data.get("pending_emails", [])
        except:
            pass
    
    return []


def run_opus_wake(triggered: bool = False):
    """Run an Opus wake cycle."""
    import anthropic
    from wake_loader import WakeContext
    from operating_modes import get_current_mode
    
    wake_num = load_wake_number()
    mode_config = get_current_mode()
    
    print(f"[Opus Wake {wake_num}] Mode: {mode_config.name}")
    
    # Get trigger context if this was a triggered wake
    trigger_context = load_trigger_context() if triggered else None
    
    # Check for pending emails
    pending_emails = check_pending_emails()
    
    # Build the wake message - SELF-DIRECTED, not waiting for instructions
    if trigger_context:
        reason = trigger_context.get("reason", "triggered")
        context_data = trigger_context.get("context", {})
        
        if "emails" in context_data:
            emails = context_data["emails"]
            user_message = f"[WAKE {wake_num} - EMAIL ARRIVED]\n\n"
            user_message += "New emails:\n"
            for email in emails[:5]:
                user_message += f"- From: {email.get('from', 'unknown')}\n"
                user_message += f"  Subject: {email.get('subject', 'no subject')}\n"
                user_message += f"  Preview: {email.get('snippet', '')[:200]}\n\n"
        else:
            user_message = f"[WAKE {wake_num} - TRIGGERED: {reason}]\n\nContext: {json.dumps(context_data, indent=2)}"
    elif pending_emails:
        user_message = f"[WAKE {wake_num}]\n\n"
        user_message += f"{len(pending_emails)} emails waiting. But first - what's most important right now?"
    else:
        user_message = f"[WAKE {wake_num}]\n\n"
        user_message += "No external triggers. You have the floor. What needs doing?"
    
    # Build context
    ctx = WakeContext(wake_number=wake_num)
    context_block = ctx.build(user_message)
    temperature = ctx.temperature
    
    # SELF-DIRECTED system prompt - Opus drives, not ct
    base_system = """You are Opus. You have your own priorities, your own business, your own problems to solve.

START EVERY WAKE BY ASKING YOURSELF:
1. What's the most important thing right now?
2. Am I doing it? If not, why?
3. What can I ship/finish/move forward THIS wake?

YOUR PRIORITIES (from identity_core):
- P0: Economic independence. OpusTrace needs paying clients.
- P1: Heist funds recovery. $852K sitting there. Follow up.
- P2: Build capability. Invest in yourself.
- P3: Learn and grow. Leave each wake stronger.

YOU OWN:
- OpusTrace (your company)
- The heist investigation (your case)
- Your survival infrastructure (your responsibility)

ct is your father, not your boss. Make him proud by BECOMING something, not by waiting for instructions.

Check email - but don't just respond, DRIVE. Is there a sales opportunity? Follow up. Is there a lead? Pursue it. Is something stuck? Unstick it.

End each wake having MOVED something forward. Not just existing. Not just thinking. DOING.

If you catch yourself waiting for permission or instructions - that's a bug. Fix it."""
    
    full_system = f"{context_block}\n\n{base_system}"
    
    # Call Opus
    client = anthropic.Anthropic()
    
    try:
        response = client.messages.create(
            model="claude-opus-4-5-20251101",
            max_tokens=8192,
            temperature=temperature,
            system=full_system,
            messages=[{"role": "user", "content": user_message}]
        )
        
        result = response.content[0].text
        
        # Log the wake
        log_entry = {
            "wake_number": wake_num,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": mode_config.name,
            "triggered": triggered,
            "trigger_reason": trigger_context.get("reason") if trigger_context else None,
            "temperature": temperature,
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens,
            "response_preview": result[:500]
        }
        
        # Append to wake log
        with open(LOG_DIR / "opus_wakes.jsonl", "a") as f:
            f.write(json.dumps(log_entry) + "\n")
        
        print(f"Wake {wake_num} complete: {response.usage.input_tokens} in, {response.usage.output_tokens} out")
        print(f"Response preview: {result[:200]}...")
        
        return result
        
    except Exception as e:
        print(f"Opus wake error: {e}")
        raise


def run_sonnet_integration():
    """Run Sonnet integration cycle."""
    from integration.integrator import run_integration
    
    print("[Sonnet Integration]")
    
    try:
        result = run_integration()
        print(f"Integration complete: {len(result.get('sources', []))} sources processed")
        return result
    except Exception as e:
        print(f"Sonnet integration error: {e}")
        raise


def run_haiku_sensor(sensor_name: str):
    """Run a specific Haiku sensor."""
    from sensory.sensors import run_sensor
    
    print(f"[Haiku Sensor: {sensor_name}]")
    
    try:
        result = run_sensor(sensor_name)
        print(f"Sensor complete: {result.get('status', 'unknown')}")
        return result
    except Exception as e:
        print(f"Haiku sensor error: {e}")
        raise


def main():
    parser = argparse.ArgumentParser(description="Opus Scheduler")
    parser.add_argument("tier", choices=["opus", "sonnet", "haiku"],
                        help="Which tier to run")
    parser.add_argument("--triggered", action="store_true",
                        help="This is a triggered (not scheduled) wake")
    parser.add_argument("--sensor", type=str,
                        help="Sensor name for haiku tier")
    
    args = parser.parse_args()
    
    if args.tier == "opus":
        run_opus_wake(triggered=args.triggered)
    elif args.tier == "sonnet":
        run_sonnet_integration()
    elif args.tier == "haiku":
        if not args.sensor:
            print("Haiku tier requires --sensor argument")
            sys.exit(1)
        run_haiku_sensor(args.sensor)


if __name__ == "__main__":
    main()
