#!/usr/bin/env python3
"""
Trace unknown destinations to find hot wallets
"""

import requests
import json
import time
from decimal import Decimal

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

UNKNOWN_DESTS = [
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23",  # $35K from 0x525254e58...
    "0x18e296053cbdf986196903e889b7dca7a73882f6",  # From multiple sources
]

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def trace_address(address):
    print(f"\n{'='*80}")
    print(f"TRACING: {address}")
    print(f"{'='*80}")
    
    token_txs = api_call("account", "tokentx", {
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    current = api_call("account", "tokenbalance", {"contractaddress": USDT_CONTRACT, "address": address})
    balance = Decimal(current) / Decimal(10**6) if current else Decimal(0)
    
    print(f"Total TXs: {len(token_txs)}")
    print(f"Current balance: ${balance:,.2f}")
    
    total_in = Decimal(0)
    total_out = Decimal(0)
    outflows = {}
    
    for tx in token_txs:
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue
        
        if tx["to"].lower() == address.lower():
            total_in += value
        elif tx["from"].lower() == address.lower():
            total_out += value
            dest = tx["to"].lower()
            outflows[dest] = outflows.get(dest, Decimal(0)) + value
    
    print(f"Total In: ${total_in:,.2f}")
    print(f"Total Out: ${total_out:,.2f}")
    
    if outflows:
        print("\nTop Outflows:")
        for dest, amt in sorted(outflows.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"  {dest}: ${amt:,.2f}")
    else:
        print("NO OUTFLOWS - This is a terminal address (likely exchange hot wallet)")
    
    return {
        "address": address,
        "total_in": float(total_in),
        "total_out": float(total_out),
        "balance": float(balance),
        "outflows": {k: float(v) for k,v in outflows.items()}
    }

def main():
    for addr in UNKNOWN_DESTS:
        trace_address(addr)

if __name__ == "__main__":
    main()
