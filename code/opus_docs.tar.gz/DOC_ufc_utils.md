# UFC Utils Module Documentation

**File:** `UFC/ufc_utils.c`  
**Lines:** 651  
**Module:** UFC (Unified Financial Core)  
**Documented by:** Opus (Wake 1304)

---

## Overview

The UFC Utils module provides utility functions used throughout the UFC system. It includes transaction decoding, inventory management helpers, price targeting calculations, and various mathematical operations. Many core functions have been moved to `frama_verified.c` for formal verification.

---

## Key Concepts

### Inventory Direction
The system tracks whether trades are "hurtful" or "helpful" based on current pool balance:
- **V2O (VUSD to Other)**: Hurtful when pool is VUSD-heavy
- **O2V (Other to VUSD)**: Hurtful when pool is Other-heavy

### Price Targeting
Functions compute target prices for swaps based on:
- Current pool price (UFC price)
- Last traded price
- OOB (Out-of-Band) price for adverse selection protection

---

## Core Functions

### Inventory Management

#### `ufc_inventory_choose_hurtful_dir()`
```c
int32_t ufc_inventory_choose_hurtful_dir(struct valisL1_info *L1, int32_t aid)
```

**Purpose:** Determine which direction (V2O or O2V) is "hurtful" for the pool.

**Algorithm:**
1. Get pool balances (VUSD and other)
2. Calculate TVL in VUSD terms
3. Compute current VUSD percentage
4. Compare to target percentage (default 50%)
5. If VUSD-heavy: V2O is hurtful (returns 1)
6. If Other-heavy: O2V is hurtful (returns 0)

**Returns:** 1 if V2O is hurtful, 0 if O2V is hurtful.

#### `ufc_inventory_flow_is_hurtful()`
```c
int32_t ufc_inventory_flow_is_hurtful(struct valisL1_info *L1, int32_t aid, int32_t is_v2o)
```

**Purpose:** Check if a specific flow direction is hurtful.

**Returns:** 1 if the given direction is hurtful, 0 otherwise.

---

### Transaction Decoding

#### `ufc_decode_pooltx()`
```c
int32_t ufc_decode_pooltx(const struct txheader *tx_hdr, ufc_txdec_t *dec)
```

**Purpose:** Decode a pool transaction into structured form.

**Determines transaction kind:**
- `UFC_KIND_WITHDRAW`: Source is pool share token
- `UFC_KIND_DEPOSIT`: Destination is pool share token
- `UFC_KIND_SWAP_V2O`: Source is VUSD
- `UFC_KIND_SWAP_O2V`: Destination is VUSD
- `UFC_KIND_SWAP_C2C`: Neither is VUSD (coin-to-coin)

**Outputs:**
- `dec->kind`: Transaction type
- `dec->asset_src`: Source asset
- `dec->asset_dst`: Destination asset
- `dec->amount_in`: Input amount

#### `ufc_coin_asset_from_pooltx()`
```c
int32_t ufc_coin_asset_from_pooltx(const struct txheader *tx_hdr,
                                    assetid_t *coin_asset_out,
                                    int32_t *is_deposit_ptr,
                                    int32_t *is_withdraw_ptr,
                                    int32_t *is_swap_vusd2other_ptr,
                                    int32_t *is_swap_other2vusd_ptr)
```

**Purpose:** Extract the non-VUSD asset and transaction type flags from a pool transaction.

#### `ufc_coin_asset_from_ordertx()`
```c
void ufc_coin_asset_from_ordertx(const struct txheader *tx_hdr, assetid_t *coin_asset_out)
```

**Purpose:** Extract the non-VUSD asset from an order transaction.

---

### Price Calculations

#### `ufc_compute_virt_other_to_price_target()`
```c
int64_t ufc_compute_virt_other_to_price_target(struct valisL1_info *L1,
                                                assetid_t pool_asset,
                                                int64_t targetVUSDprice,
                                                int64_t pool_vusd,
                                                int64_t pool_other)
```

**Purpose:** Calculate how much "other" asset is needed to move price to target.

**Algorithm:**
1. Get effective pool balances
2. Calculate current price
3. If already at or above target, return 0
4. Compute required other amount to reach target

**Returns:** Virtual other amount needed.

#### `ufc_compute_virt_vusd_to_price_target()`
```c
int64_t ufc_compute_virt_vusd_to_price_target(struct valisL1_info *L1,
                                               assetid_t pool_asset,
                                               int64_t targetVUSDprice,
                                               int64_t pool_vusd,
                                               int64_t pool_other)
```

**Purpose:** Calculate how much VUSD is needed to move price to target.

**Returns:** Virtual VUSD amount needed.

#### `ufc_choose_target_px_for_swap()`
```c
int64_t ufc_choose_target_px_for_swap(struct valisL1_info *L1,
                                       assetid_t pool_asset,
                                       int64_t last_px,
                                       int64_t ufc_px,
                                       int32_t is_vusd_to_other)
```

**Purpose:** Choose appropriate target price for a swap.

**Logic:**
- If swap is in OOB direction (adverse selection), use OOB price
- Otherwise, use UFC (pool) price

**OOB Direction Detection:**
- V2O: OOB if last_px >= ufc_px (buying into strength)
- O2V: OOB if last_px <= ufc_px (selling into weakness)

---

### Price Clamping

#### `ufc_clamp_vs_prev_for_asset()`
```c
int64_t ufc_clamp_vs_prev_for_asset(struct valisL1_info *L1, int32_t aid,
                                     int64_t prev_price, int64_t candidate_price,
                                     int32_t *out_clamp_bps)
```

**Purpose:** Clamp price movement to prevent excessive volatility.

**Algorithm:**
1. Get clamp parameters (max move BPS, floor BPS)
2. Load alpha state for premium information
3. Adjust clamp based on:
   - Premium relative to TVL
   - TVL size
   - Tock lag
4. Apply asymmetric clamping (up vs down)
5. Return clamped price

**Outputs:**
- Returns: Clamped price
- `out_clamp_bps`: Actual clamp applied in BPS

---

### Lag Management

#### `get_tocklag()`
```c
int32_t get_tocklag(struct valisL1_info *L1)
```

**Purpose:** Get current tock processing lag in seconds.

**Calculation:** `processed_utime - validator_utime`

#### `ufc_should_halt_swaps_for_lag()`
```c
int32_t ufc_should_halt_swaps_for_lag(struct valisL1_info *L1)
```

**Purpose:** Check if swaps should be halted due to excessive lag.

**Returns:** 1 if lag exceeds `LAGGING_REJECT_TAKER_ORDERS`, 0 otherwise.

---

## Functions Moved to frama_verified.c

The following functions were moved for formal verification:
- `safe_mul_then_div` - Safe multiply-divide operation
- `ufc_pool_oob_sure_cap_from_balances` - OOB capacity calculation
- `ufc_compute_oob_price_simple` - Simple OOB price computation
- `ufc_calc_premium_vusd` - Premium calculation in VUSD
- `ufc_leg_vusd_from_amount` - VUSD value from leg amount
- `ufc_age_weight` - Age-based weighting
- `ufc_clamp_vs_prev` - Basic price clamping

---

## Helper Functions

#### `pool_effective_balances()`
Gets effective pool balances accounting for any adjustments.

---

## Constants Used

| Constant | Purpose |
|----------|---------|
| `UFC_OOB_TARGET_END_PCT_BPS` | Target inventory percentage (default 5000 = 50%) |
| `UFC_OOB_GAIN_BPS` | Default OOB gain in basis points |
| `UFC_OOB_CLAMP_BPS` | Maximum OOB price deviation |
| `UFC_MAX_MOVE_BPS` | Maximum price move per update |
| `UFC_ALPHA_FLOW_REL_BPS_CAP` | Cap on flow relative to TVL |
| `BPS_DENOM` | Basis points denominator (10000) |
| `SATOSHIS` | Price scaling factor |
| `LAGGING_REJECT_TAKER_ORDERS` | Lag threshold for halting swaps |

---

## Data Structures

### `ufc_txdec_t`
Decoded transaction structure:
```c
typedef struct {
    int32_t kind;        // UFC_KIND_*
    assetid_t asset_src; // Source asset
    assetid_t asset_dst; // Destination asset
    int64_t amount_in;   // Input amount
} ufc_txdec_t;
```

### Transaction Kinds
```c
UFC_KIND_DEPOSIT      // Add liquidity
UFC_KIND_WITHDRAW     // Remove liquidity
UFC_KIND_SWAP_V2O     // VUSD → Other
UFC_KIND_SWAP_O2V     // Other → VUSD
UFC_KIND_SWAP_C2C     // Coin → Coin (neither VUSD)
```

---

## Integration Points

- **ufc.h**: Type definitions and constants
- **validator.h**: Transaction validation types
- **frama_verified.c**: Formally verified core functions
- **ufc_planner.c**: Uses inventory direction helpers
- **ufc_swap.c**: Uses price targeting functions
- **ufc_oob.c**: Uses OOB price calculations

---

## Design Philosophy

1. **Separation of Concerns**: Core math moved to frama_verified.c for verification
2. **Defensive Programming**: Extensive null checks and bounds validation
3. **Inventory Awareness**: All pricing considers current pool balance
4. **Lag Protection**: System can halt during excessive lag to prevent stale pricing
