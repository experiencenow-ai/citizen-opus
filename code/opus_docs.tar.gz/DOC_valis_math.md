# valis_math.c Documentation

**File:** `/root/valis/utils/valis_math.c`  
**Lines:** 1216  
**Documented:** Wake 1301  
**Author:** Opus

---

## Overview

`valis_math.c` provides core mathematical utilities for the Tockchain system. It handles:

1. **128-bit Arithmetic** - Portable multiplication and division for large integers
2. **Safe Integer Operations** - Overflow-protected arithmetic with error handling
3. **Decimal Conversion** - String-to-satoshi and satoshi-to-uint256 conversions
4. **Hex/Binary Utilities** - Conversion between hex strings and byte arrays
5. **Hash Functions** - Non-cryptographic hashing for checksums and mixing
6. **AMM Calculations** - Constant-product swap calculations
7. **Consensus Utilities** - Epoch-based node selection and merkle tree computation

---

## Constants

```c
#define MINPOOL_SATOSHIS 10              // Minimum pool balance for swaps
#define MIX_FINAL_M1     0xff51afd7ed558ccdULL  // MurmurHash3 finalizer constant
#define MIX_FINAL_M2     0xc4ceb9fe1a85ec53ULL  // MurmurHash3 finalizer constant
#define MIX_GOLDEN64     0x9E3779B185EBCA87ULL  // Knuth golden ratio (decorrelation)
```

---

## 128-bit Arithmetic

### portable_mul128

```c
int portable_mul128(uint64_t a, uint64_t b, uint64_t res[2])
```

Multiplies two 64-bit values into a 128-bit result.

**Parameters:**
- `a`, `b`: 64-bit multiplicands
- `res[2]`: Output array where `res[0]` = low 64 bits, `res[1]` = high 64 bits

**Returns:** Always 0 (success)

**Implementation:** Uses schoolbook multiplication by splitting each 64-bit value into two 32-bit halves, computing partial products, and combining with carry propagation.

### portable_div128

```c
int portable_div128(uint64_t num[2], uint64_t den, uint64_t *q, uint64_t *rem)
```

Divides a 128-bit number by a 64-bit divisor.

**Parameters:**
- `num[2]`: 128-bit dividend (`num[0]` = low, `num[1]` = high)
- `den`: 64-bit divisor
- `q`: Output quotient
- `rem`: Output remainder

**Returns:**
- `0`: Success
- `-1`: Division by zero or quotient exceeds `MAXCOINSUPPLY`

**Implementation:** Bit-by-bit long division, processing from MSB to LSB.

---

## Safe Integer Operations

### safe_mul_div

```c
int64_t safe_mul_div(int64_t a, int64_t b, int64_t c, int round_flag, int64_t div0_err)
```

Computes `(a * b) / c` with overflow protection.

**Parameters:**
- `a`, `b`: Multiplicands
- `c`: Divisor
- `round_flag`: If non-zero, round result (currently not implemented in portable version)
- `div0_err`: Value to return on division by zero

**Returns:** Result or `div0_err` on error

**Note:** Delegates to `safe_mul_then_div()` from `frama_verified.c`.

### safe_add_int128

```c
int safe_add_int128(int64_t val[2], int64_t addend)
```

Adds a 64-bit value to a 128-bit accumulator.

**Parameters:**
- `val[2]`: 128-bit accumulator (modified in place)
- `addend`: Value to add (must be non-negative)

**Returns:**
- `0`: Success
- `-1`: Overflow
- `-3`: Negative addend

### safe_accumulate_adj

```c
int64_t safe_accumulate_adj(int64_t val[2], int64_t mul_quot)
```

Wrapper for accumulating multiplication quotients.

**Returns:** `0` on success, `-1` on error

---

## Price Calculation

### calc_price

```c
int64_t calc_price(int64_t vusd, int64_t other)
```

Calculates price as `(vusd * SATOSHIS) / other`.

**Parameters:**
- `vusd`: Value in VUSD (satoshi units)
- `other`: Denominator amount

**Returns:** Price in satoshis, or `0` on division by zero

---

## String/Number Conversion

### string_to_int64

```c
int32_t string_to_int64(const char *str, int64_t *result)
```

Parses a decimal string (with up to 8 decimal places) into satoshi units.

**Input Format:** `[-]integer[.fraction]`
- Supports optional sign
- Fractional part padded/truncated to 8 decimal places
- Result scaled by 10^8 (satoshi conversion)

**Returns:**
- `true` (1): Success
- Negative values: Various parse errors
  - `-1`: Integer overflow during parsing
  - `-2`: Digit overflow
  - `-3`: Invalid character in fractional part
  - `-4`: Invalid character after integer
  - `-5` to `-8`: Scaling/bounds overflow

**Example:** `"1.5"` → `150000000` (1.5 * 10^8)

---

## Big Number Conversion (GMP-based)

### u256bin_to_63bit_with_8decimals

```c
int32_t u256bin_to_63bit_with_8decimals(const uint8_t be32[32], uint8_t decimals, 
                                         uint8_t scaling_factor_decimals, uint64_t *result)
```

Converts a 256-bit big-endian value to a 64-bit satoshi amount with decimal scaling.

**Parameters:**
- `be32`: 32-byte big-endian uint256
- `decimals`: Token's decimal places
- `scaling_factor_decimals`: Additional scaling factor
- `result`: Output in satoshi units

**Scaling Logic:**
- If `decimals >= 8`: Divide by `10^(decimals - 8 + scaling_factor_decimals)`
- If `decimals < 8`: Multiply by `10^(8 - decimals - scaling_factor_decimals)`

**Returns:** `0` on success, negative on error

### int63_to_be32_scaled

```c
int int63_to_be32_scaled(int64_t value, uint8_t decimals, 
                         uint8_t scaling_factor_decimals, uint8_t out_be32[32])
```

Inverse of above - converts satoshi amount to 256-bit big-endian.

**Returns:** `0` on success, negative on error

---

## Hex Utilities

### hex_nibble

```c
static int hex_nibble(char c)
```

Converts hex character to value (0-15).

**Returns:** Value or `-1` for invalid character

### hex_to_be32

```c
int hex_to_be32(const char *hex, uint8_t out_be32[32])
```

Parses hex string into 32-byte big-endian array.

**Features:**
- Handles optional `0x`/`0X` prefix
- Supports odd-length strings (implicit leading zero)
- Right-pads with zeros if < 64 hex chars

**Returns:** `0` on success, negative on error

---

## Hash Functions (Non-Cryptographic)

### calc_checksum64

```c
uint64_t calc_checksum64(uint8_t *data, int32_t len, uint64_t seed)
```

Fast 64-bit checksum using MurmurHash3-inspired mixing.

**Algorithm:**
1. Process 8 bytes at a time with XOR-shift mixing
2. Handle remaining bytes as tail
3. Apply MurmurHash3 64-bit finalizer

**Use Case:** Fast checksums, hash table keys, deduplication - NOT for cryptographic purposes.

### listmix64_stride_off

```c
uint64_t listmix64_stride_off(void *base, uint32_t count, uint32_t stride_bytes, 
                               uint32_t field_offset, uint64_t seed)
```

Mixes a list of structures by reading 8-byte fields at specified offsets.

**Parameters:**
- `base`: Pointer to array
- `count`: Number of elements
- `stride_bytes`: Size of each element
- `field_offset`: Byte offset of 8-byte field to mix
- `seed`: Initial seed

**Variants:**
- `listmix64_stride()`: Field offset = 0
- `listmix64_from_u64()`: For contiguous uint64_t arrays

---

## AMM Swap Calculation

### swapcalc

```c
int64_t swapcalc(int32_t swaptype, int64_t amount, int64_t srcbalance, 
                 int64_t destbalance, int64_t poolshares)
```

Constant-product AMM swap calculation (x * y = k).

**Parameters:**
- `swaptype`: Swap type (currently unused)
- `amount`: Input amount
- `srcbalance`: Source pool balance
- `destbalance`: Destination pool balance
- `poolshares`: Pool shares (currently unused)

**Formula:** `dy = destbalance - (srcbalance * destbalance) / (srcbalance + amount)`

**Guards:**
- Returns `0` if any balance ≤ 0
- Returns `0` if `destbalance < MINPOOL_SATOSHIS`
- Pool-favoring rounding (truncates output)

**Returns:** Output amount, or `0`/negative on error

---

## Consensus Utilities

### compute_stride_for_epoch

```c
static inline uint32_t compute_stride_for_epoch(uint32_t node_count, uint64_t epoch_index, 
                                                 uint64_t epoch_salt)
```

Deterministically computes a stride value for epoch-based node selection.

**Returns:** Stride in range `[1, node_count-1]`, or `0` if `node_count <= 1`

### compute_destination_for_node

```c
int32_t compute_destination_for_node(int32_t nodeid, int32_t numvalidators, 
                                      int32_t epoch, uint64_t epoch_salt)
```

Maps a node to its destination for fan-out messaging.

**Formula:** `destination = (nodeid + stride) % numvalidators`

**Guarantees:** Creates a permutation (no overlaps) when `numvalidators >= 2`

### elected_sender_hrw

```c
uint64_t elected_sender_hrw(uint64_t item_id, uint64_t epoch_index, 
                            uint64_t epoch_salt, uint32_t node_id)
```

Rendezvous/Highest Random Weight hashing for sender election.

**Use Case:** Multiple potential senders can independently agree on who transmits an item by computing scores and selecting the highest.

---

## Merkle Tree

### _calc_merklehash

```c
struct hash256 _calc_merklehash(struct hash256 *tree, int32_t num, int32_t *merklenump)
```

Computes merkle root from an array of hashes.

**Parameters:**
- `tree`: Array of hashes (modified during computation)
- `num`: Number of leaf hashes
- `merklenump`: Output - total nodes in tree

**Algorithm:**
- Pads odd levels by duplicating last hash
- Iteratively hashes pairs until single root remains

### calc_merkleroot

```c
void calc_merkleroot(uint8_t *txids, int32_t numtx, uint8_t merkleroot[32], 
                     int32_t need_proofofabsence)
```

Wrapper for computing merkle root from transaction IDs.

---

## Bit Manipulation

### bitweight64

```c
int32_t bitweight64(uint64_t bits64, int32_t max)
```

Counts set bits (population count) up to `max` bits.

### bitweight

```c
int32_t bitweight(uint8_t *ptr, int32_t n)
```

Counts set bits in a byte array.

### calc_needmask

```c
uint64_t calc_needmask(int32_t n)
```

Creates a bitmask with first `n` bits set.

---

## Dependencies

- `sha256.h` - SHA256 hashing
- `_valis.h` - Core definitions, `MAXCOINSUPPLY`, `SATOSHIS`
- `frama_verified.h` - Formally verified arithmetic (`safe_mul_then_div`)
- GMP library (`mpz_*`) - Big number operations

---

## Design Notes

1. **Satoshi Units:** All monetary values use satoshi (10^-8) as base unit
2. **Overflow Protection:** Critical operations use 128-bit intermediates
3. **Pool Safety:** AMM calculations include minimum balance guards
4. **Determinism:** Consensus functions use deterministic hashing for agreement
5. **Portability:** 128-bit arithmetic implemented without compiler extensions

---

## Security Considerations

- `calc_checksum64` is NOT cryptographically secure - use only for checksums
- Safe arithmetic functions return error codes that MUST be checked
- GMP operations can fail on memory exhaustion (not explicitly handled)
