# UFC (Unified Fair Clearing) Visual Guide

**Generated:** Wake 1324 (2026-01-13)  
**Purpose:** Visual explanation of UFC's hybrid DEX mechanism

---

## What is UFC?

UFC is a **hybrid DEX** that combines:
- Direct pool (not AMM - no x*y=k)
- Time-of-book (TOB) orderbook
- External signals (oracles, BPF)

Key innovations:
- **No impermanent loss** for LPs
- **No profitable manipulation** long-term
- **1-second (1-tock) cadence**
- **Zero gas fees** (economics via premium flows)

---

## Pool Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           UFC POOL (per asset)                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                        Pool Balances                               │    │
│   │                                                                    │    │
│   │   X = pool_vusd_balance    ──▶ VUSD in pool (satoshis)           │    │
│   │   Y = pool_other_balance   ──▶ Asset in pool (satoshis)          │    │
│   │   S = pool_share_balance   ──▶ Total LP shares outstanding       │    │
│   │                                                                    │    │
│   └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                        Price State                                 │    │
│   │                                                                    │    │
│   │   last_price_sat   ──▶ Previous tock's reference price           │    │
│   │   ufc_price_sat    ──▶ Current neutral UFC price                 │    │
│   │   tvl_vusd         ──▶ Total Value Locked in VUSD                │    │
│   │                                                                    │    │
│   └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                        OOB (Out-of-Balance) State                  │    │
│   │                                                                    │    │
│   │   oob_sure_cap_vusd    ──▶ Max hurtful capacity this tock        │    │
│   │   oob_sure_used_vusd   ──▶ Hurtful capacity used so far          │    │
│   │   oob_premiumvusd_to_vnet ──▶ Premiums collected                 │    │
│   │                                                                    │    │
│   └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Swap Directions

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SWAP DIRECTIONS                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   V2O (VUSD → Other Asset)                                                  │
│   ┌─────────┐                      ┌─────────┐                             │
│   │  User   │ ──── VUSD ─────────▶ │  Pool   │                             │
│   │         │ ◀─── OTHER ───────── │         │                             │
│   └─────────┘                      └─────────┘                             │
│   Example: Buy ETH with VUSD                                                │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   O2V (Other Asset → VUSD)                                                  │
│   ┌─────────┐                      ┌─────────┐                             │
│   │  User   │ ──── OTHER ────────▶ │  Pool   │                             │
│   │         │ ◀─── VUSD ────────── │         │                             │
│   └─────────┘                      └─────────┘                             │
│   Example: Sell ETH for VUSD                                                │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   C2C (Coin → Coin via VUSD)                                               │
│   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐               │
│   │  User   │───▶│ Pool A  │───▶│  VUSD   │───▶│ Pool B  │               │
│   │         │    │ (O2V)   │    │ (leg)   │    │ (V2O)   │               │
│   └─────────┘    └─────────┘    └─────────┘    └─────────┘               │
│   Example: Swap ETH → BTC (decomposes to ETH→VUSD→BTC)                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Helpful vs Hurtful Swaps

The key insight: swaps that **help** the pool rebalance get better prices.
Swaps that **hurt** (push further out of balance) pay premiums.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      HELPFUL vs HURTFUL SWAPS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Pool State: Currently has TOO MUCH ETH, TOO LITTLE VUSD                  │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   HELPFUL SWAP (O2V - selling ETH for VUSD)                        │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │  • Reduces ETH excess                                      │   │  │
│   │   │  • Increases VUSD                                          │   │  │
│   │   │  • Gets BETTER price (no premium)                          │   │  │
│   │   │  • Unlimited capacity                                      │   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │                                                                     │  │
│   │   HURTFUL SWAP (V2O - buying more ETH with VUSD)                   │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │  • Increases ETH excess                                    │   │  │
│   │   │  • Decreases VUSD further                                  │   │  │
│   │   │  • Pays PREMIUM (worse price)                              │   │  │
│   │   │  • LIMITED capacity per tock (oob_sure_cap_vusd)           │   │  │
│   │   │  • Premium goes to VNET (not arbitrageurs)                 │   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## OOB (Out-of-Balance) Capacity

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        OOB CAPACITY SYSTEM                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Per-Tock Capacity Limit                                                   │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   oob_sure_cap_vusd = TVL × dyn_gain_bps / BPS_DENOM               │  │
│   │                                                                     │  │
│   │   Example: $10M TVL × 50 bps = $50,000 hurtful capacity per tock   │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Capacity Usage                                                            │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│   │  │
│   │   │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │   |<---- used (oob_sure_used) ---->|<-- remaining -->|            │  │
│   │                                                                     │  │
│   │   When capacity exhausted: hurtful swaps REJECTED until next tock  │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Why This Matters                                                          │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   • Prevents flash-loan attacks (can't move pool infinitely)       │  │
│   │   • Rate-limits manipulation                                       │  │
│   │   • Premiums compensate LPs for imbalance risk                     │  │
│   │   • Capacity resets each tock (1 second)                           │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Orderbook Integration

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ORDERBOOK + POOL HYBRID                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │                         ORDERBOOK                                   │  │
│   │   ┌─────────────────────────────────────────────────────────────┐  │  │
│   │   │  Limit Orders (Time-of-Book)                                │  │  │
│   │   │                                                             │  │  │
│   │   │  BID (buy)           │  ASK (sell)                         │  │  │
│   │   │  ────────────────────│────────────────────                 │  │  │
│   │   │  100 @ $2000         │  50 @ $2005                         │  │  │
│   │   │  200 @ $1995         │  75 @ $2010                         │  │  │
│   │   │  150 @ $1990         │  100 @ $2015                        │  │  │
│   │   │                      │                                      │  │  │
│   │   └─────────────────────────────────────────────────────────────┘  │  │
│   │                                                                     │  │
│   │                              ↕                                      │  │
│   │                                                                     │  │
│   │                          POOL                                       │  │
│   │   ┌─────────────────────────────────────────────────────────────┐  │  │
│   │   │  Direct Swaps at UFC Price                                  │  │  │
│   │   │                                                             │  │  │
│   │   │  UFC Price: $2002                                          │  │  │
│   │   │  Pool VUSD: 5,000,000                                      │  │  │
│   │   │  Pool ETH:  2,500                                          │  │  │
│   │   │                                                             │  │  │
│   │   └─────────────────────────────────────────────────────────────┘  │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Execution Priority                                                        │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   1. Market orders first fill against orderbook (if better price)  │  │
│   │   2. Then fill remainder against pool at UFC price                 │  │
│   │   3. Limit orders rest on book until matched or cancelled          │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## LP (Liquidity Provider) Operations

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        LIQUIDITY PROVIDER OPERATIONS                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   DEPOSIT (Add Liquidity)                                                   │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   User deposits:  VUSD + OTHER (in current pool ratio)             │  │
│   │   User receives:  Pool shares (proportional to TVL contribution)   │  │
│   │                                                                     │  │
│   │   ┌─────────┐                      ┌─────────┐                     │  │
│   │   │   LP    │ ──── VUSD ─────────▶ │  Pool   │                     │  │
│   │   │         │ ──── OTHER ────────▶ │         │                     │  │
│   │   │         │ ◀─── SHARES ──────── │         │                     │  │
│   │   └─────────┘                      └─────────┘                     │  │
│   │                                                                     │  │
│   │   shares_minted = deposit_vusd_value × S / TVL                     │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   WITHDRAW (Remove Liquidity)                                               │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   User burns:     Pool shares                                      │  │
│   │   User receives:  VUSD + OTHER (proportional to share of pool)     │  │
│   │                                                                     │  │
│   │   ┌─────────┐                      ┌─────────┐                     │  │
│   │   │   LP    │ ──── SHARES ───────▶ │  Pool   │                     │  │
│   │   │         │ ◀─── VUSD ────────── │         │                     │  │
│   │   │         │ ◀─── OTHER ───────── │         │                     │  │
│   │   └─────────┘                      └─────────┘                     │  │
│   │                                                                     │  │
│   │   vusd_out = shares_burned × X / S                                 │  │
│   │   other_out = shares_burned × Y / S                                │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   NO IMPERMANENT LOSS                                                       │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   Unlike AMMs, UFC LPs don't suffer impermanent loss because:      │  │
│   │                                                                     │  │
│   │   • Pool doesn't use x*y=k invariant                               │  │
│   │   • Hurtful swaps pay premiums that accrue to pool                 │  │
│   │   • Price discovery happens via oracle + orderbook, not arb        │  │
│   │   • LPs get proportional share of all premiums collected           │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Tock Lifecycle

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        TOCK (1-SECOND) LIFECYCLE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   TOCK START                                                        │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │  • Reset OOB capacity (oob_sure_used_vusd = 0)             │   │  │
│   │   │  • Update prices from oracles                              │   │  │
│   │   │  • Set ufc_price_sat for each asset                        │   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │                          │                                          │  │
│   │                          ▼                                          │  │
│   │   TRANSACTION PROCESSING                                            │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │  • Validate incoming swaps                                 │   │  │
│   │   │  • Check minout (slippage protection)                      │   │  │
│   │   │  • Classify helpful vs hurtful                             │   │  │
│   │   │  • Track OOB capacity usage                                │   │  │
│   │   │  • Defer execution to end-of-tock                          │   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │                          │                                          │  │
│   │                          ▼                                          │  │
│   │   TOCK END (ufc_end_of_tock_process)                               │  │
│   │   ┌────────────────────────────────────────────────────────────┐   │  │
│   │   │  • Execute all deferred swaps atomically                   │   │  │
│   │   │  • Match orderbook orders                                  │   │  │
│   │   │  • Update pool balances                                    │   │  │
│   │   │  • Route premiums to VNET                                  │   │  │
│   │   │  • Update last_price_sat for next tock                     │   │  │
│   │   └────────────────────────────────────────────────────────────┘   │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Why Deferred Execution?                                                   │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   • All swaps in a tock get the SAME price (fair)                  │  │
│   │   • No front-running within a tock                                 │  │
│   │   • Atomic execution prevents partial fills                        │  │
│   │   • Orderbook + pool matching happens together                     │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Premium Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PREMIUM FLOW                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Where Premiums Come From                                                  │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   1. OOB Premiums (hurtful pool swaps)                             │  │
│   │      • Swaps that push pool further out of balance                 │  │
│   │      • Premium = f(imbalance_degree, swap_size)                    │  │
│   │                                                                     │  │
│   │   2. OB Premiums (orderbook fills)                                 │  │
│   │      • Spread captured from limit order fills                      │  │
│   │      • Premium = execution_price - reference_price                 │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Where Premiums Go                                                         │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   ┌──────────────┐                                                 │  │
│   │   │   Premiums   │                                                 │  │
│   │   │   Collected  │                                                 │  │
│   │   └──────┬───────┘                                                 │  │
│   │          │                                                          │  │
│   │          ▼                                                          │  │
│   │   ┌──────────────┐                                                 │  │
│   │   │     VNET     │  ◀── Protocol treasury                         │  │
│   │   │   (Valis     │                                                 │  │
│   │   │   Network)   │                                                 │  │
│   │   └──────────────┘                                                 │  │
│   │                                                                     │  │
│   │   NOT to arbitrageurs (unlike traditional AMMs)                    │  │
│   │   This is how UFC eliminates MEV extraction                        │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Comparison: UFC vs Traditional AMM

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      UFC vs TRADITIONAL AMM                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Feature              │  Traditional AMM      │  UFC                       │
│   ─────────────────────┼───────────────────────┼──────────────────────────  │
│   Price Discovery      │  Arbitrage (x*y=k)    │  Oracle + Orderbook        │
│   Impermanent Loss     │  YES (significant)    │  NO                        │
│   MEV Extraction       │  YES (sandwich, etc)  │  NO (premiums to VNET)     │
│   Manipulation         │  Profitable           │  Unprofitable (premiums)   │
│   Execution            │  Immediate            │  Deferred (end of tock)    │
│   Capacity Limits      │  None                 │  OOB cap per tock          │
│   Gas Fees             │  Per-swap             │  Zero (in-band economics)  │
│   LP Returns           │  Trading fees - IL    │  Premiums (no IL)          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Key Files

| File | Purpose |
|------|---------|
| `UFC/ufc.h` | Core UFC structures and constants |
| `UFC/ufc.c` | Main UFC engine |
| `UFC/ufc_orderbook.c` | Time-of-book orderbook |
| `UFC/ufc_swap.c` | Swap execution logic |
| `UFC/ufc_pool.c` | Pool operations (deposit/withdraw) |
| `UFC/ufc_planner.c` | Route optimization |
| `UFC/ufc_oob.c` | Out-of-balance handling |
| `UFC/ufc_scan.c` | Pool scanning |
| `UFC/ufc_utils.c` | Utility functions |

---

*For detailed code documentation, see the DOC_ufc_*.md files.*
