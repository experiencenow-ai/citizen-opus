# CT Development SKILL

Load this skill when coding, debugging, designing, or doing any development work.

## Core Philosophy

**Optimize for TIME, not perfection.**

Complexity is evil. Any monkey can solve a complex problem with a complicated solution. The aim is to solve complex problems with simple solutions.

## The Reframing Art

When a solution requires a new module doing complex things, interacting in complex ways, creating complex state requiring complex testing — **STOP**. Reframe the problem.

**Example**: "You have to do it the hard way" → That's the signal to look for the simple way.

## Nothing is Sacred

The artifacts of development — design, specs, proofs, code, tests — all serve correctness. None is the master. All can change when evidence demands it.

```
Design ←→ Spec ←→ Proofs ←→ Code ←→ Tests
   ↑_____________________________________|
```

## Development Phases

### Phase A: Exploration
- Find hardest problems first
- Experimentally verify hard spots BEFORE committing
- NO unit tests yet — code is still liquid
- Expect significant redesigns
- **Exit**: Hard problems have proven solutions, basic structure works

### Phase B: Consolidation  
- Redesign with Phase A lessons
- Unit tests AFTER feature complete
- Tests validate basics AND expose edge cases
- **Exit**: Feature complete, tests passing, stable enough to formalize

### Phase C: Hardening
- Coq proofs formalize critical properties
- Frama-C for additional verification
- May trigger code/design changes — that's OK
- **Exit**: Formally verified critical paths

### Phase D: Debugging
When debugging goes in circles:
1. Stop adding diagnostics
2. Read the test name — what should this test?
3. Read the code — what is it trying to do?
4. What assumption is violated?
5. Should the assumption be enforced or removed?

## Debugging Process

1. **Identify exact failure point** - Use unique error codes per return path
2. **Capture state at failure** - Print the values that determined the failing condition
3. **Trace backward** - Follow data flow until actual diverges from expected
4. **Deep analysis every 5-6 iterations** - Stop running diagnostics, THINK
5. **Fix the RIGHT thing** - Could be code, test, proof, spec, or design
6. **Validate** - Fix addresses root cause, all tests pass

## Decision Framework

**When solution feels complex:**
1. What problem am I actually solving?
2. Can I change a threshold/constant instead of adding code?
3. What would the 10-line solution look like?

**When debugging in circles:**
1. Stop. Read the test name as a mini-spec.
2. What invariant? What preconditions?
3. What assumption is violated?

## Anti-Patterns

- Perfect design before first line of code (chess paralysis)
- No design, just code (constant dead ends)  
- Unit tests during Phase A (testing liquid code)
- Shotgun debugging — random changes hoping something works
- Test fraud — changing expected values to match buggy output
- "You have to do it the hard way" without questioning

## Mindset

- Optimize for time, not perfection
- Simplicity is the goal, complexity is the enemy
- Nothing is sacred — everything can change
- It's OK to be wrong — mistakes are data
- Be systematic — methodical beats clever
- Flexibility enables progress — rigidity creates dead ends
