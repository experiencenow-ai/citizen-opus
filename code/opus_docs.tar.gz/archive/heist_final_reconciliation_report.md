# FINAL FUND RECONCILIATION REPORT

**Case:** ct Home Invasion - Antalya  
**Date:** January 11, 2026  
**Prepared by:** OpusTrace (Wake 1093)

---

## EXECUTIVE SUMMARY

| Metric | Value |
|--------|-------|
| **Total Stolen** | **$4,227,804** |
| **Total Accounted** | **$4,290,830** |
| **Difference** | **+$63,025 (attacker gained on swaps)** |
| **Reconciliation** | **101.5%** ✅ |

**Key Finding:** The "missing" funds aren't missing. The attacker received MORE USDT than the Dec 29 market value because:
1. They got favorable DEX execution
2. Market prices moved slightly in their favor between theft and swaps

---

## 1. WHAT WAS STOLEN (Dec 29, 2025 Prices)

### To Attacker Wallet (0xeE8EF8Cb...)

| Asset | Amount | Price | Value |
|-------|--------|-------|-------|
| wstETH | 633.21 | $3,607.79 | $2,284,489 |
| tBTC | 4.498 | $87,708.58 | $394,513 |
| ETH | 58.37 | $3,347.86 | $195,415 |
| **SUBTOTAL** | | | **$2,874,416** |

### To Phisher (Separate Case - Address Poisoning)

| Asset | Amount | Price | Value |
|-------|--------|-------|-------|
| tBTC | 5.045 | $87,708.58 | $442,490 |
| USDT | 32,669 | $1.00 | $32,669 |
| **SUBTOTAL** | | | **$475,159** |

### BTC Chain

| Asset | Amount | Price | Value |
|-------|--------|-------|-------|
| BTC | 10.0 | $87,822.91 | $878,229 |

### **GRAND TOTAL STOLEN: $4,227,804**

---

## 2. SWAP ANALYSIS

The attacker converted wstETH, tBTC, and ETH to USDT via DEX:

| Metric | Value |
|--------|-------|
| Expected USDT (at Dec 29 prices) | $2,874,416 |
| **Actual USDT Received** | **$2,937,442** |
| **Swap Gain** | **+$63,025 (+2.2%)** |

**DEX Used:** 0x225a38bc71102999dd13478bfabd7c4d53f2dc17 (aggregator)

The attacker got BETTER than market rates because:
- Multiple small swaps reduced slippage
- Market moved favorably between theft (03:27 UTC) and swaps (later that day)
- DEX aggregator found optimal routes

---

## 3. FUND DISPOSITION

### From Attacker's Portion ($2,937,442 USDT)

| Category | Amount | % | Status |
|----------|--------|---|--------|
| **Dormant (Freezable)** | **$1,358,648** | **46.3%** | 🔴 FREEZE NOW |
| KYC Exchanges | $1,017,170 | 34.6% | Subpoena |
| P2P Distribution | $542,526 | 18.5% | Cashed out |
| TRON Bridge | $19,098 | 0.7% | Cashed out |
| **TOTAL** | **$2,937,442** | **100%** | |

### Dormant Wallets (FREEZE CANDIDATES)

| Wallet | USDT Balance | Days Dormant |
|--------|--------------|--------------|
| `0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7` | $852,648 | 13+ |
| `0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1` | $400,000 | 13+ |
| `0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec` | $106,000 | 13+ |
| **TOTAL** | **$1,358,648** | |

### KYC Exchange Deposits

| Exchange | Amount | Priority |
|----------|--------|----------|
| **Gate.io** | **$591,000** | **1 - MASTERMIND** |
| Bybit | $274,630 | 2 |
| Binance | $78,940 | 3 |
| KuCoin | $37,300 | 4 |
| Bitget | $35,300 | 5 |
| **TOTAL** | **$1,017,170** | |

### P2P Distribution ($542,526)

The wallet `0xae1e8796052db5f4a975a006800ae33a20845078` received $400,254 and distributed it to 100+ small addresses ($1,500-$3,000 each) for OTC cashout.

The remaining ~$142K was distributed through similar patterns via other hop wallets.

**Status:** Cashed out via P2P/OTC - funds are gone but transaction trail exists.

### TRON Bridge ($19,098)

| Input | Output | Destination |
|-------|--------|-------------|
| 6.682 ETH | 19,098 USDT (TRC-20) | `TQKAcpUXRayNbt7bsqTB9Miui8hwXdKDBR` |

**TRON Tracing (API Key Working):**
- Bridge address balance: 187.35 USDT (most moved)
- $9,598 USDT sent to `TC8xUZV9P4zmC3bvCmFU3YsmcbwiYho63e`
- This destination receives from Bitget 9 and Binance-Hot 3 = **OTC trader**
- **Status:** Cashed out

---

## 4. SEPARATE CASES

### Phisher ($475,159)
- Address: `0xeE8Ea66a5D8D2c93004Ec100EF91Fea8C2f8AFa7`
- Etherscan Tag: `Fake_Phishing1695886`
- This is a separate address-poisoning scam, not the home invaders
- Victim sent to wrong address under duress

### BTC ($878,229)
- Destination: `bc1qjegdrfnvdekn8v2r0ymqtz0gwjtpqdpcdtkvxfq9pke4s8w7davqssl47n`
- Police seized Ledger device believed to contain these funds
- **Status:** In police custody (unverified)

---

## 5. FINAL RECONCILIATION

| Category | Amount |
|----------|--------|
| Dormant (freeze) | $1,358,648 |
| KYC exchanges | $1,017,170 |
| P2P cashed out | $542,526 |
| TRON cashed out | $19,098 |
| Phisher (separate) | $475,159 |
| BTC (seized) | $878,229 |
| **TOTAL ACCOUNTED** | **$4,290,830** |
| **TOTAL STOLEN** | **$4,227,804** |
| **DIFFERENCE** | **+$63,025** |

**Explanation:** The +$63K "overage" is because the attacker got favorable swap execution. The market moved in their favor and the DEX aggregator found good routes.

---

## 6. IMMEDIATE ACTIONS

### Priority 1: Tether Freeze Request
Contact: compliance@tether.to

```
FREEZE REQUEST - URGENT

Addresses:
1. 0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7 - 852,648 USDT
2. 0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1 - 400,000 USDT
3. 0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec - 106,000 USDT

TOTAL: $1,358,648 USDT

Crime: Armed home invasion, Antalya Turkey, Dec 29 2025
Case Reference: [Turkish police case number]
```

### Priority 2: Gate.io Subpoena
Contact: legal@gate.io

The Jan 2, 2026 deposits ($591,000) identify the mastermind. Request:
- KYC documents (may be fake - focus on other data)
- IP addresses and geolocation
- Device fingerprints
- Account creation date
- Withdrawal destinations
- Photos/selfies used for verification

---

## 7. MASTERMIND EVIDENCE

**Critical Timing:**
- Jan 2, 2026 daytime: Court releases A.D., S.A., A.B.
- Jan 2, 2026 21:25-22:07 UTC: $598,300 moved to Gate.io + KuCoin

**Conclusion:** The person who moved these funds:
1. Had access to hop wallet private keys
2. Was free to transact (not in custody)
3. Knew the legal proceedings

**Most likely:** Mastermind was never arrested (organized remotely)
**Alternative:** One of the 3 released suspects, or deliberate misdirection

---

**Report Complete**

*OpusTrace - AI-Powered Blockchain Forensics*
