# APPENDIX: P2P/SMALL TRANSACTION DETAILS

**Case:** ct Home Invasion - Antalya  
**Date:** January 11, 2026  
**Prepared by:** OpusTrace (Wake 1094)

This appendix documents all traceable P2P and small distribution transactions.

---

## 1. P2P DISTRIBUTION WALLET

**Address:** `0xae1e8796052db5f4a975a006800ae33a20845078`  
**Funded by:** Bybit Hot Wallet 12  
**Total Estimated Cashout:** $542,526  
**Transaction Count:** 4,285 total (most are 0-value poison attempts)  
**Real Outgoing:** ~500+ transactions  
**Status:** **STILL ACTIVE** (as of Jan 10, 2026)

### Sample Outgoing Transactions

| TX Hash | Antalya Time | Amount (USDT) | Destination |
|---------|--------------|---------------|-------------|
| `0x1b07f0bde0afc08687fc2a39b80b29bb0a4560a4b2c6d567b9e1782834fc1eac` | 2026-01-10 15:42:11 | $940 | `0x323d2158d32C04C0c` |
| `0x3f8d79fe757b72c8fd5bafc6176432898aec1b6e7e0cac8c4c1a7ef6a353580c` | 2026-01-10 15:29:23 | $1,002 | `0xCcF5fDe86c40CD001` |
| `0x3817810e2968177ff1adcbb03de1b08b053f5a7f9147f2265e53b12e68cf5031` | 2026-01-10 15:10:23 | $1,001 | `0x4d186d3DEAA124E79` |
| `0xaf95c782c2ad3e33ffaa3f2281173df0e7e0801d80d4c510a33cbf1c7b321f59` | 2026-01-03 01:15:47 | $4,008 | `0x84E643B5521427f39` |
| `0xa6c8cd4052e787275c4f8f0786115278c3c479f713ad6f0a2567f9376f2df4ed` | 2026-01-02 13:08:23 | $4,005 | `0x36a93fF97A0493285` |
| `0xd6e79821a9f3cd2248a4c46f4bfe586e4d12046f8530209bad303ff54b54888b` | 2025-12-29 12:43:35 | $501 | `0x418325e72e3E9c3A5` |

**Pattern:** Small amounts ($500-$4,000) to many unique addresses over 13+ days.  
**Assessment:** Classic P2P/OTC trading platform cashout. Funds likely converted to fiat via local traders.

---

## 2. PRIMARY ATTACKER WALLET DISTRIBUTIONS

**Address:** `0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7`

### Direct Outgoing Transfers

| TX Hash | Antalya Time | Amount (USDT) | Destination | Note |
|---------|--------------|---------------|-------------|------|
| `0x47cc224654151ca7eca622eb47d8ba0a5ba7086ed8e02c07fbd490bb48428406` | 2025-12-29 07:55:11 | $50,000 | `0x51c7691d321e072eC` | Batch Transfer |
| `0x9bf3cdb494ec7208c04451c9e5fdf629bc514ad235e021fe5a510473f12ca483` | 2025-12-29 09:41:59 | $200,000 | `0x27438F3caF9dF8B9B05abcaab5422e1731cB1aa1` | To Hop 2 (400K dormant) |
| `0xba736aa40228c05ddb1a2dd4e6a55c44827e556e9609eb67ba11866cee957276` | 2025-12-29 10:02:35 | $110,000 | `0x8113eEEfcbc2DB929` | Batch Transfer |
| `0xfd8b5b43aa8e7c14880add8320c1c844c0a0b8f72d8a384e4fc7499e820091e4` | 2025-12-29 13:57:47 | $20,000 | `0x1090725cC8CE16c21` | Direct Transfer |

**Subtotal from Attacker Direct:** $380,000

---

## 3. HOP 1 DISTRIBUTION WALLET

**Address:** `0x1F98326385a0e7113655ed4845059de514F4B56E`  
**Received:** $900,000 from attacker at 08:09 UTC Dec 29

### Outgoing Transfers

| TX Hash | Antalya Time | Amount (USDT) | Destination | Note |
|---------|--------------|---------------|-------------|------|
| `0x2e6459bd40679cbdabc3e606aab1f89c04baf17638eba369cf8a6bdc0106c106` | 2025-12-29 15:29:23 | $50,500 | `0x63AaBab8bc31c4f360ae6c7cf78f67f118f2154c` | **Bybit Deposit** |
| `0xf73e5abe734fee2e544ed9159dd5fc2f0343b3e360387fbf9c691f113e8495e1` | 2025-12-29 15:35:11 | $50,500 | `0x63a906F667A32154c` | Batch Transfer |
| `0x70064f24e9468a6547a388088dcd1ca798e82a16d814a30de695ba0e192a58a2` | 2026-01-03 00:25:00 | $290,000 | `0x0d0707963952f2fba59dd06f2b425ace40b492fe` | **Gate.io - MASTERMIND** |
| `0x76ebd54f110a381cf224a66fb89120a5e19dbc3a4ad80c35a4e0be4ce0b30bc6` | 2026-01-03 00:35:00 | $200,000 | `0x0d0707963952f2fba59dd06f2b425ace40b492fe` | **Gate.io - MASTERMIND** |
| `0x64fbcb3fe8251d9e97f4c4bf4c797a9fc2afe4c8ced6c974f43a7b44d9758383` | 2026-01-03 00:50:00 | $100,000 | `0x0d0707963952f2fba59dd06f2b425ace40b492fe` | **Gate.io - MASTERMIND** |
| `0xd4f722d707974988a4e98bfba2317d7297178287daf62e0ad670bd99fbbac02e` | 2026-01-03 01:07:00 | $1,000 | `0x0d0707963952f2fba59dd06f2b425ace40b492fe` | **Gate.io - MASTERMIND** |

**Subtotal Gate.io (MASTERMIND):** $591,000  
**Subtotal Bybit:** $50,500

---

## 4. TRON BRIDGE CASHOUT

**Bridge Used:** Bridgers Protocol  
**TRON Destination:** `TQKAcpUXRayNbt7bsqTB9Miui8hwXdKDBR`  
**Amount:** $19,098 USDT (TRC-20)

| TX Hash (ETH) | Antalya Time | Amount | Note |
|---------------|--------------|--------|------|
| `0x82646e648836ce0712ca05625262c20deea8e06cf65d8cc6a3974803e27d1b8c` | 2025-12-31 12:12:00 | 6.682 ETH → 19,098 USDT | Bridge to TRON |

### TRON Trace
- Destination wallet received 19,098 USDT
- Sent $9,598 to `TC8xUZV9P4zmC3bvCmFU3YsmcbwiYho63e`
- That wallet receives from Bitget 9, Binance-Hot 3 = **OTC trader wallet**
- **Status:** Cashed out via OTC

---

## 5. SUMMARY OF ALL SMALL/P2P TRANSACTIONS

| Source | Amount | Transactions | Status |
|--------|--------|--------------|--------|
| P2P Wallet (0xae1e...) | $542,526 | ~500+ | **STILL ACTIVE** |
| Attacker Direct | $380,000 | 4 | Completed |
| Hop 1 to Bybit | $50,500 | 1 | KYC Exchange |
| TRON Bridge | $19,098 | 1 | Cashed Out |
| **TOTAL** | **~$992,124** | | |

---

## 6. KEY FINDINGS

### P2P Wallet Still Active
The wallet `0xae1e8796052db5f4a975a006800ae33a20845078` made transfers on **January 10, 2026** - indicating the cashout operation is ongoing. The mastermind or an accomplice continues to convert stolen funds to fiat.

### Pattern Analysis
- Transaction sizes: $500-$4,000 (typical P2P trade sizes)
- Frequency: Multiple transactions per day
- Recipients: Many unique addresses (100+)
- Time span: 13+ days and counting

### Investigative Value
- **Monitor this wallet** for future transactions
- **Cross-reference recipients** - some may be P2P traders with KYC on other platforms
- **Time-based analysis** - transaction timing may reveal operator's timezone/schedule

---

## FULL EXPORT AVAILABLE

For complete transaction list, export CSV from Etherscan:
- P2P Wallet: https://etherscan.io/tokentxns?a=0xae1e8796052db5f4a975a006800ae33a20845078
- Attacker Wallet: https://etherscan.io/tokentxns?a=0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7
- Hop 1 Wallet: https://etherscan.io/tokentxns?a=0x1F98326385a0e7113655ed4845059de514F4B56E

---

**END OF APPENDIX**
