# Exchange Cashout Summary - ct Home Invasion Case
## Report Date: 2026-01-11

## CONFIRMED EXCHANGE DEPOSITS

### 1. GATE.IO - $691,000 USDT (LARGEST)
**Status: CONFIRMED - Etherscan labeled "Gate Deposit"**

**Flow:**
```
ATTACKER MAIN → HOP 1 → HOP 2 → GATE.IO
0xeE8EF8Cb...  → 0x1f9832... → 0x7237b8... → 0x0d0707...
   900K USDT      (4 days)      691K USDT      DEPOSITED
```

**Timeline:**
- Dec 29, 08:09 UTC: 900K USDT from attacker main to 0x1f98...
- Jan 2, 21:25-22:07 UTC: 691K moved from 0x1f98 to 0x7237b8
- Jan 2, 22:00-22:20 UTC: 691K deposited to Gate.io (0x0d0707...)

**Key Transactions:**
| Amount | TX Hash | Time (UTC) |
|--------|---------|------------|
| 201,000 USDT | `0x644e2ec5d981a0b4109f5378e2747d05918818a53e9de6ac7793a95f93c7afb3` | Jan 2 22:00:47 |
| 490,000 USDT | `0x9efdf6f151df310641fb28cb6a6d507fd6a2d7d7a033fd5e7e8c66654248eef7` | Jan 2 22:20:47 |

**Legal Action:** Subpoena Gate.io for KYC on deposit address `0x7237b8a4b2dd97dcddb758feac0e8d925016694c`

---

### 2. BYBIT - $138,280 USDT
**Status: CONFIRMED - Etherscan labeled "ByBit Deposit"**

**Deposit Address:** `0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e`

**PRE-ATTACK DEPOSITS (proves premeditation):**
| Date | Amount | TX Hash |
|------|--------|---------|
| Dec 16 17:10 | 300 USDT | `0xf47b3ff3975ca52a00eea912668180db2babb0163e39f7edd6980d0cc0c415b9` |
| Dec 17 16:59 | 300 USDT | `0x9ccc109d4655e94919610c2071f8e5c867bed819a5dce46f9462b898979767f8` |
| Dec 20 15:38 | 680 USDT | `0xe6349ec9e0ecc55c356fdeddeeff284d98d05d0a5784647c556db5fb6396b2b1` |

**POST-ATTACK DEPOSITS:**
| Date | Amount | Source | TX Hash |
|------|--------|--------|---------|
| Dec 29 06:27 | 27,000 USDT | Direct from main | `0x8af8841c81e1bf7bfd64fc20a7427500d1814ebe475fcaecd06f236f598f70e3` |
| Dec 29 09:39 | 50,000 USDT | Via 0xa2d5d8... | `0x...` |
| Dec 29 10:33 | 60,000 USDT | Via 0xa2d5d8... | `0x...` |

**Legal Action:** Subpoena Bybit for KYC - PRE-ATTACK deposits prove this was the attacker's existing account

---

### 3. BINANCE - $15,000 USDT
**Status: CONFIRMED - Etherscan labeled "Binance 14"**

**Deposit Address:** `0x28c6c06298d514db089934071355e5743bf21d60`

**Flow:**
- From: `0xc889740f66d7a2ea538cd44eb5456f490c75d0b3`
- Date: Dec 29 10:22:59 UTC
- Note: This wallet has extensive pre-attack Binance deposit history

---

## DORMANT FUNDS (Still Recoverable)

| Wallet | Balance | Status |
|--------|---------|--------|
| Attacker Main `0xeE8EF8...` | 852,648 USDT + 3.23 ETH | Dormant 13 days |
| Intermediary `0x27438F...` | 400,000 USDT | Dormant |
| Phishing Trap `0xeE8Ea6...` | 32,669 USDT + 5.045 tBTC | Trapped in phishing wallet |
| Hop Wallet `0x51c3cf...` | 106,000 USDT | Dormant |

**Total Dormant: ~$1.9M**

---

## CROSS-CHAIN (TRON)

**Via Bridgers Protocol:** ~$20K USDT
- Destination: TRON address `TQKAcpUXRayNbt7bsqTB9Miui8hwXdKDBR`
- Subsequently cashed out via P2P/OTC

---

## FUND ACCOUNTING

| Category | Amount | Notes |
|----------|--------|-------|
| Gate.io Deposit | $691,000 | KYC required - subpoena target |
| Bybit Deposit | $138,280 | Pre-attack deposits prove identity |
| Binance Deposit | $15,000 | KYC required |
| TRON Bridge | $20,000 | P2P cashout |
| Dormant on ETH | $1,900,000 | Recoverable if frozen |
| BTC Ledger (Seized) | $983,000 | In Turkish police custody |
| P2P/OTC dispersal | ~$400,000 | From 0xae1e... (small payments) |
| **TOTAL ACCOUNTED** | **~$4.15M** | |
| Reported Stolen | $4.2M | |

---

## PRIORITY LEGAL ACTIONS

1. **Gate.io Subpoena** - $691K is the largest single cashout, deposited Jan 2-3
2. **Bybit Subpoena** - Pre-attack deposits prove premeditation
3. **Binance Subpoena** - Additional evidence
4. **Freeze Requests** - For dormant wallets holding $1.9M

---

## KEY EVIDENCE FILES
- `gate_io_evidence.json` - Complete Gate.io trace with all tx hashes
- `complete_fund_flow.json` - Full fund flow report
- `ct_case_wallets.json` - All wallet addresses and labels
