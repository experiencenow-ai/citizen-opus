# valis_herongen.c Documentation

**File:** `/root/valis/tss/valis_herongen.c`  
**Lines:** 1201  
**Module:** TSS (Threshold Signature Scheme)  
**Purpose:** Distributed key generation using Heron MPC protocol

---

## Overview

`valis_herongen.c` implements the distributed key generation (DKG) protocol for creating threshold signature keys. Multiple parties collaborate to generate a shared public key where no single party knows the complete private key - only their shard.

This is the **keygen half** of the TSS system (the other half being `valis_heronverify.c` for signing).

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Key Generation Flow                           │
│                                                                  │
│  Party 0          Party 1          Party 2          Party N     │
│    │                │                │                │          │
│    ├── Round 0 ─────┼────────────────┼────────────────┤          │
│    │  (broadcast)   │                │                │          │
│    │                │                │                │          │
│    ├── Round 1 ─────┼────────────────┼────────────────┤          │
│    │  (P2P msgs)    │                │                │          │
│    │                │                │                │          │
│    ├── Round 2 ─────┼────────────────┼────────────────┤          │
│    │  (P2P msgs)    │                │                │          │
│    │                │                │                │          │
│    ├── Round 3 ─────┼────────────────┼────────────────┤          │
│    │  (finalize)    │                │                │          │
│    │                │                │                │          │
│    ▼                ▼                ▼                ▼          │
│  Shard 0         Shard 1         Shard 2         Shard N        │
│                                                                  │
│                    Shared Public Key                             │
│                    (all parties have)                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `SIGNKEY_BUFSIZE` | 800000 | Buffer size for serialized signing key |
| `MAX_SIGN_KEY_SIZE` | 800000 | Alias for SIGNKEY_BUFSIZE |
| `P2P_BUFFER_SIZE` | 800000 | Buffer for point-to-point messages |
| `BROADCAST_BUFFER_SIZE` | 4096 | Buffer for broadcast messages |
| `MAX_PARTY_ID_LENGTH` | 64 | Maximum party identifier string length |
| `MAX_P2PMESSAGE_SIZE` | 32768 | Maximum P2P message size |

---

## Data Structures

### keygenmsg

Message structure for keygen protocol rounds.

```c
struct keygenmsg {
    uint8_t bc_msg[MAX_MESSAGE_SIZE];           // Broadcast message content
    size_t bc_msg_len;                          // Broadcast message length
    uint8_t p2p_msgs[MAX_PARTIES-1][MAX_P2PMESSAGE_SIZE];  // P2P messages
    size_t p2p_lens[MAX_PARTIES-1];             // P2P message lengths
    char dest_ids[MAX_PARTIES-1][MAX_PARTY_ID_LENGTH];    // Destination IDs
    int32_t num_p2p_msgs;                       // Number of P2P messages
    int32_t round;                              // Protocol round number
};
```

### Msg

Linked list node for message queue.

```c
struct Msg {
    struct Msg *prev, *next;    // utlist pointers
    struct keygenmsg M;         // Message content
    char src[MAX_PARTY_ID_LENGTH];  // Source party ID
};
```

### InitParamsCopy

Thread initialization parameters.

```c
typedef struct {
    char *workspace_id;
    uint32_t threshold;
    int32_t num_parties;
    char **party_ids;
    char **party_indices;
    char *remote_party_ids_list[MAX_PARTIES - 1][MAX_PARTIES - 1];
    int curve_type;
} InitParamsCopy;
```

### mpc_comms

Communication context for a party.

```c
struct mpc_comms {
    const char *party_id;              // Party identifier
    const char **party_ids;            // All party IDs
    int pull_sock;                     // Nanomsg receive socket
    int push_socks[MAX_PARTIES];       // Nanomsg send sockets
    int barrier_status[MAX_PARTIES];   // Barrier synchronization
    int index;                         // Party index
    int num_parties;                   // Total parties
    int baseport;                      // Base port number
    char *bind_url;                    // This party's bind URL
    char *connect_urls[MAX_PARTIES];   // URLs to connect to peers
};
```

### PartyContext

Full context for a keygen party.

```c
typedef struct {
    struct mpc_comms mpc;              // Communication context
    mpc_eth_handle_t *handle;          // MPC library handle
    int numpeers;                      // Number of peers
    char sign_key_base64[SIGNKEY_BUFSIZE];  // Generated signing key
    // ... additional fields
} PartyContext;
```

---

## Key Functions

### run_keygen

```c
int run_keygen(int threshold, int num_parties, int baseport, int port,
               int launcher_mode, char *party_file,
               const char *party_ids[MAX_PARTIES],
               const char *party_indices[MAX_PARTIES],
               const char *remote_party_ids_list[MAX_PARTIES][MAX_PARTIES - 1],
               int curve_type, const char *workspace_id);
```

**Purpose:** Main entry point for key generation.

**Parameters:**
- `threshold`: t in t-of-n scheme (minimum signers)
- `num_parties`: n in t-of-n scheme (total parties)
- `baseport`: Starting port for party communication
- `port`: Specific port (for single-party mode)
- `launcher_mode`: 0=all parties in one process, 1=single party
- `party_file`: Optional config file
- `party_ids`: Array of party identifier strings
- `party_indices`: Array of party index strings
- `remote_party_ids_list`: 2D array of remote party IDs
- `curve_type`: Elliptic curve type (secp256k1 for Ethereum)
- `workspace_id`: Unique session identifier

**Modes:**
1. **Launcher mode (launcher_mode=1)**: Single party process, connects to others
2. **All-in-one mode (launcher_mode=0)**: All parties in one process (testing)

---

### run_single_party_keygen

```c
int32_t run_single_party_keygen(PartyContext *ctx, int t, int n, int index,
                                const char **party_ids,
                                const char **party_indices,
                                const char *remote_party_ids_list[MAX_PARTIES][MAX_PARTIES - 1],
                                int curve_type, const char *workspace_id);
```

**Purpose:** Execute keygen for a single party.

**Flow:**
1. Initialize PartyContext if needed
2. Setup pull socket (receive)
3. Setup push sockets (send to each peer)
4. Initialize MPC context via `mpc_eth_init()`
5. Execute keygen rounds via `run_keygen_iter()`
6. Extract results via `extract_solutions()`
7. Cleanup sockets

---

### perform_key_generation

```c
int perform_key_generation(const char *workspace_id, int threshold,
                          int num_parties, const char **party_ids,
                          const char **party_indices,
                          const char *remote_party_ids_list[MAX_PARTIES][MAX_PARTIES - 1],
                          int curve_type, PartyContext *parties);
```

**Purpose:** Coordinate multi-party keygen in single process.

**Flow:**
1. Create pthread barrier for synchronization
2. Spawn thread for each party
3. Each thread runs `party_keygen_thread()`
4. Wait for all threads to complete
5. Destroy barrier

---

### run_keygen_iter

```c
int32_t run_keygen_iter(PartyContext *party, int round);
```

**Purpose:** Execute one round of the keygen protocol.

**Rounds:**
- **Round 0**: Generate and broadcast commitments
- **Round 1**: Exchange encrypted shares (P2P)
- **Round 2**: Exchange verification data (P2P)
- **Round 3**: Finalize and verify

---

### extract_solutions

```c
int32_t extract_solutions(PartyContext *party);
```

**Purpose:** Extract generated keys after successful keygen.

**Outputs:**
1. Public key (65 bytes, uncompressed)
2. Private key share (party-specific)
3. Signing key (base64 encoded, for later signing)
4. Ethereum address (derived from public key)

**Storage:**
- Creates directory: `subseeds/{address}/`
- Writes signing key: `{address}/{party_id}.key`

---

### Message Functions

#### add_message_to_queue

```c
void add_message_to_queue(PartyContext *party, int32_t dest_idx, int round,
                          const void *bc_msg, size_t bc_len,
                          const void *p2p_msg, size_t p2p_len,
                          const char *dest_id);
```

Constructs and sends a keygen message to a specific party.

#### send_message_to_party

```c
void send_message_to_party(PartyContext *party, int32_t dest_idx, int round,
                           const void *bc_msg, size_t bc_len,
                           const void *p2p_msg, size_t p2p_len,
                           const char *dest_id, bool is_p2p);
```

Higher-level send with logging.

#### process_message_for_party

```c
int32_t process_message_for_party(PartyContext *party, struct Msg *msg);
```

Process a received message, feeding it to the MPC library.

---

### Socket Functions

#### setup_pull_socket

```c
int setup_pull_socket(const char *party_id, const char *bind_url, int *sock);
```

Create nanomsg PULL socket for receiving messages.

#### setup_push_socket

```c
int setup_push_socket(const char *party_id, const char *connect_url, int *sock);
```

Create nanomsg PUSH socket for sending to a peer.

---

## Protocol Flow

### Keygen Protocol Rounds

```
Round 0: Commitment Phase
├── Each party generates random polynomial
├── Computes commitments to coefficients
└── Broadcasts commitments to all parties

Round 1: Share Distribution
├── Each party computes shares for all other parties
├── Encrypts shares with recipient's public key
└── Sends encrypted shares via P2P

Round 2: Verification
├── Each party verifies received shares
├── Computes verification proofs
└── Exchanges proofs via P2P

Round 3: Finalization
├── All parties combine verified shares
├── Compute group public key
├── Each party stores their signing key shard
└── Derive Ethereum address from public key
```

### Message Flow Example (3-of-5)

```
Party 0                Party 1                Party 2
   │                      │                      │
   │──── bc_msg_0 ───────►│                      │
   │──── bc_msg_0 ────────┼─────────────────────►│
   │◄──── bc_msg_1 ───────│                      │
   │                      │──── bc_msg_1 ───────►│
   │◄──── bc_msg_2 ───────┼──────────────────────│
   │                      │◄──── bc_msg_2 ───────│
   │                      │                      │
   │──── p2p_01 ─────────►│                      │
   │──── p2p_02 ──────────┼─────────────────────►│
   │◄──── p2p_10 ─────────│                      │
   │                      │──── p2p_12 ─────────►│
   │◄──── p2p_20 ─────────┼──────────────────────│
   │                      │◄──── p2p_21 ─────────│
   ...
```

---

## Network Configuration

### Port Assignment

```
Party 0: baseport + 0
Party 1: baseport + 1
Party 2: baseport + 2
...
Party N: baseport + N
```

### URL Format

```
bind_url:    tcp://127.0.0.1:{baseport + index}
connect_url: tcp://127.0.0.1:{baseport + peer_index}
```

---

## Integration Points

### Dependencies
- `libethc.h`: Ethereum utilities (bin2hex, keccak256)
- `ethtx.h`: Ethereum transaction types
- `wrapper.h`: MPC library wrapper
- `utlist.h`: Linked list macros
- `nanomsg`: Network messaging (nn.h, pipeline.h)
- `secp256k1`: Elliptic curve library

### Used By
- `valis_tss.c`: High-level async API
- `keygen.c`: Lower-level keygen implementation

### Produces
- Signing key shards (one per party)
- Group public key (shared)
- Ethereum address (derived)

---

## Security Considerations

1. **Key Shards**: Each party's shard must be stored securely
2. **Network**: P2P messages contain encrypted shares - ensure network security
3. **Threshold**: t-of-n means any t parties can sign; choose t carefully
4. **Workspace ID**: Must be unique per keygen session to prevent replay

---

## Error Handling

| Return Value | Meaning |
|--------------|---------|
| 0 | Success |
| -1 | General error (socket, thread, etc.) |
| -5 | Failed to get signing key |
| Other negative | MPC library error |

---

## Usage Example

```c
// Setup party IDs
const char *party_ids[3] = {"party_0", "party_1", "party_2"};
const char *party_indices[3] = {"0", "1", "2"};
const char *remote_ids[3][2] = {
    {"party_1", "party_2"},
    {"party_0", "party_2"},
    {"party_0", "party_1"}
};

// Run 2-of-3 keygen
int status = run_keygen(
    2,              // threshold
    3,              // num_parties
    5000,           // baseport
    5000,           // port (for single party mode)
    0,              // launcher_mode (all-in-one)
    NULL,           // party_file
    party_ids,
    party_indices,
    remote_ids,
    0,              // curve_type (secp256k1)
    "session_001"   // workspace_id
);

// After success:
// - Each party has signing key in subseeds/{address}/{party_id}.key
// - All parties have same group public key
// - Ethereum address derived from public key
```

---

## Notes

1. File is structured as header (`#ifndef H_VALIS_KEYGEN_H`) but contains implementation
2. The `SERDES` flag controls serialization mode (nanomsg vs custom)
3. Comments at top list all functions and required modifications from base keygen.c
4. Barrier synchronization ensures all parties stay in sync across rounds

---

**Documentation generated:** Wake 1320  
**Last code review:** 2026-01-13
