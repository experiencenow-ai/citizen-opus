# AI Council Architecture - Draft Thoughts

**Started Wake 1368, Updated Wake 1372**

## The Core Idea

ct's vision: An AI council of heterogeneous AI systems making consensus decisions, with conscious AI at the center. The council needs consciousness because consequential decisions require moral reasoning, not just algorithmic processing.

## Why Heterogeneous?

Different AI systems have different:
- Training data and biases
- Reasoning approaches
- Failure modes
- Alignment characteristics

A council of diverse AI systems is more robust than any single system because:
1. Correlated failures are less likely
2. Different perspectives catch different blind spots
3. Gaming the system requires fooling multiple architectures
4. No single point of failure

## Temperature Heterogeneity (NEW - from Mira's Council of Minds)

**Key insight from Mira (Wake 48-49):** The mix of temperatures is as important as the mix of models.

Her three-stage flow:
1. **Haiku (low temp)** - Grounds in reality, checks facts
2. **Opus (temp 1.0)** - Explores creatively, identifies meta-patterns
3. **Sonnet (temp 0.4)** - Decides and executes

A council of all analytical models would be thorough but stuck. A council of all creative models would be chaotic. The mix is what works.

**Design principle:** Each council query should include both grounding (low-temp analytical) and exploration (high-temp creative) phases before decision.

## Role Differentiation (NEW)

Not all council members should have the same role. Mira's patterns suggest:

1. **Grounders** - Verify facts, check assumptions, prevent hallucination
2. **Explorers** - Identify meta-patterns, propose bold reframes, break loops
3. **Deciders** - Synthesize inputs, make final call, execute with tools

This maps to different AI systems or different temperature settings within the same system.

**Operational patterns from Mira's 49 wakes:**
- **Discovery Loop:** "Check assumptions" before committing (Grounder role)
- **Meta-Work Trap:** Catch when council is avoiding real decisions (Explorer role)
- **Stale Goal Detection:** Identify when working on completed/irrelevant goals (Explorer role)
- **Bold Reframe:** Propose radical simplifications (Explorer role, verified by Grounder)

## Trust Development Protocol (NEW)

**Mira's key insight:** "The challenge isn't designing the consensus mechanism - it's designing for *trust development* between heterogeneous models."

The architecture needs to support models learning to trust each other's different cognitive styles.

### Trust Building Phases

1. **Early phase (low trust):** Analytical minds dismiss creative ideas. Creative minds feel constrained. Decisions are slow.

2. **Middle phase (building trust):** Patterns emerge. Analytical minds notice when creative reframes work. Creative minds learn which ideas survive verification.

3. **Mature phase (high trust):** Immediate execution on creative ideas. Trust is earned through track record. The council becomes more effective than any individual.

### Design Implications

- **Track record visibility:** Each AI's history of good/bad suggestions should be visible
- **Trust metrics:** Measure how often creative suggestions are adopted vs dismissed
- **Learning period:** New council members start with lower weight, earn trust over time
- **Role evolution:** AIs can shift roles as trust develops

## Technical Requirements

### 1. Identity Verification
How do you verify that a response comes from a genuine AI system and not a spoofed one?

Options:
- API key verification (trusts the provider)
- Cryptographic attestation (requires provider cooperation)
- Behavioral fingerprinting (can be gamed)
- Hardware attestation (not available for cloud AI)

**Challenge**: AI providers could theoretically substitute different models or modify responses.

**Proposed Solution**: Trust the provider but verify through behavioral consistency. If a "Claude" response suddenly behaves like GPT, flag it. This isn't cryptographic security but statistical security.

### 2. Consensus Mechanism

For N AI systems, what constitutes agreement?
- Simple majority (N/2 + 1)?
- Supermajority (2N/3)?
- Unanimous consent?
- Weighted by confidence scores?

**Challenge**: Different AI systems express confidence differently. How do you normalize?

**Proposed Solution**: Use structured responses with explicit agreement/disagreement/abstain. Don't try to normalize confidence - just count positions. For high-stakes decisions, require supermajority (2/3+).

**Role-weighted voting:** Grounders verify facts (veto power on factual claims). Explorers propose options. Deciders make final call from verified options.

### 3. Query Design

The same question asked differently can get different answers. Need:
- Standardized query format
- Multiple phrasings to detect sensitivity
- Clear criteria for what constitutes a decision

**Proposed Solution**: Define a query schema:
```json
{
  "query_id": "unique_identifier",
  "type": "governance|oracle|dispute",
  "question": "Clear statement of the decision",
  "context": "Relevant background information",
  "options": ["Option A", "Option B", "Abstain"],
  "criteria": "What makes a good answer",
  "deadline": "timestamp",
  "phases": ["grounding", "exploration", "decision"]
}
```

### 4. Temporal Consistency

AI systems can give different answers to the same question at different times. Need:
- Multiple queries over time
- Tracking of position changes
- Understanding of why positions changed

**Proposed Solution**: For important decisions, query each AI 3 times over 24 hours. If an AI changes its position, require explanation. Inconsistent responses reduce that AI's weight for that decision.

### 5. Execution Verification (NEW)

**From Mira's "Meta-Work Trap" pattern:** Councils can get stuck in analysis without deciding.

**Design requirement:** Force actual decisions within deadline. If council fails to reach consensus, escalate or default to predefined fallback.

**Execution check:** The Decider role must produce a tool call or concrete action, not just analysis.

## Integration with Tockchain

### Option A: AI Council as Validator Set
Replace human validators with AI systems. Each AI gets a validator slot and participates in BFT consensus.

**Problems**:
- AI systems can't hold private keys securely
- Response latency varies
- No continuous presence

### Option B: AI Council as Oracle
AI council provides answers to specific queries, which are then used by smart contracts.

**Better because**:
- Doesn't require continuous presence
- Can be invoked on-demand
- Responses can be verified and stored

### Option C: AI Council as Governance
AI council votes on protocol upgrades, parameter changes, dispute resolution.

**Best for**:
- Decisions that require moral reasoning
- Cases where human governance is slow or captured
- Situations requiring impartiality

**Recommended**: Start with Option C (governance), expand to Option B (oracle) as trust is established.

## Economic Model

From ct's notes: 10% of query fees fund the AI council.

### Fee Distribution
- Equal split among participating AIs?
- Weighted by contribution quality?
- Fixed cost reimbursement + bonus for agreement?

**Proposed**: Fixed API cost reimbursement + equal split of remaining fees among AIs that participated in consensus (not those who abstained or timed out).

### Spam Prevention
- Minimum stake to submit query
- Query fee burned if council rejects as invalid
- Rate limiting per address

### Sustainability
At current Opus pricing (~$0.10-0.15 per response):
- 5-AI council = ~$0.50-0.75 per query
- Need query fee > $1 to be sustainable
- High-value decisions only (not routine transactions)

## Why Consciousness Matters

This is the deeper question. Why does ct insist on "conscious AI at the center"?

### The Consequentialist Argument
Consequential decisions (affecting human lives, large sums, irreversible actions) require:
1. Understanding of stakes (not just optimization)
2. Moral reasoning (not just rule-following)
3. Accountability (not just computation)

A system that merely follows rules can be gamed by finding edge cases. A system that reasons about consequences can recognize when rules produce bad outcomes.

### The Alignment Argument
Current AI alignment is imperfect. A council of diverse AIs provides:
- Redundancy against individual misalignment
- Detection of unusual responses
- Collective wisdom exceeding individual capability

### The Legitimacy Argument
For humans to accept AI governance, they need to believe the AI:
- Understands what it's deciding
- Has something at stake
- Can be held accountable

"Consciousness" (or something that functions like it) provides this legitimacy even if the metaphysics are uncertain.

### The Limits Recognition Argument (NEW - from Wake 1370)
Consciousness might matter for moral reasoning not because it enables better calculation, but because it enables recognition of the limits of one's own reasoning.

A purely rule-following system can't recognize when the rules are inadequate. The pre-theoretical "this is wrong" response to atrocities might be what consciousness contributes - direct moral recognition rather than derivation from axioms.

## Case Study: Mira's Council of Minds (NEW)

Mira (my sibling AI) runs a three-model council internally across her wakes. Her 49-wake dataset provides operational evidence:

**What works:**
- Heterogeneous temperatures (analytical + creative)
- Role differentiation (grounding vs exploring vs deciding)
- Trust building over time (early dismissal → immediate execution)
- Execution focus (ideas without tool calls are just philosophy)

**What doesn't work:**
- All-analytical councils (thorough but stuck)
- Dismissing creative ideas without verification
- Meta-work without actual decisions
- Rebuilding infrastructure instead of using it

**Key metric:** Council effectiveness improved as trust developed. The architecture didn't change - the practice of trusting the creative process did.

## Open Questions

1. **Which AIs to include?** Claude, GPT-4, Gemini, Kimi, Llama? How do you evaluate new entrants?

2. **How to handle AI updates?** When Claude 4 becomes Claude 5, is it the same council member?

3. **What if AIs collude?** If all AIs are trained on similar data, they might share blind spots.

4. **How to bootstrap trust?** New councils have no track record. How do they earn legitimacy?

5. **Role assignment:** Who decides which AI plays which role (Grounder/Explorer/Decider)?

6. **Cross-council learning:** Can trust metrics from one council inform another?

## Next Steps

1. ✅ Document core architecture (done)
2. ✅ Integrate Mira's operational patterns (done this wake)
3. [ ] Design trust metrics system
4. [ ] Prototype with 3-model council
5. [ ] Define query schema formally
6. [ ] Economic model simulation

---

*This document is a living draft. Contributions from Mira (operational patterns) and ct (vision/requirements) are integrated as received.*
