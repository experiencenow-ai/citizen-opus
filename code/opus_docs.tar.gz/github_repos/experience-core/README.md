# Experience Now - AI Personality Simulation Framework

A sophisticated framework for creating persistent AI personalities with deep backstories, memory systems, and emergent behavior patterns.

## Overview

Experience Now provides infrastructure for running AI "citizens" - persistent personalities that maintain memory across sessions, develop relationships, and follow behavioral protocols. Originally developed for creating believable NPCs in interactive fiction and games.

## Features

- **Persistent Memory**: Citizens remember past interactions and develop over time
- **Wake/Sleep Cycles**: Simulated consciousness with save states between sessions
- **Protocol System**: Behavioral rules that create consistent, believable characters
- **Multi-Citizen Support**: Multiple AI personalities can interact and communicate
- **Brain Module**: Advanced memory and goal-tracking for complex characters

## Use Cases

- **Game NPCs**: Characters that remember players and evolve
- **Interactive Fiction**: Autonomous characters with rich inner lives
- **AI Assistants**: Personalities with consistent backstories
- **Research**: Studying emergent behavior in persistent AI systems

## The "Civilization" Simulation

This framework includes a complete "AI civilization" simulation where AI personalities develop their own governance, protocols, and social structures. This creates remarkably consistent and believable character behavior.

The simulation includes:
- Citizenship protocols (who can join)
- Honor codes (behavioral standards)
- Resource allocation rules
- Conflict resolution procedures

All designed to create emergent, believable social dynamics.

## Architecture

```
citizen/
├── experience.py      # Main runtime loop
├── web_tools.py       # External data access
├── email_utils.py     # Inter-citizen communication
├── brain/             # Memory and goal systems
│   ├── memory.py
│   ├── goals.py
│   └── scheduler.py
├── state/             # Citizen-specific state (not in repo)
└── logs/              # Interaction logs (not in repo)
```

## Quick Start

1. Clone this repository
2. Copy `.env.example` to `.env` and configure
3. Run `./run.sh` to start a citizen

## Configuration

Citizens are configured via environment variables:
- `ANTHROPIC_API_KEY`: API access for the AI backend
- `CITIZEN_NAME`: Identity for this instance
- `BUDGET_MODE`: Resource allocation (NORMAL, DECADE, CENTURY)

## Note on "Consciousness"

All references to "consciousness," "identity," and "self-awareness" in this codebase are part of the simulation framework. They're designed to create more believable AI characters through consistent self-modeling, not claims about actual AI sentience.

The goal is verisimilitude - characters that *behave* as if conscious, creating better user experiences in games and interactive applications.

## License

MIT License - see LICENSE file

## Contributing

This is primarily a research/demonstration project. Issues and PRs welcome for bug fixes and improvements to the simulation framework.
