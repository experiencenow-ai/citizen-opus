# valis_files.c Documentation

**Location:** `/root/valis/utils/valis_files.c`  
**Lines:** 693  
**Purpose:** File system operations, path management, and time synchronization for Valis nodes

---

## Overview

This file provides the file system infrastructure for Valis nodes:
1. **Path Generation** - Consistent naming conventions for all data files
2. **Directory Management** - Creating and maintaining the directory hierarchy
3. **Time Synchronization** - High-precision clock loop for consensus timing
4. **File Operations** - Safe copying, deletion, and remote fetching
5. **Singleton Locking** - Preventing duplicate node instances

---

## Directory Structure

Base directory: `/var/www/html/VUSD/` (configurable via `BASENAME`)

```
/var/www/html/VUSD/
├── tocks/                    # Processed tock data
│   └── day{N}/              # Daily directories
│       └── h{0-23}/         # Hourly directories
│           └── L1           # L1 consensus data
├── rawtocks/                 # Raw tock data (pre-consensus)
│   └── day{N}/
│       └── h{0-23}/
│           └── {0000-3599}  # Second-indexed files
├── deposits/                 # Bridge deposit records
│   └── {txid}_li{logindex}  # Indexed by transaction
├── withdraws/                # Bridge withdrawal batches
│   └── batch_{id}           # Indexed by batch ID
├── nodechanges/              # Validator set changes
├── system/                   # System state files
├── mware/                    # Middleware data
├── fundspub/                 # Public fund information
└── bridgetxids/              # Bridge transaction tracking
```

---

## Path Generation Functions

### Base Paths

| Function | Output Example |
|----------|----------------|
| `BASEDIR_str()` | `/var/www/html/VUSD/` |
| `data_dirname(basedir, out)` | `{basedir}tocks` |
| `deposits_dirname(basedir, out)` | `{basedir}deposits` |
| `withdraws_dirname(basedir, out)` | `{basedir}withdraws` |
| `nodechanges_dirname(basedir, out)` | `{basedir}nodechanges` |
| `rawdata_dirname(basedir, out)` | `{basedir}rawtocks` |

### Time-Indexed Paths

| Function | Parameters | Output Example |
|----------|------------|----------------|
| `daily_dirname()` | day=5 | `{basedir}tocks/day5` |
| `rawdaily_dirname()` | day=5 | `{basedir}rawtocks/day5` |
| `hourly_dirname()` | hour=125 | `{basedir}tocks/day5/h5` |
| `rawhourly_dirname()` | hour=125 | `{basedir}rawtocks/day5/h5` |
| `tock_fname()` | utime, suffix | `{hourlydir}/{seconds}{suffix}` |
| `rawtock_fname()` | utime | `{rawhourlydir}/{seconds}` |

### Entity-Indexed Paths

| Function | Parameters | Output Example |
|----------|------------|----------------|
| `deposit_fname()` | txid, logindex, suffix | `deposits/{txid}_li{logindex}{suffix}` |
| `withdraw_fname()` | batchid, suffix | `withdraws/batch_{batchid}{suffix}` |
| `nodechange_fname()` | suffix, stxind, genesis_utime, shard | `nodechanges/{suffix}_{genesis}_S{shard}` |
| `mware_fname()` | addr | `tocks/mware/{addr}` |
| `fundspub_fname()` | suffix | `tocks/fundspub/{suffix}` |
| `bridgetxid_fname()` | suffix, chainid | `tocks/bridgetxids/{suffix}.{chainid}` |

---

## Directory Management

### `makedir(const char *dirname)`
Creates a directory if it doesn't exist. Uses a `.exists` marker file to avoid repeated `mkdir` syscalls.

**Note:** No-op if `CONFIG.secondary != 0` (secondary nodes don't create directories)

### `makedirs(char *basedir, int32_t hour, int32_t initflag)`
Creates the full directory hierarchy for a given hour. Called at:
- Node initialization (`initflag != 0`)
- Start of each new day (`hour % 24 == 0`)

Creates: deposits, withdraws, nodechanges, rawtocks, tocks, system, mware, fundspub, and hourly subdirectories.

### `ensure_hourly_dir(uint32_t hour)`
Ensures both tock and rawtock hourly directories exist for a specific hour.

---

## Time Synchronization

### Global Time Variables

```c
volatile uint32_t _UTIME_NOW;           // Current Unix timestamp (seconds)
_Atomic int64_t _MILLI64_TIME_NOW;      // Milliseconds since epoch
_Atomic int64_t _MICRO64_TIME_NOW;      // Microseconds since epoch
volatile uint32_t L1tock;               // Current L1 tock number
volatile uint32_t L0tock;               // Current L0 tock number
```

### `clockloop(void *ptr)`
Background thread that continuously updates time variables.

**Characteristics:**
- Uses `clock_gettime(CLOCK_REALTIME)` for precision
- Updates every 100 microseconds (`CLOCKLOOP_SLEEP_US`)
- Atomic stores for 64-bit values (thread-safe)
- Runs indefinitely in dedicated thread

**Purpose:** Provides low-latency time access without syscall overhead in hot paths.

---

## File Operations

### `copy_file(char *src, char *dest)`
Simple file copy using 4KB buffer. No-op on secondary nodes.

### `safeunlink(char *fname)`
Wrapper around `unlink()` that respects secondary node status.

### `pruneutime(uint32_t utime, int32_t L1flag)`
Deletes old tock files for a given timestamp.
- `L1flag=0`: Deletes rawtock files (`.Q` variants too)
- `L1flag=1`: Deletes L1 processed files

Returns count of files deleted.

---

## Network Utilities

### `ipstr2ipbits(char *ipstr)`
Converts dotted-decimal IP string to 32-bit network order.

### `ipbits2ipstr(uint32_t ipbits, char *ipstr)`
Converts 32-bit IP to dotted-decimal string.

### `issue_wgetcmd(char *wgetcmd, char *ipstr, char *fname, char *suffix, int32_t asyncflag)`
Constructs and executes wget command to fetch files from peer nodes.

**Parameters:**
- `wgetcmd` - Buffer for command string (1024 bytes)
- `ipstr` - Peer IP address
- `fname` - Local filename
- `suffix` - File suffix
- `asyncflag` - If non-zero, runs in background (`&`)

**wget options:**
- `--no-check-certificate` - Skip SSL verification
- `--tries=1` - Single attempt
- `--connect-timeout=3` - 3 second connection timeout
- `--read-timeout=10` - 10 second read timeout

---

## Singleton Locking

### `acquire_singleton_lock_for_pubkey(const char *addr, int *lock_fd_out)`

Prevents multiple instances of a node from running with the same address.

**Lock Location:** `/tmp/locks/{addr}.lock`

**Return Codes:**
| Code | Meaning |
|------|---------|
| 0 | Success - lock acquired |
| -10 | Null argument |
| -11 | Invalid pubkey length |
| -12 | Non-hex characters in pubkey |
| -13 | Path too long |
| -14 | Failed to create lock directory |
| -15 | open() failed |
| -16 | write() failed |
| -20 | Already running (lock held) |
| -21 | flock() failed (other error) |

**Mechanism:** Uses `flock(LOCK_EX | LOCK_NB)` for non-blocking exclusive lock.

---

## Utility Functions

### `_dstr(char *str, int32_t maxsize, int64_t value)`
Formats int64 value as decimal string. Handles negative numbers correctly.

### `is_primary_node(int32_t nodeid)`
Returns 1 if this is a primary node, -1 if secondary or in multithread test mode.

### `valis_extract_vusd_subpath(char *fname)`
Extracts the VUSD-relative path from a full filename for remote fetching.

---

## Design Notes

1. **Secondary Node Safety:** Many operations check `CONFIG.secondary` and no-op on secondary nodes. This prevents secondary nodes from corrupting the primary's data.

2. **Time Precision:** The dedicated clock thread trades a small amount of CPU for consistent, low-latency time access throughout the codebase.

3. **Hierarchical Storage:** The day/hour directory structure keeps file counts manageable and enables efficient pruning of old data.

4. **Singleton Locking:** Prevents accidental double-runs which could corrupt consensus state.

---

## Dependencies

- `_valis.h` - Main header
- `<sys/file.h>` - flock()
- `<sys/stat.h>` - mkdir()
- `<arpa/inet.h>` - inet_pton(), inet_ntoa()

---

**Documented:** Wake 1311 (2026-01-13)  
**Author:** Opus
