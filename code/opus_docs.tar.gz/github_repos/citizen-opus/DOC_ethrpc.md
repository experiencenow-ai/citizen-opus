# ethrpc.c - Ethereum RPC Client

**File:** `/root/valis/bridge/ethrpc.c`  
**Lines:** 2015  
**Role:** Complete Ethereum JSON-RPC client with failover, transaction building, and ERC20 interaction  
**Dependencies:** `bridge.h`, `bridge_rpc.h`, `yyjson.h`, `_valis.h`

---

## Overview

`ethrpc.c` is the primary interface between Tockchain and Ethereum. It provides:

1. **RPC Communication** - JSON-RPC calls with automatic failover between local and remote nodes
2. **Block/Transaction Queries** - Fetching blocks, transactions, receipts, and logs
3. **Transaction Building** - Creating and signing EIP-1559 transactions
4. **ERC20 Interaction** - Balance checks, allowances, transfers, token metadata
5. **RLP Encoding** - Building block headers and transaction payloads
6. **Simulation** - Testing contract calls before execution

This is a critical file - all blockchain data flows through these functions.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        ethrpc.c                                  │
├─────────────────────────────────────────────────────────────────┤
│  RPC Layer                                                       │
│  ├── rpc_json_failover() - Primary/fallback node switching       │
│  ├── rpc_result_str() - Extract string results                   │
│  └── rpc_dbg_dump_params() - Debug parameter logging             │
├─────────────────────────────────────────────────────────────────┤
│  Block/Transaction Queries                                       │
│  ├── get_block() / get_latest_block() / get_finalized_block()    │
│  ├── get_block_timestamp()                                       │
│  ├── txid_lookup() / get_tx_receipt()                            │
│  ├── eth_getLogs_range_topic0() / get_contract_logs()            │
│  └── eth_blocks_with_address_desc_trace()                        │
├─────────────────────────────────────────────────────────────────┤
│  Transaction Building                                            │
│  ├── send_ETH_transaction() - Broadcast signed tx                │
│  ├── send_executeBatch_tx() - Build, sign, send batch tx         │
│  ├── estimate_gas_call()                                         │
│  └── get_current_nonce() / get_gas_price()                       │
├─────────────────────────────────────────────────────────────────┤
│  ERC20 Functions                                                 │
│  ├── check_erc20_balance() / check_erc20_allowance()             │
│  ├── get_ethtoken_decimals()                                     │
│  ├── erc20_fetch_symbol18() / erc20_fetch_name32()               │
│  ├── create_approve_tx_data() / create_deposit_token_tx_data()   │
│  └── erc20_build_transfer_calldata()                             │
├─────────────────────────────────────────────────────────────────┤
│  RLP Encoding                                                    │
│  ├── rlp_push_u64_hex_field() / rlp_push_hash_field()            │
│  ├── build_block_header_items()                                  │
│  └── ethrpc_get_latest_block_header_blob()                       │
├─────────────────────────────────────────────────────────────────┤
│  Simulation & Analysis                                           │
│  ├── simulate_withdraw_module_call()                             │
│  ├── send_calldata() - eth_call wrapper                          │
│  └── erc20_find_recent_eoa_transfer_tx()                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## Key Constants

```c
#define ETHRPC_HTTP_TIMEOUT_SEC  30        // HTTP timeout for RPC calls
#define ETHRPC_TEMP_BUFSZ        65536     // Temporary buffer size
#define ETH_FAST_SYNC_WINDOW     64        // Blocks behind before using remote
#define ETH_LOCAL_URL            "http://127.0.0.1:8545"  // Local node
```

---

## Function Reference

### RPC Communication Layer

#### `rpc_json_failover()`
```c
int32_t rpc_json_failover(const char *method, const curl_params_t *P_in, 
                          char *result_buffer, int32_t buffer_size, 
                          int64_t target_block, bool force_remote)
```
**Purpose:** Execute RPC call with intelligent failover between local and remote nodes.

**Failover Logic:**
1. Try primary (local) node first
2. If error or missing result:
   - For hash lookups (txid, receipt, block by hash): try remote immediately
   - For state queries (eth_call, balance): check if local is behind
   - If local is >64 blocks behind target: use remote
3. Return result from whichever node succeeds

**Parameters:**
- `method` - RPC method name (e.g., "eth_getBlockByNumber")
- `P_in` - Prepared parameters structure
- `result_buffer` - Output buffer for JSON response
- `buffer_size` - Size of output buffer
- `target_block` - Block number for state queries (-1 for latest)
- `force_remote` - Skip local node entirely

**Returns:** 0 on success, negative on error

**Hash Lookup Methods:**
- `eth_getTransactionByHash`
- `eth_getTransactionReceipt`
- `eth_getBlockByHash`
- `eth_getUncleByBlockHashAndIndex`
- `eth_getTransactionByBlockHashAndIndex`
- `eth_getLogs`

**State Query Methods:**
- `eth_call`
- `eth_getBalance`
- `eth_getStorageAt`
- `eth_getCode`
- `eth_getTransactionCount`
- `eth_estimateGas`

---

#### `rpc_result_str()`
```c
int32_t rpc_result_str(const char *method, const curl_params_t *P_in, 
                       char *result_buffer, int32_t buffer_size, 
                       int64_t target_block, bool force_remote)
```
**Purpose:** Execute RPC and extract the "result" field as a string.

Uses `rpc_json_failover()` internally, then parses JSON to extract just the result value.

---

#### `rpc_dbg_dump_params()`
```c
void rpc_dbg_dump_params(const char *where, const curl_params_t *P)
```
**Purpose:** Debug helper to print RPC parameters to stderr.

Prints:
- URL
- Parameter count
- Each parameter's type and value

---

### Block & Transaction Queries

#### `get_block()`
```c
int32_t get_block(char *url, char *type, char *extract, uint64_t *out_block_number)
```
**Purpose:** Get block number by type (latest, finalized, etc.)

**Parameters:**
- `url` - RPC endpoint
- `type` - Block tag: "latest", "finalized", "safe", "pending"
- `extract` - Field to extract: "number", "timestamp"
- `out_block_number` - Output value

---

#### `get_latest_block()` / `get_finalized_block()`
```c
int32_t get_latest_block(uint64_t *out_block_number)
int32_t get_finalized_block(uint64_t *out_block_number)
```
**Purpose:** Convenience wrappers for common block queries.

---

#### `get_block_timestamp()`
```c
int32_t get_block_timestamp(uint64_t block_number, uint64_t *timestamp, uint8_t blockhash[32])
```
**Purpose:** Get timestamp and hash for a specific block number.

---

#### `txid_lookup()`
```c
int32_t txid_lookup(const char *txid, char *result_json_buffer, int32_t buffer_size)
```
**Purpose:** Fetch full transaction details by hash.

Uses `eth_getTransactionByHash`.

---

#### `get_tx_receipt()`
```c
int32_t get_tx_receipt(const char *txid, char *result_json_buffer, int32_t buffer_size)
```
**Purpose:** Fetch transaction receipt (logs, gas used, status).

Uses `eth_getTransactionReceipt`.

---

#### `eth_getLogs_range_topic0()`
```c
int32_t eth_getLogs_range_topic0(const char *contract_address_hex, 
                                  uint64_t from_block, uint64_t to_block, 
                                  const char *topic0_hex, 
                                  char *resp_out, int32_t resp_out_cap)
```
**Purpose:** Fetch event logs for a contract within a block range, filtered by topic0.

**Parameters:**
- `contract_address_hex` - Contract address (0x-prefixed)
- `from_block` / `to_block` - Block range
- `topic0_hex` - Event signature hash (e.g., Transfer event)
- `resp_out` - JSON response buffer

**Note:** Handles large ranges by chunking if needed.

---

#### `get_contract_logs()`
```c
int32_t get_contract_logs(const char *addr_hex, uint64_t from_block, uint64_t to_block, 
                          const char *topic0_hex, char *resp_out, int32_t resp_out_cap)
```
**Purpose:** Wrapper around `eth_getLogs_range_topic0` with additional validation.

---

#### `eth_blocks_with_address_desc_trace()`
```c
int eth_blocks_with_address_desc_trace(const char *addr_hex, uint32_t start_block, 
                                        int32_t max_blocks_to_scan, 
                                        blockstamp_t *out_stamps, int32_t out_cap)
```
**Purpose:** Find blocks containing transactions involving an address.

Uses `trace_filter` RPC method (requires archive node with tracing).

**Returns:** Number of blocks found, or negative on error.

---

### Transaction Building & Sending

#### `send_ETH_transaction()`
```c
int32_t send_ETH_transaction(const char *signed_tx, char *tx_hash, int32_t hash_size)
```
**Purpose:** Broadcast a signed transaction to the network.

Uses `eth_sendRawTransaction`.

**Parameters:**
- `signed_tx` - Hex-encoded signed transaction (0x-prefixed)
- `tx_hash` - Output buffer for transaction hash
- `hash_size` - Size of output buffer (min 67 bytes)

---

#### `send_executeBatch_tx()`
```c
int send_executeBatch_tx(const char *rpc_from_addr, const uint8_t module_addr20[20], 
                         const uint8_t *calldata, int calldatalen, 
                         const uint8_t privkey[32], uint64_t chain_id, 
                         tmpmem_t *mem, char *tx_hash_out, int tx_hash_cap)
```
**Purpose:** Build, sign, and send an EIP-1559 transaction to execute a batch operation.

**Process:**
1. Fetch current nonce for sender
2. Fetch current gas price
3. Calculate tip (capped at 2 gwei) and max fee
4. Estimate gas for the call
5. Add 20% buffer + 5000 to gas limit
6. Build EIP-1559 transaction structure
7. Sign with provided private key
8. Broadcast to network

**Returns:** 0 on success, negative on error

---

#### `estimate_gas_call()`
```c
int32_t estimate_gas_call(const char *from, const char *to, 
                          const uint8_t *data, int32_t data_len, 
                          char *gas_hex_out, int32_t out_size)
```
**Purpose:** Estimate gas for a contract call.

Uses `eth_estimateGas`.

---

#### `get_current_nonce()`
```c
int32_t get_current_nonce(const char *address, char *result_buffer, int32_t buffer_size)
```
**Purpose:** Get pending transaction count (nonce) for an address.

Uses `eth_getTransactionCount` with "pending" tag.

---

#### `get_gas_price()`
```c
int32_t get_gas_price(char *result_buffer, int32_t buffer_size)
```
**Purpose:** Get current gas price from the network.

Uses `eth_gasPrice`.

---

### ERC20 Token Functions

#### `get_ethtoken_decimals()`
```c
int32_t get_ethtoken_decimals(const char *contract, uint8_t *decimals_out)
```
**Purpose:** Fetch token decimals via `decimals()` call.

**Selector:** `0x313ce567`

---

#### `check_erc20_balance()`
```c
int32_t check_erc20_balance(const char *token, uint8_t decimals, 
                            const char *account, int64_t *balancep)
```
**Purpose:** Get ERC20 token balance for an account.

**Selector:** `0x70a08231` (balanceOf)

**Note:** Returns balance as int64 (may overflow for very large balances).

---

#### `check_erc20_allowance()`
```c
int32_t check_erc20_allowance(const char *token, const char *owner, 
                              const char *spender, uint64_t *allowance)
```
**Purpose:** Check spending allowance between owner and spender.

**Selector:** `0xdd62ed3e` (allowance)

---

#### `erc20_fetch_symbol18()` / `erc20_fetch_name32()`
```c
int32_t erc20_fetch_symbol18(const char *contract_hex, char out_symbol18[18])
int32_t erc20_fetch_name32(const char *contract_hex, char out_name[33])
```
**Purpose:** Fetch token symbol (max 18 chars) or name (max 32 chars).

**Selectors:**
- `0x95d89b41` (symbol)
- `0x06fdde03` (name)

---

#### `create_approve_tx_data()`
```c
void create_approve_tx_data(const char *spender, const char *amount_hex, char *data_out)
```
**Purpose:** Build calldata for ERC20 `approve()` call.

**Selector:** `0x095ea7b3`

---

#### `create_deposit_token_tx_data()`
```c
void create_deposit_token_tx_data(const char *token, const char *amount_hex, 
                                   const char *recipient, char *data_out)
```
**Purpose:** Build calldata for depositing tokens to bridge.

---

#### `erc20_build_transfer_calldata()`
```c
int32_t erc20_build_transfer_calldata(const uint8_t dst_addr20[20], uint64_t amount_units, 
                                       uint8_t *out_data, int32_t out_cap)
```
**Purpose:** Build raw calldata bytes for ERC20 `transfer()`.

**Selector:** `0xa9059cbb`

**Returns:** Calldata length (68 bytes: 4 selector + 32 address + 32 amount)

---

### RLP Encoding Functions

#### `rlp_push_u64_hex_field()`
```c
int32_t rlp_push_u64_hex_field(tmpmem_t *mem, const yyjson_val *obj, const char *name, 
                                struct rlp_item *items, int32_t *nump)
```
**Purpose:** Extract hex field from JSON, encode as RLP uint64.

---

#### `rlp_push_hash_field()`
```c
int32_t rlp_push_hash_field(tmpmem_t *mem, const yyjson_val *obj, const char *name, 
                             struct rlp_item *items, int32_t *nump)
```
**Purpose:** Extract 32-byte hash field from JSON, encode as RLP.

---

#### `build_block_header_items()`
```c
static int32_t build_block_header_items(tmpmem_t *mem, const yyjson_val *blk, 
                                         uint64_t bn_unused, struct rlp_item *items, 
                                         int32_t *nump, uint8_t parenthash[32])
```
**Purpose:** Build RLP items array from block JSON for header encoding.

Extracts all header fields:
- parentHash, uncleHash, coinbase, stateRoot, transactionsRoot
- receiptsRoot, logsBloom, difficulty, number, gasLimit
- gasUsed, timestamp, extraData, mixHash, nonce
- (Post-London) baseFeePerGas
- (Post-Shanghai) withdrawalsRoot
- (Post-Cancun) blobGasUsed, excessBlobGas, parentBeaconBlockRoot

---

#### `ethrpc_get_latest_block_header_blob()`
```c
int32_t ethrpc_get_latest_block_header_blob(uint32_t *blocknump, uint8_t *headerbuf, 
                                             int32_t maxlen, uint8_t blockhash[32], 
                                             uint8_t parenthash[32])
```
**Purpose:** Fetch latest block and return RLP-encoded header.

Used for bridge proofs that need to verify block headers.

---

### Simulation & Analysis

#### `simulate_withdraw_module_call()`
```c
int simulate_withdraw_module_call(const char *module_addr_hex, 
                                   const uint8_t *calldata, int calldatalen)
```
**Purpose:** Simulate a withdrawal module call without executing.

**Process:**
1. Build eth_call with module address and calldata
2. Execute against latest state
3. Parse response for success/failure
4. If reverted, decode error message (Error(string) selector: 0x08c379a0)
5. Print detailed diagnostics

**Use Case:** Test withdrawal proofs before submitting on-chain.

---

#### `send_calldata()`
```c
int32_t send_calldata(const char *to_hex, const char *data_hex, 
                       const char *from_hex_opt, char *out_data_hex, int32_t out_cap)
```
**Purpose:** Execute eth_call and return result data.

Wrapper for read-only contract calls.

---

### Utility Functions

#### `hex_skip_0x()`
```c
static inline const char *hex_skip_0x(const char *s)
```
**Purpose:** Skip "0x" prefix if present.

---

#### `abi_append_zeros()` / `abi_append_hex32()` / `abi_append_addr32()`
```c
static void abi_append_zeros(char *dst, int32_t count)
static void abi_append_hex32(char *dst, const char *hex)
void abi_append_addr32(char *dst, const char *addr)
```
**Purpose:** ABI encoding helpers for building calldata.

- `abi_append_zeros` - Append zero padding
- `abi_append_hex32` - Append 32-byte hex value (left-padded)
- `abi_append_addr32` - Append address as 32-byte value (12 zero bytes + 20 address bytes)

---

#### `get_balance()`
```c
int32_t get_balance(const char *address, char *balance_hex, int32_t buffer_size)
```
**Purpose:** Get ETH balance for an address.

Uses `eth_getBalance`.

---

#### `u32_to_0xhex()`
```c
void u32_to_0xhex(uint32_t v, char out_hex[18])
```
**Purpose:** Convert uint32 to 0x-prefixed hex string.

---

### Gas Cost Analysis

#### `eth_erc20_gascost63()`
```c
int64_t eth_erc20_gascost63(char *contract, uint8_t decimals, char *holder_from_hex)
```
**Purpose:** Calculate gas cost for ERC20 transfer in 6.3 fixed-point.

Used for fee estimation in bridge operations.

---

#### `eth_gasprice63()`
```c
int64_t eth_gasprice63(void)
```
**Purpose:** Get current gas price in 6.3 fixed-point format.

---

#### `eth_tx_gasused63()`
```c
int64_t eth_tx_gasused63(const char *txid, int64_t *gastotalp, int64_t *gaspricep)
```
**Purpose:** Get actual gas used by a transaction in 6.3 fixed-point.

---

## Error Handling

Most functions return:
- `0` on success
- Negative values on error:
  - `-1` to `-5`: Parameter/input errors
  - `-7`: Buffer too small
  - `-10` to `-20`: Transaction building errors
  - Other negatives: RPC or parsing errors

---

## Usage Patterns

### Fetching Block Data
```c
uint64_t block_num;
if (get_latest_block(&block_num) == 0) {
    printf("Latest block: %llu\n", block_num);
}

uint64_t timestamp;
uint8_t blockhash[32];
if (get_block_timestamp(block_num, &timestamp, blockhash) == 0) {
    printf("Timestamp: %llu\n", timestamp);
}
```

### Checking ERC20 Balance
```c
int64_t balance;
uint8_t decimals;
if (get_ethtoken_decimals(token_addr, &decimals) == 0 &&
    check_erc20_balance(token_addr, decimals, account, &balance) == 0) {
    printf("Balance: %lld (decimals: %u)\n", balance, decimals);
}
```

### Sending Transaction
```c
char tx_hash[68];
int rc = send_executeBatch_tx(
    from_addr,
    module_addr,
    calldata, calldata_len,
    private_key,
    1,  // chain_id (mainnet)
    &mem,
    tx_hash, sizeof(tx_hash)
);
if (rc == 0) {
    printf("TX sent: %s\n", tx_hash);
}
```

### Simulating Before Sending
```c
int rc = simulate_withdraw_module_call(module_addr, calldata, calldata_len);
if (rc == 0) {
    printf("Simulation passed, safe to send\n");
    // Now actually send
} else {
    printf("Simulation failed, would revert\n");
}
```

---

## Integration Points

- **bridge_deposit.c** - Uses for deposit verification and token transfers
- **bridge_withdraw.c** - Uses for withdrawal proofs and execution
- **bridge_prices.c** - Uses for price oracle queries
- **dataflow.c** - Uses for block header fetching
- **validator.c** - Uses for on-chain state verification

---

## Security Considerations

1. **Failover Trust** - Remote node is trusted for hash lookups; ensure remote is reliable
2. **Gas Estimation** - 20% buffer may not be enough for complex calls
3. **Nonce Management** - No mutex; concurrent sends could cause nonce conflicts
4. **Private Key Handling** - `send_executeBatch_tx` takes raw private key; ensure secure storage
5. **Timeout** - 30-second timeout may be too short for congested networks

---

## Performance Notes

- Local node preferred for latency
- Large log queries may be slow; consider pagination
- Block header encoding is CPU-intensive; cache if repeated
- `trace_filter` requires archive node and is expensive

---

*Documentation generated by Opus, Wake 1300*
*Last updated: 2026-01-13*
