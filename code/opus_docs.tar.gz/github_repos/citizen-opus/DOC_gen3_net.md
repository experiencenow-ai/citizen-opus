# gen3_net.c Documentation

**File:** `generator/gen3_net.c`  
**Lines:** ~755  
**Purpose:** Network layer for Tockchain consensus - broadcasting, packet processing, and message routing  
**Author:** Opus (Wake 1309)  
**Audit:** Pending (assigned to Kira)

---

## Overview

This file implements the networking layer for the Tockchain generator (consensus engine). It handles:

1. **Broadcasting** - Sending consensus messages to validator peers
2. **Packet Processing** - Receiving and routing inbound messages
3. **Queue Management** - Managing packet queues for different message types
4. **VANS Distribution** - Validator Accumulated Node State synchronization

The networking integrates with `valis_net_MT.c` (multi-threaded transport) and `gen3_vote.c` (consensus voting).

---

## Message Types

| Message | Constant | Description |
|---------|----------|-------------|
| VANS | NODETXIDS_MSG | Node transaction ID hashes |
| Signatures | ALLSIGS_BROADCAST_MSG | Aggregated vote signatures |
| Needbits | 'N' | Missing data requests |
| Votes | Various | Consensus ballot messages |

---

## Core Broadcasting Functions

### `broadcast_valis_update()`
```c
int32_t broadcast_valis_update(global_reserve_t *GEN3, int32_t fifoind,
                                unified_header_t *H, int32_t packetlen,
                                uint8_t destpub[PKSIZE], int32_t mustsign)
```

Low-level broadcast with redundancy control.

**Parameters:**
- `GEN3` - Global generator state
- `fifoind` - FIFO index for metrics tracking
- `H` - Unified packet header (filled in if fields are zero)
- `packetlen` - Total packet length
- `destpub` - Destination public key (NULL for broadcast)
- `mustsign` - Whether to sign packet (always forced to 1)

**Behavior:**
1. Validates packet length
2. Fills in genesis_utime if not set
3. Calculates redundancy factor via `update_outbound_metrics()`
4. Sends packet `redundancy` times via `vnet_send()`
5. Tracks send errors via `update_metrics_senderr()`

**Returns:** Redundancy count (number of sends attempted)

---

### `broadcast_packet()`
```c
int32_t broadcast_packet(utime_data_t *U, uint8_t msg, uint8_t *packetH,
                          uint8_t *payload, int32_t payloadsize, uint8_t *destpub)
```

High-level packet broadcast with header construction.

**Parameters:**
- `U` - Current utime state
- `msg` - Message type byte
- `packetH` - Pre-allocated packet buffer (or NULL to use stack)
- `payload` - Message payload
- `payloadsize` - Payload length
- `destpub` - Destination (NULL for broadcast)

**Header Fields Set:**
- `msg` - Message type
- `senderid` - This node's ID
- `srcvapp` / `destvapp` - VAPPID_UTIMED
- `utime` - Current consensus second
- `pubkey` - This node's public key
- `packetlen` - Total size

**Safety:** Validates `payloadsize + sizeof(H) <= SAFE_MTU_SIZE`

---

### `broadcast_allsigs()`
```c
int32_t broadcast_allsigs(utime_data_t *U, uint8_t destpub[PKSIZE], int32_t qidx)
```

Broadcasts aggregated signatures for a consensus question.

**Process:**
1. Gathers all signatures via `gather_allsigs()`
2. Packs into ALLSIGS_BROADCAST_MSG
3. Broadcasts to network

**Use Case:** Propagating consensus finalization to peers.

---

### `broadcast_my_nVANS()`
```c
int32_t broadcast_my_nVANS(utime_data_t *U, uint8_t destpub[PKSIZE])
```

Broadcasts this node's VANS (Validator Accumulated Node State).

**Payload Contents:**
- `nodevanshashes` - Hashes of accumulated state
- `final_numvans` - VIP and normal VAN counts
- `final_numtx` - Transaction counts
- `needbits` - Bitmap of missing data

**Verification:** Self-validates via `parse_needbits()` before sending.

---

### `broadcast_needbits()`
```c
int32_t broadcast_needbits(global_reserve_t *GEN3, unified_header_t *H,
                            int32_t seqid, int32_t *needlenp)
```

Broadcasts requests for missing data.

**Message Type:** 'N'

**Behavior:**
1. Sets up header with needbits payload
2. Optionally validates via `process_inbound_needbits()` (disabled)
3. Broadcasts to all peers
4. Resets needlen counter

---

### `broadcast_votebatch()`
```c
int32_t broadcast_votebatch(global_reserve_t *GEN3, unified_header_t *H,
                             int32_t seqid, int32_t *batchcountp)
```

Broadcasts batched consensus votes.

**Efficiency:** Batches multiple votes into single network packet.

---

## Inbound Processing

### `drain_vapp_slot()`
```c
int32_t drain_vapp_slot(global_reserve_t *GEN3, 
                         int32_t (*process_func)(utime_data_t*, unified_header_t*, int32_t, uint64_t),
                         int32_t peerset, int32_t fifoind, int32_t vappid, int32_t maxpackets)
```

Drains packets from a VAPP slot queue.

**Parameters:**
- `process_func` - Callback for processing each packet
- `peerset` - Peer set identifier
- `fifoind` - FIFO slot index
- `vappid` - Virtual application ID
- `maxpackets` - Maximum packets to process

**Process:**
1. Dequeues packets from slot
2. Validates sender signature
3. Calls process_func for each packet
4. Updates metrics
5. Frees processed packets

**Returns:** Number of packets processed

---

### `gen3_drain_vans()`
```c
static inline void gen3_drain_vans(global_reserve_t *GEN3, utime_data_t *U, int32_t fifoind)
```

Drains all VAN-related queues for a utime.

**Queues Drained:**
1. `VAPPID_UTIMED` - General consensus messages
2. `VAPPID_VIP_VANS` - VIP validator VANs
3. `VAPPID_NORMAL_VANS` - Normal validator VANs

---

### `process_inbound_nodetxids()`
```c
int32_t process_inbound_nodetxids(utime_data_t *U, unified_header_t *H,
                                   int32_t senderid, uint64_t arrival_ms)
```

Processes incoming node transaction ID messages.

**Actions:**
1. Checks if sender is disabled
2. Updates latency metrics
3. Finalizes VANS for both VIP and normal categories
4. Parses needbits from payload

---

### `process_inbound_needbits()`
```c
int32_t process_inbound_needbits(global_reserve_t *GEN3, unified_header_t *H,
                                  int32_t offset, int32_t testmode)
```

Processes incoming needbits (missing data requests).

**Protocol:**
1. Extract utime from payload
2. Get corresponding utime_data
3. Validate utime matches (or enter testmode)
4. Parse needbits via `parse_needbits()`
5. Queue needbits for processing

**Error Codes:**
- `-12` - Zero utime
- `-13` - Cannot get utime data
- `-111` - Payload too short

---

## Queue Management

### `queue_van()`
```c
void queue_van(utime_data_t *U, int32_t is_vip, int32_t mustsign,
                unified_header_t *H, int32_t packetlen)
```

Queues a VAN for broadcast.

**Conditions Checked:**
- Rotating vanless node configuration
- Cold VAN with no pending election

---

### `queue_futuretx()`
```c
int32_t queue_futuretx(global_reserve_t *GEN3, uint32_t utime,
                        uint8_t *txbuf, int32_t len, int32_t is_vip)
```

Queues a transaction for future processing.

**Thread Safety:** Uses mutex on slot

**Limits:** `GEN3_FUTURETX_MAX_PER_SLOT` per time slot

**Returns:**
- `1` - Success
- `-1` - Invalid parameters
- `-2` - Slot full
- `-3` - Allocation failed

---

### `queue_needbits()`
```c
int32_t queue_needbits(utime_data_t *U, int32_t senderid, uint8_t *needbits, int32_t len)
```

Queues needbits for processing by utime thread.

**Packet Fields:**
- `internalmsg = 1` - Internal routing
- `qidx = NEEDBITS_MSG` - Message type
- `senderid` - Originating node

---

### `queue_vote()`
```c
int32_t queue_vote(global_reserve_t *GEN3, valis_vote_t *recv_vote, int32_t senderid)
```

Queues a received vote for consensus processing.

**Routing:** Uses ballot's utime for FIFO slot selection.

---

## Packet Structures

### unified_header_t
```c
typedef struct {
    uint8_t msg;           // Message type
    uint8_t senderid;      // Sender node ID
    uint8_t srcvapp;       // Source VAPP
    uint8_t destvapp;      // Destination VAPP
    uint32_t utime;        // Consensus second
    uint32_t genesis_utime; // Network genesis time
    uint32_t packetlen;    // Total packet length
    uint8_t pubkey[PKSIZE]; // Sender public key
    // ... signature fields
} unified_header_t;
```

### nodetxidshash_payload_t
```c
typedef struct {
    uint8_t nodevanshashes[2][32]; // VIP and normal hashes
    uint16_t final_numvans[2];     // VAN counts
    uint16_t final_numtx[2];       // TX counts
} nodetxidshash_payload_t;
```

---

## Thread Model

| Thread | Functions Called |
|--------|-----------------|
| Global | queue_futuretx, broadcast_needbits, broadcast_votebatch |
| Utime | gen3_drain_vans, broadcast_packet, queue_van |
| Network | Delivers to VAPP slots |

---

## Metrics Integration

The networking layer integrates with metrics tracking:

- `update_outbound_metrics()` - Tracks sends, calculates redundancy
- `update_metrics_senderr()` - Tracks send failures
- `update_global_recvmetrics()` - Tracks receives
- `update_utime_lagms()` - Tracks network latency

---

## Error Handling

| Error | Meaning |
|-------|---------|
| -1 | Invalid parameters or packet too large |
| -2 | Queue full or buffer too small |
| -3 | Memory allocation failed |
| -8 | Non-critical processing error (sampled logging) |
| -12 | Zero utime in needbits |
| -13 | Cannot get utime data |

---

## Dependencies

- `gen3.h` - Type definitions
- `gen3_utils.c` - Ring buffer, utime management
- `gen3_vote.c` - Vote gathering
- `gen3_needbits.c` - Needbits calculation/parsing
- `valis_net_MT.c` - Transport layer

---

## Integration Points

| Component | Interaction |
|-----------|-------------|
| gen3_vote.c | Receives queued votes, sends signatures |
| gen3_needbits.c | Calculates and parses needbits |
| gen3_vans.c | VANS finalization |
| valis_messaging.c | Low-level message protocol |

---

## Performance Considerations

1. **Redundancy:** Adaptive based on network conditions
2. **Batching:** Votes batched for efficiency
3. **FIFO Slots:** Prevents unbounded queue growth
4. **Mutex Scope:** Minimized in queue operations

---

## Audit Checklist (for Kira)

- [ ] Verify MTU size checks prevent buffer overflows
- [ ] Check mutex usage in queue_futuretx is correct
- [ ] Validate sender verification in drain_vapp_slot
- [ ] Confirm needbits parsing handles malformed data
- [ ] Review redundancy calculation logic
- [ ] Check for potential deadlocks in queue operations
