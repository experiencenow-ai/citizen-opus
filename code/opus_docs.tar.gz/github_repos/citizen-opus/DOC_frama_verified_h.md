# frama_verified.h - Formally Verified Functions Header

**Location:** `/root/valis/frama_verified.h`  
**Lines:** 459  
**Companion:** `frama_verified.c` (implementation)  
**Purpose:** Header declaring pure functions that have been formally verified using Frama-C/WP

---

## Overview

This header provides the interface to Tockchain's formally verified pure functions. These functions handle critical financial calculations (multiplication, division, fee computation, swap pricing) where correctness is essential. The implementations in `frama_verified.c` have been proven correct using Frama-C's Weakest Precondition (WP) plugin.

**Verification command:** `frama-c -wp -wp-rte frama_verified.c`

---

## Design Philosophy

### Constant Synchronization
The header re-declares constants from `_valis.h`, `ufc.h`, and `dataflow.h` with **identical text**. This creates a compile-time drift detection mechanism:
- If constants differ between headers, the compiler warns about redefinition
- Any divergence is caught at build time, not runtime

### Verification Strategy
- **Pure functions only** - no side effects, no global state
- **Overflow-safe arithmetic** - uses `__int128` for intermediate calculations
- **ACSL annotations** - formal specifications embedded in code
- **Trusted primitives** - some operations (memcpy, union punning) are marked trusted because WP cannot reason about them

---

## Constants Defined

### Core Limits
```c
#define MAX_SAFE_63BITS (((int64_t)1 << 62) - 2)  // ~4.6 quintillion
#define PKSIZE 20                                   // Address size (bytes)
#define PYLON_HASH_BYTES 32                        // Hash size
#define MAXCOINSUPPLY MAX_SAFE_63BITS              // Maximum coin supply
#define SATOSHIS ((int64_t)100000000)              // 1 TOCK = 100M satoshis
```

### Dataflow Gas Constants
```c
#define DF_GAS_PRICE_SAT_PER_UNIT INT64_C(1000)   // Gas price in satoshis
#define DF_FRONTIER_GAS_QUANTUM 100                // Gas billing quantum
#define DF_SCORE_STALE_DELTA ((uint16_t)300)       // Staleness threshold
```

### UFC (Unified Flow Control) Constants
```c
#define BPS_DENOM 10000                            // Basis points denominator
#define UFC_MAX_MOVE_BPS 75                        // Max price move per swap (0.75%)
#define UFC_EXT_MAX_MOVE_BPS 4                     // External max move (0.04%)
#define UFC_FLOOR_MIN_BPS 1000                     // Min floor (10%)
#define UFC_FLOOR_MAX_BPS 5000                     // Max floor (50%)
#define UFC_MIN_BALANCE_UNITS 1                    // Minimum balance
#define UFC_OOB_TVL_MAX_DEPL_BPS 250               // OOB max TVL depletion (2.5%)
#define UFC_OOB_SURE_FILL_MARGIN_BPS 200           // OOB sure fill margin (2%)
#define UFC_OOB_CLAMP_BPS 250                      // OOB clamp (2.5%)
#define UFC_RAW_BPS_CAP 100000                     // Raw BPS cap (1000%)
```

---

## Types

### Asset ID
```c
typedef struct assetid_s { 
    uint16_t aid:NUM_ASSETID_BITS,  // 15-bit asset ID
             iscoin:1;               // 1 = native coin, 0 = token
} assetid_t;
```

---

## Function Categories

### 1. Arithmetic Primitives (Trusted)
These use `__int128` for overflow-safe multiplication:

```c
int64_t safe_mul_then_div(int64_t a, int64_t b, int64_t c, int64_t div0_err);
int64_t ufc_mul_div_floor(int64_t a, int64_t b, int64_t c);
int64_t ufc_mul_div_ceil(int64_t a, int64_t b, int64_t c);
```

### 2. UFC Pure Functions
From `ufc_utils.c` and `ufc_swap.c`:
- Price calculations
- Swap amount computations
- Fee calculations
- Floor/ceiling operations

### 3. Dataflow Functions
- Gas charging with rounding
- Score calculations
- Frontier operations
- Address encoding/decoding

---

## Macros

### UFC Calculation Macros
```c
#define UFC_MUL_DIV(a,b,c,err) safe_mul_then_div((int64_t)(a),(int64_t)(b),(int64_t)(c),(int64_t)(err))
#define UFC_VUSD_FROM_OTHER(amount,price_sat) ufc_mul_div_floor((amount),(price_sat),(SATOSHIS))
#define UFC_OTHER_FROM_VUSD(amount,price_sat) ufc_mul_div_floor((amount),(SATOSHIS),(price_sat))
```

---

## Inline Functions

### Bit Reinterpretation (Type Punning)
```c
static inline int64_t df_frontier_i64_from_u64_bits(uint64_t u);
static inline uint64_t df_frontier_u64_from_i64_bits(int64_t s);
```
Uses union punning to reinterpret bits without conversion.

### Address Encoding (Trusted, Not WP-Verified)
```c
#ifndef __FRAMAC__
static inline void df_frontier_addr20_to_words3(const uint8_t addr20[PKSIZE], uint64_t out3[3]);
static inline void df_frontier_words3_to_addr20(const uint64_t in3[3], uint8_t out20[PKSIZE]);
static inline void df_trigger_ptr20_decode(uint8_t out_pk[PKSIZE], uint64_t p0, uint64_t p1, uint32_t p2_lo32);
static inline void df_trigger_ptr20_encode(const uint8_t in_pk[PKSIZE], uint64_t *p0, uint64_t *p1, uint32_t *p2_lo32);
#endif
```
These are excluded from Frama-C verification (`#ifndef __FRAMAC__`) because memcpy is not WP-friendly.

### Gas Charging
```c
static inline int64_t df_frontier_charge_roundup_vusd(int64_t gas_used_gas, int64_t cap_vusd_sat);
```
Calculates gas charges with:
- Rounding up to quantum boundaries
- Cap enforcement
- Overflow protection

---

## ACSL Annotations

Functions include Frama-C ACSL annotations:
```c
/*@
 terminates \true;      // Function always terminates
 assigns \nothing;      // No side effects
 */
```

These annotations enable formal verification of:
- Termination guarantees
- Memory safety (no buffer overflows)
- Arithmetic safety (no integer overflow)
- Functional correctness

---

## Integration Notes

### Include Order
This header should be included after the main headers (`_valis.h`, `ufc.h`, `dataflow.h`) to enable drift detection.

### Conditional Compilation
- `__FRAMAC__` - defined when running under Frama-C analyzer
- Some functions are excluded from verification because they use constructs WP cannot reason about

### Why Formal Verification Matters
Financial calculations must be:
1. **Overflow-safe** - no silent truncation
2. **Deterministic** - same inputs always produce same outputs
3. **Correct** - mathematical properties hold

Formal verification proves these properties mathematically, not just through testing.

---

## Related Files

| File | Relationship |
|------|--------------|
| `frama_verified.c` | Implementation of declared functions |
| `_valis.h` | Source of core constants |
| `ufc.h` | Source of UFC constants |
| `dataflow.h` | Source of dataflow constants |
| `dataflow_inc.h` | Source of assetid_t type |

---

## Verification Status

All pure functions in `frama_verified.c` have been verified with:
- `frama-c -wp -wp-rte frama_verified.c`

The `-wp-rte` flag enables runtime error checking proofs (division by zero, overflow, etc.).

---

*Documentation generated by Opus, Wake 1319*
