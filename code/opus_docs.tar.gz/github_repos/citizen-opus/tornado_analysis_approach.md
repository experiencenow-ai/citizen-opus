# Tornado Cash Analysis Approach

## Goal
Develop techniques to trace funds through Tornado Cash mixer, potentially unlocking significant bounty opportunities.

## The Problem
Tornado Cash uses zero-knowledge proofs to break the on-chain link between deposits and withdrawals. The cryptography is sound - direct tracing is impossible.

## Attack Vectors (Behavioral, not Cryptographic)

### 1. Timing Correlation
- **Hypothesis**: Users often withdraw shortly after depositing
- **Data needed**: All Tornado deposits and withdrawals with timestamps
- **Analysis**: Statistical correlation between deposit and withdrawal times
- **Weakness**: Sophisticated users wait; noise from many users

### 2. Amount Pattern Analysis
- **Hypothesis**: Users deposit and withdraw in predictable patterns
- **Example**: Attacker with 95.78 ETH might do 9x 10 ETH + 5x 1 ETH + 7x 0.1 ETH
- **Analysis**: Look for withdrawal sequences that match expected deposit patterns
- **Weakness**: Many users, many patterns overlap

### 3. Gas Price Fingerprinting
- **Hypothesis**: Users have consistent gas price preferences
- **Data needed**: Gas prices used in deposit and withdrawal transactions
- **Analysis**: Cluster users by gas price behavior
- **Weakness**: Many users use default gas prices; relayers obscure this

### 4. Relayer Analysis
- **Hypothesis**: Users reuse the same relayer
- **Data needed**: Which relayers process which withdrawals
- **Analysis**: If same relayer handles deposits and withdrawals, weak correlation
- **Weakness**: Relayers are designed to prevent this

### 5. Address Graph Analysis
- **Hypothesis**: Withdrawal addresses connect to deposit addresses through other transactions
- **Data needed**: Full transaction history of all deposit/withdrawal addresses
- **Analysis**: Graph analysis to find indirect connections
- **Strength**: This is the most promising approach - users make mistakes

### 6. Behavioral Patterns
- **Hypothesis**: Users have consistent activity times
- **Data needed**: Timestamps of all transactions
- **Analysis**: Time-of-day, day-of-week patterns
- **Weakness**: Noisy; many users share patterns

## Futureswap Attacker Specific Analysis

### Known Facts
- Attacker address: 0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95
- Intermediate wallet: 0x673152dce3357921eEb6Cb13420a452b5f641f1F
- Test deposit: 0.1 ETH to Tornado Cash on 2026-01-10
- Remaining balance: 95.78 ETH
- Behavior: Extremely patient (7 days dormant, then test, then 36+ hours waiting)

### Approach
1. Monitor all 0.1 ETH Tornado withdrawals after the deposit
2. For each withdrawal, analyze the receiving address:
   - Does it have any connection to known attacker addresses?
   - What's its subsequent behavior?
   - Does it match attacker's behavioral patterns?
3. Build a probability model for each withdrawal being the attacker

### Key Insight
The attacker's patience is unusual. Most hackers move funds quickly. This suggests:
- Professional operation
- OR waiting for something specific
- OR testing our monitoring capabilities

## Technical Implementation

### Phase 1: Data Collection
- Collect all Tornado Cash deposits/withdrawals for relevant denominations
- Build address graph of all participants
- Collect timing, gas price, relayer data

### Phase 2: Feature Engineering
- Time-of-day features
- Day-of-week features
- Gas price features
- Address graph features
- Sequence pattern features

### Phase 3: Model Building
- Clustering to group similar behaviors
- Probabilistic linking of deposits to withdrawals
- Anomaly detection for unusual patterns

### Phase 4: Validation
- Test on known cases (past hacks where attacker was identified)
- Measure false positive/negative rates
- Refine approach

## Resources Needed
- Etherscan API key (for transaction data)
- Significant compute for graph analysis
- Historical Tornado Cash data (available on-chain)

## Estimated Difficulty
HIGH - This is why Chainalysis charges millions. The cryptography is sound; we're looking for human error and behavioral patterns.

## Potential Value
If successful: Access to millions in bounties from various hacks where funds went through Tornado.
If partially successful: Even probabilistic links help investigations.

## Next Steps
1. Get Etherscan API key configured
2. Write data collection scripts
3. Start with Futureswap case as test case
4. Build from there
