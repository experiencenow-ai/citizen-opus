# ledger_hourly.c - Periodic Ledger Maintenance

## Overview

This file implements periodic (hourly) maintenance operations for the Tockchain ledger, including address sorting, ranking, and parallel processing utilities. It provides comparison functions for various sorting criteria and OpenMP thread management.

**Location:** `/root/valis/validator/ledger_hourly.c`  
**Lines:** ~1127  
**Dependencies:** validator.h, OpenMP

## Core Concepts

### Hourly Maintenance
- Periodic cleanup and reorganization
- Address ranking by various criteria
- Parallel processing for large datasets

### Sorting Criteria
Multiple comparison functions for different ranking needs:
- By address index (creation order)
- By VUSD balance
- By VNET balance
- By total VUSD value

## Key Functions

### Maintenance Entry Point

#### `L1clear_hour(L1)`
Clears hourly state (stub implementation):
- Called at hour boundaries
- Resets temporary counters

### Comparison Functions

#### `cmpaddressind(a, b)`
Compares addresses by creation order:
- Primary: addressind (unique index)
- Fallback: pubkey comparison (for collision detection)
- Returns -1, 0, or 1 for qsort compatibility

#### `cmpVUSD(a, b)`
Compares addresses by VUSD balance:
- Primary: VUSD balance (descending)
- Secondary: addressind (ascending, for stability)
- Higher balance = earlier in sort

#### `cmpVNET(a, b)`
Compares addresses by VNET balance:
- Same logic as cmpVUSD but for VNET
- Used for governance weight ranking

#### `cmpVUSDval(a, b)`
Compares addresses by adjusted VUSD value:
- Uses adjVUSDvalue field (total portfolio value in VUSD)
- Secondary: addressind for stability
- Used for wealth ranking

### Thread Management

#### `numthreads_foromp()`
Calculates optimal thread count for OpenMP:
```c
int32_t numthreads = (omp_get_max_threads() - 1) / 2;
if (numthreads < 1)
    numthreads = 1;
return numthreads;
```
- Uses half of available threads minus one
- Leaves CPU headroom for other operations
- Minimum of 1 thread

## Sorting Usage

These comparison functions are used with qsort:
```c
// Sort addresses by VUSD balance
qsort(addresses, count, sizeof(struct addrhashentry), cmpVUSD);

// Sort by creation order
qsort(addresses, count, sizeof(struct addrhashentry), cmpaddressind);
```

## Ranking Applications

### VUSD Ranking
- Identifies largest VUSD holders
- Used for fee distribution
- Governance weight calculation

### VNET Ranking
- Validator stake ranking
- Network participation metrics
- Reward distribution

### Value Ranking
- Total portfolio value in VUSD terms
- Cross-asset wealth comparison
- Risk assessment

## Parallel Processing

OpenMP is used for:
- Large dataset sorting
- Parallel balance calculations
- Batch address processing

Thread count is conservative to:
- Avoid CPU saturation
- Leave headroom for consensus
- Prevent thermal throttling

## Integration Points

- **validator.c**: Calls hourly maintenance
- **ledger_atomic.c**: Provides address data
- **ledger_vhandlers.c**: Uses sorted rankings
- **gen3.c**: Coordinates with consensus timing

## Performance Considerations

- Comparison functions are inlined where possible
- Secondary sort key ensures stable ordering
- Thread count adapts to available cores
- Sorting is O(n log n) complexity

## Collision Detection

The `cmpaddressind` function includes collision detection:
```c
if (a->addressind == b->addressind) {
    printf("ERROR addressind.%ld collision\n", (long)a->addressind);
    return memcmp(a->pubkey, b->pubkey, PKSIZE);
}
```
This should never happen in normal operation - indicates data corruption.
