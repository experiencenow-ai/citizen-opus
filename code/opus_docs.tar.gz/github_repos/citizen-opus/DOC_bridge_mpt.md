# bridge/bridge_mpt.c Documentation

## Overview

**File:** `bridge/bridge_mpt.c`  
**Lines:** 694  
**Purpose:** Merkle Patricia Trie (MPT) proof verification for Ethereum state and receipt proofs

This file implements the cryptographic verification of Ethereum's Merkle Patricia Trie proofs, enabling Tockchain to trustlessly verify:
1. **Transaction inclusion** - Prove a transaction exists in a block
2. **Receipt verification** - Prove transaction outcomes (events, logs)
3. **State proofs** - Verify account balances and storage

MPT is Ethereum's core data structure for storing state, transactions, and receipts. This implementation allows Tockchain to verify Ethereum data without trusting an RPC provider.

---

## Dependencies

```c
#include "bridge.h"
```

**External functions used:**
- `eth_keccak256()` - Keccak-256 hashing
- `parse_rlp()`, `rlp_get_item()`, `rlp_list_count()` - RLP parsing (from bridge_rlp.c)
- `tmp_alloc()` - Temporary memory allocation

---

## Constants

```c
#define MAX_MPT_NODES 32  // Maximum proof depth (defined in bridge.h)
```

Ethereum MPT proofs rarely exceed 10-15 nodes; 32 provides ample margin.

---

## Data Structures

### nibbles_struct
```c
struct nibbles_struct {
    uint8_t *nib;      // Array of 4-bit nibbles
    int32_t len;       // Number of nibbles
    int odd;           // Odd-length path flag
    int terminate;     // Leaf node flag
};
```
MPT paths are encoded as nibbles (4-bit values). This structure holds decoded path segments.

### proof_entry
```c
struct proof_entry {
    const uint8_t *buf;  // RLP-encoded node data
    int32_t len;         // Node data length
    uint8_t hash[32];    // Keccak-256 hash of node
};
```
Represents a single node in the MPT proof.

### eth_mpt_proof (from bridge.h)
```c
struct eth_mpt_proof {
    uint8_t root[32];           // Expected Merkle root
    uint8_t key[32];            // Key being proven
    int32_t key_len;            // Key length in bytes
    int32_t num_nodes;          // Number of proof nodes
    uint16_t node_lens[MAX_MPT_NODES];  // Length of each node
    int32_t datalen;            // Total data length
    uint8_t data[];             // Concatenated node data
};
```

### eth_header_t
```c
typedef struct {
    uint8_t blockhash[32];      // Block hash
    uint8_t parenthash[32];     // Parent block hash
    uint8_t txroot[32];         // Transactions root
    uint8_t receiptsroot[32];   // Receipts root
    uint32_t blocknum;          // Block number
    uint32_t timestamp;         // Block timestamp
} eth_header_t;
```

---

## MPT Node Types

Ethereum MPT has three node types:

| Type | Structure | Description |
|------|-----------|-------------|
| **Branch** | 17-element list | 16 children (one per nibble) + value slot |
| **Extension** | 2-element list | Shared path prefix + child reference |
| **Leaf** | 2-element list | Remaining path + value |

### Hex Prefix Encoding

Path segments use hex prefix encoding:
- First nibble flags: `[odd][leaf]`
- If even length: second nibble is padding (0)

| Flag | Meaning |
|------|---------|
| 0x0 | Even extension |
| 0x1 | Odd extension |
| 0x2 | Even leaf |
| 0x3 | Odd leaf |

---

## Function Reference

### Path Decoding

#### `decode_hex_prefix(mem, item, out)` (static)
Decode hex-prefix encoded path from RLP item.

```c
static int32_t decode_hex_prefix(
    tmpmem_t *mem,
    const struct rlp_item *item,
    struct nibbles_struct *out
)
```

**Parameters:**
- `mem`: Temporary memory allocator
- `item`: RLP item containing encoded path
- `out`: Output nibbles structure

**Returns:**
- `0` on success
- `-1` on error (invalid encoding or allocation failure)

**Decoding process:**
1. Extract flag nibble (high 4 bits of first byte)
2. Determine odd/even and leaf/extension from flag
3. Convert remaining bytes to nibble array

---

### Proof Verification

#### `find_node_by_hash(entries, num_proof, h, out_buf, out_len)`
Find a proof node by its hash.

```c
int32_t find_node_by_hash(
    struct proof_entry *entries,
    int32_t num_proof,
    const uint8_t h[32],
    const uint8_t **out_buf,
    int32_t *out_len
)
```

**Returns:** `1` if found, `0` if not found.

**Use case:** When traversing the trie, child references may be hashes (if node > 32 bytes). This function resolves hash references to actual node data.

#### `eth_verify_mpt_proof(mem, root, rlp_key, rlp_key_len, proof, proof_lens, num_proof, value_out, value_len_out)` (static)
Core MPT proof verification algorithm.

```c
static int32_t eth_verify_mpt_proof(
    tmpmem_t *mem,
    const uint8_t root[32],
    const uint8_t *rlp_key,
    int32_t rlp_key_len,
    const uint8_t **proof,
    const int32_t *proof_lens,
    int32_t num_proof,
    uint8_t **value_out,
    int32_t *value_len_out
)
```

**Parameters:**
- `mem`: Temporary memory allocator
- `root`: Expected Merkle root (32 bytes)
- `rlp_key`: Key to verify (will be converted to nibbles)
- `rlp_key_len`: Key length
- `proof`: Array of proof node buffers
- `proof_lens`: Length of each proof node
- `num_proof`: Number of proof nodes
- `value_out`: Output pointer to proven value
- `value_len_out`: Output length of proven value

**Returns:**
- `0` on success (value proven to exist at key)
- Negative on error or proof failure

**Algorithm:**
1. Convert key to nibble array
2. Hash all proof nodes, store in lookup table
3. Start at root hash
4. For each node:
   - If branch: follow nibble path to child
   - If extension: verify path prefix matches, follow to child
   - If leaf: verify remaining path matches, return value
5. Child references may be inline (≤32 bytes) or hash references

**Error codes:**
| Code | Meaning |
|------|---------|
| -1 | NULL parameters or allocation failure |
| -2 | Hashing failure |
| -3 | Invalid node structure |
| -10 | Key not found (empty value) |
| -11 | Hash reference not found in proof |
| -13 | Traversal limit exceeded |

#### `eth_mpt_proof_verify_value(mem, proof, value_out, value_len_out)`
High-level proof verification using eth_mpt_proof structure.

```c
int32_t eth_mpt_proof_verify_value(
    tmpmem_t *mem,
    const struct eth_mpt_proof *proof,
    uint8_t **value_out,
    int32_t *value_len_out
)
```

**Returns:**
- `0` on success
- `-1` if parameters NULL
- `-2` if invalid node count
- `-3` if node lengths don't sum to datalen

---

### Root Recomputation

#### `eth_mpt_recompute_root(proof, mem, out_root, out_value, out_value_len)`
Recompute the Merkle root from proof nodes (bottom-up verification).

```c
int32_t eth_mpt_recompute_root(
    const struct eth_mpt_proof *proof,
    tmpmem_t *mem,
    uint8_t out_root[32],
    const uint8_t **out_value,
    int32_t *out_value_len
)
```

**Parameters:**
- `proof`: MPT proof structure
- `mem`: Temporary memory allocator
- `out_root`: Output computed root (32 bytes)
- `out_value`: Output pointer to leaf value
- `out_value_len`: Output length of leaf value

**Algorithm:**
1. Start from leaf node
2. For each level up:
   - Reconstruct parent node with child hash
   - Hash to get parent's hash
3. Final hash should match expected root

This is more secure than top-down verification because it proves the entire path, not just that nodes exist.

---

### Receipt Parsing

#### `eth_receipt_parse_events(data, len, mem, out_deposits, out_n, out_transfers, out_tn)`
Parse Ethereum receipt logs for deposit and transfer events.

```c
int32_t eth_receipt_parse_events(
    const uint8_t *data,
    int32_t len,
    tmpmem_t *mem,
    receipt_deposit_t **out_deposits,
    int32_t *out_n,
    receipt_transfer_t **out_transfers,
    int32_t *out_tn
)
```

**Parameters:**
- `data`: RLP-encoded receipt data
- `len`: Data length
- `mem`: Temporary memory allocator
- `out_deposits`: Output array of deposit events
- `out_n`: Output number of deposits
- `out_transfers`: Output array of transfer events
- `out_tn`: Output number of transfers

**Event signatures detected:**
- `Deposit(address,address,uint256,uint256)` - Bridge deposits
- `Transfer(address,address,uint256)` - ERC-20 transfers

---

### Transaction Proof

#### `prove_hashandroot(mem, tx_proof, out_txid, root, rp)`
Verify transaction proof and extract transaction ID and deposit info.

```c
int32_t prove_hashandroot(
    tmpmem_t *mem,
    const struct eth_mpt_proof *tx_proof,
    uint8_t out_txid[32],
    uint8_t root[32],
    receipt_deposit_t *rp
)
```

**Parameters:**
- `mem`: Temporary memory allocator
- `tx_proof`: Transaction MPT proof
- `out_txid`: Output transaction ID (32 bytes)
- `root`: Output computed root (32 bytes)
- `rp`: Output deposit info (optional, can be NULL)

**Returns:**
- `0` on success
- `-107` if computed root doesn't match expected
- Other negative values on parse/verification errors

**Process:**
1. Recompute root from proof (bottom-up)
2. Verify computed root matches expected
3. Hash leaf value to get transaction ID
4. Parse receipt events for deposit info

---

### Block Header Parsing

#### `eth_header_from_rlp(rlp, rlp_len, out)`
Parse Ethereum block header from RLP encoding.

```c
int eth_header_from_rlp(
    const uint8_t *rlp,
    size_t rlp_len,
    eth_header_t *out
)
```

**Parameters:**
- `rlp`: RLP-encoded block header
- `rlp_len`: Header length
- `out`: Output header structure

**Returns:**
- `0` on success
- Negative on error

**Fields extracted:**
| Index | Field | Description |
|-------|-------|-------------|
| 0 | parentHash | Previous block hash |
| 4 | transactionsRoot | Merkle root of transactions |
| 5 | receiptsRoot | Merkle root of receipts |
| 8 | number | Block number |
| 11 | timestamp | Block timestamp |

**Note:** Block hash is computed as `keccak256(rlp)`.

---

## Usage Examples

### Verifying a Transaction Receipt

```c
struct eth_mpt_proof proof;
tmpmem_t mem;
uint8_t txid[32], root[32];
receipt_deposit_t deposit;

// Fill proof from RPC response...

int rc = prove_hashandroot(&mem, &proof, txid, root, &deposit);
if (rc == 0) {
    // Transaction proven to exist
    // deposit contains event data if present
    printf("Verified txid: ");
    for (int i = 0; i < 32; i++) printf("%02x", txid[i]);
    printf("\n");
}
```

### Parsing Block Header

```c
uint8_t header_rlp[1024];
size_t header_len;
eth_header_t header;

// Fetch header from RPC...

if (eth_header_from_rlp(header_rlp, header_len, &header) == 0) {
    printf("Block %u at timestamp %u\n", header.blocknum, header.timestamp);
    printf("Receipts root: ");
    for (int i = 0; i < 32; i++) printf("%02x", header.receiptsroot[i]);
    printf("\n");
}
```

---

## Security Considerations

1. **Root verification**: Always verify computed root matches expected root from trusted source (e.g., block header from multiple nodes)

2. **Proof completeness**: Incomplete proofs will fail verification - all nodes from root to leaf must be present

3. **Key canonicalization**: Keys must be properly RLP-encoded before verification

4. **Memory safety**: All allocations use bounded temporary memory; caller must ensure sufficient capacity

5. **Depth limits**: MAX_MPT_NODES (32) prevents stack overflow from malicious deep proofs

---

## Integration Notes

### Relationship to Other Bridge Files

| File | Relationship |
|------|--------------|
| `bridge.h` | Type definitions (eth_mpt_proof, receipt_*_t, etc.) |
| `bridge_rlp.c` | RLP parsing used throughout |
| `bridge_rpc.c` | Fetches proofs from Ethereum nodes |
| `bridge_deposit.c` | Uses proof verification for deposit processing |

### Typical Flow

1. `bridge_rpc.c` fetches block header and receipt proof from Ethereum
2. `eth_header_from_rlp()` parses header, extracts receiptsRoot
3. `prove_hashandroot()` verifies receipt proof against receiptsRoot
4. `eth_receipt_parse_events()` extracts deposit/transfer events
5. `bridge_deposit.c` processes verified deposits into Tockchain
