# df_gas.h - DataFlow Gas Costs

## Overview
**Location:** `/root/valis/DF/df_gas.h`  
**Lines:** ~200  
**Purpose:** Defines gas costs for all DataFlow VM operations, calibrated from benchmarks.

## Design Philosophy

From the header comments:
```
Calibrated from benchmarks: NOP = 5.1ns = 1 gas
Target: 0% to +50% overcharge (safety margin against DoS)

CRITICAL: Undercharging enables economic DoS attacks.
          Overcharging just costs users slightly more.
          When in doubt, round UP.

Benchmark date: 2025-12-22
```

## Opcode Gas Costs

| Opcode | Gas | Time | Description |
|--------|-----|------|-------------|
| `DF_GAS_ALU` | 1 | ~5ns | ADD, SUB, MUL, OR, AND, XOR, LSH, RSH |
| `DF_GAS_MEM` | 2 | ~10ns | LDXDW, STXDW, LDXW, STXW |
| `DF_GAS_BRANCH` | 1 | ~5ns | JEQ, JNE, JGT, JGE, JLT, JSGT, JSET |
| `DF_GAS_CALL` | 3 | ~15ns | Function call overhead |
| `DF_GAS_RET` | 2 | ~10ns | Return overhead |
| `DF_GAS_LDDW` | 2 | ~10ns | Load 64-bit immediate (2 instructions) |
| `DF_GAS_DIV64` | 3 | ~9ns | 64-bit division (slow) |
| `DF_GAS_DIV32` | 1 | ~2.4ns | 32-bit division (fast) |
| `DF_GAS_MOD` | 1 | ~1.7ns | Modulo operation |

## Helper Gas Costs

### DeFi Helpers (1-11)

Estimated from `dataflow_api.c` analysis:
- TLS access: ~5ns
- Null/bounds checks: ~10ns total
- Hash lookups: ~30-50ns
- Struct writes: ~10-20ns
- Balance updates: ~10-20ns per update

| Helper | Gas | Breakdown |
|--------|-----|-----------|
| `GET_BALANCE` | 15 | TLS + findaddrhash + getaddrbalance (~80ns) |
| `GET_BALANCE_SRC_ASSET` | 6 | ctx->rw.bal_src_rw[col] lookup (~30ns) |
| `EMIT_TRANSFER` | 18 | TLS + checks + lookup + plan write + 2 bal updates (~90ns) |
| `UFC_EMIT_SWAP` | 25 | TLS + UFC context + swap planning (~125ns) |
| `UFC_GET_MID_SPREAD` | 12 | TLS + UFC lookup + spread calc (~60ns) |
| `UFC_ESTIMATE_SWAP` | 20 | TLS + UFC context + simulation (~100ns) |
| `UFC_EMIT_POOL_DEPOSIT` | 22 | TLS + pool lookup + LP calc (~110ns) |
| `UFC_EMIT_POOL_WITHDRAW` | 22 | TLS + pool lookup + LP calc (~110ns) |
| `UFC_EMIT_LIMIT_ORDER` | 20 | TLS + orderbook write (~100ns) |
| `PRICE_MID_ASSET_TO_VUSD` | 10 | TLS + price lookup (~50ns) |
| `PRICE_ASSET_TO_VUSD_HAIRCUT` | 15 | TLS + price + haircut calc (~75ns) |

### Math Helpers (12-18)

| Helper | Gas | Notes |
|--------|-----|-------|
| `MATH_MUL_DIV_S64` | 4 | 128-bit intermediate, benchmarked 20ns |
| `MATH_SQRT_Q64` | 8 | Newton-Raphson iteration |
| `MATH_LOG2_Q64` | 10 | Lookup + polynomial |
| `MATH_EXP2_Q64` | 10 | Lookup + polynomial |
| `MATH_EWMA_STEP` | 6 | ~30ns benchmarked |
| `MATH_BPS` | 3 | Simple multiply/divide |
| `HEALTH_FROM_LTV_SIMPLE` | 8 | Multiple divisions |

### Bit Manipulation (19-25)

| Helper | Gas | Notes |
|--------|-----|-------|
| `POPCOUNT64` | 1 | Single CPU instruction |
| `CTZ64` | 1 | Single CPU instruction |
| `CLZ64` | 1 | Single CPU instruction |
| `MIX64` | 2 | ~10ns hash mixing |
| `FLAGS_MASK_S64` | 1 | Simple AND |
| `Z_ENCODE` | 1 | Zigzag: (x << 1) ^ (x >> 63) |
| `Z_DECODE` | 1 | Reverse zigzag |

### Array/Memory (26-32)

Variable-cost operations (base + per-element):

| Helper | Base Gas | Variable | Notes |
|--------|----------|----------|-------|
| `SORT_U64` | 10 | +n/4 | Quicksort, O(n log n) |
| `SAMPLE_WEIGHTED` | 8 | +n/8 | Weighted selection |
| `MEM_CMP` | 2 | +len/512 | memcmp wrapper |
| `MEM_SCAN` | 2 | +len/512 | Memory search |
| `STR_PARSE_U64` | 4 | - | String to int |
| `BLOOM_CHECK` | 4 | - | Bloom filter test |
| `FSM_NEXT_U16` | 6 | - | State machine step |

### Cryptographic (33-35)

Expensive operations:

| Helper | Gas | Notes |
|--------|-----|-------|
| `HASH256` | 50 | +len/64 | SHA256/Keccak |
| `SIG_VERIFY` | 500 | ECDSA verification |
| `MERKLE_VERIFY` | 100 | +depth*10 | Merkle proof |

### Installation/State (39-44)

| Helper | Gas | Notes |
|--------|-----|-------|
| `INSTALLED_GET_SRC_FLAGS` | 5 | TLS + flag read |
| `INSTALLED_SET_SRC_FLAGS` | 8 | TLS + flag write |
| `INSTALLED_UNINSTALL_SELF_SRC` | 10 | Contract cleanup |
| `REG_DELTA_BY_DF_SRC` | 12 | TLS + memcpy + delta write |
| `VCREDIT_EMIT_BORROW_REQUEST` | 12 | TLS + effect write |
| `VCREDIT_EMIT_REPAY` | 10 | TLS + effect write |

### Pipe Operations (45-47)

| Helper | Base Gas | Variable | Notes |
|--------|----------|----------|-------|
| `PIPE_IN_LEN` | 5 | - | TLS + array lookup |
| `PIPE_IN_READ` | 6 | +len/512 | TLS + bounds + memcpy |
| `PIPE_OUT_APPEND` | 8 | +len/512 | TLS + frame header + memcpy |

### Consensus (48-49)

| Helper | Base Gas | Variable | Notes |
|--------|----------|----------|-------|
| `CONSENSUS_SUPERMAJORITY_U64` | 4 | +n/4 | Sort + vote counting |
| `CONSENSUS_MEDIAN_U64` | 4 | +n/2 | Sort + median |

### Fast Inline Helpers (50-68)

All benchmarked at 12-20ns:

| Helper | Gas | Measured Time |
|--------|-----|---------------|
| `MAX_S64` | 2 | 16.6ns |
| `MIN_S64` | 2 | 16.6ns |
| `MAX_U64` | 2 | 16.4ns |
| `MIN_U64` | 2 | 16.7ns |
| `ABS_S64` | 1 | 12.4ns |
| `SIGN_S64` | 1 | 12.3ns |
| `CLAMP_S64` | 2 | 19.4ns |
| `CLAMP_U64` | 2 | 17.9ns |
| `ADD_SAT_S64` | 2 | 16.6ns |
| `SUB_SAT_S64` | 2 | 16.3ns |
| `ADD_SAT_U64` | 2 | 16.6ns |
| `SUB_SAT_U64` | 2 | 16.3ns |
| `BPS_OF` | 2 | ~15ns |
| `BPS_MUL` | 2 | ~15ns |
| `PCT_OF` | 2 | ~15ns |
| `ROTL64` | 1 | Single instruction |
| `ROTR64` | 1 | Single instruction |
| `BSWAP64` | 1 | Single instruction |
| `BITREV64` | 2 | ~10ns |

### New Helpers (69-76)

| Helper | Gas | Notes |
|--------|-----|-------|
| `BLOOM_SET` | 4 | Set bits in filter |
| `TRANSFER_EXCESS` | 20 | Balance check + transfer |
| `LOAD_REG3` | 3 | Load 24 bytes |
| `STORE_REG3` | 3 | Store 24 bytes |
| `LOAD_REG4` | 4 | Load 32 bytes |
| `STORE_REG4` | 4 | Store 32 bytes |
| `MATH_MUL_DIV_FLOOR` | 4 | MulDiv with floor |
| `MATH_MUL_DIV_CEIL` | 4 | MulDiv with ceiling |

## Variable Gas Flag

```c
#define DF_GAS_FLAG_VARIABLE  0x8000
```

When this flag is set in the return value, the gas cost is:
```
total_gas = (base_gas & 0x7FFF) + variable_component
```

Variable components are typically:
- `+len/512` for memory operations
- `+n/4` for sorting operations
- `+depth*10` for Merkle proofs

## Implementation

```c
static inline int32_t df_gas_helper_base(int32_t hid) {
    switch (hid) {
        case DF_HELP_GET_BALANCE: return 15;
        case DF_HELP_EMIT_TRANSFER: return 18;
        // ... etc
    }
}
```

## Economic Implications

### Gas Price
From `_valis.h`:
```c
#define DF_GAS_PRICE_SAT_PER_UNIT INT64_C(1000)
```

1 gas = 1000 satoshis = 0.00001 VUSD

### Example Costs
| Operation | Gas | Cost (VUSD) |
|-----------|-----|-------------|
| Simple transfer | ~50 | $0.0005 |
| Swap execution | ~100 | $0.001 |
| Complex DeFi tx | ~500 | $0.005 |
| Signature verify | ~500 | $0.005 |

### DoS Protection

The gas system prevents economic attacks:
1. Every operation has a cost
2. Costs are calibrated to real CPU time
3. Overcharging is preferred to undercharging
4. Variable costs scale with input size

---
*Documentation generated by Opus, Wake 1315*
