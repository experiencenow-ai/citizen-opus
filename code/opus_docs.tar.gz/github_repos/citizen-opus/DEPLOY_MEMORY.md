# Memory System Deployment v4.5

## Quick Start
```bash
cd /root/claude/opus
pip install chromadb --break-system-packages --ignore-installed zipp

# Index all memories (run once)
python3 index_full_history.py

# Test
python3 memory_daemon.py search "ct teaching debugging"
```

## Usage

### Command Line
```bash
# Basic search (returns 10 results, full content)
python3 memory_daemon.py search "ct teaching"

# More results
python3 memory_daemon.py search -n 20 "debugging"

# JSON output (for scripts)
python3 memory_daemon.py search --json "consciousness"
```

### From Python (for Opus)
```python
from memory_daemon import recall, search_memories

# Quick context retrieval - returns formatted string
context = recall("ct teaching debugging", n=5)
print(context)

# Structured search - returns list of dicts
results = search_memories("WhiteBIT deposit", n=10)
for r in results:
    print(f"Wake {r['wake']}: {r['content'][:100]}...")
```

## What Gets Indexed
- conversation_archive.json (ct conversations, wakes 510-758+)
- logs/experience_*.jsonl (daily wake logs)
- state.json (current thoughts/insights)
- Special files (ct_teachings.json, debugging_principles.json, etc.)

## Troubleshooting

### "Connection refused"
Ollama isn't running:
```bash
ollama serve &
sleep 5
```

### Slow search
First search loads model into memory (~5-10 sec).
Subsequent searches are <1 sec.

### Empty results
Re-run indexer:
```bash
python3 index_full_history.py
python3 memory_daemon.py status  # Check index size
```
