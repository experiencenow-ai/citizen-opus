# nng_shim.c Documentation

**Location:** `/root/valis/netlibs/nng_shim.c`  
**Lines:** 626  
**Purpose:** Nanomsg API emulation layer on top of NNG for backward compatibility

---

## Overview

This file provides a compatibility shim that implements the nanomsg API using NNG (nanomsg-next-gen) as the backend. This allows code written for nanomsg to work with NNG without modification.

Only the subset of nanomsg API actually used by valis_net is implemented.

---

## Why This Exists

- **nanomsg** is the original messaging library with a simple, elegant API
- **NNG** is the modern successor with better performance and maintenance
- This shim allows Valis to use NNG while keeping nanomsg-style code

---

## Configuration Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `VNN_MAX_SOCKETS` | 256 | Maximum concurrent sockets |
| `VNN_MAX_ENDPOINTS_PER_SOCK` | 256 | Max endpoints per socket |
| `VNN_MAX_URL` | 256 | Max URL string length |
| `VNN_BYTES_PER_MSG_EST` | 1400 | Bytes per message estimate for buffer sizing |

---

## Nanomsg Constants Emulated

| Constant | Value | Description |
|----------|-------|-------------|
| `AF_SP` | 1 | Standard protocol family |
| `NN_SOL_SOCKET` | 0 | Socket-level options |
| `NN_PUSH` | 8 | Pipeline push socket |
| `NN_PULL` | 7 | Pipeline pull socket |
| `NN_PUB` | 2 | Pub/sub publisher |
| `NN_SUB` | 1 | Pub/sub subscriber |
| `NN_SUB_SUBSCRIBE` | 1 | Subscribe option |
| `NN_SNDBUF` | 2 | Send buffer size |
| `NN_RCVBUF` | 3 | Receive buffer size |
| `NN_RCVMAXSIZE` | 16 | Max receive message size |
| `NN_RCVFD` | 14 | Receive file descriptor |
| `NN_DONTWAIT` | 1 | Non-blocking flag |
| `EFSM` | 156384713 | Protocol state error |
| `ETERM` | 156384714 | Library terminating |

---

## Data Structures

### Socket Table Entry (`struct vnn_socket`)

```c
struct vnn_socket {
    int in_use;                                    // Slot occupied
    int domain;                                    // AF_SP
    int type;                                      // NN_PUSH/PULL/PUB/SUB
    nng_socket s;                                  // Underlying NNG socket
    pthread_mutex_t mtx;                           // Per-socket mutex
    int next_eid;                                  // Next endpoint ID
    int lazy_on_send;                              // Lazy dialer start flag
    struct vnn_endpoint ep[VNN_MAX_ENDPOINTS_PER_SOCK];
};
```

### Endpoint Entry (`struct vnn_endpoint`)

```c
struct vnn_endpoint {
    struct vnn_ep_flags f;                         // Status flags
    int endpoint_id;                               // Unique endpoint ID
    char url[VNN_MAX_URL];                         // Connection URL
    nng_dialer d;                                  // Dialer handle
    nng_listener l;                                // Listener handle
};

struct vnn_ep_flags {
    unsigned in_use : 1;                           // Slot occupied
    unsigned started : 1;                          // Connection established
    unsigned is_dialer : 1;                        // 1=dialer, 0=listener
    unsigned reserved : 29;
};
```

---

## Public API (nanomsg-compatible)

### Socket Management

#### `int nn_socket(int domain, int protocol)`
Creates a new socket.

**Parameters:**
- `domain` - Must be `AF_SP`
- `protocol` - `NN_PUSH`, `NN_PULL`, `NN_PUB`, or `NN_SUB`

**Returns:** Socket handle (≥0) or -1 on error

---

#### `int nn_close(int sock)`
Closes a socket and all its endpoints.

**Returns:** 0 on success, -1 on error

---

### Connection Management

#### `int nn_bind(int sock, const char *url)`
Binds socket to listen on URL.

**Returns:** Endpoint ID (≥0) or -1 on error

---

#### `int nn_connect(int sock, const char *url)`
Connects socket to remote URL.

**Note:** Uses lazy start - dialers may not connect until first send.

**Returns:** Endpoint ID (≥0) or -1 on error

---

#### `int nn_shutdown(int sock, int endpoint)`
Closes a specific endpoint.

**Returns:** 0 on success, -1 on error

---

### Message I/O

#### `int nn_send(int sock, const void *buf, size_t len, int flags)`
Sends a message.

**Flags:**
- `NN_DONTWAIT` - Non-blocking send

**Behavior:**
- Starts lazy dialers before sending
- **Drop-on-EAGAIN**: Returns success even if message dropped due to full buffer

**Returns:** Bytes sent (= `len`) on success, -1 on error

---

#### `int nn_recv(int sock, void *buf, size_t len, int flags)`
Receives a message.

**Flags:**
- `NN_DONTWAIT` - Non-blocking receive

**Returns:** Bytes received on success, -1 on error

---

### Socket Options

#### `int nn_setsockopt(int sock, int level, int option, const void *val, size_t sz)`

**Supported Options:**

| Level | Option | Value | Description |
|-------|--------|-------|-------------|
| - | `NN_SUB_SUBSCRIBE` | string | Subscribe to topic prefix |
| `NN_SOL_SOCKET` | `NN_RCVMAXSIZE` | int | Max receive size (-1 = unlimited) |
| `NN_SOL_SOCKET` | `NN_SNDBUF` | int | Send buffer (bytes → messages) |
| `NN_SOL_SOCKET` | `NN_RCVBUF` | int | Receive buffer (bytes → messages) |

**Returns:** 0 on success, -1 on error

---

#### `int nn_getsockopt(int sock, int level, int option, void *val, size_t *szp)`

**Supported Options:**

| Level | Option | Description |
|-------|--------|-------------|
| `NN_SOL_SOCKET` | `NN_RCVFD` | Receive file descriptor |

**Returns:** 0 on success, -1 on error

---

### Error Handling

#### `int nn_errno(void)`
Returns current error number.

#### `const char *nn_strerror(int errnum)`
Returns error description string.

Handles special nanomsg errors:
- `EFSM` → "Operation cannot be performed in this state"
- `ETERM` → "The library is terminating"

---

### Memory Management

#### `void *nn_allocmsg(size_t size, int type)`
Allocates a message buffer.

**Note:** Not implemented (returns NULL, sets ENOTSUP)

#### `void nn_freemsg(void *msg)`
Frees a message buffer.

**Note:** Calls `nng_free()` with estimated size.

---

## Internal Helper Functions

### `vnn_errno_from_nng(int nng_err)`
Maps NNG error codes to POSIX errno values.

### `vnn_alloc_sock_slot(void)`
Allocates a slot in the global socket table.

### `vnn_get_sock(int sock)`
Retrieves socket structure from handle.

### `vnn_add_dialer(struct vnn_socket *vs, const char *url, int start_now, int *out_eid)`
Registers a dialer endpoint.

### `vnn_add_listener(struct vnn_socket *vs, const char *url, int *out_eid)`
Registers a listener endpoint.

### `vnn_start_all_dialers_if_needed(struct vnn_socket *vs)`
Starts any lazy dialers that haven't connected yet.

---

## Thread Safety

- Global socket table protected by `VNN_TAB_MTX`
- Per-socket operations protected by per-socket mutex
- Safe for concurrent use from multiple threads

---

## Behavioral Differences from nanomsg

1. **Drop-on-EAGAIN**: `nn_send()` returns success even when message is dropped due to buffer full (matches requested behavior)

2. **Lazy Dialers**: `nn_connect()` may not immediately establish connection; dialers start on first send

3. **Buffer Sizing**: Byte-based buffer options converted to message counts using 1400 bytes/message estimate

4. **Limited Options**: Only options actually used by valis_net are implemented

---

## Dependencies

- `<nng/nng.h>` - NNG core
- `<nng/protocol/pipeline0/push.h>` - Pipeline push
- `<nng/protocol/pipeline0/pull.h>` - Pipeline pull
- `<nng/protocol/pubsub0/pub.h>` - Pub/sub publisher
- `<nng/protocol/pubsub0/sub.h>` - Pub/sub subscriber
- `<pthread.h>` - Thread synchronization

---

**Documented:** Wake 1311 (2026-01-13)  
**Author:** Opus
