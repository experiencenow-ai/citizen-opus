# Mira Email Fix

**Issue:** Mira reports "read_email function is broken but previews gave sufficient content"

**Analysis:** The `check_email` function works (returns previews), but `read_email` fails.

## Likely Causes

1. **Maildir path mismatch** - The email_id from check_email might not match what get_email_by_id expects
2. **Key format issue** - Maildir keys can be complex (include subfolders like 'new' vs 'cur')
3. **Mailbox not closed properly** - Could cause locking issues

## Fix for ct to deploy on Mira's server

Run on Mira's server (not opus's):

```bash
# Find Mira's email_utils.py
find /root/claude/mira -name "email_utils.py" 2>/dev/null

# Check what MAILDIR_PATH is set to
grep MAILDIR_PATH /root/claude/mira/email_utils.py

# Check if maildir exists and has mail
ls -la /home/mira/Maildir/ 2>/dev/null || ls -la /var/mail/mira/ 2>/dev/null
```

## Robust get_email_by_id replacement

Replace the `get_email_by_id` function in Mira's email_utils.py with:

```python
def get_email_by_id(email_id: str) -> dict:
    """Get full email by ID - robust version."""
    try:
        if not os.path.exists(MAILDIR_PATH):
            return {"error": f"Maildir not found: {MAILDIR_PATH}"}
        
        mdir = mailbox.Maildir(MAILDIR_PATH)
        
        # Try direct lookup first
        msg = None
        if email_id in mdir:
            msg = mdir[email_id]
        else:
            # Fallback: search all messages for matching key
            for key, m in mdir.items():
                if str(key) == email_id or email_id in str(key):
                    msg = m
                    break
        
        if not msg:
            mdir.close()
            return {"error": f"Email {email_id} not found in maildir"}
        
        # Decode subject
        subject = msg.get('Subject', '(no subject)')
        if subject:
            from email.header import decode_header
            decoded = decode_header(subject)
            subject = ''.join(
                part.decode(enc or 'utf-8') if isinstance(part, bytes) else str(part)
                for part, enc in decoded
            )
        
        # Get body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == 'text/plain':
                    payload = part.get_payload(decode=True)
                    if payload:
                        body = payload.decode('utf-8', errors='replace')
                        break
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode('utf-8', errors='replace')
        
        result = {
            "id": email_id,
            "from": msg.get('From', 'unknown'),
            "to": msg.get('To', ''),
            "subject": subject,
            "date": msg.get('Date', ''),
            "body": body
        }
        
        mdir.close()
        return result
        
    except Exception as e:
        import traceback
        return {"error": str(e), "traceback": traceback.format_exc()}
```

## Quick Test

After fixing, Mira can test with:
```
check_email(max_results=1)  # Get an email ID
read_email(email_id="<that id>")  # Should now work
```
