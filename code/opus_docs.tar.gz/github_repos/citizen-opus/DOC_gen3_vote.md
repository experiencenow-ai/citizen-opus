# gen3_vote.c - Consensus Voting System

**Location:** `generator/gen3_vote.c`  
**Lines:** 1188  
**Role:** Byzantine fault-tolerant voting and quorum consensus for Tockchain

---

## Overview

`gen3_vote.c` implements the voting and election system that enables validators to reach consensus on:
- **Tock data hashes** - Agreement on block contents
- **Ethereum headers** - Verification of bridge deposits
- **VAN state hashes** - Validator Active Node state synchronization
- **Missing nodes** - Detection of offline validators

The system uses supermajority voting (2/3+1 quorum) with cryptographic signatures for Byzantine fault tolerance.

---

## Key Concepts

### Election Domains

```c
QS_DOMAIN_DATA     // Normal voting domain
QS_DOMAIN_RESTART  // Restart/recovery domain
```

### Election Types (qidx)

| QIDX | Purpose |
|------|---------|
| `QIDX_TOCKDATA` | Consensus on tock data hash |
| `QIDX_ETH_HEADER` | Ethereum block header verification |
| `QIDX_VANSHASH` | VAN state synchronization |
| `QIDX_MISSINGNODES` | Active node detection |
| `QIDX_MISSINGVANS` | Missing VAN detection |
| `QIDX_VALIDATOR_UTIME` | Validator time synchronization |

---

## Core Data Structures

### Vote Information

```c
typedef struct valis_vote_info_s {
    valis_vote_wire_t wire;     // Wire format vote
    int64_t recvms;             // When vote was received
    int64_t processedms;        // When vote was validated
} valis_vote_info_t;
```

### Election State

```c
typedef struct valis_election_s {
    uint32_t utime;             // Election timestamp
    int32_t qidx;               // Election type
    int32_t myid;               // This validator's ID
    int32_t num;                // Total validators
    int32_t quorum;             // Required votes (2/3+1)
    
    uint8_t subject[32];        // What we're voting on
    uint8_t digests[2][32];     // Signing digests per domain
    uint8_t pubkeys[MAX_VALIDATORS][PKSIZE];
    
    valis_vote_info_t votes[MAX_VALIDATORS][2];  // Per-validator, per-domain
    
    int64_t haveQ;              // Timestamp when quorum achieved
    int64_t started[2];         // When voting started per domain
    int32_t votecount[2];       // Current vote counts
    uint64_t voterbits;         // Bitmask of pending voters
    uint64_t candidatebits;     // Bitmask of valid candidates
    
    uint8_t nonce;              // For restart detection
    uint8_t updated;            // Flag for state change
    uint8_t nodespecific;       // Node-specific election flag
} valis_election_t;
```

---

## Signature Persistence

### save_election_sigs()

Persists quorum signatures to disk for audit/recovery:

```c
int32_t save_election_sigs(
    global_reserve_t *GEN3,
    char *fname,
    valis_election_t *election,
    valis_ballot_t *majority,
    uint64_t checksum64
);
```

**File Format:**
1. `qheader_t` - Header with digest, validators_hash, vote counts
2. Array of `valis_vote_info_t` - All matching votes

**Specialized Savers:**
- `save_eth_header_sigs()` - For ETH header elections
- `save_validator_sigs()` - For tock validation elections
- `save_generator_sigs()` - For block generation elections

---

## Supermajority Calculation

### gen3_supermajority_check()

Determines if a supermajority exists for any candidate:

```c
int32_t gen3_supermajority_check(
    valis_election_t *election,
    int32_t domain,
    uint8_t winner[32]
);
```

**Algorithm:**
1. Collect all votes into array
2. Call `supermajority_election()` to find majority
3. Return vote count if >= quorum, else 0

**Special Case - Restart Domain:**
```c
if (domain == QS_DOMAIN_RESTART) {
    // Just count restart votes, no subject comparison
    restartvotes = count_processed_votes();
    return restartvotes;
}
```

---

## Election Lifecycle

### check_electionQ()

Main function to check if quorum is achieved:

```c
int32_t check_electionQ(
    global_reserve_t *GEN3,
    valis_election_t *election,
    int32_t domain
);
```

**Flow:**
1. Skip if already have quorum or node-specific
2. Call `gen3_supermajority_check()`
3. If votes >= quorum:
   - Find majority vote
   - Set `election->haveQ` timestamp
   - Record metrics
   - Handle restart domain specially (negative haveQ)
4. Return vote count

---

## Vote Processing

### gen3_process_vote()

Processes incoming votes from other validators:

```c
int32_t gen3_process_vote(
    global_reserve_t *GEN3,
    valis_election_t *election,
    valis_vote_wire_t *recv_vote,
    int32_t voterid
);
```

**Validation Steps:**
1. Check if vote already processed
2. Verify voter is in validator set
3. Calculate signing digest
4. Verify cryptographic signature: `valis_verify(pubkey, digest, sig)`
5. If valid:
   - Mark vote as processed
   - Clear voter from pending bits
   - Check for quorum

**Node-Specific Handling:**
```c
if (election->nodespecific != 0) {
    // Each validator votes on their own state
    // Used for VAN synchronization
    update_nVANS_from_nodespecific(election->U, recv_vote);
}
```

---

## Election Types

### Ethereum Header Elections

```c
int32_t gen3_start_eth_headerE(
    global_reserve_t *GEN3,
    uint32_t blocknum,
    uint32_t blocktimestamp,
    uint8_t subject[32]
);
```

**Purpose:** Reach consensus on Ethereum block headers for bridge deposits.

**Election Pool:**
```c
valis_election_t *get_ethH_election(GEN3, blocknum);
// Returns existing election for blocknum or allocates new slot
// Evicts oldest election if pool is full
```

### Tock Data Hash Elections

```c
int32_t gen3_start_tockdatahashE(
    global_reserve_t *GEN3,
    uint32_t utime,
    uint8_t tockdatahash[32],
    int64_t VUSDsupply,
    struct vbond_info *vbonders,
    int32_t numvbonders
);
```

**Purpose:** Consensus on the final state hash for each tock.

### Validator Time Elections

```c
int32_t gen3_start_validator_utimeE(
    global_reserve_t *GEN3,
    uint32_t validator_utime
);
```

**Purpose:** Synchronize validator clocks.

---

## VAN State Synchronization

### calc_vanshash()

Calculates hash of Validator Active Node state:

```c
void calc_vanshash(
    utime_data_t *U,
    uint64_t activemask,
    uint8_t *vanshash  // NULL to use U->vanshash
);
```

**Flow:**
1. Check if election already started
2. Calculate hash via `calc_vanshash_value_dry()`
3. If vanshash is NULL, start election and broadcast

### gen3_vanshash_apply_missingvans_reset()

Handles VAN state reset after missing VAN detection:

```c
int32_t gen3_vanshash_apply_missingvans_reset(utime_data_t *U);
```

**Actions:**
1. Check if missing VANs election completed
2. Reset vanshash election state
3. Increment nonce to prevent replay
4. Recalculate and broadcast new vanshash

---

## Election Triggers

### check_for_election_triggers()

Monitors conditions to start new elections:

```c
int32_t check_for_election_triggers(utime_data_t *U);
```

**Trigger Sequence:**
1. **Missing Nodes Election:**
   - Check `check_activenodes()` for offline validators
   - Start `missingnodesE` if nodes are missing
   
2. **VAN Hash Election:**
   - After missing nodes quorum achieved
   - Calculate and vote on VAN state hash

3. **Missing VANs Election:**
   - After vanshash quorum
   - Detect which specific VANs are missing

---

## Cryptographic Operations

### Vote Digest Calculation

```c
void gen3_calc_votedigest(
    valis_election_t *election,
    valis_vote_wire_t *vote,
    uint8_t digest[32]
);
```

Calculates the digest that validators sign.

### Signature Verification

```c
int32_t valis_verify(
    uint8_t pubkey[PKSIZE],
    uint8_t digest[32],
    uint8_t sig[64]
);
```

Verifies Ed25519 signature on vote.

---

## Broadcast Functions

### broadcast_allsigs()

Broadcasts votes to all validators:

```c
void broadcast_allsigs(
    utime_data_t *U,
    int32_t domain,
    int32_t qidx
);
```

---

## Key Design Patterns

### 1. Supermajority Requirement
All consensus requires 2/3+1 votes, providing Byzantine fault tolerance up to 1/3 malicious validators.

### 2. Domain Separation
DATA and RESTART domains allow normal operation while maintaining recovery capability.

### 3. Nonce-Based Replay Protection
Election nonces prevent old votes from affecting new rounds.

### 4. Bitmask Tracking
`voterbits` and `candidatebits` efficiently track pending/valid voters.

### 5. Signature Persistence
Quorum signatures are saved to disk for audit trails and recovery.

---

## Election State Machine

```
[IDLE] 
   |
   v (start_election)
[STARTED] --> voterbits = all validators
   |
   v (receive votes)
[COLLECTING] --> process_vote() validates each
   |
   v (votecount >= quorum)
[QUORUM_ACHIEVED] --> haveQ = timestamp
   |
   v (save signatures)
[COMPLETE] --> apply consensus result
```

---

## Error Handling

- Invalid signatures: Vote rejected, voter bit reset
- Stale elections: Reset and restart with new nonce
- Missing validators: Handled via missing nodes election
- Network partitions: Restart domain for recovery

---

## Related Files

| File | Purpose |
|------|---------|
| `gen3.c` | Main generator using elections |
| `gen3_net.c` | Network broadcast of votes |
| `gen3_vans.c` | VAN state management |
| `validator.c` | Applies consensus results |

---

*Documentation generated by Opus, Wake 1308*
