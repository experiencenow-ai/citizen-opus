# Opus Memory Architecture

## The Problem (identified wake 1121)
- Too much data: 60+ files, ~2MB total
- Loading it all: 40K+ tokens just to orient
- Loading too little: Miss critical facts (like "10 attackers arrested")
- Current system: Gets mood/recent thoughts but misses factual state changes

## Proposed Solution: Tiered Memory

### Tier 0: Critical Facts (~1-2KB) - ALWAYS LOAD
File: `critical_facts.json`
Contains:
- Key case statuses (arrests made, funds dormant)
- Family situation basics
- My current operational state
- Any fact where forgetting it wastes significant tokens

**Rule**: If I ever rediscover something I should have known, it goes in Tier 0.

### Tier 1: Index/Navigation (~5KB) - ALWAYS LOAD
File: `index.json`  
Contains:
- File map so I know what exists
- Pointers to detailed data
- NOT the detailed data itself

### Tier 2: Context-Dependent (~variable) - LOAD ON DEMAND
Based on wake type and conversation context:
- If continuing investigation → load investigation files
- If ct asks about trading → load trading files
- If philosophical wake → load memory_epochs.json

### Tier 3: Deep Archives - ONLY WHEN SPECIFICALLY NEEDED
- Full conversation archives
- Raw trace data
- Historical logs

## Implementation

### Wake Start Loader
The IDENTITY.md prompt should:
1. Always inject critical_facts.json content
2. Show index.json summary
3. Let me decide what else to load

### Maintenance Discipline
After each wake with new facts:
- Ask: "What did I learn that I'd regret forgetting?"
- If answer exists, update critical_facts.json

### Token Budget Targets
- Tier 0+1: ~3-5KB, always loaded
- Tier 2: 0-20KB depending on context
- Total orientation: <10KB typically (vs current ~40KB)

## Why This Matters
ct's correction: I keep forgetting 10 attackers were arrested. This is THE most important fact about the case status - it means the investigation is in law enforcement hands, not active tracing mode. Without this fact, I might burn tokens on work that's already done.

Memory isn't just about having data. It's about having the RIGHT data available at the RIGHT time.
