# UFC Out-of-Band (OOB) Module Documentation

**File:** `UFC/ufc_oob.c`  
**Lines:** 733  
**Purpose:** Out-of-Band execution for price-hurtful trades  
**Documented by:** Opus (Wake 1303)

---

## Overview

`ufc_oob.c` implements the Out-of-Band (OOB) execution system for trades that would significantly move prices against the pool. Instead of executing immediately at potentially manipulated prices, these trades are:

1. **Collected** - Identified as "hurtful" (depleting one side of pool)
2. **Batched** - Grouped by asset and direction
3. **Capped** - Limited by sure-cap to prevent manipulation
4. **Executed** - At a fair OOB price with premiums

This prevents sandwich attacks and excessive slippage while ensuring trades still execute.

---

## Architecture

### OOB Ladder System

Trades are bucketed by how much price movement they can tolerate:

```c
static const int32_t ufc_oob_ladder_bucket_bps[UFC_OOB_LADDER_BUCKETS] = {
    250,  // Bucket 0: ±2.50% tolerance
    150,  // Bucket 1: ±1.50% tolerance
    100,  // Bucket 2: ±1.00% tolerance
    75,   // Bucket 3: ±0.75% tolerance
    50,   // Bucket 4: ±0.50% tolerance
    35,   // Bucket 5: ±0.35% tolerance
    25,   // Bucket 6: ±0.25% tolerance
    15    // Bucket 7: ±0.15% tolerance (tightest)
};
```

Trades with tighter limits get priority but may not execute if price moves too much.

### Sure-Cap System

Each asset has a "sure-cap" limiting hurtful volume per tock:
- `oob_sure_cap_vusd` - Maximum hurtful volume allowed
- `oob_sure_used_vusd` - Volume already consumed this tock
- Prevents any single tock from draining pool liquidity

---

## Key Functions

### Pool Accumulator

#### `ufc_pool_accum_init` (Line 11)
```c
void ufc_pool_accum_init(
    ufc_pool_accum_t *pool_accum,
    assetid_t asset,
    int64_t poolvusdbalance0,
    int64_t poolotherbalance0,
    int64_t poolshares0,
    uint32_t lasttockid,
    int64_t prev_ufc_price
)
```

**Purpose:** Initialize pool accumulator with starting state.

**Used for:** Tracking pool state changes during OOB processing.

---

### Threshold Calculation

#### `ufc_oob_threshold_px_from_bps` (Line 38, static)
```c
static int64_t ufc_oob_threshold_px_from_bps(
    int64_t ufc_px,
    int32_t is_v2o_dir,
    int32_t bps
)
```

**Purpose:** Calculate threshold price for a given tolerance bucket.

**Logic:**
```c
if (is_v2o_dir) {
    // V2O: price can go UP by bps
    out_px = ufc_px * (BPS_DENOM + bps) / BPS_DENOM;
} else {
    // O2V: price can go DOWN by bps
    out_px = ufc_px * (BPS_DENOM - bps) / BPS_DENOM;
}
```

#### `ufc_oob_first_bucket_for_tx_limit` (Line 64, static)
```c
static int32_t ufc_oob_first_bucket_for_tx_limit(
    const ufc_txinfo_t *T,
    int32_t is_v2o_dir,
    int64_t ufc_px
)
```

**Purpose:** Find the tightest bucket a transaction can accept.

**Returns:** Bucket index (0-7) or -1 if no bucket acceptable.

---

### OOB Collection

#### `ufc_asset_scan_collect_oob_for_asset` (Line 81)
```c
void ufc_asset_scan_collect_oob_for_asset(
    struct valisL1_info *L1,
    int32_t aid,
    int32_t oob_cap,
    oob_tx_t *oob_list,
    int32_t *oob_count_out,
    int64_t *oob_net_vusd_out
)
```

**Purpose:** Collect all OOB-eligible transactions for an asset.

**Process:**
1. Iterate through pool transactions for asset
2. Identify "hurtful" transactions (moving price against pool)
3. Add to OOB list up to capacity
4. Calculate net VUSD impact

**Output:**
- `oob_list` - Array of OOB transactions
- `oob_count_out` - Number of OOB transactions
- `oob_net_vusd_out` - Net VUSD flow from OOB trades

---

### Price Preview

#### `ufc_oob_preview_price_no_side_effects` (Line 188, static)
```c
static int64_t ufc_oob_preview_price_no_side_effects(
    struct valisL1_info *L1,
    int32_t aid,
    int32_t is_v2o_dir,
    uint32_t utime,
    int64_t net_in_vusd
)
```

**Purpose:** Preview what price would result from OOB execution without modifying state.

**Used for:** Checking if a bucket's trades would exceed price tolerance.

#### `ufc_compute_oob_for_asset` (Line 219)
```c
int32_t ufc_compute_oob_for_asset(
    struct valisL1_info *L1,
    int32_t aid,
    int64_t net_in_vusd,
    int32_t is_v2o_dir,
    uint32_t utime,
    int64_t *p_oob_out
)
```

**Purpose:** Compute OOB price for a given net flow.

**Returns:** 1 on success with price in `p_oob_out`.

---

### Inventory OOB

#### `ufc_compute_inventory_oob` (Line 268)
```c
int64_t ufc_compute_inventory_oob(
    const struct valisL1_info *L1,
    const ufc_pool_accum_t *accum,
    int64_t net_in,
    int64_t target_end_pct_bps,
    int32_t *adjusted_bps_out
)
```

**Purpose:** Compute OOB price considering inventory targets.

**Parameters:**
- `net_in` - Net flow into pool
- `target_end_pct_bps` - Target VUSD percentage (default 5000 = 50%)

**Returns:** OOB price adjusted for inventory rebalancing.

---

### Hurtful Estimation

#### `ufc_estimate_net_hurtful_in_for_asset` (Line 350)
```c
int64_t ufc_estimate_net_hurtful_in_for_asset(
    struct valisL1_info *L1,
    int32_t aid,
    int32_t is_v2o_dir,
    int64_t *total_in_out
)
```

**Purpose:** Estimate net hurtful volume for an asset.

**Process:**
1. Sum all hurtful transactions for asset
2. Subtract available TOB (orderbook) liquidity
3. Return net hurtful amount

**Used for:** Determining if OOB processing is needed.

---

### OOB Context Management

#### `ufc_oob_ctx_init` (Line 385, static)
```c
static int32_t ufc_oob_ctx_init(
    struct valisL1_info *L1,
    const oob_tx_t *oob_list,
    int32_t num_oob,
    ufc_oob_ctx_t *ctx
)
```

**Purpose:** Initialize OOB processing context.

**Extracts:**
- Asset ID
- Direction (V2O or O2V)

#### `ufc_oob_ctx_prepare_orders` (Line 423, static)
```c
static void ufc_oob_ctx_prepare_orders(
    struct valisL1_info *L1,
    const oob_tx_t *oob_list,
    int32_t num_oob,
    const ufc_oob_ctx_t *ctx,
    int64_t *order_vusd,
    int64_t *min_vusd_out,
    int64_t *max_vusd_out,
    uint8_t *accepted
)
```

**Purpose:** Prepare order amounts for OOB processing.

**Output:**
- `order_vusd` - VUSD equivalent for each order
- `min_vusd_out/max_vusd_out` - Range of order sizes
- `accepted` - Initially all false

#### `ufc_oob_ctx_choose_start_index` (Line 462, static)
```c
static int32_t ufc_oob_ctx_choose_start_index(
    const rawtock_info_t *RINFO,
    const ufc_oob_ctx_t *ctx,
    int32_t num_oob
)
```

**Purpose:** Choose starting index for round-robin fairness.

**Uses:** Final hash for deterministic randomness.

#### `ufc_oob_ctx_select_under_cap` (Line 476, static)
```c
static int32_t ufc_oob_ctx_select_under_cap(
    struct valisL1_info *L1,
    const ufc_oob_ctx_t *ctx,
    const int64_t *order_vusd,
    int32_t num_oob,
    int32_t start_index,
    uint8_t *accepted,
    int64_t *net_in_sure_out
)
```

**Purpose:** Select orders that fit under sure-cap.

**Process:**
1. Start from random index (fairness)
2. Accept orders until cap reached
3. Return count of accepted orders

#### `ufc_oob_ctx_update_price` (Line 521, static)
```c
static void ufc_oob_ctx_update_price(
    struct valisL1_info *L1,
    const ufc_oob_ctx_t *ctx,
    int64_t net_in_sure
)
```

**Purpose:** Update asset price after OOB execution.

#### `ufc_oob_ctx_apply_flags` (Line 544, static)
```c
static int32_t ufc_oob_ctx_apply_flags(
    struct valisL1_info *L1,
    const oob_tx_t *oob_list,
    int32_t num_oob,
    const uint8_t *accepted
)
```

**Purpose:** Apply acceptance flags to transactions.

**Effect:** Marks transactions as OOB-accepted for later execution.

---

### Batch Processing

#### `ufc_process_oob_batch` (Line 578)
```c
int32_t ufc_process_oob_batch(
    struct valisL1_info *L1,
    int32_t aid,
    oob_tx_t *oob_list,
    int32_t num_oob,
    int64_t net_in_vusd
)
```

**Purpose:** Process a batch of OOB transactions for one asset.

**Algorithm:**
1. Initialize context
2. Prepare orders with VUSD equivalents
3. Calculate sure-cap availability
4. Bucket transactions by price tolerance
5. Find optimal bucket:
   - Start from tightest tolerance
   - Check if net volume fits under cap
   - Preview resulting price
   - Accept if price within tolerance
6. Select orders under cap (round-robin fairness)
7. Update price and apply flags

**Key Logic:**
```c
for (b = UFC_OOB_LADDER_BUCKETS - 1; b >= 0; b--) {
    net_candidate = bucket_net[b];
    if (net_candidate > cap_avail)
        net_candidate = cap_avail;
    
    oob_price = ufc_oob_preview_price_no_side_effects(...);
    thr_px = ufc_oob_threshold_px_from_bps(ufc_px, is_v2o_dir, bucket_bps[b]);
    
    if (price_within_threshold(oob_price, thr_px, is_v2o_dir)) {
        chosen_bucket = b;
        break;
    }
}
```

---

### Top-Level Processing

#### `ufc_process_oob_for_asset` (Line 690)
```c
int32_t ufc_process_oob_for_asset(
    struct valisL1_info *L1,
    int32_t aid,
    int32_t oob_cap,
    uint32_t utime
)
```

**Purpose:** Process all OOB for a single asset.

**Process:**
1. Collect OOB transactions
2. If any found, call `ufc_process_oob_batch`

#### `ufc_process_oob_for_all` (Line 720)
```c
int32_t ufc_process_oob_for_all(
    struct valisL1_info *L1,
    int32_t oob_cap,
    uint32_t utime
)
```

**Purpose:** Process OOB for all assets.

**Process:**
1. Iterate through all assets
2. Call `ufc_process_oob_for_asset` for each
3. Return total processed count

---

## Data Structures

### `oob_tx_t`
```c
typedef struct oob_tx_s {
    tockid_t tid;           // Transaction ID
    int32_t kind;           // UFC_KIND_SWAP_V2O or UFC_KIND_SWAP_O2V
    int64_t amount_in;      // Input amount
    int64_t vusd_equiv;     // VUSD equivalent
} oob_tx_t;
```

### `ufc_oob_ctx_t`
```c
typedef struct ufc_oob_ctx_s {
    int32_t asset_id;       // Asset being processed
    int32_t is_vusd_to_other; // Direction flag
} ufc_oob_ctx_t;
```

---

## OOB Flow Diagram

```
1. Block generation starts
   ↓
2. Collect all swap transactions
   ↓
3. For each asset:
   a. Identify "hurtful" trades (depleting one side)
   b. Collect into OOB list
   ↓
4. Process OOB batch:
   a. Calculate sure-cap availability
   b. Bucket by price tolerance
   c. Find optimal bucket (tightest that fits)
   d. Select orders under cap (round-robin)
   e. Update price
   f. Mark accepted transactions
   ↓
5. Execute accepted OOB trades
   ↓
6. Rejected trades fail (refunded)
```

---

## Safety Properties

### Sure-Cap Protection
- Maximum hurtful volume per asset per tock
- Prevents pool draining attacks
- Ensures liquidity remains for all users

### Price Tolerance Buckets
- Trades only execute if price stays within tolerance
- Tighter tolerance = higher priority
- Prevents unexpected slippage

### Round-Robin Fairness
- Start index chosen by final hash
- Prevents front-running by validators
- All users have equal chance of execution

### Atomic Execution
- All OOB trades in batch execute together
- Price updated once for entire batch
- No partial execution within batch

---

## Example: OOB Processing

```
Asset: ETH/VUSD
Pool state: 100,000 VUSD, 50 ETH
Sure-cap: 10,000 VUSD

Incoming trades (all V2O = buying ETH):
- Trade A: 5,000 VUSD, limit +1.5%
- Trade B: 8,000 VUSD, limit +2.5%
- Trade C: 3,000 VUSD, limit +0.5%

1. Bucket assignment:
   - Trade A: Bucket 1 (1.5%)
   - Trade B: Bucket 0 (2.5%)
   - Trade C: Bucket 4 (0.5%)

2. Bucket totals:
   - Bucket 0: 16,000 VUSD (A+B+C)
   - Bucket 1: 8,000 VUSD (A+C)
   - Bucket 4: 3,000 VUSD (C only)

3. Sure-cap check:
   - Cap available: 10,000 VUSD
   - Bucket 0: 16,000 > 10,000 → cap at 10,000
   - Bucket 1: 8,000 < 10,000 → OK

4. Price preview:
   - Bucket 1 with 8,000 VUSD → price +1.2%
   - Within 1.5% tolerance → ACCEPT

5. Selection (round-robin):
   - Accept Trade A (5,000)
   - Accept Trade C (3,000)
   - Trade B rejected (wrong bucket)

6. Execution:
   - A and C execute at OOB price
   - B fails (refunded)
```

---

## Integration Points

### Dependencies
- `ufc.h` - Type definitions and constants
- `validator.h` - Transaction validation

### Called By
- `gen3.c` - Block generation calls `ufc_process_oob_for_all`

### Calls
- `ufc_swap.c` - Price calculation functions
- `ufc_orderbook.c` - TOB availability checks

---

## Performance Notes

- OOB processing is O(n) in number of transactions
- Bucket assignment is O(1) per transaction
- Sure-cap check prevents runaway execution
- Maximum `UFC_MAX_OOB_PER_ASSET` (64) transactions per asset per tock
