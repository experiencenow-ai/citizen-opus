# UFC Orderbook Module Documentation

**File:** `UFC/ufc_orderbook.c`  
**Lines:** 1068  
**Purpose:** Limit order book management and matching for UFC DEX  
**Documented by:** Opus (Wake 1303)

---

## Overview

`ufc_orderbook.c` implements the limit order book (LOB) component of Tockchain's hybrid AMM+LOB DEX. It manages:

1. **Top-of-Book (TOB) Tracking** - Best bid/ask prices per asset
2. **Order Matching** - Filling taker orders against maker orders
3. **Premium Calculation** - Extracting premiums for VNET when orders cross spread
4. **Price Discovery** - Combining pool, orderbook, and oracle prices
5. **Maker Registration** - Tracking active market makers

The orderbook complements the AMM pools - orders can execute against either the pool or standing limit orders, whichever offers a better price.

---

## Architecture

### Per-Asset Orderbook

Each asset has its own orderbook state in `ufc_assetinfo_t`:
- `tob_entries[]` - Array of top-of-book entries
- `tob_count` - Number of active entries
- `tob_cap` - Maximum entries (default: `UFC_MAX_TOB_LEVELS_PER_ASSET`)

### Order Priority

Orders are prioritized by:
1. **Price** - Better price wins
2. **Age** - Older orders have priority (with decay)
3. **This-tock bonus** - Orders created this tock get priority boost

---

## Key Functions

### Order Fill Calculation

#### `ufc_compute_order_fill_core` (Line 11)
```c
int64_t ufc_compute_order_fill_core(
    const struct ordertx *order,
    int64_t makerbalance,
    int64_t *takerspentp,
    int32_t entropy_bit
)
```

**Purpose:** Calculate how much of an order can be filled given maker's balance.

**Parameters:**
- `order` - The limit order to fill
- `makerbalance` - Maker's available balance
- `takerspentp` - Output: amount taker will spend
- `entropy_bit` - Random bit for tie-breaking (unused currently)

**Returns:** Amount maker will provide (maker_filled).

**Logic:**
```c
if (order->makerasset.aid != ASSET_VUSD) {
    // Maker sells OTHER, receives VUSD
    // order->amount is VUSD spend limit
    max_vusd = makerbalance * price / SATOSHIS;
    takerspent = min(order->amount, max_vusd);
    makerfilled = takerspent * SATOSHIS / price;
} else {
    // Maker sells VUSD, receives OTHER
    // order->amount is OTHER amount limit
    max_other = makerbalance * SATOSHIS / price;
    takerspent = min(order->amount, max_other);
    makerfilled = ceil(takerspent * price / SATOSHIS);
}
```

---

### Trade Recording

#### `ufc_record_taker_trade_signal` (Line 76)
```c
void ufc_record_taker_trade_signal(
    struct valisL1_info *L1,
    assetid_t asset,
    int32_t is_bid,
    int64_t price_sat,
    int64_t trade_vusd
)
```

**Purpose:** Record a trade for price discovery and TOB updates.

**Effect:** Updates the asset's trade history for weighted price calculation.

#### `ufc_record_taker_trade_as_tob` (Line 111, static)
```c
static void ufc_record_taker_trade_as_tob(...)
```

**Purpose:** Record trade as a TOB entry for future reference.

---

### TOB Management

#### `ufc_tob_refresh_capacity_vusd` (Line 116)
```c
int64_t ufc_tob_refresh_capacity_vusd(
    struct valisL1_info *L1,
    const ufc_tob_entry_t *entry,
    struct addrhashentry **maker_entry_out
)
```

**Purpose:** Get current capacity of a TOB entry.

**Returns:** VUSD equivalent capacity of the order.

**Process:**
1. Look up maker's current balance
2. Convert to VUSD equivalent at order's price
3. Return maker's address entry for transfers

#### `ufc_ob_compute_order_amount` (Line 156)
```c
int64_t ufc_ob_compute_order_amount(
    int32_t is_bid,
    int64_t remain_amt,
    int64_t cap_vusd,
    int64_t price_sat
)
```

**Purpose:** Compute order amount for a TOB fill.

**Parameters:**
- `is_bid` - 1 if taker is buying (hitting asks)
- `remain_amt` - Remaining amount to fill
- `cap_vusd` - Maker's capacity in VUSD
- `price_sat` - Order price

**Returns:** Amount to fill from this order.

#### `ufc_build_taker_ordertx_for_tob_fill` (Line 177)
```c
void ufc_build_taker_ordertx_for_tob_fill(
    const ufc_txdec_t *dec,
    const ufc_tob_entry_t *tob,
    int32_t is_bid,
    int64_t order_amt,
    struct ordertx *ord
)
```

**Purpose:** Build an ordertx structure for filling against a TOB entry.

---

### Premium Calculation

#### `ufc_calculate_v2o_ob_premium_vusd` (Line 203, static)
```c
static int64_t ufc_calculate_v2o_ob_premium_vusd(
    const ufc_info_t *ufc,
    int32_t aid,
    int32_t is_vusd_to_other,
    const struct ordertx *ord,
    int64_t maker_filled,
    int64_t taker_spent,
    const int64_t *remain_amt_in_out
)
```

**Purpose:** Calculate premium for VUSD→Other orderbook fills.

**Premium Logic:**
- If order price is better than reference price, premium is extracted
- Premium goes to VNET pool (network token holders)
- Ensures market makers can't extract all spread

#### `ufc_calculate_o2v_ob_premium_other` (Line 253, static)
```c
static int64_t ufc_calculate_o2v_ob_premium_other(...)
```

**Purpose:** Calculate premium for Other→VUSD orderbook fills.

---

### Order Execution

#### `ufc_apply_tob_fill_and_transfer` (Line 379)
```c
int32_t ufc_apply_tob_fill_and_transfer(
    struct valisL1_info *L1,
    struct addrhashentry *maker_entry,
    struct addrhashentry *taker_entry,
    const struct ordertx *ord,
    tockid_t tock_id,
    int32_t is_bid,
    assetid_t pool_asset,
    int64_t *remain_amt_in_out,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap
)
```

**Purpose:** Execute a fill against a TOB entry and add transfers to plan.

**Process:**
1. Get maker's current balance
2. Calculate fill amounts using `ufc_compute_order_fill_core`
3. Calculate and apply premiums
4. Add transfers to plan:
   - Maker → Taker: maker's asset
   - Taker → Maker: taker's asset
   - Maker → VNET: premium (if applicable)
5. Update remaining amount
6. Record trade signal

**Returns:** 1 on success, negative on error.

---

### Maker Registration

#### `ufc_notify_validator_makerpub` (Line 447)
```c
void ufc_notify_validator_makerpub(
    struct valisL1_info *L1,
    int32_t is_bid,
    assetid_t asset,
    int64_t VUSDprice,
    int64_t fundsbalance,
    const uint8_t makerpub[PKSIZE],
    const uint8_t fundspub[PKSIZE],
    uint32_t now_utime,
    uint32_t lastutime
)
```

**Purpose:** Register a maker's order in the TOB.

**Parameters:**
- `is_bid` - 1 for bid (buying), 0 for ask (selling)
- `VUSDprice` - Price in satoshis per unit
- `fundsbalance` - Maker's available balance
- `makerpub/fundspub` - Maker's public keys
- `now_utime/lastutime` - Timestamps for age calculation

**Effect:** Adds entry to asset's TOB array for matching.

#### `ufc_maker_vusd_capacity` (Line 495)
```c
int64_t ufc_maker_vusd_capacity(
    const struct makerpub_info *info,
    int32_t is_bid
)
```

**Purpose:** Calculate maker's capacity in VUSD terms.

#### `ufc_maker_better_than` (Line 509)
```c
int32_t ufc_maker_better_than(
    const struct makerpub_info *a,
    int64_t a_vusd,
    const struct makerpub_info *b,
    int64_t b_vusd,
    int32_t is_bid
)
```

**Purpose:** Compare two makers for priority ordering.

**Comparison:**
1. Better price wins
2. If same price, larger capacity wins
3. If same capacity, older order wins

---

### TOB Matching

#### `ufc_try_fill_from_tob` (Line ~600)
```c
int64_t ufc_try_fill_from_tob(
    struct valisL1_info *L1,
    const ufc_txdec_t *dec,
    int64_t remain_amt,
    struct addrhashentry *funds_entry,
    tockid_t tock_id,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap
)
```

**Purpose:** Try to fill a taker order from the orderbook.

**Process:**
1. Determine target price (pool price or better)
2. Iterate through TOB entries
3. For each entry with acceptable price:
   - Check capacity
   - Build order
   - Execute fill
   - Update remaining amount
4. Return remaining unfilled amount

**Key Logic:**
```c
for each TOB entry E:
    if (is_vusd_to_other && E->price_sat <= target_px) ||
       (!is_vusd_to_other && E->price_sat >= target_px):
        // Price is acceptable
        cap_vusd = ufc_tob_refresh_capacity_vusd(L1, E, &maker_entry);
        order_amt = ufc_ob_compute_order_amount(is_bid, remain_amt, cap_vusd, E->price_sat);
        ufc_apply_tob_fill_and_transfer(...);
        remain_amt -= filled;
```

---

### Price Discovery

#### `ufc_ob_compute_pool_tvl_and_price` (static)
```c
static void ufc_ob_compute_pool_tvl_and_price(
    struct valisL1_info *L1,
    ufc_pool_accum_t *pool_accum,
    int64_t prev_px,
    int64_t bpf_px,
    int64_t p_ob,
    int64_t *pool_px_out,
    int64_t *tvl_vusd_out
)
```

**Purpose:** Calculate pool price and TVL.

**Price Fallback Chain:**
1. Pool price (from reserves)
2. Previous tock price
3. BPF (oracle) price
4. Orderbook price
5. Default: 1 SATOSHI

#### `ufc_ob_compute_liquidity_weights` (static)
```c
static void ufc_ob_compute_liquidity_weights(
    struct valisL1_info *L1,
    int32_t tocklag,
    int64_t tvl_vusd,
    int64_t ob_vusd,
    int64_t bpf_px,
    int32_t bpf_conf_bps,
    int32_t *w_pool_bps,
    int32_t *w_ob_bps,
    int32_t *w_bpf_bps,
    int32_t *w_prev_bps
)
```

**Purpose:** Calculate weights for price sources.

**Weights Based On:**
- Pool TVL → `w_pool_bps`
- Previous price → `w_prev_bps`
- Orderbook liquidity → `w_ob_bps` (capped at TVL/10)
- Oracle confidence → `w_bpf_bps`

**Constraint:** Weights sum to `BPS_DENOM` (10000).

---

## Data Structures

### `ufc_tob_entry_t`
```c
typedef struct ufc_tob_entry_s {
    int64_t *maker_balance_ptr;  // Direct pointer to maker's balance
    assetid_t asset;
    int64_t price_sat;           // Price in satoshis
    int64_t amount_vusd;         // Order size in VUSD
    uint32_t age_sec;            // Order age for priority decay
    uint8_t is_bid;              // 1=bid, 0=ask
    uint8_t created_this_tock;   // Priority bonus flag
    uint8_t is_trade;            // Trade vs standing order
} ufc_tob_entry_t;
```

### `ordertx`
```c
struct ordertx {
    assetid_t makerasset;   // Asset maker provides
    assetid_t takerasset;   // Asset maker receives
    int64_t VUSDprice;      // Price in satoshis
    int64_t amount;         // Order amount
    // ... other fields
};
```

---

## Premium System

The orderbook extracts premiums when orders cross the spread:

### V2O (VUSD → Other) Premium
- If maker's ask price < reference price
- Premium = (ref_price - ask_price) * amount
- Paid in VUSD to VNET pool

### O2V (Other → VUSD) Premium
- If maker's bid price > reference price
- Premium = (bid_price - ref_price) * amount
- Paid in Other asset to VNET pool

### Reference Price Selection
```c
ref_px = ufc_ob_choose_ref_px(A, ord);
// Uses: pool price, previous price, or order price
```

---

## Integration Points

### Dependencies
- `ufc.h` - Type definitions and constants

### Called By
- `ufc_swap.c` - `ufc_try_fill_from_tob` during swap execution
- `validator.c` - `ufc_notify_validator_makerpub` for maker registration

### Calls
- `ufc_swap.c` - `ufc_tx_plan_add_transfer` for transfers

---

## Order Matching Flow

```
1. Taker submits swap (e.g., 1000 VUSD → ETH)

2. Check orderbook for asks at/below pool price:
   - Ask 1: 100 ETH @ 0.0009 VUSD/sat (better than pool)
   - Ask 2: 50 ETH @ 0.00095 VUSD/sat (better than pool)

3. Fill against orderbook:
   - Fill Ask 1: 100 ETH for 900 VUSD
   - Fill Ask 2: 50 ETH for 47.5 VUSD
   - Extract premiums for VNET

4. Remaining 52.5 VUSD goes to AMM pool

5. All transfers committed atomically
```

---

## Safety Properties

1. **Balance Validation**
   - Maker balance checked before fill
   - Fill amount capped by actual balance

2. **Price Protection**
   - Only fills at acceptable prices
   - Premium extraction prevents manipulation

3. **Dust Prevention**
   - Minimum lot sizes enforced
   - Small remainders handled gracefully

4. **Atomic Execution**
   - All fills accumulated in plan
   - Single commit or full rollback

---

## Performance Considerations

- TOB entries limited per asset (`UFC_MAX_TOB_LEVELS_PER_ASSET`)
- Orderbook liquidity capped at TVL/10 for price weighting
- Age-based priority decay reduces stale order impact
- Quota system limits orderbook fills per tock
