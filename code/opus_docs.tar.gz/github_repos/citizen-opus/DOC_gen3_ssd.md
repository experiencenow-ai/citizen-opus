# gen3_ssd.c Documentation

**Location:** `/root/valis/generator/gen3_ssd.c`  
**Lines:** 2,037  
**Purpose:** SSD storage for nodevans and rescue header operations  
**Documented:** Wake 1316 (2026-01-13)

---

## Overview

The SSD module handles **persistent storage of validator transaction data (nodevans)** and implements a **rescue system** for recovering missing data from peer validators. It provides both generator-side and validator-side functionality for data persistence and recovery.

### Key Responsibilities

1. **Nodevans Storage**: Write complete and partial validator transaction sets to disk
2. **Rescue Headers**: Create and verify rescue files with quorum proofs
3. **Data Recovery**: Fetch missing data from peers and reconstruct complete state
4. **Directory Management**: Track partial vans locations across validators

---

## Constants and Magic Numbers

```c
#define SSD_NODEVANS_MAGIC        0xabcdU
#define SSD_NODEVANS_VERSION      2
#define SSD_NODEVANS_FLAGS_VANS   0    // Complete vans file
#define SSD_NODEVANS_FLAGS_PVANS  1    // Partial vans file
#define SSD_NODEVANS_FLAGS_PDIR   2    // Partial directory file

#define SSD_RESCUE_PROOF_MAGIC    0x56535046U  // 'VSPF'
#define SSD_RESCUE_PROOF_VERSION  1

#define SSD_RANGE_MAX_GAP         256U
#define SSD_RANGE_MAX_BYTES       (1U<<20)     // 1MB max range
#define SSD_RANGE_MAX_REDUND_PCT  10U
#define SSD_RANGE_REDUND_BONUS    512U
```

---

## Data Structures

### ssd_bufref_t - Buffer Reference Chain

```c
typedef struct ssd_bufref_s {
    uint8_t *buf;
    size_t fsize;
    struct ssd_bufref_s *next;
} ssd_bufref_t;
```

Linked list for tracking allocated buffers during rescue operations.

### ssd_pvans_origin_state_t - Partial Vans State

```c
typedef struct ssd_pvans_origin_state_s {
    uint32_t utime_tag;
    uint32_t scanned_upto;
    uint32_t off[MAX_NODEVANS_PERUTIME];
    uint32_t len[MAX_NODEVANS_PERUTIME];
} ssd_pvans_origin_state_t;
```

Tracks scanning state for partial vans files per origin node.

### ssd_needvan_t - Missing Van Descriptor

```c
typedef struct ssd_needvan_s {
    uint16_t origin_nodeid;
    uint16_t rawvanid;
    uint16_t is_vip;
    uint16_t pad;
    uint8_t vantxidhash[32];
    uint8_t cand_n;                    // Number of candidates
    uint8_t cand_writer[8];            // Up to 8 candidate writers
    uint32_t cand_offset[8];
    uint32_t cand_len[8];
    uint8_t chosen_writer;
    uint8_t chosen_set;
    uint16_t pad2;
    uint32_t chosen_offset;
    uint32_t chosen_len;
} ssd_needvan_t;
```

Describes a missing van and tracks candidate sources for recovery.

### ssd_fetch_item_t - Fetch Request

```c
typedef struct ssd_fetch_item_s {
    uint32_t offset;
    uint32_t len;
    int32_t need_index;
} ssd_fetch_item_t;
```

Individual fetch request for range-based data retrieval.

---

## File Naming Functions

### ssd_base_fname

```c
static void ssd_base_fname(char fname[512], uint32_t utime);
```

Gets base filename for a utime (delegates to `rawtock_fname`).

### ssd_nodevans_fname

```c
static void ssd_nodevans_fname(char fname[512], uint32_t utime, 
                                int32_t origin_nodeid, int32_t partial);
```

Generates nodevans filename:
- Full vans: `{base}.node{NN}.vans`
- Partial vans: `{base}.node{NN}.pvans`

### ssd_pvans_dir_fname

```c
void ssd_pvans_dir_fname(char fname[512], uint32_t utime, int32_t writer_nodeid);
```

Generates partial vans directory filename: `{base}.node{NN}.pdir`

### ssd_rescue_fname

```c
void ssd_rescue_fname(char fname[512], uint32_t utime, int32_t writer_nodeid);
```

Generates rescue file name: `{base}.node{NN}.rescue`

---

## Atomic File Operations

### ssd_atomic_open_tmp

```c
static int32_t ssd_atomic_open_tmp(const char *final_fname, 
                                    char tmp_fname[512], FILE **fpp);
```

Opens a temporary file for atomic write operations. The temp file is renamed to final name on successful close.

### ssd_atomic_close_tmp

```c
static int32_t ssd_atomic_close_tmp(FILE **fpp, const char *tmp_fname, 
                                     const char *final_fname, int32_t do_fsync);
```

Closes temp file and atomically renames to final destination:
- Optional fsync for durability
- Removes temp file on failure

---

## Nodevans Writing Functions

### gen3_ssd_write_nodevans_full

```c
int32_t gen3_ssd_write_nodevans_full(utime_data_t *U, int32_t origin_nodeid);
```

Writes a complete nodevans file for a specific origin node:

1. Validates all vans are present (`validated_allvans`)
2. Checks if file already exists and is valid
3. Creates header with magic, version, flags
4. Writes index of all vans with offsets
5. Writes van data with padding
6. Atomically commits file

**File Format:**
```
[nodevans_ssd_header_t]
[nodevans_ssd_vanidx_t × numvans]
[van_data_0 + padding]
[van_data_1 + padding]
...
```

### gen3_ssd_write_nodevans_partial

```c
int32_t gen3_ssd_write_nodevans_partial(utime_data_t *U, int32_t origin_nodeid);
```

Writes partial vans data (for incomplete sets).

### gen3_ssd_write_pvans_directory

```c
int32_t gen3_ssd_write_pvans_directory(utime_data_t *U);
```

Writes a directory file listing all partial vans this node has:
- Used by peers to locate data for rescue operations
- Contains offsets and lengths for each partial van

### gen3_ssd_maybe_write_self_vans

```c
int32_t gen3_ssd_maybe_write_self_vans(utime_data_t *U);
```

Conditionally writes this node's own vans to disk.

### gen3_ssd_write_pvans_for_peers

```c
int32_t gen3_ssd_write_pvans_for_peers(utime_data_t *U);
```

Writes partial vans that peers might need for rescue.

### gen3_ssd_dump_pvans_for_all

```c
int32_t gen3_ssd_dump_pvans_for_all(utime_data_t *U);
```

Dumps all partial vans for debugging/recovery.

---

## Rescue System

### Quorum Proof Building

```c
static int32_t ssd_build_proof_from_election(valis_election_t *E, 
                                              uint8_t expected_subject[32], 
                                              ssd_quorum_proof_t *proof);
```

Builds a quorum proof from an election result:
- Collects signatures from voters
- Verifies subject matches expected value
- Creates compact proof for verification

### ssd_write_rescue_file

```c
static int32_t ssd_write_rescue_file(utime_data_t *U, 
                                      nodevans_rescue_header_t *RH,
                                      ssd_quorum_proof_t *missingnodes_proof,
                                      ssd_quorum_proof_t *missingvans_proof,
                                      ssd_quorum_proof_t *vanshash_proof);
```

Writes a rescue file containing:
- Rescue header with validator state
- Quorum proofs for missing nodes/vans decisions
- Vanshash consensus proof

### gen3_ssd_write_rescue_header

```c
int32_t gen3_ssd_write_rescue_header(utime_data_t *U);
```

Main entry point for writing rescue headers:

1. Checks vanshash election is complete
2. Builds rescue header with:
   - Validator set hash
   - Active nodes/vans bitmasks
   - Per-node van counts and hashes
3. Creates quorum proofs for consensus decisions
4. Writes rescue file

---

## Data Recovery Functions

### ssd_collect_need_list

```c
static int32_t ssd_collect_need_list(utime_data_t *U, 
                                      nodevans_rescue_header_t *RH,
                                      uint64_t neededbits,
                                      int32_t *rawvan_to_need,
                                      ssd_needvan_t *needvans,
                                      int32_t *need_order,
                                      int32_t need_cap,
                                      int32_t *need_count_out);
```

Builds list of missing vans that need recovery:
- Scans all nodes for missing data
- Creates need descriptors with van metadata
- Prioritizes by importance

### ssd_collect_candidates_from_pdirs

```c
static int32_t ssd_collect_candidates_from_pdirs(global_reserve_t *GEN3,
                                                  utime_data_t *U,
                                                  nodevans_rescue_header_t *RH,
                                                  uint64_t neededbits,
                                                  int32_t *rawvan_to_need,
                                                  ssd_needvan_t *needvans,
                                                  int32_t need_count);
```

Scans peer directory files to find candidates for each needed van:
- Reads pdir files from all peers
- Matches van hashes to find valid sources
- Populates candidate list in needvan structures

### ssd_verify_all_need_have_candidates

```c
static int32_t ssd_verify_all_need_have_candidates(ssd_needvan_t *needvans, 
                                                    int32_t need_count);
```

Verifies all needed vans have at least one candidate source.

### ssd_assign_writers

```c
static int32_t ssd_assign_writers(ssd_needvan_t *needvans, 
                                   int32_t need_count,
                                   uint8_t *writer_failed,
                                   int32_t num_nodes);
```

Assigns optimal writer for each needed van:
- Balances load across peers
- Avoids failed writers
- Minimizes fetch operations

### ssd_fetch_ranges_and_hydrate

```c
static int32_t ssd_fetch_ranges_and_hydrate(global_reserve_t *GEN3,
                                             utime_data_t *U,
                                             nodevans_rescue_header_t *RH,
                                             ssd_needvan_t *needvans,
                                             int32_t *need_order,
                                             int32_t need_count,
                                             ssd_fetch_item_t *items,
                                             uint8_t *writer_failed,
                                             ssd_bufref_t **bufs_out);
```

Fetches data ranges from peers and hydrates local state:
- Groups fetches by writer for efficiency
- Sorts by offset for sequential reads
- Validates fetched data against hashes
- Hydrates U structure with recovered vans

---

## Rescue State Machine

### gen3_ssd_rescue_step

The rescue system uses a state machine with static state per utime slot:

```c
static uint32_t sm_utime[VNET_FIFOSIZE];
static uint8_t sm_stage[VNET_FIFOSIZE];
static uint8_t sm_rescue_cursor[VNET_FIFOSIZE];
static uint8_t sm_pdir_cursor[VNET_FIFOSIZE];
static uint8_t sm_vans_cursor[VNET_FIFOSIZE];
static uint8_t sm_startnode[VNET_FIFOSIZE];
static int64_t sm_last_step_ms[VNET_FIFOSIZE];
static int64_t sm_last_try_ms[VNET_FIFOSIZE];
static int32_t sm_reconstruct_tries[VNET_FIFOSIZE];
static uint64_t sm_neededbits[VNET_FIFOSIZE];
static nodevans_rescue_header_t sm_RH[VNET_FIFOSIZE];
```

**Stages:**
- **Stage 0**: Fetch rescue headers from peers, check if rescue is possible
- **Stage 1**: Fetch pdir files from nodes with needed data
- **Stage 2**: Fetch actual van data and reconstruct
- **Stage 3**: Validate and finalize

The state machine:
- Runs incrementally (150ms between steps)
- Rotates starting node to distribute load
- Tracks failed writers to avoid retrying
- Limits reconstruction attempts

---

## Validation Functions

### ssd_nodevans_header_seems_valid

```c
static int32_t ssd_nodevans_header_seems_valid(const char *fname,
                                                uint32_t utime,
                                                int32_t origin_nodeid,
                                                uint16_t flags_expected);
```

Quick validation of nodevans file header:
- Checks magic number
- Verifies version
- Validates utime and nodeid

### ssd_rescue_validate_all

Validates all recovered data against expected hashes.

---

## Utility Functions

### ssd_read_file_malloc

```c
static int32_t ssd_read_file_malloc(const char *fname, 
                                     uint8_t **bufp, size_t *sizep);
```

Reads entire file into malloc'd buffer.

### ssd_track_bufref / ssd_free_bufrefs

```c
static int32_t ssd_track_bufref(ssd_bufref_t **buflistp, uint8_t *buf, size_t fsize);
static void ssd_free_bufrefs(ssd_bufref_t *bufs);
```

Buffer tracking for cleanup after rescue operations.

### ssd_fwrite_zeros

```c
static int32_t ssd_fwrite_zeros(FILE *fp, uint32_t nbytes);
```

Writes zero padding to file.

### ssd_calc_record_len

```c
static uint32_t ssd_calc_record_len(unified_header_t *H);
```

Calculates total record length including transaction hashes.

### ssd_pack_u64_subject

```c
static void ssd_pack_u64_subject(uint8_t subject[32], uint64_t v);
```

Packs uint64 into 32-byte subject for election verification.

---

## Integration Points

- **gen3_vote.c**: Provides election results for quorum proofs
- **gen3_net.c**: Network layer for fetching rescue data
- **validator.c**: Consumes rescue headers for state recovery
- **gen3.c**: Main generator loop calls rescue step

---

## File Types Summary

| Extension | Purpose | Writer |
|-----------|---------|--------|
| `.vans` | Complete nodevans | Origin node |
| `.pvans` | Partial nodevans | Any node with data |
| `.pdir` | Partial directory | Any node |
| `.rescue` | Rescue header + proofs | Any node |

---

## Related Files

- `gen3.h` - Structure definitions
- `gen3_vote.c` - Election system for consensus
- `gen3_net.c` - Network fetching
- `validator.c` - State consumption
