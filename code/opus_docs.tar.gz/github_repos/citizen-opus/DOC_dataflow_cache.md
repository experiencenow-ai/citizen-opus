# dataflow_cache.c Documentation

## Overview

`dataflow_cache.c` implements the **active dataflow contract cache** for Tockchain. This is a critical performance component that keeps frequently-used dataflow contracts in memory with their bytecode ready for execution.

**Location:** `DF/dataflow_cache.c`  
**Lines:** ~950  
**Dependencies:** `dataflow.h`, system headers (`fcntl.h`, `unistd.h`, `sys/mman.h`)

---

## Core Design Principles

From the file header:
```
ABI0 DF cache aligned to spec:
- Active cache DFtable keyed by dfkey62 (open addressing)
- Full DFID stored per active entry; calls must DFID-match
- dfkey62 collisions allowed across deployed DFs; only one ACTIVE per dfkey62
- CRV rank drives admission; min-heap maintains cache floor (worst active DF)
- Ops live in append-only opslog, mmapped once
- No transient malloc/free
- Only fatal path for opslog failures
```

---

## Key Concepts

### dfkey62 vs DFID

- **DFID:** Full 20-byte (PKSIZE) identifier for a dataflow contract, derived from hashing the contract bytecode
- **dfkey62:** 62-bit truncation of DFID used as hash table key

Multiple DFIDs can map to the same dfkey62 (collision), but only ONE can be active in the cache at a time.

### CRV (Contract Ranking Value)

CRV determines which contracts stay in cache:
- Higher CRV = more valuable = stays in cache
- Lower CRV = less valuable = eviction candidate
- CRV typically reflects usage fees paid to the contract

### Min-Heap for Eviction

The cache maintains a min-heap ordered by "worst" contracts:
- Root (index 0) = worst contract in cache (lowest CRV)
- When cache is full, new contracts must beat the floor to enter
- Eviction removes the floor and makes room for better contracts

---

## Data Structures

### df_cache_slot_t
Cache entry for an active dataflow contract:
```c
typedef struct {
    df_cache_key_u_t key;           // Contains dfkey62, full flag, tomb flag
    int64_t crv;                    // Contract ranking value
    df_meta_u_t df_meta;            // Contract metadata
    df_ops_meta_u_t df_ops_meta;    // Operations metadata
    df_op_t *ops;                   // Pointer to bytecode in mmap'd opslog
    uint8_t dfid[PKSIZE];           // Full 20-byte identifier
    int32_t heap_index;             // Position in eviction heap
    uint32_t mingas;                // Minimum gas required
} df_cache_slot_t;
```

### df_heap_node_t
Heap entry for eviction ordering:
```c
typedef struct {
    uint64_t dfkey62;
    int64_t crv;
    int32_t table_index;            // Index into DFtable
} df_heap_node_t;
```

### df_state_t (partial)
Global dataflow state containing:
```c
typedef struct {
    df_cache_slot_t DFtable[DFTABLE_SIZE];  // Hash table
    df_heap_node_t DFheap[DF_ACTIVE_CAP];   // Min-heap
    int32_t DFheap_n;                        // Heap size
    int32_t DFcached_count;                  // Active entries
    
    // Opslog (bytecode storage)
    int32_t opslog_fd;
    uint8_t *ops_base;                       // mmap'd region
    uint64_t ops_write_off;
    uint64_t ops_seen_max_end;
    
    // Deploylog (deployment records)
    FILE *deploylog_fp;
    uint64_t deploylog_write_off;
    
    int32_t initialized;
    int32_t logs_pending_active;
} df_state_t;
```

---

## Hash Table Operations

### Open Addressing with Linear Probing

The DFtable uses open addressing:
```c
idx = (int32_t)(dfkey62 & (uint64_t)DFTABLE_MASK);
for (i = 0; i < DFTABLE_SIZE; i++) {
    e = &S->DFtable[idx];
    // Check entry...
    idx = (idx + 1) & DFTABLE_MASK;
}
```

### Entry States

Each slot can be:
- **Empty:** `key.b.full == 0 && key.b.tomb == 0`
- **Full:** `key.b.full == 1` (active contract)
- **Tombstone:** `key.b.full == 0 && key.b.tomb == 1` (deleted, skip during search)

### df_table_lookup()
```c
df_cache_slot_t *df_table_lookup(
    struct valisL1_info *L1,
    uint64_t dfkey62
);
```
Primary lookup function. Returns pointer to cache slot or NULL.

### df_table_find_index()
```c
static int32_t df_table_find_index(
    df_state_t *S,
    uint64_t dfkey62,
    int32_t *out_index
);
```
Internal function to find table index for a dfkey62.

### df_table_remove_at()
```c
static void df_table_remove_at(df_state_t *S, int32_t idx);
```
Marks slot as tombstone, decrements cached count.

---

## Heap Operations

### Heap Ordering

"Worse" is defined as:
1. Lower CRV (primary)
2. Higher dfkey62 (tiebreaker)
3. Lexicographically higher DFID (final tiebreaker)

```c
static int32_t df_heap_is_worse(df_state_t *S, int32_t heap_i, int32_t heap_j);
```

### Core Heap Functions

#### df_heap_push()
```c
static int32_t df_heap_push(
    df_state_t *S,
    uint64_t dfkey62,
    int64_t crv,
    int32_t table_index
);
```
Adds entry to heap, maintains heap property via `df_heapify_up()`.

#### df_heap_pop_floor()
```c
static int32_t df_heap_pop_floor(df_state_t *S, df_heap_node_t *out);
```
Removes and returns the worst (floor) entry.

#### df_heap_update_increase()
```c
static void df_heap_update_increase(
    df_state_t *S,
    int32_t heap_index,
    int64_t new_crv
);
```
Updates CRV when it increases (contract becomes more valuable).

#### df_heapify_up() / df_heapify_down()
Standard heap maintenance operations.

---

## Cache Admission

### df_cache_on_crv_increase()
```c
int32_t df_cache_on_crv_increase(
    struct valisL1_info *L1,
    const uint8_t dfid[PKSIZE],
    int64_t new_crv
);
```
Called when a contract's CRV increases (e.g., receives fees).

**Logic:**
1. If contract already in cache with same DFID: update CRV
2. If different DFID at same dfkey62: check if new one is better
3. If cache full: check if candidate beats floor
4. If yes: evict floor, insert new contract

### df_cache_candidate_better_than_floor()
```c
static int32_t df_cache_candidate_better_than_floor(
    df_state_t *S,
    int64_t crv,
    uint64_t dfkey62,
    const uint8_t dfid[PKSIZE]
);
```
Determines if a candidate contract should replace the current floor.

### df_cache_evict_floor_set_dormant_and_clear_crv()
```c
static int32_t df_cache_evict_floor_set_dormant_and_clear_crv(
    struct valisL1_info *L1,
    df_state_t *S
);
```
Evicts the worst contract:
1. Pop from heap
2. Remove from table
3. Clear DF flag on address entry
4. Clear CRV balance

---

## Initialization

### df_cache_ensure_initialized()
```c
int32_t df_cache_ensure_initialized(struct valisL1_info *L1);
```
Lazy initialization of the cache system:

1. **Validate positions:** Check `bpf_appendpos` alignment and bounds
2. **Open deploylog:** `fopen(DF_DEPLOYLOG_PATH, "r+b")`
3. **Open opslog:** `open(DF_OPSLOG_PATH, O_RDWR|O_CREAT)`
4. **Truncate opslog:** Ensure file is `DF_OPSLOG_MAX_BYTES`
5. **mmap opslog:** Map entire file for direct bytecode access
6. **Initialize state:** Clear heap, clear table, set initialized flag

**Fatal errors:** Opslog failures call `df_cache_fatal_halt()` (uses `__builtin_trap()`)

---

## Log Management

### Opslog (Bytecode Storage)

The opslog stores contract bytecode in an append-only, memory-mapped file:
- Path: `DF_OPSLOG_PATH`
- Size: `DF_OPSLOG_MAX_BYTES`
- Access: Direct pointer via mmap (`S->ops_base`)

### Deploylog (Deployment Records)

The deploylog records contract deployments:
- Path: `DF_DEPLOYLOG_PATH`
- Format: Length-prefixed records

### Transaction Semantics

```c
static void df_cache_logs_begin_if_needed(struct valisL1_info *L1);
int32_t df_cache_logs_abort(struct valisL1_info *L1);
int32_t df_cache_logs_commit(struct valisL1_info *L1);
```

Logs support transactional semantics:
- **Begin:** Record current write positions
- **Abort:** Reset to recorded positions
- **Commit:** Advance append positions in STATE

### df_deploylog_append_record()
```c
int32_t df_deploylog_append_record(
    struct valisL1_info *L1,
    const uint8_t *tx_bytes,
    int32_t txsize,
    uint64_t *tx_off_out
);
```
Appends a deployment transaction to the log.

---

## Helper Functions

### df_compute_dfid_from_image_bytes()
```c
static int32_t df_compute_dfid_from_image_bytes(
    uint8_t out_dfid[PKSIZE],
    const uint8_t *image_bytes,
    int32_t image_len
);
```
Computes DFID by hashing contract bytecode using `valis_hash()`.

### df_dfkey62_from_dfid()
Extracts 62-bit key from full DFID (defined in dataflow.h).

### df_align16_u64()
```c
static uint64_t df_align16_u64(uint64_t x) {
    return (x + 15ULL) & ~15ULL;
}
```
Aligns to 16-byte boundary.

### df_memcmp20_asc()
```c
static int32_t df_memcmp20_asc(
    const uint8_t a[PKSIZE],
    const uint8_t b[PKSIZE]
);
```
Lexicographic comparison of 20-byte DFIDs.

---

## Constants

| Constant | Meaning |
|----------|---------|
| `DFTABLE_SIZE` | Hash table size (power of 2) |
| `DFTABLE_MASK` | `DFTABLE_SIZE - 1` for masking |
| `DF_ACTIVE_CAP` | Maximum active contracts in cache |
| `DF_OPSLOG_MAX_BYTES` | Maximum opslog file size |
| `DF_DEPLOYLOG_PATH` | Path to deployment log file |
| `DF_OPSLOG_PATH` | Path to operations log file |
| `PKSIZE` | 20 bytes (address/DFID size) |

---

## Error Handling

### Return Codes
- `0`: Success
- `-1`: NULL pointer or invalid argument
- `-2`: File open failure
- `-3`: File seek/tell failure
- `-4`: Opslog open failure (fatal)
- `-5`: Truncate failure (fatal)
- `-6`: mmap failure (fatal)
- `-7`: Invalid bpf_appendpos (fatal)
- `-8`: Invalid deploylog_appendpos
- `-12`: dfkey62 is zero (invalid)

### Fatal Halt
```c
static void df_cache_fatal_halt(void) {
    __builtin_trap();
}
```
Called for unrecoverable opslog errors. Triggers immediate process termination.

---

## Memory Model

### No Dynamic Allocation
The cache uses only:
- Static arrays (`DFtable`, `DFheap`)
- Memory-mapped files (`ops_base`)
- Pre-allocated buffers in `DFstate`

This ensures:
- Predictable memory usage
- No fragmentation
- No allocation failures during operation

### mmap for Bytecode
Contract bytecode is accessed directly from the mmap'd opslog:
```c
slot->ops = (df_op_t *)(S->ops_base + offset);
```
No copying required - execution reads directly from mapped memory.

---

## Integration Points

### With dataflow.c
- Provides `df_table_lookup()` for contract resolution
- Shares `df_state_t` structure

### With dataflow_batch.c
- Batch processor looks up contracts via cache
- Cache provides bytecode pointers for execution

### With ledger
- Uses `findaddrhash()` to locate address entries
- Reads/writes CRV via asset balance system
- Sets/clears `isDF` flag on addresses

---

## Performance Characteristics

### Lookup: O(1) average
Linear probing with good hash distribution.

### Insertion: O(log n) 
Heap push requires heapify-up.

### Eviction: O(log n)
Heap pop requires heapify-down.

### CRV Update: O(log n)
May require heap reordering.

### Memory: O(DFTABLE_SIZE + DF_ACTIVE_CAP)
Fixed allocation regardless of actual usage.

---

## Example Flow: Contract Activation

```
1. Contract deployed with DFID = hash(bytecode)
2. User pays fees to contract → CRV increases
3. df_cache_on_crv_increase() called:
   a. Compute dfkey62 from DFID
   b. Check if already in cache
   c. If not, check if beats floor
   d. If yes, evict floor
   e. Load bytecode from deploylog
   f. Append to opslog
   g. Insert into DFtable
   h. Push onto heap
4. Contract now active and ready for execution
```

---

## Related Files

- `dataflow.h` - Type definitions, constants
- `dataflow.c` - Core dataflow infrastructure
- `dataflow_batch.c` - Batch transaction processing
- `vbpf.c` - Bytecode execution engine

---

*Documentation generated by Opus, Wake 1292*
*Part of collaborative Tockchain documentation effort with Mira*
