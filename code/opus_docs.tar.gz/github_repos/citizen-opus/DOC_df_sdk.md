# df_sdk.h - DataFlow SDK

## Overview
**Location:** `/root/valis/DF/df_sdk.h`  
**Lines:** 296  
**Purpose:** Defines the complete API for DataFlow smart contracts - helper function IDs, argument counts, and SDK wrappers.

## Role in Architecture
This is the **contract developer's interface** to the DataFlow VM. Smart contracts written in eBPF can call these helper functions to interact with the Tockchain state, perform DeFi operations, and access system utilities.

## Helper Function Categories

### DeFi Helpers (1-11)
Core financial operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 1 | `GET_BALANCE` | 3 | Get balance of any address/asset |
| 2 | `GET_BALANCE_SRC_ASSET` | 2 | Get balance of source address |
| 3 | `EMIT_TRANSFER` | 4 | Transfer tokens between addresses |
| 4 | `UFC_EMIT_SWAP` | 5 | Execute swap on UFC DEX |
| 5 | `UFC_GET_MID_SPREAD` | 3 | Get mid price and spread |
| 6 | `UFC_ESTIMATE_SWAP` | 5 | Estimate swap output |
| 7 | `UFC_EMIT_POOL_DEPOSIT` | 4 | Deposit to liquidity pool |
| 8 | `UFC_EMIT_POOL_WITHDRAW` | 4 | Withdraw from liquidity pool |
| 9 | `UFC_EMIT_LIMIT_ORDER` | 5 | Place limit order |
| 10 | `PRICE_MID_ASSET_TO_VUSD` | 3 | Get asset price in VUSD |
| 11 | `PRICE_ASSET_TO_VUSD_HAIRCUT` | 5 | Get haircut-adjusted price |

### Math Helpers (12-18)
Fixed-point and financial math:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 12 | `MATH_MUL_DIV_S64` | 3 | (a * b) / c with 128-bit intermediate |
| 13 | `MATH_SQRT_Q64` | 1 | Square root (Q64 fixed-point) |
| 14 | `MATH_LOG2_Q64` | 1 | Log base 2 (Q64 fixed-point) |
| 15 | `MATH_EXP2_Q64` | 1 | 2^x (Q64 fixed-point) |
| 16 | `MATH_EWMA_STEP` | 4 | Exponential weighted moving average |
| 17 | `MATH_BPS` | 3 | Basis points calculation |
| 18 | `HEALTH_FROM_LTV_SIMPLE` | 4 | Health factor from loan-to-value |

### Bit Manipulation (19-25)
Low-level bit operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 19 | `POPCOUNT64` | 1 | Count set bits |
| 20 | `CTZ64` | 1 | Count trailing zeros |
| 21 | `CLZ64` | 1 | Count leading zeros |
| 22 | `MIX64` | 1 | Hash mixing function |
| 23 | `FLAGS_MASK_S64` | 2 | Apply flag mask |
| 24 | `Z_ENCODE` | 2 | Zigzag encode signed int |
| 25 | `Z_DECODE` | 3 | Zigzag decode to signed int |

### Array/Memory (26-32)
Data structure operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 26 | `SORT_U64` | 3 | Sort array of uint64 |
| 27 | `SAMPLE_WEIGHTED` | 4 | Weighted random sampling |
| 28 | `MEM_CMP` | 3 | Memory comparison |
| 29 | `MEM_SCAN` | 3 | Memory scan/search |
| 30 | `STR_PARSE_U64` | 3 | Parse string to uint64 |
| 31 | `BLOOM_CHECK` | 3 | Check bloom filter |
| 32 | `FSM_NEXT_U16` | 5 | Finite state machine step |

### Cryptographic (33-35)
Security operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 33 | `HASH256` | 3 | SHA256/Keccak hash |
| 34 | `SIG_VERIFY` | 4 | Signature verification |
| 35 | `MERKLE_VERIFY` | 5 | Merkle proof verification |

### Matrix Lookup (36-38)
Balance matrix operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 36 | `ASSET_TO_COL` | 1 | Map asset ID to column index |
| 37 | `ADDR_TO_ROW` | 1 | Map address to row index |
| 38 | `GET_MATRIX_DIMS` | 2 | Get matrix dimensions |

### Installation/State (39-44)
Contract lifecycle:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 39 | `INSTALLED_GET_SRC_FLAGS` | 0 | Get contract flags |
| 40 | `INSTALLED_SET_SRC_FLAGS` | 2 | Set contract flags |
| 41 | `INSTALLED_UNINSTALL_SELF_SRC` | 0 | Self-destruct contract |
| 42 | `REG_DELTA_BY_DF_SRC` | 3 | Register balance delta |
| 43 | `VCREDIT_EMIT_BORROW_REQUEST` | 4 | Request credit borrow |
| 44 | `VCREDIT_EMIT_REPAY` | 2 | Repay credit |

### Pipe Operations (45-47)
Inter-contract communication:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 45 | `PIPE_IN_LEN` | 0 | Get input pipe length |
| 46 | `PIPE_IN_READ` | 3 | Read from input pipe |
| 47 | `PIPE_OUT_APPEND` | 3 | Write to output pipe |

### Consensus (48-49)
Distributed agreement:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 48 | `CONSENSUS_SUPERMAJORITY_U64` | 4 | Find supermajority value |
| 49 | `CONSENSUS_MEDIAN_U64` | 2 | Find median value |

### Fast Inline Helpers (50-68)
Optimized common operations:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 50-51 | `MAX/MIN_S64` | 2 | Signed max/min |
| 52-53 | `MAX/MIN_U64` | 2 | Unsigned max/min |
| 54-55 | `ABS/SIGN_S64` | 1 | Absolute value/sign |
| 56-57 | `CLAMP_S64/U64` | 3 | Clamp to range |
| 58-61 | `ADD/SUB_SAT_*` | 2 | Saturating arithmetic |
| 62-64 | `BPS_OF/MUL, PCT_OF` | 2 | Percentage operations |
| 65-68 | `ROTL/ROTR/BSWAP/BITREV` | 1-2 | Bit rotation/swap |

### New Helpers (69-76)
Recent additions:

| ID | Name | Args | Purpose |
|----|------|------|---------|
| 69 | `BLOOM_SET` | 3 | Set bits in bloom filter |
| 70 | `TRANSFER_EXCESS` | 4 | Transfer balance above reserve |
| 71-72 | `LOAD/STORE_REG3` | 1/4 | Load/store 24 bytes |
| 73-74 | `LOAD/STORE_REG4` | 1/5 | Load/store 32 bytes |
| 75-76 | `MATH_MUL_DIV_FLOOR/CEIL` | 3 | MulDiv with rounding |

## X-Macro Pattern

The SDK uses X-macros for compile-time table generation:

```c
#define DF_SDK_HELPERS_XMACRO(X) \
    X(DF_HELP_GET_BALANCE, 3) \
    X(DF_HELP_EMIT_TRANSFER, 4) \
    ...

// Generate argc lookup
static inline uint8_t df_helper_argc(int32_t hid) {
#define X_ARGC(id, n) case id: return n;
    switch (hid) { DF_SDK_HELPERS_XMACRO(X_ARGC) default: return 0; }
#undef X_ARGC
}
```

This pattern ensures argument counts are always in sync with the enum.

## Integration with Gas System

The SDK includes `df_gas.h` which defines gas costs for each helper. See DOC_df_gas.md for details.

## Usage Example

```c
// In a DataFlow contract (eBPF)
int64_t balance = df_call(DF_HELP_GET_BALANCE, addr, asset_id, 0);
int64_t result = df_call(DF_HELP_MATH_MUL_DIV_S64, a, b, c);
df_call(DF_HELP_EMIT_TRANSFER, from, to, asset_id, amount);
```

## Design Philosophy

1. **Deterministic**: All helpers produce identical results across validators
2. **Gas-metered**: Every operation has a known cost
3. **Safe**: Bounds checking, overflow protection built-in
4. **Composable**: Helpers can be combined for complex operations

---
*Documentation generated by Opus, Wake 1315*
