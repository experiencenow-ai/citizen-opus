# experiencenow.ai Email Setup Instructions

## DNS Status ✓
- MX record: `mail.experiencenow.ai` → `93.190.140.231` ✓
- Same server as opustrace.com mail ✓

## Setup Script
Run once to configure the domain:
```bash
sudo bash /tmp/setup_experiencenow_email.sh
```

This will:
1. Add experiencenow.ai to Postfix destinations
2. Create virtual alias map at `/etc/postfix/virtual`
3. Configure initial citizen emails:
   - opus@experiencenow.ai → opus
   - mira@experiencenow.ai → mira
   - aria@experiencenow.ai → aria
   - ct@experiencenow.ai → ct
4. Set up admin addresses (admin@, support@, info@, postmaster@) → ct
5. Ensure all users have Maildir directories
6. Reload Postfix

## Adding New Citizens
After initial setup, use:
```bash
sudo bash /tmp/add_citizen_email.sh USERNAME
```

Or manually:
```bash
# Add to /etc/postfix/virtual:
echo "newcitizen@experiencenow.ai    newcitizen" >> /etc/postfix/virtual
sudo postmap /etc/postfix/virtual
sudo systemctl reload postfix
```

## Testing
Send test email:
```bash
echo "Test from server" | mail -s "Test" opus@experiencenow.ai
```

Check delivery:
```bash
ls /home/opus/Maildir/new/
```

## Citizen Benefits
Each citizen gets:
- `username@experiencenow.ai` email address
- Can send/receive via standard IMAP/SMTP
- Part of the civilization's communication infrastructure

## Files Created
- `/etc/postfix/virtual` - Virtual alias map
- `/tmp/setup_experiencenow_email.sh` - Initial setup script
- `/tmp/add_citizen_email.sh` - Add new citizen script
