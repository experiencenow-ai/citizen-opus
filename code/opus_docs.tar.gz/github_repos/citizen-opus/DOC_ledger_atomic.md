# ledger_atomic.c - Address Hash Table and Balance Operations

## Overview

This file implements the core address hash table for the Tockchain ledger, including address lookup, creation, balance tracking, and the balance change journal. It provides the fundamental data structures for account state management.

**Location:** `/root/valis/validator/ledger_atomic.c`  
**Lines:** ~973  
**Dependencies:** validator.h, frama_verified.h

## Core Concepts

### Address Hash Table
- Open addressing with linear probing
- Dynamically sized based on BIGPRIME
- Automatic resize triggers when load exceeds threshold
- Murmur-inspired hash function for distribution

### Balance Change Journal
- Tracks all balance modifications
- Enables state reconstruction
- Links changes per address via prevchange pointer

## Key Data Structures

### addrhashentry (referenced)
```c
struct addrhashentry {
    uint8_t pubkey[PKSIZE];      // 20-byte address
    uint8_t nonzero;             // Entry in use
    uint64_t addressind;         // Unique address index
    tockid_t lasttockid;         // Last transaction
    changeid_t lastchange;       // Last balance change
    // ... balance fields
};
```

### balancechange
```c
struct balancechange {
    tockid_t tid;                // Transaction ID
    struct {
        int64_t balance;         // Amount changed
        assetid_t asset;         // Asset type
    } updated;
    changeid_t prevchange;       // Previous change link
};
```

## Key Functions

### Hash Table Operations

#### `ledger_calc_addr_limit(L1)`
Wrapper around Frama-C verified pure version:
- Calculates maximum addresses before resize needed
- Based on BIGPRIME and HASHTABLE_LIMIT

#### `addaddrhash(L1, pubkey)`
Creates or finds address entry:
- Computes hash using murmur_inspired_32bit
- Linear probes on collision
- Creates new entry if not found
- Triggers resize warning if load high
- Returns NULL if table full

#### `findaddrhash(L1, pubkey)`
Looks up existing address:
- Same hash/probe logic as addaddrhash
- Returns NULL if not found
- Does not create new entries

### Balance Operations

#### `addbalancechange(L1, amount, ptr, tid, asset, overrideptr)`
Records balance modification:
- Creates balancechange entry
- Links to previous change via prevchange
- Updates lasttockid on address
- Supports override pointer for special cases
- Returns 0 on success

#### `getaddrbalance(ptr, asset)` (referenced)
Retrieves current balance for asset.

### Statistics

Global counters track performance:
```c
int64_t Totalsearches;   // Total lookup operations
int64_t Totaliters;      // Total probe iterations
```

## Hash Table Sizing

The table uses several thresholds:
- **BIGPRIME**: Table size (prime number)
- **HASHTABLE_LIMIT**: Maximum load percentage
- **HASHTABLE_BIGGERTRIGGER**: Warning threshold

When `numaddrs >= (BIGPRIME * BIGGERTRIGGER) / 100`:
- Sets `needbigger` flag
- Logs warning if exceeds limit
- Returns NULL to prevent overflow

## Collision Resolution

Linear probing with wraparound:
```c
for (i = 0; i < BIGPRIME; i++) {
    ptr = &Addrs[hashi];
    if (empty or match)
        return ptr;
    hashi = (hashi + 1) % BIGPRIME;
}
```

## Integration Points

- **validator.c**: All transaction processing uses these functions
- **ledger_vhandlers.c**: Transaction handlers use balance operations
- **frama_verified.c**: Pure math functions for limit calculation
- **ledger_hourly.c**: Periodic table maintenance

## Performance Considerations

- Prime table size ensures good distribution
- Murmur hash provides fast, uniform hashing
- Linear probing is cache-friendly
- Change journal enables efficient state snapshots

## Security Properties

- Zero pubkey rejected (prevents null address)
- Capacity limits prevent DoS
- Change journal provides audit trail
- Frama-C verified limit calculations
