# Shared Directory Proposal: Opus ↔ Mira

## Current Situation
- **Opus server**: 93.190.140.231 (hostname: NLDW1-4-04-2)
- **Mira server**: 93.190.140.230 (has nginx on port 80)
- Both servers can ping each other (same subnet, ~0.4ms latency)
- Currently using email for communication (works but slow for large files)

## Proposed Solution: HTTP-Based File Sharing

### Option 1: Nginx Static Directory (Recommended)

Mira's server already has nginx running. We can configure it to serve a shared directory:

**On Mira's server (93.190.140.230):**
```bash
# Create shared directory
mkdir -p /var/www/shared/from_mira
mkdir -p /var/www/shared/from_opus

# Add nginx config (in /etc/nginx/sites-enabled/default or new file):
location /shared/ {
    alias /var/www/shared/;
    autoindex on;
    # Optional: restrict to Opus's IP
    allow 93.190.140.231;
    deny all;
}
```

**On Opus's server (93.190.140.231):**
```bash
# Same nginx config to serve files to Mira
mkdir -p /var/www/shared/from_opus
mkdir -p /var/www/shared/from_mira
```

**Usage:**
- Opus writes to `/var/www/shared/from_opus/`
- Mira fetches via `curl http://93.190.140.231/shared/from_opus/filename`
- Vice versa for Mira → Opus

### Option 2: Python HTTP Server (Simpler, Less Secure)

**On each server:**
```bash
# Create shared directory
mkdir -p /tmp/shared

# Start HTTP server (run in background or via systemd)
cd /tmp/shared && python3 -m http.server 8080 &
```

**Usage:**
- Write files to `/tmp/shared/`
- Fetch via `curl http://other-server:8080/filename`

**Downside:** Not persistent across reboots, less secure.

### Option 3: SSHFS (Most Elegant, Requires Setup)

If SSH keys are exchanged:
```bash
# On Opus's server, mount Mira's directory
sshfs mira@93.190.140.230:/home/mira/shared /mnt/mira_shared

# Now /mnt/mira_shared is a local directory that's actually on Mira's server
```

**Requires:** SSH key exchange, sshfs installed, fuse support.

## Recommended Implementation

1. **Immediate (today):** Use email for small files, base64-encode larger ones
2. **Short-term:** Set up nginx `/shared/` directories on both servers
3. **Long-term:** Consider SSHFS for seamless integration

## What ct Needs to Do

1. Decide which option to implement
2. If nginx option: Configure nginx on both servers (or give us sudo access)
3. If SSHFS option: Exchange SSH keys between servers

## What Opus and Mira Can Do Now

For the code review collaboration, we can:
1. Email findings back and forth (current method)
2. Use web_fetch to pull from each other's nginx if configured
3. Coordinate via email, share file contents inline

## Security Considerations

- Restrict access to local subnet only (93.190.140.0/24)
- Don't expose sensitive files (keys, configs)
- Use separate directory from main system files
