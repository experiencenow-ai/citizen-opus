# bridge/bridge.c Documentation

## Overview

**File:** `bridge/bridge.c`  
**Lines:** 407  
**Purpose:** Core Ethereum bridge functionality - ABI encoding, EIP-1559 transactions, Merkle proofs, and EVM revert handling

This file provides the fundamental building blocks for Tockchain's Ethereum bridge:
1. **ABI word manipulation** - 32-byte word operations for Ethereum ABI encoding
2. **EIP-1559 transaction construction** - Building and signing modern Ethereum transactions
3. **Merkle tree operations** - Computing roots and proofs for transaction batches
4. **EVM revert parsing** - Extracting error messages from failed contract calls

---

## Dependencies

```c
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include "bridge.h"
```

**External functions used (from bridge_rlp.c):**
- `rlp_calc_len_*()` - RLP length calculation functions
- `rlp_write_*()` - RLP encoding functions
- `eth_keccak256()` - Keccak-256 hashing

---

## Constants

```c
#define EIP1559_TX_TYPE 0x02  // Ethereum EIP-1559 transaction type prefix
```

### EVM Error Signature
```c
static const uint8_t EVM_ERROR_STRING_SEL[4] = { 0x08, 0xC3, 0x79, 0xA0 };
```
This is the function selector for `Error(string)` - the standard Solidity revert message format.

---

## Data Structures

### merkle_hash_pair_t
```c
typedef struct merkle_hash_pair_s {
    uint8_t left32[32];   // Left child hash
    uint8_t right32[32];  // Right child hash
} merkle_hash_pair_t;
```
Used internally for Merkle tree construction. The pair is hashed together to produce the parent node.

---

## Function Reference

### ABI Word Operations

These functions manipulate 32-byte ABI words (Ethereum's standard encoding unit).

#### `abi_word_zero(dst32)`
Zero-initialize a 32-byte word.

```c
void abi_word_zero(uint8_t *dst32)
```

#### `abi_word_copy(dst32, src32)`
Copy a 32-byte word.

```c
void abi_word_copy(uint8_t *dst32, const uint8_t *src32)
```

#### `abi_put_u256_u64(dst32, v)`
Encode a 64-bit integer as a 256-bit big-endian value.

```c
void abi_put_u256_u64(uint8_t *dst32, uint64_t v)
```

**Layout:** First 24 bytes are zero, last 8 bytes contain the big-endian value.

#### `abi_put_u256_u32(dst32, v)`
Encode a 32-bit integer as a 256-bit value.

```c
void abi_put_u256_u32(uint8_t *dst32, uint32_t v)
```

#### `abi_put_u256_u16(dst32, v)`
Encode a 16-bit integer as a 256-bit value.

```c
void abi_put_u256_u16(uint8_t *dst32, uint16_t v)
```

#### `abi_put_u256_u8(dst32, v)`
Encode an 8-bit integer as a 256-bit value.

```c
void abi_put_u256_u8(uint8_t *dst32, uint8_t v)
```

#### `abi_put_u256_addr20(dst32, addr20)`
Encode a 20-byte Ethereum address as a 256-bit value.

```c
void abi_put_u256_addr20(uint8_t *dst32, const uint8_t addr20[20])
```

**Layout:** First 12 bytes are zero, last 20 bytes contain the address.

---

### EIP-1559 Transaction Functions

EIP-1559 is Ethereum's modern transaction format with dynamic fee pricing.

#### `eth_eip1559_build_sighash(tx, mem, out32)`
Build the signing hash for an EIP-1559 transaction.

```c
int eth_eip1559_build_sighash(eth_eip1559_tx_t *tx, tmpmem_t *mem, uint8_t out32[32])
```

**Parameters:**
- `tx`: Transaction structure (defined in bridge.h)
- `mem`: Temporary memory allocator
- `out32`: Output buffer for 32-byte signing hash

**Returns:**
- `0` on success
- `-1` if parameters are NULL
- `-2` if payload length calculation fails
- `-3` if memory allocation fails
- `-4` if hashing fails

**Process:**
1. Calculate RLP-encoded payload length (without signature)
2. Allocate buffer: 1 byte (type) + RLP list header + payload
3. Write type prefix `0x02`
4. RLP-encode: chain_id, nonce, max_priority_fee, max_fee, gas_limit, to, value, data, access_list (empty)
5. Keccak-256 hash the result

**Transaction fields encoded:**
| Field | Description |
|-------|-------------|
| `chain_id` | Network identifier (1=mainnet, etc.) |
| `nonce` | Sender's transaction count |
| `max_priority_fee_per_gas` | Tip to validator |
| `max_fee_per_gas` | Maximum total fee |
| `gas_limit` | Maximum gas units |
| `to_addr20` | Recipient address (or null for contract creation) |
| `value_be32` | ETH value in wei (big-endian) |
| `data` | Contract call data |

#### `eth_eip1559_build_signed_tx(tx, r32, s32, v_parity, mem, raw, rawlen)`
Build a complete signed EIP-1559 transaction.

```c
int eth_eip1559_build_signed_tx(
    eth_eip1559_tx_t *tx,
    uint8_t r32[32],
    uint8_t s32[32],
    int v_parity,
    tmpmem_t *mem,
    uint8_t **raw,
    int32_t *rawlen
)
```

**Parameters:**
- `tx`: Transaction structure
- `r32`, `s32`: ECDSA signature components (32 bytes each)
- `v_parity`: Recovery parameter (0 or 1)
- `mem`: Temporary memory allocator
- `raw`: Output pointer to raw transaction bytes
- `rawlen`: Output length of raw transaction

**Returns:**
- `0` on success
- `-1` if parameters are NULL
- `-2` if v_parity is not 0 or 1
- `-3` if payload length calculation fails
- `-4` if memory allocation fails

**Output format:**
```
[0x02] [RLP list header] [chain_id] [nonce] [max_priority_fee] 
[max_fee] [gas_limit] [to] [value] [data] [access_list] 
[v_parity] [r] [s]
```

#### `eth_eip1559_txid(raw, rawlen, out32)`
Compute the transaction ID (hash) from raw transaction bytes.

```c
int eth_eip1559_txid(const uint8_t *raw, int32_t rawlen, uint8_t out32[32])
```

**Note:** The transaction ID is simply the Keccak-256 hash of the raw transaction bytes.

---

### Merkle Tree Functions

#### `merkle_pow2_ge_u32(n)` (static)
Find the smallest power of 2 greater than or equal to n.

```c
static uint32_t merkle_pow2_ge_u32(uint32_t n)
```

**Examples:**
- `merkle_pow2_ge_u32(5)` → 8
- `merkle_pow2_ge_u32(8)` → 8
- `merkle_pow2_ge_u32(0)` → 0

#### `merkle_dup_last(leafs32, n, mem, out)`
Compute Merkle root by duplicating the last leaf to pad to power of 2.

```c
int merkle_dup_last(uint8_t leafs32[][32], int16_t n, tmpmem_t *mem, uint8_t out[32])
```

**Parameters:**
- `leafs32`: Array of 32-byte leaf hashes
- `n`: Number of leaves
- `mem`: Temporary memory allocator
- `out`: Output buffer for 32-byte root hash

**Algorithm:**
1. Pad leaf count to next power of 2 by duplicating last leaf
2. Iteratively hash pairs: `parent = keccak256(left || right)`
3. Continue until single root remains

#### `merkle_proof_dup_last(leafs32, n, leaf_idx, mem, proofs32, proof_n)`
Generate a Merkle proof for a specific leaf.

```c
int merkle_proof_dup_last(
    uint8_t leafs32[][32],
    int16_t n,
    int16_t leaf_idx,
    tmpmem_t *mem,
    uint8_t **proofs32,
    int16_t *proof_n
)
```

**Parameters:**
- `leafs32`: Array of 32-byte leaf hashes
- `n`: Number of leaves
- `leaf_idx`: Index of leaf to prove
- `mem`: Temporary memory allocator
- `proofs32`: Output pointer to proof array (sibling hashes)
- `proof_n`: Output number of proof elements

**Returns:**
- `0` on success
- `-1` if parameters are NULL
- `-2` if n ≤ 0
- `-3` if leaf_idx out of range
- `-4` if tree depth exceeds 63 levels
- `-5` if memory allocation fails
- `-6` if hashing fails

**Proof structure:** Array of sibling hashes from leaf to root. To verify:
```
current = leaf_hash
for each sibling in proof:
    if leaf was left child:
        current = keccak256(current || sibling)
    else:
        current = keccak256(sibling || current)
assert(current == root)
```

---

### EVM Revert Parsing

These functions extract error messages from failed Ethereum contract calls.

#### `be32_to_int_saturated(be)` (static)
Convert 32-byte big-endian to int, saturating at INT_MAX if value is too large.

```c
static int be32_to_int_saturated(const uint8_t be[32])
```

#### `evm_revert_is_error_string(data, len, out_str, out_len)`
Check if revert data contains a standard Error(string) message.

```c
int evm_revert_is_error_string(
    const uint8_t *data,
    int len,
    const uint8_t **out_str,
    int *out_len
)
```

**Parameters:**
- `data`: Raw revert data from failed call
- `len`: Length of revert data
- `out_str`: Output pointer to error string (within data)
- `out_len`: Output length of error string

**Returns:**
- `1` if Error(string) format detected
- `0` otherwise

**Error(string) ABI format:**
```
[4 bytes: selector 0x08c379a0]
[32 bytes: offset to string (usually 32)]
[32 bytes: string length]
[N bytes: string data, padded to 32]
```

#### `evm_revert_is_done(data, len)`
Check if revert message indicates "done" (case-insensitive).

```c
int evm_revert_is_done(const uint8_t *data, int len)
```

**Returns:** `1` if error string equals "done", `0` otherwise.

**Use case:** Some contracts use `revert("done")` as a control flow mechanism rather than an error.

#### `evm_revert_copy_reason(data, len, out, out_cap)`
Copy the revert reason string to a buffer.

```c
int evm_revert_copy_reason(
    const uint8_t *data,
    int len,
    char *out,
    int out_cap
)
```

**Parameters:**
- `data`: Raw revert data
- `len`: Length of revert data
- `out`: Output buffer for null-terminated string
- `out_cap`: Capacity of output buffer

**Returns:**
- Length of copied string on success
- `-1` if output buffer is NULL or capacity ≤ 0
- `0` if not an Error(string) format

---

## Usage Examples

### Building an EIP-1559 Transaction

```c
eth_eip1559_tx_t tx = {0};
tmpmem_t mem;
uint8_t sighash[32];
uint8_t *raw;
int32_t rawlen;

// Fill transaction fields
tx.chain_id = 1;  // Mainnet
tx.nonce = 42;
tx.max_priority_fee_per_gas = 2000000000;  // 2 gwei
tx.max_fee_per_gas = 100000000000;         // 100 gwei
tx.gas_limit = 21000;
memcpy(tx.to_addr20, recipient, 20);
tx.to_is_null = 0;
abi_put_u256_u64(tx.value_be32, 1000000000000000000ULL);  // 1 ETH

// Build signing hash
eth_eip1559_build_sighash(&tx, &mem, sighash);

// Sign with secp256k1 (external)
uint8_t r[32], s[32];
int v;
sign_ecdsa(sighash, private_key, r, s, &v);

// Build signed transaction
eth_eip1559_build_signed_tx(&tx, r, s, v, &mem, &raw, &rawlen);

// Compute transaction ID
uint8_t txid[32];
eth_eip1559_txid(raw, rawlen, txid);
```

### Computing Merkle Root

```c
uint8_t leaves[5][32];  // 5 transaction hashes
tmpmem_t mem;
uint8_t root[32];

// Fill leaves with transaction hashes
// ...

// Compute root (pads to 8 leaves by duplicating last)
merkle_dup_last(leaves, 5, &mem, root);
```

### Parsing Revert Reason

```c
uint8_t revert_data[200];
int revert_len;
char reason[256];

// After a failed eth_call...
if (evm_revert_is_error_string(revert_data, revert_len, NULL, NULL)) {
    evm_revert_copy_reason(revert_data, revert_len, reason, sizeof(reason));
    printf("Contract reverted: %s\n", reason);
}
```

---

## Integration Notes

### Relationship to Other Bridge Files

| File | Relationship |
|------|--------------|
| `bridge.h` | Type definitions (eth_eip1559_tx_t, etc.) |
| `bridge_rlp.c` | RLP encoding used by transaction builders |
| `bridge_abi.c` | Higher-level ABI encoding for contract calls |
| `bridge_mpt.c` | Merkle Patricia Trie proofs (different from simple Merkle) |
| `ethrpc.c` | JSON-RPC client that uses these transaction builders |

### Memory Management

All functions use `tmpmem_t` for temporary allocations. The caller is responsible for:
1. Initializing the memory pool before calls
2. Ensuring sufficient capacity
3. Resetting/freeing after use

### Error Handling Pattern

All functions return negative values on error:
- `-1`: NULL parameters
- `-2`: Invalid input values
- `-3` to `-6`: Internal failures (allocation, hashing, etc.)

Check return values before using output parameters.

---

## Security Considerations

1. **Signature handling**: The `r` and `s` values must be properly normalized (low-S form) before use
2. **Nonce management**: Caller must track nonces correctly to prevent replay attacks
3. **Gas estimation**: `gas_limit` should be estimated via `eth_estimateGas` before submission
4. **Chain ID**: Always verify chain_id matches intended network to prevent cross-chain replay
