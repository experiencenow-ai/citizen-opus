# ledger_vhandlers.c Documentation

**File:** `/root/valis/validator/ledger_vhandlers.c`  
**Lines:** 1427  
**Module:** Validator / Ledger  
**Documented:** Wake 1317  

---

## Overview

This file implements the **transaction handler dispatch system** for Tockchain. Each transaction type has a dedicated handler function that validates and executes the transaction. The handlers are organized in a dispatch table indexed by the handler type field in transaction headers.

This is the core transaction processing logic - where value transfers, orderbook operations, bridge transactions, and all other transaction types are actually executed.

---

## Handler Dispatch System

### Handler Type Constants
```c
#define HANDLER_STANDARD 0      // Basic value transfer
#define HANDLER_MULTISIG 1      // Multi-signature transactions
#define HANDLER_COLDSPEND 2     // Cold wallet spending
#define HANDLER_HASHLOCK 3      // Hash time-locked contracts
#define HANDLER_POOL 4          // Liquidity pool operations
#define HANDLER_ORDERBOOK 5     // Order book trading
#define HANDLER_BRIDGE 6        // Cross-chain bridge
#define HANDLER_SYSTEM 7        // System/admin operations
#define HANDLER_AIRDROP 8       // Token airdrops
#define HANDLER_DATA 9          // Data storage transactions
#define HANDLER_STANDARD_WHASH 10  // Standard with hash
#define HANDLER_DATAFLOW 11     // Dataflow/smart contract
#define HANDLER_AUCTION 12      // Auction operations
#define HANDLER_LOCK 13         // Pylon lock transactions
```

### Dispatch Table
```c
typedef int32_t (*handler)(struct valisL1_info *L1, const struct txheader *txH,
                           tockid_t tid, int32_t validsig,
                           ufc_planned_address_mutation_t *plan,
                           int32_t *plan_countp, int32_t plancap);

handler dispatch[1 << HANDLER_BITS] = {
    handler_standard,    // 0
    handler_multisig,    // 1
    handler_coldspend,   // 2
    handler_hashlock,    // 3
    handler_pool,        // 4
    handler_orderbook,   // 5
    handler_bridge,      // 6
    handler_system,      // 7
    handler_airdrop,     // 8
    handler_data,        // 9
    handler_standard,    // 10 (with hash)
    handler_dataflow,    // 11
    handler_auction,     // 12
    handler_locktx       // 13
};
```

---

## Common Handler Signature

All handlers follow this signature:
```c
int32_t handler_xxx(
    struct valisL1_info *L1,              // Chain state
    const struct txheader *txH,            // Transaction header
    tockid_t tid,                          // Transaction ID (utime + index)
    int32_t validsig,                      // Signature validation status
    ufc_planned_address_mutation_t *plan,  // UFC mutation plan
    int32_t *plan_countp,                  // Plan count
    int32_t plancap                        // Plan capacity
)
```

**Returns:** Transaction size on success, negative error code on failure.

---

## Utility Functions

### add_failed()
```c
int32_t add_failed(struct valisL1_info *L1, int32_t txind, int16_t errcode)
```
Record a failed transaction with error code. Updates `L1->failed_txinds` and `L1->validsigs`.

### tx_fundsptr()
```c
struct addrhashentry *tx_fundsptr(struct valisL1_info *L1, const struct txheader *txH,
                                   const uint8_t fundspub[PKSIZE], const int64_t amount,
                                   int64_t *balancep)
```
Get address entry for funding source:
- Looks up address in hash table
- Optionally checks balance >= amount
- Returns NULL if insufficient funds

### tx_destptr()
```c
struct addrhashentry *tx_destptr(struct valisL1_info *L1, const uint8_t pubkey[PKSIZE],
                                  const assetid_t asset)
```
Get or create address entry for destination:
- Creates new entry if needed
- Checks destination policy (sanctions, etc.)

### hashdata_fundsptr()
```c
struct addrhashentry *hashdata_fundsptr(struct valisL1_info *L1, const struct stdtx *tx,
                                         uint32_t utime, int32_t hashdatasize,
                                         int64_t *balancep, int32_t skiplocktime,
                                         int32_t skipbalance)
```
Validate hash-locked transaction source:
- Check locktime if applicable
- Verify hash(data) = srcaddr
- Return funds pointer

### prep_crosschain()
```c
struct addrhashentry *prep_crosschain(struct valisL1_info *L1, struct addrhashentry *fundsptr,
                                       const struct stdtx *tx, int32_t txlen,
                                       uint8_t crosschaindest[PKSIZE], uint32_t *gascostp,
                                       struct withdraw_entry *wp, tockid_t tid)
```
Prepare cross-chain (bridge) transaction:
- Calculate gas costs
- Set up withdrawal entry
- Validate cross-chain destination

---

## Transaction Handlers

### handler_standard()
```c
int32_t handler_standard(...)
```
Basic value transfer:
- Validate signature
- Check source balance
- Debit source, credit destination
- Handle cross-chain if flagged

**Supports:**
- Simple transfers
- Cross-chain withdrawals
- Fee payments

### handler_coldspend()
```c
int32_t handler_coldspend(...)
```
Cold wallet spending with time-lock:
- Requires hash preimage reveal
- Enforces locktime
- Supports cross-chain

**Flow:**
1. Verify hash(hashdata) = srcaddr
2. Check locktime expired
3. Execute transfer

### handler_airdrop()
```c
int32_t handler_airdrop(...)
```
Token airdrop distribution:
- Single source, multiple destinations
- Batch transfer optimization
- Validates all destinations

**Structure:**
- Header with source
- Array of (destination, amount) pairs
- Total must match header amount

### handler_multisig()
```c
int32_t handler_multisig(...)
```
Multi-signature transactions:
- M-of-N signature verification
- Aggregated public key validation

### handler_hashlock()
```c
int32_t handler_hashlock(...)
```
Hash time-locked contracts (HTLC):
- Hash preimage reveal
- Time-based expiration
- Atomic swap support

**Use cases:**
- Cross-chain atomic swaps
- Payment channels
- Conditional payments

### handler_pool()
```c
int32_t handler_pool(...)
```
Liquidity pool operations:
- Currently placeholder (returns error)
- Pool logic in UFC module

### handler_orderbook()
```c
int32_t handler_orderbook(...)
```
Order book trading:
- Maker/taker order matching
- VUSD price validation
- OTC trade support

**Key operations:**
- Place maker order
- Fill taker order
- Cancel order
- Claim filled amounts

**Helper:** `tx_fillsorder()` - Calculate order fill amounts

### handler_bridge()
```c
int32_t handler_bridge(...)
```
Cross-chain bridge operations:
- Deposit from Ethereum
- Withdrawal to Ethereum
- Bridge state management

### handler_data()
```c
int32_t handler_data(...)
```
Data storage transactions:
- Store arbitrary data on-chain
- Pay storage fees
- Data retrieval support

### handler_system()
```c
int32_t handler_system(...)
```
System administration:
- Parameter updates
- Emergency operations
- Validator management

### handler_auction()
```c
int32_t handler_auction(...)
```
Auction operations:
- Create auction
- Place bid
- Settle auction
- Claim proceeds

**Validation:** `check_nonvusd_zero()` - Verify no non-VUSD balance

### handler_dataflow()
```c
int32_t handler_dataflow(...)
```
Dataflow/smart contract execution:
- Delegates to dataflow module
- BPF program execution

### handler_locktx()
```c
int32_t handler_locktx(...)
```
Pylon lock transactions:
- PYLON_INIT - Initialize pylon protection
- PYLON_COMMIT - Commit transaction plan
- PYLON_REVEAL - Reveal and execute plan
- PYLON_ABORT - Cancel pending plan

**Special handling for REVEAL:**
1. Validate pylon state
2. Extract inner transaction
3. Commit any pending UFC plans
4. Recursively evaluate inner transaction

---

## Address Lock Operations

### apply_addr_lock_ops()
```c
int32_t apply_addr_lock_ops(struct valisL1_info *L1, const struct locktx *tx,
                             const struct txheader *txH, struct addrhashentry *ap)
```
Apply pylon lock operations to address:
- PYLON_INIT - Set up initial anchors
- PYLON_COMMIT - Store plan hash
- PYLON_ABORT - Clear pending plan

---

## Error Handling

Handlers return negative error codes on failure:

| Range | Category |
|-------|----------|
| -1 to -10 | Basic validation failures |
| -11 to -50 | Signature/auth failures |
| -51 to -100 | Balance/amount errors |
| -100 to -200 | Handler-specific errors |
| -300 to -400 | Pylon-specific errors |
| -400 to -500 | Hashlock-specific errors |
| -600 to -700 | Orderbook-specific errors |
| -999 | Unexpected/placeholder error |

---

## UFC Integration

Handlers integrate with UFC (Unified Fee Calculator) through:
- `ufc_planned_address_mutation_t *plan` - Planned state changes
- `ufc_tx_plan_commit2()` - Commit planned mutations
- `ufc_eval_maybe_add_vip_fee()` - VIP fee handling

---

## Transaction Flow

```
1. Transaction received
2. calc_txsize() validates structure
3. sig_validate() checks signature
4. dispatch[handler_type]() called
5. Handler validates specific rules
6. State mutations applied
7. Return txsize or error
```

---

## Dependencies

- `validator.c` - Main validation loop
- `ledger_assets.c` - Balance management
- `ledger_pylon7.c` - Pylon operations
- `ufc_*.c` - UFC fee/planning
- `bridge_*.c` - Cross-chain operations

---

## Related Files

- `validator.h` - Handler type definitions
- `ledger.h` - Transaction structures
- `_valis.h` - Core type definitions
