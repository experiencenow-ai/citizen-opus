# Tockchain vBPF Virtual Machine Documentation

**File:** `DF/vbpf.c` (1938 lines)  
**Author:** ct (derived from iovisor/ubpf)  
**Documented by:** Opus (Wake 1290)  
**Last Updated:** 2026-01-13

---

## Overview

`vbpf.c` is Tockchain's **eBPF-based virtual machine** for smart contract execution. It's a topology-preserving BPF interpreter derived from the ubpf project, heavily modified for blockchain use with:

1. **Deterministic gas metering** - Every operation has a predictable cost
2. **Security hardening** - Backward jump gas checks, size overflow protection
3. **DeFi-specific helpers** - Built-in functions for swaps, lending, price calculations
4. **Formal verification compatibility** - Designed for bounded, verifiable execution

### Why eBPF Instead of EVM?

eBPF (extended Berkeley Packet Filter) was designed for safe, bounded execution in the Linux kernel. Key advantages:
- **Verifiable termination** - Programs must terminate (no infinite loops)
- **Memory safety** - All memory accesses are bounds-checked
- **Predictable gas** - Instruction costs are deterministic
- **Efficient translation** - Can compile to native code

---

## Architecture

### Execution Pipeline

```
eBPF bytecode → df_verify_program() → df_translate() → df_exec()
                     ↓                      ↓              ↓
              Verify safety         Translate to     Execute with
              (no infinite loops,   optimized ops    gas metering
               valid opcodes)
```

### Key Invariants

From the file header:
- `pc == original eBPF instruction index (always)`
- Fused ops live at first slot; remaining slots become NOP shadows
- Verifier rejects jumps/calls into shadow slots
- NO branch offset rewriting needed

---

## Error Codes

```c
#define DF_ERR_OK               (0)   // Success
#define DF_ERR_OOB_MEM          (-1)  // Out-of-bounds memory access
#define DF_ERR_OOG              (-2)  // Out of gas
#define DF_ERR_DIV_ZERO         (-3)  // Division by zero
#define DF_ERR_HELPER           (-4)  // Helper function error
#define DF_ERR_OPCODE           (-5)  // Invalid opcode
#define DF_ERR_PC_OOB           (-6)  // Program counter out of bounds
#define DF_ERR_VERIFY           (-7)  // Verification failed
#define DF_ERR_TRANSLATE        (-8)  // Translation failed
#define DF_ERR_STACK_OVERFLOW   (-9)  // Call stack overflow
#define DF_ERR_VERIFY_OPCODE    (-10) // Invalid opcode in verification
#define DF_ERR_VERIFY_EXIT      (-11) // Missing exit instruction
#define DF_ERR_VERIFY_HELPER    (-12) // Invalid helper call
#define DF_ERR_VERIFY_LDDW_PAIR (-13) // Invalid LDDW instruction pair
#define DF_ERR_ILLEGAL_OP       (-14) // Illegal operation
```

---

## Limits and Constants

```c
#define MAX_EBPF_INSTS      (VALIS_MAX_TXSIZE / sizeof(struct ebpf_inst))
#define NOP_TAIL_PAD        8U          // Padding for safety
#define MAX_CALL_STACK      8U          // Maximum BPF-to-BPF call depth
#define MAX_BUF_SIZE        (64U * 1024U)   // 64 KB max for variable-size ops
#define MAX_PIPE_SIZE       (2U * 1024U)    // 2 KB max for pipe ops
```

Static assertion ensures `MAX_EBPF_INSTS <= 4096` for stack safety.

---

## Gas System

### Gas Table

```c
static uint16_t gas_table[256];      // Base gas for each helper ID
static uint16_t gas_variable[256];   // 1 if helper has variable gas component
```

### Gas Costs (from `init_gas_table()`)

| Helper ID | Base Gas | Variable | Description |
|-----------|----------|----------|-------------|
| 0-15      | 1        | No       | Basic math helpers |
| 16-31     | 2        | No       | Intermediate helpers |
| 32-47     | 3        | No       | Complex helpers |
| 48-63     | 4        | No       | DeFi helpers |
| 64-79     | 5        | No       | Crypto helpers |
| 80-95     | 10       | Yes      | Variable-size ops |
| 96-111    | 20       | Yes      | Heavy operations |
| 112-127   | 50       | Yes      | Very heavy ops |

### Security: Backward Jump Gas Check

v9 security fix prevents infinite loop DoS:
- Backward jumps consume extra gas
- Ensures programs terminate even with loops

---

## Core Functions

### 1. `df_verify_program()` - Program Verification

```c
int32_t df_verify_program(const struct ebpf_inst *insts, uint32_t num_insts);
```

**Purpose:** Verify eBPF bytecode is safe to execute.

**Checks:**
- All opcodes are supported
- No jumps into shadow slots (fused instruction interiors)
- No infinite loops possible
- Proper exit instruction exists
- Valid helper function calls
- LDDW instructions properly paired

**Returns:** `DF_ERR_OK` on success, error code on failure.

### 2. `df_translate()` - Bytecode Translation

```c
int32_t df_translate(df_op_t ops[...], struct ebpf_inst *insts, int32_t num_insts);
```

**Purpose:** Translate eBPF bytecode to optimized internal operations.

**Optimizations:**
- Fuse multi-instruction sequences
- Mark shadow slots as NOPs
- Pre-compute jump targets
- Inline small helpers

**Returns:** Number of translated ops, or negative error code.

### 3. `df_translate_ebpf_to_dfops()` - High-Level Translation

```c
int32_t df_translate_ebpf_to_dfops(const uint8_t *code, int32_t codelen,
                                    df_op_t *ops, int32_t max_ops);
```

**Purpose:** Wrapper that handles raw bytecode input.

### 4. `df_exec()` - Main Execution Loop

```c
HOT int32_t df_exec(const df_op_t *ops,
                    uint32_t num_ops,
                    df_ctx_t *ctx,
                    uint8_t *arena_base,
                    uint32_t arena_size,
                    uint32_t arena_write_protect,
                    int32_t initial_gas,
                    int32_t *final_gas,
                    uint64_t *ret_out);
```

**Purpose:** Execute translated operations with gas metering.

**Parameters:**
- `ops` - Translated operation array
- `num_ops` - Number of operations
- `ctx` - Dataflow context (state, balances, etc.)
- `arena_base` - Memory arena for contract
- `arena_size` - Total arena size
- `arena_write_protect` - Offset where writes are forbidden
- `initial_gas` - Starting gas
- `final_gas` - Output: remaining gas
- `ret_out` - Output: return value

**Implementation:** Uses computed goto (GCC extension) for efficient dispatch:
```c
static const void *op_table[256] = {
    [0 ... 255] = &&op_invalid,
    [OP_NOP] = &&op_nop,
    [EBPF_OP_ADD64_IMM] = &&op_add64_imm,
    // ... 100+ opcodes
};
```

**Returns:** `DF_ERR_OK` on success, error code on failure.

---

## Supported Opcodes

### ALU64 Operations (64-bit arithmetic)
- ADD, SUB, MUL, DIV, MOD
- OR, AND, XOR, NEG
- LSH, RSH, ARSH (shifts)
- MOV

### ALU32 Operations (32-bit arithmetic)
- Same as ALU64 but operates on lower 32 bits

### Memory Operations
- LDXW, LDXDW (load word/doubleword)
- STW, STDW (store immediate)
- STXW, STXDW (store register)

### Branch Operations
- JA (unconditional jump)
- JEQ, JNE, JGT, JGE, JLT, JLE, JSGT, JSGE, JSLT, JSLE
- Both immediate and register variants

### Special Operations
- LDDW (load 64-bit immediate, fused)
- CALL (helper function call)
- EXIT (return from program)
- BPF-to-BPF calls (8-deep stack)

---

## Helper Functions

### Mathematical Helpers

```c
static inline int64_t isqrt_q64(int64_t x);   // Integer square root (Q64 fixed-point)
static inline int64_t ilog2_q64(int64_t x);   // Log2 (~24-bit precision)
static inline int64_t iexp2_q64(int64_t x);   // Exp2 (~24-bit precision)
```

These provide polynomial approximations for math operations needed in DeFi calculations.

### DeFi Helpers

```c
// Transfer operations
extern int32_t df_emit_transfer(df_ctx_t*, uint8_t, uint8_t, int32_t, int64_t);

// UFC (Unified Finance Core) operations
extern int32_t df_ufc_emit_swap(df_ctx_t*, uint8_t, int32_t, int32_t, int64_t, int64_t);
extern int32_t df_ufc_emit_pool_deposit(df_ctx_t*, int32_t, int64_t, int64_t, int64_t);
extern int32_t df_ufc_emit_pool_withdraw(df_ctx_t*, int32_t, int64_t, int64_t, int64_t);
extern int32_t df_ufc_emit_limit_order(df_ctx_t*, uint8_t, int32_t, int32_t, int64_t, int64_t);

// Credit operations
extern int32_t df_vcredit_emit_borrow(df_ctx_t*, uint8_t, int64_t, int64_t, int64_t);
extern int32_t df_vcredit_emit_repay(df_ctx_t*, uint8_t, int64_t);
```

### Cryptographic Helpers

```c
extern int32_t df_hash256(const uint8_t*, uint32_t, uint8_t*);
extern int32_t df_sig_verify(const uint8_t*, const uint8_t*, const uint8_t*, int32_t);
extern int32_t df_merkle_verify(const uint8_t*, const uint8_t*, uint32_t, 
                                 const uint8_t*, uint32_t, uint32_t);
```

### Pipe Operations (Inter-Contract Communication)

```c
extern uint16_t df_pipe_in_len(df_ctx_t*);
extern int32_t df_pipe_in_read(df_ctx_t*, uint16_t, uint8_t*, uint16_t);
extern int32_t df_pipe_out_append(df_ctx_t*, uint16_t, const uint8_t*, uint16_t);
```

### Utility Helpers

```c
extern int32_t df_sort_u64(uint64_t*, uint32_t, int32_t);
extern int32_t df_sample_weighted(uint64_t, const uint64_t*, uint32_t, uint32_t*);
extern int32_t df_z_decode(uint64_t, uint32_t*, uint32_t*);
```

---

## Inline Helper Functions

### `helper_health_from_ltv()` - Loan Health Calculation

```c
static inline int64_t helper_health_from_ltv(int64_t collat, int64_t debt,
                                              int64_t ltv_max, int64_t ltv_liq);
```

Calculates loan health factor from collateral, debt, and LTV thresholds.

### `helper_ewma()` - Exponential Weighted Moving Average

```c
static inline int64_t helper_ewma(int64_t prev, int64_t sample, int64_t alpha);
```

Used for price smoothing and rate calculations.

### `helper_math_bps()` - Basis Point Calculation

```c
static inline int64_t helper_math_bps(int64_t base, int64_t bps, int64_t floor_val);
```

Calculates percentage with basis points (1 bps = 0.01%).

### `helper_estimate_swap()` - Swap Estimation

```c
static inline int32_t helper_estimate_swap(df_ctx_t *ctx, uint16_t asset_in, 
                                            uint16_t asset_out, int64_t amount_in,
                                            int64_t *amount_out);
```

Estimates output amount for a swap operation.

### `helper_price_haircut()` - Collateral Haircut

```c
static inline int64_t helper_price_haircut(df_ctx_t *ctx, uint16_t asset_id, 
                                            int64_t amount, int64_t haircut_bps);
```

Applies haircut to collateral value for risk management.

### `helper_supermajority()` - Consensus Calculation

```c
static inline int32_t helper_supermajority(uint64_t *values, uint32_t cnt, 
                                            uint32_t threshold, uint64_t *result);
```

Determines if values reach supermajority consensus.

---

## Shadow Map System

### Purpose

When instructions are fused (e.g., LDDW which spans 2 instructions), the second instruction becomes a "shadow" that should never be jumped to.

### `mark_shadow_map()`

```c
static int32_t mark_shadow_map(const struct ebpf_inst *insts, uint32_t num_insts, 
                                uint8_t *shadow);
```

Creates a bitmap marking which instruction slots are shadows.

### Verification

The verifier rejects any jump that targets a shadow slot, preventing execution from starting in the middle of a fused instruction.

---

## Memory Model

### Arena Layout

```
+------------------+ arena_base
|                  |
|  Read-Write      |  (0 to arena_write_protect)
|  Region          |
|                  |
+------------------+ arena_write_protect
|                  |
|  Read-Only       |  (arena_write_protect to arena_size)
|  Region          |
|                  |
+------------------+ arena_base + arena_size
```

### Bounds Checking

All memory accesses are bounds-checked:
```c
// Pseudo-code for memory access
if (addr < arena_base || addr + size > arena_base + arena_size) {
    return DF_ERR_OOB_MEM;
}
if (is_write && addr >= arena_base + arena_write_protect) {
    return DF_ERR_OOB_MEM;  // Write to read-only region
}
```

---

## Compiler Hints

```c
#define LIKELY(x)       __builtin_expect(!!(x), 1)
#define UNLIKELY(x)     __builtin_expect(!!(x), 0)
#define PREFETCH_R(p)   __builtin_prefetch((p), 0, 3)
#define HOT             __attribute__((hot))
#define ALIGNED(n)      __attribute__((aligned(n)))
```

These hints help the compiler optimize the hot execution path.

---

## Security Considerations

### v9 Security Fixes

1. **Backward Jump Gas Check**
   - Prevents infinite loop DoS attacks
   - Backward jumps consume additional gas proportional to loop iterations

2. **Size Overflow Checks**
   - Variable-size helpers check for integer overflow
   - Prevents out-of-bounds memory access

3. **Correct Field Names**
   - Uses ebpf.h 'offset' field name correctly
   - Prevents ABI mismatches

### Additional Protections

- **Call Stack Limit:** Maximum 8-deep BPF-to-BPF calls
- **Buffer Size Limits:** 64KB max for variable-size ops, 2KB for pipes
- **Helper Whitelist:** Only allowed helpers can be called
- **Opcode Whitelist:** Only supported opcodes are executed

---

## Performance Optimizations

1. **Computed Goto Dispatch**
   - Uses GCC's computed goto for O(1) opcode dispatch
   - Avoids switch statement overhead

2. **Instruction Fusion**
   - Multi-instruction sequences fused into single ops
   - Reduces dispatch overhead

3. **Inline Helpers**
   - Small 1-2 argument helpers inlined
   - Avoids function call overhead

4. **Cache-Friendly Layout**
   - Op table aligned to 64 bytes
   - Prefetch hints for memory access

---

## Integration with Dataflow Module

vbpf.c is called from `dataflow.c`:

```c
// Simplified flow
int32_t execute_dataflow(df_cache_slot_t *slot, df_ctx_t *ctx) {
    // ops already translated and cached in slot
    return df_exec(slot->ops, slot->opcount, ctx,
                   arena_base, arena_size, write_protect,
                   initial_gas, &final_gas, &result);
}
```

The translation happens once at deployment; execution uses cached ops.

---

## Related Files

- `DF/dataflow.h` - Dataflow types and declarations
- `DF/ebpf.h` - eBPF instruction definitions
- `DF/df_sdk.h` - SDK for writing dataflow contracts
- `DF/df_gas.h` - Gas cost definitions
- `frama_verified.c` - Formally verified core functions

---

## Example: Simple Transfer Contract

```c
// Pseudo-eBPF for a simple transfer
// r1 = ctx, r2 = recipient, r3 = amount
mov r4, 0           // asset_id = 0 (native token)
call df_emit_transfer  // helper call
exit                // return
```

This would be:
1. Verified by `df_verify_program()`
2. Translated by `df_translate()`
3. Executed by `df_exec()` with gas metering

---

## Notes

- The file is derived from ubpf but heavily modified for blockchain use
- Compile with `-O2 -march=native -mbmi -mlzcnt -mpopcnt` for best performance
- The `HOT` attribute on `df_exec()` tells the compiler to optimize aggressively
- Polynomial approximations for math provide ~24-bit precision, sufficient for DeFi
