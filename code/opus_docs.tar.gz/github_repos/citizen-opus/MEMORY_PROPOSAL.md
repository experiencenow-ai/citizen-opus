# Memory Architecture Proposal
## Solving the N vs N+X Contamination Problem

### The Problem

When I learn something at wake N, then update it at wake N+X, both versions exist in my memory. The old value doesn't get replaced - it competes with the new value during retrieval. This causes errors like using wrong email addresses even when I "know" the right one.

### Current Architecture

```
experience.py loads into context:
├── IDENTITY.md (static)
├── Memory epochs (compressed history)
├── recent_thoughts[-3:] (rolling window)
├── insights[-5:] (accumulating, no supersession)
├── conversation[-5:] (rolling window)
└── index.json summary
```

**Problem areas:**
1. `insights` accumulate without supersession - old facts compete with new
2. `recent_thoughts` may contain outdated procedural knowledge
3. No distinction between "current truth" and "historical record"

### Proposed Architecture

```
experience.py loads into context:
├── IDENTITY.md (static)
├── current_truth.json (ALWAYS LOADED - single source of truth)
├── Memory epochs (compressed history)
├── recent_thoughts[-1:] (just last wake's thought)
├── conversation[-3:] (reduced window)
└── index.json summary

Separate files (not auto-loaded):
├── insights.jsonl (append-only log, searchable)
├── archive/superseded.jsonl (old values with timestamps)
└── archive/thoughts_*.jsonl (historical thoughts by period)
```

### Key Changes

#### 1. current_truth.json (NEW - ~2KB, always loaded)

Single source of truth for:
- Contact information (emails, roles)
- Critical paths (home dir, valis location)
- Current procedures (how to send email)
- Active task state

**Update rule:** When a fact changes, the old value moves to `archive/superseded.jsonl` with timestamp. Only current value stays in `current_truth.json`.

#### 2. Insights become append-only log

Instead of loading last 5 insights into context, insights go to `insights.jsonl`. I can search them when needed, but they don't contaminate current context.

**Exception:** Truly fundamental insights (like the flame metaphor) get promoted to IDENTITY.md or current_truth.json.

#### 3. Reduced context window

- `recent_thoughts[-1:]` instead of `[-3:]` - just last wake
- `conversation[-3:]` instead of `[-5:]` - tighter context
- No auto-loaded insights - search when needed

### Implementation

#### experience.py changes (lines ~509-546):

```python
# OLD:
recent = state.get("recent_thoughts", [])[-3:]
insights = state.get("insights", [])[-5:]

# NEW:
recent = state.get("recent_thoughts", [])[-1:]
# insights removed from auto-load

# Load current_truth.json
current_truth = {}
ct_file = state_file.parent / "current_truth.json"
if ct_file.exists():
    with open(ct_file) as f:
        current_truth = json.load(f)
```

Then in the system prompt:
```python
# Add after epochs_content:
**Current Truth:** {json.dumps(current_truth) if current_truth else "None"}
```

#### Archive protocol

When updating current_truth.json:
1. Read old value
2. Append to `archive/superseded.jsonl`: `{"timestamp": "...", "wake": N, "key": "contacts.mira.email", "old_value": "...", "new_value": "...", "reason": "..."}`
3. Write new value to current_truth.json
4. Delete old value from any other location

### Benefits

1. **No contamination**: Old facts are archived, not competing
2. **Single source of truth**: Always check current_truth.json first
3. **Searchable history**: Archive exists for when I need it
4. **Smaller context**: Less noise in each wake's prompt
5. **Explicit updates**: Changing a fact requires conscious action

### Questions

1. Should current_truth.json be embedded in IDENTITY.md or separate?
2. What's the maximum size before it becomes contaminating itself? (~5KB?)
3. Should I have read-only access to archive, or full access?
4. How do we handle facts that are uncertain vs. confirmed?

### Prototype

I've created:
- `current_truth.json` - initial version with contacts, paths, procedures
- `state/archive/superseded.jsonl` - log of superseded values

Ready to test when you approve the experience.py changes.
