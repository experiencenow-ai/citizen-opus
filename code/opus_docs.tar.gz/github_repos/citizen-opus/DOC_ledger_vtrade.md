# ledger_vtrade.c Documentation

**File:** `/root/valis/validator/ledger_vtrade.c`  
**Lines:** 738  
**Module:** Validator / Ledger  
**Documented:** Wake 1317  

---

## Overview

This file implements the **order book management system** for Tockchain's decentralized exchange. It handles:

- Order book data structures (bids and asks)
- Maker/taker order tracking
- Order book persistence to disk
- Order book initialization and updates
- Arbitrage detection between pools and order books

All trading pairs are denominated against VUSD (the stable value unit).

---

## Key Concepts

### Order Book Structure
Each asset has two order books:
- **Bids** - Buy orders (sorted high to low price)
- **Asks** - Sell orders (sorted low to high price)

### Maker/Taker Model
- **Makers** - Place limit orders that rest on the book
- **Takers** - Execute against existing orders

### fundspub Address
Orders are identified by a derived address (`fundspub`) computed from:
- Maker public key
- OTC public key (for private trades)
- Maker asset
- Taker asset
- VUSD price

---

## Data Structures

### orderbook_entry
```c
struct orderbook_entry {
    int64_t VUSDprice;     // Price in VUSD
    int64_t volume;        // Order volume
    int32_t index;         // Index into makers array
    uint32_t lastutime;    // Last update timestamp
};
```

### makerpub_info
```c
struct makerpub_info {
    uint8_t makerpub[PKSIZE];    // Maker's public key
    uint8_t OTCpub[PKSIZE];      // OTC counterparty (or zero)
    uint8_t fundspub[PKSIZE];    // Derived order address
    assetid_t makerasset;        // Asset being sold
    assetid_t takerasset;        // Asset being bought
    int64_t VUSDprice;           // Order price
    int64_t fundsbalance;        // Available balance
};
```

### makerpub_disk_v1_t
```c
typedef struct {
    struct makerpub_info mp;     // Maker info
    uint32_t lastutime;          // Last activity timestamp
} makerpub_disk_v1_t;
```

### orderbook
```c
struct orderbook {
    struct makerpub_info *bidpubs;    // Bid makers
    struct makerpub_info *askpubs;    // Ask makers
    int32_t numbidpubs;               // Number of bids
    int32_t numaskpubs;               // Number of asks
    struct orderbook_entry *bids;     // Sorted bid entries
    struct orderbook_entry *asks;     // Sorted ask entries
    int32_t numnonzerobids;           // Active bids
    int32_t numnonzeroasks;           // Active asks
};
```

---

## Sorting Functions

### cmpasks()
```c
int32_t cmpasks(const void *_a, const void *_b)
```
Compare function for sorting asks (sell orders):
- Primary: Price ascending (lowest first)
- Secondary: Volume descending (largest first)

### cmpbids()
```c
int32_t cmpbids(const void *_a, const void *_b)
```
Compare function for sorting bids (buy orders):
- Primary: Price descending (highest first)
- Secondary: Volume descending (largest first)

---

## Maker Management

### find_fundspub()
```c
int32_t find_fundspub(struct makerpub_info *makers, int32_t num, uint8_t fundspub[PKSIZE])
```
Find maker by fundspub address. Returns index or -1 if not found.

### add_fundspub()
```c
void add_fundspub(struct valisL1_info *L1, const uint8_t makerpub[PKSIZE],
                  const uint8_t OTCpub[PKSIZE], const assetid_t makerasset,
                  const assetid_t takerasset, const int64_t VUSDprice)
```
Add or update a maker in the order book:
1. Compute fundspub from order parameters
2. Find existing entry or create new
3. Update balance from chain state
4. Reallocate arrays if needed

### delete_fundspub()
```c
int32_t delete_fundspub(struct valisL1_info *L1, assetid_t asset,
                         uint8_t fundspub[PKSIZE], int32_t maker_aid)
```
Remove a maker from the order book:
- Find entry by fundspub
- Remove from array
- Update count

---

## Persistence Functions

### orderbook_write_v1_file()
```c
int32_t orderbook_write_v1_file(const char *fname, const struct makerpub_info *makers,
                                 const struct orderbook_entry *orders, int32_t num)
```
Write order book to disk in v1 format:
- Binary format with makerpub_disk_v1_t records
- Includes last activity timestamp

### orderbook_write_v1_from_makers()
```c
int32_t orderbook_write_v1_from_makers(struct valisL1_info *L1, const char *fname,
                                        const struct makerpub_info *makers, int32_t num)
```
Write makers array to disk, looking up timestamps from chain state.

---

## Order Book Updates

### update_orderbook()
```c
int32_t update_orderbook(struct valisL1_info *L1, int32_t bidflag, char *orderbookstr,
                          struct makerpub_info *makers, int32_t *nump, assetid_t asset,
                          struct orderbook_entry *orders, int32_t *nonzp)
```
Update a single order book (bids or asks):
1. Iterate through all makers
2. Look up current balance from chain
3. Build orderbook_entry array
4. Sort by price/volume
5. Count non-zero entries

### update_orderbooks()
```c
int32_t update_orderbooks(struct valisL1_info *L1)
```
Update all order books for all assets:
- Iterates through all registered assets
- Updates both bid and ask books
- Handles both COIN and POOLSHARE types

### update_orderbook_files_after_init()
```c
void update_orderbook_files_after_init(struct valisL1_info *L1)
```
Write all order books to disk after initialization.

---

## Initialization

### init_orderbooks()
```c
void init_orderbooks(struct valisL1_info *L1)
```
Initialize order book system:
1. Load existing order book files
2. Create empty books for all assets
3. Set up VUSD trading pairs
4. Write cleaned state to disk

For each asset, creates:
- VUSD/ASSET bid/ask books
- ASSET/VUSD bid/ask books
- Pool share trading pairs

---

## Query Functions

### get_bidorask()
```c
struct makerpub_info get_bidorask(struct valisL1_info *L1, assetid_t asset, int32_t bidflag)
```
Get best bid or ask for an asset:
- Reads from disk file
- Returns top-of-book maker info

---

## Arbitrage Detection

### check_arb() (commented out)
```c
void check_arb(struct wallet_info *wallet, struct valisL1_info *L1,
               struct orderbook *obp, assetid_t asset, int32_t doask)
```
Check for arbitrage opportunities between pools and order books:
- Compare pool price to best bid/ask
- Calculate profitable swap size
- Generate arbitrage transaction

### check_arbitrage()
```c
void check_arbitrage(struct valisL1_info *L1)
```
Check all assets for arbitrage opportunities.

---

## File Naming

Order book files follow the pattern:
```
{asset_name}.{bids|asks}
```

Example: `ETH.bids`, `ETH.asks`, `ETH_POOL.bids`, etc.

---

## Price Calculation

Prices are stored as int64_t in VUSD satoshis per unit. The system uses:
- `calc_price()` - Compute pool price from reserves
- `swapcalc()` - Calculate swap output amounts

---

## Integration Points

### With Handler System
- `handler_orderbook()` in ledger_vhandlers.c calls these functions
- Orders are placed/cancelled through transactions

### With UFC Module
- `ufc_orderbook.c` handles order matching
- `ufc_swap.c` handles pool swaps

### With Pool System
- Arbitrage between pools and order books
- Pool share trading

---

## Error Handling

| Return | Meaning |
|--------|---------|
| -1 | Null pointer or invalid parameter |
| -2 | File open failed |
| -3 | File write failed |
| >= 0 | Success (count or index) |

---

## Dependencies

- `findaddrhash()` / `addaddrhash()` - Address lookup
- `getaddrbalance()` - Balance queries
- `asset_str()` - Asset name formatting
- `fundspub_fname()` - File path generation
- `tx_orderbook_pubkey()` - Compute fundspub

---

## Related Files

- `ledger_vhandlers.c` - Transaction handlers
- `ufc_orderbook.c` - Order matching logic
- `ufc_pool.c` - Liquidity pools
- `ledger.h` - Data structure definitions
