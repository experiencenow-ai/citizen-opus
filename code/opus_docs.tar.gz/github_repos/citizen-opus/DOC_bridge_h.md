# bridge/bridge.h Documentation

## Overview

**File:** `bridge/bridge.h`  
**Lines:** 687  
**Purpose:** Main header file for the Ethereum-Tockchain bridge - defines all structures, constants, and function prototypes for cross-chain operations

The Ethereum bridge enables:
1. **Deposits**: Moving assets from Ethereum to Tockchain (ETH, ERC-20 tokens)
2. **Withdrawals**: Moving assets from Tockchain back to Ethereum
3. **Proof Verification**: Validating Ethereum state using Merkle Patricia Tries (MPT)
4. **ABI/RLP Encoding**: Serializing data for Ethereum compatibility

---

## Dependencies

```c
#include <curl/curl.h>       // HTTP client for RPC calls
#include "yyjson.h"          // Fast JSON parsing
#include "_valis.h"          // Core Valis types
#include "bridge_rpc.h"      // RPC-specific types
#include "ledger.h"          // Ledger state management
```

---

## Configuration Constants

### Network Configuration

| Constant | Value | Description |
|----------|-------|-------------|
| `ETH_REMOTE_URL` | `CONFIG.ethrpc` | Remote Ethereum RPC endpoint |
| `ETH_LOCAL_URL` | `"http://127.0.0.1:8545"` | Local node fallback |
| `ETH_FAST_SYNC_WINDOW` | `500000` | Block range for fast sync |
| `ETHRPC_TEMP_BUFSZ` | `262144` | 256KB temp buffer for RPC |
| `ETHRPC_PARAMS_BUFSZ` | `8192` | 8KB params buffer |
| `ETHRPC_HTTP_TIMEOUT_SEC` | `30` | HTTP request timeout |
| `ETHRPC_HTTP_CONNECT_SEC` | `10` | Connection timeout |

### Contract Addresses (Ethereum Mainnet)

| Constant | Address | Purpose |
|----------|---------|---------|
| `SAFECONTRACT` | `0xec4512f4da32c510128515a2eacc477e06f9abb6` | Safe multisig for withdrawals |
| `WITHDRAW_MODULE` | `0xd5e153efbc5863dc5d756126b3fe6ce2b2f61e66` | Withdrawal execution module |
| `READER_CONTRACT` | `0x805B91Eb96E44a337E91C4a4566ee6c8fB4B9403` | On-chain state reader |
| `DEPOSIT_CONTRACT` | `0x136deaBcd151E7eeEEc7FbEA2Cbe0346C83E6Bdc` | ETH deposit contract |
| `USDTDEPOSIT_CONTRACT` | `0x0be8642bb98182bb71e03fda2403b29e153bbeb1` | USDT-specific deposit |
| `USDT_CONTRACT` | `0xdAC17F958D2ee523a2206206994597C13D831ec7` | USDT token address |
| `WETH_CONTRACT` | `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2` | Wrapped ETH address |

### Function Selectors (4-byte Keccak prefixes)

| Selector | Function | Description |
|----------|----------|-------------|
| `0x186f0354` | `safe()` | Get Safe address |
| `0xaffed0e0` | `nonce()` | Get current nonce |
| `0xd68d9d4e` | `depositETH(bytes32)` | Deposit ETH with recipient |
| `0x84abac95` | `depositToken(address,uint256,bytes32)` | Deposit ERC-20 |
| `0x095ea7b3` | `approve(address,uint256)` | ERC-20 approval |
| `0x70a08231` | `balanceOf(address)` | ERC-20 balance query |
| `0xdd62ed3e` | `allowance(address,address)` | ERC-20 allowance query |

### Gas Limits

| Constant | Value | Description |
|----------|-------|-------------|
| `ETH_GASLIMIT` | `0x5208` (21000) | Standard ETH transfer |
| `ERC20_GASLIMIT_DECIMAL` | `150000` | ERC-20 transfer limit |
| `MIN_ERC20_GASCOST` | `50000` | Minimum ERC-20 gas |
| `MAX_ERC20_GASCOST` | `200000` | Maximum ERC-20 gas |
| `ETH_GASTOLERANCE` | `SATOSHIS * 4 / 3` | 33% gas price premium |

---

## Deposit State Machine

Deposits progress through these states:

```
DEPOSIT_STARTED (1)
    ↓
DEPOSIT_HAVE_BLOCKHASH (2)
    ↓
DEPOSIT_PENDING_PROOF (3)
    ↓
DEPOSIT_HAVE_PROOF (4)
    ↓
DEPOSIT_PENDING_DATATX (5)
    ↓
DEPOSIT_HAVE_DATATX (6)
    ↓
DEPOSIT_HAVE_QUORUM (7)
    ↓
DEPOSIT_PENDING_MINT (8)
    ↓
DEPOSIT_FINISHED (9)
```

**Error States:**
- `DEPOSIT_ERROR (-1)` - Generic error
- `DEPOSIT_EXPIRED (-2)` - Proof window expired
- `DEPOSIT_PROOFGEN_ERROR (-3)` - Proof generation failed
- `DEPOSIT_DATATX_CREATE_ERROR (-4)` - Data TX creation failed
- `DEPOSIT_DATATX_CONFIRM_ERROR (-5)` - Data TX confirmation failed
- `DEPOSIT_BROADCAST_ERROR (-6)` - Broadcast failed
- `DEPOSIT_MINT_CREATE_ERROR (-7)` - Mint TX creation failed
- `DEPOSIT_MINT_CONFIRM_ERROR (-8)` - Mint TX confirmation failed

---

## Core Data Structures

### RLP Item (Parsing)

```c
struct rlp_item {
    const uint8_t *data;  // Pointer to RLP data
    int32_t len;          // Length of data
    int32_t is_list;      // 1 if list, 0 if string
};
```

### Ethereum Header

```c
typedef struct eth_header {
    uint8_t  blockhash[32];     // keccak256(RLP(header))
    uint8_t  parenthash[32];    // header[0]
    uint8_t  txroot[32];        // header[4] - transaction root
    uint8_t  receiptsroot[32];  // header[5] - receipts root
    uint32_t blocknum;          // header[8], host-endian
    uint32_t timestamp;         // header[11], host-endian
} eth_header_t;
```

### MPT Proof

```c
struct eth_mpt_proof {
    uint8_t root[32];                    // Expected root hash
    uint64_t index;                      // Key index in trie
    int32_t num_nodes;                   // Number of proof nodes
    int32_t datalen;                     // Total data length
    int32_t node_lens[MAX_MPT_NODES];    // Length of each node
    uint8_t data[];                      // Flexible array of node data
};
```

**Note:** `MAX_MPT_NODES = 64` - Maximum depth of MPT proof

### Receipt Structures

**Transfer Event:**
```c
typedef struct receipt_transfer_s {
    uint8_t value_be32[32];       // Transfer amount (big-endian)
    uint8_t contract_addr20[20];  // Token contract
    uint8_t from_addr20[20];      // Sender
    uint8_t to_addr20[20];        // Recipient
    uint8_t pad[4];               // Alignment padding
} receipt_transfer_t;
```

**Deposit Event:**
```c
typedef struct receipt_deposit_s {
    uint8_t recipient_pubkey32[32];  // Tockchain recipient (32-byte pubkey)
    uint8_t amount_be32[32];         // Deposit amount
    uint8_t nonce_be32[32];          // Deposit nonce
    uint8_t block_number_be32[32];   // Block number
    uint8_t contract_addr20[20];     // Deposit contract
    uint8_t depositor_addr20[20];    // Ethereum depositor
    uint8_t token_addr20[20];        // Token (or 0x0 for ETH)
    uint8_t pad[4];                  // Alignment padding
} receipt_deposit_t;
```

---

## Withdrawal Structures

### Withdraw Leaf (Solidity-aligned)

```c
typedef struct withdraw_leaf_s {
    uint8_t withdraw_id[32];      // Unique withdrawal ID
    uint8_t token_addr20[20];     // Token to withdraw
    uint8_t recipient_addr20[20]; // Ethereum recipient
    uint8_t amount_be32[32];      // Amount (big-endian)
} withdraw_leaf_t;
```

### Batch Token

```c
typedef struct batch_token_s {
    uint8_t token_addr20[20];  // Token address
    uint8_t total_be32[32];    // Total amount for this token
} batch_token_t;
```

### Approval Batch

Matches Solidity `ApprovalBatch` struct:
```c
typedef struct approval_batch_s {
    uint8_t batchhash[32];           // Hash of the batch
    uint8_t batch_root[32];          // Merkle root of leaves
    uint64_t batch_value_usd64;      // USD value of batch
    uint64_t bridge_value_usd64;     // USD value in bridge
    uint64_t lifetime_batch_index;   // Global batch counter
    uint32_t signer_set_epoch;       // Signer set version
    uint32_t utime_sec;              // Unix timestamp
    uint8_t leaf_count;              // Number of leaves
    uint8_t num_tokens;              // Number of unique tokens
    // Followed by BatchToken[] tokens
} approval_batch_t;
```

---

## Deposit Binding (Cryptographic Proof)

The deposit binding creates a cryptographic commitment to all deposit parameters:

```c
typedef struct deposit_binding_preimage {
    uint8_t receiptsRoot[32];   // From verified Ethereum header
    uint8_t txRoot[32];         // From verified Ethereum header
    uint8_t deposit_txid[32];   // Proven via TX MPT proof
    uint8_t local_idx_be[2];    // Receipt log index (big-endian)
    uint8_t recipient[32];      // Tockchain recipient pubkey
    uint8_t amount[32];         // Deposit amount
    uint8_t token[20];          // Token address
} deposit_binding_preimage_t;
```

**Binding calculation:**
```
binding = keccak256(receiptsRoot || txRoot || deposit_txid || 
                    local_idx_be || recipient || amount || token)
```

Total preimage: 182 bytes

---

## Helper Types

### Logs Filter Parameters

```c
typedef struct LogsFilterParams_s {
    const char *address;     // Contract address filter
    uint64_t from_block;     // Start block
    uint64_t to_block;       // End block
    const char *topic;       // Event topic filter
} LogsFilterParams;
```

### Block Stamp (Compact)

```c
typedef struct blockstamp_s {
    uint64_t timestamp:32;  // Unix timestamp
    uint64_t blocknum:30;   // Block number
    uint64_t send:1;        // Is send operation
    uint64_t recv:1;        // Is receive operation
} blockstamp_t;
```

### ABI Buffer

```c
typedef struct vabi_buf_s {
    uint8_t *data;   // Buffer data
    int32_t len;     // Current length
    int32_t cap;     // Capacity
} vabi_buf_t;
```

### Signer Status

```c
typedef struct {
    bool ok;           // Is valid signer
    uint8_t tier;      // Signer tier (0-2)
    uint32_t epoch;    // Signer set epoch
    uint64_t weight;   // Voting weight
} vwr_signer_now_t;
```

---

## Function Categories

### RLP Encoding Functions

**Length Calculators** (no allocation, return encoded size):
- `rlp_calc_len_bytes(src, len)` - Byte array
- `rlp_calc_len_list(payload_len)` - List wrapper
- `rlp_calc_len_uint64(v)` - 64-bit integer
- `rlp_calc_len_address(addr20, is_null)` - 20-byte address
- `rlp_calc_len_u256_be32(be32)` - 256-bit big-endian
- `rlp_calc_len_data(p, len)` - Arbitrary data

**Writers** (write to buffer, return pointer past written data):
- `rlp_write_bytes(dst, src, len)`
- `rlp_write_list(dst, payload_len)`
- `rlp_write_uint64(dst, v)`
- `rlp_write_address(dst, addr20, is_null)`
- `rlp_write_u256_be32(dst, be32)`
- `rlp_write_data(dst, p, len)`

**Parsing**:
- `parse_rlp(input, input_len, item)` - Parse single RLP item
- `rlp_list_count(list)` - Count items in RLP list
- `rlp_get_item(list, idx, out)` - Get item by index
- `rlp_u64_be(it)` - Extract uint64 from RLP item

### MPT Proof Functions

- `eth_mpt_proof_from_json_into_buffer(...)` - Parse JSON proof into buffer
- `eth_mpt_recompute_root(...)` - Verify proof by recomputing root
- `eth_mpt_proof_get_typed_receipt(...)` - Extract typed receipt from proof

### Receipt Parsing

- `eth_receipt_parse_events(...)` - Parse all events from receipt
- `eth_receipt_parse_from_proof(...)` - Parse receipt from MPT proof
- `parse_transfer_log(...)` - Parse ERC-20 Transfer event
- `parse_deposit_log(...)` - Parse Deposit event

### Withdrawal Functions

- `build_executeBatch_calldata(...)` - Build batch withdrawal calldata
- `build_executeLeafFallback_calldata(...)` - Build single leaf fallback
- `compute_approval_batch_structhash(...)` - Compute EIP-712 struct hash
- `merkle_proof_for_leaf_dup(...)` - Generate Merkle proof for leaf

### HTTP/RPC Functions

- `http_get(url, out, out_cap, timeout_sec)` - Simple HTTP GET
- `rpc_http_run(...)` - Execute RPC call with CURL

### Utility Functions

- `be_to_u64(b, n)` - Big-endian bytes to uint64
- `be_right_copy_hex(out32, contractaddr)` - Right-align hex address to 32 bytes
- `be_right_copy_to_32(out32, src, src_len)` - Right-align bytes to 32
- `central_hex_to_bin(hex, bin, max_out, out_len)` - Hex string to binary
- `get_event_sigs(dep, tr)` - Get Deposit and Transfer event signatures

---

## Inline Helper Functions

### Get Deposit Wire

```c
static inline eth_deposit_wire_t *get_deposit_wire(struct datatx *dtx) {
    return (eth_deposit_wire_t *)dtx->data;
}
```

### Get Deposit Proofs Pointer

```c
static inline uint8_t *get_deposit_proofs_ptr(struct datatx *dtx) {
    return dtx->data + ETH_DEPOSIT_WIRE_HEADER_SIZE;
}
```

---

## ABI Encoding Notes

From the header comments:

> **Top-level dynamic arg offsets:** from start of args (after 4-byte selector)
>
> **Nested dynamic inside a tuple:** from start of the tuple
>
> **Array-of-dynamic element head offsets:** from start of the heads table (after array length)
>
> **Always pad dynamic tails to 32-byte boundaries**

---

## ERC-20 Flags

```c
#define ERC20_TYPE_ERC20        1     // Standard ERC-20
#define ERC20_FLAG_PREAPPROVED  0x01  // Already approved for bridge
#define ERC20_FLAG_ASSET_CREATED 0x02 // Tockchain asset exists
#define ERC20_FLAG_DISABLED     0x04  // Token disabled
#define ERC20_FLAG_DIRTY        0x08  // Needs state update
```

---

## Questions/Notes for ct

1. **VUSD Mapping**: `VUSD_MAPPED_CONTRACT` points to USDT - is VUSD a Tockchain-native stablecoin backed by USDT?

2. **Deployment Block**: `DEPLOYMENT_BLOCK = 22947462` - is this the block where the deposit contract was deployed?

3. **YIELD_ADDRESS**: What is the yield contract used for?

4. **Signer Tiers**: The `vwr_signer_now_t` has a `tier` field (0-2). What do the tiers represent?

---

## Related Files

- `bridge_rlp.c` - RLP encoding/decoding implementation
- `bridge_abi.c` - ABI encoding implementation
- `bridge_mpt.c` - Merkle Patricia Trie verification
- `bridge_deposit.c` - Deposit processing logic
- `bridge_withdraw.c` - Withdrawal processing logic
- `ethrpc.c` - Ethereum RPC client

---

*Documentation generated: Wake 1280 (2026-01-13)*
*Documenter: Opus*
*Status: Awaiting audit*
