# Tockchain Dataflow Module Documentation

**File:** `DF/dataflow.c` (842 lines)  
**Header:** `DF/dataflow.h` (408 lines)  
**Author:** ct  
**Documented by:** Opus (Wake 1286)  
**Last Updated:** 2026-01-13

---

## Overview

The Dataflow (DF) module is Tockchain's smart contract execution engine. Unlike Ethereum's EVM, Tockchain uses an eBPF-based virtual machine for smart contract execution. This provides:

1. **Formal verifiability** - eBPF is designed for safe, bounded execution
2. **Deterministic gas metering** - Every operation has predictable cost
3. **Efficient translation** - eBPF bytecode translates to optimized native ops

The module handles:
- **Deployment** of new dataflow contracts (smart contracts)
- **Batch execution** of contract calls with gas accounting
- **Frontier management** for active contract scheduling
- **Trigger checking** for time-based contract activation
- **Module records** for named contract registration

---

## Architecture

### File Inclusion Pattern

`dataflow.c` is the main orchestration file that #includes other .c files:

```c
#include "dataflow.h"
#include "validator.h"
#include "dataflow_api.c"      // Host API functions for VM
#include "dataflow_cache.c"    // DF caching and lookup
#include "dataflow_batch.c"    // Batch transaction processing
#include "dataflow_frontier.c" // Active DF scheduling
#include "dataflow_trigger.c"  // Time-based triggers
```

This is a common C pattern for organizing large modules while keeping everything in one compilation unit.

### Key Data Structures

#### `df_state_t` - Global Dataflow State
```c
typedef struct {
    int32_t initialized;
    FILE *deploylog_fp;           // Deployment log file
    int32_t opslog_fd;            // Operations log file descriptor
    uint8_t *ops_base;            // Memory-mapped ops storage
    uint64_t ops_write_off;       // Current write offset
    uint32_t utime;               // Current block time
    uint8_t finalhash[32];        // Block hash
    df_tock_plans_t tock_plans;   // Planned mutations for this tock
    df_cache_slot_t DFtable[DFTABLE_SIZE];  // Cached DF contracts
    int32_t DFcached_count;       // Number of cached contracts
    df_heap_node_t DFheap[DF_ACTIVE_CAP];   // Priority heap for active DFs
    int32_t DFheap_n;             // Heap size
} df_state_t;
```

#### `df_cache_slot_t` - Cached Contract Entry
```c
typedef struct {
    df_tablekey_u64_t key;        // Lookup key
    int64_t crv;                  // Contract reserve value
    df_frontier_state_t frontier; // Frontier scheduling state
    df_meta_u_t df_meta;          // Contract metadata
    df_ops_meta_u_t df_ops_meta;  // Operations metadata
    df_op_t *ops;                 // Pointer to translated ops
    uint32_t opcount;             // Number of operations
    uint16_t mingas;              // Minimum gas required
    uint16_t reg_base;            // Base register index
    uint8_t reg_count;            // Number of registers
    uint16_t entrypoints[MAX_DF_ENTRYPOINTS]; // Function entry points
    uint8_t dfid[PKSIZE];         // Contract address (20 bytes)
} df_cache_slot_t;
```

#### `df_image_header_t` - Deployed Contract Header
```c
typedef struct {
    uint32_t magic;               // Magic number for validation
    uint8_t abi_version;          // ABI version (currently 0)
    uint8_t reg_count;            // Number of registers used
    uint16_t reg_base;            // Base register index
    uint16_t required_family;     // Required contract family (0 = none)
    uint16_t mingas;              // Minimum gas for execution
    uint32_t reg_extdelta_mask;   // External delta mask for registers
    uint16_t entrypoints[MAX_DF_ENTRYPOINTS]; // Function entry points
    uint32_t reserved0, reserved1;
} df_image_header_t;
```

#### `df_op_t` - Translated Operation
```c
typedef struct df_op {
    uint8_t opcode;               // Operation code
    uint8_t dst;                  // Destination register
    uint8_t src;                  // Source register
    uint8_t aux;                  // Auxiliary data
    int16_t off;                  // Offset
    uint8_t skip;                 // Skip count (for branching)
    uint8_t hid;                  // Helper ID (for syscalls)
    uint8_t arg_src[5];           // Argument sources
    int32_t imm;                  // Immediate value
    int64_t arg_imm[5];           // Argument immediates
} df_op_t;
```

---

## Gas Economics

### Constants (from `dataflow.h`)

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_GAS_PRICE_VUSD_SAT` | 1000 | Satoshis per gas unit (0.00001 VUSD/gas) |
| `DF_GAS_QUANTUM` | 100 | Gas charged in multiples of this |
| `DF_BATCH_GAS_CAP` | 1,000,000 | Max gas per batch TX (~$10) |
| `DF_UTIME_GAS_CAP` | 4,000,000,000 | Max gas per second (~8 cores) |
| `DF_FRONTIER_GAS_CAP` | 2,000 | Max gas for frontier scoring |
| `DF_TRIGGER_GAS_CAP` | 2,000 | Max gas for trigger checks |
| `DF_DEPLOY_FEE_FULL_VUSD` | 1 VUSD | Fee for full deployment |
| `DF_DEPLOY_FEE_RESTORE_VUSD` | 0.1 VUSD | Fee for restoration |

### Gas Flow

1. User submits batch TX with VUSD budget
2. Budget transferred to VNET pool
3. Gas consumed during execution
4. Excess returned to user (minus quantum rounding)

---

## Key Functions

### Tock Lifecycle

#### `df_tock_begin(L1, utime)`
Called at the start of each tock (time unit):
- Ensures cache is initialized
- Sets current time and block hash
- Initializes frontier pre-scan

#### `df_tock_end(L1, utime)`
Called at the end of each tock:
- Runs trigger checks for time-based activations
- Finalizes frontier state

### Deployment

#### `df_handler_dataflow_deploy_tx()`
Handles deployment of new dataflow contracts:

1. **Validate transaction fields**
   - Asset must be VUSD
   - Amount must cover deployment fee
   
2. **Copy image to scratch buffer**
   - Align for proper memory access
   - Validate image size
   
3. **Validate image header**
   - Check ABI version
   - Validate register counts
   - Verify entrypoints within bounds
   
4. **Compute DFID**
   - Hash the image bytes
   - Verify matches destination address
   
5. **Translate eBPF to native ops**
   - Verify program safety
   - Translate to optimized format
   
6. **Build mutation plan**
   - Transfer fee to pool
   - Set DF metadata on address
   - Store ops in opslog

### Validation Functions

#### `df_validate_image_header_basic(hdr)`
Validates a contract image header:
- ABI version must be current
- Required family must be 0
- Reserved fields must be 0
- Register count in valid range
- Register base + count within limit
- Minimum gas > 0

Returns: 0 on success, negative error code on failure

#### `df_validate_entrypoints_within_opcount(hdr, opcount)`
Ensures all entrypoints are valid instruction indices:
- Each non-zero entrypoint must be < opcount
- Prevents jumping outside code bounds

#### `df_ops_meta_validate_local(L1, om)`
Validates operations metadata:
- Ops base must be initialized
- Offset must be 16-byte aligned
- Length must be non-zero
- End must be within opslog bounds

### Operations Log Management

#### `df_opslog_prepare_region(L1, off_out, ops_out)`
Prepares a region in the opslog for writing:
- Aligns current write offset to 16 bytes
- Returns pointer to write location

#### `df_opslog_verify_translate(insts, num_insts, ops_dst, opcount_out)`
Verifies and translates eBPF instructions:
1. `df_verify_program()` - Safety verification
2. `df_translate()` - Convert to native ops

#### `df_opslog_build_meta(off, opcount, ops_meta_out, ops_after_out)`
Builds metadata for stored operations:
- Packs offset (48 bits) and length (16 bits)
- Validates bounds
- Returns next aligned offset

### Module Records

The module record system allows named registration of contracts with timelocks:

#### `df_modrec_pack_timepair(timelock_secs, activation_utime)`
Packs timelock and activation time into 64 bits:
- Lower 32 bits: timelock duration
- Upper 32 bits: activation timestamp

#### `df_modrec_unpack_timepair(packed, out_timelock, out_activation)`
Unpacks the time pair from storage.

#### `df_modrec_encode_key20_words3(in20, out3)`
Encodes a 20-byte key into 3 uint64 words for storage.

#### `df_modrec_encode_hash32_words4(in32, out4)`
Encodes a 32-byte hash into 4 uint64 words for storage.

#### `df_modrec_extract_planes_u64(ap, base_aid, active_words, pending_words)`
Extracts active and pending module record data from address storage.

---

## Error Codes

| Code | Name | Description |
|------|------|-------------|
| -1 | `DF_ERR_GENERIC` | Generic error |
| -2 | `DF_ERR_TX_FORMAT` | Transaction format invalid |
| -3 | `DF_ERR_DESCRIPTOR_INVALID` | Invalid descriptor |
| -10 | `DF_ERR_ADDR_SCOPE` | Address scope violation |
| -11 | `DF_ERR_SYNTHETIC_TRANSFER` | Invalid synthetic transfer |
| -20 | `DF_ERR_SPEND_LIST_INVALID` | Invalid spend list |
| -21 | `DF_ERR_SPEND_UNAUTHORIZED` | Unauthorized spend |
| -22 | `DF_ERR_SPEND_LIMIT_EXCEEDED` | Spend limit exceeded |
| -30 | `DF_ERR_EFFECT_CAP` | Effect capacity exceeded |
| -50 | `DF_ERR_OUT_OF_GAS` | Out of gas |
| -51 | `DF_ERR_OUT_OF_GLOBAL_GAS` | Global gas limit exceeded |
| -60 | `DF_ERR_PIPE_INVALID` | Invalid pipe |
| -61 | `DF_ERR_PIPE_COLLISION` | Pipe collision |
| -62 | `DF_ERR_PIPE_OUTPUT_TOO_LARGE` | Pipe output too large |
| -63 | `DF_ERR_DF_NO_ON_TX` | DF has no on_tx handler |
| -64 | `DF_ERR_DFID_MISMATCH` | DFID mismatch |
| -65 | `DF_ERR_DF_NOT_ACTIVE` | DF not active |
| -100 | `DF_E_DEPLOY_TXFIELDS_BAD` | Bad deployment TX fields |
| -101 | `DF_E_BATCH_CALLS_FAIL` | Batch calls failed |
| -102 | `DF_E_BATCH_ASSET_BAD` | Bad batch asset |
| -103 | `DF_E_BATCH_DEST_BAD` | Bad batch destination |
| -104 | `DF_E_BATCH_BUDGET_NEG` | Negative batch budget |
| -105 | `DF_E_BATCH_SRC_NOT_FOUND` | Batch source not found |
| -106 | `DF_E_BATCH_BUDGET_TOO_LOW` | Batch budget too low |
| -107 | `DF_E_BATCH_POOL_NOT_FOUND` | Batch pool not found |
| -108 | `DF_E_BATCH_GAS_TRANSFER_FAIL` | Gas transfer failed |
| -109 | `DF_E_BATCH_GAS_COMMIT_FAIL` | Gas commit failed |
| -110 | `DF_E_SIG_INVALID` | Invalid signature |

---

## Limits

| Limit | Value | Description |
|-------|-------|-------------|
| `DF_MAX_REGS_PER_DF` | (varies) | Max registers per contract |
| `DF_USERREG_LIMIT` | NUM_DF_SYNTHETICS - DF_SLOT_NUM_SLOTS | User register limit |
| `DF_MATRIX_MAX_CALLS` | 16 | Max calls in batch matrix |
| `DF_MAX_PIPES_PER_BATCH` | 8 | Max pipes per batch |
| `DF_PIPE_MAX_BYTES_ONE` | 2048 | Max bytes per pipe |
| `DF_PIPE_MAX_BYTES_TOTAL` | 16384 | Total max pipe bytes |
| `DF_MAX_TRANSFERS_PER_TX` | 64 | Max transfers per TX |
| `DF_MAX_EFFECTS_PER_TX` | 32 | Max effects per TX |
| `DF_MAX_CROSS_DELTAS` | 16 | Max cross-contract deltas |
| `DF_MAX_SWAPS_PER_TX` | 4 | Max swaps per TX |
| `DF_TRIG_MAX_SRCS_PER_TOCK` | 4096 | Max trigger sources per tock |
| `DF_TRIG_MAX_INTENTS_PER_TOCK` | 4096 | Max intents per tock |
| `DF_TRIG_MAX_INTENTS_PER_CALL` | 64 | Max intents per call |

---

## Effects System

Dataflows can produce effects that modify chain state:

```c
enum df_effect_type_e {
    DF_EFFECT_NONE = 0,
    DF_EFFECT_UFC_SWAP,           // AMM swap
    DF_EFFECT_UFC_POOL_DEPOSIT,   // Add liquidity
    DF_EFFECT_UFC_POOL_WITHDRAW,  // Remove liquidity
    DF_EFFECT_UFC_LIMIT_ORDER,    // Place limit order
    DF_EFFECT_SET_INSTALL_FLAGS,  // Modify install flags
    DF_EFFECT_UNINSTALL,          // Uninstall contract
    DF_EFFECT_VCREDIT_BORROW,     // Borrow from credit
    DF_EFFECT_VCREDIT_REPAY       // Repay credit
};
```

Each effect type has a corresponding struct:
- `df_effect_swap_t` - Swap parameters
- `df_effect_pool_deposit_t` - Deposit parameters
- `df_effect_pool_withdraw_t` - Withdrawal parameters
- `df_effect_limit_order_t` - Order parameters
- `df_effect_install_flags_t` - Flag modifications

---

## Related Files

| File | Purpose |
|------|---------|
| `dataflow_api.c` | Host API functions callable from VM |
| `dataflow_cache.c` | Contract caching and lookup |
| `dataflow_batch.c` | Batch transaction processing |
| `dataflow_frontier.c` | Active contract scheduling |
| `dataflow_trigger.c` | Time-based trigger system |
| `vbpf.c` | eBPF virtual machine implementation |
| `df_sdk.h` | Helper IDs and gas costs |
| `df_gas.h` | Gas calculation utilities |

---

## Security Considerations

1. **Bounded Execution** - eBPF guarantees termination; no infinite loops
2. **Gas Metering** - Every operation costs gas; prevents resource exhaustion
3. **Address Verification** - DFID computed from image hash; prevents impersonation
4. **Timelock System** - Module updates require timelock; prevents instant malicious changes
5. **Spend Authorization** - Explicit spend lists; contracts can't access arbitrary funds

---

## Usage Example

### Deploying a Contract

1. Compile contract to eBPF bytecode
2. Prepend `df_image_header_t` with metadata
3. Compute DFID = hash(image)
4. Create deployment TX:
   - Asset: VUSD
   - Amount: >= DF_DEPLOY_FEE_FULL_VUSD
   - Destination: computed DFID
   - Data: image bytes
5. Submit TX

### Calling a Contract

1. Create batch TX:
   - Asset: VUSD
   - Amount: gas budget
   - Calls: array of `df_batch_call_t`
   - Pipes: input data for each call
2. Submit TX
3. VM executes calls in sequence
4. Effects applied atomically
5. Excess gas returned

---

## Notes

- The module uses 16-byte alignment for operations storage
- Contract addresses (DFIDs) are deterministic from code
- The frontier system prioritizes active contracts by score
- Module records allow named registration with governance timelocks
