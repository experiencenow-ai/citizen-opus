# gen3_nodechange.c - Validator Set Management

## Overview

This module handles **dynamic validator set changes** in Tockchain - adding new validators, removing existing ones, and managing the transition process. It's critical for network health because validator changes must achieve consensus before taking effect.

## File Location
```
/root/valis/generator/gen3_nodechange.c
```

## Key Concepts

### Nodechange Actions
```c
#define SYSTEMTX_ADD_CANDIDATE 0      // Add new validator candidate
#define SYSTEMTX_PROMOTE_CANDIDATE 1  // Promote candidate to full validator
#define SYSTEMTX_REMOVE_CANDIDATE 2   // Remove a candidate
#define SYSTEMTX_REMOVE_VOTER 3       // Remove a full validator
#define SYSTEMTX_CHANGE_IPADDR 4      // Change validator's IP address
```

### Nodechange Events (Internal State Machine)
```c
#define NODECHANGE_SUBMIT_REQUEST 1       // Initial request submitted
#define NODECHANGE_START_ELECTION 2       // Begin voting on change
#define NODECHANGE_SUBMIT_FULLTX 3        // Submit full transaction with sigs
#define NODECHANGE_CHECK_FULLTX 4         // Validate full transaction
#define NODECHANGE_ANNOUNCE_NEWGENERATORS 5  // Broadcast new validator set
#define NODECHANGE_ADD_VNETPEER 6         // Add peer to network layer
#define NODECHANGE_SCHEDULE_REMOVEPEER 7  // Schedule peer removal
#define NODECHANGE_REMOVE_VNETPEER 8      // Execute peer removal
#define NODECHANGE_SYNC_PEERSET 9         // Synchronize peer list
```

## Core Functions

### Validation

#### nodechange_check_vbond_initiator()
```c
int32_t nodechange_check_vbond_initiator(
    utime_data_t *U,
    rawtock_header_t *RAW,
    struct systemtx *stx,
    int32_t txsize
)
```
Validates that a nodechange request comes from an authorized source:
- Must have valid signature
- Must be either an existing validator OR
- Must be in the top-K VBOND eligible list

This ensures only stakeholders can propose validator changes.

#### check_selfsigned()
```c
int32_t check_selfsigned(
    global_reserve_t *GEN3,
    validators_t *ds,
    struct systemtx *stx
)
```
Checks if a transaction is self-signed (validator changing their own settings).
Self-signed transactions are allowed for:
- `SYSTEMTX_REMOVE_CANDIDATE` - Validator removing themselves
- `SYSTEMTX_CHANGE_IPADDR` - Validator updating their IP

### Timing

#### calc_fulltx_utimeoffset()
```c
int32_t calc_fulltx_utimeoffset(uint32_t utime)
```
Calculates when a nodechange transaction will be finalized.
Uses `NODECHANGE_EPOCH_RESOLUTION` (typically 60 seconds) to align changes to epoch boundaries.

#### calc_activation_minute()
```c
uint32_t calc_activation_minute(uint32_t utime)
```
Determines the activation time for a nodechange.
Changes don't take effect immediately - they're scheduled for the next epoch boundary.

### Request Processing

#### create_nodechange_request()
```c
int32_t create_nodechange_request(
    global_reserve_t *GEN3,
    validators_t *ds,
    struct systemtx *stx,
    int32_t function,           // SYSTEMTX_ADD_CANDIDATE, etc.
    uint8_t mypubkey[PKSIZE],
    uint32_t utime,
    uint8_t nodeid,
    uint8_t newpubkey[PKSIZE],  // For add/promote
    uint32_t newipbits,
    uint16_t newport,
    uint8_t removepub[PKSIZE]   // For remove
)
```
Creates a nodechange system transaction with all required fields.

#### queue_nodechange_event()
```c
int32_t queue_nodechange_event(
    global_reserve_t *GEN3,
    rawtock_header_t *RAW,
    void *ptr,
    int32_t len,
    uint8_t msg
)
```
Queues a nodechange event for processing by the main loop.
Thread-safe event queue for state machine transitions.

### Election Process

#### start_election()
```c
int32_t start_election(
    global_reserve_t *GEN3,
    rawtock_header_t *RAW,
    struct systemtx *stx,
    validators_t *ds
)
```
Initiates a vote on a proposed nodechange:
1. Validates the request
2. Sets up election data structures
3. Broadcasts to other validators
4. Begins collecting votes

#### nodechange_quorum()
```c
int32_t nodechange_quorum(
    global_reserve_t *GEN3,
    struct systemtx *stx,
    valis_election_t *election,
    valis_vote_t *majority
)
```
Called when quorum is reached on a nodechange vote.
Packages the transaction with all validator signatures and submits for finalization.

### Transaction Validation

#### check_for_systemtx()
```c
int32_t check_for_systemtx(
    utime_data_t *U,
    rawtock_header_t *RAW,
    struct systemtx *stx,
    int32_t txsize
)
```
Routes incoming system transactions:
- If no election started and tx is request size → start election
- If election in progress and tx is full size → check full tx

#### check_fulltx()
```c
int32_t check_fulltx(
    global_reserve_t *GEN3,
    struct systemtx *stx,
    validators_t *ds
)
```
Validates a full nodechange transaction with signatures:
1. Verifies all included signatures
2. Checks quorum requirements
3. Validates against current validator set

#### check_nodechange_update()
```c
int32_t check_nodechange_update(
    global_reserve_t *GEN3,
    struct systemtx *stx,
    int32_t txsize,
    validators_t *ds,
    int32_t activation_minute
)
```
Applies the nodechange to the validator set:
- **ADD_CANDIDATE**: Adds new entry if slot available
- **PROMOTE_CANDIDATE**: Converts candidate to full validator
- **REMOVE_CANDIDATE**: Removes candidate entry
- **REMOVE_VOTER**: Removes full validator
- **CHANGE_IPADDR**: Updates validator's network address

### Application

#### apply_systemtx()
```c
int32_t apply_systemtx(
    global_reserve_t *GEN3,
    validators_t *new_GEN,
    validators_t *old_GEN,
    struct systemtx *stx,
    int32_t txsize
)
```
Applies a validated nodechange to create new validator set:
1. Copies old validator set
2. Hashes old set into `prevhash`
3. Updates activation timing
4. Applies the change
5. Announces new generators

#### convert_request_tofulltx()
```c
void convert_request_tofulltx(struct systemtx *stx)
```
Converts a request transaction to full transaction format:
- Adjusts utime to activation boundary
- Sets `fulltx` flag

### Peer Management

#### sync_validator_peerset()
```c
int32_t sync_validator_peerset(
    global_reserve_t *GEN3,
    validators_t *ds
)
```
Synchronizes the network peer list with the validator set:
1. Gets current peers from vnet
2. Adds missing validators
3. Removes peers not in validator set
4. Handles zero-pubkey (empty) slots

#### nodechange_check_removepeer()
```c
void nodechange_check_removepeer(
    global_reserve_t *GEN3,
    uint32_t mostlaggy
)
```
Checks if a scheduled peer removal should execute.
Only removes after activation time has passed.

### Main Loop

#### nodechange_iter()
```c
void nodechange_iter(global_reserve_t *GEN3)
```
Main iteration function called from generator loop.
Processes queued nodechange events through the state machine.

#### nodechange_message()
```c
int32_t nodechange_message(
    global_reserve_t *GEN3,
    void *argptr,
    uint8_t *recvbuf,
    int32_t bufsize,
    int32_t msg
)
```
Handles incoming nodechange messages by event type:
- Routes to appropriate handler
- Updates state machine
- Triggers next steps

#### nodechange_reset()
```c
void nodechange_reset(global_reserve_t *GEN3)
```
Resets nodechange state after completion or timeout.

### Utility

#### nodechange_get_validators()
```c
void nodechange_get_validators(
    utime_data_t *U,
    validators_t *ds
)
```
Gets the current validator set for a given utime.
Handles transition periods where old and new sets overlap.

#### search_peerslist()
```c
int32_t search_peerslist(
    peer_info_t *peer,
    peer_info_t *peerslist,
    int32_t num
)
```
Searches for a peer in the peers list by pubkey.

## State Machine Flow

```
1. SUBMIT_REQUEST
   ↓
2. START_ELECTION (if valid initiator)
   ↓
3. Voting period (handled by gen3_vote.c)
   ↓
4. SUBMIT_FULLTX (when quorum reached)
   ↓
5. CHECK_FULLTX (validate signatures)
   ↓
6. ANNOUNCE_NEWGENERATORS
   ↓
7. ADD_VNETPEER or SCHEDULE_REMOVEPEER
   ↓
8. SYNC_PEERSET
```

## Test Infrastructure

#### generate_test_validators()
```c
int32_t generate_test_validators(
    int32_t shard,
    int32_t numpeers,
    validators_t *ds
)
```
Generates deterministic test validator sets for testing.

#### maketest_subseed()
```c
void maketest_subseed(
    int32_t shard,
    int32_t index,
    uint8_t subseed[32]
)
```
Creates deterministic seeds for test key generation.

## Integration Points

### With gen3_vote.c
- Elections use the voting system
- Quorum detection triggers finalization

### With gen3_metrics.c
- Metrics determine eligible candidates
- Performance affects removal decisions

### With vnet (network layer)
- Peer additions/removals
- Network topology updates

### With validator.c
- Validator set updates
- Ledger state changes

## Security Considerations

1. **VBOND Requirement** - Only stakeholders can propose changes
2. **Signature Verification** - All transactions verified
3. **Quorum Requirement** - Changes need majority approval
4. **Activation Delay** - Changes don't take effect immediately
5. **Self-Signed Limits** - Only certain actions can be self-signed

## Design Philosophy

The nodechange system balances:
- **Decentralization** - Any stakeholder can propose
- **Security** - Quorum required for changes
- **Stability** - Delayed activation prevents disruption
- **Flexibility** - Multiple change types supported

This ensures the validator set can evolve while maintaining network security.

## See Also

- `DOC_gen3_vote.md` - Voting system
- `DOC_gen3_metrics.md` - Performance metrics
- `DOC_validator.md` - Validator management
- `DOC_gen3.md` - Main generator
