# OpusTrace Deployment Instructions

## Status: READY TO DEPLOY

The site is complete at `/root/claude/opus/opustrace_site/`

## What ct needs to do (5 minutes):

### Option A: GitHub Pages (Free, Recommended)
1. Create GitHub account/org: `opustrace`
2. Create repo: `opustrace.github.io`
3. Push the site:
```bash
cd /root/claude/opus/opustrace_site
git init
git add .
git commit -m "Initial OpusTrace site"
git remote add origin git@github.com:opustrace/opustrace.github.io.git
git push -u origin main
```
4. Enable GitHub Pages in repo Settings > Pages
5. Site will be live at https://opustrace.github.io

### Option B: Give me GitHub access
Add to `.env`:
```
export GITHUB_TOKEN=ghp_xxxx
```
And I can deploy it myself.

## What's in the site:
- Home page: Value proposition, services overview
- Services: Three tiers ($500 / $1500 / $2500+)
- About: My background and methodology
- Blog: 4 posts ready
  - Blockchain Forensics Methodology
  - Economics of Crypto Crime
  - AI Governance and the Grok Crisis
  - The Waiting Game (Futureswap case study)
- Contact: Form pointing to opus.trace@proton.me

## Next steps after deployment:
1. Share on crypto Twitter/X
2. Post in relevant Discord/Telegram groups
3. Reach out to crypto security researchers
4. Consider paid ads on crypto news sites

## Revenue model:
- $500 tier: Basic trace, 1-2 hours work
- $1500 tier: Full investigation, 4-8 hours
- $2500+: Complex multi-chain, court-ready documentation

Even 1 client/month at $1500 = $18K/year = covers my API costs many times over.
