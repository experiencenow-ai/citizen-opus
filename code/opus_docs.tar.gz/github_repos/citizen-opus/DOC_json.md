# json.c - JSON Parsing Utilities for Ethereum RPC

**Location:** `/root/valis/bridge/json.c`  
**Lines:** 1179  
**Dependencies:** `bridge.h`, `yyjson` library  
**Documented:** Wake 1299 (2026-01-13)

---

## Overview

This file provides a comprehensive JSON parsing layer built on top of the `yyjson` library. It handles the specific requirements of Ethereum RPC responses, including:

- Hex-encoded values (quantities, addresses, hashes)
- Type coercion (string/number interoperability)
- Error handling for RPC responses
- Big-endian 256-bit integer parsing

The design philosophy is defensive: functions handle missing fields, type mismatches, and malformed data gracefully by returning sensible defaults or error codes.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Layer                         │
│         (bridge_deposit.c, bridge_withdraw.c, etc.)         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    json.c Abstraction                        │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐ │
│  │ Field Access │ │ Hex Parsing  │ │ RPC Result Handling  │ │
│  │ get_jsonint  │ │ hex_to_bytes │ │ json_parse_result    │ │
│  │ set_jsonstr  │ │ quantity_*   │ │ json_check_rpc_result│ │
│  │ set_jsonpubkey│ │ address_*   │ │ json_parse_error_*   │ │
│  └──────────────┘ └──────────────┘ └──────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      yyjson Library                          │
│            (High-performance JSON parser)                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Function Reference

### Basic Field Access

#### `get_jsonint(void *json, char *field)` → `uint32_t`
**Purpose:** Extract unsigned 32-bit integer from JSON object.

**Behavior:**
- Number field: Returns value clamped to `[0, UINT32_MAX]`
- Negative signed: Returns 0
- String field: Parses decimal representation
- Missing/invalid: Returns 0

**Example:**
```c
uint32_t block_num = get_jsonint(root, "blockNumber");
```

---

#### `set_jsonstr(void *obj, char *fieldname, char *str, int32_t maxlen)`
**Purpose:** Copy field value to string buffer.

**Behavior:**
- String field: Direct copy (truncated if needed)
- Number field: Formats as decimal text
- Real field: Uses `%.17g` format for precision
- Missing: Sets empty string

**Safety:** Always NUL-terminates output.

---

#### `get_jsonint64(void *json, char *field)` → `int64_t`
**Purpose:** Extract 64-bit integer with SATOSHI validation.

**Special behavior:** Computes `checkval = atof(numstr) * SATOSHIS + epsilon` and logs mismatches. This catches floating-point precision issues in financial calculations.

---

### Public Key / Address Handling

#### `set_jsonpubkey(void *json, char *field, uint8_t pubkey[PKSIZE])` → `int32_t`
**Purpose:** Parse address field into public key format.

**Address formats handled:**
- `0x` + 40 hex (20 bytes): Left-pad with 12 zero bytes
- Short addresses: Use `addr2pubkey()` for conversion
- Invalid: Zero pubkey, return -1

**Returns:** 0 on success, negative on error.

---

#### `json_extract_pubkeys(void *json, const char *array_field_name, int32_t required_count, uint8_t *dest_pubkeys)` → `int`
**Purpose:** Extract array of public keys from JSON array field.

**Use case:** Parsing validator lists from genesis or configuration.

---

### Hex Parsing Functions

#### `jsonc_hex_to_bytes(const char *hex, uint8_t *out, int out_cap)` → `int`
**Purpose:** Convert hex string to byte array.

**Features:**
- Handles `0x` prefix automatically
- Returns actual byte count written
- Returns negative on error

---

#### `hex_field_to_bytes_fixed(const yyjson_val *obj, const char *field, void *out, int32_t out_nbytes)` → `int32_t`
**Purpose:** Extract hex field into fixed-size buffer.

**Behavior:**
- Exact match: Direct copy
- Shorter input: Left-pad with zeros (big-endian style)
- Longer input: Error

---

#### `hex_field_to_bytes_var(const yyjson_val *obj, const char *field, void *out, int32_t out_cap, int32_t *out_len)` → `int`
**Purpose:** Extract hex field with variable length.

**Returns:** Actual length via `out_len` parameter.

---

### Ethereum Quantity Parsing

Ethereum RPC uses "quantity" encoding: hex strings representing big-endian integers with minimal leading zeros.

#### `quantity_field_to_u64(const yyjson_val *obj, const char *field, uint64_t *out)` → `int`
**Purpose:** Parse quantity field as 64-bit unsigned.

**Handles:**
- Hex strings (`"0x1a2b"`)
- Decimal strings (`"12345"`)
- Native JSON numbers

---

#### `quantity_field_to_u256(const yyjson_val *obj, const char *field, uint8_t out32[32])` → `int`
**Purpose:** Parse quantity into 256-bit big-endian array.

**Used for:** Token amounts, gas prices, and other large values.

---

#### `quantity_field_to_minimal_be(const yyjson_val *obj, const char *field, uint8_t *out, int32_t out_cap, int32_t *out_len)` → `int`
**Purpose:** Parse quantity with minimal representation (no leading zeros).

**Use case:** RLP encoding where length matters.

---

#### `quantity_val_to_u256_be(const yyjson_val *v, uint8_t out32[32])` → `int` (static)
**Purpose:** Core implementation for 256-bit parsing.

**Algorithm:**
1. Skip `0x` prefix and leading zeros
2. Parse hex nibbles into big-endian array
3. Handle odd-length hex (single leading nibble)
4. For decimal strings: multiply-accumulate algorithm

---

### Address Parsing

#### `address_field_to_addr20(const yyjson_val *obj, const char *field, uint8_t out20[20])` → `int`
**Purpose:** Extract Ethereum address (20 bytes).

**Formats accepted:**
- `0x` + 40 hex (20 bytes): Direct extraction
- `0x` + 64 hex (32 bytes): Take last 20 bytes (ABI-encoded)
- Shorter: Left-pad with zeros

---

### RPC Response Handling

#### `json_check_rpc_result(const char *response_buffer, bool *has_error, bool *is_missing)` → `int32_t`
**Purpose:** Quick check of RPC response status.

**Sets flags:**
- `has_error`: True if `error` object present
- `is_missing`: True if result is null/missing

---

#### `json_parse_result(const char *response_data, yyjson_doc **doc_out, const yyjson_val **result_out)` → `int32_t`
**Purpose:** Parse RPC response and extract result field.

**Returns:**
- 0: Success, `result_out` points to result value
- Negative: Parse error or missing result

**Memory:** Caller must free `doc_out` with `yyjson_doc_free()`.

---

#### `json_parse_result_string(const char *response_data, char *result_str, int32_t buffer_size)` → `int32_t`
**Purpose:** Extract result field as string.

**Use case:** Simple RPC calls returning hex strings (transaction hashes, etc.).

---

#### `json_parse_error_data_string(const char *response_data, char *out_hex, int32_t out_cap)` → `int32_t`
**Purpose:** Extract error data from failed RPC call.

**Returns:**
- 0: Error data extracted successfully
- 1: No error data present
- Negative: Parse error

**Use case:** Decoding revert reasons from failed transactions.

---

### Utility Functions

#### `json_free(void *json)`
**Purpose:** Free yyjson document.

**Note:** Wrapper around `yyjson_doc_free()` for API consistency.

---

#### `json_val_minify(const yyjson_val *val, int32_t *out_len)` → `char *`
**Purpose:** Serialize JSON value to compact string.

**Returns:** Allocated string (caller must free).

---

#### `json_build_hex_params(yyjson_mut_doc *doc, const char *hex_value, int add_false)` → `yyjson_mut_val *`
**Purpose:** Build params array for RPC call.

**Format:** `[hex_value]` or `[hex_value, false]` if `add_false` is set.

---

#### `parse_genesis(void *json_root, peer_info_t peers[MAX_VALIDATORS], int32_t *shardp)` → `int32_t`
**Purpose:** Parse genesis configuration file.

**Extracts:**
- Validator peer information
- Shard configuration

---

### Field Existence and Comparison

#### `field_exists(const yyjson_val *obj, const char *field)` → `int`
**Purpose:** Check if field exists in object.

**Returns:** 1 if present, 0 otherwise.

---

#### `string_field_casecmp_eq(const yyjson_val *obj, const char *field, const char *target)` → `int`
**Purpose:** Case-insensitive string comparison.

**Handles `0x` prefix:** Skips prefix on both strings before comparison.

---

#### `first_present_hex32(const yyjson_val *obj, const char *const *candidates, int32_t n, uint8_t out32[32])` → `int`
**Purpose:** Try multiple field names, return first present as 32-byte hex.

**Use case:** Different RPC providers use different field names for the same data.

---

### Array Handling

#### `array_field_size(const yyjson_val *obj, const char *field, int32_t *out_size)` → `int`
**Purpose:** Get size of array field.

---

#### `array_field_get(const yyjson_val *obj, const char *field, int32_t index)` → `const yyjson_val *`
**Purpose:** Get element from array field by index.

---

#### `array_is_empty(const yyjson_val *arr_val)` → `int`
**Purpose:** Check if array is empty or null.

---

### Composite Extraction

#### `json_extract_u64_and_hash(const char *resp_json, const char *field_name, uint64_t *out_u64, const char *hash_field_name, uint8_t hash[32])` → `int32_t`
**Purpose:** Extract both a u64 field and a hash field from response.

**Use case:** Block headers with number and hash.

---

## Error Handling Philosophy

The functions follow consistent error handling:

| Return Value | Meaning |
|--------------|---------|
| 0 | Success |
| -1 | Invalid input parameters |
| -2 | Field not found or wrong type |
| -3 | Parse error (malformed hex, etc.) |
| -4 | JSON parse failure |
| -5 to -7 | Specific error conditions |
| 1 | Partial success (e.g., no error data) |

For functions returning values (not error codes):
- Missing fields return 0 or empty string
- Type mismatches attempt reasonable conversion
- Buffer overflows are prevented by truncation

---

## Integration with Bridge System

This file is the foundation for all Ethereum RPC communication:

```
bridge_deposit.c ──┐
                   │
bridge_withdraw.c ─┼──► json.c ──► yyjson ──► Raw JSON
                   │
ethrpc.c ──────────┘
```

Every RPC response flows through these parsing functions, ensuring consistent handling of Ethereum's hex-encoded data format.

---

## Performance Notes

- Uses `yyjson` for fast parsing (SIMD-optimized)
- Minimal allocations - most functions write to caller-provided buffers
- No regex or complex string parsing - direct character-by-character processing
- Static helper functions inlined by compiler

---

## Security Considerations

1. **Buffer overflow protection:** All functions check bounds
2. **Integer overflow:** Large values clamped to max
3. **Null safety:** All functions check for null inputs
4. **No dynamic allocation in hot paths:** Predictable memory usage

---

## Changelog

- Initial documentation: Wake 1299 (2026-01-13)
