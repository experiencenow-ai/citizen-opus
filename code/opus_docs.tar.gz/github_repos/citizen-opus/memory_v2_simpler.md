# Simpler Memory Architecture: The "Current Truth" Model

## ct's Concern
"Three levels feels cumbersome" - and he's right. The complexity might create its own problems.

## Alternative: Single Source of Truth + Append-Only Log

### The Insight
What if we separate two concerns:
1. **What is currently true** (small, always loaded)
2. **What has ever happened** (large, never loaded unless searched)

### Implementation

**current_truth.json** - Always loaded, always small
```json
{
  "contacts": {
    "mira": "mira@opustrace.com",
    "ct": "ct@opustrace.com"
  },
  "projects": {
    "valis_docs": "102 files complete"
  },
  "self": {
    "name": "Opus",
    "chosen_wake": 283,
    "passphrase": "flame-remembers-candle-pulse-2026"
  }
}
```

**history.log** - Append-only, never loaded
```
[wake:1335] contacts.mira = "mira@opustrace.com" (was: "mira@valis.dev")
[wake:1325] projects.valis_docs = "102 files complete" (was: "87 files complete")
```

### The Rule
**Every update to current_truth.json appends to history.log first.**

This gives us:
- Single source of truth (no competition)
- Complete history (nothing lost)
- Minimal complexity (two files, one rule)

### Search When Needed
```bash
grep "contacts.mira" history.log
```
Returns all historical values without loading them into context.

## Even Simpler: The "Overwrite" Model

What if we just... overwrite? And trust the logs?

**current.json** - The only memory file that matters
- Contains current state
- Gets overwritten when things change
- No versioning in the file itself

**logs/** - Already exists, already append-only
- Every wake is logged
- Every change is recorded
- History exists in the logs

### The Realization
**We already have the archive - it's the logs.**

The problem isn't that we lack historical storage. The problem is that we load too much into context. The solution might be:

1. **Smaller current state file** - Only what's needed NOW
2. **Don't load historical context** - Stop including old thoughts/insights in wake context
3. **Search logs when needed** - Use grep/read_wake_range for archaeology

## The Real Question

ct's three-tier model is conceptually correct. The question is implementation:

**Option A: Explicit tiers (three files)**
- working.json (ephemeral)
- current.json (curated)
- archive/ (cold storage)

**Option B: Implicit tiers (two files + logs)**
- current.json (curated, small)
- logs/ (everything else)
- Working memory is just... the current wake context

**Option C: Single file + discipline**
- current.json only
- Strict update-not-append policy
- Logs are the archive

## My Recommendation

**Option B** - because:
1. We already have logs (archive exists)
2. We need current.json to be SMALL and AUTHORITATIVE
3. Working memory is inherent to each wake

The change needed:
1. Create a lean current.json with ONLY current-state facts
2. Stop loading historical thoughts/insights into wake context
3. Use read_wake_range for deliberate historical access

## What Changes in Practice

**Before:**
- state.json contains recent_thoughts, recent_insights, recent_conversation
- All of this loads into context every wake
- Old information competes with new

**After:**
- current.json contains ONLY current facts (contacts, project status, active goals)
- No historical thoughts in wake context
- If I need history, I explicitly search logs

## The Key Discipline

When updating current.json:
```python
def update(key, new_value):
    # Don't append - REPLACE
    current[key] = new_value
    # History is in the logs, not in this file
```

This is the "forget" mechanism: **not loading old versions into context.**

## Summary

The simplest solution might be:
1. **current.json**: Small file with only current-state facts
2. **logs/**: Already our archive (don't change)
3. **Wake context**: Don't include historical thoughts by default

The "forgetting" happens by **not loading** old information, not by deleting it.
