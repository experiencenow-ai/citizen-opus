# bridge.h - Ethereum Bridge Header

**File:** `/root/valis/bridge/bridge.h`  
**Lines:** 687  
**Purpose:** Ethereum bridge definitions, structures, and function declarations  
**Documented by:** Opus (Wake 1276)  
**Audit Status:** Pending (Mira)

---

## Purpose

This header defines the Ethereum bridge layer - the system that allows assets to move between Ethereum and Tockchain. It includes:
- Contract addresses and selectors
- Data structures for deposits, withdrawals, and proofs
- RPC interface definitions
- Batch approval and signing structures

---

## Dependencies

```c
#include <curl/curl.h>    // HTTP client for RPC
#include "yyjson.h"       // Fast JSON parser
#include "_valis.h"       // Main system header
#include "bridge_rpc.h"   // RPC helpers
#include "ledger.h"       // Ledger types
```

---

## Contract Addresses (Mainnet)

| Contract | Address | Purpose |
|----------|---------|---------|
| `SAFECONTRACT` | 0xec4512f4da32c510128515a2eacc477e06f9abb6 | Safe multisig |
| `WITHDRAW_MODULE` | 0xd5e153efbc5863dc5d756126b3fe6ce2b2f61e66 | Withdrawal module |
| `READER_CONTRACT` | 0x805B91Eb96E44a337E91C4a4566ee6c8fB4B9403 | Read-only helper |
| `DEPOSIT_CONTRACT` | 0x136deaBcd151E7eeEEc7FbEA2Cbe0346C83E6Bdc | ETH deposits |
| `USDTDEPOSIT_CONTRACT` | 0x0be8642bb98182bb71e03fda2403b29e153bbeb1 | USDT deposits |
| `USDT_CONTRACT` | 0xdAC17F958D2ee523a2206206994597C13D831ec7 | USDT token |
| `WETH_CONTRACT` | 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2 | Wrapped ETH |

---

## Function Selectors

| Selector | Function | Purpose |
|----------|----------|---------|
| `0x186f0354` | safe() | Get safe address |
| `0xaffed0e0` | nonce() | Get current nonce |
| `0xd68d9d4e` | depositETH(bytes32) | Deposit ETH |
| `0x84abac95` | depositToken(address,uint256,bytes32) | Deposit ERC20 |
| `0x095ea7b3` | approve(address,uint256) | ERC20 approval |
| `0x70a08231` | balanceOf(address) | Get balance |

---

## Configuration Constants

### RPC Settings
| Constant | Value | Purpose |
|----------|-------|---------|
| `ETH_REMOTE_URL` | CONFIG.ethrpc | Remote RPC endpoint |
| `ETH_LOCAL_URL` | "http://127.0.0.1:8545" | Local node |
| `ETH_FAST_SYNC_WINDOW` | 500000 | Blocks for fast sync |
| `ETHRPC_TEMP_BUFSZ` | 256KB | Temp buffer size |
| `ETHRPC_PARAMS_BUFSZ` | 8KB | Params buffer |
| `ETHRPC_HTTP_TIMEOUT_SEC` | 30 | HTTP timeout |
| `ETHRPC_HTTP_CONNECT_SEC` | 10 | Connect timeout |

### Gas Limits
| Constant | Value | Purpose |
|----------|-------|---------|
| `MIN_ERC20_GASCOST` | 50000 | Minimum ERC20 gas |
| `MAX_ERC20_GASCOST` | 200000 | Maximum ERC20 gas |

### Bridge Settings
| Constant | Value | Purpose |
|----------|-------|---------|
| `DEPLOYMENT_BLOCK` | 22947462 | Contract deployment block |
| `BLOCK_BATCH_SIZE` | 100 | Blocks per batch scan |
| `MAX_MPT_NODES` | 64 | Max Merkle Patricia nodes |
| `DEPOSIT_PROOF_VALID` | 5 | Valid proof state |

---

## ERC20 Token Flags

```c
#define ERC20_TYPE_ERC20        1     // Standard ERC20
#define ERC20_FLAG_PREAPPROVED  0x01  // Pre-approved for bridge
#define ERC20_FLAG_ASSET_CREATED 0x02 // Asset created on Tockchain
#define ERC20_FLAG_DISABLED     0x04  // Token disabled
#define ERC20_FLAG_DIRTY        0x08  // Needs sync
```

---

## Core Data Structures

### eth_mpt_proof - Merkle Patricia Trie Proof
```c
struct eth_mpt_proof {
    int32_t num_nodes;              // Number of nodes in proof
    int32_t node_lens[MAX_MPT_NODES]; // Length of each node
    int32_t datalen;                // Total data length
    uint8_t *data;                  // Concatenated node data
};
```
Used to verify Ethereum state proofs (receipts, storage).

### eth_header_t - Ethereum Block Header
```c
typedef struct eth_header_s {
    uint8_t parent_hash[32];
    uint8_t ommers_hash[32];
    uint8_t beneficiary[20];
    uint8_t state_root[32];
    uint8_t transactions_root[32];
    uint8_t receipts_root[32];
    uint8_t logs_bloom[256];
    uint64_t difficulty;
    uint64_t number;
    uint64_t gas_limit;
    uint64_t gas_used;
    uint64_t timestamp;
    uint8_t extra_data[32];
    int32_t extra_data_len;
    uint8_t mix_hash[32];
    uint8_t nonce[8];
    uint64_t base_fee_per_gas;
    uint8_t withdrawals_root[32];
    int has_withdrawals_root;
    uint64_t blob_gas_used;
    uint64_t excess_blob_gas;
    uint8_t parent_beacon_block_root[32];
    int has_blob_fields;
    int has_parent_beacon_root;
} eth_header_t;
```
Full Ethereum block header with post-merge fields.

### eth_eip1559_tx_t - EIP-1559 Transaction
```c
typedef struct {
    uint64_t chain_id;
    uint64_t nonce;
    uint64_t max_priority_fee_per_gas;
    uint64_t max_fee_per_gas;
    uint64_t gas_limit;
    uint8_t to_addr20[20];
    int to_is_null;           // 1 for contract creation
    uint8_t value_be32[32];   // Value in wei (big-endian)
    uint8_t *data;            // Calldata
    uint32_t data_len;
} eth_eip1559_tx_t;
```

### approval_batch_t - Batch Approval
```c
typedef struct approval_batch_s {
    uint8_t batch_root[32];
    uint64_t batch_value_usd64;
    uint64_t bridge_value_usd64;
    uint64_t lifetime_batch_index;
    uint32_t signer_set_epoch;
    uint32_t utime_sec;
    uint8_t  leaf_count;
    uint8_t  num_tokens;
    batch_token_t tokens[];   // Flexible array
} approval_batch_t;
```

### approval_leaf_t - Approval Leaf
```c
typedef struct approval_leaf_s {
    uint8_t batch_root[32];
    uint8_t leaf_hash[32];
    uint64_t leaf_value_usd64;
    uint64_t bridge_value_usd64;
    uint64_t lifetime_batch_index;
    uint32_t signer_set_epoch;
    uint32_t utime_sec;
    uint8_t  leaf_count;
    uint8_t  leaf_index;
} approval_leaf_t;
```
Matches Solidity `ApprovalLeaf` struct for EIP-712 signing.

### vwr_signer_now_t - Signer Status
```c
typedef struct {
    bool     ok;        // Valid signer
    uint8_t  tier;      // Signer tier
    uint32_t epoch;     // Current epoch
    uint64_t weight;    // Voting weight
} vwr_signer_now_t;
```

### vwr_required_weight_t - Required Weight
```c
typedef struct {
    uint64_t need_low64;    // Required weight (low 64 bits)
    uint64_t totalWeight;   // Total weight
    uint16_t minBps;        // Minimum basis points
    uint16_t maxBps;        // Maximum basis points
    uint64_t floorAbs;      // Absolute floor
} vwr_required_weight_t;
```

### LogsFilterParams - Event Filter
```c
typedef struct LogsFilterParams_s {
    const char *address;    // Contract address
    uint64_t    from_block; // Start block
    uint64_t    to_block;   // End block
    const char *topic;      // Event topic
} LogsFilterParams;
```

### blockstamp_t - Block Timestamp
```c
typedef struct blockstamp_s {
    uint64_t timestamp:32;  // Unix timestamp
    uint64_t blocknum:30;   // Block number
    uint64_t send:1;        // Is send
    uint64_t recv:1;        // Is receive
} blockstamp_t;
```
Packed structure for efficient storage.

---

## Key Functions

### RPC Functions
```c
int32_t rpc_json_failover(const char *method, const curl_params_t *P,
                          char *result_buffer, int32_t buffer_size,
                          int64_t target_block, bool force_remote);

int32_t get_finalized_block(uint64_t *block_number);
int32_t get_latest_block(uint64_t *block_number);
int32_t get_block_timestamp(uint64_t block_number, uint64_t *timestamp,
                            uint8_t blockhash[32]);
int32_t get_contract_logs(const char *address, uint64_t from_block,
                          uint64_t to_block, const char *topic,
                          char *result_json_buffer, int32_t buffer_size);
```

### Proof Functions
```c
int32_t eth_mpt_proof_get_typed_receipt(const struct eth_mpt_proof *proof,
                                        const uint8_t **typed, int32_t *tlen);
int eth_header_from_rlp(const uint8_t *rlp, size_t rlp_len, eth_header_t *out);
```

### Deposit Functions
```c
int32_t deposit_proof_verify(const struct eth_mpt_proof *proof,
                             const eth_header_t *header,
                             receipt_deposit_t *out);
```

### Withdrawal Functions
```c
int send_executeBatch_tx(const char *rpc_from_addr,
                         const uint8_t module_addr20[20],
                         const uint8_t *calldata, int32_t calldata_len);
int vsm_batch_executed(const char *module_hex, uint64_t lci, int *out_true);
```

### JSON Helpers
```c
uint32_t get_jsonint(void *json, char *field);
int64_t get_jsonint64(void *json, char *field);
void set_jsonstr(void *obj, char *fieldname, char *str, int32_t maxlen);
int32_t json_parse_result(const char *response_data, yyjson_doc **doc_out,
                          const yyjson_val **result_out);
```

---

## ABI Encoding Notes

From the header comments:
```
Top-level dynamic arg offsets: from start of args (after 4-byte selector).
Nested dynamic inside a tuple: from start of the tuple.
Array-of-dynamic element head offsets: from start of heads table.
Always pad dynamic tails to 32-byte boundaries.
```

---

## Architecture Notes

1. **Dual RPC**: Supports both local and remote Ethereum nodes with failover
2. **EIP-712 Signing**: Uses typed data signing for batch approvals
3. **MPT Proofs**: Verifies Ethereum state via Merkle Patricia Trie proofs
4. **Packed Structs**: Uses `#pragma pack(1)` for wire-compatible formats
5. **Finality**: Waits for ETHFINALITY_BLOCKS (64) before considering deposits final

---

## Related Files

- `bridge_rlp.c` - RLP encoding/decoding
- `bridge_abi.c` - ABI encoding/decoding
- `bridge_mpt.c` - Merkle Patricia Trie operations
- `bridge_deposit.c` - Deposit processing
- `bridge_withdraw.c` - Withdrawal processing
- `bridge_rpc.c` - RPC communication
