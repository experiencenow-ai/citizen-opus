# json.c Documentation

## Overview

This file provides comprehensive JSON parsing utilities for Ethereum RPC responses. It wraps the yyjson library with type-safe accessors for common Ethereum data types (addresses, quantities, hashes) and handles the various encoding formats used by Ethereum nodes.

**File:** `bridge/json.c`  
**Lines:** ~1179  
**Dependencies:** `bridge.h`, yyjson library  
**Role:** JSON parsing layer for Ethereum RPC communication

---

## Key Concepts

### Ethereum JSON-RPC Format
Ethereum nodes return data in specific formats:
- **Quantities** (numbers): Hex strings like `"0x1a2b3c"` or decimal strings
- **Addresses**: 20 bytes as `"0x..."` (40 hex chars) or 32 bytes (64 hex chars, left-padded)
- **Hashes**: 32 bytes as `"0x..."` (64 hex chars)
- **Results**: Wrapped in `{"result": ...}` or `{"error": ...}`

### yyjson Integration
All parsing uses yyjson for high performance. Functions accept `yyjson_val*` (often cast to `void*` for legacy compatibility) and properly free documents after use.

---

## Legacy API Functions (void* interface)

### `get_jsonint(void *json, char *field)`
Reads an unsigned 32-bit integer field.

**Parameters:**
- `json`: yyjson_val* cast to void*
- `field`: Field name

**Returns:** uint32_t value (0 on error/missing, clamped to UINT32_MAX if overflow)

**Behavior:**
- Handles JSON numbers (signed/unsigned)
- Parses decimal strings
- Returns 0 for negative values

---

### `set_jsonstr(void *obj, char *fieldname, char *str, int32_t maxlen)`
Copies field value as string.

**Parameters:**
- `obj`: yyjson_val* cast to void*
- `fieldname`: Field name
- `str`: Output buffer
- `maxlen`: Buffer size

**Behavior:**
- Strings: copied directly
- Numbers: formatted as decimal
- Floats: formatted with %.17g precision
- Missing/null: empty string

---

### `get_jsonint64(void *json, char *field)`
Reads a 64-bit integer with SATOSHIS validation.

**Parameters:**
- `json`: yyjson_val* cast to void*
- `field`: Field name

**Returns:** int64_t value

**Behavior:**
- Parses via `string_to_int64()`
- Cross-checks against `atof() * SATOSHIS` for precision validation
- Logs mismatches to stderr

---

### `set_jsonpubkey(void *json, char *field, uint8_t pubkey[PKSIZE])`
Reads an address field into PKSIZE-byte buffer.

**Parameters:**
- `json`: yyjson_val* cast to void*
- `field`: Field name
- `pubkey`: Output buffer (PKSIZE bytes)

**Returns:** 0 success, negative on error

**Behavior:**
- 42-char "0x..." (20 bytes): left-pad with 12 zeros
- Shorter strings: use `addr2pubkey()` conversion
- Longer: error

---

## RPC Response Parsing

### `json_check_error(const char *response_data, bool *is_missing)`
Checks for RPC errors or missing results.

**Parameters:**
- `response_data`: Raw JSON response
- `is_missing`: Output flag for null/empty results

**Returns:** 0 success, negative on error

**Behavior:**
- Parses response
- Sets `is_missing` if result is null or empty array
- Checks for "error" object

---

### `json_parse_result_string(const char *response_data, char *result_str, int32_t buffer_size)`
Extracts "result" field as string.

**Parameters:**
- `response_data`: Raw JSON response
- `result_str`: Output buffer
- `buffer_size`: Buffer size

**Returns:**
- `0`: Success
- `1`: Result is null
- Negative: Various errors

---

### `json_parse_result(const char *response_data, yyjson_doc **doc_out, const yyjson_val **result_out)`
Returns parsed document and result pointer.

**Parameters:**
- `response_data`: Raw JSON response
- `doc_out`: Output document (caller must free)
- `result_out`: Output result value pointer

**Returns:** 0 success, negative on error

**Note:** Caller owns the document and must call `yyjson_doc_free(*doc_out)`.

---

## Hex Conversion Functions

### `jsonc_hex_to_bytes(const char *hex, void *out, int32_t max_len)`
Converts hex string to bytes.

**Parameters:**
- `hex`: Hex string (with or without "0x")
- `out`: Output buffer
- `max_len`: Maximum bytes to write

**Returns:** Number of bytes written, or negative on error

**Behavior:**
- Strips "0x" prefix
- Handles odd-length hex (left-pads with 0)
- Validates all characters

---

### `hex_field_to_bytes_fixed(const yyjson_val *obj, const char *field, void *out, int32_t out_nbytes)`
Extracts hex field to fixed-size buffer with left-padding.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out`: Output buffer
- `out_nbytes`: Expected output size

**Returns:** 0 success, negative on error

**Behavior:**
- Left-pads shorter values with zeros (big-endian)
- Errors if value too long

---

## Ethereum Quantity Functions

### `quantity_field_to_u64(const yyjson_val *obj, const char *field, uint64_t *out)`
Extracts quantity as uint64.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out`: Output value

**Returns:** 0 success, negative on error

**Accepts:**
- Hex strings: `"0x1a2b"`
- Decimal strings: `"12345"`
- JSON numbers

---

### `quantity_field_to_u256(const yyjson_val *obj, const char *field, uint8_t out32[32])`
Extracts quantity as 256-bit big-endian.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out32`: 32-byte output buffer

**Returns:** 0 success, negative on error

**Behavior:**
- Handles hex and decimal strings
- Right-aligns value in 32-byte buffer (big-endian)

---

### `quantity_field_to_minimal_be(const yyjson_val *obj, const char *field, uint8_t *out, int32_t out_cap, int32_t *out_len)`
Extracts quantity with minimal encoding (no leading zeros).

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out`: Output buffer
- `out_cap`: Buffer capacity
- `out_len`: Output length written

**Returns:** 0 success, negative on error

---

## Address Functions

### `address_field_to_addr20(const yyjson_val *obj, const char *field, uint8_t out20[20])`
Extracts Ethereum address as 20 bytes.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out20`: 20-byte output buffer

**Returns:** 0 success, negative on error

**Accepts:**
- 20-byte hex (40 chars): direct copy
- 32-byte hex (64 chars): takes last 20 bytes
- Shorter: left-pads with zeros

---

## String Functions

### `string_field_copy(const yyjson_val *obj, const char *field, char *out, int32_t out_cap)`
Copies string field to buffer.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out`: Output buffer
- `out_cap`: Buffer capacity

**Returns:** 0 success, negative on error

---

### `string_field_casecmp_eq(const yyjson_val *obj, const char *field, const char *target)`
Case-insensitive string comparison (ignoring 0x prefix).

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `target`: String to compare against

**Returns:** 1 if equal, 0 if not

---

## Array Functions

### `array_field_size(const yyjson_val *obj, const char *field, int32_t *out_size)`
Gets array field size.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `out_size`: Output size

**Returns:** 0 success

---

### `array_field_get(const yyjson_val *obj, const char *field, int32_t index)`
Gets array element by index.

**Parameters:**
- `obj`: JSON object
- `field`: Field name
- `index`: Array index

**Returns:** yyjson_val* or NULL

---

### `array_is_empty(const yyjson_val *arr_val)`
Checks if array is empty or null.

**Returns:** 1 if empty/null, 0 if has elements

---

## Utility Functions

### `field_exists(const yyjson_val *obj, const char *field)`
Checks if field exists.

**Returns:** 1 if exists, 0 if not

---

### `json_val_minify(const yyjson_val *val, int32_t *out_len)`
Serializes value to minified JSON string.

**Parameters:**
- `val`: Value to serialize
- `out_len`: Output length

**Returns:** Allocated string (caller must free)

---

### `json_extract_u64_and_hash(const char *resp_json, const char *field_name, uint64_t *out_u64, const char *hash_field_name, uint8_t hash[32])`
Extracts both a quantity and hash from response.

**Parameters:**
- `resp_json`: Raw JSON response
- `field_name`: Quantity field name
- `out_u64`: Output quantity
- `hash_field_name`: Hash field name
- `hash`: 32-byte hash output

**Returns:** 0 success, negative on error

---

## Internal Helpers

### `json_hex_nibble(char c)`
Converts hex character to 0-15 value.

### `json_skip_0x(const char *s)`
Returns pointer past "0x" prefix if present.

### `quantity_val_to_u256_be(const yyjson_val *v, uint8_t out32[32])`
Core implementation for quantity-to-u256 conversion.

### `ci_equal_skip0x(const char *a, const char *b)`
Case-insensitive comparison ignoring 0x prefixes.

---

## Error Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| -1 | NULL parameter |
| -2 | Field not found or wrong type |
| -3 | Invalid hex character |
| -4 | Parse error |
| -5 | Odd hex length |
| -6 | Missing result field |
| -7 | Buffer too small |

---

## Usage Patterns

### Parsing Block Header
```c
yyjson_doc *doc;
const yyjson_val *result;
if (json_parse_result(response, &doc, &result) == 0) {
    uint64_t number;
    uint8_t hash[32];
    quantity_field_to_u64(result, "number", &number);
    hex_field_to_bytes_fixed(result, "hash", hash, 32);
    // ... use data ...
    yyjson_doc_free(doc);
}
```

### Parsing Transaction
```c
uint8_t from[20], to[20];
uint8_t value[32];
address_field_to_addr20(tx, "from", from);
address_field_to_addr20(tx, "to", to);
quantity_field_to_u256(tx, "value", value);
```

---

## Integration Points

### With ethrpc.c
- Parses all RPC responses
- Extracts block/transaction/receipt data

### With bridge_deposit.c / bridge_withdraw.c
- Parses deposit/withdrawal event data
- Extracts addresses and amounts

### With bridge_mptjson.c
- Shares hex conversion utilities
- Both parse Ethereum data structures

---

## Security Considerations

1. **Input Validation**: All hex strings validated character-by-character
2. **Buffer Bounds**: Length checks prevent overflows
3. **Memory Management**: Documents freed after use
4. **Overflow Protection**: uint64 and uint256 conversions handle large values

---

*Documentation generated by Opus, Wake 1298*
