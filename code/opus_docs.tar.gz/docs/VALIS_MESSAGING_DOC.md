# Valis Messaging Module Documentation

**File:** `/root/valis/netlibs/valis_messaging.c` and `valis_messaging.h`  
**Lines:** 408 (implementation) + 47 (header)  
**Purpose:** Portable messaging abstraction layer (NNG/nanomsg)  
**Documented by:** Opus (Wake 1288)  
**Status:** Complete

---

## Overview

The Valis Messaging module provides a portable socket-like API for inter-process communication. It abstracts over two messaging libraries:

1. **NNG (Nanomsg Next Generation)** - Primary backend (USE_NNG defined)
2. **nanomsg** - Legacy fallback

This abstraction allows Tockchain to switch messaging backends without changing application code. The API mirrors nanomsg's design but adds thread-safety and context isolation.

---

## Dependencies

```c
#include "valis_messaging.h"
#include "_valis.h"
#include <errno.h>
#include <pthread.h>

// NNG backend
#include <nng/nng.h>
#include <nng/protocol/pipeline0/push.h>
#include <nng/protocol/pipeline0/pull.h>
#include <nng/protocol/pubsub0/pub.h>
#include <nng/protocol/pubsub0/sub.h>
```

---

## Socket Types

```c
#define VMSG_PUB   1   // Publisher (one-to-many broadcast)
#define VMSG_SUB   2   // Subscriber (receives from publishers)
#define VMSG_PUSH  3   // Push (load-balanced pipeline)
#define VMSG_PULL  4   // Pull (receives from pushers)
```

**Patterns:**
- **PUB/SUB** - Fan-out messaging (one publisher, many subscribers)
- **PUSH/PULL** - Pipeline (load-balanced work distribution)

---

## Socket Options

```c
#define VMSG_SOL_SOCKET   0    // Socket-level options
#define VMSG_SUBSCRIBE    1    // Subscribe to topic prefix
#define VMSG_SNDBUF       2    // Send buffer size (bytes)
#define VMSG_RCVBUF       3    // Receive buffer size (bytes)
#define VMSG_RCVFD        14   // Receive pollable file descriptor
#define VMSG_RCVMAXSIZE   16   // Max receive message size (-1 = unlimited)
```

---

## Internal Data Structures

### Socket Table Entry

```c
struct vmsg_sock {
    int in_use;                           // Slot occupied
    nng_socket s;                         // NNG socket handle
    int type;                             // VMSG_PUB/SUB/PUSH/PULL
    int next_eid;                         // Next endpoint ID
    pthread_mutex_t mtx;                  // Per-socket mutex
    struct vmsg_endpoint ep[VMSG_MAX_ENDPOINTS];  // Endpoint array
};
```

### Endpoint Entry

```c
struct vmsg_endpoint {
    int in_use;
    int is_dialer;    // 1 = dialer (connect), 0 = listener (bind)
    int started;
    int id;           // Endpoint ID returned to caller
    union {
        nng_dialer d;
        nng_listener l;
    };
};
```

### Context Structure

All socket state is stored in `vnet_context_t` (from `_valis.h`):
- `VMSG_TAB[VMSG_MAX_SOCKETS]` - Socket table
- `VMSG_TAB_MTX` - Global table mutex

---

## API Functions

### vmsg_socket

```c
int vmsg_socket(vnet_context_t *VNET, int domain, int type)
```

**Purpose:** Create a new messaging socket.

**Parameters:**
- `VNET` - Network context
- `domain` - Ignored (kept for nanomsg compatibility)
- `type` - `VMSG_PUB`, `VMSG_SUB`, `VMSG_PUSH`, or `VMSG_PULL`

**Returns:** Socket handle (≥0) or -1 on error.

**Implementation:**
1. Opens appropriate NNG socket type
2. Allocates slot in socket table
3. Initializes per-socket mutex

---

### vmsg_bind

```c
int vmsg_bind(vnet_context_t *VNET, int sock, const char *url)
```

**Purpose:** Bind socket to listen on URL.

**URL Formats:**
- `tcp://0.0.0.0:5555` - TCP listener
- `ipc:///tmp/mysock` - Unix domain socket
- `inproc://name` - In-process transport

**Returns:** Endpoint ID (≥1) or -1 on error.

**Implementation:** Creates NNG listener, starts it, stores in endpoint table.

---

### vmsg_connect

```c
int vmsg_connect(vnet_context_t *VNET, int sock, const char *url)
```

**Purpose:** Connect socket to remote URL.

**Returns:** Endpoint ID (≥1) or -1 on error.

**Implementation:** Creates NNG dialer with `NNG_FLAG_NONBLOCK` for background reconnection.

---

### vmsg_shutdown

```c
int vmsg_shutdown(vnet_context_t *VNET, int sock, int endpoint)
```

**Purpose:** Close a specific endpoint (listener or dialer).

**Returns:** 0 on success, -1 on error.

---

### vmsg_close

```c
int vmsg_close(vnet_context_t *VNET, int sock)
```

**Purpose:** Close socket and all its endpoints.

**Implementation:**
1. Closes all dialers and listeners
2. Closes NNG socket
3. Frees socket table slot

---

### vmsg_send

```c
int vmsg_send(vnet_context_t *VNET, char *str, int sock, 
              const void *buf, int32_t len, int flags)
```

**Purpose:** Send message on socket.

**Parameters:**
- `str` - Debug string (for logging)
- `sock` - Socket handle
- `buf` - Message data
- `len` - Message length
- `flags` - `VMSG_DONTWAIT` for non-blocking

**Returns:** Bytes sent or negative error.

**Implementation:**
- Blocking: `nng_send()`
- Non-blocking: `nng_send()` with `NNG_FLAG_NONBLOCK`

---

### vmsg_recv

```c
int vmsg_recv(vnet_context_t *VNET, int sock, void *buf, int32_t len, int flags)
```

**Purpose:** Receive message from socket.

**Parameters:**
- `sock` - Socket handle
- `buf` - Buffer for message
- `len` - Buffer capacity
- `flags` - `VMSG_DONTWAIT` for non-blocking

**Returns:** Bytes received or negative error.

**Implementation:** Uses `nng_recv()` with appropriate flags.

---

### vmsg_setsockopt

```c
int vmsg_setsockopt(vnet_context_t *VNET, int sock, int level, 
                    int option, const void *val, int32_t sz)
```

**Purpose:** Set socket option.

**Supported Options:**

| Option | Level | Description |
|--------|-------|-------------|
| `VMSG_SUBSCRIBE` | - | Subscribe to topic prefix (SUB sockets) |
| `VMSG_RCVMAXSIZE` | `VMSG_SOL_SOCKET` | Max receive message size |
| `VMSG_SNDBUF` | `VMSG_SOL_SOCKET` | Send buffer size (bytes → msgs) |
| `VMSG_RCVBUF` | `VMSG_SOL_SOCKET` | Receive buffer size (bytes → msgs) |

**Buffer Size Conversion:**
```c
#define VMSG_BYTES_PER_MSG_EST 1400
int msgs = bytes / VMSG_BYTES_PER_MSG_EST;
```
NNG uses message counts, not byte counts, so we estimate.

---

### vmsg_getsockopt

```c
int vmsg_getsockopt(vnet_context_t *VNET, int sock, int level, 
                    int option, void *val, int32_t *szp)
```

**Purpose:** Get socket option.

**Supported:** `VMSG_RCVFD` (receive file descriptor for polling).

---

### vmsg_errno / vmsg_strerror

```c
int vmsg_errno(void)
const char *vmsg_strerror(int errnum)
```

**Purpose:** Error handling (wraps standard errno/strerror).

---

## Error Mapping

NNG errors are mapped to standard errno values:

```c
static int map_errno_from_nng(int nng_err)
{
    switch (nng_err) {
        case 0:               return 0;
        case NNG_EAGAIN:      return EAGAIN;
        case NNG_ENOTSUP:     return ENOTSUP;
        case NNG_ECLOSED:     return EBADF;
        case NNG_ETIMEDOUT:   return ETIMEDOUT;
        case NNG_EINVAL:      return EINVAL;
        case NNG_ENOMEM:      return ENOMEM;
        case NNG_ESTATE:      return EINVAL;
        default:              return EINVAL;
    }
}
```

---

## Thread Safety

- **Global table mutex** (`VMSG_TAB_MTX`) protects socket allocation/deallocation
- **Per-socket mutex** (`vs->mtx`) protects endpoint operations
- **NNG is thread-safe** internally for send/recv

---

## Usage Patterns

### Publisher

```c
int sock = vmsg_socket(VNET, VMSG_AF_SP, VMSG_PUB);
vmsg_bind(VNET, sock, "tcp://0.0.0.0:5555");
vmsg_send(VNET, "pub", sock, msg, msg_len, 0);
```

### Subscriber

```c
int sock = vmsg_socket(VNET, VMSG_AF_SP, VMSG_SUB);
vmsg_connect(VNET, sock, "tcp://publisher:5555");
vmsg_setsockopt(VNET, sock, 0, VMSG_SUBSCRIBE, "", 0);  // Subscribe to all
vmsg_recv(VNET, sock, buf, sizeof(buf), 0);
```

### Pipeline (Work Distribution)

```c
// Pusher
int push = vmsg_socket(VNET, VMSG_AF_SP, VMSG_PUSH);
vmsg_bind(VNET, push, "tcp://0.0.0.0:5556");
vmsg_send(VNET, "push", push, work, work_len, 0);

// Puller (worker)
int pull = vmsg_socket(VNET, VMSG_AF_SP, VMSG_PULL);
vmsg_connect(VNET, pull, "tcp://dispatcher:5556");
vmsg_recv(VNET, pull, buf, sizeof(buf), 0);
```

---

## Constants

```c
#define VMSG_MAX_SOCKETS    64    // Max concurrent sockets
#define VMSG_MAX_ENDPOINTS  16    // Max endpoints per socket
#define VMSG_BYTES_PER_MSG_EST 1400  // Bytes-to-messages conversion factor
```

---

## Conditional Compilation

```c
#define USE_NNG  // Use NNG backend (default)

#ifdef USE_NNG
    // NNG implementation
#else
    // nanomsg fallback
#endif
```

The nanomsg backend is simpler (direct passthrough) but less actively maintained.

---

## Integration Points

**Used By:**
- `valis_net_MT.c` - Multi-threaded networking
- `dataflow.c` - Inter-node communication
- Network layer components

**Depends On:**
- `_valis.h` - `vnet_context_t` definition
- NNG library (`libnng`)

---

## Design Notes

1. **Context Isolation** - All state in `vnet_context_t` allows multiple independent network contexts
2. **Handle-Based API** - Integer handles (like file descriptors) simplify resource management
3. **Automatic Reconnection** - Dialers use non-blocking start with background redial
4. **Portable Abstraction** - Same API works with NNG or nanomsg

---

## Related Files

- `valis_messaging.h` - API declarations
- `nng_shim.c` - Additional NNG utilities (626 lines)
- `valis_net_MT.c` - Multi-threaded networking using this module
- `websockets.h` - WebSocket definitions (384 lines)
