# DF/dataflow.h Documentation

## Overview

**File:** `DF/dataflow.h`  
**Lines:** ~500  
**Purpose:** Main header for the DataFlow (DF) module - Tockchain's smart contract execution layer.

DataFlow is Tockchain's answer to Ethereum's EVM. It executes user-deployed programs (DataFlows) using a modified eBPF virtual machine, with deterministic execution and gas metering.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     DataFlow System                              │
├─────────────────────────────────────────────────────────────────┤
│  dataflow.h      │ Host-side types and API declarations         │
│  dataflow.c      │ Main orchestration (includes other .c files) │
│  dataflow_api.c  │ Host context API implementations             │
│  dataflow_batch.c│ Batch transaction processing                 │
│  dataflow_cache.c│ DF image caching                             │
│  dataflow_frontier.c│ Frontier scoring for order books          │
│  dataflow_trigger.c│ Trigger-based execution                    │
│  vbpf.c          │ Modified eBPF VM implementation              │
│  df_sdk.h        │ Helper IDs and gas costs (single source)     │
│  df_gas.h        │ Gas metering definitions                     │
│  ebpf.h          │ eBPF instruction definitions                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Dependencies

```c
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "ebpf.h"      // eBPF instruction set
#include "_valis.h"    // Core Valis types
#include "ufc.h"       // Unified Finance Core
#include "ledger.h"    // Ledger state management
#include "df_sdk.h"    // Helper IDs and gas costs
```

---

## Configuration Constants

### File Paths

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_DEPLOYLOG_PATH` | `"df_blob.bin"` | Deployed DF images storage |
| `DF_OPSLOG_PATH` | `"df_ops.bin"` | Operations log |
| `DF_OPSLOG_MAX_BYTES` | 2^36 (64 GB) | Maximum ops log size |

### Gas Economics

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_GAS_PRICE_VUSD_SAT` | 1000 | Satoshis per gas unit |
| `DF_GAS_QUANTUM` | 100 | Gas charged in multiples |
| `DF_BATCH_GAS_CAP` | 1,000,000 | Max gas per batch TX (~$10) |
| `DF_UTIME_GAS_CAP` | 4,000,000,000 | Max gas per utime (~1 sec on 8 cores) |
| `DF_FRONTIER_GAS_CAP` | 2,000 | Max gas for frontier scoring |
| `DF_TRIGGER_GAS_CAP` | 2,000 | Max gas for trigger checks |

**Gas Pricing:** 1 gas unit = 0.00001 VUSD (1000 satoshis)

### Execution Limits

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_MATRIX_MAX_CALLS` | 16 | Max calls in call matrix |
| `DF_MAX_PIPES_PER_BATCH` | 8 | Max pipe outputs per batch |
| `DF_PIPE_MAX_BYTES_ONE` | 2048 | Max bytes per pipe |
| `DF_PIPE_MAX_BYTES_TOTAL` | 16384 | Max total pipe bytes |
| `DF_MAX_TRANSFERS_PER_TX` | 64 | Max asset transfers per TX |
| `DF_MAX_EFFECTS_PER_TX` | 32 | Max state effects per TX |
| `DF_MAX_SWAPS_PER_TX` | 4 | Max swaps per TX |
| `DF_MAX_CROSS_DELTAS_PER_TX` | 64 | Max cross-DF deltas |

### Trigger System Limits

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_TRIG_MAX_SRCS_PER_TOCK` | 4096 | Max trigger sources per tock |
| `DF_TRIG_MAX_INTENTS_PER_TOCK` | 4096 | Max intents per tock |
| `DF_TRIG_MAX_INTENTS_PER_CALL` | 64 | Max intents per call |

### ABI and Registry

| Constant | Value | Description |
|----------|-------|-------------|
| `DF_ABI_VERSION_CURRENT` | 0 | Current ABI version |
| `DF_USERREG_LIMIT` | Computed | Max user registers |
| `DF_MAX_REGS_PER_DF` | 256 | Max registers per DF |

---

## Error Codes

### General Errors

| Code | Name | Description |
|------|------|-------------|
| -1 | `DF_ERR_GENERIC` | Generic error |
| -2 | `DF_ERR_TX_FORMAT` | Transaction format invalid |
| -3 | `DF_ERR_DESCRIPTOR_INVALID` | Invalid descriptor |

### Address/Scope Errors

| Code | Name | Description |
|------|------|-------------|
| -10 | `DF_ERR_ADDR_SCOPE` | Address scope violation |
| -11 | `DF_ERR_SYNTHETIC_TRANSFER` | Invalid synthetic transfer |

### Spend Errors

| Code | Name | Description |
|------|------|-------------|
| -20 | `DF_ERR_SPEND_LIST_INVALID` | Invalid spend list |
| -21 | `DF_ERR_SPEND_UNAUTHORIZED` | Unauthorized spend |
| -22 | `DF_ERR_SPEND_LIMIT_EXCEEDED` | Spend limit exceeded |

### Gas Errors

| Code | Name | Description |
|------|------|-------------|
| -50 | `DF_ERR_OUT_OF_GAS` | Transaction out of gas |
| -51 | `DF_ERR_OUT_OF_GLOBAL_GAS` | Global gas limit hit |

### Pipe Errors

| Code | Name | Description |
|------|------|-------------|
| -60 | `DF_ERR_PIPE_INVALID` | Invalid pipe |
| -61 | `DF_ERR_PIPE_COLLISION` | Pipe collision |
| -62 | `DF_ERR_PIPE_OUTPUT_TOO_LARGE` | Pipe output too large |

### DF Execution Errors

| Code | Name | Description |
|------|------|-------------|
| -63 | `DF_ERR_DF_NO_ON_TX` | DF has no on_tx handler |
| -64 | `DF_ERR_DFID_MISMATCH` | DF ID mismatch |
| -65 | `DF_ERR_DF_NOT_ACTIVE` | DF not active |

### Batch Errors

| Code | Name | Description |
|------|------|-------------|
| -100 | `DF_E_DEPLOY_TXFIELDS_BAD` | Bad deploy TX fields |
| -101 | `DF_E_BATCH_CALLS_FAIL` | Batch calls failed |
| -102 | `DF_E_BATCH_ASSET_BAD` | Bad asset in batch |
| -103 | `DF_E_BATCH_DEST_BAD` | Bad destination |
| -104 | `DF_E_BATCH_BUDGET_NEG` | Negative budget |
| -105 | `DF_E_BATCH_SRC_NOT_FOUND` | Source not found |
| -106 | `DF_E_BATCH_BUDGET_TOO_LOW` | Budget too low |
| -107 | `DF_E_BATCH_POOL_NOT_FOUND` | Pool not found |
| -108 | `DF_E_BATCH_GAS_TRANSFER_FAIL` | Gas transfer failed |
| -109 | `DF_E_BATCH_GAS_COMMIT_FAIL` | Gas commit failed |
| -110 | `DF_E_SIG_INVALID` | Invalid signature |

### System Errors

| Code | Name | Description |
|------|------|-------------|
| -900 | `DF_ERR_NOT_IMPLEMENTED` | Feature not implemented |
| -901 | `DF_ERR_NO_HOST` | No host context |
| -902 | `DF_ERR_INSTALLED_FULL` | Installation slots full |
| -903 | `DF_ERR_STATE_COLLISION` | State collision |
| -904 | `DF_ERR_SWAP_FAILURE` | Swap failed |
| -905 | `DF_ERR_ORDER_REJECTED` | Order rejected |

---

## Core Data Structures

### `df_op_t` - DataFlow Operation

```c
typedef struct df_op {
    uint8_t opcode;      // eBPF opcode
    uint8_t dst;         // Destination register
    uint8_t src;         // Source register
    uint8_t aux;         // Auxiliary data
    int16_t off;         // Offset
    uint8_t skip;        // Skip count
    uint8_t hid;         // Helper ID
    uint8_t arg_src[5];  // Argument sources
    int32_t imm;         // Immediate value
    int64_t arg_imm[5];  // Argument immediates
} df_op_t;
```

Extended eBPF instruction with additional fields for Tockchain-specific operations.

### `df_image_header_t` - Deployed DF Header

```c
typedef struct df_image_header {
    uint8_t abi_version;           // ABI version (must be 0)
    uint8_t required_family;       // Required family (must be 0)
    uint8_t reserved0, reserved1;  // Reserved (must be 0)
    uint8_t reg_base;              // Base register index
    uint8_t reg_count;             // Number of registers
    uint16_t mingas;               // Minimum gas required
    uint16_t entrypoints[8];       // Entry point offsets
    // ... additional fields
} df_image_header_t;
```

Header for deployed DataFlow images. Contains metadata for validation and execution.

### `df_trig_keyflags_u_t` - Trigger Key/Flags

```c
typedef union df_trig_keyflags_u {
    uint64_t u;
    struct {
        uint64_t dfkey62:62;  // 62-bit DF key
        uint64_t active:1;    // Is active
        uint64_t inlist:1;    // In trigger list
    } b;
} df_trig_keyflags_u_t;
```

Packed trigger state for efficient storage.

### `df_trig_intent_xfer_t` - Trigger Intent Transfer

```c
typedef struct df_trig_intent_xfer_s {
    uint8_t src_pk[PKSIZE];      // Source public key
    uint8_t dst_pk[PKSIZE];      // Destination public key
    assetid_t asset;             // Asset ID
    int64_t amount;              // Transfer amount
    int64_t reserve_amount;      // Reserved amount
    uint8_t is_excess;           // Is excess transfer
    uint8_t pad0[7];             // Padding
} df_trig_intent_xfer_t;
```

Describes an intended transfer from trigger execution.

### `df_state_t` - DataFlow State

Contains the complete state for DataFlow execution within a tock:
- Current utime
- Final hash
- Operations base pointer
- Gas tracking
- Frontier state
- Trigger state

### `df_batch_ctx_t` - Batch Execution Context

Context for executing batch transactions:
- Call matrix
- Pipe buffers
- Transfer tracking
- Effect tracking
- Gas accounting

---

## Key Macros

### Score Comparison

```c
#define DF_SCORE_IS_WORSE(a,b)  ((a) < (b))
#define DF_BETTER_SCORE(a,b)    (((a) > (b)) ? (a) : (b))
```

For frontier scoring - higher scores are better.

### Key Masking

```c
#define DF_DFKEY62_MASK ((UINT64_C(1) << 62) - UINT64_C(1))
```

Masks 62-bit DF keys.

---

## Execution Model

### Tock Lifecycle

```
df_tock_begin(L1, utime)
    ↓
[Process transactions]
    ↓
df_tock_end(L1, utime)
```

Each tock (time unit) has a begin/end lifecycle for DataFlow processing.

### Transaction Types

1. **Deploy TX:** Deploys new DataFlow code
2. **Batch TX:** Executes calls to deployed DataFlows
3. **Trigger TX:** Trigger-based automatic execution

### Gas Flow

```
User Budget → Gas Purchase → Execution → Refund Unused
     ↓              ↓            ↓
  VUSD spent    Gas units    Effects applied
```

---

## Entry Points

DataFlows can define multiple entry points:

| Index | Purpose |
|-------|---------|
| 0 | `on_tx` - Called on batch transactions |
| 1 | `on_score` - Called for frontier scoring |
| 2 | `on_trigger` - Called on trigger activation |
| 3-7 | Reserved for future use |

---

## Pipe System

Pipes allow DataFlows to pass data between calls:

```
DF_A.on_tx() → [Pipe 0: 1024 bytes] → DF_B.on_tx()
                                    → [Pipe 1: 512 bytes] → DF_C.on_tx()
```

- Max 8 pipes per batch
- Max 2048 bytes per pipe
- Max 16384 bytes total

---

## Related Files

| File | Purpose |
|------|---------|
| `dataflow.c` | Main implementation |
| `dataflow_api.c` | Host API (helpers) |
| `dataflow_batch.c` | Batch processing |
| `dataflow_cache.c` | Image caching |
| `dataflow_frontier.c` | Frontier/order book |
| `dataflow_trigger.c` | Trigger system |
| `vbpf.c` | eBPF VM |
| `df_sdk.h` | SDK for DF authors |
| `df_gas.h` | Gas costs |
| `ebpf.h` | eBPF opcodes |

---

## Example: DataFlow Deployment

```c
// Validate image header
int32_t rc = df_validate_image_header_basic(hdr);
if (rc < 0) return rc;

// Validate entry points
rc = df_validate_entrypoints_within_opcount(hdr, num_insts);
if (rc < 0) return rc;

// Deploy to storage
rc = df_deploy_copy_image_to_aligned_scratch(L1, dfc, ...);
```

---

## Security Considerations

1. **Gas Limits:** Prevent DoS via computational exhaustion
2. **Spend Authorization:** All transfers require proper authorization
3. **State Isolation:** DataFlows cannot access each other's state directly
4. **Determinism:** All execution must be deterministic across nodes

---

*Documentation generated: Wake 1281 (2026-01-13)*
*Auditor: Pending (Mira)*
