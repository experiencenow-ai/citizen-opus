# Generator Module Documentation

## Overview

The Generator module (`generator/gen3*.c`) is the **heart of Tockchain consensus**. It manages the per-second "tock" cycle where validators coordinate to produce blocks, handle transactions, and maintain network synchronization.

**Total Size:** ~20,900 lines across 12 files

## File Structure

| File | Lines | Purpose |
|------|-------|---------|
| `gen3.c` | 908 | Main loop, state machine, initialization |
| `gen3.h` | 587 | Header with structures, constants, macros |
| `gen3_chain.c` | 850 | Chain management, tock finalization |
| `gen3_metrics.c` | 1,564 | Performance metrics, monitoring |
| `gen3_needbits.c` | 640 | Bit manipulation for node masks |
| `gen3_net.c` | 755 | Network communication, packet handling |
| `gen3_nodechange.c` | 745 | Validator set changes, elections |
| `gen3_rawtock.c` | 632 | Raw tock data processing |
| `gen3_ssd.c` | 2,037 | SSD storage, persistence |
| `gen3_utils.c` | 393 | Utility functions |
| `gen3_vans.c` | 881 | VAN (Validator Assigned Number) handling |
| `gen3_vote.c` | 1,188 | Voting mechanism, quorum |
| `obsolete.h` | 9,742 | Legacy code (reference only) |

## Core Concepts

### The Tock Cycle

Tockchain produces one "tock" per second. Each tock goes through a state machine:

```
USTATE_IDLE → USTATE_NEW_UTIME → USTATE_ADMIT_NORMAL → USTATE_ADMIT_VIP_ONLY → USTATE_WAITFOR_QUORUM → (finalize) → USTATE_IDLE
```

**States:**
- `USTATE_IDLE (0)`: Waiting for next second
- `USTATE_NEW_UTIME (1)`: New timestamp, begin processing
- `USTATE_ADMIT_NORMAL (2)`: Accept normal transactions
- `USTATE_ADMIT_VIP_ONLY (3)`: Only VIP transactions (under load)
- `USTATE_WAITFOR_QUORUM (4)`: Waiting for validator consensus

### VANs (Validator Assigned Numbers)

Each validator is assigned a VAN - their unique identifier in the current validator set. VANs are used for:
- Tracking which validators have submitted data
- Building consensus masks (bitmasks of participating validators)
- Assigning transaction processing responsibility

Key constants:
- `ACTIVE_VANS_MAX`: Maximum active VANs per node (2)
- `ILLEGAL_VANID`: Sentinel value for invalid VAN (0xFFFF)

### Node Masks

The system uses 64-bit masks to track validator participation:
- `activenodes`: Bitmask of currently active validators
- `havehashmasks`: Which validators have submitted hash commitments
- `havevansmasks`: Which validators have submitted VAN data

## Main Functions

### gen3.c

```c
void *valis_loop(void *arg)
```
**The main generator loop.** Runs continuously, processing:
1. New timestamps (once per second)
2. Node change elections
3. Metrics updates
4. Disk space management (pruning old data)
5. Packet processing

```c
int32_t utime_iter(global_reserve_t *GEN3, utime_data_t *U, int32_t fifoind)
```
**Per-tock iteration.** Advances the state machine for a single timestamp.

```c
void *fifoind_worker(void *arg)
```
**Worker thread** for processing tock data in parallel.

### State Machine Functions

```c
static uint64_t ustate_new_utime(utime_data_t *U)
static uint64_t ustate_admit_normal(utime_data_t *U)
static uint64_t ustate_admit_vip_only(utime_data_t *U)
static uint64_t ustate_waitfor_quorum(utime_data_t *U)
static uint64_t ustate_idle(utime_data_t *U)
```

Each returns a mask indicating which validators have completed their work for that state.

## Attack Mitigations (from source comments)

### Mitigated Attacks
| Attack | Mitigation |
|--------|------------|
| Fake nodetxidshash | Validation checks |
| Fake rawtockfile | -vonly mode validates all txids |
| Missing node | activenodes mask adjusts dynamically |
| VAN spam | Per-node limits prevent CPU exhaustion |
| TX spam | High processing capacity, uses archive space |
| Numsigs attack | Adaptive validator speed |
| Network partition | Cross-pollination after time delay |

### Open Issues
- Incomplete VANs sent (node sends hash but not all TX)
- Incomplete datasync
- RAM exhaustion from spam

### Anti-Geoclustering Design

The system includes a mechanism to prevent geographic centralization:

1. **Latency Measurement**: Nodes gossip signed pings to build a Network Distance Matrix
2. **Cluster Detection**: Nodes with <5ms latency are in same cluster (same datacenter/city)
3. **Score Cap**: No latency cluster can control more than X% of total score
4. **Effect**: Prevents AWS-US-East (or similar) from dominating the network

## Key Data Structures

### From gen3.h

```c
struct vbond_info {
    uint8_t addr20[PKSIZE];      // 20-byte address
    int64_t vbonds, vusd, VUSDvalue;
    uint32_t lockutime;
    int8_t nodeid;
};
```

### Node Change Constants

```c
#define NODECHANGE_EPOCH_RESOLUTION 60           // Must be 0 mod VNET_FIFOSIZE
#define NODECHANGE_VOTER_REMOVAL_THRESHOLD 99000000  // 99% in satoshi fractions
#define NODECHANGE_CANDIDATE_REMOVAL_THRESHOLD 3     // Worst 3 nodes can be removed
```

## Integration Points

### Dependencies
- `_valis.h`: Core Valis definitions
- `ufc.h`: UFC (Unified Financial Core) integration
- `ledger.h`: Ledger state management

### Used By
- Main test harness (test.c)
- Websocket daemon (websocketd.c)

## File-by-File Details

### gen3_vote.c (1,188 lines)
Handles the voting mechanism for consensus:
- Quorum calculation
- Vote aggregation
- Finality determination

### gen3_nodechange.c (745 lines)
Manages validator set changes:
- Election epochs (every 60 seconds)
- Candidate addition/removal
- Voter removal thresholds

### gen3_ssd.c (2,037 lines)
Persistent storage:
- Tock data serialization
- State snapshots
- Recovery from disk

### gen3_metrics.c (1,564 lines)
Performance monitoring:
- Throughput tracking
- Latency measurements
- Node health metrics

## TODO Items (from source)

High priority:
- [ ] Bridge: autoconvert incoming WETH to ETH
- [ ] Bridge: check sigtx confirmed, resend if not
- [ ] Bridge: EBD system to avoid dust extraction
- [ ] Dataflow support for UFC taker
- [ ] Pylon integration

Medium priority:
- [ ] Charge for oversized/coldvans
- [ ] Limit erc20 addaddrhash
- [ ] Don't prune if liabilities exist
- [ ] Radix sort hourly
- [ ] Falcon systemtx

## Diagram: Tock State Machine

```
                    ┌─────────────────┐
                    │   USTATE_IDLE   │
                    │   (waiting)     │
                    └────────┬────────┘
                             │ new second
                             ▼
                    ┌─────────────────┐
                    │ USTATE_NEW_UTIME│
                    │ (initialize)    │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │USTATE_ADMIT_    │
                    │NORMAL           │
                    │(accept all TX)  │
                    └────────┬────────┘
                             │ load high OR timeout
                             ▼
                    ┌─────────────────┐
                    │USTATE_ADMIT_    │
                    │VIP_ONLY         │
                    │(priority TX)    │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │USTATE_WAITFOR_  │
                    │QUORUM           │
                    │(consensus)      │
                    └────────┬────────┘
                             │ quorum reached
                             ▼
                    ┌─────────────────┐
                    │   FINALIZE      │
                    │   (commit)      │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │   USTATE_IDLE   │
                    └─────────────────┘
```

## Diagram: Generator Module Dependencies

```
                         ┌──────────────┐
                         │   gen3.h     │
                         │  (header)    │
                         └──────┬───────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
        ▼                       ▼                       ▼
┌───────────────┐      ┌───────────────┐      ┌───────────────┐
│   gen3.c      │      │ gen3_vote.c   │      │gen3_chain.c   │
│ (main loop)   │      │ (consensus)   │      │(finalization) │
└───────────────┘      └───────────────┘      └───────────────┘
        │
        ├──────────────────────────────────────────────────┐
        │                                                  │
        ▼                                                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│gen3_vans.c    │  │gen3_net.c     │  │gen3_ssd.c     │  │gen3_metrics.c │
│(VAN handling) │  │(networking)   │  │(storage)      │  │(monitoring)   │
└───────────────┘  └───────────────┘  └───────────────┘  └───────────────┘
        │
        ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│gen3_nodechange│  │gen3_rawtock.c │  │gen3_needbits.c│
│(elections)    │  │(raw data)     │  │(bit ops)      │
└───────────────┘  └───────────────┘  └───────────────┘
```

---
*Documentation generated by Opus, Wake 1277*
*Last updated: 2026-01-13*
