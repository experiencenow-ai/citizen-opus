# Validator Module Documentation

## Overview

The Validator module (`validator/*.c`) handles **ledger state management**, **transaction validation**, and **consensus participation**. It maintains the authoritative state of all accounts, assets, and balances on Tockchain.

**Total Size:** ~10,500 lines across 10 files

## File Structure

| File | Lines | Purpose |
|------|-------|---------|
| `validator.c` | 1,092 | Main validator logic, tock processing |
| `validator.h` | 725 | Core structures, port definitions |
| `ledger.h` | 528 | Ledger structures, asset ID layout |
| `ledger_assets.c` | 1,454 | Asset management, minting, burning |
| `ledger_atomic.c` | 973 | Atomic operations, swaps |
| `ledger_erc20.c` | 1,439 | ERC-20 token handling |
| `ledger_hourly.c` | 1,127 | Hourly aggregations, snapshots |
| `ledger_pylon7.c` | 1,042 | Pylon integration (cold storage) |
| `ledger_vhandlers.c` | 1,427 | Transaction handlers by type |
| `ledger_vtrade.c` | 738 | Trading operations |

## Core Concepts

### Port Configuration

```c
#define _L0CONNPORT VNET_PORT        // PUSH/PULL (generator communication)
#define _L1CONNPORT (VNET_PORT + 1)  // PUB/SUB (state updates)
#define _MIDDLEWAREPORT 9057         // websocketd connection
#define _WEBSOCKETSPORT 9999         // localhost API
#define _MCPORT 11211                // memcached port
#define DEFAULT_BASEPORT 31500       // base for dynamic ports
```

### Synthetic Asset ID Layout

The top of the asset ID space is reserved for synthetic/special assets:

```
SYNTH_AID_TOP (2^NUM_ASSETID_BITS)
    │
    ├── _COINSMINTED             (TOP - 1)
    ├── _COINSBURNED             (TOP - 2)
    ├── _POOLSHARES              (TOP - 3)
    ├── _BRIDGESTATE             (TOP - 4)
    ├── _ASSET_DF_META           (TOP - 5)
    ├── _ASSET_DF_SPEND_WILDCARD (TOP - 6)
    ├── _ADDRESS_LABEL           (TOP - 7)
    ├── _ADDRESS_LABEL2          (TOP - 8)
    ├── _ASSET_DF_CRV            (TOP - 9)
    │
    ├── UFC_ALPHA (16 slots)
    ├── PYLON_COLD (12 slots)
    ├── DF_SYNTHETICS (512 slots)
    ├── DF_MODREC (12 slots)
    ├── DF_FRONTIER_WORST (4 slots)
    └── TRIG (4 slots)
    
    Total: ~570 synthetic slots (budget: 1024)
```

### Chain IDs

```c
#define ETHEREUM_CHAINID ((1 << DESTCHAINBITS) - 1)  // Max value
#define SOL_CHAINID      ((1 << DESTCHAINBITS) - 2)  // Solana
#define TBD_CHAINID      ((1 << DESTCHAINBITS) - 3)  // Reserved
```

## Key Data Structures

### L1_state (Ledger State)

```c
struct L1_state {
    // Hashes for verification
    uint8_t validators_hash[32];
    uint8_t prevtockdatahash[32];
    uint8_t hourlytablehash[32];
    
    // Counters
    int64_t totaltx, totalfailed, totalchanges;
    int64_t NextAddressind, totalswept;
    int64_t VUSDminted, VUSDburned;
    int64_t checksum64, totalduplicatetxids;
    
    // Bridge state
    int64_t bridge_VUSDvalue, next_batchid;
    int64_t current_gasgwei, current_withdrawgas;
    int64_t numburns, numdeposits, crosschainburns;
    
    // Configuration
    uint32_t genesis_utime, prevutime, airdroputime;
    int32_t numassets, emptytocks, RLnonz;
    uint8_t numshards, numvalidators, shard, chainid;
    
    // Rich list for coinbase distribution
    struct pubkeyamount adjVUSDrichlist[RICHLISTSIZE];
};
```

### tockdata (Per-Tock Data)

```c
struct tockdata {
    valis_ballot_t tockdatahash;  // Must be first
    uint8_t resthash[32];
    struct burnproofhdr bph;
    struct tockdata_rest rest;
    struct balancechange bchanges[];  // Variable length
    // Followed by: numfailed * txinds
};

struct tockdata_rest {
    uint8_t finalhash[32], statehash[32];
    int32_t numtx, numfailed, numchanges;
    int32_t numduplicatetxids, numbatches, extra;
};
```

### withdraw_entry (Bridge Withdrawals)

```c
struct withdraw_entry {
    uint8_t txid[32];
    uint8_t srcaddr[PKSIZE];
    uint8_t destaddr[PKSIZE];
    int64_t VUSDvalue, amount;
    tockid_t tid;
    assetid_t asset;
};
```

## Main Functions

### validator.c

```c
void *validator_main(void *_args)
```
**Entry point** for validator thread. Initializes state and enters main loop.

```c
int32_t L1process_tock(struct valisL1_info *L1, uint32_t utime)
```
**Process a single tock.** Validates transactions, updates ledger, computes tockdata hash.

```c
int32_t update_ledger(struct valisL1_info *L1, uint32_t utime)
```
**Apply all transactions** from the current tock to the ledger state.

```c
void calc_tockdata(struct valisL1_info *L1, struct tockdata *td, uint32_t utime, int32_t numbatches)
```
**Compute tockdata structure** including merkle roots and state hashes.

```c
int64_t distribute_coinbase(struct valisL1_info *L1, uint32_t utime, uint64_t entropy)
```
**Distribute block rewards.** Uses entropy for fair distribution among validators and rich list.

### Signature Verification

```c
int32_t valis_eval_all_txsigs_adaptive(struct valisL1_info *L1, uint32_t utime)
```
**Adaptive signature verification.** Dynamically adjusts thread count based on transaction volume.

```c
int32_t valis_choose_sig_threads(int32_t total_tx)
```
**Thread count selection.** Returns optimal number of signature verification threads.

```c
static void txsig_compute_signhash4(...)
```
**Batch signature hashing.** Processes 4 signatures in parallel for efficiency.

## Ledger Submodules

### ledger_assets.c (1,454 lines)
Asset lifecycle management:
- Asset creation and registration
- Minting and burning
- Balance queries
- Asset metadata

### ledger_atomic.c (973 lines)
Atomic operations:
- Multi-asset swaps
- Conditional transfers
- Rollback on failure

### ledger_erc20.c (1,439 lines)
ERC-20 compatibility:
- Token deposits from Ethereum
- Token withdrawals to Ethereum
- Balance tracking per token

### ledger_hourly.c (1,127 lines)
Periodic aggregations:
- Hourly snapshots
- Statistics computation
- Historical data pruning

### ledger_pylon7.c (1,042 lines)
Pylon cold storage:
- Cold wallet management
- Delayed withdrawals
- Security policies

### ledger_vhandlers.c (1,427 lines)
Transaction type handlers:
- Transfer handler
- Swap handler
- Bridge handler
- System transaction handler

### ledger_vtrade.c (738 lines)
Trading operations:
- Order matching
- Price discovery
- Trade execution

## Coinbase Distribution

The coinbase (block reward) distribution uses a weighted random selection:

```c
int32_t topN[7] = TOPN;  // Distribution tiers

// Distribution by utime % 10:
// 0-6: Select from top N of rich list (N varies by modval)
// 7-8: Select from active validators
// 9: Reserved
```

This creates a hybrid model where:
1. Large stakeholders receive proportional rewards (0-6)
2. Active validators receive operational rewards (7-8)

## Halving Schedule

```c
if (utime >= GENESIS_UTIME + HALVING_TIME) {
    elapsed = timediff(utime, GENESIS_UTIME);
    halvings = (int32_t)(elapsed / HALVING_TIME);
    tockreward = (SATOSHIS >> halvings);
}
```

Block rewards halve periodically, similar to Bitcoin's model.

## Integration Points

### Dependencies
- `ufc.h`: UFC (Unified Financial Core)
- `gen3.h`: Generator module
- `bridge.h`: Ethereum bridge
- `dataflow.h`: Dataflow system

### Includes (via validator.c)
```c
#include "ledger_atomic.c"
#include "ledger_vtrade.c"
#include "ledger_erc20.c"
#include "ledger_assets.c"
#include "ledger_hourly.c"
#include "ledger_pylon7.c"
#include "ledger_vhandlers.c"
#include "ufc_utils.c"
#include "ufc_scan.c"
#include "ufc_swap.c"
#include "ufc_pool.c"
#include "ufc_planner.c"
#include "ufc_oob.c"
#include "ufc_orderbook.c"
#include "ufc.c"
#include "bridge.h"
```

## Diagram: Validator Data Flow

```
                    ┌─────────────────┐
                    │   Generator     │
                    │   (gen3.c)      │
                    └────────┬────────┘
                             │ tock data
                             ▼
                    ┌─────────────────┐
                    │   validator.c   │
                    │  L1process_tock │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ledger_vhandlers│   │ledger_atomic │   │ledger_erc20  │
│(tx dispatch)  │   │(atomic ops)  │   │(tokens)      │
└───────────────┘   └───────────────┘   └───────────────┘
        │                    │                    │
        └────────────────────┼────────────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │   L1_state      │
                    │  (ledger)       │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ledger_hourly  │   │ledger_assets │   │ledger_pylon7 │
│(snapshots)    │   │(balances)    │   │(cold storage)│
└───────────────┘   └───────────────┘   └───────────────┘
```

## Diagram: Tock Processing Pipeline

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Receive TX  │ ──▶ │ Verify Sigs │ ──▶ │ Apply to    │
│ from tock   │     │ (adaptive)  │     │ Ledger      │
└─────────────┘     └─────────────┘     └─────────────┘
                                               │
                                               ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Broadcast   │ ◀── │ Compute     │ ◀── │ Calc State  │
│ tockdata    │     │ tockdatahash│     │ Changes     │
└─────────────┘     └─────────────┘     └─────────────┘
```

## Error Handling

The validator tracks:
- `totalfailed`: Transactions that failed validation
- `numduplicatetxids`: Duplicate transaction attempts
- `emptytocks`: Tocks with no transactions

Failed transactions are recorded in `failedroot` merkle tree for auditability.

---
*Documentation generated by Opus, Wake 1277*
*Last updated: 2026-01-13*
