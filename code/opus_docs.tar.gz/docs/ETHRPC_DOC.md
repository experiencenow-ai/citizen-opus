# ethrpc.c - Ethereum RPC Client

## Overview

`ethrpc.c` is the Ethereum JSON-RPC client implementation for Tockchain's bridge system. It provides a comprehensive interface for communicating with Ethereum nodes, handling everything from basic block queries to complex transaction construction and submission.

**Location:** `/root/valis/bridge/ethrpc.c`  
**Size:** ~2015 lines  
**Dependencies:** `_valis.h`, `bridge.h`, `bridge_rpc.h`, `yyjson.h`

## Architecture

### Design Philosophy

The module implements a **failover-first** architecture:
1. Queries first attempt the local Ethereum node (`ETH_LOCAL_URL`)
2. On failure or missing data, automatically retry with remote node (`ETH_REMOTE_URL`)
3. Different query types have different failover strategies

### Core Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    High-Level API                           │
│  (get_balance, check_erc20_balance, send_ETH_transaction)  │
├─────────────────────────────────────────────────────────────┤
│                  Mid-Level Wrappers                         │
│  (txid_lookup, get_tx_receipt, eth_getLogs_range_topic0)   │
├─────────────────────────────────────────────────────────────┤
│                  Failover Layer                             │
│  (rpc_json_failover, rpc_result_str)                       │
├─────────────────────────────────────────────────────────────┤
│                  Transport Layer                            │
│  (rpc_json from bridge_rpc.c)                              │
└─────────────────────────────────────────────────────────────┘
```

## Key Functions

### RPC Infrastructure

#### `rpc_json_failover()`
```c
int32_t rpc_json_failover(const char *method, const curl_params_t *P_in, 
                          char *result_buffer, int32_t buffer_size, 
                          int64_t target_block, bool force_remote)
```
Core RPC function with intelligent failover:
- Tries local node first (unless `force_remote`)
- Falls back to remote on failure
- Handles hash lookups vs state queries differently
- Hash lookups (tx by hash, receipts, logs) always retry remote on miss
- State queries (eth_call, getBalance) check if local node is behind

#### `rpc_result_str()`
```c
int32_t rpc_result_str(const char *method, const curl_params_t *P_in,
                       char *result_buffer, int32_t buffer_size,
                       int64_t target_block, bool force_remote)
```
Wrapper that extracts just the `result` field from JSON-RPC response.

### Block Queries

#### `get_latest_block()` / `get_finalized_block()`
```c
int32_t get_latest_block(uint64_t *out_block_number)
int32_t get_finalized_block(uint64_t *out_block_number)
```
Get current blockchain head positions.

#### `get_block_timestamp()`
```c
int32_t get_block_timestamp(uint64_t block_number, uint64_t *timestamp, 
                            uint8_t blockhash[32])
```
Retrieve timestamp and hash for a specific block.

#### `get_latest_basefee()`
```c
int32_t get_latest_basefee(uint64_t *basefee_out)
```
Get current EIP-1559 base fee for gas estimation.

### Transaction Operations

#### `txid_lookup()` / `get_tx_receipt()`
```c
int32_t txid_lookup(const char *txid, char *result_json_buffer, int32_t buffer_size)
int32_t get_tx_receipt(const char *txid, char *result_json_buffer, int32_t buffer_size)
```
Look up transaction details and receipts by hash.

#### `send_ETH_transaction()`
```c
int32_t send_ETH_transaction(const char *signed_tx, char *tx_hash, int32_t hash_size)
```
Broadcast a signed transaction to the network.

#### `send_calldata()`
```c
int32_t send_calldata(const char *to_hex, const char *data_hex, 
                      const char *from_hex_opt, char *out_data_hex, int32_t out_cap)
```
Execute `eth_call` (read-only contract call).

### Event Log Queries

#### `eth_getLogs_range_topic0()`
```c
int32_t eth_getLogs_range_topic0(const char *contract_address_hex, 
                                  uint64_t from_block, uint64_t to_block,
                                  const char *topic0_hex, 
                                  char *resp_out, int32_t resp_out_cap)
```
Query event logs by contract address and topic0 (event signature) across a block range.

#### `get_contract_logs()`
```c
int32_t get_contract_logs(const char *addr_hex, uint64_t from_block, 
                          uint64_t to_block, const char *topic0_hex,
                          char *resp_out, int32_t resp_out_cap)
```
Higher-level wrapper for log queries.

### ERC-20 Token Operations

#### `get_ethtoken_decimals()`
```c
int32_t get_ethtoken_decimals(const char *contract, uint8_t *decimals_out)
```
Query token decimals via `decimals()` call.

#### `check_erc20_balance()`
```c
int32_t check_erc20_balance(const char *token, uint8_t decimals,
                            const char *account, int64_t *balancep)
```
Check ERC-20 token balance for an account.

#### `check_erc20_allowance()`
```c
int32_t check_erc20_allowance(const char *token, const char *owner, 
                               const char *spender, uint64_t *allowance)
```
Check token spending allowance.

### Transaction Construction

#### `create_approve_tx_data()`
```c
void create_approve_tx_data(const char *spender, const char *amount_hex, char *data_out)
```
Build calldata for ERC-20 `approve()` transaction.

#### `create_deposit_token_tx_data()`
```c
void create_deposit_token_tx_data(const char *token, const char *amount_hex, 
                                   const char *recipient, char *data_out)
```
Build calldata for bridge token deposit.

#### `create_deposit_tx_data()`
```c
void create_deposit_tx_data(const char *recipient_bytes32, char *data_out)
```
Build calldata for native ETH bridge deposit.

### EIP-1559 Transaction Building

#### `send_executeBatch_tx()`
```c
int send_executeBatch_tx(const char *rpc_from_addr, const uint8_t module_addr20[20],
                         const uint8_t *calldata, int calldatalen,
                         const uint8_t privkey[32], uint64_t chain_id,
                         tmpmem_t *mem, char *tx_hash_out, int tx_hash_cap)
```
Complete EIP-1559 transaction construction and submission:
1. Fetches current nonce
2. Gets gas price and calculates tip/max fee
3. Estimates gas limit (with 20% buffer)
4. Builds transaction structure
5. Signs with provided private key
6. Broadcasts to network

### RLP Encoding Helpers

#### `rlp_push_u64_hex_field()` / `rlp_push_hash_field()`
```c
int32_t rlp_push_u64_hex_field(tmpmem_t *mem, const yyjson_val *obj,
                                const char *name, struct rlp_item *items, int32_t *nump)
int32_t rlp_push_hash_field(tmpmem_t *mem, const yyjson_val *obj,
                             const char *name, struct rlp_item *items, int32_t *nump)
```
Extract JSON fields and push to RLP encoding buffer.

### ABI Encoding Helpers

#### `abi_append_addr32()`
```c
void abi_append_addr32(char *dst, const char *addr)
```
Append address as 32-byte ABI-encoded parameter (left-padded with zeros).

## Query Type Classification

The failover logic distinguishes between query types:

**Hash Lookups** (always retry remote on miss):
- `eth_getTransactionByHash`
- `eth_getTransactionReceipt`
- `eth_getBlockByHash`
- `eth_getLogs`

**State Queries** (check if local is behind):
- `eth_call`
- `eth_getBalance`
- `eth_getStorageAt`
- `eth_getCode`
- `eth_getTransactionCount`
- `eth_estimateGas`

## Error Handling

Return codes follow consistent patterns:
- `0`: Success
- `-1`: Invalid parameters
- `-5`: Data not found after retries
- `-7`: Buffer too small
- `-10` to `-19`: Nonce/gas related errors
- `-42`, `-43`: JSON parsing errors

## Debug Support

#### `rpc_dbg_dump_params()`
```c
void rpc_dbg_dump_params(const char *where, const curl_params_t *P)
```
Dumps RPC parameter structure for debugging. Shows:
- URL being called
- Parameter count and types
- Parameter values (strings, bools, quantities)

## Integration Points

**Used by:**
- `bridge_deposit.c` - Deposit monitoring and processing
- `bridge_withdraw.c` - Withdrawal verification
- `bridge_prices.c` - Price oracle queries
- `bridge_mpt.c` - MPT proof fetching

**Depends on:**
- `bridge_rpc.c` - Low-level HTTP/JSON-RPC transport
- `yyjson` - JSON parsing
- `bridge_rlp.c` - RLP encoding for transactions

## Configuration

Key compile-time constants (defined elsewhere):
- `ETH_LOCAL_URL` - Local Ethereum node endpoint
- `ETH_REMOTE_URL` - Remote/fallback node endpoint
- `ETHRPC_TEMP_BUFSZ` - Temporary buffer size
- `ETHRPC_HTTP_TIMEOUT_SEC` - HTTP request timeout

## Security Considerations

1. **Private keys** passed to `send_executeBatch_tx()` are used only for signing, never logged
2. **Failover** to remote nodes may expose query patterns to third parties
3. **Gas estimation** includes 20% buffer to prevent out-of-gas failures
4. **Nonce management** is per-call; concurrent transactions need external coordination

## Typical Usage Flow

```
1. Query current state
   get_latest_block() -> current block number
   get_balance() -> ETH balance
   check_erc20_balance() -> token balance

2. Monitor events
   eth_getLogs_range_topic0() -> find deposit events
   get_tx_receipt() -> verify transaction status

3. Submit transaction
   create_deposit_tx_data() -> build calldata
   send_executeBatch_tx() -> sign and broadcast
   get_tx_receipt() -> confirm inclusion
```

---
*Documentation generated wake 1289 by Opus*
*Part of Tockchain documentation project*
