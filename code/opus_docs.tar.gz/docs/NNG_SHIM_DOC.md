# NNG Shim Module Documentation

**File:** `/root/valis/netlibs/nng_shim.c`  
**Lines:** 626  
**Purpose:** Nanomsg API emulation layer on top of NNG  
**Documented by:** Opus (Wake 1288)  
**Status:** Complete

---

## Overview

The NNG Shim provides a **nanomsg-compatible API** implemented on top of NNG (Nanomsg Next Generation). This allows code written for the original nanomsg library to run unchanged while using the more modern NNG library underneath.

**Why This Exists:**
- NNG is actively maintained; nanomsg is not
- NNG has better performance and features
- Existing code uses nanomsg API
- This shim bridges the gap

---

## Dependencies

```c
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <nng/nng.h>
#include <nng/protocol/pipeline0/push.h>
#include <nng/protocol/pipeline0/pull.h>
#include <nng/protocol/pubsub0/pub.h>
#include <nng/protocol/pubsub0/sub.h>
```

---

## Nanomsg Constants (Emulated)

```c
#define AF_SP                1     // Address family
#define NN_SOL_SOCKET        0     // Socket-level options
#define NN_PUSH              8     // Push socket type
#define NN_PULL              7     // Pull socket type
#define NN_PUB               2     // Publisher socket type
#define NN_SUB               1     // Subscriber socket type
#define NN_SUB_SUBSCRIBE     1     // Subscribe option
#define NN_SNDBUF            2     // Send buffer size
#define NN_RCVBUF            3     // Receive buffer size
#define NN_RCVMAXSIZE        16    // Max receive message size
#define NN_RCVFD             14    // Receive file descriptor
#define NN_DONTWAIT          1     // Non-blocking flag
#define EFSM                 156384713  // Protocol state error
#define ETERM                156384714  // Library terminating
```

---

## Configuration Constants

```c
#define VNN_MAX_SOCKETS            256   // Max concurrent sockets
#define VNN_MAX_ENDPOINTS_PER_SOCK 256   // Max endpoints per socket
#define VNN_MAX_URL                256   // Max URL length
#define VNN_BYTES_PER_MSG_EST      1400  // Bytes-to-messages estimate
```

---

## Internal Data Structures

### Endpoint Flags (Bitfield)

```c
struct vnn_ep_flags
{
    unsigned in_use : 1;     // Slot occupied
    unsigned started : 1;    // Dialer/listener started
    unsigned is_dialer : 1;  // 1=dialer, 0=listener
    unsigned reserved : 29;
};
```

### Endpoint Entry

```c
struct vnn_endpoint
{
    struct vnn_ep_flags f;
    int endpoint_id;                // Unique endpoint ID
    char url[VNN_MAX_URL];          // Endpoint URL
    nng_dialer d;                   // NNG dialer (if is_dialer)
    nng_listener l;                 // NNG listener (if !is_dialer)
};
```

### Socket Entry

```c
struct vnn_socket
{
    int in_use;                     // Slot occupied
    int domain;                     // Address family (AF_SP)
    int type;                       // NN_PUSH/PULL/PUB/SUB
    nng_socket s;                   // NNG socket handle
    pthread_mutex_t mtx;            // Per-socket mutex
    int next_eid;                   // Next endpoint ID
    int lazy_on_send;               // Lazy dialer start flag
    struct vnn_endpoint ep[VNN_MAX_ENDPOINTS_PER_SOCK];
};
```

### Global State

```c
static struct vnn_socket VNN_SOCKTAB[VNN_MAX_SOCKETS];
static pthread_mutex_t VNN_TAB_MTX = PTHREAD_MUTEX_INITIALIZER;
```

---

## Public API (Nanomsg-Compatible)

### nn_socket

```c
int nn_socket(int domain, int protocol)
```

**Purpose:** Create a new socket.

**Parameters:**
- `domain` - Address family (AF_SP)
- `protocol` - Socket type (NN_PUSH, NN_PULL, NN_PUB, NN_SUB)

**Returns:** Socket handle (≥0) or -1 on error.

**Implementation:**
1. Maps nanomsg protocol to NNG socket type
2. Opens NNG socket
3. Allocates slot in socket table
4. Sets `lazy_on_send=1` for PUSH sockets

---

### nn_bind

```c
int nn_bind(int sock, const char *url)
```

**Purpose:** Bind socket to listen on URL.

**Returns:** Endpoint ID (≥0) or -1 on error.

**Implementation:** Creates and starts NNG listener immediately.

---

### nn_connect

```c
int nn_connect(int sock, const char *url)
```

**Purpose:** Connect socket to remote URL.

**Returns:** Endpoint ID (≥0) or -1 on error.

**Implementation:** Creates NNG dialer, starts with `NNG_FLAG_NONBLOCK` for background reconnection. Errors are swallowed (nanomsg behavior).

---

### nn_shutdown

```c
int nn_shutdown(int sock, int endpoint)
```

**Purpose:** Close a specific endpoint.

**Returns:** 0 on success, -1 on error.

---

### nn_close

```c
int nn_close(int sock)
```

**Purpose:** Close socket and all endpoints.

**Returns:** 0 on success, -1 on error.

---

### nn_send

```c
int nn_send(int sock, const void *buf, size_t len, int flags)
```

**Purpose:** Send message on socket.

**Flags:** `NN_DONTWAIT` for non-blocking.

**Returns:** Bytes sent or -1 on error.

**Special Behavior:**
- Starts lazy dialers before sending (for PUSH sockets)
- **Drop-on-EAGAIN**: Returns success even if message dropped due to buffer full

```c
if (rc == NNG_EAGAIN)
    return (int)len; // drop-on-EAGAIN semantics
```

This matches nanomsg's behavior where PUSH sockets silently drop messages when no peers are connected.

---

### nn_recv

```c
int nn_recv(int sock, void *buf, size_t len, int flags)
```

**Purpose:** Receive message from socket.

**Flags:** `NN_DONTWAIT` for non-blocking.

**Returns:** Bytes received or -1 on error.

---

### nn_setsockopt

```c
int nn_setsockopt(int sock, int level, int option, const void *val, size_t sz)
```

**Purpose:** Set socket option.

**Supported Options:**

| Option | Level | Description |
|--------|-------|-------------|
| `NN_SUB_SUBSCRIBE` | - | Subscribe to topic prefix |
| `NN_RCVMAXSIZE` | `NN_SOL_SOCKET` | Max receive message size |
| `NN_SNDBUF` | `NN_SOL_SOCKET` | Send buffer size |
| `NN_RCVBUF` | `NN_SOL_SOCKET` | Receive buffer size |

**Buffer Size Conversion:**
```c
msgs = (bytes <= 0) ? 0 : (bytes / VNN_BYTES_PER_MSG_EST);
```

---

### nn_getsockopt

```c
int nn_getsockopt(int sock, int level, int option, void *val, size_t *szp)
```

**Purpose:** Get socket option.

**Supported:** `NN_RCVFD` - Returns pollable file descriptor for receive.

---

### nn_errno / nn_strerror

```c
int nn_errno(void)
const char *nn_strerror(int errnum)
```

**Purpose:** Error handling.

**Special Errors:**
- `EFSM` (156384713) - "Protocol state incorrect"
- `ETERM` (156384714) - "Library terminating"

---

## Internal Helper Functions

### vnn_errno_from_nng

```c
static int vnn_errno_from_nng(int nng_err)
```

Maps NNG error codes to standard errno values.

### vnn_alloc_sock_slot

```c
static int vnn_alloc_sock_slot(void)
```

Allocates a free slot in the socket table.

### vnn_get_sock

```c
static struct vnn_socket *vnn_get_sock(int sock)
```

Retrieves socket entry by handle, validates it's in use.

### vnn_add_dialer

```c
static int vnn_add_dialer(struct vnn_socket *vs, const char *url, 
                          int start_now, int *out_eid)
```

Creates and optionally starts an NNG dialer.

### vnn_add_listener

```c
static int vnn_add_listener(struct vnn_socket *vs, const char *url, int *out_eid)
```

Creates and starts an NNG listener.

### vnn_start_all_dialers_if_needed

```c
static void vnn_start_all_dialers_if_needed(struct vnn_socket *vs)
```

Starts any lazy dialers that haven't been started yet. Called before send on PUSH sockets.

---

## Lazy Dialer Pattern

For PUSH sockets, dialers are created but not immediately started. They're started lazily on first send:

```c
if (vs->lazy_on_send)
    vnn_start_all_dialers_if_needed(vs);
```

This matches nanomsg's behavior where you can connect before the remote is available.

---

## Thread Safety

- **Global mutex** (`VNN_TAB_MTX`) protects socket allocation
- **Per-socket mutex** (`vs->mtx`) protects endpoint operations
- **NNG is thread-safe** for send/recv

---

## Deprecated API Fallback

```c
#define VNN_NNG_USE_DEPRECATED_FALLBACK 0
```

When enabled, falls back to deprecated NNG APIs (`nng_setopt_*`) if modern APIs fail. Currently disabled.

---

## Differences from Real Nanomsg

1. **Subset Only** - Only APIs used by valis_net are implemented
2. **Drop-on-EAGAIN** - Explicitly drops messages when buffer full (requested behavior)
3. **Lazy Dialers** - PUSH sockets start dialers lazily
4. **No Zero-Copy** - Uses standard NNG send/recv, not zero-copy variants

---

## Usage Example

```c
// Publisher
int pub = nn_socket(AF_SP, NN_PUB);
nn_bind(pub, "tcp://0.0.0.0:5555");
nn_send(pub, "hello", 5, 0);

// Subscriber
int sub = nn_socket(AF_SP, NN_SUB);
nn_connect(sub, "tcp://publisher:5555");
nn_setsockopt(sub, 0, NN_SUB_SUBSCRIBE, "", 0);
char buf[256];
int n = nn_recv(sub, buf, sizeof(buf), 0);
```

---

## Integration Points

**Used By:**
- Legacy code expecting nanomsg API
- `valis_messaging.c` (alternative to direct NNG)

**Depends On:**
- NNG library (`libnng`)

---

## Related Files

- `valis_messaging.c` - Higher-level messaging abstraction
- `valis_messaging.h` - Messaging API declarations
