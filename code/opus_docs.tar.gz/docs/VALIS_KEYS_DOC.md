# Valis Keys Module Documentation
## File: `utils/valis_keys.c` (734 lines)

**Purpose:** Cryptographic key management, signature operations, and wallet functionality for Tockchain. Handles secp256k1 operations, Ethereum address derivation, signature verification, and secure wallet storage.

**Last Updated:** Wake 1282 (2026-01-13)

---

## Architecture Overview

This module provides the cryptographic foundation for Tockchain's identity and transaction signing system. It bridges Ethereum-compatible cryptography (secp256k1, Keccak-256 hashing) with Tockchain's native operations.

### Key Dependencies
- `secp256k1` library (Bitcoin's elliptic curve implementation)
- `secp256k1_recovery.h` for signature recovery
- `_valis.h` for core types and hash functions

---

## Core Functions

### Private Key Validation

```c
int is_valid_ETHprivkey(uint8_t privkey[32])
```
**Purpose:** Validate that a 32-byte private key is valid for secp256k1.
- Returns 0 if key is all zeros (invalid)
- Returns 0 if key >= curve order n (invalid)
- Returns 1 if valid

The curve order for secp256k1 is:
```
0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
```

---

### Ethereum Address Functions

```c
int eth_is_hex(const char *str, int32_t len)
```
**Purpose:** Check if a string is valid hexadecimal.
- Handles optional "0x" prefix
- Returns 1 if valid hex, 0 if not, -1 if null/empty

```c
int eth_is_checksum_address(char *addr)
```
**Purpose:** Verify EIP-55 checksum encoding of an Ethereum address.
- Uses Keccak-256 hash of lowercase address
- Each nibble of hash determines case of corresponding address character
- Returns 1 if valid checksum, 0 if invalid, negative on error

```c
int eth_to_checksum_address(char *addr)
```
**Purpose:** Convert address to EIP-55 checksum format in-place.
- Modifies the input string
- Returns 1 on success, negative on error

---

### Key Derivation

```c
int32_t pubkey2addr(uint8_t addr20[20], char *addr)
```
**Purpose:** Convert 20-byte address to hex string with "0x" prefix.

```c
int32_t addr2pubkey(char *addr, uint8_t addr20[20])
```
**Purpose:** Convert hex address string to 20-byte binary.

```c
int32_t bigpub2addr20(uint8_t *pubkey, int32_t pubkey_len, uint8_t addr20[20])
```
**Purpose:** Derive Ethereum address from uncompressed public key.
- Takes 64-byte uncompressed public key (without 0x04 prefix)
- Keccak-256 hashes the public key
- Takes last 20 bytes as address

```c
int32_t priv2pub64(uint8_t privkey[32], uint8_t pubkey[64])
```
**Purpose:** Derive 64-byte uncompressed public key from private key.
- Uses secp256k1 library
- Returns uncompressed key without 0x04 prefix

```c
void priv2addr20(uint8_t privkey[32], uint8_t addr20[20])
```
**Purpose:** Derive Ethereum address directly from private key.
- Combines priv2pub64 and bigpub2addr20

---

### Signature Operations

```c
int32_t valis_sign(uint8_t privkey[32], uint8_t digest[32], uint8_t sig[65])
```
**Purpose:** Sign a 32-byte message digest.
- Uses secp256k1 recoverable signatures
- Output is 65 bytes: [r(32) | s(32) | v(1)]
- v is the recovery ID (0-3)

```c
int32_t valis_verify(uint8_t refaddr20[20], uint8_t digest[32], uint8_t sig[65])
```
**Purpose:** Verify a signature against an expected address.
- Recovers public key from signature
- Derives address from recovered key
- Compares to reference address
- Returns 1 if match, negative on error

```c
int32_t calculate_sender_address(uint8_t addr20[20], const uint8_t r[32], 
                                  const uint8_t s[32], uint8_t recid, 
                                  const uint8_t msg_hash[32])
```
**Purpose:** Recover sender address from signature components.
- Used for Ethereum transaction validation
- Takes r, s, v components separately

```c
int verify_secp256k1_hexsig(const char *pubkey_hex, const char *msg_hash_hex,
                            const char *r_hex, const char *s_hex)
```
**Purpose:** Verify signature using hex-encoded inputs.
- Convenience function for external interfaces

---

### Wallet Management

```c
struct wallet_info {
    uint8_t privkey[32];
    uint8_t passhash[32];
    char fname[256];
    struct seedinfo trading;
    struct seedinfo derived[NUMDERIVEDADDRS];
};

struct seedinfo {
    uint8_t privkey[32];
    uint8_t pub64[64];
    uint8_t addr20[20];
    char addr[64];
};
```

```c
void _deriveaddr(uint8_t privkey[32], struct seedinfo *s, char *extrastr)
```
**Purpose:** Derive a seedinfo structure from a private key.
- If extrastr is provided, derives a child key by hashing privkey + hash(extrastr)
- Populates all fields: privkey, pub64, addr20, addr

```c
void deriveaddrs(struct wallet_info *wallet, int32_t numderived)
```
**Purpose:** Derive trading address and multiple derived addresses.
- Trading address uses base privkey
- Derived addresses use "derived.N" as extrastr

```c
int32_t unlockwallet(struct wallet_info *wallet, int32_t silentflag)
```
**Purpose:** Load encrypted wallet from file.
- Reads XOR-encrypted privkey from file
- Decrypts using passhash
- Derives all addresses

```c
int32_t walletseed_init(struct wallet_info *wallet, char *password, int32_t silentflag)
```
**Purpose:** Initialize wallet from password.
- Hashes password to create passhash
- Creates wallet file path from first 8 bytes of passhash
- If file exists, loads it
- If new, prompts for seed or generates random

---

### Security Functions

```c
void memscrub(volatile uint8_t *ptr, int32_t len)
```
**Purpose:** Securely erase sensitive memory.
- Overwrites with 0xFF
- Overwrites 13 times with random data
- Final overwrite with 0xFF
- Uses volatile to prevent compiler optimization

```c
void walletscrub(struct wallet_info *wallet)
```
**Purpose:** Securely erase wallet structure.
- Preserves only the trading address (for display)
- Scrubs all private keys and sensitive data

```c
void randseed(uint8_t privkey[32])
```
**Purpose:** Generate random 32-byte seed from /dev/urandom.

---

### Pylon Signature Validation

Pylon is Tockchain's post-quantum vault system for protecting funds against quantum computer attacks.

```c
int32_t pylon_eval_txsig(struct valisL1_info *L1, uint32_t utime, 
                          struct txheader *txH, sigctx_t ctx, int32_t txind)
```
**Purpose:** Evaluate transaction signature for pylon-protected accounts.
- Checks if sender has pylon protection enabled
- For PYLON_PQVAULT: allows commit/reveal/abort operations
- For PYLON_FAST: validates hot key rotation (k_curr, c_next)
- Returns 1 if valid, negative error code otherwise

**Pylon Types:**
- `PYLON_NONE`: No pylon protection
- `PYLON_FAST`: Fast pylon with hot key rotation
- `PYLON_PQVAULT`: Post-quantum vault with commit-reveal scheme

---

### Multi-Signature Validation

```c
int32_t sig_validate(struct valisL1_info *L1, sigctx_t ctx, 
                     const void *ctx_ptr, int32_t validsig)
```
**Purpose:** Validate signatures based on context type.

**Signature Contexts (sigctx_t):**
- `SIGCTX_NONE`: No signature required
- `SIGCTX_VALIDATOR_BUNDLE`: Validator consensus signatures
- `SIGCTX_TX_NORMAL`: Standard transaction signature
- `SIGCTX_TX_MULTISIG`: Multi-signature transaction
- `SIGCTX_TX_BRIDGE_SRC`: Bridge transaction (source chain)

**For Validator Bundles:**
- Validates multiple validator signatures
- Checks against known validator set
- Requires minimum threshold of valid signatures

**For Multi-sig Transactions:**
- Validates M-of-N signatures
- Tracks which signers have signed (prevents double-counting)
- Returns success only if threshold met

---

### Transaction Signature Evaluation

```c
int32_t eval_txsig(struct valisL1_info *L1, uint32_t utime, 
                   struct txheader *txH, int32_t txlen, int32_t txind,
                   int32_t txsize, int32_t signlen, const uint8_t signhash[32])
```
**Purpose:** Main entry point for transaction signature validation.
- Determines signature context from transaction type
- Routes to appropriate validation function
- Handles pylon-protected accounts
- Returns 1 if valid, negative error code otherwise

---

## Security Considerations

1. **Private Key Handling**
   - Keys are XOR-encrypted at rest
   - memscrub() used to clear sensitive memory
   - Password hashing uses valis_hash (Kangaroo12)

2. **Signature Malleability**
   - Uses secp256k1 library which handles low-S normalization
   - Recovery ID included in signature for deterministic verification

3. **Pylon Protection**
   - Accounts can opt into quantum-resistant protection
   - Hot key rotation prevents key extraction from signatures
   - Commit-reveal scheme for high-security operations

4. **Multi-sig Security**
   - Tracks seen signers to prevent signature reuse
   - Validates against known public key set
   - Threshold enforcement is strict

---

## Usage Examples

### Sign a Message
```c
uint8_t privkey[32], digest[32], sig[65];
// ... populate privkey and digest ...
if (valis_sign(privkey, digest, sig) == 1) {
    // sig contains 65-byte signature
}
```

### Verify a Signature
```c
uint8_t expected_addr[20], digest[32], sig[65];
// ... populate from transaction ...
if (valis_verify(expected_addr, digest, sig) == 1) {
    // Signature is valid and matches expected sender
}
```

### Initialize Wallet
```c
struct wallet_info wallet;
char password[] = "my_secure_password";
if (walletseed_init(&wallet, password, 0) == 0) {
    printf("Trading address: %s\n", wallet.trading.addr);
}
// When done:
walletscrub(&wallet);
```

---

## Related Files

- `_valis.h` - Core type definitions and hash functions
- `valis_hash.c` - Kangaroo12 hash implementation
- `cryptolibs/` - secp256k1 library
- `validator/validator.c` - Uses sig_validate for consensus
