# bridge.c - Core Bridge Utilities

## Overview

`bridge.c` provides foundational utilities for the Tockchain-Ethereum bridge, including ABI encoding helpers, EIP-1559 transaction construction, Merkle tree operations, and EVM revert message parsing.

**Location:** `/root/valis/bridge/bridge.c`  
**Size:** ~407 lines  
**Dependencies:** `bridge.h`

## Architecture

This file contains pure utility functions with no global state. Functions are organized into logical groups:

```
┌─────────────────────────────────────────────────────────────┐
│                    ABI Encoding                             │
│  (abi_word_*, abi_put_u256_*)                              │
├─────────────────────────────────────────────────────────────┤
│                EIP-1559 Transactions                        │
│  (eth_eip1559_build_sighash, eth_eip1559_build_signed_tx)  │
├─────────────────────────────────────────────────────────────┤
│                  Merkle Trees                               │
│  (merkle_dup_last, merkle_proof_for_leaf_dup)              │
├─────────────────────────────────────────────────────────────┤
│                 EVM Revert Parsing                          │
│  (evm_revert_is_error_string, evm_revert_is_done)          │
└─────────────────────────────────────────────────────────────┘
```

## Key Functions

### ABI Encoding Helpers

These functions encode values into 32-byte ABI words (Ethereum's standard encoding):

#### `abi_word_zero()` / `abi_word_copy()`
```c
void abi_word_zero(uint8_t *dst32)
void abi_word_copy(uint8_t *dst32, const uint8_t *src32)
```
Zero or copy a 32-byte ABI word.

#### `abi_put_u256_u64()` / `abi_put_u256_u32()` / etc.
```c
void abi_put_u256_u64(uint8_t *dst32, uint64_t v)
void abi_put_u256_u32(uint8_t *dst32, uint32_t v)
void abi_put_u256_u16(uint8_t *dst32, uint16_t v)
void abi_put_u256_u8(uint8_t *dst32, uint8_t v)
```
Encode unsigned integers as big-endian 256-bit values (right-aligned, zero-padded).

#### `abi_put_u256_addr20()`
```c
void abi_put_u256_addr20(uint8_t *dst32, const uint8_t addr20[20])
```
Encode a 20-byte Ethereum address as 32-byte ABI word (left-padded with 12 zero bytes).

### EIP-1559 Transaction Construction

#### `eth_eip1559_build_sighash()`
```c
int eth_eip1559_build_sighash(eth_eip1559_tx_t *tx, tmpmem_t *mem, uint8_t out32[32])
```
Build the signing hash for an EIP-1559 transaction:
1. Calculate payload length
2. Allocate temporary buffer
3. Write type byte (0x02)
4. RLP-encode transaction fields (chain_id, nonce, fees, gas, to, value, data, access_list)
5. Keccak256 hash the result

**Returns:** 0 on success, negative on error

#### `eth_eip1559_build_signed_tx()`
```c
int eth_eip1559_build_signed_tx(eth_eip1559_tx_t *tx, uint8_t r32[32], uint8_t s32[32],
                                 int v_parity, tmpmem_t *mem, 
                                 uint8_t **raw, int32_t *rawlen)
```
Build a complete signed EIP-1559 transaction:
1. Calculate full payload length (including signature)
2. Allocate buffer
3. Write type byte + RLP-encoded fields + signature (v, r, s)
4. Return raw bytes and length

**Returns:** 0 on success, negative on error

#### `eth_eip1559_txid()`
```c
int eth_eip1559_txid(const uint8_t *raw, int32_t rawlen, uint8_t out32[32])
```
Compute transaction ID (hash) from raw signed transaction bytes.

### Merkle Tree Operations

The bridge uses Merkle trees for batch verification. These functions implement a "duplicate last" padding strategy where trees are padded to power-of-2 size by duplicating the last leaf.

#### `merkle_dup_last()`
```c
int merkle_dup_last(uint8_t leafs32[][32], int16_t n, tmpmem_t *mem, uint8_t out[32])
```
Compute Merkle root from leaves:
1. Pad to next power of 2 by duplicating last leaf
2. Iteratively hash pairs until single root remains
3. Uses Keccak256 for hashing

**Algorithm:**
```
Level 0: [L0] [L1] [L2] [L2]  (padded)
Level 1: [H(L0,L1)] [H(L2,L2)]
Level 2: [H(H01,H22)] = ROOT
```

#### `merkle_proof_for_leaf_dup()`
```c
int merkle_proof_for_leaf_dup(uint8_t leafs32[][32], int16_t n, int16_t leaf_idx,
                               tmpmem_t *mem, uint8_t **proofs32, int16_t *proof_n)
```
Generate Merkle proof for a specific leaf:
1. Pad tree as above
2. At each level, record sibling hash
3. Return array of proof hashes and count

**Proof verification:** Given leaf and proof, verifier can reconstruct root by hashing with each proof element in sequence.

### EVM Revert Parsing

When contract calls fail, the EVM returns revert data. These functions parse common revert formats.

#### `evm_revert_is_error_string()`
```c
int evm_revert_is_error_string(const uint8_t *data, int len, 
                                const uint8_t **out_str, int *out_len)
```
Check if revert data is `Error(string)` format:
- Selector: `0x08c379a0`
- Followed by ABI-encoded string

**Returns:** 1 if matches (sets out_str/out_len), 0 otherwise

#### `evm_revert_is_done()`
```c
int evm_revert_is_done(const uint8_t *data, int len)
```
Check if revert message indicates "done" (case-insensitive).

#### `evm_revert_copy_reason()`
```c
int evm_revert_copy_reason(const uint8_t *data, int len, char *out, int out_cap)
```
Extract human-readable reason string from revert data.

## Internal Helpers

#### `eth_eip1559_calc_payload_len()`
```c
static int32_t eth_eip1559_calc_payload_len(const eth_eip1559_tx_t *tx, 
                                             int with_sig, ...)
```
Calculate total RLP-encoded length of transaction (with or without signature).

#### `merkle_pow2_ge_u32()`
```c
static uint32_t merkle_pow2_ge_u32(uint32_t n)
```
Find smallest power of 2 >= n.

#### `be32_to_int_saturated()`
```c
static int be32_to_int_saturated(const uint8_t be[32])
```
Convert big-endian 256-bit to int, saturating at INT_MAX.

#### `ascii_iequals_literal()`
```c
static int ascii_iequals_literal(const uint8_t *s, int n, const char *lit)
```
Case-insensitive string comparison.

## Data Structures

### `eth_eip1559_tx_t` (from bridge.h)
```c
typedef struct {
    uint64_t chain_id;
    uint64_t nonce;
    uint64_t max_priority_fee_per_gas;  // tip
    uint64_t max_fee_per_gas;           // cap
    uint64_t gas_limit;
    uint8_t  to_addr20[20];
    int      to_is_null;                // for contract creation
    uint8_t  value_be32[32];            // ETH value
    const uint8_t *data;
    uint32_t data_len;
} eth_eip1559_tx_t;
```

### `merkle_hash_pair_t` (internal)
```c
typedef struct {
    uint8_t left32[32];
    uint8_t right32[32];
} merkle_hash_pair_t;
```
Used for Merkle tree hashing - concatenates two 32-byte hashes.

## Memory Management

All functions use `tmpmem_t` for temporary allocations:
- No heap allocations
- Caller provides memory arena
- Thread-safe (no global state)

## Integration Points

**Used by:**
- `bridge_deposit.c` - Transaction construction for deposits
- `bridge_withdraw.c` - Merkle proofs for withdrawals
- `ethrpc.c` - Transaction building and submission

**Depends on:**
- `bridge.h` - Type definitions and RLP helpers
- Keccak256 implementation (via `eth_keccak256`)

## Security Considerations

1. **Merkle tree padding** uses duplicate-last strategy - different from zero-padding
2. **Transaction signing** requires caller to protect private key
3. **Revert parsing** handles malformed data gracefully (returns 0/failure)
4. **Integer overflow** - `be32_to_int_saturated` prevents overflow by saturating

## Example: Building a Transaction

```c
eth_eip1559_tx_t tx = {0};
uint8_t sighash[32], r[32], s[32];
uint8_t *raw;
int32_t rawlen;
int v_parity;

// Fill transaction fields
tx.chain_id = 1;  // mainnet
tx.nonce = 42;
tx.max_priority_fee_per_gas = 2000000000;  // 2 gwei tip
tx.max_fee_per_gas = 50000000000;          // 50 gwei cap
tx.gas_limit = 21000;
memcpy(tx.to_addr20, recipient, 20);
// ... set value, data

// Build signing hash
eth_eip1559_build_sighash(&tx, &mem, sighash);

// Sign externally (secp256k1)
sign(privkey, sighash, r, s, &v_parity);

// Build final transaction
eth_eip1559_build_signed_tx(&tx, r, s, v_parity, &mem, &raw, &rawlen);

// raw now contains bytes to broadcast
```

---
*Documentation generated wake 1289 by Opus*
*Part of Tockchain documentation project*
