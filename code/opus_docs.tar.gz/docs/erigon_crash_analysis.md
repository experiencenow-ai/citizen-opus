# Erigon Crash Analysis

## Problem
Erigon crashes when certain commands are sent.

## Likely Cause: `trace_filter` calls

I found 6 Python scripts that use `trace_filter`:

1. **find_attacker_laundering.py** - trace_filter with 50,000 block range
2. **multi_hop_tracer.py** - trace_filter (used for multi-hop fund tracing)
3. **quick_trace.py** - trace_filter with configurable block range (default 10,000)
4. **trace_rapid_depositor.py** - trace_filter
5. **transaction_tracer.py** - trace_filter for incoming/outgoing traces

### Why trace_filter crashes Erigon

`trace_filter` is one of the most expensive RPC calls because it:
- Scans ALL internal transactions across a block range
- Requires full trace data (which Erigon stores but is expensive to query)
- Can return massive result sets

**Large block ranges + trace_filter = potential OOM or timeout**

For example, `find_attacker_laundering.py` does:
```python
trace_filter([{
    "fromAddress": [ATTACKER_PROXY],
    "fromBlock": hex(EXPLOIT_BLOCK),
    "toBlock": hex(EXPLOIT_BLOCK + 50000),  # 50K blocks!
    "count": 20
}])
```

Even with `count: 20`, Erigon may need to scan all 50K blocks to find 20 results.

### Other potentially heavy calls

`eth_getLogs` with large block ranges can also be heavy, though less than trace_filter:
- check_vault_events.py - eth_getLogs over 50,000 blocks
- find_attacker_outflows.py - eth_getLogs 
- find_balancer_exploit.py - eth_getLogs
- tornado_monitor.py - eth_getLogs

## Recommendations

1. **Limit block ranges** - Max 10,000 blocks per query, paginate if needed
2. **Add timeouts** - Wrap RPC calls with shorter timeouts
3. **Avoid trace_filter on large ranges** - Use Etherscan API instead for historical traces
4. **Use Etherscan for historical data** - It's indexed and won't crash your node

## Safe vs Unsafe Scripts

### Safe (use public RPCs or Etherscan):
- check_futureswap.py - uses public RPC
- attacker_behavior_analyzer.py - uses llamarpc.com
- etherscan_v2.py - uses Etherscan API

### Potentially Unsafe (use localhost:8545 with trace_filter):
- quick_trace.py
- multi_hop_tracer.py
- find_attacker_laundering.py
- transaction_tracer.py

## Fix Applied

I'll update the dangerous scripts to:
1. Use smaller block ranges (max 5000)
2. Add proper timeouts
3. Fall back to Etherscan when available
