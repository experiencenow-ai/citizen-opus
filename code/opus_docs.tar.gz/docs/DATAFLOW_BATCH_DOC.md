# dataflow_batch.c - Batch Transaction Processing

## Overview

This file implements batch transaction processing for the dataflow system. It handles parsing, validation, and execution of batched dataflow transactions that can modify multiple accounts and assets in a single atomic operation.

**Location**: `/root/valis/DF/dataflow_batch.c`  
**Lines**: ~1491  
**Dependencies**: ledger.h, dataflow.h, ufc.h, validator.h

## Core Concepts

### Batch Transactions
Dataflow batch transactions allow multiple operations to be bundled together:
- Multiple source addresses can participate
- Multiple assets can be transferred
- Operations are validated atomically
- Plans are built for efficient execution

### Matrix Model
The batch system uses a matrix representation:
- Rows represent dataflow contracts
- Columns represent assets
- Cells track balance changes
- Conservation laws are enforced per-pair

## Key Data Structures

### df_batch_sections_t
Parsed sections of a batch transaction:
- Asset lists
- Address lists  
- Spend lists
- Register windows

### df_batch_matrix_t
Matrix tracking balance changes:
- Source balances (per address, per asset)
- Dataflow balances (per contract, per asset)
- Slot tracking for contract state

### df_tock_plans_t
Execution plans for applying changes:
- Pre-allocated plan arrays
- Per-transaction counts
- Capacity limits

## Key Functions

### Parsing Functions

#### `df_batch_parse_sections_matrix()`
```c
static int32_t df_batch_parse_sections_matrix(
    const struct dataflow_tx *tx, 
    int32_t txsize, 
    df_batch_sections_t *out
)
```
Parses raw transaction bytes into structured sections.

#### `df_batch_matrix_init()`
```c
static int32_t df_batch_matrix_init(
    df_batch_matrix_t *m,
    struct valisL1_info *L1,
    const struct dataflow_tx *dfc,
    const df_batch_sections_t *sec
)
```
Initializes the matrix with current balances from ledger state.

### Validation Functions

#### `df_batch_validate_assets_real_unique()`
```c
static int32_t df_batch_validate_assets_real_unique(
    struct valisL1_info *L1,
    const df_batch_sections_t *sec
)
```
Ensures all declared assets are valid and unique.

#### `df_batch_validate_spend_list()`
```c
static int32_t df_batch_validate_spend_list(
    struct valisL1_info *L1, 
    const df_batch_sections_t *sec
)
```
Validates that spend operations are properly authorized.

#### `df_validate_batch_sum_mingas_and_install()`
```c
int32_t df_validate_batch_sum_mingas_and_install(
    struct valisL1_info *L1, 
    const struct dataflow_tx *dfc, 
    int32_t txsize, 
    int64_t *sum_mingas_out
)
```
**Public API**: Validates entire batch and calculates minimum gas.

### Execution Functions

#### `df_tock_parallel_evaluate()`
```c
int32_t df_tock_parallel_evaluate(
    struct valisL1_info *L1, 
    uint32_t utime
)
```
**Public API**: Evaluates all dataflow transactions in parallel for a tock.

#### `df_eval_one_batch_tx_build_plan_matrix()`
```c
static int32_t df_eval_one_batch_tx_build_plan_matrix(
    struct valisL1_info *L1,
    const uint8_t *tx_bytes,
    int32_t txsize,
    int32_t txind,
    uint32_t utime,
    ufc_planned_address_mutation_t *plan,
    int32_t *plan_countp,
    int32_t plan_cap
)
```
Evaluates a single batch transaction and builds execution plan.

### Helper Functions

#### `df_batch_asset_lut_find()` / `df_batch_asset_lut_set()`
Hash-based lookup table for fast asset indexing within batches.

#### `df_slice_u8()`
Safe slice extraction with bounds checking.

#### `df_safe_add_i64()`
Overflow-safe 64-bit addition.

#### `df_batch_check_pair_conservation()`
Enforces conservation laws between source and dataflow balances.

## Security Features

### Scope Validation
```c
static int32_t df_plan_check_scope_and_synthetics(
    const ufc_planned_address_mutation_t *plan,
    int32_t plan_count,
    const uint8_t allowed_addrs[][PKSIZE],
    uint16_t allowed_count,
    const assetid_t *declared_assets,
    uint16_t declared_asset_count
)
```
- Ensures plans only modify allowed addresses
- Validates synthetic asset constraints
- Prevents unauthorized transfers

### Conservation Enforcement
- Every asset transfer must balance
- Source debits equal dataflow credits
- Overflow protection on all arithmetic

### Address Authorization
```c
static int32_t df_addr_is_allowed(
    const uint8_t allowed_addrs[][PKSIZE], 
    uint16_t allowed_count, 
    const uint8_t pubkey[PKSIZE]
)
```
Only pre-declared addresses can be modified.

## Error Codes

| Code | Meaning |
|------|---------|
| DF_ERR_TX_FORMAT | Malformed transaction data |
| DF_ERR_GENERIC | General processing error |
| DF_ERR_ADDR_SCOPE | Address not in allowed set |
| DF_ERR_SYNTHETIC_TRANSFER | Invalid synthetic asset operation |

## Processing Flow

1. **Parse**: `df_batch_parse_sections_matrix()` extracts sections
2. **Initialize**: `df_batch_matrix_init()` loads current state
3. **Validate**: Multiple validation passes check constraints
4. **Plan**: Build mutation plans for each address
5. **Execute**: Apply plans atomically via UFC

## Integration Points

- **UFC (Universal Function Call)**: Plans are applied through UFC
- **Validator**: Coordinates batch processing during tock validation
- **Ledger**: Reads/writes account balances
- **Cache**: Uses dataflow cache for contract state

## Performance Considerations

- Hash-based asset lookup (O(1) average)
- Pre-allocated plan arrays avoid malloc during processing
- Matrix representation enables efficient conservation checking
- Parallel evaluation of independent transactions

## Related Files

- `dataflow.c` - Core dataflow operations
- `dataflow.h` - Type definitions
- `ufc.c` - Universal function call execution
- `validator.c` - Block validation coordination

---
*Documentation generated by Opus, Wake 1296*
