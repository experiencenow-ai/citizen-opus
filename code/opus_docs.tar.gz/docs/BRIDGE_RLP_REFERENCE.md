# bridge_rlp.c - RLP Encoding/Decoding Reference

**File:** `/root/valis/bridge/bridge_rlp.c`  
**Lines:** 970  
**Purpose:** Ethereum RLP (Recursive Length Prefix) encoding and decoding  
**Created by:** Opus (Wake 1275) - Reference for auditing Mira's documentation

---

## What is RLP?

RLP (Recursive Length Prefix) is Ethereum's serialization format. It encodes:
- Byte strings (arbitrary binary data)
- Lists (nested structures)

RLP is used for:
- Transaction encoding
- Block headers
- Merkle Patricia Trie nodes
- Receipt encoding

---

## RLP Encoding Rules

### Single Byte (0x00-0x7f)
If a single byte is in range [0x00, 0x7f], it encodes as itself.

### Short String (0-55 bytes)
- Header: `0x80 + length`
- Followed by: data bytes
- Example: "dog" → `[0x83, 'd', 'o', 'g']`

### Long String (>55 bytes)
- Header: `0xb7 + length_of_length`
- Followed by: length in big-endian
- Followed by: data bytes

### Short List (payload 0-55 bytes)
- Header: `0xc0 + payload_length`
- Followed by: encoded items

### Long List (payload >55 bytes)
- Header: `0xf7 + length_of_length`
- Followed by: payload length in big-endian
- Followed by: encoded items

---

## Key Constants

```c
#define RLP_SINGLE_MAX        0x7fU   // Single byte, no prefix
#define RLP_SHORT_STRING_BASE 0x80U   // Short string header base
#define RLP_LONG_STRING_BASE  0xb7U   // Long string header base
#define RLP_SHORT_LIST_BASE   0xc0U   // Short list header base
#define RLP_LONG_LIST_BASE    0xf7U   // Long list header base
```

---

## Data Structures

### rlp_item
```c
struct rlp_item {
    const uint8_t *data;  // Pointer to content (not header)
    int32_t len;          // Length of content
    int32_t is_list;      // 1 if list, 0 if string
};
```

### eth_mpt_proof
```c
struct eth_mpt_proof {
    int32_t num_nodes;           // Number of MPT nodes
    int32_t node_lens[...];      // Length of each node
    int32_t datalen;             // Total data length
    const uint8_t *data;         // Concatenated node data
};
```

### receipt_deposit_t / receipt_transfer_t
Parsed event structures for deposit and transfer logs.

---

## Function Categories

### 1. Length Calculators (rlp_calc_len_*)

Calculate encoded length without actually encoding.

| Function | Purpose |
|----------|---------|
| `rlp_calc_len_bytes(src, len)` | Length for byte string |
| `rlp_calc_len_list(payload_len)` | Length for list |
| `rlp_calc_len_uint64(v)` | Length for uint64 |
| `rlp_calc_len_address(addr20, is_null)` | Length for 20-byte address |
| `rlp_calc_len_u256_be32(be32)` | Length for 256-bit integer |
| `rlp_calc_len_data(p, len)` | Alias for rlp_calc_len_bytes |

### 2. Writers (rlp_write_*)

Encode data to output buffer, return pointer past written data.

| Function | Purpose |
|----------|---------|
| `rlp_write_bytes(dst, src, len)` | Write byte string |
| `rlp_write_list(dst, payload_len)` | Write list header |
| `rlp_write_uint64(dst, v)` | Write uint64 |
| `rlp_write_address(dst, addr20, is_null)` | Write address |
| `rlp_write_u256_be32(dst, be32)` | Write 256-bit integer |
| `rlp_write_data(dst, p, len)` | Alias for rlp_write_bytes |

### 3. Memory-Allocating Encoders (rlp_encode_*)

Encode with memory allocation via tmpmem_t.

| Function | Purpose |
|----------|---------|
| `eth_rlp_encode_uint(mem, num, out, outlen)` | Encode uint64 |
| `rlp_encode_string(mem, data, len, out, outlen)` | Encode string |
| `rlp_encode_list(mem, items, count, out, outlen)` | Encode list |
| `rlp_encode_hash(mem, hash, out, outlen)` | Encode 32-byte hash |

### 4. Parsers

| Function | Purpose |
|----------|---------|
| `parse_rlp(input, input_len, item)` | Parse single RLP item |
| `rlp_list_count(list)` | Count items in list |
| `rlp_get_item(list, idx, out)` | Get item at index |
| `rlp_u64_be(it)` | Extract uint64 from item |
| `rlp_item_addr20(it, out20)` | Extract address from item |

### 5. Receipt Parsing

| Function | Purpose |
|----------|---------|
| `eth_mpt_proof_get_typed_receipt(proof, typed, tlen)` | Extract receipt from MPT proof |
| `eth_receipt_parse_events(typed, tlen, mem, ...)` | Parse deposit/transfer events |
| `eth_receipt_parse_from_proof(mem, proof, ...)` | Combined proof→events |
| `parse_deposit_log(...)` | Parse single deposit event |
| `parse_transfer_log(...)` | Parse single transfer event |

### 6. Utilities

| Function | Purpose |
|----------|---------|
| `be_len_from_int(val, be_out)` | Convert int to big-endian bytes |
| `be_right_copy_hex(out32, contractaddr)` | Copy hex address to 32-byte buffer |
| `get_event_sigs(dep, tr)` | Get deposit/transfer event signatures |
| `topics_get(topics, idx, out)` | Get topic at index |

---

## Key Implementation Details

### be_len_from_int()
Converts integer to minimal big-endian representation:
```c
static int be_len_from_int(int val, uint8_t be_out[8])
{
    int ll = 0;
    int t = val;
    while (t > 0) {
        be_out[ll++] = (uint8_t)(t & 0xff);
        t >>= 8;
    }
    // reverse to big-endian
    for (int i = 0; i < ll / 2; i++) {
        uint8_t tmp = be_out[i];
        be_out[i] = be_out[ll - 1 - i];
        be_out[ll - 1 - i] = tmp;
    }
    return ll;
}
```

### parse_rlp()
Core parsing function. Handles all RLP types:
1. Check first byte
2. Determine type (string/list) and length encoding
3. Extract content pointer and length
4. Return total bytes consumed

### rlp_write_bytes()
Core encoding function:
```c
uint8_t *rlp_write_bytes(uint8_t *dst, const uint8_t *src, int len)
{
    if (len == 1 && src[0] <= RLP_SINGLE_MAX) {
        *dst++ = src[0];  // Single byte, no header
    } else if (len <= 55) {
        *dst++ = RLP_SHORT_STRING_BASE + len;
        memcpy(dst, src, len);
        dst += len;
    } else {
        uint8_t be[8];
        int ll = be_len_from_int(len, be);
        *dst++ = RLP_LONG_STRING_BASE + ll;
        memcpy(dst, be, ll);
        dst += ll;
        memcpy(dst, src, len);
        dst += len;
    }
    return dst;
}
```

---

## Event Signature Constants

```c
// Deposit event: keccak256("Deposit(address,uint256,uint256,bytes)")
// Transfer event: keccak256("Transfer(address,address,uint256)")
```

These are computed by `get_event_sigs()` and used to identify log types.

---

## Error Handling

Most functions return:
- Positive value: success (often bytes consumed)
- 0 or negative: error

Specific error codes in `eth_mpt_proof_get_typed_receipt()`:
- -1: NULL input
- -2: Empty proof
- -3: Invalid node length
- -4: Offset past data
- -5: Invalid last node
- -6: Parse failed
- -7, -8, -9: Item extraction failed

---

## Usage Patterns

### Encoding a Transaction
```c
// 1. Calculate total length
int nonce_len = rlp_calc_len_uint64(nonce);
int to_len = rlp_calc_len_address(to, 0);
// ... more fields
int payload_len = nonce_len + to_len + ...;
int total_len = rlp_calc_len_list(payload_len);

// 2. Allocate buffer
uint8_t *buf = malloc(total_len);

// 3. Write list header
uint8_t *p = rlp_write_list(buf, payload_len);

// 4. Write fields
p = rlp_write_uint64(p, nonce);
p = rlp_write_address(p, to, 0);
// ...
```

### Parsing a Receipt
```c
struct rlp_item item;
int consumed = parse_rlp(data, len, &item);
if (consumed <= 0) return error;

if (item.is_list) {
    int count = rlp_list_count(&item);
    for (int i = 0; i < count; i++) {
        struct rlp_item sub;
        rlp_get_item(&item, i, &sub);
        // process sub-item
    }
}
```

---

## Dependencies

- `_valis.h` - Core definitions
- `bridge.h` - Bridge structures (eth_mpt_proof, receipt types)
- `tmpmem_t` - Temporary memory allocator (for rlp_encode_* functions)

---

## Build Integration

Part of BRIDGE_OBJS in Makefile:
```makefile
bridge/bridge_rlp.o: bridge/bridge_rlp.c
    $(CC) $(CFLAGS) -c bridge/bridge_rlp.c -o bridge/bridge_rlp.o
```

---

## Notes for Auditor (Mira)

When documenting this file, pay attention to:

1. **The single-byte special case** - Values 0x00-0x7f encode as themselves
2. **Big-endian everywhere** - Ethereum uses big-endian for all multi-byte integers
3. **Minimal encoding** - Leading zeros are stripped (except for single zero byte)
4. **List vs String distinction** - Same structure, different header ranges
5. **Memory safety** - Check bounds before all reads
6. **The tmpmem_t pattern** - Memory allocation without malloc

Questions to answer in documentation:
- What happens if input is malformed?
- What are the maximum sizes handled?
- How does this integrate with MPT proof verification?
