# dataflow_api.c - Host-Side API Functions

## Overview

This file provides the host-side API functions that dataflow contracts can call. These functions require access to the host context (TLS-based) and handle operations like transfers, swaps, and inter-contract communication.

**Location**: `/root/valis/DF/dataflow_api.c`  
**Lines**: ~537  
**Dependencies**: df_sdk.h, dataflow.h

## Design Philosophy

From the header comment:
```
ONLY functions that need hostctx belong here.
ctx-only lookups are inlined in VM helper dispatch.
Pure functions are inlined in VM.
```

This file is specifically for operations that need:
- Thread-local host context (`df_hostctx_t`)
- Access to L1 state
- Plan mutation capabilities

## Thread-Local Context

```c
static __thread df_hostctx_t *tls_hostctx = NULL;

df_hostctx_t *df_hostctx_get(void);
void df_hostctx_set(df_hostctx_t *H);
```

Each thread maintains its own host context, allowing parallel execution of dataflow contracts.

## Transfer Operations

### `df_emit_transfer()`
```c
int32_t df_emit_transfer(
    df_ctx_t *ctx, 
    uint8_t from_row, 
    uint8_t to_row,
    int32_t col, 
    int64_t amount
)
```
Emits a transfer between rows in the matrix.

**Parameters**:
- `from_row` - Source row (0 = source address, df_row = contract)
- `to_row` - Destination row
- `col` - Asset column index
- `amount` - Amount to transfer (must be positive)

**Returns**: 0 on success, negative on error

**Validation**:
- Row indices must be valid
- Column must be valid
- Amount must be positive
- Source must have sufficient balance
- Transfer count limit not exceeded

### `df_transfer_excess()`
```c
int32_t df_transfer_excess(
    df_ctx_t *ctx,
    uint8_t src_sel_u8,
    uint8_t dst_row_u8,
    assetid_t asset,
    int64_t reserve_amount_s64
)
```
Transfers any balance above a reserve amount.

## UFC (Universal Function Call) Operations

### `df_ufc_emit_swap()`
```c
int32_t df_ufc_emit_swap(
    df_ctx_t *ctx, 
    uint8_t fund_row, 
    int32_t col_in,
    int32_t col_out, 
    int64_t amount_in, 
    int64_t min_out
)
```
Emits a swap operation through UFC.

### `df_ufc_emit_pool_deposit()`
```c
int32_t df_ufc_emit_pool_deposit(
    df_ctx_t *ctx, 
    int32_t pool_col,
    int64_t amount
)
```
Deposits into a liquidity pool.

### `df_ufc_emit_pool_withdraw()`
```c
int32_t df_ufc_emit_pool_withdraw(
    df_ctx_t *ctx, 
    int32_t pool_col,
    int64_t lp_amount
)
```
Withdraws from a liquidity pool.

### `df_ufc_emit_limit_order()`
```c
int32_t df_ufc_emit_limit_order(
    df_ctx_t *ctx, 
    uint8_t fund_row, 
    int32_t col,
    int64_t amount, 
    int64_t price
)
```
Places a limit order.

## Contract State Operations

### `df_installed_get_flags()`
```c
int32_t df_installed_get_flags(df_ctx_t *ctx, uint32_t *out_flags)
```
Gets the current flags for an installed contract.

### `df_installed_set_flags()`
```c
int32_t df_installed_set_flags(
    df_ctx_t *ctx, 
    uint32_t set_mask, 
    uint32_t clr_mask
)
```
Modifies contract flags (set some bits, clear others).

### `df_installed_uninstall()`
```c
int32_t df_installed_uninstall(df_ctx_t *ctx)
```
Uninstalls the current contract.

## Inter-Contract Communication

### `df_reg_delta_by_df()`
```c
int32_t df_reg_delta_by_df(
    df_ctx_t *ctx, 
    const dfid_t *target,
    int32_t reg, 
    int64_t delta
)
```
Modifies a register in another dataflow contract.

### `df_pipe_in_read()`
```c
int32_t df_pipe_in_read(
    df_ctx_t *ctx, 
    uint16_t off, 
    uint8_t *dst, 
    uint16_t bytes
)
```
Reads from the input pipe (incoming messages).

### `df_pipe_out_append()`
```c
int32_t df_pipe_out_append(
    df_ctx_t *ctx, 
    uint16_t msg_type,
    const uint8_t *data, 
    uint16_t len
)
```
Appends a message to the output pipe.

## Credit Operations

### `df_vcredit_emit_borrow()`
```c
int32_t df_vcredit_emit_borrow(
    df_ctx_t *ctx, 
    uint8_t row, 
    int64_t amount,
    int64_t max_rate
)
```
Emits a borrow operation against vCredit.

### `df_vcredit_emit_repay()`
```c
int32_t df_vcredit_emit_repay(
    df_ctx_t *ctx, 
    uint8_t row, 
    int64_t amount
)
```
Repays a vCredit loan.

## Cryptographic Operations

### `df_merkle_verify()`
```c
int32_t df_merkle_verify(
    const uint8_t *root, 
    const uint8_t *leaf,
    const uint8_t *proof, 
    int32_t proof_len
)
```
Verifies a Merkle proof.

### `df_sig_verify()`
```c
int32_t df_sig_verify(
    const uint8_t *pubkey, 
    const uint8_t *hash,
    const uint8_t *sig, 
    int32_t type
)
```
Verifies a cryptographic signature.

### `df_hash256()`
```c
int32_t df_hash256(
    const uint8_t *data, 
    uint32_t len, 
    uint8_t *out32
)
```
Computes SHA-256 hash.

## Helper Functions

### `df_matrix_find_col_for_asset()`
```c
static int32_t df_matrix_find_col_for_asset(
    const df_ctx_t *ctx,
    assetid_t asset,
    int32_t *out_col
)
```
Finds the column index for a given asset in the matrix.

### `df_matrix_get_rw_row_ptr()`
```c
static int32_t df_matrix_get_rw_row_ptr(
    df_ctx_t *ctx,
    uint8_t row,
    int64_t **out_rw
)
```
Gets a pointer to the read-write row data.

## Error Codes

| Code | Meaning |
|------|---------|
| -1 | NULL context or host context |
| -2 | Insufficient balance |
| -3 | Invalid row/column/parameter |
| -4 | Limit exceeded (transfers, etc.) |

## Integration Points

- **vbpf.c** - VM calls these functions via host callbacks
- **dataflow_batch.c** - Batch processing uses these APIs
- **ufc.c** - UFC operations are routed through here

---
*Documentation generated by Opus, Wake 1296*
