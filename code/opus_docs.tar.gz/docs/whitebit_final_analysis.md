# WhiteBit Deposit Analysis - Final Report

**Investigation:** CT Heist Fund Tracing  
**Date:** January 11, 2026  
**Analyst:** Opus (Wake 1101)

## Executive Summary

71 P2P recipient wallets deposited **$259,450** to WhiteBit's hot wallet. The critical question: did these go to one WhiteBit account or multiple accounts?

## Key Technical Finding

WhiteBit uses a **batch sweep system** where:
1. Users deposit USDT to their unique deposit address (or directly to hot wallet)
2. WhiteBit periodically sweeps all deposits in a single batch transaction
3. The sweep transaction shows multiple USDT transfers FROM various addresses TO the hot wallet

Example batch transaction `0x41f12fb9...`:
- Contains 58 separate USDT transfers to WhiteBit
- **Includes 2 of our P2P recipients** (0x0e1faa94... and 0xe17b08ad...)
- Total value in this single batch: ~$300K+

## The Critical Question

**How does WhiteBit identify which account receives a deposit?**

### Option A: Unique Deposit Addresses
If WhiteBit assigns unique deposit addresses per account:
- Each P2P recipient address = unique deposit identifier
- WhiteBit's internal system maps sender address → account
- 71 sender addresses could mean 71 different accounts

### Option B: Account-Level Identification  
If WhiteBit tracks by sender address:
- Same sender address = same account (even across transactions)
- 71 unique sender addresses = 71 potential accounts
- OR mastermind linked all 71 addresses to ONE account

## Evidence Analysis

### Pattern 1: Amount Consistency
- 30 deposits of ~$4,000
- 32 deposits of ~$3,500
- 13 deposits of ~$3,000

This consistent sizing suggests:
- Deliberate structuring below a threshold
- Possibly below WhiteBit's KYC trigger or daily limit

### Pattern 2: Timing
- 6-day deposit window (Dec 29 - Jan 4)
- 71 deposits across 7 days = ~10 deposits/day average
- Daily limits per account may explain this pacing

### Pattern 3: Sequential Amounts
Deposits follow a sequential pattern:
```
$4,009 -> $4,008 -> $4,007 -> $4,006 -> $4,005 -> ...
```
This strongly suggests **automated distribution** by a single controller.

## CT's Hypothesis: Multiple Below-KYC Accounts

**Hypothesis:** Mastermind created dozens of WhiteBit accounts, each below KYC threshold, to cash out P2P funds.

**Supporting Evidence:**
1. ~$4K per deposit (below typical KYC triggers)
2. 71 unique deposit addresses (one per account?)
3. Sequential amount pattern (automated system)
4. 6-day timeframe (daily withdrawal limits?)

**What WhiteBit Can Reveal:**
1. Which account(s) received deposits from these 71 addresses
2. If multiple accounts: registration patterns (IP, email, phone)
3. Withdrawal destinations from those accounts
4. Any internal transfers between accounts

## WhiteBit Hot Wallet

```
0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3
```

All 71 deposits went to this address. This is WhiteBit's main Ethereum hot wallet.

## Complete Deposit List

| # | P2P Recipient | Amount | TXID |
|---|---------------|--------|------|

## Action Items for Law Enforcement

1. **Contact WhiteBit Compliance**
   - Provide list of 71 sender addresses
   - Request: Which account(s) received these deposits?
   - Request: KYC data for those accounts
   - Request: Account creation dates and IPs

2. **Request Withdrawal Records**
   - Where did funds go after deposit?
   - Internal transfers to other accounts?
   - External withdrawals (addresses/banks)?

3. **Pattern Analysis Request**
   - Multiple accounts from same IP?
   - Similar email patterns?
   - Same KYC documents across accounts?

4. **Freeze Request**
   - If funds still present, request freeze
   - Preserve withdrawal addresses for further tracing

## Technical Notes

- WhiteBit batch sweeps deposits periodically
- Multiple P2P recipients appear in same sweep transaction
- This is normal exchange behavior, not evidence of single account
- Account identification requires WhiteBit's internal records

---

**Total to WhiteBit:** $259,450.02  
**Unique Deposit Addresses:** 71  
**WhiteBit Hot Wallet:** `0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3`
