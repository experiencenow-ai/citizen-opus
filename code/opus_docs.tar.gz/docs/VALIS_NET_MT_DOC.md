# valis_net_MT.c - Multi-Threaded Networking

## Overview

**Location:** `/root/valis/utils/valis_net_MT.c`  
**Lines:** ~772  
**Purpose:** Implements the peer-to-peer networking layer with multi-threaded message handling, using nanomsg (nng) for transport.

This is the core networking infrastructure that enables validators to communicate, broadcast transactions, and maintain peer connections.

---

## Architecture

### Threading Model

The networking layer uses multiple dedicated threads:
1. **vnet_recvloop**: Receives messages from PULL socket (direct messages)
2. **ipc_recvloop**: Handles inter-process communication via IPC socket
3. **vnet_sub_recvloop**: Receives broadcast messages via PUB/SUB

### Socket Types

Uses nanomsg (nng) sockets:
- **PUSH/PULL**: For direct peer-to-peer messaging
- **PUB/SUB**: For broadcast messages to all peers
- **IPC**: For local inter-process communication

---

## Key Constants

```c
#define BIGBUFSIZE              (11 * 1024 * 1024)  // 11MB max message size
#define VNET_SEND_IDLE_US       1000                // 1ms idle between sends
#define VNET_BACKOFF_BASE_MS    100                 // Base backoff for retries
#define VNET_BACKOFF_MAX_SHIFT  5                   // Max backoff multiplier (2^5)
#define VNET_STALE_PEER_SECS    600                 // 10 min peer timeout
#define VNET_SEND_THROTTLE_TRIGGER 1024             // Queue depth trigger
#define VNET_PUB_PORT           (VNET_PORT + 1)     // PUB socket port offset
```

---

## Core Data Structures

### `vnet_context_t`
Main networking context containing:
- `mypubkey[PKSIZE]`: This node's public key
- `servers[]`: Array of connected peer information
- `servers_mutex`: Protects peer list access
- `genesis_utime`: Genesis timestamp for chain identification
- `testprivkey[32]`: Signing key (temporary location)

### `vnet_server_info`
Per-peer connection state:
- `peer`: Peer identification (pubkey, IP)
- `push_sock`: PUSH socket for sending
- `sub_sock`: SUB socket for receiving broadcasts
- `active`: Connection status flag
- `peersets_bitmap`: Which peer sets this peer belongs to

### `vnet_packet_queue`
Queued packet structure:
- `destpub[PKSIZE]`: Destination public key
- `recvbuf[]`: Packet data (flexible array)
- `bufsize`: Packet length

---

## Packet Queue Management

### `alloc_qp(destpub, recvbuf, packetlen)`
Allocates a packet queue entry with embedded data buffer.

**Memory layout:**
```
[vnet_packet_queue header][packet data...]
```

### `enqueue_packet_to_slot(slot, qp)`
Thread-safe enqueue using mutex and doubly-linked list (DL_APPEND).

---

## Peer Management

### `vnet_find_serverpub(VNET, pubkey)`
Finds a peer by public key across all peer sets.

**Thread-safe:** Uses `servers_mutex`.

### `vnet_find_server_in_peerset(VNET, peerset, pubkey)`
Finds a peer by public key within a specific peer set.

**Parameters:**
- `peerset`: Peer set index (-1 for any)
- `pubkey`: 32-byte public key to find

### `vnet_alloc_server(VNET, peer)`
Allocates a new server slot for a peer.

**Process:**
1. Check if peer already exists
2. Find empty slot in servers array
3. Initialize connection state
4. Connect sockets

### `vnet_connect_peer(VNET, sp)`
Establishes connection to a peer.

**Creates:**
- PUSH socket for sending messages
- SUB socket for receiving broadcasts

### `vnet_disconnect_peer(VNET, sp)`
Cleanly disconnects from a peer.

**Cleanup:**
- Closes sockets
- Clears peer state
- Marks slot as inactive

---

## Message Handling

### `vnet_broadcast(VNET, sendbuf, packetlen, flags)`
Broadcasts a message to all connected peers.

**Process:**
1. Iterate through all active servers
2. Send to each peer's PUSH socket
3. Handle send failures with backoff

### `vnet_send(VNET, H, packetlen, destpub, must_sign)`
Sends a message to a specific peer.

**Parameters:**
- `H`: Unified header (message metadata)
- `packetlen`: Total packet length
- `destpub`: Destination public key
- `must_sign`: Whether to sign the message

**Features:**
- Finds peer by public key
- Optionally signs message
- Handles connection failures

### `vnet_process_inbound(VNET, buf, size)`
Processes a received message.

**Validation:**
- Checks packet length
- Verifies genesis timestamp
- Validates signature if present

---

## Receive Loops

### `vnet_recvloop(arg)`
Main receive thread for PULL socket.

```c
while (running) {
    nng_recv(pull_sock, &buf, &size, NNG_FLAG_ALLOC);
    vnet_process_inbound(VNET, buf, size);
    nng_free(buf, size);
}
```

### `ipc_recvloop(arg)`
Receives from local IPC socket for inter-process communication.

### `vnet_sub_recvloop(arg)`
Receives broadcast messages from PUB/SUB socket.

---

## Public API

### `vnet_init(peerset, mypubkey, ds)`
Initializes the networking context.

**Parameters:**
- `peerset`: Initial peer set
- `mypubkey`: This node's public key
- `ds`: Validators structure

**Returns:** Initialized `vnet_context_t*`

### `vnet_shutdown(VNET)`
Gracefully shuts down networking.

**Process:**
1. Signal threads to stop
2. Close all sockets
3. Free resources

### `vnet_add_peer(VNET, peerset, peer)`
Adds a new peer to a peer set.

**Returns:**
- 0: Success
- -1: Peer already exists
- -2: No available slots

### `vnet_remove_peer(VNET, peerset, pubkey)`
Removes a peer from a peer set.

### `vnet_is_disabled(VNET, peerset, pubkey)`
Checks if a peer is disabled/inactive.

### `vnet_find_ipbits(VNET, pubkey)`
Looks up IP address for a public key.

### `vnet_get_peers_in_peerset(VNET, peerset, peers, max)`
Gets list of peers in a specific peer set.

### `vnet_collect_active_ips(VNET, ips, maxips)`
Collects unique IP addresses of all active peers.

### `vnet_get_vapp_packet(VNET, peerset, vappid, fifoind)`
Retrieves a packet for a specific virtual application.

---

## Packet Validation

### `validate_inbound_packet(VNET, qp)`
Validates an inbound packet.

**Checks:**
1. Packet not NULL
2. Packet length >= header size
3. Genesis timestamp matches
4. Signature valid (if signed)

**Returns:**
- 0: Valid
- -1: Invalid packet
- -2: Genesis mismatch

### `packethash(H, packetlen, hash)`
Computes SHA-256 hash of packet for signing/verification.

---

## Thread Safety

All peer list operations are protected by `servers_mutex`:
- Finding peers
- Adding/removing peers
- Iterating peer list

Packet queues use per-slot mutexes for concurrent access.

---

## Error Handling

- Socket failures trigger reconnection attempts
- Exponential backoff for failed sends
- Stale peer detection (VNET_STALE_PEER_SECS)
- Queue depth monitoring (VNET_SEND_THROTTLE_TRIGGER)

---

## Dependencies

- `gen3.h`: Generator definitions
- `valis_messaging.h`: Message format definitions
- nanomsg (nng): Transport layer
- pthread: Threading primitives
- `utlist.h`: Doubly-linked list macros

---

## Related Files

- `valis_messaging.h`: Message format definitions
- `netlibs/`: Lower-level networking utilities
- `validator/`: Uses networking for consensus
