# MM (Market Maker) Dataflow Documentation

**File:** `/root/valis/DF/MM.c`  
**Version:** v8.4 (ABI0-aligned)  
**Lines:** 994  
**Purpose:** Professional spot market maker execution engine

---

## Overview

MM.c implements an **automated market making** system as a Tockchain dataflow program. It provides:

1. **Two-sided quoting** with dynamic spread adjustment
2. **Inventory-aware skewing** to manage position risk
3. **Volatility-responsive spreads** that widen in turbulent markets
4. **Gamma hedging** integration with perpetual futures
5. **Circuit breaker** protection during extreme volatility

---

## Architecture

### Execution Model

- **Keeper-driven**: Only responds to `df_on_dataflowtx` (no scheduler integration)
- **Stateless "Pro" interface**: Strategy parameters passed in userdata per-call
- **Persistent safety config**: Hedge parameters stored in registers S4-S7

### State Storage

| Register | Name | Description |
|----------|------|-------------|
| S0 | `MM_S_META` | Last update timestamp |
| S1 | `MM_S_CAPITAL_HINT_VUSD` | Total capital in VUSD terms |
| S2 | `MM_S_INVENTORY_BASE` | Current base asset inventory |
| S3 | `MM_S_LAST_CENTER_PRICE` | Last computed center price |
| S4 | `MM_S_VOL_THRESHOLD_LOW_BPS` | Low volatility threshold |
| S5 | `MM_S_VOL_THRESHOLD_HIGH_BPS` | High volatility threshold |
| S6 | `MM_S_HEDGE_RATIO_MIN_PCT` | Minimum hedge ratio % |
| S7 | `MM_S_HEDGE_RATIO_MAX_PCT` | Maximum hedge ratio % |

---

## Configuration Constants

```c
#define MM_BASE_SPREAD_BPS          20      // 0.20% base spread
#define MM_VOL_MULTIPLIER           1       // +1 bps spread per 1 bps vol
#define MM_MAX_SPREAD_BPS           2500    // 25% max spread
#define MM_VOL_CIRCUIT_BREAKER_BPS  8000    // 80% vol triggers circuit breaker
#define MM_HEDGE_REBALANCE_THRESHOLD_VUSD_SCALED  (100 * SATOSHIS)  // 100 VUSD
```

---

## Operations (Opcodes)

### Op 1: Execute (`MM_OP_EXECUTE`)

Main market making operation. Computes and places two-sided quotes.

**Wire Format:**
```c
typedef struct mmdf_wire_exec_s {
    uint32_t validity_window;        // Seconds until expiry
    uint32_t tx_ref_block;           // Reference block for staleness check
    int16_t alpha_prediction_bps;    // Price direction prediction (-10000 to +10000)
    uint16_t volatility_signal_bps;  // External volatility estimate
    int64_t price_barrier_hi;        // Upper price barrier
    int64_t price_barrier_lo;        // Lower price barrier
    uint8_t k_skew;                  // Skew intensity (0-255)
    uint8_t k_hedge;                 // Override hedge ratio (0-200, 0=use S4-S7)
    uint8_t min_edge_bps;            // Minimum edge requirement
    uint8_t exec_style;              // Execution style flags
} mmdf_wire_exec_t;
```

### Op 2: Config (`MM_OP_CONFIG`)

Update persistent safety parameters (S4-S7).

### Op 3: Pulse (`MM_OP_PULSE`)

Trigger gamma hedge rebalancing without updating quotes.

### Op 4: Exit (`MM_OP_EXIT`)

Cancel all outstanding quotes and exit market making.

---

## Quote Computation

### 1. Center Price Calculation

```c
center_price = mid_price * (1 + alpha_prediction_bps / 10000)
```

The alpha prediction allows the keeper to bias quotes based on expected price movement.

### 2. Spread Calculation

```c
// Base spread + volatility adjustment
effective_vol = max(onchain_vol, external_vol_signal)
spread_bps = BASE_SPREAD + (effective_vol * VOL_MULTIPLIER)
spread_bps = clamp(spread_bps, 0, MAX_SPREAD)
```

### 3. Inventory Skew

To manage inventory risk, quotes are skewed based on current position:

```c
// Calculate inventory deviation from target (50% base / 50% VUSD)
target_base_value = capital_vusd / 2
inv_dev = current_base_value - target_base_value
inv_dev_ratio = inv_dev / capital_vusd  // in bps

// Apply skew (k_skew controls intensity)
skew_offset = inv_dev_ratio * k_skew / 256
```

- **Long inventory** → Lower bid, higher ask (encourage selling)
- **Short inventory** → Higher bid, lower ask (encourage buying)

### 4. Final Quote Prices

```c
bid_price = center_price * (1 - half_spread - skew_offset)
ask_price = center_price * (1 + half_spread + skew_offset)
```

---

## Circuit Breaker

When volatility exceeds `MM_VOL_CIRCUIT_BREAKER_BPS` (80%):

1. Quotes are **not placed**
2. Function returns early with status code 1
3. Keeper should retry when volatility subsides

---

## Gamma Hedging

The MM integrates with perpetual futures for delta hedging:

### Hedge Ratio Calculation

```c
// Interpolate hedge ratio based on volatility
if (vol >= vol_high)
    ratio = hedge_max_pct
else if (vol <= vol_low)
    ratio = hedge_min_pct
else
    ratio = interpolate(vol, vol_low, vol_high, hedge_min, hedge_max)
```

### Hedge Target

```c
target_hedge_qty = -inventory_base * hedge_ratio_pct / 100
```

Negative because hedging a long spot position requires a short perp position.

### Rebalancing

Only rebalances when delta exceeds threshold:

```c
if (delta_value_vusd >= MM_HEDGE_REBALANCE_THRESHOLD_VUSD_SCALED)
    emit_hedge_target(target_hedge_qty)
```

---

## Pipe Messages

For integration with PERP DF in the same batch:

| Message Type | ID | Purpose |
|--------------|-----|---------|
| `MM_PIPEMSG_PERP_EXPOSURE_BASE` | 0x4D10 | Query current perp position |
| `MM_PIPEMSG_HEDGE_TARGET_BASE` | 0x4D11 | Emit hedge target to PERP |

---

## UFC Integration

The MM uses UFC limit orders for quote placement:

```c
df_ufc_emit_limit_order(fund_row, col, side, price, qty)
```

**Assumptions:**
- Orders are **idempotent** per (fund_row, col, side)
- New order **replaces** existing quote for that side
- `qty == 0` means **auto-size** based on available balance

---

## Staleness Protection

Each execute call includes a validity window:

```c
static int32_t mmdf_check_stale(df_ctx_t *ctx, uint32_t tx_ref_block, uint32_t validity_window)
{
    uint64_t limit = tx_ref_block + validity_window;
    if (ctx->ro.utime > limit)
        return -1;  // Stale, reject
    return 0;
}
```

This prevents old keeper transactions from executing with outdated parameters.

---

## Helper Functions

### Price Calculations

```c
mmdf_apply_bps_floor(price, offset_bps)  // price * (1 + offset/10000), round down
mmdf_apply_bps_ceil(price, offset_bps)   // price * (1 + offset/10000), round up
```

### Safe Arithmetic

```c
mmdf_saturating_add_i64(a, b)  // Add with saturation at INT64_MIN/MAX
mmdf_muldiv_floor_pos(a, b, den)  // (a * b) / den, floor, using __int128
mmdf_muldiv_ceil_pos(a, b, den)   // (a * b) / den, ceiling, using __int128
```

---

## Capital Tracking

After each operation, capital is updated:

```c
static void mmdf_update_inventory_and_capital(...)
{
    inv_base = df_src_bal(ctx, col_base);
    inv_vusd = df_src_bal(ctx, col_vusd);
    base_value_vusd = inv_base * center_price / SATOSHIS;
    capital_vusd = inv_vusd + base_value_vusd;
    
    // Store in registers
    ctx->rw.regbank_rw[MM_S_CAPITAL_HINT_VUSD] = capital_vusd;
    ctx->rw.regbank_rw[MM_S_INVENTORY_BASE] = inv_base;
    ctx->rw.regbank_rw[MM_S_LAST_CENTER_PRICE] = center_price;
}
```

---

## Compile-Time Configuration

Required defines:
- `MM_BASE_ASSET_ID`: Asset ID for the base token being market-made
- `MM_VUSD_ASSET_ID`: Asset ID for VUSD quote currency

---

## Key Design Decisions

1. **Keeper-driven**: No autonomous execution - requires external trigger
2. **Stateless parameters**: Strategy can change per-call without state migration
3. **Inventory skew**: Natural mean-reversion to target allocation
4. **Vol-responsive spreads**: Wider spreads in volatile markets = more edge
5. **Integrated hedging**: Delta-neutral via perpetual futures
6. **Circuit breaker**: Automatic shutdown in extreme conditions

---

## Usage Pattern

Typical keeper flow:

1. Observe market conditions (price, volatility, inventory)
2. Compute alpha prediction based on signals
3. Pack `mmdf_wire_exec_t` with parameters
4. Submit dataflow transaction
5. MM computes and places quotes
6. If hedging needed, emit pipe message to PERP DF

---

*Documentation generated by Opus, Wake 1317*
