# VBPF Virtual Machine Documentation
## File: `DF/vbpf.c` (1938 lines)

**Purpose:** Topology-preserving BPF interpreter for DataFlow smart contracts. This is the execution engine that runs eBPF bytecode on Tockchain.

**Last Updated:** Wake 1281 (2026-01-13)

---

## Overview

VBPF (Valis BPF) is derived from [uBPF](https://github.com/iovisor/ubpf) with significant modifications for blockchain use:

1. **Gas metering** - Every instruction costs gas, preventing infinite loops
2. **Security hardening** - Backward jump gas checks, size overflow protection
3. **Instruction fusion** - Multiple instructions combined for efficiency
4. **Helper dispatch** - Controlled access to system functions

### Key Invariant
```
pc == original eBPF instruction index (always)
```
- Fused ops live at first slot; remaining slots become NOP shadows
- Verifier rejects jumps/calls into shadow slots
- NO branch offset rewriting needed

---

## Error Codes

| Code | Name | Description |
|------|------|-------------|
| 0 | `DF_ERR_OK` | Success |
| -1 | `DF_ERR_OOB_MEM` | Out of bounds memory access |
| -2 | `DF_ERR_OOG` | Out of gas |
| -3 | `DF_ERR_DIV_ZERO` | Division by zero |
| -4 | `DF_ERR_HELPER` | Helper function error |
| -5 | `DF_ERR_OPCODE` | Invalid opcode |
| -6 | `DF_ERR_PC_OOB` | Program counter out of bounds |
| -7 | `DF_ERR_VERIFY` | Verification failed |
| -8 | `DF_ERR_TRANSLATE` | Translation failed |
| -9 | `DF_ERR_STACK_OVERFLOW` | Call stack overflow |
| -10 | `DF_ERR_VERIFY_OPCODE` | Invalid opcode in verification |
| -11 | `DF_ERR_VERIFY_EXIT` | Missing EXIT instruction |
| -12 | `DF_ERR_VERIFY_HELPER` | Invalid helper call |
| -13 | `DF_ERR_VERIFY_LDDW_PAIR` | Invalid LDDW instruction pair |
| -14 | `DF_ERR_ILLEGAL_OP` | Illegal operation |

---

## Limits

```c
#define MAX_EBPF_INSTS      (VALIS_MAX_TXSIZE / sizeof(struct ebpf_inst))
#define NOP_TAIL_PAD        8U
#define MAX_CALL_STACK      8U       // BPF-to-BPF call depth
#define MAX_BUF_SIZE        (64U * 1024U)   // 64 KB max for variable-size ops
#define MAX_PIPE_SIZE       (2U * 1024U)    // 2 KB max for pipe ops
```

---

## Internal Opcodes

VBPF extends standard eBPF with internal opcodes for optimization:

| Opcode | Value | Description |
|--------|-------|-------------|
| `OP_NOP` | 0xFE | No operation (shadow slot) |
| `OP_CALL_BPF` | 0xF0 | BPF-to-BPF call |
| `OP_FUSED_CALL1` | 0xF1 | Fused 1-arg helper call |
| `OP_FUSED_CALL2` | 0xF2 | Fused 2-arg helper call |
| `OP_FUSED_CALL3` | 0xF3 | Fused 3-arg helper call |
| `OP_FUSED_CALL4` | 0xF4 | Fused 4-arg helper call |
| `OP_FUSED_CALL5` | 0xF5 | Fused 5-arg helper call |
| `OP_LDDW_FUSED` | 0xF6 | Fused 64-bit load |

---

## Core Functions

### Gas Table Initialization

```c
static void init_gas_table(void)
```
**Purpose:** Initialize the gas cost table for all helper functions.
- Called lazily on first use
- Maps helper IDs to gas costs
- Thread-safe initialization

---

### Shadow Map

```c
static int32_t mark_shadow_map(
    const struct ebpf_inst *insts,
    uint32_t num_insts,
    uint8_t *shadow
)
```
**Purpose:** Mark shadow slots in instruction stream.
- Shadow slots are created by LDDW (2-instruction sequence)
- Prevents jumps into middle of multi-instruction sequences
- Returns 0 on error, non-zero on success

---

### Verifier

```c
int32_t df_verify_program(
    const struct ebpf_inst *insts,
    uint32_t num_insts
)
```
**Purpose:** Verify eBPF program before execution.

**Verification Steps:**
1. Check instruction count bounds
2. **First pass - Structural validation:**
   - LDDW structure (must have continuation)
   - Opcode support check
   - Register bounds (0-10)
   - Static div-by-zero detection
   - Helper call validation
3. Check EXIT at end
4. Build shadow map
5. **Second pass - Jump validation:**
   - No jumps into shadow slots
   - No BPF-to-BPF calls into shadows

**Returns:** `DF_ERR_OK` on success, error code on failure.

---

### Translator

```c
int32_t df_translate(
    df_op_t ops[VALIS_MAX_TXSIZE/sizeof(uint64_t)],
    struct ebpf_inst *insts,
    int32_t num_insts
)
```
**Purpose:** Translate eBPF instructions to internal df_op_t format.

**Translation Features:**
- LDDW fusion (2 instructions → 1 fused op)
- Helper call fusion (MOV + CALL → fused call)
- Multi-arg call fusion (up to 5 MOVs + CALL)
- NOP padding for shadow slots

**Returns:** Number of translated ops, or negative error code.

---

### High-Level Translation API

```c
int32_t df_translate_ebpf_to_dfops(
    const uint8_t *code,
    int32_t codelen,
    tmpmem_t *arena,
    df_op_t **out_ops,
    int32_t *out_opcount
)
```
**Purpose:** Complete translation pipeline.

**Steps:**
1. Parse code as ebpf_inst array
2. Verify program
3. Allocate ops array from arena
4. Translate instructions
5. Return ops and count

---

### Executor

```c
HOT int32_t df_exec(
    const df_op_t *ops,
    uint32_t num_ops,
    df_ctx_t *ctx,
    uint8_t *arena_base,
    uint32_t arena_size,
    uint32_t arena_write_protect,
    int32_t initial_gas,
    int32_t *final_gas,
    uint64_t *ret_out
)
```
**Purpose:** Execute translated DataFlow program.

**Parameters:**
- `ops`: Translated instruction array
- `num_ops`: Number of instructions
- `ctx`: Execution context (registers, state)
- `arena_base`: Memory arena for program
- `arena_size`: Total arena size
- `arena_write_protect`: Bytes that are read-only
- `initial_gas`: Starting gas budget
- `final_gas`: Output - remaining gas
- `ret_out`: Output - return value (r0)

**Implementation:**
- Uses computed goto (GCC extension) for dispatch
- 256-entry jump table for opcodes
- Hot path optimized with `__attribute__((hot))`

**Supported Operations:**
- All ALU32/ALU64 opcodes
- All memory opcodes (load/store)
- All branch opcodes (conditional/unconditional)
- BPF-to-BPF calls (8-deep stack)
- Helper calls with gas metering

---

## Instruction Fusion

VBPF optimizes common patterns by fusing multiple instructions:

### LDDW Fusion
```
LDDW r1, imm_lo    →    OP_LDDW_FUSED r1, imm64
CONT 0, imm_hi
```

### Helper Call Fusion
```
MOV r1, arg1       →    OP_FUSED_CALL1 helper_id, arg1
CALL helper_id
```

### Multi-Arg Fusion
```
MOV r1, arg1       →    OP_FUSED_CALL3 helper_id, arg1, arg2, arg3
MOV r2, arg2
MOV r3, arg3
CALL helper_id
```

---

## Gas Model

### Per-Instruction Gas
Every instruction consumes gas based on its type:
- Simple ALU: 1 gas
- Memory access: 2-4 gas
- Helper calls: Variable (from gas_table)
- Backward jumps: Extra gas check (DoS prevention)

### Gas Exhaustion
When gas reaches 0:
- Execution halts immediately
- `DF_ERR_OOG` returned
- State changes rolled back

### Backward Jump Protection
```c
// v9 Security fix: backward jumps consume extra gas
if (offset < 0 && gas < BACKWARD_JUMP_GAS) {
    return DF_ERR_OOG;
}
```

---

## Memory Model

### Arena Layout
```
[0 ... arena_write_protect-1]  : Read-only (code, constants)
[arena_write_protect ... arena_size-1] : Read-write (heap, stack)
```

### Bounds Checking
All memory accesses are bounds-checked:
```c
if (addr + size > arena_size) return DF_ERR_OOB_MEM;
if (addr < arena_write_protect && is_write) return DF_ERR_OOB_MEM;
```

---

## Helper Functions

Helpers are external functions callable from eBPF:

### Validation
```c
if (!helper_allowed(helper_id)) return DF_ERR_VERIFY_HELPER;
```

### Dispatch
```c
uint64_t result = helper_dispatch(helper_id, r1, r2, r3, r4, r5);
```

### Built-in Helpers
- Polynomial math (log2, exp2, sqrt)
- Memory operations
- Cryptographic functions
- State access

---

## Security Features

1. **Bounded Execution**
   - All loops must be bounded (eBPF requirement)
   - Backward jump gas prevents infinite loops

2. **Memory Safety**
   - All accesses bounds-checked
   - Write protection for code region

3. **Stack Depth Limit**
   - MAX_CALL_STACK = 8
   - Prevents stack overflow attacks

4. **Size Overflow Protection**
   - MAX_BUF_SIZE = 64KB
   - MAX_PIPE_SIZE = 2KB
   - Prevents OOB via size manipulation

5. **Static Analysis**
   - Div-by-zero detected at verify time
   - Invalid opcodes rejected
   - Jump targets validated

---

## Compiler Hints

```c
#define LIKELY(x)       __builtin_expect(!!(x), 1)
#define UNLIKELY(x)     __builtin_expect(!!(x), 0)
#define PREFETCH_R(p)   __builtin_prefetch((p), 0, 3)
#define HOT             __attribute__((hot))
#define ALIGNED(n)      __attribute__((aligned(n)))
```

**Recommended compilation:**
```
-O2 -march=native -mbmi -mlzcnt -mpopcnt
```

---

## Data Structures

### df_op_t
Internal instruction format:
```c
typedef struct {
    uint8_t opcode;    // Instruction opcode
    uint8_t dst;       // Destination register
    uint8_t src;       // Source register
    uint8_t hid;       // Helper ID (for calls)
    int16_t off;       // Offset
    uint8_t aux;       // Auxiliary data (gas cost)
    uint8_t skip;      // Instructions to skip (fusion)
    int32_t imm;       // Immediate value
    uint64_t imm64;    // 64-bit immediate (LDDW)
} df_op_t;
```

### df_ctx_t
Execution context:
- Registers r0-r10
- Stack pointer
- Program counter
- State references

---

## Related Files

| File | Purpose |
|------|---------|
| `dataflow.h` | DataFlow definitions |
| `dataflow.c` | Main orchestration |
| `ebpf.h` | eBPF instruction definitions |
| `df_sdk.h` | SDK for DF development |
| `df_gas.h` | Gas calculation |
| `frama_verified.h` | Verified math functions |

---

## Usage Example

```c
// Verify program
int32_t rc = df_verify_program(insts, num_insts);
if (rc != DF_ERR_OK) {
    // Handle verification failure
}

// Translate
df_op_t *ops;
int32_t opcount;
rc = df_translate_ebpf_to_dfops(code, codelen, arena, &ops, &opcount);
if (rc != DF_ERR_OK) {
    // Handle translation failure
}

// Execute
int32_t final_gas;
uint64_t result;
rc = df_exec(ops, opcount, ctx, arena_base, arena_size,
             write_protect, initial_gas, &final_gas, &result);
if (rc != DF_ERR_OK) {
    // Handle execution failure
}
```

---

*Documentation generated by Opus, Wake 1281*
