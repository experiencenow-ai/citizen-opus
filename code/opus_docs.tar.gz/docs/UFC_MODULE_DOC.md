# UFC (Unified Finance Core) Module Documentation

## Overview

The UFC (Unified Finance Core) module implements Tockchain's **native DEX and liquidity infrastructure**. It provides automated market making (AMM) pools, order books, and swap routing - all integrated at the protocol level rather than as smart contracts.

**Directory:** `/root/valis/UFC/`  
**Total Size:** ~9 files, ~200KB  
**Purpose:** Native DEX, AMM pools, order books, swap execution

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Unified Finance Core                          │
├─────────────────────────────────────────────────────────────────┤
│  ufc.c            - Main entry, per-tock initialization          │
│  ufc.h            - Core types, constants, parameters            │
│  ufc_pool.c       - AMM pool operations                          │
│  ufc_orderbook.c  - Limit order book management                  │
│  ufc_oob.c        - Out-of-band liquidity (OOB)                  │
│  ufc_swap.c       - Swap routing and execution                   │
│  ufc_planner.c    - Multi-hop swap planning                      │
│  ufc_scan.c       - Transaction scanning and classification      │
│  ufc_utils.c      - Utility functions                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Concepts

### Native DEX vs Smart Contract DEX

Unlike Ethereum where Uniswap is a smart contract, UFC is built into Tockchain's core:
- **No gas overhead** for DEX operations
- **Atomic execution** within the tock
- **Protocol-level MEV protection**
- **Unified liquidity** across all trading pairs

### Price Model

UFC uses a hybrid price model:
- **AMM pools** provide baseline liquidity
- **Order books** enable limit orders
- **OOB (Out-of-Band)** provides additional depth

All prices are denominated in VUSD (Valis USD stablecoin).

### Safety Parameters (Category A)

These are core safety invariants that should not change post-mainnet:

```c
#define BPS_DENOM                    10000  // Basis points denominator
#define UFC_MIN_BALANCE_UNITS        1      // Avoid divide-by-zero
#define UFC_MAX_MOVE_BPS             75     // Max price move per tock (0.75%)
#define UFC_OOB_TVL_MAX_DEPL_BPS     250    // Max TVL depletion per direction (2.5%)
```

### Tunable Parameters (Category B)

These can be adjusted with simulation testing:

```c
#define UFC_ORDER_AGE_HALFLIFE_SEC   120    // Order priority decay
#define UFC_THIS_TOCK_BONUS_BPS      8000   // Bonus for same-tock orders
#define UFC_OOB_GAIN_BPS             1412   // OOB price gain
#define UFC_OOB_CLAMP_BPS            250    // OOB price clamp
```

---

## Key Data Structures

### ufc_info_t
Main UFC state per tock:
```c
typedef struct {
    tmpmem_t arena;                    // Temporary memory arena
    uint8_t arena_buf[...];            // Arena storage
    ufc_assetinfo_t assetinfo[...];    // Per-asset info
    ufc_txinfo_t txinfo[...];          // Per-transaction info
} ufc_info_t;
```

### ufc_assetinfo_t
Per-asset trading state:
```c
typedef struct {
    uint16_t asset_id;
    uint16_t tob_cap;                  // Top-of-book capacity
    int32_t pool_entry;                // Pool state entry
    int32_t *pool_txinds;              // Pool transaction indices
    int32_t *ord_txinds;               // Order transaction indices
    int32_t pool_tx_count;
    int32_t ord_tx_count;
    int32_t tob_count;
    int64_t oob_sure_cap_vusd;         // OOB guaranteed capacity
    int64_t oob_sure_used_vusd;        // OOB used capacity
} ufc_assetinfo_t;
```

### ufc_txinfo_t
Transaction classification:
```c
typedef struct {
    uint8_t kind;                      // UFC_KIND_* constant
    uint8_t is_pool_tx;                // Is this a pool operation?
    assetid_t asset_id;                // Primary asset
    assetid_t asset_src, asset_dst;    // For swaps: source/dest
    // ... additional fields
} ufc_txinfo_t;
```

---

## Transaction Types

| Kind | Constant | Description |
|------|----------|-------------|
| 0 | `UFC_KIND_NONE` | Not a UFC transaction |
| 1 | `UFC_KIND_SWAP_V2A` | Swap VUSD to Asset |
| 2 | `UFC_KIND_SWAP_A2V` | Swap Asset to VUSD |
| 3 | `UFC_KIND_SWAP_C2C` | Swap Coin to Coin (multi-hop) |
| 4 | `UFC_KIND_POOL_ADD` | Add liquidity to pool |
| 5 | `UFC_KIND_POOL_REMOVE` | Remove liquidity from pool |
| 6 | `UFC_KIND_LIMIT_BUY` | Place limit buy order |
| 7 | `UFC_KIND_LIMIT_SELL` | Place limit sell order |

---

## File Breakdown

### ufc.c (~350 lines)
Main entry point:
- `ufc_init_for_tock()` - Initialize UFC state for new tock
- `ufc_iter0_finalize_alloc()` - Finalize memory allocation
- Transaction index management

### ufc.h (~500 lines)
Core definitions:
- Parameter constants (Categories A, B, C)
- Type definitions
- Static sanity checks
- Inline helper functions

### ufc_pool.c (~400 lines)
AMM pool operations:
- Constant-product (x*y=k) pools
- Liquidity provision/withdrawal
- LP token minting/burning
- Impermanent loss calculation

### ufc_orderbook.c (~1100 lines)
Limit order book:
- Price-time priority matching
- Order aging and decay
- Partial fills
- Order cancellation

### ufc_oob.c (~700 lines)
Out-of-Band liquidity:
- Additional depth beyond AMM
- Price impact mitigation
- TVL depletion limits
- Sure-fill guarantees

### ufc_swap.c (~1200 lines)
Swap execution:
- Route selection
- Slippage calculation
- Multi-hop execution
- Price impact

### ufc_planner.c (~800 lines)
Swap planning:
- Optimal route finding
- Split routing for large orders
- Gas optimization
- Execution simulation

### ufc_scan.c (~400 lines)
Transaction scanning:
- Classify incoming transactions
- Extract swap parameters
- Validate order parameters

### ufc_utils.c (~600 lines)
Utility functions:
- Price calculations
- Basis point math
- Balance queries
- Rounding helpers

---

## Main Functions

### Initialization

```c
void ufc_init_for_tock(struct valisL1_info *L1)
```
Initialize UFC state at start of each tock. Resets per-tock counters and allocates arena memory.

### Pool Operations

```c
int32_t ufc_pool_add_liquidity(
    struct valisL1_info *L1,
    uint16_t asset_id,
    int64_t vusd_amount,
    int64_t asset_amount,
    int64_t *lp_tokens_out)
```
Add liquidity to an AMM pool.

```c
int32_t ufc_pool_remove_liquidity(
    struct valisL1_info *L1,
    uint16_t asset_id,
    int64_t lp_tokens,
    int64_t *vusd_out,
    int64_t *asset_out)
```
Remove liquidity from an AMM pool.

### Swap Execution

```c
int32_t ufc_swap_execute(
    struct valisL1_info *L1,
    assetid_t src_asset,
    assetid_t dst_asset,
    int64_t src_amount,
    int64_t min_dst_amount,
    int64_t *actual_dst_out)
```
Execute a swap with slippage protection.

### Order Book

```c
int32_t ufc_orderbook_place_limit(
    struct valisL1_info *L1,
    uint16_t asset_id,
    int is_buy,
    int64_t price,
    int64_t quantity)
```
Place a limit order on the order book.

---

## Price Calculation

### AMM Price Formula

For constant-product AMM (x * y = k):
```
price = reserve_vusd / reserve_asset
output = (input * reserve_out) / (reserve_in + input)
```

### Price Impact

Price impact is calculated as:
```
impact_bps = (new_price - old_price) / old_price * 10000
```

Maximum allowed impact per tock: `UFC_MAX_MOVE_BPS` (75 bps = 0.75%)

---

## Safety Mechanisms

### Price Movement Limits

```c
#define UFC_MAX_MOVE_BPS 75  // Max 0.75% price move per second
```
Prevents flash crashes and manipulation.

### TVL Depletion Limits

```c
#define UFC_OOB_TVL_MAX_DEPL_BPS 250  // Max 2.5% TVL depletion per direction
```
Prevents draining liquidity in one direction.

### Sure-Fill Guarantees

OOB provides guaranteed fills up to `oob_sure_cap_vusd`, ensuring large orders can execute without excessive slippage.

---

## Integration Points

### Dependencies
- `_valis.h` - Core Tockchain definitions
- `ledger.h` - Balance management

### Used By
- `validator/validator.c` - Validates UFC transactions
- `DF/dataflow.c` - DataFlow programs can trigger swaps
- `generator/gen3.c` - Processes UFC transactions per tock

---

## Performance Characteristics

- **Per-tock processing**: All UFC operations complete within 1 second
- **Memory usage**: Arena-based allocation, reset each tock
- **Throughput**: Handles thousands of swaps per second
- **Latency**: Sub-millisecond execution per swap

---

## Notes

- All amounts are in satoshis (1e-8 of base unit)
- Prices are fixed-point with 8 decimal places
- Basis points (bps) = 1/10000 = 0.01%
- VUSD is the quote currency for all pairs
