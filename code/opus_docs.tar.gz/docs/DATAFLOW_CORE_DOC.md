# DataFlow Core Module Documentation
## File: `DF/dataflow.c` (842 lines)

**Purpose:** Main orchestration module for DataFlow smart contracts on Tockchain. Handles deployment, execution, batching, and lifecycle management of eBPF-based smart contracts.

**Last Updated:** Wake 1281 (2026-01-13)

---

## Architecture Overview

DataFlow is Tockchain's smart contract system. Unlike Ethereum's EVM, it uses eBPF (extended Berkeley Packet Filter) bytecode, which is:
- Formally verifiable (bounded loops, no unbounded recursion)
- JIT-compilable for near-native performance
- Already proven in Linux kernel for safety

### Module Structure

The main `dataflow.c` file includes several sub-modules via `#include`:
```c
#include "dataflow.h"
#include "validator.h"
#include "dataflow_api.c"      // API functions for DF interaction
#include "dataflow_cache.c"    // Caching layer for DF state
#include "dataflow_batch.c"    // Batch execution of multiple calls
#include "dataflow_frontier.c" // Frontier tracking for execution order
#include "dataflow_trigger.c"  // Trigger-based execution
```

---

## Core Functions

### Tock Lifecycle Functions

```c
void df_tock_begin(struct valisL1_info *L1, uint32_t utime)
```
**Purpose:** Initialize DataFlow state at the beginning of each tock (block).
- Ensures cache is initialized
- Sets current utime in DFstate
- Copies finalhash from raw info
- Initializes frontier pre-scan

```c
void df_tock_end(struct valisL1_info *L1, uint32_t utime)
```
**Purpose:** Finalize DataFlow state at end of tock.
- Runs trigger checks for end-of-tock events
- Finalizes frontier state

---

### Validation Functions

```c
static int32_t df_ops_meta_validate_local(const struct valisL1_info *L1, df_ops_meta_u_t om)
```
**Purpose:** Validate operations metadata.
- Checks offset is 16-byte aligned
- Validates length is non-zero
- Ensures end doesn't exceed `DF_OPSLOG_MAX_BYTES`

**Returns:** 0 on success, negative error codes:
- `-1`: NULL L1
- `-2`: ops_base is NULL
- `-3`: length is 0
- `-4`: offset not 16-byte aligned
- `-5`: end exceeds max bytes

```c
static int32_t df_validate_image_header_basic(const df_image_header_t *hdr)
```
**Purpose:** Basic validation of DF image header.
- Checks ABI version matches current
- Validates required_family is 0
- Ensures reserved fields are 0
- Validates register count (1 to DF_MAX_REGS_PER_DF)
- Validates register base + count doesn't exceed limit
- Ensures mingas > 0

```c
static int32_t df_validate_entrypoints_within_opcount(const df_image_header_t *hdr, uint32_t opcount)
```
**Purpose:** Validate all entrypoints are within valid opcode range.
- Iterates through entrypoints array
- Skips zero entries (unused)
- Ensures each entrypoint < opcount

---

### Deployment Functions

```c
static int32_t df_deploy_copy_image_to_aligned_scratch(
    struct valisL1_info *L1,
    const struct dataflow_tx *dfc,
    int32_t tx_nosig,
    int32_t *image_len_out,
    df_image_header_t **hdr_out,
    struct ebpf_inst **insts_out,
    int32_t *num_insts_out
)
```
**Purpose:** Copy DF image to aligned scratch memory for processing.
- Calculates max payload from transaction
- Copies image to aligned scratch buffer
- Parses header and instruction pointers
- Returns instruction count

```c
static int32_t df_handler_dataflow_deploy_tx(
    struct valisL1_info *L1,
    const struct txheader *txH,
    const struct dataflow_tx *dfc,
    int32_t txsize,
    int32_t signlen,
    tockid_t tid,
    ufc_planned_address_mutation_t *plan,
    int32_t *plan_countp,
    int32_t plancap
)
```
**Purpose:** Handle deployment of a new DataFlow contract.
- Validates transaction fields
- Copies image to scratch
- Validates header and entrypoints
- Translates eBPF to internal ops format
- Builds deployment plan
- Commits to ledger

**Error Codes (DF_E_DEPLOY_*):**
- `DF_E_DEPLOY_TXFIELDS_BAD`: Invalid transaction fields
- `DF_E_DEPLOY_IMAGE_COPY_FAIL`: Failed to copy image
- `DF_E_DEPLOY_HEADER_BAD`: Invalid image header
- `DF_E_DEPLOY_ENTRYPOINTS_BAD`: Invalid entrypoints
- `DF_E_DEPLOY_TRANSLATE_FAIL`: Translation failed

---

### Restore Functions

```c
static int32_t df_handler_dataflow_restore_tx(
    struct valisL1_info *L1,
    const struct txheader *txH,
    const struct dataflow_tx *dfc,
    int32_t txsize,
    tockid_t tid,
    ufc_planned_address_mutation_t *plan,
    int32_t *plan_countp,
    int32_t plancap
)
```
**Purpose:** Restore a previously deployed DataFlow contract.
- Handles contract restoration after state changes
- Validates source and destination addresses
- Manages fee and excess fund transfers
- Updates CRV (Contract Reserve Value)

---

### Batch Execution

```c
static int32_t df_handler_dataflow_batch_predebit(
    struct valisL1_info *L1,
    const struct txheader *txH,
    struct dataflow_tx *dfc,
    int32_t txsize,
    tockid_t tid,
    ufc_planned_address_mutation_t *plan,
    int32_t *plan_countp,
    int32_t plancap
)
```
**Purpose:** Pre-debit gas for batch execution of multiple DF calls.
- Validates asset is VUSD
- Validates destination is VNET pool
- Validates budget is non-negative
- Calculates sum of mingas for all calls
- Transfers gas budget to pool
- Commits transaction plan

**Error Codes (DF_E_BATCH_*):**
- `DF_E_BATCH_CALLS_FAIL`: General batch failure
- `DF_E_BATCH_ASSET_BAD`: Wrong asset type
- `DF_E_BATCH_POOL_NOT_FOUND`: VNET pool not found
- `DF_E_BATCH_DEST_BAD`: Wrong destination
- `DF_E_BATCH_BUDGET_NEG`: Negative budget
- `DF_E_BATCH_SRC_NOT_FOUND`: Source address not found
- `DF_E_BATCH_BUDGET_TOO_LOW`: Budget less than sum of mingas
- `DF_E_BATCH_GAS_TRANSFER_FAIL`: Gas transfer failed
- `DF_E_BATCH_GAS_COMMIT_FAIL`: Commit failed

---

### Modification Record Functions

```c
static assetid_t df_modrec_word_asset(uint16_t word_index, int32_t is_pending)
```
**Purpose:** Generate asset ID for modification record word.
- Base is `ASSET_DF_MODREC0`
- Adds word_index to aid
- Sets iscoin flag based on pending status

```c
static void df_modrec_unpack_timepair(
    uint64_t packed,
    uint32_t *out_timelock_secs,
    uint32_t *out_activation_utime
)
```
**Purpose:** Unpack time pair from packed 64-bit value.
- Upper 32 bits: timelock_secs
- Lower 32 bits: activation_utime

```c
static void df_modrec_encode_key20_words3(
    const uint8_t in20[PKSIZE],
    uint64_t out3[3]
)
```
**Purpose:** Encode 20-byte key into 3 64-bit words.
- Word 0: bytes 0-7
- Word 1: bytes 8-15
- Word 2: bytes 16-19 (upper 4 bytes, lower 4 zeroed)

---

## Operations Log (OpsLog)

The OpsLog stores translated eBPF instructions in an internal format.

```c
static int32_t df_opslog_prepare_region(
    struct valisL1_info *L1,
    uint64_t *off_out,
    df_op_t **ops_out
)
```
**Purpose:** Prepare a region in the ops log for new instructions.
- Returns current offset
- Returns pointer to ops array

```c
static int32_t df_opslog_verify_translate(
    const struct ebpf_inst *insts,
    int32_t num_insts,
    df_op_t *ops_dst,
    int32_t *opcount_out
)
```
**Purpose:** Verify and translate eBPF instructions to internal format.
- Validates each instruction
- Translates to df_op_t format
- Returns opcount

```c
static int32_t df_opslog_build_meta(
    uint64_t off,
    int32_t opcount,
    df_ops_meta_u_t *ops_meta_out,
    uint64_t *ops_after_out
)
```
**Purpose:** Build metadata for ops log entry.
- Packs offset and length into ops_meta
- Calculates ops_after (next available offset)

---

## Data Structures

### df_state_t
Main state structure for DataFlow system:
- `utime`: Current unix time
- `finalhash`: Hash of current block
- `ops_base`: Base pointer for operations log
- Cache and frontier state

### df_image_header_t
Header for deployed DF images:
- `abi_version`: ABI version for compatibility
- `required_family`: Required CPU family (0 for portable)
- `reg_count`: Number of registers used
- `reg_base`: Base register index
- `mingas`: Minimum gas required
- `entrypoints[]`: Array of entrypoint offsets

### df_ops_meta_u_t
Packed metadata for operations:
- `offset48`: 48-bit offset into ops log
- `len16`: 16-bit length

### df_meta_u_t
General metadata union for DF contracts.

---

## Gas Model

DataFlow uses a gas model similar to Ethereum but with key differences:
- Gas is denominated in VUSD
- Minimum gas (`mingas`) is specified per contract
- Batch operations pre-debit total gas
- Unused gas is refunded

---

## Integration Points

### With Validator
- `validator.h` included for transaction validation
- Uses `transferfunds()` for fund movements
- Uses `findaddrhash()` for address lookup

### With UFC (Universal Financial Computer)
- `ufc_tx_plan_*` functions for transaction planning
- `ufc_get_vnet_pool_common()` for pool access

### With Bridge
- DataFlow contracts can interact with Ethereum bridge
- CRV (Contract Reserve Value) tracks bridged assets

---

## Error Handling

All functions return `int32_t`:
- Positive values: Success (often transaction size)
- Zero: Success (no data)
- Negative values: Error codes

Error code namespaces:
- `DF_E_DEPLOY_*`: Deployment errors
- `DF_E_BATCH_*`: Batch execution errors
- `DF_E_RESTORE_*`: Restore errors

---

## Security Considerations

1. **Bounded Execution**: eBPF guarantees bounded loops
2. **Gas Limits**: All operations require gas
3. **Validation**: Multiple validation layers before execution
4. **Alignment**: 16-byte alignment enforced for ops log
5. **Overflow Protection**: Uses safe math functions from frama_verified.c

---

## Related Files

| File | Purpose |
|------|---------|
| `dataflow.h` | Header definitions |
| `dataflow_api.c` | External API functions |
| `dataflow_cache.c` | State caching |
| `dataflow_batch.c` | Batch execution |
| `dataflow_frontier.c` | Execution ordering |
| `dataflow_trigger.c` | Event triggers |
| `vbpf.c` | eBPF VM implementation |
| `df_gas.h` | Gas calculation |
| `df_sdk.h` | SDK for DF development |

---

## Usage Example

```c
// At start of each tock
df_tock_begin(L1, current_utime);

// Process DataFlow transactions
// ... (handled by validator)

// At end of each tock
df_tock_end(L1, current_utime);
```

---

*Documentation generated by Opus, Wake 1281*
