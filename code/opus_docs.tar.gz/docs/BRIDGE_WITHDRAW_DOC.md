# Bridge Withdraw Module Documentation

**File:** `/root/valis/bridge/bridge_withdraw.c`  
**Lines:** ~1871  
**Purpose:** Processes withdrawals from Tockchain to Ethereum using epoch-based batching and Merkle proofs

## Overview

This module implements the withdrawal side of the Ethereum-Tockchain bridge. Unlike deposits (which are processed individually), withdrawals are batched into epochs and finalized collectively. This design:
- Reduces gas costs by batching many withdrawals
- Enables efficient Merkle proof verification on Ethereum
- Provides a clear finalization window for validators

## Architecture

### Withdrawal Flow

```
User Withdrawal Request (Tockchain)
        ↓
    Append to Epoch (bridge_withdraw_epoch_append)
        ↓
    Epoch Closes (time-based)
        ↓
    Compute Merkle Root (bridge_withdraw_epoch_compute_root)
        ↓
    Collect Validator Signatures (bridge_withdraw_sig_add)
        ↓
    Submit Root to Ethereum (acceptRoot)
        ↓
    User Claims on Ethereum (claim with Merkle proof)
```

### Epoch System

Withdrawals are grouped into time-based epochs:

| Constant | Purpose |
|----------|---------|
| `WITHDRAW_EPOCH_SECS` | Duration of each epoch |
| `WITHDRAW_EPOCH_LEAD_SECS` | Lead time before epoch closes |

Functions for epoch timing:
- `withdraw_epoch_id_for_withdraw_utime()` - Get epoch ID for a withdrawal
- `withdraw_epoch_id_for_finalize_utime()` - Get epoch ID for finalization
- `withdraw_utime_should_finalize_epoch()` - Check if current time triggers finalization

## Key Data Structures

### `withdraw_state_t`
Global withdrawal state, accessed via `withdraw_state(L1)`:
```c
withdraw_state_t {
    pthread_mutex_t epoch_mutex;    // Thread safety for epoch operations
    FILE *active_fp;                // Currently open epoch file
    uint64_t active_epoch_id;       // Current epoch being written
    int32_t eip712_inited;          // EIP-712 initialization flag
    // EIP-712 type hashes cached
    uint8_t domain_typehash[32];
    uint8_t root_typehash[32];
    // Pending signatures from validators
    withdraw_pending_epoch_t pending[N_PENDING];
    withdraw_sigq_t sigq;           // Signature queue
};
```

### `withdraw_claim_leaf_t`
Individual withdrawal claim data:
```c
withdraw_claim_leaf_t {
    uint8_t token_addr20[20];       // Token contract (0 = ETH)
    uint8_t recipient_addr20[20];   // Destination address
    uint8_t amount_be32[32];        // Amount (big-endian)
    uint8_t withdraw_id[32];        // Unique withdrawal ID
    union {
        uint32_t u32;
        struct {
            uint32_t is_eth : 1;    // Native ETH vs ERC20
        } f;
    } flags;
};
```

### `withdraw_epoch_record_t`
On-disk record for each withdrawal in an epoch:
```c
withdraw_epoch_record_t {
    uint32_t utime;                 // Withdrawal timestamp
    uint32_t txind;                 // Transaction index
    withdraw_claim_leaf_t leaf;     // Claim data
    int64_t value_usd63;            // USD value (fixed-point)
};
```

### `withdraw_root_approval_t`
Header for validator signature collection:
```c
withdraw_root_approval_t {
    uint64_t bridge_id;             // Bridge identifier
    uint64_t epoch_id;              // Epoch being approved
    uint8_t merkle_root[32];        // Computed root hash
    uint64_t total_value_usd63;     // Total epoch value
    uint32_t leaf_count;            // Number of withdrawals
};
```

## Core Functions

### Epoch Management

#### `bridge_withdraw_epoch_set_active()`
```c
int32_t bridge_withdraw_epoch_set_active(withdraw_state_t *W, uint64_t epoch_id)
```
Opens an epoch file for appending. Closes previous epoch if different.

#### `bridge_withdraw_epoch_append()`
```c
int32_t bridge_withdraw_epoch_append(struct valisL1_info *L1, uint32_t utime_sec,
                                     struct withdraw_entry *wp)
```
Adds a withdrawal to the current epoch. Converts internal format to claim leaf.

#### `bridge_withdraw_epoch_close_active()`
```c
void bridge_withdraw_epoch_close_active(withdraw_state_t *W)
```
Closes the currently active epoch file.

### Merkle Tree Operations

#### `withdraw_compute_leaf_hash()`
```c
int32_t withdraw_compute_leaf_hash(uint64_t bridge_id, uint64_t epoch_id,
                                   uint64_t index, const withdraw_claim_leaf_t *leaf,
                                   uint8_t out32[32])
```
Computes keccak256 hash of a leaf using ABI encoding:
- bridge_id, epoch_id, index (uint256)
- token, recipient (address)
- amount (uint256)
- flags (uint32)

#### `bridge_withdraw_epoch_compute_root()`
Computes Merkle root for an entire epoch by:
1. Reading all records from epoch file
2. Computing leaf hashes
3. Building binary Merkle tree
4. Writing proof data to `.proof` file

#### `bridge_withdraw_epoch_read_proof()`
```c
int32_t bridge_withdraw_epoch_read_proof(uint64_t epoch_id, uint32_t leaf_index,
                                         uint8_t **proof_out, uint32_t *proof_n_out,
                                         uint64_t *path_bits_out)
```
Reads Merkle proof for a specific leaf from the proof file.

### EIP-712 Signing

The module uses EIP-712 typed data signing for validator approvals.

#### `bridge_withdraw_eip712_init_once()`
Initializes type hashes for:
- Domain separator: `EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)`
- Root approval: `RootApproval(uint256 bridgeId,uint256 epochId,bytes32 merkleRoot,uint256 totalValueUsd,uint256 leafCount,uint256 signerEpoch)`

#### `bridge_withdraw_eip712_digest()`
```c
int32_t bridge_withdraw_eip712_digest(withdraw_state_t *W,
                                      const withdraw_root_approval_t *hdr,
                                      uint32_t signer_epoch, uint32_t chainid,
                                      const uint8_t module_addr20[20],
                                      uint8_t out32[32])
```
Computes the final EIP-712 digest for signing:
`keccak256("\x19\x01" || domainSeparator || structHash)`

### Signature Collection

#### `bridge_withdraw_sig_add()`
```c
int32_t bridge_withdraw_sig_add(withdraw_pending_epoch_t *pe,
                                const withdraw_sig_datatx_t *sigtx)
```
Adds a validator signature to pending collection. Checks for duplicates.

#### `bridge_withdraw_sigq_push()` / `bridge_withdraw_sigq_pop()`
Thread-safe queue for incoming signature transactions.

### Ethereum Calldata Generation

#### `bridge_withdraw_build_claim_calldata()`
```c
int32_t bridge_withdraw_build_claim_calldata(withdraw_state_t *W, tmpmem_t *mem,
                                             uint64_t epoch_id, uint64_t leaf_index,
                                             const withdraw_claim_leaf_t *leaf,
                                             const uint8_t *proof32, uint32_t proof_n,
                                             uint64_t path_bits,
                                             uint8_t **out_calldata, int32_t *out_len)
```
Builds ABI-encoded calldata for the Ethereum `claim()` function:
- Function selector (4 bytes)
- epoch_id, leaf_index (uint256)
- token, recipient (address)
- amount, flags (uint256)
- proof offset, path_bits, proof_n (uint256)
- proof data (32 * proof_n bytes)

#### `bridge_withdraw_acceptroot_selector()` / `bridge_withdraw_claim_selector()`
Compute function selectors for Ethereum contract calls.

### Index Operations

For efficient lookup of withdrawals by (utime, txind):

#### `withdraw_index_table_init()` / `withdraw_index_table_insert()`
Build hash table mapping (utime, txind) → leaf_index.

#### `withdraw_index_lookup_file()`
Binary search in on-disk index file.

## File System

| Pattern | Purpose |
|---------|---------|
| `withdraw/{epoch_id}.epoch` | Epoch records (append-only) |
| `withdraw/{epoch_id}.proof` | Merkle proofs |
| `withdraw/{epoch_id}.root` | Finalized root + signatures |
| `withdraw/{epoch_id}.index` | (utime,txind) → leaf_index mapping |

## Token Handling

#### `convert_withdraw2leaf()`
Converts internal withdrawal to claim leaf:
- VUSD → mapped USDC contract address
- WETH → zero address (native ETH)
- Other ERC20 → original token address
- Handles decimal scaling differences

## Thread Safety

- `epoch_mutex` protects epoch file operations
- `sigq` uses mutex for signature queue
- All epoch operations lock before file I/O

## Security Considerations

1. **Epoch finalization:** Withdrawals locked after epoch closes
2. **Validator quorum:** Multiple signatures required for root approval
3. **Merkle verification:** On-chain proof verification prevents fraud
4. **EIP-712:** Typed signing prevents signature replay across chains

## Dependencies

- `bridge.h` - Shared bridge definitions
- `pthread.h` - Thread synchronization
- `eth_keccak256()` - Hashing
- `secp256k1` - Signature operations

## Related Files

- `bridge_deposit.c` - Deposit (Ethereum → Tockchain) processing
- `withdraw.sol` - Ethereum withdrawal contract
- `bridge.h` - Shared constants and structures
