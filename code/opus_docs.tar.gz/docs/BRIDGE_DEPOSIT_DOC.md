# Bridge Deposit Module Documentation

**File:** `/root/valis/bridge/bridge_deposit.c`  
**Lines:** ~1270  
**Purpose:** Monitors Ethereum for deposits and processes them into Tockchain minting transactions

## Overview

This module implements the deposit side of the Ethereum-Tockchain bridge. It:
1. Polls Ethereum blocks for deposit events
2. Tracks deposit state through a multi-stage pipeline
3. Generates cryptographic proofs for deposits
4. Creates Tockchain transactions to mint corresponding tokens

## Architecture

### Deposit Flow

```
Ethereum Deposit Event
        ↓
    Poll & Detect (eth_weth_enum_next)
        ↓
    Queue Deposit (queue_deposit)
        ↓
    Get Block Hash (get_deposit_blockhash)
        ↓
    Generate Proof (issue_proofs_mjs)
        ↓
    Create DataTx (generate_eth_datatx)
        ↓
    Submit to Validators (check_possible_mint)
        ↓
    Finalize (DEPOSIT_FINISHED)
```

### Deposit States

The module uses a state machine to track each deposit:

| State | Value | Description |
|-------|-------|-------------|
| `DEPOSIT_STARTED` | 0 | Initial state, deposit detected |
| `DEPOSIT_HAVE_BLOCKHASH` | 1 | Block hash retrieved |
| `DEPOSIT_PENDING_PROOF` | 2 | Waiting for MPT proof generation |
| `DEPOSIT_HAVE_DATATX` | 3 | DataTx created |
| `DEPOSIT_HAVE_QUORUM` | 4 | Validator quorum achieved |
| `DEPOSIT_SUBMITTED` | 5 | Transaction submitted |
| `DEPOSIT_FINISHED` | 6 | Successfully minted |
| `DEPOSIT_EXPIRED` | 7 | Deadline passed, deposit failed |

## Key Data Structures

### `deposit_block_info`
```c
struct deposit_block_info {
    uint8_t txid[32];           // Ethereum transaction ID
    uint8_t blockhash[32];      // Block containing deposit
    uint8_t depositor[32];      // Depositor address (padded)
    uint8_t amount32[32];       // Deposit amount
    uint32_t blocknum;          // Block number
    uint32_t timestamp;         // Block timestamp
    int32_t txind;              // Transaction index in block
    int32_t logindex;           // Log index in transaction
    int32_t selector;           // Contract selector (WETH/USDT)
    int32_t state;              // Current processing state
    uint32_t proofgen_utime;    // Proof generation start time
    uint32_t txutime;           // Transaction submission time
    uint32_t mint_utime;        // Minting completion time
};
```

### `eth_weth_enum_t`
Enumerator for scanning Ethereum blocks for deposit events.

## Core Functions

### Event Detection

#### `get_deposit_topic0_hex()`
```c
void get_deposit_topic0_hex(char out_hex[67])
```
Returns the keccak256 hash of the Deposit event signature:
`Deposit(address,address,bytes32,uint256,uint256,uint256)`

Used to filter Ethereum logs for deposit events.

#### `eth_weth_enum_init()` / `eth_weth_enum_next()`
```c
void eth_weth_enum_init(eth_weth_enum_t *cur, uint32_t from_block, 
                        uint32_t to_block, int32_t last_log_index)
int eth_weth_enum_next(int32_t selector, eth_weth_enum_t *cur, ...)
```
Initialize and iterate through deposit events in a block range.

### Deposit Processing

#### `queue_deposit()`
```c
int32_t queue_deposit(struct valisL1_info *L1, int32_t selector,
                      uint8_t txid[32], uint32_t blocknum,
                      int32_t txind, int32_t logind,
                      uint8_t depositor[32], uint8_t amount32[32])
```
Adds a new deposit to the processing queue. Checks for duplicates.

#### `get_deposit_blockhash()`
```c
int32_t get_deposit_blockhash(struct deposit_block_info *dp)
```
Fetches the block hash for a deposit's block number via Ethereum RPC.

#### `issue_proofs_mjs()`
```c
void issue_proofs_mjs(struct deposit_block_info *dp, char *txidstr)
```
Spawns the `proofs.mjs` script to generate Merkle Patricia Trie proofs for the deposit receipt.

### Transaction Creation

#### `create_ethbridge_tx()`
```c
int32_t create_ethbridge_tx(struct datatx *dtx, int32_t datalen,
                            receipt_deposit_t *rp, int32_t ethbridge,
                            uint8_t sigdest[PKSIZE])
```
Creates a signed Tockchain transaction for bridge operations. Handles:
- `DATATX_ETH_HEADER` - Ethereum block header submission
- `DATATX_ETH_MINT` - Token minting
- `DATATX_UPDATE_TOB` - Top-of-book updates
- `DATATX_UPDATE_PRICES` - Price oracle updates

#### `generate_eth_datatx()`
```c
int32_t generate_eth_datatx(char *prooffname, uint8_t txid[32],
                            uint8_t dtxbuf[VALIS_MAX_TXSIZE])
```
Generates a complete data transaction from proof file, including:
- Ethereum block header
- Receipt trie proof
- Deposit event data

### State Management

#### `update_deposit_state()`
```c
int32_t update_deposit_state(struct valisL1_info *L1, uint32_t finalized,
                             int32_t pushsock, struct deposit_block_info *dp)
```
Main state machine driver. Advances deposits through states based on:
- File existence checks (proofs, datatx files)
- Time elapsed
- Finalization status

#### `check_possible_mint()`
```c
int32_t check_possible_mint(validators_t *ds, uint8_t deposit_txid[32],
                            uint8_t dtxbuf[VALIS_MAX_TXSIZE])
```
Checks if a deposit can be minted by verifying:
- DataTx is valid
- Validator quorum exists
- Deposit hasn't already been processed

### Batch Operations

#### `update_pending_deposits()`
```c
void update_pending_deposits(struct valisL1_info *L1, uint32_t finalized,
                             int32_t pushsock)
```
Iterates through all pending deposits and updates their states.

#### `import_deposits_from_dir()`
```c
int32_t import_deposits_from_dir(struct valisL1_info *L1, const char *dirpath)
```
Imports deposit data from a directory of datatx files. Used for recovery/replay.

## Contract Selectors

The module supports multiple deposit contracts:

| Selector | Contract | Purpose |
|----------|----------|---------|
| 0 | `DEPOSIT_CONTRACT` | WETH deposits |
| 1 | `USDTDEPOSIT_CONTRACT` | USDT deposits |

## File System Integration

The module uses files to track deposit state:

| Pattern | Purpose |
|---------|---------|
| `proofs/{txid}.json` | MPT proof data |
| `{blockhash}.Q` | Quorum achieved marker |
| `{txid}_{logindex}.datatx` | Serialized data transaction |

## Error Handling

- **Expired deposits:** Deposits older than `BRIDGE_DEADLINE` are marked `DEPOSIT_EXPIRED`
- **Proof generation timeout:** Re-triggers proof generation after 300 seconds
- **Invalid receipts:** Logged and rejected in `create_ethbridge_tx()`

## Security Considerations

1. **Finalization check:** Deposits only processed after Ethereum finalization
2. **Duplicate prevention:** `enqueue_pending_deposit_unique()` prevents double-processing
3. **Signature verification:** All bridge transactions are signed with wallet private key
4. **Deadline enforcement:** Prevents stale deposits from being processed

## Dependencies

- `gen3.h` - Core generator types
- `yyjson.h` - JSON parsing for proofs
- `uthash.h` - Hash table for deposit tracking
- `valis_messaging.h` - Network communication
- `proofs.mjs` - External proof generation script

## Related Files

- `bridge_withdraw.c` - Withdrawal (Tockchain → Ethereum) processing
- `bridge_mpt.c` - Merkle Patricia Trie verification
- `bridge_rlp.c` - RLP encoding/decoding
- `bridge.h` - Shared bridge definitions
