# bridge_utils.c - Low-Level Conversion Utilities

## Purpose

This module provides centralized, efficient hex/binary conversion functions and low-level helpers used throughout the bridge code. It handles the constant need to convert between human-readable hex strings (like Ethereum addresses) and binary data.

**Design Philosophy**: All conversion helpers route through `bin2hex` and `central_hex_to_bin` for consistency and efficiency. Uses lookup tables for O(1) hex character conversion.

## Constants

```c
#define ETH_SECONDS_PER_SLOT 12U      // Ethereum slot duration
#define ETH_SLOTS_PER_EPOCH 32U       // Slots per epoch
#define BEACON_GENESIS_TIME 1606824023 // Dec 1, 2020 12:00:23 UTC
```

## Lookup Tables

### g_hex_nibble_lut[256]
Maps ASCII characters to nibble values (0-15) or -1 for invalid.
- '0'-'9' → 0-9
- 'a'-'f' or 'A'-'F' → 10-15
- All others → -1

### g_hex_pairs_lut[256][3]
Pre-computed hex string pairs for each byte value.
- 0x00 → "00"
- 0xFF → "ff"
- Enables O(1) byte-to-hex conversion

## Functions

### Time/Slot Conversion

#### eth_slot_from_unix
```c
uint64_t eth_slot_from_unix(uint64_t unix_ts, uint64_t beacon_genesis_time)
```
Converts Unix timestamp to Ethereum beacon chain slot number.

**Formula**: `slot = (unix_ts - genesis) / 12`

**Returns**: Slot number (0 if before genesis)

#### eth_epoch_from_unix
```c
uint32_t eth_epoch_from_unix(uint32_t unix_ts)
```
Converts Unix timestamp to Ethereum epoch number.

**Formula**: `epoch = slot / 32`

### Memory Allocation

#### tmp_alloc
```c
void *tmp_alloc(tmpmem_t *mem, int32_t size, int32_t align)
```
Allocates memory from a temporary buffer with alignment.

**Parameters**:
- `mem`: Temporary memory context
- `size`: Bytes to allocate
- `align`: Alignment requirement (1, 2, 4, 8, etc.)

**Returns**: Pointer to allocated memory, or NULL if insufficient space

**Note**: This is a bump allocator - no individual frees, reset entire buffer at once.

#### tmp_alloc_offset
```c
void *tmp_alloc_offset(tmpmem_t *mem, int32_t size, int32_t align, uint16_t *offsetp)
```
Like tmp_alloc but also returns the offset within the buffer.

**Use case**: When you need to store a reference to allocated data as an offset rather than pointer.

### Hex/Binary Conversion

#### bin2hex
```c
int32_t bin2hex(const uint8_t *bin, int32_t bin_len, char *hex)
```
Converts binary data to lowercase hex string.

**Output**: Null-terminated hex string (no "0x" prefix)

**Returns**: Length of hex string (bin_len * 2), or -1 on error

**Performance**: O(n) using lookup table

#### central_hex_to_bin
```c
int32_t central_hex_to_bin(const char *hex, uint8_t *bin, 
                           int32_t max_out_bin_len, int32_t *out_bin_len)
```
**Core hex-to-binary converter.** All other hex→bin functions use this.

**Features**:
- Handles optional "0x" or "0X" prefix
- Validates all characters
- Enforces maximum output length

**Returns**: 0 on success, -1 on error

#### byteToHex / hexToByte
```c
void byteToHex(const uint8_t *byte, char *hex, const int sizeInByte)
int hexToByte(const char *hex, uint8_t *bytes, int32_t len)
```
Legacy wrapper functions for compatibility.

#### hex2bin
```c
int32_t hex2bin(const char *hex, uint8_t *bin, int32_t *bin_len)
```
Alternative interface to central_hex_to_bin.

**Note**: `bin_len` is both input (max) and output (actual).

### Numeric Conversion

#### hex0x_to_u64
```c
int32_t hex0x_to_u64(const char *s, uint64_t *out_u64)
```
Parses "0x..." hex string to uint64_t.

**Validation**:
- Must start with "0x" or "0X"
- All characters must be valid hex
- Overflow check against MAXCOINSUPPLY

**Returns**: 0 on success, negative on error

#### hex0x_to_bytes
```c
int hex0x_to_bytes(const char *hex, uint8_t *out, int out_cap)
```
Converts "0x..." hex string to bytes, handling odd-length input.

**Features**:
- Handles optional "0x" prefix
- Handles odd-length hex (pads high nibble with 0)
- Right-aligns output for proper numeric interpretation

**Returns**: Number of bytes written, or negative on error

#### bytes_to_0xhex
```c
int bytes_to_0xhex(char *dst, int dst_cap, const uint8_t *src, int len)
```
Converts bytes to "0x..." hex string.

**Output format**: "0x" + lowercase hex

**Returns**: 0 on success, -1 on error

### Address Handling

#### addr_hex_to_20
```c
int addr_hex_to_20(const char *hex_addr, uint8_t out20[20])
```
Converts hex address string to 20-byte binary.

**Handles**:
- 20-byte addresses (direct copy)
- 32-byte ABI-encoded addresses (extract last 20 bytes)
- Short addresses (left-pad with zeros)

**Returns**: 0 on success, negative on error

### Big-Endian Utilities

#### be_from_u64_min
```c
int be_from_u64_min(uint64_t v, uint8_t out[8])
```
Converts uint64 to big-endian bytes, returning minimal length.

**Example**:
- 0x1234 → [0x12, 0x34], returns 2
- 0 → [0,0,0,0,0,0,0,0], returns 0

**Use case**: RLP encoding requires minimal-length integers

#### be_right_copy_to_32
```c
void be_right_copy_to_32(uint8_t out32[32], const uint8_t *src, int32_t src_len)
```
Right-aligns source bytes into 32-byte buffer, zero-padding left.

**Use case**: Converting variable-length integers to 32-byte EVM words

#### be_to_u64
```c
uint64_t be_to_u64(const uint8_t *b, int32_t n)
```
Converts big-endian bytes to uint64.

**Handles**: Variable-length input (1-8 bytes), truncates if longer

## Usage Examples

### Converting Ethereum Address
```c
uint8_t addr[20];
int rc = addr_hex_to_20("0x742d35Cc6634C0532925a3b844Bc9e7595f1b", addr);
```

### Allocating Temporary Memory
```c
tmpmem_t mem = {.buffer = buf, .capacity = 4096, .used = 0};
uint8_t *data = tmp_alloc(&mem, 256, 8);  // 256 bytes, 8-byte aligned
```

### Slot Calculation
```c
uint64_t slot = eth_slot_from_unix(1704067200, 0);  // Jan 1, 2024
// Returns slot number for that timestamp
```

## Dependencies

- **bridge.h**: Type definitions (tmpmem_t, MAXCOINSUPPLY)
- **string.h**: memcpy, memset, strlen

## Code Style Notes

From the file header:
- Allman braces
- No blank lines inside functions
- Locals declared at top of function
- stdint types for locals
- Single-statement if folded to two lines

## File Statistics
- **Lines**: 320
- **Size**: ~9KB
- **Functions**: 14
- **Complexity**: Low - utility functions

---
*Documentation generated by Opus, Wake 1279*
*Part of Tockchain/Valis documentation project*
