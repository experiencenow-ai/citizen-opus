# bridge_mpt.c - Merkle Patricia Trie Proof Verification

## Purpose

This module implements Ethereum's Merkle Patricia Trie (MPT) proof verification and root computation. It enables Tockchain to cryptographically verify that a transaction or receipt exists in an Ethereum block without trusting any third party - the proof itself is mathematically verifiable against the block's state root.

This is critical for the Ethereum bridge: when someone claims they deposited ETH/tokens on Ethereum, Tockchain can verify this claim by checking the MPT proof against the known block header.

## Key Concepts

### Merkle Patricia Trie
Ethereum stores all state (accounts, transactions, receipts) in a modified Merkle tree called the Patricia Trie. Each leaf is reachable by a unique key path, and the root hash commits to the entire tree's contents. Any change to any leaf changes the root.

### Hex Prefix Encoding
MPT keys are encoded in "nibbles" (4-bit values, 0-15). The hex prefix encoding stores:
- Whether the path length is odd or even
- Whether this is a leaf node (terminating) or extension node

### Node Types
- **Branch nodes**: 17 elements (16 children for each nibble + value)
- **Extension nodes**: 2 elements (shared path prefix + child hash)
- **Leaf nodes**: 2 elements (remaining path + value)

## Data Structures

### nibbles_struct
```c
struct nibbles_struct {
    uint8_t *nib;      // Array of nibbles (0-15 each)
    int32_t len;       // Number of nibbles
    int32_t odd;       // 1 if odd-length path
    int32_t terminate; // 1 if leaf node
};
```

### proof_entry
```c
struct proof_entry {
    const uint8_t *buf;  // Raw RLP-encoded node
    int32_t len;         // Length of node data
    uint8_t hash[32];    // Keccak256 hash of node
};
```

### eth_mpt_proof (from bridge.h)
```c
struct eth_mpt_proof {
    uint8_t root[32];           // Expected MPT root
    uint32_t index;             // Transaction/receipt index
    int32_t num_nodes;          // Number of proof nodes
    uint16_t node_lens[MAX_MPT_NODES]; // Length of each node
    int32_t datalen;            // Total data length
    uint8_t data[];             // Concatenated node data
};
```

### receipt_deposit_t
Parsed deposit event from Ethereum receipt:
```c
typedef struct {
    uint8_t sender[20];         // Depositor address
    uint8_t token[20];          // Token address (0 for ETH)
    uint8_t valis_dest[32];     // Destination on Tockchain
    uint8_t amount_be32[32];    // Amount (big-endian)
    uint8_t nonce_be32[32];     // Deposit nonce
    uint8_t block_number_be32[32]; // Block number
} receipt_deposit_t;
```

## Functions

### decode_hex_prefix (static)
```c
static int32_t decode_hex_prefix(tmpmem_t *mem, const struct rlp_item *item, 
                                  struct nibbles_struct *out)
```
Decodes Ethereum's hex-prefix encoding to extract nibbles and node type.

**Logic:**
1. Extract flag byte (first nibble indicates odd/even and leaf/extension)
2. Allocate nibble array in temporary memory
3. Convert bytes to nibbles (each byte → 2 nibbles)
4. Handle odd-length paths (first nibble is data, not padding)

**Returns:** 0 on success, -1 on error

### find_node_by_hash
```c
int32_t find_node_by_hash(struct proof_entry *entries, int32_t num_proof,
                          const uint8_t h[32], const uint8_t **out_buf, 
                          int32_t *out_len)
```
Searches proof entries for a node matching the given hash.

**Used for:** Following child references in branch/extension nodes during proof traversal.

**Returns:** 1 if found (with output pointers set), 0 if not found

### eth_verify_mpt_proof (static)
```c
static int32_t eth_verify_mpt_proof(tmpmem_t *mem, const uint8_t root[32],
                                     const uint8_t *rlp_key, int32_t rlp_key_len,
                                     const uint8_t **proof, const int32_t *proof_lens,
                                     int32_t num_proof, uint8_t **value_out, 
                                     int32_t *value_len_out)
```
**Core verification function.** Traverses the MPT from root to leaf, verifying each step.

**Algorithm:**
1. Convert key to nibbles
2. Hash each proof node and store in entries array
3. Start at root hash, find matching node
4. For each node:
   - If branch: follow nibble index, consume 1 nibble
   - If extension: verify path prefix matches, consume prefix nibbles
   - If leaf: verify remaining path matches, return value
5. Continue until key fully consumed or error

**Returns:** 0 on success with value_out set, negative on error

### eth_mpt_proof_verify_value
```c
int32_t eth_mpt_proof_verify_value(tmpmem_t *mem, const struct eth_mpt_proof *proof,
                                    uint8_t **value_out, int32_t *value_len_out)
```
Public wrapper that verifies an eth_mpt_proof structure.

**Steps:**
1. Validate proof structure (node count, lengths)
2. Build node pointer array
3. RLP-encode the index as key
4. Call eth_verify_mpt_proof

**Returns:** 0 on success, negative on error

### eth_mpt_compute_root_bottom_up (static)
```c
static int32_t eth_mpt_compute_root_bottom_up(tmpmem_t *mem, const uint8_t *rlp_key,
                                               int32_t rlp_key_len, const uint8_t *value,
                                               int32_t value_len, const uint8_t **proof,
                                               const int32_t *proof_lens, int32_t num_proof,
                                               uint8_t computed_root[32])
```
**Recomputes the MPT root** by reconstructing nodes bottom-up with a given value.

**Purpose:** Allows verification that a specific value at a specific key produces the expected root. This is the inverse of verification - instead of checking if a value exists, it proves what root would result from that value.

**Algorithm:**
1. Start at leaf level with the value
2. For each level going up:
   - Reconstruct the node with the new child hash
   - Hash the reconstructed node
   - Use this hash as input for next level
3. Final hash should match expected root

**Returns:** 0 on success with computed_root set

### eth_mpt_recompute_root
```c
int32_t eth_mpt_recompute_root(const struct eth_mpt_proof *p, tmpmem_t *mem,
                                uint8_t out_root[32], const uint8_t **out_val,
                                int32_t *out_val_len)
```
Public function combining verification and root recomputation.

**Steps:**
1. Verify proof and extract value (top-down)
2. Recompute root from value (bottom-up)
3. Verify computed root matches proof's root

**Returns:** 0 on success

### eth_receipt_collect_deposits
```c
int32_t eth_receipt_collect_deposits(const uint8_t *typed, int32_t tlen, tmpmem_t *mem,
                                      receipt_deposit_t **out_deposits,
                                      uint32_t **out_txlog_indexes, int32_t *out_n)
```
Parses an Ethereum receipt to extract Deposit events.

**Logic:**
1. Handle typed transactions (EIP-2718: type byte prefix)
2. Parse receipt RLP: [status, cumulativeGas, logsBloom, logs]
3. For each log entry:
   - Check if topic[0] matches Deposit event signature
   - If match, extract sender, token, destination, amount, nonce, block
4. Return array of deposits

**Deposit Event Signature:**
```
keccak256("Deposit(address,address,bytes32,uint256,uint256,uint256)")
```

### prove_hashandroot
```c
int32_t prove_hashandroot(tmpmem_t *mem, const struct eth_mpt_proof *tx_proof,
                          uint8_t out_txid[32], uint8_t root[32], receipt_deposit_t *rp)
```
**Main entry point for deposit verification.**

**Steps:**
1. Recompute and verify MPT root
2. Verify computed root matches proof's claimed root
3. Compute transaction ID (keccak256 of raw tx)
4. If rp provided, parse receipt for deposit events

**Returns:** 0 on success, negative on error

### eth_header_from_rlp
```c
int eth_header_from_rlp(const uint8_t *rlp, size_t rlp_len, eth_header_t *out)
```
Parses an RLP-encoded Ethereum block header.

**Extracts:**
- blockhash (computed via keccak256 of raw RLP)
- parenthash (index 0)
- txroot (index 4) - transactions trie root
- receiptsroot (index 5) - receipts trie root  
- blocknum (index 8)
- timestamp (index 11)

**Returns:** 0 on success

## Error Codes

| Code | Meaning |
|------|---------|
| -1   | Invalid parameters |
| -2   | Memory allocation failed |
| -3   | Proof length mismatch |
| -4   | Node data overflow |
| -5   | RLP encoding failed |
| -6 to -12 | Proof traversal errors |
| -13  | Key not found in trie |
| -19 to -22 | Root computation errors |
| -100 | Invalid prove_hashandroot params |
| -107 | Root mismatch |

## Dependencies

- **bridge.h**: Type definitions, RLP parsing, keccak256
- **tmp_alloc**: Temporary memory allocator
- **eth_keccak256**: Keccak-256 hash function
- **parse_rlp, rlp_***: RLP encoding/decoding utilities

## Usage in Bridge Flow

```
Ethereum Deposit → Receipt with Deposit event
                         ↓
              Generate MPT proof for receipt
                         ↓
              Submit proof to Tockchain
                         ↓
    eth_mpt_proof_verify_value() - verify inclusion
                         ↓
    eth_receipt_collect_deposits() - extract deposit
                         ↓
              Credit user on Tockchain
```

## Security Considerations

1. **Root Trust**: The MPT root must come from a trusted source (e.g., verified block header)
2. **Proof Completeness**: All nodes from root to leaf must be included
3. **Hash Verification**: Each node's hash is verified against parent's reference
4. **No Forgery**: Cannot create valid proof for non-existent data without breaking keccak256

## ASCII Diagram: MPT Structure

```
                    [Root Hash]
                         │
              ┌──────────┴──────────┐
              │                     │
         [Branch Node]         [Extension]
         (16 children)         (shared path)
              │                     │
    ┌────┬────┼────┬────┐          │
    0    1    2    ...  f     [Branch Node]
    │                              │
[Leaf]                   ┌────────┼────────┐
(value)                  0        5        f
                         │        │        │
                      [Leaf]  [Leaf]   [Leaf]
```

## File Statistics
- **Lines**: 694
- **Size**: ~24KB
- **Functions**: 8 (3 static, 5 public)
- **Complexity**: High - cryptographic proof verification

---
*Documentation generated by Opus, Wake 1279*
*Part of Tockchain/Valis documentation project*
