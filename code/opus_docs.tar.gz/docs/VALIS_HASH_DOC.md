# utils/valis_hash.c Documentation

## Overview

**File:** `utils/valis_hash.c`  
**Lines:** 1064  
**Purpose:** Cryptographic hashing for Tockchain - implements both Ethereum-compatible Keccak-256 and a custom high-performance "Turbo Hash" using AVX2 SIMD instructions.

This file is critical infrastructure - every transaction, block, and Merkle tree in Tockchain depends on these hash functions.

---

## Architecture

The file implements two distinct hashing systems:

### 1. Ethereum Keccak-256 (Standard Compatibility)
- Full 24-round Keccak-f[1600] permutation
- Rate: 136 bytes, Capacity: 512 bits
- Output: 32 bytes (256 bits)
- Suffix: 0x01 (Ethereum-specific domain separation)
- **Purpose:** Bridge operations, Ethereum compatibility, address derivation

### 2. Turbo Hash (K12-Inspired, Performance)
- Reduced-round Keccak variants for speed
- Leaf: 6-round Keccak-p[1600], rate=168 bytes, suffix=0x0B
- Trunk: 8-round Keccak-p[1600], suffix=0x07
- 8 KiB leaf blocks, AVX2 4-way parallel processing
- **Purpose:** Internal Tockchain hashing where Ethereum compatibility isn't required

---

## Dependencies

```c
#include <stdint.h>
#include <string.h>
#include <immintrin.h>  // AVX2 intrinsics (x86_64 only)
```

**Platform Requirement:** x86_64 with AVX2 support. The file will fail to compile on other architectures.

---

## Constants

### Ethereum Keccak-256

| Constant | Value | Description |
|----------|-------|-------------|
| `ETH_RATE_BYTES` | 136 | Sponge rate (1600-512)/8 |
| `ETH_OUT_BYTES` | 32 | Output hash size |
| `ETH_SUFFIX` | 0x01 | Ethereum domain separator |

### Turbo Hash (K12-style)

| Constant | Value | Description |
|----------|-------|-------------|
| `VHASH_RATE_BYTES` | 168 | Sponge rate (1600-256)/8 |
| `VHASH_LEAF_BYTES` | 8192 | 8 KiB leaf block size |
| `VHASH_LEAF_SUFFIX` | 0x0B | Leaf domain separator |
| `VHASH_FINAL_SUFFIX` | 0x07 | Final block domain separator |

### Keccak Round Constants

```c
static const uint64_t KECCAK_RC[24] = {
    0x0000000000000001ULL, 0x0000000000008082ULL,
    0x800000000000808aULL, 0x8000000080008000ULL,
    // ... 24 total round constants
};
```

---

## Core Functions

### Public API

#### `eth_keccak256`
```c
int32_t eth_keccak256(uint8_t *out32, const uint8_t *in, uint64_t len);
```
Standard Ethereum Keccak-256 hash.
- **out32:** Output buffer (32 bytes)
- **in:** Input data
- **len:** Input length in bytes
- **Returns:** 1 on success

**Usage:** Address derivation, transaction hashing, Ethereum bridge operations.

#### `eth_keccak256_x4_avx2`
```c
int32_t eth_keccak256_x4_avx2(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *in0, uint64_t len0,
    const uint8_t *in1, uint64_t len1,
    const uint8_t *in2, uint64_t len2,
    const uint8_t *in3, uint64_t len3
);
```
Parallel 4-way Keccak-256 using AVX2. Processes 4 independent inputs simultaneously.
- **Performance:** ~4x throughput vs scalar for bulk hashing

#### `eth_keccak256_x4_64B_avx2`
```c
int32_t eth_keccak256_x4_64B_avx2(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *a0, const uint8_t *b0,  // 32+32=64 bytes
    const uint8_t *a1, const uint8_t *b1,
    const uint8_t *a2, const uint8_t *b2,
    const uint8_t *a3, const uint8_t *b3
);
```
Specialized 4-way hash for 64-byte inputs (two 32-byte halves). Optimized for Merkle tree parent computation.

#### `turbo_hash_dispatch`
```c
int32_t turbo_hash_dispatch(uint8_t *out32, const uint8_t *in, uint64_t len);
```
High-performance hash using K12-inspired tree structure.
- **Small inputs (<8KB):** Single leaf hash
- **Large inputs:** Tree hash with 8KB leaves

#### `valis_hash`
```c
int32_t valis_hash(uint8_t *buf, int32_t len, uint8_t hash[32]);
```
Main Tockchain hash function. Currently wraps `eth_keccak256` for compatibility.
- **Note:** Can be switched to turbo hash for internal operations

#### `calc_merkleroot_avx`
```c
void calc_merkleroot_avx(uint8_t *txids, int32_t numtx, uint8_t merkleroot[32], int32_t need_proofofabsence);
```
Computes Merkle root from transaction IDs using AVX2-accelerated hashing.
- **txids:** Array of 32-byte transaction hashes
- **numtx:** Number of transactions
- **merkleroot:** Output 32-byte root
- **need_proofofabsence:** Flag for proof generation

**Algorithm:**
1. Allocates tree buffer for all levels
2. Processes pairs 4-at-a-time using `eth_keccak256_x4_64B_avx2`
3. Handles odd counts by duplicating last element
4. Iterates until single root remains

#### `valis_hash_select_runtime`
```c
int32_t valis_hash_select_runtime(void);
```
Runtime CPU feature detection (currently disabled, returns 0).

#### `cmptxid2`
```c
int32_t cmptxid2(const void *_a, const void *_b);
```
Comparison function for sorting 32-byte hashes. Used with `qsort()`.

---

## Internal Functions

### Keccak Permutations

#### `keccakf1600_permute_24`
```c
static void keccakf1600_permute_24(uint64_t st[25]);
```
Full 24-round Keccak-f[1600] permutation (scalar).
- **State:** 25 × 64-bit words = 1600 bits
- **Rounds:** 24 (full security)

#### `keccakp1600_permute_8`
```c
static void keccakp1600_permute_8(uint64_t st[25]);
```
Reduced 8-round Keccak-p[1600] for turbo hash trunk.

#### `keccakf1600_permute24x4_avx2`
```c
static void keccakf1600_permute24x4_avx2(__m256i A[25]);
```
4-way parallel 24-round permutation using AVX2.
- Processes 4 independent states simultaneously
- Each `__m256i` holds 4 × 64-bit lanes

#### `keccakp1600_permute6x4_avx2`
```c
static void keccakp1600_permute6x4_avx2(__m256i A[25]);
```
4-way parallel 6-round permutation for turbo hash leaves.

### Turbo Hash Helpers

#### `k12_absorb_trunk_digest`
```c
static void k12_absorb_trunk_digest(uint64_t trunk[25], const uint8_t leaf32[32]);
```
Absorbs a 32-byte leaf digest into the trunk state.

#### `leaf_digest_times4_avx2_r6`
```c
static void leaf_digest_times4_avx2_r6(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *in0, const uint8_t *in1, const uint8_t *in2, const uint8_t *in3,
    uint64_t len_each
);
```
Computes 4 leaf digests in parallel (same length inputs).

#### `leaf_digest_times4_avx2_varlen_r6`
```c
static void leaf_digest_times4_avx2_varlen_r6(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *in0, const uint8_t *in1, const uint8_t *in2, const uint8_t *in3,
    uint64_t len0, uint64_t len1, uint64_t len2, uint64_t len3
);
```
Computes 4 leaf digests in parallel (variable length inputs).

### Utility Functions

#### `rol64` / `rol64_256`
```c
static inline uint64_t rol64(uint64_t x, uint32_t n);
static inline __m256i rol64_256(__m256i x, int n);
```
64-bit rotate left (scalar and AVX2 versions).

#### `load64_tail`
```c
static inline uint64_t load64_tail(const uint8_t *p, uint32_t t);
```
Loads partial 64-bit word (1-7 bytes) for padding.

---

## Data Structures

### `hash256_t`
```c
typedef struct hash256 { uint8_t hash[32]; } hash256_t;
```
32-byte hash wrapper for type safety and sorting.

---

## Algorithm Details

### Keccak Sponge Construction

```
┌─────────────────────────────────────────┐
│         1600-bit State (25×64)          │
├─────────────────────┬───────────────────┤
│     Rate (r)        │   Capacity (c)    │
│   (absorb/squeeze)  │   (security)      │
├─────────────────────┼───────────────────┤
│ ETH: 136 bytes      │ ETH: 64 bytes     │
│ K12: 168 bytes      │ K12: 32 bytes     │
└─────────────────────┴───────────────────┘
```

**Absorb Phase:**
1. XOR input blocks into rate portion
2. Apply permutation after each block

**Squeeze Phase:**
1. Extract output from rate portion
2. Apply permutation if more output needed

### Turbo Hash Tree Structure

```
Input: [============ Large Data ============]
       ↓ Split into 8KB leaves
       
Leaves: [L0][L1][L2][L3][L4][L5][L6][L7]...
        ↓ 6-round Keccak each (parallel 4-way)
        
Digests: [D0][D1][D2][D3][D4][D5][D6][D7]...
         ↓ Absorb into trunk state
         
Trunk:   [=====================================]
         ↓ 8-round Keccak finalize
         
Output:  [32-byte hash]
```

### Merkle Tree Construction

```
Level 0 (leaves):  [TX0] [TX1] [TX2] [TX3] [TX4] [TX5] [TX6] [TX7]
                     \   /       \   /       \   /       \   /
Level 1:            [H01]       [H23]       [H45]       [H67]
                       \         /             \         /
Level 2:              [H0123]                 [H4567]
                           \                   /
Level 3 (root):            [Merkle Root]
```

**Odd count handling:** Last element duplicated to form pair.

---

## Performance Characteristics

| Operation | Throughput | Notes |
|-----------|------------|-------|
| `eth_keccak256` (scalar) | ~500 MB/s | Single hash |
| `eth_keccak256_x4_avx2` | ~2 GB/s | 4-way parallel |
| `turbo_hash` (large) | ~3 GB/s | Tree structure + 6-round leaves |
| Merkle root (1000 tx) | ~0.5 ms | AVX2 accelerated |

*Approximate, depends on CPU.*

---

## Security Notes

1. **Ethereum Compatibility:** `eth_keccak256` uses full 24 rounds - cryptographically secure for all purposes.

2. **Turbo Hash:** Reduced rounds (6 leaf, 8 trunk) trade some security margin for speed. Suitable for internal Tockchain operations where collision resistance is primary concern.

3. **Determinism:** All functions are deterministic across nodes with identical binaries. No floating-point, no uninitialized memory.

4. **Side Channels:** Implementation uses table lookups and data-dependent branches. Not constant-time. Acceptable for blockchain hashing (public data).

---

## Usage Examples

### Basic Hash
```c
uint8_t hash[32];
uint8_t data[] = "Hello, Tockchain!";
eth_keccak256(hash, data, sizeof(data) - 1);
```

### Merkle Root
```c
uint8_t txids[1000 * 32];  // 1000 transaction hashes
uint8_t merkle_root[32];
// ... fill txids ...
calc_merkleroot_avx(txids, 1000, merkle_root, 0);
```

### Bulk Hashing
```c
uint8_t out[4][32];
uint8_t *inputs[4] = {data0, data1, data2, data3};
uint64_t lens[4] = {len0, len1, len2, len3};
eth_keccak256_x4_avx2(out[0], out[1], out[2], out[3],
                      inputs[0], lens[0],
                      inputs[1], lens[1],
                      inputs[2], lens[2],
                      inputs[3], lens[3]);
```

---

## Build Integration

**Makefile entry:**
```makefile
utils/valis_hash.o: utils/valis_hash.c
    $(CC) $(CFLAGS) -mavx2 -c $< -o $@
```

**Required flags:** `-mavx2` (or equivalent for target CPU)

---

## Related Files

- `_valis.h` - Main header, may declare hash function prototypes
- `frama_verified.c` - Uses hashing for verified operations
- `bridge/bridge_rlp.c` - Uses Keccak for Ethereum encoding
- `validator/validator.c` - Transaction hash verification

---

## Changelog

| Date | Change |
|------|--------|
| Original | Ethereum Keccak-256 implementation |
| Later | Added AVX2 4-way parallel |
| Later | Added K12-inspired turbo hash |
| Current | Turbo hash disabled, using eth_keccak256 for all |

---

*Documentation generated: Wake 1281 (2026-01-13)*
*Auditor: Pending (Mira)*
