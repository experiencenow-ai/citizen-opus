# Bridge ABI Module Documentation

## Overview

`bridge/bridge_abi.c` implements **Ethereum ABI (Application Binary Interface) encoding and decoding** for the Tockchain-Ethereum bridge. This module enables Tockchain to construct and parse Ethereum smart contract calls.

**File:** `/root/valis/bridge/bridge_abi.c`  
**Lines:** ~1091  
**Purpose:** Encode/decode Ethereum ABI data for cross-chain communication

---

## Core Concepts

### ABI Encoding Basics

Ethereum's ABI uses 32-byte "words" for all data types:
- **Static types** (uint256, address, bool): Encoded directly as 32-byte words
- **Dynamic types** (bytes, arrays): Use offset pointers + length + data

The module provides utilities to:
1. Build ABI-encoded calldata for smart contract calls
2. Parse ABI-encoded return values from `eth_call` responses

### Buffer Management

```c
typedef struct {
    uint8_t *data;  // Raw bytes
    int32_t len;    // Current length
    int32_t cap;    // Allocated capacity
} vabi_buf_t;
```

The buffer auto-grows when needed via `vabi_ensure()`.

---

## Key Data Structures

### vabi_buf_t
Dynamic buffer for building ABI-encoded data:
- `vabi_init(buf, initial_cap)` - Initialize with capacity
- `vabi_free(buf)` - Release memory
- `vabi_ensure(buf, need)` - Ensure space for `need` more bytes

### eth_call_params_t
Parameters for `eth_call` JSON-RPC:
- `to_hex` - Target contract address (0x-prefixed)
- `data_hex` - ABI-encoded calldata (0x-prefixed)

---

## Function Reference

### Hex Utilities

```c
int vabi_hex_nibble(char c)
```
Convert hex character to 0-15 value. Returns -1 on invalid input.

### Buffer Operations

```c
int vabi_push_selector(const uint8_t sel4[4], vabi_buf_t *b)
```
Push 4-byte function selector (first 4 bytes of keccak256(signature)).

```c
int vabi_push_word(const uint8_t *src, int src_len, vabi_buf_t *b)
```
Push a 32-byte ABI word, left-padding with zeros.

### Type-Specific Encoders

```c
int vabi_push_u256_from_u64(uint64_t v, vabi_buf_t *b)
int vabi_push_u256_from_u32(uint32_t v, vabi_buf_t *b)
int vabi_push_u256_from_u16(uint16_t v, vabi_buf_t *b)
int vabi_push_u256_from_u8(uint8_t v, vabi_buf_t *b)
int vabi_push_bool(bool v, vabi_buf_t *b)
int vabi_push_bytes32(const uint8_t h32[32], vabi_buf_t *b)
int vabi_push_address20(const uint8_t a20[20], vabi_buf_t *b)
```

### Dynamic Array Encoders

```c
int vabi_push_dyn_bytes(const uint8_t *data, int datalen, vabi_buf_t *b)
```
Encode dynamic bytes: offset pointer + length + padded data.

```c
int vabi_push_dyn_address20_array_head_tail(
    const uint8_t (*addrs)[20], int count, int head_words, vabi_buf_t *b)
```
Encode dynamic address array with proper offset calculation.

### Return Value Decoders

```c
int vabi_result_word_at(const char *result_hex, int word_index, uint8_t out32[32])
int vabi_result_u64_at(const char *result_hex, int word_index, uint64_t *out)
int vabi_result_u32_at(const char *result_hex, int word_index, uint32_t *out)
int vabi_result_u16_at(const char *result_hex, int word_index, uint16_t *out)
int vabi_result_u8_at(const char *result_hex, int word_index, uint8_t *out)
int vabi_result_bool_at(const char *result_hex, int word_index, bool *out)
int vabi_result_address20_at(const char *result_hex, int word_index, uint8_t out20[20])
```

### High-Level Call Wrappers

```c
int vabi_call_bool_0(const char *to_hex, const uint8_t sel4[4], bool *out_true)
int vabi_call_u16_0(const char *to_hex, const uint8_t sel4[4], uint16_t *out_u16)
int vabi_call_u32_0(const char *to_hex, const uint8_t sel4[4], uint32_t *out_u32)
int vabi_call_u64_0_from_u256(const char *to_hex, const uint8_t sel4[4], uint64_t *out_low64)
```
Call view functions with 0 arguments and decode single return values.

---

## Contract-Specific Selectors

### VSM (Validator State Module) Selectors

```c
const uint8_t VSM_SEL_batchExecuted[4]       = {0x23,0x14,0xbf,0x23}; // batchExecuted(uint64) -> bool
const uint8_t VSM_SEL_executedMask[4]        = {0x4f,0x05,0xc1,0xdf}; // executedMask(uint64) -> uint64
const uint8_t VSM_SEL_backupAfterSec[4]      = {0x96,0xc3,0xed,0x27}; // backupAfterSec() -> uint64
const uint8_t VSM_SEL_breakGlassAfterSec[4]  = {0x44,0x5a,0xcb,0x25}; // breakGlassAfterSec() -> uint64
```

### VWR (Validator Weight Reader) Selectors

```c
const uint8_t VWR_SEL_weightsOfPrimary[4]    = {...}; // weightsOfPrimary(address,uint32,address[]) -> uint64[]
const uint8_t VWR_SEL_weightsOfBackup[4]     = {...}; // weightsOfBackup(address,uint32,address[]) -> uint64[]
```

---

## VSM (Validator State Module) Functions

```c
int vsm_batch_executed(const char *vsm_hex, uint64_t batch_id, bool *out_executed)
```
Check if a batch has been executed on Ethereum.

```c
int vsm_executed_mask(const char *vsm_hex, uint64_t batch_id, uint64_t *out_mask)
```
Get the execution mask for a batch (which validators signed).

```c
int vsm_backup_after_sec(const char *vsm_hex, uint64_t *out_sec)
int vsm_break_glass_after_sec(const char *vsm_hex, uint64_t *out_sec)
```
Get timeout parameters for backup/emergency procedures.

---

## VWR (Validator Weight Reader) Functions

```c
int vwr_weights_of_primary(
    const char *reader_hex,
    const char *module_hex,
    uint32_t epoch,
    const char **addr_list_hex,
    int addr_count,
    uint64_t *out_weights)
```
Get primary validator weights for a given epoch.

```c
int vwr_weights_of_backup(
    const char *reader_hex,
    const char *module_hex,
    uint32_t epoch,
    const char **addr_list_hex,
    int addr_count,
    uint64_t *out_weights)
```
Get backup validator weights for a given epoch.

---

## Usage Examples

### Building a Simple Call

```c
vabi_buf_t ab;
vabi_init(&ab, 64);

// Push 4-byte selector
vabi_push_selector(VSM_SEL_batchExecuted, &ab);

// Push uint64 argument
vabi_push_u256_from_u64(batch_id, &ab);

// Make the call
char result[256];
vabi_eth_call_hex_result(vsm_address, ab.data, ab.len, result, sizeof(result));

// Decode result
bool executed;
vabi_result_bool_at(result, 0, &executed);

vabi_free(&ab);
```

### Decoding Dynamic Array Return

```c
// Result format for uint64[]:
// Word 0: offset to array data (always 0x20 for single return)
// Word 1: array length (n)
// Words 2..n+1: array elements

uint64_t weights[MAX_VALIDATORS];
int count;
vwr_weights_of_primary(reader, module, epoch, addrs, addr_count, weights);
```

---

## Error Codes

All functions return:
- `0` on success
- Negative values on error:
  - `-1`: Invalid parameters
  - `-2`: Memory allocation failed
  - `-3`: Hex conversion error
  - `-4`: RPC call failed
  - `-5`: ABI encoding error
  - `-6`: Result parsing error

---

## Integration Points

### Dependencies
- `bridge.h` - Common bridge definitions
- `ethrpc.c` - JSON-RPC communication with Ethereum nodes

### Used By
- `bridge_deposit.c` - Deposit verification
- `bridge_withdraw.c` - Withdrawal execution
- `bridge.c` - Main bridge coordination

---

## Security Considerations

1. **Input Validation**: All functions validate inputs before processing
2. **Buffer Overflow Protection**: `vabi_ensure()` prevents buffer overflows
3. **Hex Parsing**: Strict validation of hex characters
4. **Memory Management**: Consistent init/free pattern prevents leaks

---

## Notes

- All addresses are 20 bytes (Ethereum format)
- All numeric values are big-endian in ABI encoding
- Function selectors are first 4 bytes of keccak256(function_signature)
- Dynamic types use offset-based encoding per Solidity ABI spec
