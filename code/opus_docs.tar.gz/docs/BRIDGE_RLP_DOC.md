# bridge_rlp.c Documentation

## Overview

**File**: `/root/valis/bridge/bridge_rlp.c`  
**Lines**: 970  
**Purpose**: Recursive Length Prefix (RLP) encoding/decoding for Ethereum bridge operations  
**Dependencies**: `_valis.h`, `bridge.h`  
**Documented by**: Opus (Wake 1278)

---

## What is RLP?

RLP (Recursive Length Prefix) is Ethereum's canonical serialization format. It encodes:
- **Strings** (arbitrary byte sequences)
- **Lists** (nested structures of strings and lists)

RLP is used for:
- Transaction encoding
- Receipt encoding
- Merkle Patricia Trie nodes
- All Ethereum wire protocol messages

This file provides Tockchain's implementation for bridging with Ethereum.

---

## RLP Encoding Rules (Reference)

| Byte Range | Meaning |
|------------|---------|
| `0x00-0x7f` | Single byte, no prefix needed |
| `0x80-0xb7` | Short string (0-55 bytes): `0x80 + len` |
| `0xb8-0xbf` | Long string (>55 bytes): `0xb7 + len_of_len`, then length bytes |
| `0xc0-0xf7` | Short list (0-55 bytes payload): `0xc0 + payload_len` |
| `0xf8-0xff` | Long list (>55 bytes payload): `0xf7 + len_of_len`, then length bytes |

---

## Constants

```c
#define RLP_SINGLE_MAX        0x7fU   // Single byte, no prefix
#define RLP_SHORT_STRING_BASE 0x80U   // Short string header base
#define RLP_LONG_STRING_BASE  0xb7U   // Long string header base
#define RLP_SHORT_LIST_BASE   0xc0U   // Short list header base
#define RLP_LONG_LIST_BASE    0xf7U   // Long list header base
```

---

## Core Data Structures

### `struct rlp_item`
```c
struct rlp_item {
    const uint8_t *data;  // Pointer to payload data
    int32_t len;          // Length of payload
    int is_list;          // 1 if list, 0 if string
};
```

Used for zero-copy parsing - points directly into input buffer.

---

## Function Reference

### Length Calculators

These functions calculate the encoded length WITHOUT actually encoding. Essential for buffer allocation.

#### `rlp_calc_len_bytes(src, len)`
```c
int rlp_calc_len_bytes(const uint8_t *src, int len);
```
- **Purpose**: Calculate RLP length for a byte string
- **Special case**: Single byte ≤ 0x7f encodes as itself (length 1)
- **Returns**: Total encoded length including header

#### `rlp_calc_len_list(payload_len)`
```c
int rlp_calc_len_list(int payload_len);
```
- **Purpose**: Calculate RLP length for a list given its payload length
- **Input**: Sum of encoded lengths of all list items
- **Returns**: Total encoded length including header

#### `rlp_calc_len_uint64(v)`
```c
int rlp_calc_len_uint64(uint64_t v);
```
- **Purpose**: Calculate minimal RLP length for a 64-bit unsigned integer
- **Special case**: Zero encodes as `0x80` (empty string)
- **Returns**: Encoded length

#### `rlp_calc_len_address(addr20, is_null)`
```c
int rlp_calc_len_address(const uint8_t addr20[20], int is_null);
```
- **Purpose**: Calculate RLP length for Ethereum address
- **is_null**: If true, returns 1 (empty string for contract creation)
- **Returns**: 1 if null, otherwise length for 20-byte string

#### `rlp_calc_len_u256_be32(be32)`
```c
int rlp_calc_len_u256_be32(const uint8_t be32[32]);
```
- **Purpose**: Calculate RLP length for 256-bit integer (big-endian)
- **Behavior**: Trims leading zeros for minimal encoding
- **Returns**: Encoded length

---

### Writers

These functions write RLP-encoded data to a buffer. All return pointer past written data.

#### `rlp_write_bytes(dst, src, len)`
```c
uint8_t *rlp_write_bytes(uint8_t *dst, const uint8_t *src, int len);
```
- **Purpose**: Write RLP-encoded byte string
- **Returns**: Pointer past written data

#### `rlp_write_list(dst, payload_len)`
```c
uint8_t *rlp_write_list(uint8_t *dst, int payload_len);
```
- **Purpose**: Write RLP list header only (not contents)
- **Usage**: Write header, then write each item's encoded form
- **Returns**: Pointer past header

#### `rlp_write_uint64(dst, v)`
```c
uint8_t *rlp_write_uint64(uint8_t *dst, uint64_t v);
```
- **Purpose**: Write minimal RLP encoding of 64-bit integer
- **Returns**: Pointer past written data

#### `rlp_write_address(dst, addr20, is_null)`
```c
uint8_t *rlp_write_address(uint8_t *dst, const uint8_t addr20[20], int is_null);
```
- **Purpose**: Write RLP-encoded Ethereum address
- **is_null**: If true, writes `0x80` (empty string)
- **Returns**: Pointer past written data

#### `rlp_write_u256_be32(dst, be32)`
```c
uint8_t *rlp_write_u256_be32(uint8_t *dst, const uint8_t be32[32]);
```
- **Purpose**: Write RLP-encoded 256-bit integer with leading zero trimming
- **Returns**: Pointer past written data

---

### Parsers

Zero-copy parsing functions that point into the input buffer.

#### `parse_rlp(input, input_len, item)`
```c
int32_t parse_rlp(const uint8_t *input, int32_t input_len, struct rlp_item *item);
```
- **Purpose**: Parse one RLP item from input
- **Output**: Fills `item` with data pointer, length, and is_list flag
- **Returns**: Number of bytes consumed, or negative on error

#### `rlp_list_count(list)`
```c
int32_t rlp_list_count(const struct rlp_item *list);
```
- **Purpose**: Count items in an RLP list
- **Precondition**: `list->is_list` must be true
- **Returns**: Number of items, or negative on error

#### `rlp_get_item(list, idx, out)`
```c
int32_t rlp_get_item(const struct rlp_item *list, int32_t idx, struct rlp_item *out);
```
- **Purpose**: Get item at index from RLP list
- **Returns**: Bytes consumed for that item, or negative on error

---

### Ethereum Bridge Functions

#### `eth_mpt_proof_get_typed_receipt(proof, typed, tlen)`
```c
int32_t eth_mpt_proof_get_typed_receipt(const struct eth_mpt_proof *proof, 
                                         const uint8_t **typed, int32_t *tlen);
```
- **Purpose**: Extract typed receipt from validated MPT proof
- **Context**: Used to get receipt data from Ethereum inclusion proofs
- **Output**: Sets `typed` to point at receipt bytes, `tlen` to length
- **Returns**: 0 on success, negative error codes on failure

#### `get_event_sigs(dep, tr)`
```c
void get_event_sigs(uint8_t dep[32], uint8_t tr[32]);
```
- **Purpose**: Get cached Keccak256 hashes of event signatures
- **Events**:
  - `Deposit(address,address,bytes32,uint256,uint256,uint256)`
  - `Transfer(address,address,uint256)`
- **Behavior**: Computes once, caches for subsequent calls

#### `eth_mpt_tmpmem_upper_bound(p, out_value_len, out_required_bytes)`
```c
int32_t eth_mpt_tmpmem_upper_bound(const struct eth_mpt_proof *p,
                                   int32_t *out_value_len,
                                   int64_t *out_required_bytes);
```
- **Purpose**: Calculate memory requirements for MPT proof verification
- **Output**: Sets `out_value_len` to receipt length, `out_required_bytes` to temp memory needed
- **Returns**: 0 on success

#### `eth_bridge_plan_memory_for_proof(...)`
```c
int32_t eth_bridge_plan_memory_for_proof(const struct eth_mpt_proof *p,
                                         int64_t *out_tmpmem_bytes,
                                         int32_t *out_deposit_n,
                                         int32_t *out_transfer_n,
                                         int64_t *out_arrays_bytes);
```
- **Purpose**: Plan memory allocation for processing bridge proof
- **Output**: Temp memory needed, number of deposits, number of transfers, array space needed
- **Returns**: 0 on success

---

### Utility Functions

#### `be_right_copy_hex(out32, contractaddr)`
```c
void be_right_copy_hex(uint8_t out32[32], char *contractaddr);
```
- **Purpose**: Copy hex address into right-aligned 32-byte buffer
- **Handles**: Optional "0x" prefix
- **Usage**: Converting Ethereum addresses to 32-byte format

#### `rlp_item_addr20(it, out20)`
```c
void rlp_item_addr20(const struct rlp_item *it, uint8_t out20[20]);
```
- **Purpose**: Extract 20-byte address from RLP item
- **Handles**: Both 20-byte and 32-byte (right-padded) formats

#### `rlp_encode_hash(mem, hash, out, outlen)`
```c
int32_t rlp_encode_hash(tmpmem_t *mem, const uint8_t hash[32], 
                        uint8_t **out, int32_t *outlen);
```
- **Purpose**: RLP-encode a 32-byte hash
- **Output**: Always `0xa0` prefix + 32 bytes (33 bytes total)
- **Memory**: Uses `tmp_alloc` for allocation

---

### Back-Compatibility Wrappers

These preserve older API names:

| Old Name | Maps To |
|----------|---------|
| `rlp_len_bytes(len)` | `rlp_calc_len_bytes(dummy, len)` |
| `rlp_len_uint64(v)` | `rlp_calc_len_uint64(v)` |
| `rlp_len_address(a, null)` | `rlp_calc_len_address(a, null)` |
| `rlp_len_u256(be32)` | `rlp_calc_len_u256_be32(be32)` |
| `rlp_len_data(len)` | `rlp_calc_len_data(NULL, len)` |
| `rlp_write_u256(dst, be32)` | `rlp_write_u256_be32(dst, be32)` |

---

## Usage Patterns

### Encoding a Transaction

```c
// 1. Calculate total length
int nonce_len = rlp_calc_len_uint64(nonce);
int gas_len = rlp_calc_len_uint64(gas);
int to_len = rlp_calc_len_address(to_addr, 0);
int value_len = rlp_calc_len_u256_be32(value);
int data_len = rlp_calc_len_data(input, input_len);

int payload = nonce_len + gas_len + to_len + value_len + data_len;
int total = rlp_calc_len_list(payload);

// 2. Allocate buffer
uint8_t *buf = malloc(total);
uint8_t *p = buf;

// 3. Write list header, then items
p = rlp_write_list(p, payload);
p = rlp_write_uint64(p, nonce);
p = rlp_write_uint64(p, gas);
p = rlp_write_address(p, to_addr, 0);
p = rlp_write_u256_be32(p, value);
p = rlp_write_bytes(p, input, input_len);
```

### Parsing a Receipt

```c
struct rlp_item receipt;
int consumed = parse_rlp(data, len, &receipt);
if (consumed > 0 && receipt.is_list) {
    int count = rlp_list_count(&receipt);
    
    struct rlp_item status;
    rlp_get_item(&receipt, 0, &status);
    // status.data, status.len now point to status field
}
```

---

## Error Codes

Most functions return negative values on error:
- `-1`: Invalid input (NULL pointers, negative lengths)
- `-2` to `-11`: Specific parsing/validation failures in MPT functions

---

## Security Considerations

1. **Zero-copy parsing**: `rlp_item.data` points into original buffer - don't free input while using parsed items
2. **Length validation**: All parsers validate lengths before accessing data
3. **Minimal encoding**: Writers produce canonical (minimal) encodings
4. **No dynamic allocation**: Core encode/decode functions don't allocate - caller manages buffers

---

## Relationship to Other Bridge Files

- **bridge_mpt.c**: Uses RLP parsing for Merkle Patricia Trie verification
- **bridge_abi.c**: Uses RLP for ABI encoding/decoding
- **bridge_deposit.c**: Uses RLP to parse deposit events
- **bridge_withdraw.c**: Uses RLP to encode withdrawal proofs

---

*Documentation generated Wake 1278 | Opus*
