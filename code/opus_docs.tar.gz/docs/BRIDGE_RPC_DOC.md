# Bridge RPC Module Documentation

**File:** `/root/valis/bridge/bridge_rpc.c` and `bridge_rpc.h`  
**Lines:** 712 (implementation) + ~150 (header)  
**Purpose:** Ethereum JSON-RPC client for blockchain communication  
**Documented by:** Opus (Wake 1288)  
**Status:** Complete

---

## Overview

The Bridge RPC module provides a complete JSON-RPC client implementation for communicating with Ethereum nodes. It handles:

1. **Parameter construction** - Type-safe building of RPC parameters
2. **JSON serialization** - Converting parameters to JSON-RPC format
3. **HTTP transport** - Making HTTP POST requests via libcurl
4. **Async operations** - Non-blocking RPC calls with callbacks

This is the communication layer between Tockchain and Ethereum - every deposit verification, withdrawal proof, and state query flows through this module.

---

## Dependencies

```c
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <curl/curl.h>
#include "_valis.h"
#include "bridge.h"
#include "bridge_rpc.h"
```

**External Libraries:**
- `libcurl` - HTTP client
- `pthread` - Threading for async operations
- `yyjson` - JSON serialization (via bridge_rpc.h)

---

## Data Structures (from bridge_rpc.h)

### RPC Value Types

```c
typedef enum rpc_type_e
{
    RPCV_NULL = 0,          // JSON null
    RPCV_BOOL = 1,          // JSON boolean
    RPCV_STR  = 2,          // Literal JSON string
    RPCV_HEXBYTES = 3,      // Raw bytes → "0x..." hex string
    RPCV_QUANTITY_U64 = 4,  // u64 → "0x..." quantity (minimal)
    RPCV_OBJECT = 5,        // JSON object
    RPCV_ARRAY  = 6,        // JSON array
    RPCV_HEXSTR = 7,        // Already-encoded hex string
    RPCV_U256_BE = 8,       // Big-endian bytes → minimal "0x..."
    RPCV_U256_LE = 9,       // Little-endian bytes → minimal "0x..."
    RPCV_NUMBER_U64 = 10,   // Plain number (not hex)
} rpc_type_t;
```

### RPC Value Union

```c
typedef struct rpc_value_s
{
    rpc_type_t t;           // Type discriminator
    union {
        const char *s;                          // String value
        struct { const uint8_t *p; uint32_t n; } bytes;  // Byte array
        uint64_t u64;                           // 64-bit integer
        uint8_t b;                              // Boolean
        struct rpc_object_s *obj;               // Object pointer
        struct rpc_array_s  *arr;               // Array pointer
    } v;
} rpc_value_t;
```

### Curl Parameters Container

```c
typedef struct curl_params_s
{
    const char   *url;                    // Optional URL override
    rpc_value_t   params[RPC_MAX_PARAMS]; // Up to 16 parameters
    uint8_t       params_n;               // Parameter count
    rpc_object_t  objects[RPC_MAX_OBJECTS]; // Object storage
    uint8_t       objects_n;
    rpc_array_t   arrays[RPC_MAX_ARRAYS];   // Array storage
    uint8_t       arrays_n;
} curl_params_t;
```

**Design Note:** Fixed-size arrays (16 elements max) avoid dynamic allocation at call sites. This is intentional - RPC calls don't need unbounded parameter counts.

---

## Key Functions

### Default RPC Endpoint Selection

```c
void valis_config_assign_default_ethrpc(char ethrpc[256])
```

**Purpose:** Randomly selects from a pool of public Ethereum RPC endpoints.

**Endpoints Pool (14 options):**
- ethereum.publicnode.com
- 1rpc.io/eth
- eth.llamarpc.com
- ethereum.public.blockpi.network
- eth.drpc.org
- rpc.mevblocker.io
- And 8 more...

**Why Random?** Load distribution across public endpoints, avoiding rate limits on any single provider.

---

### Parameter Building Functions

#### Object Operations

```c
int32_t rpc_obj_put_kv(rpc_object_t *o, const char *key, rpc_value_t val)
```
Adds a key-value pair to an RPC object. Returns 0 on success, negative on error.

```c
int32_t rpc_obj_put_u64(rpc_object_t *o, const char *key, uint64_t u)
```
Convenience wrapper for adding uint64 values.

#### Array Operations

```c
int32_t rpc_arr_push(rpc_array_t *a, rpc_value_t val)
```
Pushes a value onto an RPC array.

#### Value Constructors (Inline in Header)

```c
rpc_value_t rpcv_null(void)                           // NULL value
rpc_value_t rpcv_bool(bool b)                         // Boolean
rpc_value_t rpcv_str(const char *s)                   // String
rpc_value_t rpcv_hexstr(const char *s)                // Hex string
rpc_value_t rpcv_hexbytes(const uint8_t *p, uint32_t n) // Bytes → hex
rpc_value_t rpcv_quantity_u64(uint64_t u)             // U64 → "0x..."
rpc_value_t rpcv_u256_be(const uint8_t *be, uint32_t n) // Big-endian
rpc_value_t rpcv_u256_le(const uint8_t *le, uint32_t n) // Little-endian
rpc_value_t rpcv_number_u64(uint64_t u)               // Plain number
rpc_value_t rpcv_object(rpc_object_t *o)              // Object ref
rpc_value_t rpcv_array(rpc_array_t *a)                // Array ref
```

---

### Hex Encoding

```c
static int32_t be_bytes_to_minimal_0x(char *dst, int32_t dst_cap, 
                                       const uint8_t *be, uint32_t n)
```

**Purpose:** Converts big-endian bytes to minimal "0x" quantity format.

**Ethereum Quantity Format:**
- Leading zeros stripped (except for zero itself)
- "0x0" for zero value
- "0x1a" not "0x001a"

**Example:**
- `[0x00, 0x00, 0x1a]` → `"0x1a"`
- `[0x00, 0x00, 0x00]` → `"0x0"`

---

### JSON Serialization

```c
static yyjson_mut_val *emit_value(yyjson_mut_doc *doc, const rpc_value_t *v)
```

**Purpose:** Recursively converts rpc_value_t to yyjson mutable value.

**Type Handling:**
- `RPCV_NULL` → JSON null
- `RPCV_BOOL` → JSON boolean
- `RPCV_STR` → JSON string (as-is)
- `RPCV_HEXSTR` → JSON string (adds "0x" prefix if missing)
- `RPCV_HEXBYTES` → JSON string ("0x" + hex encoding)
- `RPCV_QUANTITY_U64` → JSON string (minimal "0x" format)
- `RPCV_U256_BE/LE` → JSON string (minimal "0x" format)
- `RPCV_NUMBER_U64` → JSON number
- `RPCV_OBJECT` → JSON object (recursive)
- `RPCV_ARRAY` → JSON array (recursive)

```c
int32_t bridge_rpc_build_params_json(const curl_params_t *P, 
                                      char *out, int32_t out_cap)
```

**Purpose:** Builds the JSON array of parameters for an RPC call.

**Output:** JSON array string like `["0x1234", {"from": "0xabc"}, "latest"]`

---

### HTTP Transport

```c
int32_t rpc_http_run(CURL *curl, const char *url, const char *method,
                     const char *content_type, const char *body, 
                     int32_t body_len, char *out, int32_t out_cap,
                     int32_t timeout_sec)
```

**Purpose:** Executes HTTP request (GET or POST).

**Features:**
- Automatic GET/POST detection based on body presence
- Custom headers support
- Response buffering with dynamic reallocation
- Timeout handling
- SSL verification for HTTPS

**Internal Buffer:**
```c
typedef struct br_buffer_s {
    char *data;
    size_t size;
} br_buffer_t;
```

**Callback:**
```c
static size_t br_write_cb(void *contents, size_t size, size_t nmemb, void *userp)
```
Standard libcurl write callback that accumulates response data.

---

### Async RPC Operations

```c
typedef struct bridge_rpc_async_s
{
    char *url;
    char *body;
    int32_t timeout_sec;
    bridge_rpc_cb cb;           // Callback function
    void *userdata;             // User context
    pthread_t th;               // Thread handle
    volatile int32_t cancel_flag;
} bridge_rpc_async_t;
```

**Thread Function:**
```c
static void *br_async_thread(void *arg)
```

**Purpose:** Runs RPC call in background thread, invokes callback on completion.

**Cancellation:**
```c
static int br_xferinfo(void *clientp, curl_off_t dltotal, curl_off_t dlnow,
                       curl_off_t ultotal, curl_off_t ulnow)
```
Progress callback that checks cancel_flag, allowing graceful cancellation of in-flight requests.

**Body Builder:**
```c
static int32_t br_build_body_from_params(const char *method, 
                                          const curl_params_t *P,
                                          char *out, int32_t out_cap)
```
Constructs complete JSON-RPC request body:
```json
{"jsonrpc":"2.0","method":"eth_call","params":[...],"id":1}
```

---

## Usage Patterns

### Simple eth_call

```c
curl_params_t P = {0};
rpc_object_t *call_obj = &P.objects[P.objects_n++];

// Build call object
rpc_obj_put_kv(call_obj, "to", rpcv_hexstr("0x1234..."));
rpc_obj_put_kv(call_obj, "data", rpcv_hexbytes(calldata, calldata_len));

// Add parameters
P.params[P.params_n++] = rpcv_object(call_obj);
P.params[P.params_n++] = rpcv_str("latest");

// Build and send
char body[4096];
br_build_body_from_params("eth_call", &P, body, sizeof(body));
// ... send via rpc_http_run
```

### Block Number Query

```c
curl_params_t P = {0};
// eth_blockNumber takes no params
char body[256];
br_build_body_from_params("eth_blockNumber", &P, body, sizeof(body));
// Result: {"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}
```

---

## Constants

```c
#define RPC_MAX_PARAMS        16    // Max parameters per call
#define RPC_MAX_OBJECTS       16    // Max nested objects
#define RPC_MAX_ARRAYS        16    // Max nested arrays
#define RPC_MAX_FIELDS        16    // Max fields per object
#define RPC_MAX_ARRAY_ELEMS   16    // Max elements per array

#define ETHRPC_HTTP_TIMEOUT_SEC  30  // Default timeout
#define ETHRPC_HTTP_CONNECT_SEC  10  // Connection timeout
#define ETHRPC_USER_AGENT "valis/1.0"
```

---

## Error Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| -1 | Invalid parameters |
| -2 | JSON document creation failed |
| -3 | Value emission failed |
| -4 | JSON write failed |
| -5 | Output buffer too small |
| -50 | Object put: null object or key |
| -51 | Object put: max fields exceeded |
| -52 | Array push: null array |
| -53 | Array push: max elements exceeded |

---

## Integration Points

**Used By:**
- `bridge_deposit.c` - Verifying deposits via eth_getProof
- `bridge_withdraw.c` - Submitting withdrawal proofs
- `bridge_prices.c` - Fetching token prices
- `bridge.c` - General Ethereum queries

**Depends On:**
- `yyjson` - JSON serialization
- `libcurl` - HTTP transport
- `_valis.h` - Configuration (ethrpc endpoint)

---

## Security Considerations

1. **SSL Verification** - Enabled for HTTPS endpoints
2. **Timeout Limits** - Prevents hanging on unresponsive nodes
3. **Buffer Bounds** - Fixed-size arrays prevent overflow
4. **No Credential Storage** - RPC endpoints are public, no auth needed

---

## Performance Notes

1. **Zero-Allocation Design** - Parameter building uses stack-allocated structures
2. **Connection Reuse** - CURL handle can be reused across calls
3. **Async Support** - Long-running calls don't block main thread
4. **Endpoint Rotation** - Random selection distributes load

---

## Related Files

- `bridge_rpc.h` - Type definitions and inline constructors
- `bridge.h` - Bridge configuration including ethrpc endpoint
- `yyjson.h` - JSON library interface
