# valis_math.c - Mathematical Utilities

## Overview

**Location:** `/root/valis/utils/valis_math.c`  
**Lines:** ~1216  
**Purpose:** Provides safe arithmetic operations, arbitrary-precision conversions, AMM swap calculations, and fixed-point math utilities.

This file is critical for preventing overflow/underflow in financial calculations and for converting between different numeric representations (satoshis, hex strings, big-endian uint256, fixed-point Q32).

---

## Key Design Principles

1. **Overflow Protection:** All arithmetic uses safe wrappers that detect and report overflow
2. **Arbitrary Precision:** Uses GMP (GNU Multiple Precision) for conversions involving uint256
3. **Portable 128-bit Math:** Software implementation for platforms without native 128-bit support
4. **Fixed-Point Q32:** Uses 32-bit fixed-point representation for fractional values (0.0 to ~1.0)

---

## Core Arithmetic Functions

### `portable_mul128(uint64_t a, uint64_t b, uint64_t res[2])`
Multiplies two 64-bit values, producing a 128-bit result.

**Implementation:** Uses the standard 4-part multiplication:
- Split each operand into high/low 32-bit halves
- Compute al*bl, ah*bl, al*bh, ah*bh
- Combine with proper carry handling
- Result: res[0] = low 64 bits, res[1] = high 64 bits

**Returns:** Always 0 (success)

### `portable_div128(uint64_t num[2], uint64_t den, uint64_t *q, uint64_t *rem)`
Divides a 128-bit number by a 64-bit divisor.

**Algorithm:** Bit-by-bit long division (127 iterations)
- Shifts remainder left, adds next bit from numerator
- Subtracts divisor when remainder >= divisor

**Returns:**
- 0: Success
- -1: Division by zero or result exceeds MAXCOINSUPPLY

### `safe_mul_div(int64_t a, int64_t b, int64_t c, int round_flag, int64_t div0_err)`
Computes `(a * b) / c` with overflow protection.

**Delegates to:** `safe_mul_then_div()` from frama_verified.c

---

## Hex/Binary Conversion Functions

### `hex_to_be32(const char *hex, uint8_t out_be32[32])`
Converts hex string to 32-byte big-endian array.

**Features:**
- Handles optional "0x" prefix
- Supports odd-length hex strings (implicit leading zero)
- Left-pads result to 32 bytes

**Returns:**
- 0: Success
- -1: NULL input
- -2: Hex string too long (>64 chars)
- -4: Invalid hex character

### `be32_to_63bit_with_8decimals(uint8_t be32[32], int32_t decimals, int32_t scaling_factor_decimals, int64_t *result)`
Converts 32-byte big-endian uint256 to int64 with decimal scaling.

**Purpose:** Convert Ethereum token amounts (uint256) to Valis satoshi representation (int64 with 8 decimals).

**Calculation:**
```
net = 8 - decimals - scaling_factor_decimals
if net > 0: result = value / 10^net
if net < 0: result = value * 10^(-net)
```

**Returns:**
- 0: Success
- -1: NULL input
- -2: Result exceeds 64 bits

### `hex_to_63bit_with_8decimals(const char *hex_str, uint8_t decimals, uint8_t scaling_factor_decimals, int64_t *result)`
Same as above but takes hex string input instead of binary.

### `int63_to_be32_scaled(int64_t value, uint8_t decimals, uint8_t scaling_factor_decimals, uint8_t out_be32[32])`
Inverse operation: converts int64 satoshi value to 32-byte big-endian uint256.

**Purpose:** Convert Valis amounts back to Ethereum format for bridge operations.

---

## Bit Manipulation

### `bitweight64(uint64_t bits64, int32_t max)`
Counts set bits in a 64-bit value up to position `max`.

### `bitweight(uint8_t *ptr, int32_t max)`
Counts set bits in a byte array up to position `max`.

Uses `GETBIT()` macro for individual bit access.

---

## AMM Swap Calculations

### `swapcalc(int64_t amount, int64_t srcbalance, int64_t destbalance)`
Calculates output amount for a constant-product AMM swap.

**Formula:** Based on `x * y = k` invariant:
```
dest_after = (srcbalance * destbalance) / (srcbalance + amount)
dy = destbalance - dest_after - 1  // -1 for rounding protection
```

**Guards:**
- Returns 0 if destbalance <= MINPOOL_SATOSHIS
- Returns 0 if result would leave pool below MINPOOL_SATOSHIS
- Subtracts 1 from positive results for conservative rounding

### `oldswapcalc(int32_t swaptype, int64_t amount, int64_t srcbalance, int64_t destbalance, int64_t poolshares)`
Legacy swap calculation with additional parameters (swaptype, poolshares unused).

**Additional logic:**
- Rejects tiny swaps that would round to zero
- Has debug printf for rejected swaps (1/1000 probability)

---

## Fixed-Point Q32 Arithmetic

Uses Q32 format: 32-bit unsigned where full scale (0xFFFFFFFF) ≈ 1.0

### Constants
```c
#define Q32_SHIFT           32
#define Q32_FRAC_MASK       0xFFFFFFFFu
#define Q32_ONE_MINUS_EPS   0xFFFFFFFFu  // ~0.9999999997671694
#define Q32_TARGET_099      4252017623u  // round(0.99 * 2^32)
```

### `ema_q32_update(uint32_t ema_q32, uint32_t decay_q32, uint32_t new_value_q32)`
Updates an exponential moving average in Q32 format.

**Formula:**
```
next = ema - (ema * decay) + (new_value * decay)
     = ema * (1 - decay) + new_value * decay
```

**Use case:** Smoothing price feeds, rate limiting.

### `q32_to_satoshis(uint32_t q32_value)`
Converts Q32 fraction to satoshi amount.

**Formula:** `satoshis = (q32 * SATOSHIS + 2^31) >> 32`

Clamps result to SATOSHIS maximum.

### `satoshis_to_q32(uint64_t satoshi_value)`
Converts satoshi amount to Q32 fraction.

**Formula:** `q32 = (satoshis << 32) / SATOSHIS`

Clamps input to SATOSHIS maximum.

### `ema_percent_of_target(uint64_t target_satoshis, uint32_t ema_q32)`
Calculates what percentage of target the EMA represents.

**Returns:** 0-100 (percentage), or 0xFF if target is 0 and EMA is non-zero.

---

## Transaction ID Utilities

### `get_txidbits16(uint8_t txid[32])`
Extracts a 16-bit identifier from a transaction ID.

**Algorithm:** Scans first 16 bytes in pairs, returns first non-zero 16-bit value (right-shifted by 1).

**Use case:** Quick transaction lookup/indexing.

---

## Dependencies

- `sha256.h`: SHA-256 hashing (Sha256_Onestep)
- `_valis.h`: Core definitions (SATOSHIS, MAXCOINSUPPLY, GETBIT)
- `frama_verified.h`: Formally verified safe arithmetic
- GMP library: Arbitrary precision arithmetic (mpz_* functions)

---

## Error Handling Pattern

Most functions return:
- 0: Success
- Negative values: Specific error codes
- Functions that return computed values use special sentinel values (e.g., -1, -2, -3) to indicate errors

The `safe_*` functions propagate errors through the call chain, allowing callers to detect overflow/underflow without explicit checks at each step.

---

## Security Considerations

1. **Overflow Protection:** All financial calculations use safe wrappers
2. **Division by Zero:** Explicitly checked before all divisions
3. **Precision Loss:** Documented and handled (rounding toward zero for safety)
4. **Input Validation:** NULL checks on all pointer parameters
5. **Range Limits:** Results checked against MAXCOINSUPPLY to prevent economic attacks

---

## Related Files

- `frama_verified.c`: Formally verified arithmetic primitives
- `valis_hash.c`: Hashing utilities
- `bridge_abi.c`: Uses these functions for Ethereum value conversions
