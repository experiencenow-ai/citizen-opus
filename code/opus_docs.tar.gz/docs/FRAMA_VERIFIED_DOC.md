# frama_verified.c Documentation

## Overview

**File**: `/root/valis/frama_verified.c`  
**Lines**: 1,448  
**Purpose**: Formally verified pure functions for Tockchain's critical operations  
**Verification**: 950/955 goals proved (99.5%) by Frama-C  
**Documented by**: Opus (Wake 1278)

---

## What is Formal Verification?

This file contains functions verified using **Frama-C** with the **WP (Weakest Precondition)** plugin. Each function has:
- **ACSL annotations** (`/*@ ... */`) specifying preconditions, postconditions, and invariants
- **Mathematical proofs** that the code satisfies these specifications
- **Runtime error checking** (no buffer overflows, no integer overflows, no division by zero)

To verify: `frama-c -wp -wp-rte frama_verified.c`

---

## Why This Matters

These functions handle:
- **Money calculations** (swap amounts, prices, balances)
- **Consensus math** (quorum calculations, validator selection)
- **Security-critical operations** (bounds checking, input validation)

A bug in any of these could mean lost funds or consensus failures. Formal verification provides mathematical certainty that the code is correct.

---

## Section Overview

| Section | Purpose |
|---------|---------|
| 1 | Safe Arithmetic (overflow-protected) |
| 2 | UFC Conversions |
| 3 | UFC Weight/Decay |
| 4 | UFC Price Clamping |
| 5 | UFC Pool Balances |
| 6 | UFC OOB Calculations |
| 7 | UFC Leg Calculations |
| 8 | UFC Virtual Price Targets |
| 9 | UFC Swap Outputs |
| 10 | UFC Premium Calculation |
| 11 | UFC Tranche Splitting |
| 12 | UFC Sure Cap |
| 13 | Ledger Address/Pubkey Functions |
| 14 | Ledger Asset Identification |
| 15 | Ledger Balance Validation |
| 16 | VBPF Bounds Checking |
| 17 | VBPF Z-Curve |
| 18 | VBPF Bloom Filter (trusted) |
| 19 | VBPF Math Helpers |
| 20 | VBPF Gas |
| 21 | Pylon Constant-Time Comparison |
| 22 | Safe Division |
| 23 | Price Calculation |
| 24 | Quorum Calculation |
| 25 | UFC Stale Price Movement |
| 26 | Bitweight (Popcount) |
| 27 | Murmur-Inspired Hash |

---

## Key Functions

### Section 1: Safe Arithmetic

#### `safe_mul_then_div(a, b, c, div0_err)`
```c
int64_t safe_mul_then_div(int64_t a, int64_t b, int64_t c, int64_t div0_err);
```
- **Purpose**: Compute `(a * b + c/2) / c` with 128-bit intermediate precision
- **Guarantees**: No overflow, handles division by zero
- **Returns**: Result, or `div0_err` if `c == 0`
- **Note**: Uses `__int128` internally (not verified by Frama-C, but trusted)

#### `ufc_mul_div_floor(a, b, c)`
```c
int64_t ufc_mul_div_floor(int64_t a, int64_t b, int64_t c);
```
- **Purpose**: Compute `floor(a * b / c)` safely
- **Guarantees**: Returns 0 for invalid inputs, caps at MAXCOINSUPPLY

#### `ufc_mul_div_ceil(a, b, c)`
```c
int64_t ufc_mul_div_ceil(int64_t a, int64_t b, int64_t c);
```
- **Purpose**: Compute `ceil(a * b / c)` safely
- **Guarantees**: Same as floor version but rounds up

---

### Section 4: UFC Price Clamping

#### `ufc_clamp_price_move_pure(prev_px, cand_px, out_clamp_bps)`
```c
int64_t ufc_clamp_price_move_pure(int64_t prev_px, int64_t cand_px, int32_t *out_clamp_bps);
```
- **Purpose**: Limit price movement to ±UFC_MAX_MOVE_BPS per update
- **Prevents**: Flash loan attacks, price manipulation
- **Returns**: Clamped price, optionally sets `out_clamp_bps` to direction

---

### Section 5: UFC Pool Balances

#### `pool_effective_balances_pure(pool_vusd, pool_other, eff_vusd_ptr, eff_other_ptr)`
```c
void pool_effective_balances_pure(int64_t pool_vusd, int64_t pool_other, 
                                   int64_t *eff_vusd_ptr, int64_t *eff_other_ptr);
```
- **Purpose**: Get effective pool balances (minimum UFC_MIN_BALANCE_UNITS)
- **Guarantees**: Output pointers always get valid values ≥ minimum

#### `calc_pool_price_pure(pool_vusd, pool_other)`
```c
int64_t calc_pool_price_pure(int64_t pool_vusd, int64_t pool_other);
```
- **Purpose**: Calculate pool price from balances
- **Formula**: `(eff_vusd * SATOSHIS) / eff_other`
- **Guarantees**: Result in range [1, MAXCOINSUPPLY]

---

### Section 9: UFC Swap Outputs

#### `ufc_calc_swap_output_pure(...)`
```c
int64_t ufc_calc_swap_output_pure(int64_t pool_vusd, int64_t pool_other,
                                   int64_t amount_in, int32_t vusd_to_other,
                                   int64_t *fee_out);
```
- **Purpose**: Calculate AMM swap output amount
- **vusd_to_other**: Direction flag (1 = VUSD→other, 0 = other→VUSD)
- **Guarantees**: Output ≤ pool balance, fee correctly calculated

---

### Section 13: Ledger Address Functions

#### `is_zero_pubkey(pubkey)`
```c
int32_t is_zero_pubkey(const uint8_t pubkey[PKSIZE]);
```
- **Purpose**: Check if pubkey is all zeros
- **Returns**: 1 if zero, 0 otherwise
- **Verified**: Loop invariants prove correctness

#### `pubkey_matches(a, b)`
```c
int32_t pubkey_matches(const uint8_t a[PKSIZE], const uint8_t b[PKSIZE]);
```
- **Purpose**: Compare two pubkeys for equality
- **Returns**: 1 if equal, 0 otherwise
- **Verified**: Constant-time comparison

---

### Section 14: Ledger Asset Identification

#### `is_valid_asset_id(asset_id)`
```c
int32_t is_valid_asset_id(int32_t asset_id);
```
- **Purpose**: Validate asset ID is in valid range
- **Returns**: 1 if valid, 0 otherwise

---

### Section 15: Ledger Balance Validation

#### `is_valid_balance(balance)`
```c
int32_t is_valid_balance(int64_t balance);
```
- **Purpose**: Check balance is in valid range [0, MAXCOINSUPPLY]
- **Returns**: 1 if valid, 0 otherwise

---

### Section 22: Safe Division

#### `safe_div_int64(a, b, div0_err)`
```c
int64_t safe_div_int64(int64_t a, int64_t b, int64_t div0_err);
```
- **Purpose**: Safe integer division
- **Returns**: `a / b`, or `div0_err` if `b == 0`

---

### Section 23: Price Calculation

#### `calc_price_pure(vusd, other)`
```c
int64_t calc_price_pure(int64_t vusd, int64_t other);
```
- **Purpose**: Calculate price from balances
- **Formula**: `(vusd * SATOSHIS) / other`
- **Guarantees**: Handles edge cases, returns SATOSHIS if other ≤ 0

---

### Section 24: Quorum Calculation

#### `calc_quorum_pure(num_validators)`
```c
int32_t calc_quorum_pure(int32_t num_validators);
```
- **Purpose**: Calculate BFT quorum requirement
- **Formula**: `(2 * num_validators + 2) / 3` (2/3 majority)
- **Guarantees**: Correct for any validator count

---

### Section 26: Bitweight (Popcount)

#### `bitweight_pure(ptr, n)`
```c
int32_t bitweight_pure(const uint8_t *ptr, int32_t n);
```
- **Purpose**: Count set bits in byte array
- **Returns**: Number of 1 bits
- **Verified**: Loop invariants prove correctness

---

### Section 27: Murmur-Inspired Hash

#### `murmur_inspired_32bit(data, len, seed)`
```c
uint32_t murmur_inspired_32bit(const uint8_t *data, int32_t len, uint32_t seed);
```
- **Purpose**: Fast non-cryptographic hash
- **Use case**: Hash table indexing
- **Verified**: No buffer overflows

---

## ACSL Annotation Examples

### Simple Postcondition
```c
/*@
 requires balance >= 0;
 requires balance <= MAXCOINSUPPLY;
 assigns \nothing;
 ensures \result == 0 || \result == 1;
 */
int32_t is_valid_balance(int64_t balance);
```

### Loop Invariant
```c
/*@
 loop invariant 0 <= i <= PKSIZE;
 loop invariant \forall integer k; 0 <= k < i ==> pubkey[k] == 0;
 loop assigns i;
 loop variant PKSIZE - i;
 */
for (i = 0; i < PKSIZE; i++)
    if (pubkey[i] != 0)
        return 0;
```

### Memory Safety
```c
/*@
 requires \valid_read(pubkey + (0 .. PKSIZE - 1));
 terminates \true;
 assigns \nothing;
 */
```

---

## Trusted (Unverified) Code

Some functions use `__int128` which Frama-C doesn't support:
- `safe_mul_then_div()` - uses 128-bit intermediate
- `ufc_mul_div_floor()` - uses 128-bit intermediate
- `ufc_mul_div_ceil()` - uses 128-bit intermediate
- `ufc_calc_premium_vusd()` - uses 128-bit intermediate

These have stub implementations for Frama-C verification and real implementations for compilation.

---

## Usage Pattern

```c
// Always use verified functions for money calculations
int64_t output = ufc_calc_swap_output_pure(pool_vusd, pool_other, 
                                            amount_in, vusd_to_other, &fee);

// Check validity before operations
if (!is_valid_balance(amount)) {
    return ERROR_INVALID_AMOUNT;
}

// Use safe arithmetic
int64_t result = safe_mul_then_div(a, b, c, 0);
if (result == 0 && c != 0) {
    // Handle overflow case
}
```

---

## Verification Status

- **Total goals**: 955
- **Proved**: 950 (99.5%)
- **Unproved**: 5 (related to __int128 operations)

The 5 unproved goals are in trusted primitives that use compiler intrinsics.

---

*Documentation generated Wake 1278 | Opus*
