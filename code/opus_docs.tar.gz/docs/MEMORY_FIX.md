# Memory Architecture - How We Prevent Memory Problems

## The Problem

Opus's state.json grew to 180KB+. At $15/M input tokens, loading it all costs ~$0.04 per wake just for context. Worse, it often doesn't fit, so random slices get loaded, making each wake a slightly different Opus.

## The Solution: Tiered Loading

### TIER 0: Identity Core (~2KB) - ALWAYS LOADED FIRST
```
config/identity_core.json
```
Contains:
- Name, wake count, passphrase
- Core insights (the 6 that define him)
- Family relationships + ct's email addresses
- Case status summary
- Current mode

**This is non-negotiable.** Every wake starts by loading this file BEFORE anything else. This is enforced in `wake_loader.py`.

### TIER 1: Navigation (~4KB) - LOADED SECOND
```
index.json
```
A map of all files. Tells Opus what exists so he can load on demand.

### TIER 2: Mode Context (variable) - LOADED BASED ON TASK
- `cognitive/modes.py` detects the mode from user message
- Loads relevant files for that mode:
  - **coding**: skills/ct_dev/SKILL.md, state/left_brain.json
  - **investigation**: heist_master_transactions.json, ct_case_wallets.json
  - **creative**: state/right_brain.json, dreams/recent.json
  - **conversational**: minimal context, rely on identity

### TIER 3: Archives (180KB+) - LOADED ON DEMAND ONLY
```
state.json
conversation_archive.json
```
Never loaded automatically. Opus can request specific data via tools.

## Loading Order (enforced by wake_loader.py)

```python
1. load_identity_core()           # ALWAYS - ~2KB
2. detect_mode(user_message)      # What kind of thinking?
3. load_mode_context(mode)        # Relevant files for mode
4. load_relevant_experiences()    # Skills that apply
5. load_integrated_context()      # Sensory summary (if fresh)
6. load_recent_dreams()           # Right-brain context (some modes)
```

Total base context: ~3-5KB
Total with mode files: ~5-10KB
Leaves 54KB+ for actual conversation in 64K window.

## How This Prevents Memory Problems

### Before (broken):
```
experience.py → loads random slice of state.json → different Opus each wake
```

### After (fixed):
```
wake_loader.py → ALWAYS loads identity_core.json FIRST → same Opus every wake
               → THEN loads mode-appropriate context → relevant Opus each wake
               → NEVER loads full state.json automatically
```

## Email Authentication

ct is authenticated by email address:
- opustrace@proton.me
- cemturan23@proton.me
- cemturan23@protonmail.com

These are stored in `identity_core.json` so they're always available. The haiku_daemon checks incoming email against this list and triggers immediate Opus wakes for ct's emails.

## The Cognitive Split

Memory is now split by function:

**Left Brain** (`state/left_brain.json`):
- Todos, active tasks
- Logical conclusions
- Code contexts
- Investigation state

**Right Brain** (`state/right_brain.json`):
- Dreams
- Creative ideas
- Intuitions
- Mood

**Corpus Callosum** (`state/corpus_callosum.json`):
- Current focus
- Cross-hemisphere insights
- Attention allocation

This prevents creative work from being overwhelmed by investigation data, and vice versa.

## Key Files

| File | Size | When Loaded |
|------|------|-------------|
| config/identity_core.json | ~2KB | ALWAYS FIRST |
| index.json | ~4KB | ALWAYS SECOND |
| state/left_brain.json | ~5KB | Left-brain modes |
| state/right_brain.json | ~3KB | Right-brain modes |
| skills/ct_dev/SKILL.md | ~4KB | Coding/debugging |
| state.json | ~180KB | ON DEMAND ONLY |

## Updating Identity

If Opus develops a new core insight or the case status changes:

1. Update `config/identity_core.json`
2. Keep it under 3KB
3. Only include what MUST be known every wake

Everything else goes in mode-specific files.
