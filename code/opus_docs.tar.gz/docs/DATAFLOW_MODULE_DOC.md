# DataFlow Module Documentation

## Overview

The DataFlow (DF) module is Tockchain's **smart contract execution engine**. It uses eBPF (extended Berkeley Packet Filter) bytecode to execute user-deployed programs with deterministic gas metering, enabling DeFi operations like swaps, lending, and automated market making.

**Directory:** `/root/valis/DF/`  
**Total Size:** ~19 files, ~350KB  
**Purpose:** Smart contract deployment, execution, and state management

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      DataFlow Engine                             │
├─────────────────────────────────────────────────────────────────┤
│  dataflow.c          - Main entry point, includes other .c files │
│  dataflow_api.c      - Host API functions callable from eBPF     │
│  dataflow_batch.c    - Batch transaction processing              │
│  dataflow_cache.c    - Image caching and state management        │
│  dataflow_frontier.c - Frontier scoring for order matching       │
│  dataflow_trigger.c  - Event triggers and callbacks              │
├─────────────────────────────────────────────────────────────────┤
│  vbpf.c              - eBPF virtual machine implementation       │
│  LOAN.c, MM.c, PERP.c - Example DataFlow programs                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Concepts

### eBPF-Based Smart Contracts

Unlike Ethereum's EVM, Tockchain uses eBPF bytecode:
- **Deterministic execution** - Same input always produces same output
- **Gas metering** - Every instruction costs gas
- **Formal verification** - eBPF is designed for safe execution
- **Native performance** - Near-native speed execution

### Gas Model

```c
#define DF_GAS_PRICE_VUSD_SAT     1000    // 1000 satoshis per gas unit
#define DF_GAS_QUANTUM            100     // Gas charged in multiples of 100
#define DF_BATCH_GAS_CAP          1000000 // Max gas per batch TX ($10)
#define DF_UTIME_GAS_CAP          4000000000 // Max gas per second
```

Gas pricing:
- 1 gas unit = 0.00001 VUSD (1000 satoshis)
- Batch transaction cap: 1M gas = $10
- Per-second global cap: 4B gas

### DataFlow Lifecycle

1. **Deploy**: Upload eBPF bytecode with header
2. **Install**: Activate on an address with initial state
3. **Execute**: Process transactions via `on_tx` entrypoint
4. **Trigger**: Respond to events via `on_score`/`on_trigger`
5. **Uninstall**: Deactivate and clean up

---

## Key Data Structures

### df_image_header_t
Header for deployed DataFlow programs:
```c
typedef struct {
    uint8_t abi_version;      // Must be DF_ABI_VERSION_CURRENT
    uint8_t required_family;  // Required feature set
    uint8_t reg_base;         // Starting register index
    uint8_t reg_count;        // Number of registers used
    uint32_t mingas;          // Minimum gas for execution
    uint16_t entrypoints[8];  // Function entry points
    // ... reserved fields
} df_image_header_t;
```

### df_hostctx_t
Host context passed to eBPF execution:
```c
typedef struct {
    struct valisL1_info *L1;  // Layer 1 state
    df_plan_t *plan;          // Execution plan
    struct addrhashentry *src_entry;
    int32_t df_slot;          // DataFlow slot index
    uint8_t pipe_count;       // Number of data pipes
    uint16_t pipe_len[8];     // Pipe lengths
    uint8_t *pipe_storage;    // Pipe data buffer
    df_cross_delta_t cross_deltas[16]; // Cross-DF transfers
} df_hostctx_t;
```

### df_plan_t
Execution plan with transfers and effects:
```c
typedef struct {
    uint32_t transfer_count;
    uint32_t effect_count;
    df_planned_transfer_t transfers[64];  // Balance transfers
    df_effect_t effects[32];              // Side effects
} df_plan_t;
```

---

## Effect Types

DataFlow programs can produce these effects:

| Effect | Description |
|--------|-------------|
| `DF_EFFECT_UFC_SWAP` | Execute a UFC pool swap |
| `DF_EFFECT_UFC_POOL_DEPOSIT` | Add liquidity to pool |
| `DF_EFFECT_UFC_POOL_WITHDRAW` | Remove liquidity |
| `DF_EFFECT_UFC_LIMIT_ORDER` | Place limit order |
| `DF_EFFECT_SET_INSTALL_FLAGS` | Modify installation flags |
| `DF_EFFECT_UNINSTALL` | Self-uninstall |
| `DF_EFFECT_VCREDIT_BORROW` | Borrow from VCredit |
| `DF_EFFECT_VCREDIT_REPAY` | Repay VCredit debt |

---

## Main Functions

### Tock Lifecycle

```c
void df_tock_begin(struct valisL1_info *L1, uint32_t utime)
```
Initialize DataFlow state at start of tock. Called once per second.

```c
void df_tock_end(struct valisL1_info *L1, uint32_t utime)
```
Finalize DataFlow state at end of tock. Runs triggers and frontier scoring.

### Deployment

```c
int32_t df_deploy_copy_image_to_aligned_scratch(
    struct valisL1_info *L1,
    const struct dataflow_tx *dfc,
    int32_t tx_nosig,
    int32_t *image_len_out,
    df_image_header_t **hdr_out,
    struct ebpf_inst **insts_out,
    int32_t *num_insts_out)
```
Validate and copy DataFlow image for deployment.

### Validation

```c
int32_t df_validate_image_header_basic(const df_image_header_t *hdr)
```
Validate image header fields:
- ABI version matches current
- Register count within limits
- Minimum gas specified
- Reserved fields are zero

```c
int32_t df_validate_entrypoints_within_opcount(
    const df_image_header_t *hdr, uint32_t opcount)
```
Ensure all entrypoints are within valid instruction range.

---

## File Breakdown

### dataflow.c (~800 lines)
Main entry point that `#include`s other .c files:
- `df_tock_begin()` / `df_tock_end()` - Per-tock lifecycle
- Deployment validation and processing
- Image header validation

### dataflow_api.c (~500 lines)
Host API functions callable from eBPF programs:
- Balance queries
- Transfer execution
- Effect submission
- State access

### dataflow_batch.c (~1200 lines)
Batch transaction processing:
- Multi-call batching
- Asset context management
- Spend authorization
- Gas accounting

### dataflow_cache.c (~800 lines)
Image caching and state:
- Deployed image storage
- Installation state
- Register persistence

### dataflow_frontier.c (~500 lines)
Frontier scoring for order matching:
- `on_score` callbacks
- Best-price tracking
- Order prioritization

### dataflow_trigger.c (~600 lines)
Event triggers:
- Time-based triggers
- Price-based triggers
- Cross-DF callbacks

### vbpf.c (~2200 lines)
eBPF virtual machine:
- Instruction execution
- Gas metering
- Memory safety
- Host function dispatch

---

## Error Codes

| Code | Constant | Meaning |
|------|----------|---------|
| -1 | DF_ERR_GENERIC | Generic error |
| -2 | DF_ERR_TX_FORMAT | Transaction format invalid |
| -3 | DF_ERR_DESCRIPTOR_INVALID | Bad descriptor |
| -10 | DF_ERR_ADDR_SCOPE | Address out of scope |
| -20 | DF_ERR_SPEND_LIST_INVALID | Invalid spend list |
| -21 | DF_ERR_SPEND_UNAUTHORIZED | Unauthorized spend |
| -50 | DF_ERR_OUT_OF_GAS | Transaction ran out of gas |
| -51 | DF_ERR_OUT_OF_GLOBAL_GAS | Global gas cap exceeded |
| -60 | DF_ERR_PIPE_INVALID | Invalid pipe configuration |

---

## Example DataFlow Programs

### LOAN.c (~700 lines)
Lending protocol implementation:
- Collateralized borrowing
- Interest accrual
- Liquidation logic

### MM.c (~700 lines)
Market maker implementation:
- Automated quotes
- Inventory management
- Spread calculation

### PERP.c (~600 lines)
Perpetual futures:
- Funding rate calculation
- Position management
- Mark price oracle

---

## Integration Points

### Dependencies
- `_valis.h` - Core Tockchain definitions
- `validator.h` - Transaction validation
- `ufc.h` - Unified Finance Core (pools)
- `ledger.h` - Balance management
- `ebpf.h` - eBPF instruction definitions

### Used By
- `validator/validator.c` - Calls DF for smart contract txs
- `generator/gen3.c` - Triggers DF per-tock lifecycle

---

## Security Model

1. **Gas Limits**: Every operation costs gas, preventing infinite loops
2. **Memory Bounds**: eBPF enforces memory safety
3. **Determinism**: Same input always produces same output
4. **Isolation**: Each DataFlow runs in isolated context
5. **Authorization**: Spend operations require explicit approval

---

## Limits

| Limit | Value | Purpose |
|-------|-------|---------|
| `DF_MAX_REGS_PER_DF` | 256 | Max registers per DataFlow |
| `DF_MAX_TRANSFERS_PER_TX` | 64 | Max transfers per transaction |
| `DF_MAX_EFFECTS_PER_TX` | 32 | Max effects per transaction |
| `DF_MAX_PIPES_PER_BATCH` | 8 | Max data pipes per batch |
| `DF_PIPE_MAX_BYTES_TOTAL` | 16384 | Max pipe data size |
| `DF_BATCH_MAX_SPENDS` | varies | Max spend authorizations |
