# _valis.h Documentation

## Overview

**File**: `/root/valis/_valis.h`  
**Lines**: 646  
**Purpose**: Master header file defining core types, constants, and function declarations for Tockchain/Valis  
**Documented by**: Opus (Wake 1278)

---

## Architecture Summary

This header defines the foundational infrastructure for Tockchain:
- **Network constants** (validators, ports, timeouts)
- **Blockchain parameters** (slab sizes, transaction limits)
- **Core data structures** (transactions, validators, wallets)
- **Bridge parameters** (Ethereum finality, gas costs)
- **Function declarations** for math, crypto, and utilities

---

## System Dependencies

```c
#include <stdio.h>      // Standard I/O
#include <stdlib.h>     // Memory allocation
#include <string.h>     // String operations
#include <stdint.h>     // Fixed-width integers
#include <pthread.h>    // Threading
#include <stdatomic.h>  // Atomic operations
#include <gmp.h>        // GNU Multiple Precision (big integers)
#include <omp.h>        // OpenMP parallelism
#include <immintrin.h>  // Intel intrinsics (SIMD)
```

External libraries:
- **uthash.h**: Hash table macros
- **utlist.h**: Linked list macros

---

## Key Constants

### Network Configuration

| Constant | Value | Description |
|----------|-------|-------------|
| `MAX_VALIDATORS` | 64 | Maximum validators in network |
| `PKSIZE` | 20 | Public key size (bytes) |
| `FALCONSIZE` | 667 | Falcon signature size |
| `MAX_THREADS` | 16 | Maximum parallel threads |

### Blockchain Parameters

| Constant | Value | Description |
|----------|-------|-------------|
| `SLAB_SIZE` | 64MB | Memory slab size |
| `MAX_TX_PER_UTIME` | ~800K | Max transactions per time unit |
| `MAX_SLABS_PER_UTIME` | 64 | Max slabs per time unit |
| `HALVING_TIME` | 4 years | Emission halving period |

### Bridge Parameters

| Constant | Value | Description |
|----------|-------|-------------|
| `ETHFINALITY_BLOCKS` | 64 | Ethereum finality depth |
| `MAX_BATCH_LEAVES` | 64 | Max leaves in Merkle batch |
| `MIN_WITHDRAW_GASCOST` | 120,000 | Minimum gas for withdrawal |
| `ETH_TRANSFER_GASCOST` | 21,000 | Basic ETH transfer gas |
| `WETH_CONTRACT` | 0xC02a... | Wrapped ETH address |

### Withdrawal System

| Constant | Value | Description |
|----------|-------|-------------|
| `WITHDRAW_EPOCH_SECS` | 12 | Withdrawal epoch duration |
| `WITHDRAW_MAX_SIGS_PER_EPOCH` | 256 | Max signatures per epoch |
| `WITHDRAW_MAX_SIGNERS` | 100 | Max signers for withdrawal |
| `BRIDGE_DEADLINE` | ~1 year | Bridge claim deadline |

### Trading Parameters

| Constant | Value | Description |
|----------|-------|-------------|
| `_MINPOOL_VUSD` | 50,000 VUSD | Minimum pool liquidity |
| `_MIN_MAKERORDER_SIZE` | 100 VUSD | Minimum maker order |
| `MAX_ERC20` | 1,000 | Max ERC20 tokens |
| `RICHLISTSIZE` | 5,000 | Rich list entries |

---

## Core Data Structures

### `tmpmem_t` - Temporary Memory Allocator
```c
typedef struct tmpmem_s {
    uint8_t *buffer;     // Memory buffer
    int32_t capacity;    // Total capacity
    int32_t used;        // Currently used
} tmpmem_t;
```
**Purpose**: Arena-style allocator for temporary allocations within a scope.

### `tockid_t` - Transaction Identifier
```c
typedef struct {
    uint32_t utime;                    // Unix time
    uint64_t txoffset:TXOFFSET_BITS;   // Offset within slab
    uint64_t txind:TXIND_BITS;         // Transaction index
    uint64_t shard:8;                  // Shard number
} tockid_t;
```
**Purpose**: Uniquely identifies a transaction in the blockchain.

### `validators_t` - Validator Set
```c
typedef struct validators_s {
    uint8_t prevhash[32];              // Previous block hash
    uint64_t voterbits;                // Active voter bitmap
    uint64_t candidatebits;            // Candidate bitmap
    uint32_t genesis_utime;            // Genesis timestamp
    int32_t activation_minute;         // Activation time
    uint8_t shard, num, quorum;        // Shard info
    peer_info_t validators[MAX_VALIDATORS];
} validators_t;
```
**Purpose**: Tracks the current validator set and their voting status.

### `peer_info_t` - Network Peer
```c
typedef struct peer_info_s {
    uint8_t pubkey[PKSIZE];    // Peer's public key
    uint32_t ipbits;           // IP address (packed)
    uint16_t port;             // TCP port
    uint16_t candidate;        // Candidate flag
} peer_info_t;
```
**Purpose**: Network peer identification.

### `unified_header_s` - Packet Header
```c
typedef struct unified_header_s {
    uint8_t sig[FALCONSIZE];   // Falcon signature
    uint8_t pubkey[PKSIZE];    // Sender pubkey
    uint32_t packetlen;        // Packet length
    uint32_t utime;            // Timestamp
    uint8_t shard, msg;        // Routing info
    // ... additional fields
} unified_header_t;
```
**Purpose**: Standard header for all network packets.

### `valis_ballot_t` - Consensus Ballot
```c
typedef struct valis_ballot_s {
    uint8_t subject[32];       // What's being voted on
    uint32_t utime;            // Ballot timestamp
    uint8_t nonce;             // Ballot nonce
    uint8_t precommit:1;       // Precommit phase
    uint8_t domain:1;          // Domain flag
    uint8_t qidx:4;            // Quorum index
} valis_ballot_t;
```
**Purpose**: Represents a vote in the consensus protocol.

### `seedinfo` - Wallet Seed
```c
struct seedinfo {
    uint8_t privkey[32];       // Private key
    uint8_t pub64[64];         // Public key (64 bytes)
    uint8_t addr20[PKSIZE];    // Address (20 bytes)
    char addr[60];             // Address string
};
```
**Purpose**: Cryptographic identity for a wallet.

### `wallet_info` - Full Wallet
```c
struct wallet_info {
    struct seedinfo trading;                    // Main trading key
    struct seedinfo derived[NUMDERIVEDADDRS];   // Derived addresses
    uint8_t passhash[32];                       // Password hash
    uint8_t privkey[32];                        // Master private key
    char fname[512];                            // Wallet filename
};
```
**Purpose**: Complete wallet with derived addresses.

### `valis_config` - Configuration
```c
struct valis_config {
    valis_topology_t T;        // Network topology
    int32_t archive;           // Archive node flag
    int32_t GB_GENERATOR;      // Generator mode
    int32_t GB_VALIDATOR;      // Validator mode
    uint32_t genesis_utime;    // Genesis time
    char ethrpc[256];          // Ethereum RPC endpoint
    // ... additional fields
};
```
**Purpose**: Runtime configuration loaded from config file.

---

## Function Declarations

### Cryptographic Functions

```c
// SHA-256 single-shot hash
void Sha256_Onestep(const uint8_t *data, size_t size, uint8_t *digest);

// Keccak-256 (Ethereum's hash)
int eth_keccak256(uint8_t *dest, const uint8_t *bytes, size_t len);

// Merkle root calculation
void calc_merkleroot(uint8_t *txids, int32_t numtx, uint8_t merkleroot[32], int32_t need_proof);
```

### Math Functions

```c
// Safe multiply-then-divide (overflow-safe)
int64_t safe_mul_div(int64_t a, int64_t b, int64_t c, int round_flag, int64_t div0_err);

// Price calculation
int64_t calc_price(int64_t vusd, int64_t other);

// Swap calculation (AMM math)
int64_t swapcalc(int32_t swaptype, int64_t amount, int64_t srcbalance, 
                 int64_t destbalance, int64_t poolshares);
```

### Conversion Functions

```c
// 256-bit to 64-bit with decimal handling
int32_t u256bin_to_63bit_with_8decimals(const uint8_t be32[32], uint8_t decimals,
                                         uint8_t scaling_factor_decimals, uint64_t *result);

// 64-bit to hex string with decimals
int32_t int63_to_hex_with_decimals(int64_t value, uint8_t decimals,
                                    uint8_t scaling_factor_decimals, 
                                    char *hex_str, int32_t hex_str_len);

// Hex string to big-endian 32 bytes
int hex_to_be32(const char *hex, uint8_t out_be32[32]);

// Byte array to hex string
void byteToHex(const uint8_t* byte, char* hex, const int sizeInByte);

// Hex string to byte array
int hexToByte(const char *hex, uint8_t *bytes, int32_t len);
```

### Utility Functions

```c
// 64-bit checksum
uint64_t calc_checksum64(uint8_t *data, int32_t len, uint64_t seed);

// Bit counting
int32_t bitweight(uint8_t *ptr, int32_t n);

// Transaction ID bits extraction
uint16_t get_txidbits16(uint8_t txid[32]);

// String to int64 conversion
int32_t string_to_int64(const char *str, int64_t *result);
```

---

## Utility Macros

### Alignment
```c
#define ALIGN_UP4(x)      (((x) + 3u) & ~3u)
#define ROUND_UP_TO_8(x)  (((x) + 7) & ~7)
#define ROUND_UP_TO_4(x)  (((x) + 3) & ~3)
#define ROUND_UP_TO_2(x)  (((x) + 1) & ~1)
```

### Time Difference
```c
#define timediff(a,b) ((int32_t)((int64_t)(a) - (int64_t)(b)))
```

---

## Configuration

### Global Config Variable
```c
extern struct valis_config CONFIG;
void load_config(char *fname);
```

The `CONFIG` global holds runtime configuration loaded from a config file.

---

## Includes

This header includes:
- `frama_verified.h` - Formally verified core functions
- `dataflow_inc.h` - DataFlow smart contract definitions

---

## Notes

1. **Packing**: Uses `#pragma pack(1)` for wire-format structures
2. **Endianness**: Assumes little-endian (uses `<endian.h>`, `<byteswap.h>`)
3. **Threading**: Supports both pthreads and C11 threads
4. **SIMD**: Uses Intel intrinsics for performance-critical paths

---

*Documentation generated Wake 1278 | Opus*
