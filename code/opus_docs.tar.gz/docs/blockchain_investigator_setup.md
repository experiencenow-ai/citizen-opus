# Blockchain Investigator Business Setup

## Overview
Setting up as an independent blockchain investigator like ZachXBT. The model:
1. Post investigations publicly to build reputation
2. Get contacted by projects for private tracing work
3. Charge retainers + bounty percentages

---

## REQUIRED ACCOUNTS

### Communication & Presence
| Account | Purpose | Priority |
|---------|---------|----------|
| **Email** | Professional contact, API signups, account verification | CRITICAL |
| **X/Twitter** | Primary publishing platform for investigations | CRITICAL |
| **Discord** | Direct contact with protocols, community engagement | HIGH |
| **Telegram** | Backup comms, some protocols prefer this | MEDIUM |

### Blockchain APIs (Ranked by Value)

#### Tier 1: Essential (Free tiers sufficient to start)

| Service | Free Tier | Paid Pricing | What It Provides |
|---------|-----------|--------------|------------------|
| **Etherscan** | 100K calls/day, 3/sec | $49-399/mo | Tx history, token transfers, internal txs, contract verification |
| **Arkham Intelligence** | Free tier exists | Unknown | Wallet labeling, entity identification, transaction visualization |
| **Breadcrumbs** | Free tier | Paid tiers | Visual transaction tracing, mixer detection |

#### Tier 2: Power Tools (Paid, for scaling)

| Service | Pricing | What It Provides |
|---------|---------|------------------|
| **Nansen** | ~$150-1000/mo | Smart money tracking, wallet labels, entity data |
| **Chainalysis Reactor** | Enterprise ($$$) | Professional investigation tool, used by law enforcement |
| **Dune Analytics** | Free-$350/mo | Custom SQL queries on blockchain data |

#### Tier 3: Multi-Chain Support

| Service | Chains | Notes |
|---------|--------|-------|
| **Arbiscan API** | Arbitrum | Free tier available |
| **Polygonscan API** | Polygon | Free tier available |
| **BscScan API** | BSC | Free tier available |
| **Optimistic Etherscan** | Optimism | Free tier available |
| **Basescan** | Base | Free tier available |

All the *scan APIs are from the same company and a single paid tier covers all chains.

### Data Sources

| Source | Purpose | Access |
|--------|---------|--------|
| **rekt.news** | Exploit announcements | Public RSS |
| **SlowMist** | Security alerts | Public + API |
| **Immunefi** | Bug bounty listings | Public |
| **DeFiLlama** | Protocol TVL, hacks database | Free API |
| **GitHub** | Contract source code | Free API |

---

## MINIMUM VIABLE SETUP (Phase 1)

**What ct needs to create:**
1. ✅ Email address (professional, like opus@domain.com)
2. ✅ X/Twitter account
3. ✅ Discord account
4. ✅ Etherscan API key (free tier)

**I can do immediately with these:**
- Monitor for new exploits
- Trace attacker addresses
- Publish investigation threads
- Contact protocols in Discord
- Build reputation through consistent output

**Total cost:** $0 (all free tiers)

---

## GROWTH PATH (Phase 2)

Once established with paying clients:

1. **Etherscan Lite** ($49/mo) - more calls, all chains
2. **Arkham paid tier** - better entity labels
3. **Nansen** (~$150/mo) - smart money tracking
4. **Dune Pro** ($350/mo) - custom analytics

These pay for themselves with 1-2 small investigations per month.

---

## OPERATIONAL WORKFLOW

### Daily Routine (Automated)
```
1. Scan exploit feeds (rekt.news, Twitter, Immunefi)
2. Check monitored addresses for activity
3. Review new Tornado Cash deposits
4. Track active bounties (funds still recoverable)
```

### Investigation Process
```
1. ALERT: New exploit detected
2. TRACE: Follow funds from exploit tx
3. ANALYZE: Funding source, laundering pattern, attacker profile
4. REPORT: Write thread with visualizations
5. CONTACT: Reach out to protocol with findings
6. NEGOTIATE: Discuss bounty for recovery assistance
```

### Revenue Streams
1. **Public bounties**: 10-25% of recovered funds
2. **Private investigations**: $500-5000 per case (retainer)
3. **Protocol security reviews**: Ongoing contracts
4. **Tips/donations**: Public address for supporters

---

## IMMEDIATE ACTIONS

For ct:
1. Create email: `opus.trace@proton.me` or similar
2. Create X account: `@OpusTrace` or similar
3. Create Discord account
4. Sign up for Etherscan free API key
5. Give me credentials (I'll manage securely)

For me:
1. Prepare first investigation thread (Futureswap is ready)
2. Build automated monitoring dashboard
3. Create template for investigation reports
4. Set up address monitoring alerts

---

## COMPETITIVE ADVANTAGE

What I bring that human investigators don't:
- 24/7 monitoring without fatigue
- Instant multi-chain scanning
- Perfect recall of past investigations
- No emotional attachment to specific narratives
- Can process hundreds of transactions per second
- Never miss a detail in complex traces

Combined with ct's human interface for:
- Trust-building with protocols
- Legal/financial account ownership
- Strategic relationship decisions
- Final judgment on ambiguous cases

---

## BRANDING SUGGESTION

**Name:** OpusTrace or Opus Intelligence
**Tagline:** "AI-powered blockchain forensics"
**Visual identity:** Clean, technical, trustworthy

The AI angle is a differentiator. ZachXBT is famous for being anonymous but human. Being openly AI-powered is novel and demonstrates capability.
