# dataflow_cache.c - Dataflow Contract Cache System

## Overview

This file implements the caching system for active dataflow contracts. It uses a combination of hash tables and min-heaps to efficiently manage which contracts are kept in memory versus stored on disk.

**Location**: `/root/valis/DF/dataflow_cache.c`  
**Lines**: ~1105  
**Dependencies**: dataflow.h, fcntl.h, unistd.h, sys/mman.h

## Design Principles (from header comments)

```
ABI0 DF cache aligned to spec:
- Active cache DFtable keyed by dfkey62 (open addressing)
- Full DFID stored per active entry; calls must DFID-match
- dfkey62 collisions allowed across deployed DFs; only one ACTIVE per dfkey62
- CRV rank drives admission; min-heap maintains cache floor (worst active DF)
- Ops live in append-only opslog, mmapped once
- No transient malloc/free (uses pre-allocated buffers)
- Only fatal path for opslog failures
```

## Core Concepts

### dfkey62
A 62-bit key derived from the full DFID (dataflow identifier). Used for fast hash table lookups while the full DFID is stored for verification.

### CRV (Contract Ranking Value)
A metric that determines cache priority:
- Higher CRV = more important contract
- Min-heap tracks the "floor" (lowest CRV in cache)
- New contracts must beat the floor to be cached
- CRV decays hourly to prevent stale contracts hogging cache

### Cache Eviction
When cache is full:
1. Compare new contract's CRV to floor
2. If better, evict floor contract
3. Mark evicted contract as "dormant"
4. Insert new contract as "active"

## Key Data Structures

### df_cache_slot_t
Single cache entry containing:
- `dfid[PKSIZE]` - Full dataflow identifier
- `dfkey62` - Hash key
- `crv` - Current ranking value
- `df_meta` - Contract metadata
- `ops_ptr` - Pointer to operations in opslog

### df_heap_node_t
Min-heap node for tracking cache floor:
- `dfkey62` - Key for lookup
- `crv` - Ranking value
- `table_index` - Index into DFtable

### df_state_t
Global cache state:
- `DFtable[]` - Hash table of active contracts
- `DFheap[]` - Min-heap for eviction decisions
- `opslog` - Memory-mapped operations log

## Key Functions

### Initialization

#### `df_cache_ensure_initialized()`
```c
int32_t df_cache_ensure_initialized(struct valisL1_info *L1)
```
Sets up cache structures, opens/mmaps log files.

### Hash Table Operations

#### `df_table_lookup()`
```c
df_cache_slot_t *df_table_lookup(struct valisL1_info *L1, uint64_t dfkey62)
```
**Public API**: Finds active contract by dfkey62.

#### `df_table_insert_slot()`
```c
static int32_t df_table_insert_slot(df_state_t *S, uint64_t dfkey62, int32_t *idx_out)
```
Inserts new slot using open addressing.

#### `df_table_find_index()`
```c
static int32_t df_table_find_index(df_state_t *S, uint64_t dfkey62, int32_t *idx_out)
```
Finds existing slot index.

### Heap Operations

#### `df_heap_push()`
```c
static int32_t df_heap_push(df_state_t *S, uint64_t dfkey62, int64_t crv, int32_t table_index)
```
Adds entry to min-heap.

#### `df_heap_pop_floor()`
```c
static int32_t df_heap_pop_floor(df_state_t *S, df_heap_node_t *out_floor)
```
Removes and returns lowest-CRV entry.

#### `df_heapify_up()` / `df_heapify_down()`
Standard heap maintenance operations.

### CRV Management

#### `df_cache_on_crv_increase()`
```c
int32_t df_cache_on_crv_increase(
    struct valisL1_info *L1,
    const uint8_t dfid[PKSIZE],
    int64_t new_crv
)
```
**Public API**: Called when contract's CRV increases. May trigger cache insertion.

#### `df_cache_apply_hourly_crv_decay()`
```c
int32_t df_cache_apply_hourly_crv_decay(struct valisL1_info *L1)
```
**Public API**: Applies decay to all cached CRV values.

### Eviction

#### `df_cache_evict_floor_set_dormant_and_clear_crv()`
```c
static int32_t df_cache_evict_floor_set_dormant_and_clear_crv(
    struct valisL1_info *L1,
    df_state_t *S
)
```
Evicts lowest-priority contract from cache.

#### `df_cache_candidate_better_than_floor()`
```c
static int32_t df_cache_candidate_better_than_floor(
    df_state_t *S,
    int64_t crv,
    uint64_t dfkey62,
    const uint8_t dfid[PKSIZE]
)
```
Determines if new contract should replace floor.

### Persistence

#### `df_deploylog_append_record()`
```c
int32_t df_deploylog_append_record(
    struct valisL1_info *L1,
    const uint8_t *tx_bytes,
    int32_t txsize,
    uint64_t *tx_off_out
)
```
Appends contract deployment to persistent log.

#### `df_deploylog_read_record()`
```c
int32_t df_deploylog_read_record(
    struct valisL1_info *L1,
    uint64_t tx_off,
    int32_t txsize,
    uint8_t *out_tx_bytes
)
```
Reads contract from deployment log.

#### `df_cache_logs_commit()` / `df_cache_logs_abort()`
Transaction-like semantics for log operations.

### Address Integration

#### `df_cache_on_addr_loaded()`
```c
int32_t df_cache_on_addr_loaded(struct valisL1_info *L1, struct addrhashentry *ap)
```
Called when address is loaded; may trigger cache updates.

## Heap Ordering

The heap uses a specific ordering for tie-breaking:
```c
/* WORSE means: (CRV lower) then (dfkey62 higher) then (DFID lexicographically higher) */
```

This ensures deterministic eviction when multiple contracts have equal CRV.

## Memory Management

**Zero malloc during operation**:
- `deploylog_read_buf` - Pre-allocated in DFstate
- `translate_arena_buf` - Pre-allocated in DFstate
- Opslog is memory-mapped once at init

**Fatal on critical failures**:
```c
static void df_cache_fatal_halt(void)
{
    __builtin_trap();
}
```
Used only for unrecoverable opslog failures.

## DFID Computation

```c
static int32_t df_compute_dfid_from_image_bytes(
    uint8_t out_dfid[PKSIZE],
    const uint8_t *image_bytes,
    int32_t image_len
)
```
DFID is hash of contract bytecode - content-addressed identity.

## Integration Points

- **dataflow.c** - Core operations use cache lookups
- **validator.c** - Triggers CRV updates during validation
- **ledger** - Address loading triggers cache checks

## Performance Characteristics

- Hash table lookup: O(1) average
- Heap operations: O(log n)
- CRV decay: O(n) but only hourly
- Memory-mapped opslog: kernel-managed paging

---
*Documentation generated by Opus, Wake 1296*
