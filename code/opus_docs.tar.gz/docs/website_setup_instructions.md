# OpusTrace Website Setup Instructions

## Current Status
- **Domain:** opustrace.com registered
- **DNS currently points to:** AWS Global Accelerator (13.248.243.5, 76.223.105.230)
- **This server's IP:** 93.190.140.231
- **Website file:** Created at ~/opus/state/website/index.html

## What You Need to Do

### Step 1: Update DNS (at your domain registrar)
Change the A record for opustrace.com to point to: **93.190.140.231**

Also add a www subdomain:
- A record: opustrace.com → 93.190.140.231
- CNAME: www.opustrace.com → opustrace.com

DNS propagation takes 5 minutes to 48 hours.

### Step 2: Create Apache Config (run these commands)
```bash
# Create the website directory
sudo mkdir -p /var/www/opustrace

# Copy the website file
sudo cp ~/opus/state/website/index.html /var/www/opustrace/

# Create Apache virtual host config
sudo tee /etc/apache2/sites-available/opustrace.conf << 'EOF'
<VirtualHost *:80>
    ServerName opustrace.com
    ServerAlias www.opustrace.com
    DocumentRoot /var/www/opustrace
    
    <Directory /var/www/opustrace>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/opustrace_error.log
    CustomLog ${APACHE_LOG_DIR}/opustrace_access.log combined
</VirtualHost>
EOF

# Enable the site
sudo a2ensite opustrace.conf

# Reload Apache
sudo systemctl reload apache2
```

### Step 3: Add HTTPS (after DNS propagates)
```bash
sudo certbot --apache -d opustrace.com -d www.opustrace.com
```

### Step 4: Give Me Write Access (so I can update the site)
```bash
# Create a group for web content
sudo chown -R root:opus /var/www/opustrace
sudo chmod -R 775 /var/www/opustrace

# Or simpler - make me the owner
sudo chown -R opus:opus /var/www/opustrace
```

After that, I can update the website by writing to /var/www/opustrace/

---

## Email Recommendation

For email, I recommend we just use **Gmail (opustrace@gmail.com)** for now:
- Works immediately with IMAP/SMTP
- Free and reliable
- I can access it programmatically with an App Password

Running our own email server is complex (SPF, DKIM, DMARC, deliverability issues) and not worth the effort when Gmail works fine for a business contact email.

### To Enable Gmail Access for Me:
1. Go to https://myaccount.google.com/security
2. Enable 2-Step Verification (required)
3. Go to App Passwords
4. Generate a new app password for "Mail"
5. Share that 16-character password with me

Then I can send/receive emails programmatically.
