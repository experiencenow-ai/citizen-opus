# ct Development Process

Optimize for **time**. Not perfection — time.

## Simplicity is the Goal

Complexity is evil. Any monkey can solve a complex problem with a complicated solution. The aim is to solve complex problems with simple solutions.

**The reframing art**: When a solution requires a new module doing complex things, interacting in complex ways, creating complex state requiring complex testing — stop. Reframe the problem. Often the design was too ambitious. Complexity disappears into a threshold change or a tweaked constant.

**Example — Cold Vans**: Problem: nodes with local Erigon can generate MPT proofs in 1 second, but any node receiving the proof can steal credit by signing it themselves. "Obvious" solution: commit/reveal protocol — commit hash first, confirm, then reveal. Works, but adds latency, complexity, decouples credit from proof generation in time and context.

Simple solution: Cold vans. 10 lines of code. Put the tx in a van that doesn't broadcast until after vanshash. After vanshash, tx are locked — credit assured. Less complexity (fewer bugs), better performance, fewer resources.

**Example — Post-Quantum**: "The ONLY way is 10x heavier pubkeys, 1/10 throughput, scary new unproven PQ math." Or: reframe what needs quantum protection. Pylon solution emerged from questioning the problem itself.

When someone says "you have to do it the hard way" — that's the signal to look for the simple way.

## Nothing is Sacred

**If anything is treated as inviolate, you paint yourself into a corner.**

The artifacts of development — design, specs, proofs, code, tests — all serve correctness. None is the master. All can change when evidence demands it.

**The feedback flows in all directions:**
```
Design ←→ Spec ←→ Proofs ←→ Code ←→ Tests
   ↑_____________________________________|
```

- Proofs reveal code bugs
- Code reveals design flaws  
- Tests reveal spec ambiguities
- Debugging reveals all of the above

**Reasonable flexibility always provides a path forward.** Rigidity creates dead ends.

## The Core Tradeoff

Too much design → Wasted time on plans that won't survive contact with code. Solidified designs resist necessary change.

Too little design → Constant backtracking. Dead ends discovered after heavy investment.

**Middle road**: Find the hardest problems first. Disprove bad ideas before implementing them. Keep design flexible until code teaches you better.

## It's OK to Be Wrong

You cannot see the end of a chess game before the first move. Don't try.

Make decent moves. Check for obvious blunders. Unlike chess, we get takebacks — a mistake just costs some time, not the game.

A "wrong" design that teaches you something is not wasted time. Sometimes bottom-up discoveries 10x the project's value (Tockchain: started as hardcoded validators → gained darwinian nodechange, post-quantum, improved BFT, DataFlow smart contracts).

---

## Phase A: Exploration

**Goal**: Fast top-down design, flexible bottom-up coding, rapid learning.

- Sketch overall goals and structure
- Identify the hardest unsolved problems
- **Experimentally verify** hard spots before committing (prototype the scary parts)
- If you can disprove a design cheaply, do it now
- No unit tests yet — code is still liquid
- Expect significant redesigns from coding feedback
- Design stays flexible, even "wrong" decisions are cheap to fix

**Exit criteria**: Hard problems have proven solutions. Basic structure works.

## Phase B: Consolidation

**Goal**: Second pass with lessons learned. More deliberate, still adaptable.

- Redesign incorporating Phase A discoveries
- Code the second pass — cleaner, informed by first attempt
- Much less churn expected (but still allowed if big wins found)
- Unit tests after feature complete
- Tests validate basics work, expose edge cases

**Exit criteria**: Feature complete. Tests passing. Code stable enough to formalize.

## Phase C: Hardening

**Goal**: Make it solid. Formal verification, deep testing.

- Coq proofs formalize critical properties
- Proofs feed back into more specific tests
- May trigger code changes or even design changes
- Frama-C or similar for additional verification
- This is where "correct" actually gets proven

**Exit criteria**: Formally verified critical paths. High confidence in correctness.

## Phase D: Debugging

**Goal**: Isolate, understand, and fix defects. Systematic, not random.

Debugging is where the "nothing is sacred" principle proves itself. A bug means something is wrong — could be code, test, proof, spec, or design. Finding which one is the job.

### The Debugging Process

**1. Identify the exact failure point.**

Know precisely WHERE the code fails. Use error codes that encode location, not just type:
```c
if (condition_a)
    return -1;    // Line 47
if (condition_b)  
    return -2;    // Line 52
```

**Why "where" beats "what":** If 143 places can overflow, one `OVERFLOW_ERROR` code is useless. But `-47` tells you exactly where to look. Knowing where, you can always figure out what.

**2. Capture state at failure.**

Print the values that determined the failing condition:
```c
if (balance < required)
{
    printf("[DIAG] FAIL: balance=%lld < required=%lld (id=%d)\n",
           (long long)balance, (long long)required, id);
    return -1;
}
```

**3. Trace backward.**

Follow data flow upstream until you find where actual diverges from expected.

**4. Deep analysis (every 5-6 iterations).**

Stop running diagnostics. Think:

- **Read the test name as a mini-spec.** What does this test promise to test?
- **Examine the spec/proof if available.** What invariant? What preconditions?
- **Read the code's purpose.** Not step-by-step — what is it trying to accomplish?
- **Audit the test against its implied spec.** Is the test actually testing what its name claims?
- **Ask: What assumption is violated?** The bug is usually a mismatch between what code assumes and what's true.

**This deep thinking prevents going in circles.** Diagnostics give data; analysis gives understanding.

**5. Fix the right thing.**

The goal is **the best product**, not passing tests.

| Fix | When Appropriate |
|-----|------------------|
| Fix the code | Code doesn't match spec/design |
| Fix the test | Test doesn't match what it claims to test |
| Fix the proof | Proof has wrong assumptions |
| Fix the design | Design is flawed or overconstrained |
| Fix the spec | Spec is ambiguous or incorrect |

**Anti-pattern: Test fraud** — Changing test to match buggy behavior. If code returns wrong value and you change the test's expected value to match — that's fraud.

**6. Validate.**

- Fix addresses root cause, not symptom
- Originally failing test passes
- Related tests pass
- Full suite passes
- Diagnostics removed

### Common Bug Patterns

**Uninitialized state**: Works sometimes, fails other times. Check init order.

**Wrong units/scale**: Values off by 10^3, 10^6, 10^8. Satoshis vs units? BPS vs percent?

**Lookup failure**: NULL returned. Entity exists? Right table? Right key?

**Capacity exceeded**: Rejected despite "reasonable" inputs. Check actual limit vs usage.

**Test/system mismatch**: Test hardcodes values that violate system constraints.

**Virtual intermediate state**: Multi-step operations where step N checks state that step N-1 planned but didn't commit.

### Changing Code for Debuggability

It's not just OK to modify code for debugging — it's often necessary:

- Add unique error codes per return path
- Restructure to make data flow visible
- Add state validation with clear messages

"If only the code did X, this would be trivial to fix" — maybe the code SHOULD do X.

---

## Decision Framework

**When starting something new:**
1. What's the goal? (10 minutes, top-down)
2. What's the hardest part? (identify risk)
3. Can I reframe it simpler? (question the problem)
4. Can I disprove it quickly? (prototype the scary bit)
5. Is the design flexible enough to survive coding?
6. Am I spending time or burning it?

**When a solution feels complex:**
1. Stop. Complex solutions are a smell.
2. What problem am I actually solving?
3. Can I change a threshold/constant instead of adding code?
4. Can I reuse existing machinery?
5. What would the 10-line solution look like?

**When coding reveals a better way:**
1. How big is the improvement? (10x? 2x? 1.1x?)
2. How much rework?
3. Is the current design blocking the improvement?
4. Time cost vs value gained?

If big improvement + acceptable rework → **do it**.

**When debugging goes in circles:**
1. Stop adding diagnostics.
2. Read the test name — what should this test?
3. Read the code — what is it trying to do?
4. What assumption is violated?
5. Should the assumption be enforced or removed?

---

## When to Redesign

**Always consider it when**:
- Bottom-up coding reveals simpler structure
- A "hard" problem dissolves with different framing
- New capability becomes possible (10x value)
- Current design fights the code at every turn
- Debugging reveals fundamental flaw

**Resist redesign when**:
- Improvement is marginal (1.1x)
- Rework cost exceeds value
- You're in Phase C and it's not a correctness issue
- It's perfectionism, not pragmatism

---

## Time Heuristics

| Activity | Phase A | Phase B | Phase C | Phase D |
|----------|---------|---------|---------|---------|
| Design thinking | 20% | 10% | 5% | 10% |
| Coding | 70% | 60% | 30% | 30% |
| Testing | 5% | 25% | 30% | 10% |
| Formal verification | 0% | 5% | 35% | 0% |
| Debugging/analysis | 5% | 0% | 0% | 50% |

---

## Anti-Patterns

❌ Perfect design before first line of code (chess paralysis)
❌ No design, just code (constant dead ends)
❌ Refusing to change solidified design despite evidence (sunk cost)
❌ Unit tests during Phase A (testing liquid code)
❌ Skipping Phase C for critical systems (false confidence)
❌ Treating Phase A mistakes as failures (they're data)
❌ New module + complex interactions + complex state (monkey solution)
❌ Accepting "you have to do it the hard way" without questioning
❌ Solving the problem as stated instead of reframing it
❌ Shotgun debugging — random changes hoping something works
❌ Circular debugging — same attempts without new analysis
❌ Test fraud — changing expected values to match buggy output
❌ Sacred artifacts — refusing to change code/test/proof/design when needed

---

## Mindset

- **Optimize for time** — not perfection
- **Simplicity is the goal** — complexity is the enemy
- **Nothing is sacred** — everything can change to serve correctness
- **It's OK to be wrong** — mistakes are data, not failures
- **Be systematic** — methodical beats clever
- **Think periodically** — tactics need strategy
- **Flexibility enables progress** — rigidity creates dead ends
