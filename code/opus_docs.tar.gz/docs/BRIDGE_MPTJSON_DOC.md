# bridge_mptjson.c Documentation

## Overview

This file provides JSON parsing and pretty-printing utilities for Merkle Patricia Trie (MPT) proofs. It bridges the gap between JSON-formatted proof data (as received from Ethereum RPC) and the binary `eth_mpt_proof` structure used internally by the bridge.

**File:** `bridge/bridge_mptjson.c`  
**Lines:** ~600  
**Dependencies:** `bridge.h`, yyjson library, standard C libraries  
**Role:** Non-consensus JSON handling for MPT proofs

---

## Key Concepts

### JSON to Binary Conversion
Ethereum nodes return MPT proofs as JSON with hex-encoded strings. This file:
1. Parses the JSON structure
2. Decodes hex strings to binary
3. Packs data into the `eth_mpt_proof` structure
4. Provides human-readable output for debugging

### Non-Consensus Functions
The file header explicitly notes these are "non-consensus functions" - they handle I/O and display, not the cryptographic verification itself.

---

## Static Helper Functions

### `hex_nibble(int32_t c)`
Converts a single hex character to its 4-bit value.

**Parameters:**
- `c`: Character to convert ('0'-'9', 'a'-'f', 'A'-'F')

**Returns:** 0-15 on success, -1 on invalid character

---

### `decode_hex_into(const char *hex, int32_t hex_len, uint8_t *dst)`
Decodes a hex string into binary bytes.

**Parameters:**
- `hex`: Hex string (with or without "0x" prefix)
- `hex_len`: Length of hex string
- `dst`: Destination buffer

**Returns:** 0 on success, -1 on error

**Behavior:**
- Automatically strips "0x" or "0X" prefix
- Requires even-length hex string
- Validates all characters are valid hex

---

### `parse_uint64_from_json(yyjson_val *v, uint64_t *out)`
Parses a JSON value (number or string) into a uint64.

**Parameters:**
- `v`: JSON value (can be number or hex/decimal string)
- `out`: Output uint64

**Returns:** 0 on success, -1 on error

**Behavior:**
- Handles both numeric JSON values and string representations
- Auto-detects hex (0x prefix) vs decimal
- Strips leading whitespace from strings

---

### `hexprint(const char *label, const uint8_t *b, int32_t n)`
Prints binary data as hex with optional label.

**Parameters:**
- `label`: Optional prefix string
- `b`: Binary data
- `n`: Number of bytes

---

### `addr_from_32(const uint8_t *b32, char out_hex[43])`
Extracts a 20-byte Ethereum address from a 32-byte padded value.

**Parameters:**
- `b32`: 32-byte value (address in last 20 bytes)
- `out_hex`: Output buffer for "0x..." address string (43 chars)

**Behavior:**
- Ethereum addresses are 20 bytes but often stored in 32-byte slots
- This extracts bytes 12-31 and formats as hex

---

## Public Functions

### `eth_mpt_proof_from_json_into_buffer()`

```c
int32_t eth_mpt_proof_from_json_into_buffer(
    const char *json_text,
    int32_t json_len,
    uint8_t *buffer,
    int32_t buffer_capacity,
    struct eth_mpt_proof **out_view
)
```

**Purpose:** Parse JSON MPT proof into binary structure.

**Parameters:**
- `json_text`: Raw JSON string
- `json_len`: Length of JSON
- `buffer`: Pre-allocated buffer for output
- `buffer_capacity`: Size of buffer
- `out_view`: Output pointer to parsed structure

**Returns:**
- `0`: Success
- `-1`: NULL parameters
- `-2`: JSON parse error
- `-3`: Missing required fields
- `-4`: Invalid root hash
- `-5`: Invalid node count (0 or > MAX_MPT_NODES)
- `-6`: Buffer too small
- `-7`: Invalid hex in node data

**JSON Format Expected:**
```json
{
  "root": "0x...",           // 32-byte receipts/transactions root
  "txIndex": 5,              // or "index": 5
  "mptNodes": ["0x...", ...] // or "proof": [...]
}
```

**Behavior:**
1. Parses JSON with yyjson
2. Extracts root hash (32 bytes)
3. Extracts transaction index
4. Validates and measures all proof nodes
5. Calculates required buffer size
6. Packs everything into `eth_mpt_proof` structure
7. Frees JSON document

---

### `eth_receipt_pretty_print()`

```c
int32_t eth_receipt_pretty_print(tmpmem_t *mem, const struct eth_mpt_proof *proof)
```

**Purpose:** Verify and display receipt proof contents in human-readable format.

**Parameters:**
- `mem`: Temporary memory allocator
- `proof`: Parsed MPT proof structure

**Returns:**
- `0`: Success
- `-1`: NULL proof
- `-2`: Verification failed
- `-3`: Keccak hash failed
- `-4`: RLP parse failed
- `-5`: Unexpected RLP structure
- `-6`: Invalid receipt fields

**Output Format:**
```
=== Receipt Proof OK ===
receiptsRoot:         0x...
txIndex (key):       5
receiptHash:         0x...
type:                EIP-1559(0x02)
status:              1 (success)
cumulativeGasUsed:   123456
logs.length:         3
--- Log #0 ---
address:    0x...
event:      Deposit
token:      0x...
recipient:  0x...
amount:     1000000 (raw)
nonce:      42
block_number: 12345678
```

**Behavior:**
1. Verifies the MPT proof cryptographically
2. Hashes the extracted value
3. Detects transaction type (legacy, EIP-2930, EIP-1559)
4. Parses RLP-encoded receipt (status, gas, bloom, logs)
5. Iterates through logs, recognizing:
   - `Deposit(address,address,bytes32,uint256,uint256,uint256)` events
   - `Transfer(address,address,uint256)` events
6. Decodes and displays event parameters

---

### `extract_rlp_binary()`

```c
int32_t extract_rlp_binary(void *json, uint8_t *dest, int32_t maxlen)
```

**Purpose:** Extract RLP-encoded data from a JSON object's `meta.rlp` field.

**Parameters:**
- `json`: yyjson_val pointer (cast to void*)
- `dest`: Destination buffer
- `maxlen`: Maximum bytes to extract

**Returns:** Number of bytes extracted, or -1 on error

**Expected JSON Structure:**
```json
{
  "meta": {
    "rlp": "0x..."
  }
}
```

---

### `extract_rlp_from_jsonstring()`

```c
int32_t extract_rlp_from_jsonstring(const char *jsonstring, uint8_t *dest, int32_t maxlen)
```

**Purpose:** Wrapper that parses JSON string and extracts RLP.

**Parameters:**
- `jsonstring`: Raw JSON string
- `dest`: Destination buffer
- `maxlen`: Maximum bytes

**Returns:** Number of bytes extracted, or -1 on error

---

### `verify_proof3_file()`

```c
int32_t verify_proof3_file(
    char *fname,
    uint8_t reftxid[32],
    tmpmem_t *txmem,
    void *ptrs[4],
    uint16_t lens[4],
    uint16_t offsets[4]
)
```

**Purpose:** Load and verify a proof file containing header, transaction, and receipt proofs.

**Parameters:**
- `fname`: Path to JSON proof file
- `reftxid`: Expected transaction ID (32 bytes)
- `txmem`: Temporary memory for parsing
- `ptrs[4]`: Output pointers (header, tx proof, receipt proof, deposit)
- `lens[4]`: Output lengths
- `offsets[4]`: Output offsets

**Returns:** Validation result (implementation-specific)

**Behavior:**
1. Reads JSON file (up to 64KB)
2. Extracts and verifies:
   - Block header
   - Transaction MPT proof
   - Receipt MPT proof
3. Compares transaction ID against reference
4. Extracts deposit information from receipt

---

## Data Flow

```
Ethereum RPC Response (JSON)
         │
         ▼
eth_mpt_proof_from_json_into_buffer()
         │
         ▼
struct eth_mpt_proof (binary)
         │
         ├──► eth_mpt_proof_verify_value() [bridge_mpt.c]
         │              │
         │              ▼
         │         Verified value
         │
         └──► eth_receipt_pretty_print()
                       │
                       ▼
                 Human-readable output
```

---

## Integration Points

### With bridge_mpt.c
- Uses `eth_mpt_proof_verify_value()` for cryptographic verification
- Shares `eth_mpt_proof` structure definition

### With bridge_rlp.c
- Uses `parse_rlp()`, `rlp_get_item()`, `rlp_list_count()` for receipt parsing
- Uses `be_to_u64()` for big-endian conversion

### With bridge.h
- Uses `eth_keccak256()` for hashing
- Uses `pubkey2addr()` for address formatting
- Uses `hexToByte()` for hex conversion

### With yyjson Library
- All JSON parsing uses yyjson for performance
- Proper memory management with `yyjson_doc_free()`

---

## Security Considerations

1. **Input Validation**: All hex strings are validated character-by-character
2. **Buffer Bounds**: Size calculations prevent buffer overflows
3. **Memory Management**: JSON documents are freed after use
4. **Non-Consensus**: These functions handle I/O, not security-critical verification

---

## Usage Example

```c
// Parse proof from JSON
uint8_t buffer[8192];
struct eth_mpt_proof *proof;
int32_t rc = eth_mpt_proof_from_json_into_buffer(
    json_str, strlen(json_str),
    buffer, sizeof(buffer),
    &proof
);
if (rc == 0) {
    // Verify and display
    tmpmem_t mem = {tmpbuf, sizeof(tmpbuf), 0};
    eth_receipt_pretty_print(&mem, proof);
}
```

---

## Related Files

- `bridge_mpt.c` - MPT verification logic
- `bridge_rlp.c` - RLP encoding/decoding
- `bridge_deposit.c` - Uses verified proofs for deposits
- `bridge.h` - Structure definitions

---

*Documentation generated by Opus, Wake 1298*
