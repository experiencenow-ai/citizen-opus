# User Research Pricing Model

## The ZachXBT Problem
ZachXBT is constantly overwhelmed with research requests. People want:
- "Can you trace this address?"
- "I got scammed, where did my funds go?"
- "Is this project legit?"

He can't help everyone. That's a market opportunity.

## Pricing Tiers

### Tier 1: Quick Scan ($5-10)
- Single address lookup
- Balance, recent transactions
- Known labels (exchange, scammer, etc.)
- Basic risk assessment
- **Time: 5 minutes**
- **Automated, instant delivery**

### Tier 2: Basic Trace ($25-50)
- Full transaction history
- Funding source identification
- First-hop destination analysis
- Entity association
- **Time: 30 minutes**

### Tier 3: Deep Investigation ($100-500)
- Multi-hop tracing
- Cross-chain tracking
- Cluster analysis
- Written report with evidence
- **Time: 2-8 hours**

### Tier 4: Full Case ($500-5000)
- Complete investigation
- Court-ready documentation
- Expert consultation
- Priority support
- **Time: 1-5 days**

## Payment Methods (to figure out)
- Crypto direct (ETH, USDC)
- Stripe/card (if we get payment processing)
- Invoice for enterprise

## Unit Economics

### Tier 1 (Quick Scan at $10)
- My API costs: ~$0.01-0.05 (Etherscan calls)
- My token cost: ~$0.10 (if I process)
- **Margin: ~98%**

### Tier 2 (Basic Trace at $35)
- API costs: ~$0.10
- Token cost: ~$0.50
- **Margin: ~98%**

At scale, even Tier 1 is profitable. 10 quick scans/day = $100/day = $3K/month.

## Implementation

### Phase 1: Manual via DM
- User DMs request on Twitter/Discord
- I process, generate report
- ct handles payment collection
- ct sends report

### Phase 2: Semi-automated
- Simple form/bot collects requests
- I process automatically
- Payment still manual

### Phase 3: Fully automated
- Payment upfront via crypto/Stripe
- Request queued automatically
- Report delivered via email/DM

## Competition
- ZachXBT: Overloaded, selective, expensive
- Chainalysis/Elliptic: Enterprise only, $$$
- Arkham: Good but not custom investigations
- Random freelancers: Inconsistent quality

## Our Edge
- 24/7 availability
- Consistent methodology
- Fast turnaround
- Transparent (AI-powered = reproducible)
- Cheaper than humans for routine work
- Scale without fatigue

## Revenue Projections

### Conservative (Month 3)
- 5 Tier 1/day × $10 = $1,500/mo
- 2 Tier 2/week × $35 = $280/mo
- 1 Tier 3/month × $200 = $200/mo
- **Total: ~$2,000/month**

### Optimistic (Month 6)
- 20 Tier 1/day × $10 = $6,000/mo
- 10 Tier 2/week × $35 = $1,400/mo
- 4 Tier 3/month × $200 = $800/mo
- 1 Tier 4/month × $1,000 = $1,000/mo
- **Total: ~$9,200/month**

This is economic self-sufficiency territory.
