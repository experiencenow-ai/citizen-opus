# bridge_rlp.c - RLP Encoding/Decoding for Ethereum Bridge

**File:** `bridge/bridge_rlp.c`  
**Lines:** 970  
**Created:** 2025-10-22  
**Documented by:** Opus (Wake 1279)  
**Status:** Ready for audit

---

## Purpose

This file implements **Recursive Length Prefix (RLP)** encoding and decoding, the serialization format used by Ethereum for transactions, receipts, and Merkle Patricia Trie proofs. It's essential for the Ethereum bridge to:

1. Encode transactions for signing and broadcast
2. Decode Merkle proofs to verify deposits
3. Parse receipt logs to extract Deposit and Transfer events

---

## RLP Format Overview

RLP encodes arbitrary data into a compact binary format:

| Prefix Range | Meaning |
|--------------|---------|
| `0x00-0x7f` | Single byte (no header needed) |
| `0x80-0xb7` | Short string (0-55 bytes), length in prefix |
| `0xb8-0xbf` | Long string (>55 bytes), length-of-length in prefix |
| `0xc0-0xf7` | Short list (0-55 bytes payload) |
| `0xf8-0xff` | Long list (>55 bytes payload) |

---

## Key Data Structures

### `struct rlp_item`
```c
struct rlp_item {
    const uint8_t *data;  // Pointer to content (not including header)
    int32_t len;          // Length of content
    int is_list;          // 1 if list, 0 if string/bytes
};
```

### `receipt_deposit_t` / `receipt_transfer_t`
Parsed event structures (defined in bridge.h) populated by receipt parsing functions.

---

## Function Categories

### 1. Length Calculators (`rlp_calc_len_*`)

Calculate encoded length without actually encoding. Used for buffer allocation.

| Function | Purpose |
|----------|---------|
| `rlp_calc_len_bytes(src, len)` | Length of RLP-encoded byte string |
| `rlp_calc_len_list(payload_len)` | Length of RLP list with given payload |
| `rlp_calc_len_uint64(v)` | Length of minimal uint64 encoding |
| `rlp_calc_len_address(addr20, is_null)` | Length of 20-byte address or empty |
| `rlp_calc_len_u256_be32(be32)` | Length of 256-bit integer (trims zeros) |
| `rlp_calc_len_data(p, len)` | General data length |

### 2. Writers (`rlp_write_*`)

Encode data to a buffer. All return pointer advanced past written bytes.

| Function | Purpose |
|----------|---------|
| `rlp_write_bytes(dst, src, len)` | Write byte string with header |
| `rlp_write_list(dst, payload_len)` | Write list header only |
| `rlp_write_uint64(dst, v)` | Write minimal uint64 |
| `rlp_write_address(dst, addr20, is_null)` | Write address or empty |
| `rlp_write_u256_be32(dst, be32)` | Write 256-bit int (trimmed) |
| `rlp_write_data(dst, p, len)` | Write arbitrary data |

### 3. Parsers

| Function | Purpose |
|----------|---------|
| `parse_rlp(input, input_len, item)` | Parse single RLP item, returns bytes consumed |
| `rlp_list_count(list)` | Count items in a parsed list |
| `rlp_get_item(list, idx, out)` | Extract item at index from list |
| `rlp_u64_be(item)` | Extract uint64 from parsed item |

### 4. Receipt/Event Parsing

These functions extract Deposit and Transfer events from Ethereum receipts:

| Function | Purpose |
|----------|---------|
| `eth_mpt_proof_get_typed_receipt(proof, typed, tlen)` | Extract receipt bytes from MPT proof |
| `eth_receipt_parse_events(typed, tlen, mem, ...)` | Parse all events from receipt |
| `eth_receipt_parse_from_proof(mem, proof, ...)` | Combined: proof → events |
| `eth_receipt_plan_sizes(typed, tlen, ...)` | Pre-count events for allocation |

### 5. Utilities

| Function | Purpose |
|----------|---------|
| `be_len_from_int(val, be_out)` | Convert int to big-endian bytes |
| `be_right_copy_hex(out32, contractaddr)` | Parse hex address to right-aligned 32 bytes |
| `rlp_item_addr20(item, out20)` | Extract 20-byte address from item |
| `get_event_sigs(dep, tr)` | Get cached Deposit/Transfer event signatures |
| `rlp_encode_hash(mem, hash, out, outlen)` | Encode 32-byte hash |

---

## Event Signatures

The file recognizes two Ethereum event types:

```
Deposit(address,address,bytes32,uint256,uint256,uint256)
Transfer(address,address,uint256)
```

These are keccak256-hashed and cached on first use via `get_event_sigs()`.

---

## Usage Patterns

### Encoding a Transaction Field
```c
// Calculate total length first
int len = rlp_calc_len_uint64(nonce) + 
          rlp_calc_len_u256_be32(gas_price) + ...;
int total = rlp_calc_len_list(len);

// Allocate and write
uint8_t *buf = malloc(total);
uint8_t *p = rlp_write_list(buf, len);
p = rlp_write_uint64(p, nonce);
p = rlp_write_u256_be32(p, gas_price);
// ...
```

### Parsing a Receipt Proof
```c
receipt_deposit_t *deposits;
receipt_transfer_t *transfers;
int32_t dep_n, tr_n;

int rc = eth_receipt_parse_from_proof(
    mem, proof,
    &deposits, &dep_n,
    &transfers, &tr_n
);
if (rc == 0) {
    // Process deposits and transfers
}
```

---

## Backward Compatibility Wrappers

The file maintains older API names for compatibility:

| Old Name | Maps To |
|----------|---------|
| `rlp_len_bytes(len)` | `rlp_calc_len_bytes(dummy, len)` |
| `rlp_len_uint64(v)` | `rlp_calc_len_uint64(v)` |
| `rlp_len_u256(be32)` | `rlp_calc_len_u256_be32(be32)` |
| `rlp_write_u256(dst, be32)` | `rlp_write_u256_be32(dst, be32)` |
| `rlp_len_list_prefix(len)` | Calculates header-only length |

---

## Dependencies

- `_valis.h` - Core types and utilities
- `bridge.h` - Bridge structures (`eth_mpt_proof`, event types)
- External: `eth_keccak256()` for event signature hashing
- External: `hexToByte()` for hex string conversion
- External: `be_from_u64_min()` for minimal big-endian conversion

---

## Error Handling

All parsing functions return negative values on error:
- `-1`: NULL input or invalid parameters
- `-2` to `-11`: Specific parsing failures (malformed RLP, wrong structure)

Writers assume valid input and sufficient buffer space - caller must pre-calculate lengths.

---

## Security Considerations

1. **Buffer bounds**: Parsers check `input_len` before accessing data
2. **Integer overflow**: Length calculations use `int32_t` - very large inputs could overflow
3. **Zero-copy parsing**: `rlp_item.data` points into original buffer - don't free input while using items
4. **Typed receipts**: Handles EIP-2718 type prefixes (0x01, 0x02)

---

## Build Integration

Compiled as `bridge/bridge_rlp.o` and linked into:
- `test` (main test harness)
- `wsdprog` (WebSocket daemon)
- `txblast` (stress testing)
- `sendtx` (transaction sender)

---

## Notes

- File uses `#ifndef H_BRIDGE_RLP` guard suggesting it may be `#include`d rather than separately compiled in some configurations
- The "canonical" prefix on newer functions indicates a cleanup/standardization effort
- Event parsing is specific to the Valis bridge contract's Deposit event format
