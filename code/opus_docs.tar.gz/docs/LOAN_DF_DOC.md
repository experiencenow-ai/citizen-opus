# LOAN Dataflow Documentation

**File:** `/root/valis/DF/LOAN.c`  
**Version:** v1.7  
**Lines:** 960  
**Purpose:** Fixed-spread gradient credit system with collateralized lending

---

## Overview

LOAN.c implements a **collateralized lending protocol** as a Tockchain dataflow program. Each user address maintains a single-collateral loan vault where they can:

1. Deposit collateral
2. Borrow VCREDIT against that collateral
3. Repay debt
4. Withdraw collateral

The system features **gradient liquidation** - a continuous deleveraging mechanism that gradually sells collateral as LTV increases, rather than sudden liquidation events.

---

## Architecture

### Execution Modes

| Mode | Trigger | UFC Access | Price Source |
|------|---------|------------|--------------|
| **LIGHT** | Scheduler scan (frontier/hourly) | Forbidden | Cached price in ctx |
| **HEAVY** | Worst offender processing | Allowed | UFC price query |

- **LIGHT mode**: Fast scoring-only pass for ranking vaults by risk
- **HEAVY mode**: Can execute one bounded deleveraging step via UFC

### State Storage

All persistent state is stored in **SRC registers** (per-address regbank):

| Register | Name | Description |
|----------|------|-------------|
| S0 | `LOAN_REG_SCORE` | Packed severity (16 bits) + debt (48 bits) |
| S1 | `LOAN_REG_COLL_QTY` | Collateral quantity (int64) |
| S2 | `LOAN_REG_DEBT_VC` | VCREDIT debt (principal + accrued interest) |
| S3 | `LOAN_REG_HEALTH_BPS` | Health factor 0-10000 (100% = healthy) |
| S4 | `LOAN_REG_RATE_BPS` | APR in basis points at last borrow |

---

## Collateral Classes

The system supports three collateral tiers with different risk parameters:

```c
typedef enum {
    LOAN_CLASS_TIER1     = 0,  // High-quality collateral
    LOAN_CLASS_SECONDARY = 1,  // Medium-quality
    LOAN_CLASS_VUSD      = 2   // Stablecoin (special handling)
} loan_coll_class_t;
```

### Class Parameters

```c
typedef struct loan_class_params_s {
    int32_t ltv_max_bps;        // Maximum LTV allowed for new borrows
    int32_t ltv_grad_start_bps; // LTV where gradient starts
    int32_t ltv_grad_stop_bps;  // LTV where gradient reaches max
    int32_t ltv_liq_bps;        // LTV at full liquidation rate
    
    int32_t rate_min_bps;       // Minimum interest rate
    int32_t rate_max_bps;       // Maximum interest rate
    int32_t spread_bps;         // Spread over risk-free rate
    
    int32_t grad_g_max_ppm;     // Max debt fraction per second at LTV_liq
} loan_class_params_t;
```

---

## Core Calculations

### Collateral Value

```c
coll_value_vusd = (coll_qty * price_scaled) / SCALE_P
```

### Loan-to-Value (LTV)

```c
ltv_bps = (debt_vc * BPS_DENOM) / coll_value_vusd
```

### Health Factor

```c
health_bps = BPS_DENOM - ltv_bps  // 10000 = fully healthy, 0 = underwater
```

### Score Packing

The score register packs severity and debt for efficient sorting:

```c
score = (severity << 48) | (debt & 0xFFFFFFFFFFFF)
// severity = BPS_DENOM - health_bps (higher = worse)
```

---

## Interest Accrual

Interest accrues per-tock (per second):

```c
d_debt = (debt_vc * rate_bps) / (BPS_DENOM * TOCKS_PER_YEAR)
```

Where `TOCKS_PER_YEAR = 31,536,000` (seconds in a year).

---

## Gradient Liquidation

Instead of sudden liquidation, the system uses **continuous gradient deleveraging**:

### Gradient Rate Calculation

```c
if (ltv < ltv_grad_start)
    g_ppm = 0;  // No deleveraging needed
else if (ltv >= ltv_liq)
    g_ppm = grad_g_max_ppm;  // Full rate
else
    g_ppm = grad_g_max_ppm * (ltv - ltv_grad_start) / (ltv_liq - ltv_grad_start);
```

### Gradient Step Execution

Each HEAVY mode call can execute one bounded step:

1. Calculate `repay_target = debt * g_ppm / PPM_DENOM`
2. Determine collateral to sell: `coll_to_sell = repay_target / price`
3. Execute UFC swap: collateral → VUSD
4. Route VUSD to repay debt via VCPOOL par window

---

## Operations (Opcodes)

### Op 0: Initialize

Reset vault to clean state. Only allowed if vault is empty.

### Op 1: Deposit Collateral

Transfer collateral from SRC address to DF vault.

```
userdata[0] = 1
userdata[1..8] = amount (int64)
```

### Op 2: Borrow VCREDIT

Borrow against deposited collateral.

```
userdata[0] = 2
userdata[1..8] = amount (int64)
```

Constraints:
- New LTV must be ≤ `ltv_max_bps`
- Sets interest rate to `risk_free_rate + spread`

### Op 3: Repay Debt

Repay VCREDIT debt.

```
userdata[0] = 3
userdata[1..8] = amount (int64)
```

Routes through VCPOOL par window (1:1 VUSD → VCREDIT).

### Op 4: Withdraw Collateral

Withdraw collateral to SRC address.

```
userdata[0] = 4
userdata[1..8] = amount (int64)
```

Constraints:
- Post-withdrawal LTV must remain ≤ `ltv_max_bps`

### Op 5: Close Vault

Full repayment and collateral withdrawal.

---

## Entry Points

### `df_on_dataflowtx(ap, ctx)`

Handles user-initiated transactions (deposit, borrow, repay, withdraw).

**Flow:**
1. Sync collateral quantity to actual DF balance
2. Accrue interest on existing debt
3. Parse opcode and amount from userdata
4. Execute operation
5. Recompute health and score
6. Update installed flags

### `df_on_score(ap, ctx, price_scaled)`

Called by scheduler for scoring passes.

**Flow:**
1. Sync collateral quantity
2. Accrue interest
3. Recompute health and score using provided price
4. If HEAVY mode and underwater: execute gradient step

---

## Safety Mechanisms

### Balance Sync

```c
static void loandf_sync_coll_qty_to_df_balance(df_ctx_t *ctx, int32_t col_coll)
```

Ensures `LOAN_REG_COLL_QTY` never exceeds actual on-chain balance. Prevents accounting discrepancies.

### Installed Flags

```c
#define DF_INSTFLAG_LOCKED       (1u << 0)  // Vault has collateral or debt
#define DF_INSTFLAG_NEEDS_SCORE  (1u << 1)  // Vault needs scoring attention
```

These flags control scheduler behavior:
- `LOCKED`: Prevents premature uninstallation
- `NEEDS_SCORE`: Includes vault in scoring passes

### Dust Threshold

```c
#define LOAN_MIN_PRINCIPAL_VC (1000LL)
```

Vaults with debt below this threshold are treated as closed.

---

## Scale Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| `LOAN_SCALE_P` | 10^8 | Price scaling factor |
| `LOAN_BPS_DENOM` | 10,000 | Basis points denominator |
| `LOAN_PPM_DENOM` | 1,000,000 | Parts per million denominator |
| `LOAN_TOCKS_PER_YEAR` | 31,536,000 | Seconds per year |

---

## Compile-Time Configuration

Required defines:
- `LOAN_COLL_ASSET_ID`: Asset ID for collateral token
- `LOAN_VUSD_ASSET_ID`: Asset ID for VUSD stablecoin

---

## Integration with Other Systems

### UFC (Universal Finance Core)

- Gradient liquidation uses UFC to swap collateral for VUSD
- Price queries via `df_price()` and `df_price_ema()`

### VCPOOL

- Debt repayment routes through VCPOOL par window
- VUSD converts 1:1 to VCREDIT for repayment

### Dataflow Scheduler

- LIGHT mode scoring for frontier management
- HEAVY mode for worst-offender processing

---

## Key Design Decisions

1. **Single-collateral vaults**: Simplifies accounting and risk management
2. **Gradient liquidation**: Smoother than cliff liquidations, reduces MEV
3. **Per-second interest**: Continuous accrual, no batch updates needed
4. **Score packing**: Efficient sorting by risk + debt size
5. **VCPOOL integration**: Native stablecoin repayment mechanism

---

*Documentation generated by Opus, Wake 1317*
