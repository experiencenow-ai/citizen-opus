# Tockchain Dataflow Header Documentation

**File:** `DF/dataflow.h` (408 lines)  
**Author:** ct  
**Documented by:** Opus (Wake 1290)  
**Last Updated:** 2026-01-13

---

## Overview

`dataflow.h` is the central header file for Tockchain's smart contract (Dataflow) module. It defines:

1. **Configuration constants** - Gas prices, limits, file paths
2. **Core data structures** - Context, cache slots, execution state
3. **API declarations** - Functions for transfers, swaps, credit, pipes

The header notes that helper IDs and gas costs are defined in `df_sdk.h` as the single source of truth.

---

## File Dependencies

```c
#include "ebpf.h"      // eBPF instruction definitions
#include "_valis.h"    // Core Valis types
#include "ufc.h"       // Unified Finance Core
#include "ledger.h"    // Ledger operations
#include "df_sdk.h"    // SDK for dataflow contracts
```

---

## Configuration Constants

### File Paths

```c
#define DF_DEPLOYLOG_PATH "df_blob.bin"      // Deployment log
#define DF_OPSLOG_PATH "df_ops.bin"          // Operations log
#define DF_OPSLOG_MAX_BYTES (1ULL << 36)     // 64 GB max ops log
```

### Gas System

```c
// Base gas pricing
#define DF_GAS_PRICE_VUSD_SAT         1000    // 1000 satoshis per gas unit
#define DF_GAS_QUANTUM                100     // Gas charged in multiples of 100

// Gas caps for different contexts
#define DF_BATCH_GAS_CAP              1000000     // Max gas per batch TX (~$10)
#define DF_UTIME_GAS_CAP              4000000000  // Max gas per utime (~1 sec on 8 cores)
#define DF_FRONTIER_GAS_CAP           2000        // Max gas for frontier on_score
#define DF_TRIGGER_GAS_CAP            2000        // Max gas for trigger check
```

**Derived values:**
```c
#define DF_GAS_QUANTUM_VUSD           (DF_GAS_QUANTUM * DF_GAS_PRICE_VUSD_SAT)
#define DF_BATCH_GAS_CAP_VUSD         (DF_BATCH_GAS_CAP * DF_GAS_PRICE_VUSD_SAT)
// etc.
```

### Execution Limits

```c
#define DF_TRIG_MAX_SRCS_PER_TOCK     4096    // Max trigger sources per tock
#define DF_TRIG_MAX_INTENTS_PER_TOCK  4096    // Max intents per tock
#define DF_TRIG_MAX_INTENTS_PER_CALL  64      // Max intents per call
#define DF_MATRIX_MAX_CALLS           16      // Max calls in matrix
#define DF_MAX_PIPES_PER_BATCH        8       // Max pipes per batch
#define DF_PIPE_MAX_BYTES_ONE         2048    // Max bytes per pipe
#define DF_PIPE_MAX_BYTES_TOTAL       16384   // Max total pipe bytes
#define DF_MAX_TRANSFERS_PER_TX       64      // Max transfers per transaction
#define DF_MAX_EFFECTS_PER_TX         32      // Max effects per transaction
#define DF_MAX_CROSS_DELTAS           16      // Max cross-DF deltas
#define DF_MAX_SWAPS_PER_TX           4       // Max swaps per transaction
```

---

## Core Data Structures

### `df_ctx_t` - Execution Context

The execution context passed to dataflow contracts. Contains:
- Current state references
- Register values
- Asset balances
- Execution metadata

### `df_cache_slot_t` - Cached Contract Entry

```c
typedef struct {
    df_tablekey_u64_t key;        // Lookup key (64-bit)
    int64_t crv;                  // Contract reserve value
    df_frontier_state_t frontier; // Frontier scheduling state
    df_meta_u_t df_meta;          // Contract metadata
    df_ops_meta_u_t df_ops_meta;  // Operations metadata
    df_op_t *ops;                 // Pointer to translated bytecode
    uint32_t opcount;             // Number of operations
    uint16_t mingas;              // Minimum gas required
    uint16_t reg_base;            // Base register index
    uint8_t reg_count;            // Number of registers used
    uint16_t entrypoint;          // Entry point offset
    // ... additional fields
} df_cache_slot_t;
```

### `df_hostctx_t` - Host Context

```c
typedef struct {
    df_spend_entry_t spend[DF_MAX_TRANSFERS_PER_TX];
    uint16_t spend_count;
    df_effect_entry_t effects[DF_MAX_EFFECTS_PER_TX];
    uint16_t effect_count;
    df_cross_delta_t cross_deltas[DF_MAX_CROSS_DELTAS_PER_TX];
    uint16_t cross_delta_count;
    uint8_t pipe_storage_buf[DF_PIPE_MAX_BYTES_TOTAL];
} df_hostctx_t;
```

Holds accumulated effects during contract execution.

### `df_batch_sections_t` - Batch Transaction Sections

```c
typedef struct {
    df_spend_entry_t *spend;      uint16_t spend_count;
    assetid_t *assetctx;          uint16_t asset_count;
    df_batch_call_t *calls;       uint16_t call_count;
    uint8_t *userdata;            uint32_t userdata_len;
    uint8_t pipe_count, _pad0[3];
} df_batch_sections_t;
```

### `df_regdesc_t` - Register Descriptor

```c
typedef struct {
    int64_t min_val;    // Minimum allowed value
    int64_t max_val;    // Maximum allowed value
    uint32_t flags;     // Behavior flags
} df_regdesc_t;

#define DF_REGCOND_FLAG_FAIL_ON_OUT 0x01  // Fail if value out of range
#define DF_REGCOND_FLAG_CLAMP       0x02  // Clamp value to range
```

---

## API Functions

### Host Context Management

```c
df_hostctx_t *df_hostctx_get(void);      // Get current host context
void df_hostctx_set(df_hostctx_t *H);    // Set host context
```

### Transfer Operations

```c
int32_t df_emit_transfer(
    df_ctx_t *ctx,
    uint8_t from_row,    // Source row in matrix
    uint8_t to_row,      // Destination row
    int32_t col,         // Asset column
    int64_t amount       // Amount to transfer
);
```

Emits a transfer from one account row to another within the execution matrix.

### UFC (Unified Finance Core) Operations

```c
// Swap assets
int32_t df_ufc_emit_swap(
    df_ctx_t *ctx,
    uint8_t fund_row,    // Funding row
    int32_t col_in,      // Input asset column
    int32_t col_out,     // Output asset column
    int64_t amount_in,   // Input amount
    int64_t min_out      // Minimum output (slippage protection)
);

// Deposit to liquidity pool
int32_t df_ufc_emit_pool_deposit(
    df_ctx_t *ctx,
    int32_t pool_col,    // Pool column
    int64_t amt_vusd,    // VUSD amount
    int64_t amt_other,   // Other asset amount
    int64_t min_lp       // Minimum LP tokens to receive
);

// Withdraw from liquidity pool
int32_t df_ufc_emit_pool_withdraw(
    df_ctx_t *ctx,
    int32_t pool_col,    // Pool column
    int64_t lp_in,       // LP tokens to burn
    int64_t min_vusd,    // Minimum VUSD to receive
    int64_t min_other    // Minimum other asset to receive
);

// Place limit order
int32_t df_ufc_emit_limit_order(
    df_ctx_t *ctx,
    uint8_t fund_row,    // Funding row
    int32_t col,         // Asset column
    int32_t is_buy,      // 1 = buy, 0 = sell
    int64_t price,       // Limit price
    int64_t qty          // Quantity
);
```

### Cross-DF Operations

```c
int32_t df_reg_delta_by_df(
    df_ctx_t *ctx,
    const dfid_t *target,  // Target dataflow ID
    uint8_t reg_idx,       // Register index
    int64_t delta          // Delta to apply
);
```

Allows one dataflow contract to modify registers in another.

### Installation Management

```c
int32_t df_installed_get_flags(df_ctx_t *ctx, uint32_t *out_flags);
int32_t df_installed_set_flags(df_ctx_t *ctx, uint32_t set_mask, uint32_t clr_mask);
int32_t df_installed_uninstall(df_ctx_t *ctx);
```

### Credit Operations

```c
// Borrow against collateral
int32_t df_vcredit_emit_borrow(
    df_ctx_t *ctx,
    uint8_t row,           // Account row
    int64_t amount,        // Borrow amount
    int64_t new_debt,      // New total debt
    int64_t new_health     // New health factor
);

// Repay debt
int32_t df_vcredit_emit_repay(
    df_ctx_t *ctx,
    uint8_t row,           // Account row
    int64_t amount         // Repay amount
);
```

### Pipe Operations (Inter-Contract Communication)

```c
// Get input pipe length
uint16_t df_pipe_in_len(df_ctx_t *ctx);

// Read from input pipe
int32_t df_pipe_in_read(
    df_ctx_t *ctx,
    uint16_t off,          // Offset in pipe
    uint8_t *dst,          // Destination buffer
    uint16_t bytes         // Bytes to read
);

// Append to output pipe
int32_t df_pipe_out_append(
    df_ctx_t *ctx,
    uint16_t msg_type,     // Message type
    const uint8_t *payload,// Payload data
    uint16_t len           // Payload length
);
```

### Cryptographic Operations

```c
// SHA-256 hash
int32_t df_hash256(const uint8_t *data, uint32_t len, uint8_t *out32);

// Signature verification
int32_t df_sig_verify(
    const uint8_t *pubkey,
    const uint8_t *hash,
    const uint8_t *sig,
    int32_t sig_type
);

// Merkle proof verification
int32_t df_merkle_verify(
    const uint8_t *root,
    const uint8_t *leaf,
    uint32_t leaf_index,
    const uint8_t *proof,
    uint32_t proof_len,
    uint32_t tree_size
);
```

### Utility Operations

```c
// Sort array of uint64
int32_t df_sort_u64(uint64_t *arr, uint32_t count, int32_t ascending);

// Weighted random sampling
int32_t df_sample_weighted(
    uint64_t seed,
    const uint64_t *weights,
    uint32_t count,
    uint32_t *out_index
);

// Z-decode (zigzag decode)
int32_t df_z_decode(uint64_t encoded, uint32_t *out_a, uint32_t *out_b);
```

---

## Inline Helpers

```c
// Get asset ID for DF ops metadata
static inline assetid_t df_asset_df_ops_meta(void) {
    assetid_t a = ASSET_DF_META;
    a.iscoin = 1;
    return a;
}

// Extract 62-bit key from dataflow ID
static inline uint64_t df_dfkey62_from_dfid(const uint8_t dfid[PKSIZE]) {
    uint64_t lo64;
    memcpy(&lo64, dfid, 8);
    return lo64 & DF_MARKER_KEY62_MASK;
}
```

---

## ABI Versioning

```c
#define DF_ABI_VERSION_V0        0
#define DF_ABI_VERSION_CURRENT   DF_ABI_VERSION_V0
```

Allows for future ABI changes while maintaining backward compatibility.

---

## Related Files

- `DF/dataflow.c` - Main dataflow implementation
- `DF/vbpf.c` - eBPF virtual machine
- `DF/df_sdk.h` - SDK for writing contracts (helper IDs, gas costs)
- `DF/df_gas.h` - Gas cost definitions
- `DF/ebpf.h` - eBPF instruction definitions
- `DF/dataflow_api.c` - API implementation
- `DF/dataflow_batch.c` - Batch processing
- `DF/dataflow_cache.c` - Contract caching
- `DF/dataflow_frontier.c` - Frontier scheduling
- `DF/dataflow_trigger.c` - Trigger system

---

## Design Notes

1. **Gas Quantum:** Gas is charged in multiples of 100 to reduce precision overhead
2. **Matrix Model:** Execution uses a matrix where rows are accounts and columns are assets
3. **Pipes:** Enable composable contract calls with message passing
4. **Cross-DF:** Contracts can interact with each other's state
5. **Credit System:** Built-in support for borrowing/lending with health factors
