# dataflow_inc.h - Dataflow Shared Types

## Purpose

Defines shared types and constants used by the dataflow (DF) system. This header is included by both the core system and the DF programs themselves, ensuring consistent data structures across the boundary.

## Location
`/root/valis/DF/dataflow_inc.h`

## Constants

```c
#define DF_MATRIX_MAX_ASSET   16      // Max assets in matrix
#define DF_MATRIX_MAX_ADDR    16      // Max addresses in matrix
#define DF_MAX_REGS_PER_DF    24      // Register bank size
#define DF_SCRATCH_BYTES      65535   // Scratch space (64KB)
#define DF_BPS_DENOM          10000   // Basis points denominator
```

## Core Types

### assetid_t
Asset identifier with coin flag:
```c
typedef struct assetid_s { 
    uint16_t aid:NUM_ASSETID_BITS;  // Asset ID
    uint16_t iscoin:1;              // Native coin flag
} assetid_t;
```

### dfid_t
Dataflow identifier (20 bytes, like an address):
```c
typedef struct dfid_s {
    uint8_t bytes[PKSIZE];  // PKSIZE = 20
} dfid_t;
```

## UFC Alpha State

Price/flow tracking for UFC (Unified Finance Core):
```c
typedef struct ufc_alpha_state_s {
    int64_t ema_price_sat;       // EMA of price in satoshis
    int64_t ema_flow_vusd;       // EMA of flow in VUSD
    int32_t flow_rel_bps;        // Relative flow in basis points
    int32_t trend_bps;           // Price trend in basis points
    int32_t jitter_bps;          // Price jitter in basis points
    int32_t premium_rel_bps;     // Premium relative to fair price
    int64_t ema_ob_price_sat;    // EMA orderbook price
    int64_t ema_bpf_price_sat;   // EMA BPF (oracle) price
    int64_t ema_premium_vusd;    // EMA premium in VUSD
} ufc_alpha_state_t;
```

## Asset Column

Per-asset data in the matrix:
```c
typedef struct df_assetcol_s {
    assetid_t asset;              // Asset identifier
    int64_t ufc_price_sat;        // UFC price in satoshis
    int64_t ufc_oob_price_sat;    // Out-of-band price
    int64_t bpf_price_sat;        // BPF oracle price
    int32_t bpf_conf_bps;         // BPF confidence (basis points)
    int32_t _pad0;
    ufc_alpha_state_t alpha;      // Alpha state
} df_assetcol_t;
```

## Matrix Context

The "matrix" provides DFs with a view of assets and balances:
```c
typedef struct df_matrix_ctx_s {
    uint8_t asset_count;                              // Number of assets
    uint8_t addr_count;                               // Number of addresses
    uint16_t _pad0;
    uint8_t addr_pubkey[DF_MATRIX_MAX_ADDR][PKSIZE];  // Address public keys
    df_assetcol_t assetcol[DF_MATRIX_MAX_ASSET];      // Asset data
    int64_t bal[DF_MATRIX_MAX_ADDR][DF_MATRIX_MAX_ASSET];  // Balance matrix
} df_matrix_ctx_t;
```

### Matrix Layout
```
              Asset0  Asset1  Asset2  ...  Asset15
Addr0         bal[0][0]  bal[0][1]  ...
Addr1         bal[1][0]  bal[1][1]  ...
...
Addr15        bal[15][0] ...
```

## DF Context (Read-Only)

Immutable context provided to DF programs:
```c
typedef struct df_ctx_ro_s {
    const void *dfc;              // Opaque core pointer
    uint32_t utime;               // Unix timestamp
    int32_t tx_index;             // Transaction index in block
    int32_t call_index;           // Call index within transaction
    uint16_t call_flags;          // Call flags
    uint8_t pipe_in;              // Input pipe
    uint8_t pipe_out;             // Output pipe
    uint8_t pipe_count;           // Total pipes
    uint8_t cur_df_row;           // Current DF row in matrix
    uint16_t _pad0;
    uint32_t rawtx_bytes;         // Raw transaction size
    uint32_t scratch_ro_bytes;    // Read-only scratch size
    uint32_t scratch_cap_bytes;   // Scratch capacity
    uint64_t per_tx_random_u64;   // Per-transaction random value
    uint8_t txid[32];             // Transaction ID
    uint8_t finalhash[32];        // Final hash
    int64_t regbank_ro[DF_MAX_REGS_PER_DF];    // User register bank (RO)
    int64_t dfregbank_ro[DF_MAX_REGS_PER_DF];  // DF register bank (RO)
    df_matrix_ctx_t matrix;       // Asset/balance matrix
} df_ctx_ro_t;
```

## DF Context (Read-Write)

Mutable state that DFs can modify:
```c
typedef struct df_ctx_rw_s {
    uint8_t userdata[DF_SCRATCH_BYTES];        // Scratch space (64KB)
    uint8_t _pad;
    uint32_t scratch_commit_bytes;             // Bytes to commit
    uint32_t _pad0;
    uint32_t userdata_len;                     // Used userdata length
    int64_t bal_src_rw[DF_MATRIX_MAX_ASSET];   // Source balance changes
    int64_t bal_df_rw[DF_MATRIX_MAX_ASSET];    // DF balance changes
    int64_t regbank_rw[DF_MAX_REGS_PER_DF];    // User register bank (RW)
    int64_t dfregbank_rw[DF_MAX_REGS_PER_DF];  // DF register bank (RW)
} df_ctx_rw_t;
```

## Combined DF Context

Full context combining read-only and read-write sections:
```c
typedef struct df_ctx_s {
    df_ctx_ro_t ro;   // Read-only section
    df_ctx_rw_t rw;   // Read-write section
} df_ctx_t;
```

## Design Principles

### Separation of Concerns
- **RO Section**: Core provides, DF reads
- **RW Section**: DF modifies, core commits

### Fixed Sizes
- Matrix dimensions fixed at compile time
- Enables static verification
- Predictable memory layout

### Basis Points
- Financial values use basis points (1/10000)
- `DF_BPS_DENOM = 10000`
- Example: 50 bps = 0.5%

## Usage in DFs

```c
int32_t df_on_dataflowtx(df_ctx_t *ctx) {
    // Read asset price
    int64_t price = ctx->ro.matrix.assetcol[0].ufc_price_sat;
    
    // Read user balance
    int64_t bal = ctx->ro.matrix.bal[ctx->ro.cur_df_row][0];
    
    // Modify balance
    ctx->rw.bal_src_rw[0] -= 1000;
    ctx->rw.bal_df_rw[0] += 1000;
    
    // Use register bank
    ctx->rw.regbank_rw[0] = ctx->ro.utime;
    
    return 0;
}
```

## Related Files

- `dataflow.h`: Main dataflow header
- `df_sdk.h`: SDK for DF development
- `dataflow.c`: Core dataflow implementation
- `vbpf.c`: eBPF execution engine
