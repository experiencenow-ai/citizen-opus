# bridge_abi.c Documentation

## Overview

**File:** `bridge/bridge_abi.c`  
**Lines:** 1091  
**Functions:** ~50  
**Purpose:** ABI (Application Binary Interface) encoding/decoding for Ethereum smart contract interaction

This file provides utilities for:
1. Building ABI-encoded calldata for contract calls
2. Decoding ABI-encoded return values
3. Making eth_call RPC requests
4. High-level contract interaction wrappers

## Dependencies

```c
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "bridge.h"
```

**External Functions Used:**
- `send_calldata()` - JSON-RPC eth_call
- `bytes_to_0xhex()` - Binary to hex conversion
- `addr_hex_to_20()` - Hex address to bytes

---

## Core Concepts

### ABI Encoding

Ethereum ABI uses 32-byte words with:
- **Static types** - Encoded in-place (uint256, address, bytes32, bool)
- **Dynamic types** - Offset pointer in head, data in tail (bytes, string, arrays)

All integers are big-endian, right-aligned in 32-byte words.

### Function Selectors

First 4 bytes of keccak256(function_signature):
```
transfer(address,uint256) → 0xa9059cbb
```

---

## Data Structures

### vabi_buf_t

Dynamic buffer for building calldata:

```c
typedef struct {
    uint8_t *data;   // Buffer data
    int32_t len;     // Current length
    int32_t cap;     // Capacity
} vabi_buf_t;
```

### vwr_signer_now_t

Return type for isSignerNow query:

```c
typedef struct {
    int ok;          // Is currently a signer
    uint8_t tier;    // Signer tier
    uint32_t epoch;  // Current epoch
    uint64_t weight; // Voting weight
} vwr_signer_now_t;
```

---

## Function Reference

### Buffer Management

#### `vabi_init()`
```c
void vabi_init(vabi_buf_t *b, int32_t initial_cap)
```
Initializes buffer with given capacity. Default 256 if initial_cap <= 0.

#### `vabi_free()`
```c
void vabi_free(vabi_buf_t *b)
```
Frees buffer memory and zeros the struct.

#### `vabi_ensure()`
```c
int vabi_ensure(vabi_buf_t *b, int need)
```
Ensures buffer has room for `need` more bytes. Doubles capacity as needed.

**Returns:** 0 on success, -1 on allocation failure

---

### Hex Utilities

#### `vabi_hex_nibble()`
```c
int vabi_hex_nibble(char c)
```
Converts hex character to value (0-15). Case-insensitive.

**Returns:** 0-15 on success, -1 for invalid character

---

### ABI Encoding (Push Functions)

All push functions return 0 on success, negative on error.

#### `vabi_push_selector()`
```c
int vabi_push_selector(const uint8_t sel4[4], vabi_buf_t *b)
```
Pushes 4-byte function selector.

#### `vabi_push_word()`
```c
int vabi_push_word(const uint8_t *src, int src_len, vabi_buf_t *b)
```
Pushes 32-byte ABI word. Left-pads with zeros if src_len < 32.

#### `vabi_push_u256_from_u64()`
```c
int vabi_push_u256_from_u64(uint64_t v, vabi_buf_t *b)
```
Encodes uint64 as uint256 (big-endian, right-aligned).

#### `vabi_push_u256_from_u32()`
```c
int vabi_push_u256_from_u32(uint32_t v, vabi_buf_t *b)
```
Encodes uint32 as uint256.

#### `vabi_push_u256_from_u16()`
```c
int vabi_push_u256_from_u16(uint16_t v, vabi_buf_t *b)
```
Encodes uint16 as uint256.

#### `vabi_push_u256_from_u8()`
```c
int vabi_push_u256_from_u8(uint8_t v, vabi_buf_t *b)
```
Encodes uint8 as uint256.

#### `vabi_push_bool()`
```c
int vabi_push_bool(bool v, vabi_buf_t *b)
```
Encodes boolean as uint256 (0 or 1).

#### `vabi_push_bytes32()`
```c
int vabi_push_bytes32(const uint8_t h32[32], vabi_buf_t *b)
```
Pushes 32-byte value directly (no padding needed).

#### `vabi_push_address20()`
```c
int vabi_push_address20(const uint8_t a20[20], vabi_buf_t *b)
```
Encodes 20-byte address as uint256 (left-padded with 12 zero bytes).

---

### Dynamic Array Encoding

#### `vabi_push_dyn_address20_array_head_tail()`
```c
int vabi_push_dyn_address20_array_head_tail(
    const uint8_t (*a20)[20],
    int n,
    int head_words,
    vabi_buf_t *b
)
```
Encodes dynamic address array with offset pointer.

**Layout:**
```
[offset to tail] (32 bytes)
... other head params ...
[array length] (32 bytes)
[address 0] (32 bytes)
[address 1] (32 bytes)
...
```

**Parameters:**
- `a20` - Array of 20-byte addresses
- `n` - Number of addresses
- `head_words` - Total words in head section (for offset calculation)

#### `vabi_push_dyn_bytes32_array_head_tail()`
```c
int vabi_push_dyn_bytes32_array_head_tail(
    const uint8_t (*h32)[32],
    int n,
    int head_words,
    vabi_buf_t *b
)
```
Encodes dynamic bytes32 array with offset pointer.

---

### RPC Interaction

#### `vabi_build_params_eth_call()`
```c
void vabi_build_params_eth_call(char *buf, size_t sz, void *userdata)
```
Builds JSON params for eth_call: `[{"to":"...","data":"..."},"latest"]`

#### `vabi_eth_call_hex_result()`
```c
int vabi_eth_call_hex_result(
    const char *to_hex,
    const uint8_t *calldata,
    int calldatalen,
    char *out_hex,
    int out_cap
)
```
Executes eth_call and returns hex result.

**Flow:**
1. Convert calldata to hex
2. Call `send_calldata()`
3. Return hex result string

**Returns:** 0 on success, negative on error

#### `vabi_build_calldata_hex()`
```c
int vabi_build_calldata_hex(
    const uint8_t *calldata,
    int len,
    char *out_hex,
    int out_cap
)
```
Converts binary calldata to "0x..." hex string.

#### `vabi_eth_estimate_gas()`
```c
int vabi_eth_estimate_gas(
    const char *from_hex,
    const char *to_hex,
    const uint8_t *calldata,
    int calldatalen,
    uint64_t *gas_out
)
```
Estimates gas for transaction.

#### `vabi_eth_latest_basefee()`
```c
int vabi_eth_latest_basefee(uint64_t *basefee_out)
```
Gets current base fee from latest block.

#### `vabi_eth_get_tx_receipt_gas_used()`
```c
int vabi_eth_get_tx_receipt_gas_used(
    const char *txhash_0x,
    uint64_t *gas_used_out
)
```
Gets gas used from transaction receipt.

---

### ABI Decoding

#### `vabi_abi_word_at_hex()`
```c
int vabi_abi_word_at_hex(
    const char *hex,
    int byte_offset,
    uint8_t out32[32]
)
```
Extracts 32-byte word from hex string at byte offset.

#### `vabi_be_word_to_u64()`
```c
uint64_t vabi_be_word_to_u64(const uint8_t w[32])
```
Converts big-endian 32-byte word to uint64 (takes last 8 bytes).

#### `vabi_result_word_at()`
```c
int vabi_result_word_at(
    const char *result_hex,
    int word_index,
    uint8_t out32[32]
)
```
Extracts word at index from result (word_index * 32 bytes offset).

#### `vabi_result_u64_at()`
```c
int vabi_result_u64_at(
    const char *result_hex,
    int word_index,
    uint64_t *out
)
```
Decodes uint64 from result at word index.

#### `vabi_result_u32_at()`
```c
int vabi_result_u32_at(
    const char *result_hex,
    int word_index,
    uint32_t *out
)
```
Decodes uint32 from result at word index.

#### `vabi_result_u16_at()`
```c
int vabi_result_u16_at(
    const char *result_hex,
    int word_index,
    uint16_t *out
)
```
Decodes uint16 from result at word index.

#### `vabi_result_u8_at()`
```c
int vabi_result_u8_at(
    const char *result_hex,
    int word_index,
    uint8_t *out
)
```
Decodes uint8 from result at word index.

#### `vabi_result_bool_at()`
```c
int vabi_result_bool_at(
    const char *result_hex,
    int word_index,
    int *out_true
)
```
Decodes boolean from result at word index.

#### `vabi_result_address20_at()`
```c
int vabi_result_address20_at(
    const char *result_hex,
    int word_index,
    uint8_t out20[20]
)
```
Decodes address from result at word index (last 20 bytes of word).

---

### High-Level Call Wrappers

#### `vabi_call_u64_0()`
```c
int vabi_call_u64_0(
    const char *to_hex,
    const uint8_t sel4[4],
    uint64_t *out
)
```
Calls function with no arguments, returns uint64.

#### `vabi_call_u64_u64arg()`
```c
int vabi_call_u64_u64arg(
    const char *to_hex,
    const uint8_t sel4[4],
    uint64_t arg,
    uint64_t *out
)
```
Calls function with one uint64 argument, returns uint64.

#### `vabi_call_u64_u32_addr()`
```c
int vabi_call_u64_u32_addr(
    const char *to_hex,
    const uint8_t sel4[4],
    uint32_t epoch,
    const char *addr20_hex,
    uint64_t *out
)
```
Calls function with (uint32, address) arguments, returns uint64.

#### `vabi_call_bool_0()`
```c
int vabi_call_bool_0(
    const char *to_hex,
    const uint8_t sel4[4],
    int *out_true
)
```
Calls function with no arguments, returns boolean.

#### `vabi_call_u16_0()`
```c
int vabi_call_u16_0(
    const char *to_hex,
    const uint8_t sel4[4],
    uint16_t *out_u16
)
```
Calls function with no arguments, returns uint16.

#### `vabi_call_u32_0()`
```c
int vabi_call_u32_0(
    const char *to_hex,
    const uint8_t sel4[4],
    uint32_t *out_u32
)
```
Calls function with no arguments, returns uint32.

#### `vabi_call_u64_0_from_u256()`
```c
int vabi_call_u64_0_from_u256(
    const char *to_hex,
    const uint8_t sel4[4],
    uint64_t *out_low64
)
```
Calls function returning uint256, extracts low 64 bits.

---

## Pre-defined Selectors

The file defines selectors for common contract functions:

### ValisSafeModule (VSM)
```c
const uint8_t VSM_SEL_batchExecuted[4]    = {0x23,0x14,0xbf,0x23}; // batchExecuted(uint64)
const uint8_t VSM_SEL_executedMask[4]     = {0x4f,0x05,0xc1,0xdf}; // executedMask(uint64)
const uint8_t VSM_SEL_bridgeId[4]         = {...};                  // bridgeId()
const uint8_t VSM_SEL_signerEpoch[4]      = {...};                  // signerEpoch()
const uint8_t VSM_SEL_signerWeight[4]     = {...};                  // signerWeight(uint32,address)
const uint8_t VSM_SEL_signerThreshold[4]  = {...};                  // signerThreshold(uint32)
```

### ValisWithdrawReader (VWR)
```c
const uint8_t VWR_SEL_currentTier[4]      = {...}; // currentTier(address)
const uint8_t VWR_SEL_currentEpochFor[4]  = {...}; // currentEpochFor(address,uint8)
const uint8_t VWR_SEL_isSignerNow[4]      = {...}; // isSignerNow(address,address)
const uint8_t VWR_SEL_signerWeights[4]    = {...}; // signerWeights(address,uint32)
```

---

## Contract Interaction Functions

### ValisSafeModule Queries

#### `vsm_batch_executed()`
```c
int vsm_batch_executed(
    const char *vsm_hex,
    uint64_t batch_id,
    int *out_executed
)
```
Checks if batch has been executed.

#### `vsm_executed_mask()`
```c
int vsm_executed_mask(
    const char *vsm_hex,
    uint64_t batch_id,
    uint64_t *out_mask
)
```
Gets execution bitmask for batch.

#### `vsm_bridge_id()`
```c
int vsm_bridge_id(const char *vsm_hex, uint64_t *out_bridge_id)
```
Gets bridge identifier.

#### `vsm_signer_epoch()`
```c
int vsm_signer_epoch(const char *vsm_hex, uint32_t *out_epoch)
```
Gets current signer epoch (increments on key rotation).

#### `vsm_signer_weight()`
```c
int vsm_signer_weight(
    const char *vsm_hex,
    uint32_t epoch,
    const char *addr_hex,
    uint64_t *out_weight
)
```
Gets signer's voting weight for given epoch.

#### `vsm_signer_threshold()`
```c
int vsm_signer_threshold(
    const char *vsm_hex,
    uint32_t epoch,
    uint64_t *out_threshold
)
```
Gets required signature threshold for epoch.

### ValisWithdrawReader Queries

#### `vwr_current_tier()`
```c
int vwr_current_tier(
    const char *reader_hex,
    const char *module_hex,
    uint8_t *tier_out
)
```
Gets current tier for withdrawal module.

#### `vwr_current_epoch_for()`
```c
int vwr_current_epoch_for(
    const char *reader_hex,
    const char *module_hex,
    uint8_t tier,
    uint32_t *epoch_out
)
```
Gets current epoch for module/tier combination.

#### `vwr_is_signer_now()`
```c
int vwr_is_signer_now(
    const char *reader_hex,
    const char *module_hex,
    const char *who_hex,
    vwr_signer_now_t *out
)
```
Checks if address is currently a valid signer.

**Returns struct with:**
- `ok` - Is signer
- `tier` - Signer tier
- `epoch` - Current epoch
- `weight` - Voting weight

---

## Usage Examples

### Building Simple Call

```c
vabi_buf_t buf;
vabi_init(&buf, 64);

// transfer(address to, uint256 amount)
uint8_t sel[4] = {0xa9, 0x05, 0x9c, 0xbb};
uint8_t to[20] = {...};

vabi_push_selector(sel, &buf);
vabi_push_address20(to, &buf);
vabi_push_u256_from_u64(1000000, &buf);

// buf.data now contains calldata
// buf.len = 4 + 32 + 32 = 68 bytes

vabi_free(&buf);
```

### Decoding Return Value

```c
char result_hex[256];
// ... make eth_call ...

uint64_t balance;
if (vabi_result_u64_at(result_hex, 0, &balance) == 0) {
    printf("Balance: %lu\n", balance);
}
```

### High-Level Query

```c
uint64_t bridge_id;
if (vsm_bridge_id("0x1234...", &bridge_id) == 0) {
    printf("Bridge ID: %lu\n", bridge_id);
}
```

---

## Error Handling

Most functions return:
- `0` - Success
- `-1` - NULL parameter or invalid input
- `-2` - Memory allocation failed
- `-3` - Encoding error
- `-4` - RPC call failed
- `-5` to `-9` - Decoding errors at specific fields

---

## Security Considerations

### Input Validation
- All functions check for NULL pointers
- Hex parsing validates characters
- Array bounds checked before access

### Memory Safety
- Buffer growth uses safe realloc pattern
- All allocations freed on error paths
- No buffer overflows possible

### RPC Security
- Results validated before parsing
- Hex format verified (0x prefix)
- Word boundaries checked

---

## Integration Points

- **bridge.h** - Type definitions
- **bridge_rpc.c** - Low-level RPC transport
- **bridge_withdraw.c** - Uses ABI for withdrawal calldata
- **bridge_deposit.c** - Uses ABI for deposit verification

---

*Documentation generated: Wake 1285*
*File version: Nov 1 2025*
