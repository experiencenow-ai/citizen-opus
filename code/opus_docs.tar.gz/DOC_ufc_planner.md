# UFC Planner Module Documentation

**File:** `UFC/ufc_planner.c`  
**Lines:** 762  
**Module:** UFC (Unified Financial Core)  
**Documented by:** Opus (Wake 1304)

---

## Overview

The UFC Planner implements per-asset trading strategy planning using alpha state signals. It manages dynamic pricing adjustments based on market conditions including premium levels, order flow, and price trends. This is the "brain" that decides how aggressively to price OOB (Out-of-Band) trades based on market signals.

---

## Key Concepts

### Alpha State
A collection of market signals tracked per asset:
- **EMA Price**: Exponential moving average of price
- **EMA Flow**: Smoothed order flow in VUSD terms
- **Flow Relative BPS**: Current flow as basis points of TVL
- **Trend BPS**: Price trend direction/magnitude
- **Jitter BPS**: Price volatility measure
- **Premium Relative BPS**: Premium as percentage of TVL
- **EMA OB Price**: Smoothed orderbook mid-price
- **EMA BPF Price**: Smoothed BPF (eBPF) computed price
- **EMA Premium VUSD**: Smoothed premium in VUSD

### Planning Output
The planner outputs:
- **Gain BPS**: How much profit to target on trades (dynamic)
- **Target End PCT BPS**: Where to target ending inventory position

---

## Core Functions

### `ufc_alpha_apply()`
```c
void ufc_alpha_apply(const ufc_alpha_state_t *alpha, int32_t is_v2o_dir,
                     int32_t base_gain_bps, int32_t base_target_end_pct_bps,
                     int32_t *out_gain_bps, int32_t *out_target_end_pct_bps)
```

**Purpose:** Apply alpha signals to compute dynamic gain and target parameters.

**Algorithm:**
1. Extract premium relative BPS (capped at `UFC_ALPHA_FLOW_REL_BPS_CAP`)
2. Compute gain range: min = base/4, max = base
3. Scale gain based on premium: higher premium → higher gain
4. Add boost based on flow + trend score
5. Compute target shift based on premium and direction
6. Output adjusted gain_bps and target_end_pct_bps

**Key Insight:** When there's high premium (demand imbalance), the system charges more (higher gain) and shifts target inventory to capture the opportunity.

---

### Alpha State Persistence

#### `ufc_alpha_state_load()`
```c
int32_t ufc_alpha_state_load(struct valisL1_info *L1, struct addrhashentry *poolap,
                             ufc_alpha_state_t *st)
```

Loads alpha state from pool address's userassets array. Uses special asset slots (`_UFC_ALPHA0` through `_UFC_ALPHA6`) to store packed state.

**Storage Layout:**
- Slot 0: `ema_price_sat`
- Slot 1: `ema_flow_vusd`
- Slot 2: `flow_rel_bps` (low 32) | `trend_bps` (high 32)
- Slot 3: `jitter_bps` (low 32) | `premium_rel_bps` (high 32)
- Slot 4: `ema_ob_price_sat`
- Slot 5: `ema_bpf_price_sat`
- Slot 6: `ema_premium_vusd`

#### `ufc_alpha_state_store()`
```c
int32_t ufc_alpha_state_store(struct valisL1_info *L1, struct addrhashentry *poolap,
                              int32_t aid, const ufc_alpha_state_t *st)
```

Stores alpha state back to pool. Also computes and stores additional derived values:
- UFC price from pool state
- OOB price
- TVL in VUSD
- Capacity metrics
- Packed share information

---

### Alpha Updates

#### `ufc_alpha_update_price()`
Updates EMA price tracking when new price data arrives.

#### `ufc_alpha_update_flow()`
Updates flow metrics based on trade direction and size:
- Tracks EMA of flow in VUSD
- Computes flow relative to TVL
- Updates trend based on flow direction changes

#### `ufc_alpha_update_premiums_for_asset()`
```c
void ufc_alpha_update_premiums_for_asset(struct valisL1_info *L1, int32_t aid,
                                          int64_t premium_vusd_total)
```

Updates premium tracking:
1. Load current alpha state
2. Update EMA premium with exponential smoothing
3. Compute premium relative to TVL
4. Store updated state

#### `ufc_alpha_update_from_premiums_for_all_assets()`
Iterates all assets and updates their premium tracking from current OOB and orderbook premiums.

---

### Planning Helpers

#### `ufc_planner_compute_exec_band()`
```c
static void ufc_planner_compute_exec_band(int64_t anchor_px,
                                           int64_t *lower_px_out,
                                           int64_t *upper_px_out)
```

Computes price band around anchor for order execution:
- Lower = anchor × (1 - band_bps)
- Upper = anchor × (1 + band_bps)

Uses `UFC_TOB_EXEC_BAND_BPS` as band width.

#### `ufc_planner_update_ob_shares()`
Updates orderbook share allocations based on net flows in each direction.

#### `ufc_get_pool_state_for_asset()`
```c
static int32_t ufc_get_pool_state_for_asset(struct valisL1_info *L1, int32_t aid,
                                             ufc_assetinfo_t **A_out,
                                             int64_t *ufc_px_out,
                                             int64_t *last_px_out,
                                             int64_t *tvl_vusd_out)
```

Retrieves current pool state for an asset:
- Asset info pointer
- UFC price (with vcredit cap applied)
- Last traded price
- TVL in VUSD terms

---

## Constants Used

| Constant | Purpose |
|----------|---------|
| `UFC_ALPHA_FLOW_REL_BPS_CAP` | Maximum relative flow in BPS |
| `UFC_ALPHA_FLOW_EMA_WINDOW` | EMA smoothing window for flow |
| `UFC_ALPHA_BULL_TARGET_MAX_BPS` | Maximum target shift in bull conditions |
| `UFC_OOB_GAIN_BPS` | Default OOB gain target |
| `UFC_OOB_CLAMP_BPS` | Maximum allowed gain |
| `UFC_TOB_EXEC_BAND_BPS` | Price band for order execution |
| `BPS_DENOM` | Basis points denominator (10000) |

---

## Mathematical Helpers

The file uses several macro helpers:
- `UFC_MUL_DIV(a,b,c,round)` - Safe multiply-divide with rounding
- `UFC_SET_IF_NONPOS(x,default)` - Set to default if non-positive
- `UFC_CLAMP(x,min,max)` - Clamp value to range
- `UFC_ABS64(x)` - Absolute value for int64
- `UFC_VUSD_FROM_OTHER(other,px)` - Convert other asset to VUSD equivalent
- `UFC_COMPUTE_TVL_VUSD(...)` - Compute total value locked in VUSD

---

## Data Flow

```
Market Events
     │
     ▼
┌─────────────────┐
│ Alpha Updates   │  ← Price, Flow, Premium signals
│ (per asset)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Alpha State     │  ← Stored in pool's userassets
│ (7 slots)       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ ufc_alpha_apply │  ← Planning decision
└────────┬────────┘
         │
         ▼
   gain_bps, target_end_pct_bps
         │
         ▼
   OOB/Orderbook Pricing
```

---

## Integration Points

- **ufc_oob.c**: Uses planner output for OOB trade pricing
- **ufc_orderbook.c**: Uses planner for orderbook positioning
- **ufc_swap.c**: May query alpha state for swap decisions
- **gen3_rawtock.c**: Triggers alpha updates during block processing

---

## Design Philosophy

The planner implements adaptive market making:

1. **Premium-Responsive**: Higher premiums (demand imbalance) → charge more
2. **Flow-Aware**: Strong directional flow → adjust targets
3. **Trend-Following**: Persistent trends boost gain targets
4. **EMA-Smoothed**: All signals use exponential smoothing to avoid noise

This creates a system that:
- Captures more profit during high-demand periods
- Adjusts inventory targets based on market direction
- Smooths out noise while remaining responsive

---

## Notes

- Alpha state uses 7 asset slots per pool for storage
- All BPS values are relative to `BPS_DENOM` (10000)
- Price capping for vcredit assets prevents manipulation
- The planner is called during block processing, not per-trade
