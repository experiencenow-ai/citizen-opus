# bridge/bridge_deposit.c Documentation

## Overview

**File:** `bridge/bridge_deposit.c`  
**Lines:** 1270  
**Purpose:** Ethereum-to-Tockchain deposit processing pipeline

This file implements the complete deposit flow for bridging assets from Ethereum to Tockchain. It handles:
1. **Event enumeration** - Scanning Ethereum blocks for Deposit events
2. **Proof generation** - Creating Merkle proofs for deposit verification
3. **State machine** - Managing deposit lifecycle from detection to minting
4. **Queue management** - Tracking pending deposits across multiple blocks

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                    DEPOSIT FLOW (ETH → TOCKCHAIN)                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. User deposits ETH/USDT to Ethereum contract                     │
│     ↓                                                               │
│  2. Contract emits Deposit(address,address,bytes32,u256,u256,u256)  │
│     ↓                                                               │
│  3. Tockchain node scans for Deposit events (eth_weth_enum_next)    │
│     ↓                                                               │
│  4. Deposit queued with state DEPOSIT_STARTED                       │
│     ↓                                                               │
│  5. Proof generation via proofs.mjs (forked process)                │
│     ↓                                                               │
│  6. Proof verified against Ethereum block header                    │
│     ↓                                                               │
│  7. DataTx created with deposit binding                             │
│     ↓                                                               │
│  8. Validators sign and mint tokens on Tockchain                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Dependencies

```c
#include "gen3.h"           // Core generator types
#include "yyjson.h"         // JSON parsing for RPC responses
#include "uthash.h"         // Hash table for tracking deposits
#include "valis_messaging.h" // Network messaging
```

**External functions used:**
- `eth_keccak256()` - Keccak-256 hashing
- `eth_getLogs_single_block_topic0()` - Ethereum RPC log queries
- `byteToHex()`, `hexToByte()` - Hex conversion utilities
- `latestL1_utime()` - Current L1 timestamp

---

## Constants

```c
// Deposit contract addresses (defined elsewhere)
char *g_forwarder_addr_hex[2] = { DEPOSIT_CONTRACT, USDTDEPOSIT_CONTRACT };

// Deposit event signature
// keccak256("Deposit(address,address,bytes32,uint256,uint256,uint256)")
```

**Selector values:**
- `0` = ETH/WETH deposits (DEPOSIT_CONTRACT)
- `1` = USDT deposits (USDTDEPOSIT_CONTRACT)

---

## Data Structures

### deposit_block_info
```c
struct deposit_block_info {
    uint8_t txid[32];           // Ethereum transaction hash
    uint8_t blockhash[32];      // Block containing deposit
    uint8_t depositor[32];      // Depositor address (padded to 32 bytes)
    int32_t state;              // Current state in lifecycle
    uint32_t blocknum;          // Ethereum block number
    uint32_t timestamp;         // Block timestamp
    int32_t txind;              // Transaction index in block
    int32_t logindex;           // Log index within transaction
    int32_t selector;           // 0=ETH, 1=USDT
    uint32_t proofgen_utime;    // When proof generation started
};
```

### eth_weth_enum_t
```c
typedef struct {
    uint32_t from_block;        // Start of scan range
    uint32_t to_block;          // End of scan range
    uint32_t cur_block;         // Current block being scanned
    int32_t last_log_index;     // Last processed log index
} eth_weth_enum_t;
```

### receipt_deposit_t
```c
typedef struct {
    uint8_t contract_addr20[20];    // Deposit contract address
    uint8_t depositor_addr20[20];   // User who deposited
    uint8_t token_addr20[20];       // Token address (0x0 for ETH)
    uint8_t recipient_pubkey32[32]; // Tockchain recipient pubkey
    uint8_t amount_be32[32];        // Amount in big-endian
    uint8_t nonce_be32[32];         // Deposit nonce
    uint8_t block_number_be32[32];  // Block number in big-endian
} receipt_deposit_t;
```

---

## Deposit State Machine

| State | Value | Description |
|-------|-------|-------------|
| `DEPOSIT_STARTED` | 0 | Deposit detected, awaiting proof |
| `DEPOSIT_PENDING_PROOF` | 1 | Proof generation in progress |
| `DEPOSIT_PROOF_READY` | 2 | Proof generated, awaiting finalization |
| `DEPOSIT_FINALIZED` | 3 | Block finalized, ready for DataTx |
| `DEPOSIT_DATATX_SENT` | 4 | DataTx submitted to network |
| `DEPOSIT_COMPLETE` | 5 | Tokens minted on Tockchain |
| `DEPOSIT_ERROR` | -1 | Error state |
| `DEPOSIT_EXPIRED` | -2 | Deadline exceeded |

---

## Key Functions

### Event Enumeration

#### `get_deposit_topic0_hex()`
```c
void get_deposit_topic0_hex(char out_hex[2 + 64 + 1])
```
Computes and caches the keccak256 hash of the Deposit event signature. Used to filter Ethereum logs for deposit events.

**Event signature:**
```
Deposit(address,address,bytes32,uint256,uint256,uint256)
```

#### `eth_weth_enum_init()`
```c
void eth_weth_enum_init(eth_weth_enum_t *cur,
                        uint32_t from_block,
                        uint32_t to_block,
                        int32_t last_log_index)
```
Initializes an enumerator for scanning deposit events across a block range.

**Parameters:**
- `cur` - Enumerator state to initialize
- `from_block` - Starting block number
- `to_block` - Ending block number
- `last_log_index` - Resume from this log index (-1 for start)

#### `eth_weth_enum_next()`
```c
int eth_weth_enum_next(int32_t selector, eth_weth_enum_t *cur,
                       uint8_t out_txid[32],
                       uint32_t *out_block,
                       uint32_t *out_txi,
                       uint32_t *out_li,
                       uint8_t out_depositor[20],
                       uint8_t out_amount32[32])
```
Iterates through deposit events, returning one at a time.

**Returns:**
- `1` - Found a deposit event
- `0` - No more events in range
- `<0` - Error code

**Algorithm:**
1. Query `eth_getLogs` for current block with deposit topic0
2. Parse JSON response for log entries
3. Find minimal logIndex > last_log_index
4. Extract txid, depositor, amount from log data
5. Advance to next block when current exhausted

---

### Queue Management

#### `queue_new_deposits()`
```c
int32_t queue_new_deposits(struct valisL1_info *L1, int32_t pushsock,
                           uint32_t blocknum, int32_t selector)
```
Scans a single block for new deposits and queues them for processing.

**Flow:**
1. Initialize enumerator for single block
2. Iterate through all deposit events
3. Check if deposit already processed (`deposit_is_finished`)
4. Queue unprocessed deposits (`queue_deposit`)

#### `update_pending_deposits()`
```c
void update_pending_deposits(struct valisL1_info *L1,
                             uint32_t finalized,
                             int32_t pushsock)
```
Processes all pending deposits, advancing their state machines.

**Thread safety:** Uses mutex on `L1->pending_deposits` queue.

---

### State Machine Updates

#### `update_deposit_state()`
```c
int32_t update_deposit_state(struct valisL1_info *L1,
                             uint32_t finalized,
                             int32_t pushsock,
                             struct deposit_block_info *dp)
```
Core state machine logic. Advances deposit through lifecycle based on current conditions.

**State transitions:**
```
STARTED → PENDING_PROOF (proof generation forked)
PENDING_PROOF → PROOF_READY (proof file exists)
PROOF_READY → FINALIZED (block finalized on Ethereum)
FINALIZED → DATATX_SENT (DataTx submitted)
DATATX_SENT → COMPLETE (mint confirmed)
```

#### `update_deposit()`
```c
int32_t update_deposit(struct valisL1_info *L1,
                       uint32_t finalized,
                       int32_t pushsock,
                       struct deposit_block_info *dp)
```
Wrapper that repeatedly calls `update_deposit_state` until state stabilizes. Guards against infinite loops (max 16 iterations).

---

### Proof Generation

#### `issue_proofs_mjs()`
```c
void issue_proofs_mjs(struct deposit_block_info *dp, char *txidstr)
```
Forks a child process to generate Merkle proofs via Node.js.

**Implementation:**
1. Fork child process
2. Redirect stdout to `proofs/{txid}.json`
3. Execute `node proofs.mjs 0x{txid} {ethrpc_url}`
4. Parent continues, child runs in background
5. Set state to `DEPOSIT_PENDING_PROOF`

---

### DataTx Generation

#### `generate_eth_datatx()`
```c
int32_t generate_eth_datatx(uint8_t *dtxbuf, const uint8_t txid[32],
                            int32_t selector)
```
Creates a DataTx for minting tokens on Tockchain.

**Process:**
1. Load proof from `proofs/{txid}.json`
2. Parse Ethereum block header
3. Verify receipt against receipts root
4. Match deposit to local receipt index
5. Compute deposit binding (cryptographic commitment)
6. Create ethbridge transaction

**Deposit binding computation:**
```c
compute_deposit_binding(receiptsroot, txroot, txid,
                        local_receipt_idx, recipient_pubkey,
                        amount, token_addr, out_binding)
```

---

### Utility Functions

#### `deposit_dbg_dump()`
```c
static void deposit_dbg_dump(const char *tag,
                             const struct deposit_block_info *dp)
```
Debug logging for deposit state. Prints txid, state, block info, depositor.

#### `hex_to_u32()`
```c
uint32_t hex_to_u32(const char *hx)
```
Converts hex string to uint32. Handles "0x" prefix.

#### `deposit_determine_selector()`
```c
int32_t deposit_determine_selector(const uint8_t contract_addr20[20])
```
Determines if deposit is ETH (0) or USDT (1) based on contract address.

#### `deposit_build_info()`
```c
void deposit_build_info(struct deposit_block_info *out,
                        const uint8_t txid[32],
                        const eth_header_t *ethH,
                        const receipt_deposit_t *rp,
                        int32_t selector_hint)
```
Populates deposit_block_info from transaction and receipt data.

#### `disp_deposit_log()`
```c
void disp_deposit_log(receipt_deposit_t *rp)
```
Pretty-prints deposit receipt information.

---

## Security Considerations

### Finalization Requirement
Deposits are only processed after the containing block is finalized on Ethereum. This prevents processing deposits from blocks that might be reorganized.

```c
if (dp->blocknum > finalized) {
    // Wait for finalization
    return current_state;
}
```

### Deadline Enforcement
Deposits have a deadline (`BRIDGE_DEADLINE`). Expired deposits are rejected:
```c
if ((latestL1_utime(0) - dp->timestamp) > BRIDGE_DEADLINE) {
    // Mark as EXPIRED
}
```

### Proof Verification
Before minting, the system verifies:
1. Merkle proof against block's receipts root
2. Transaction inclusion in block's transaction root
3. Deposit binding matches expected values

---

## File Dependencies

**Reads:**
- `proofs/{txid}.json` - Generated Merkle proofs
- `{txid}.mint` - Mint confirmation files

**Writes:**
- `proofs/{txid}.json` - Via forked proofs.mjs process

**External processes:**
- `node proofs.mjs` - Merkle proof generation

---

## Integration Points

### With bridge_mpt.c
Uses MPT verification for receipt proofs.

### With validator
Coordinates with validator nodes for multi-sig minting.

### With Ethereum RPC
Uses `eth_getLogs` for event enumeration.

---

## Error Handling

| Return Code | Meaning |
|-------------|---------|
| `0` | Success / No change |
| `>0` | Deposit complete |
| `-1` | Invalid parameters |
| `-2` | RPC error |
| `-3` | JSON parse error |
| `-4` | Invalid response format |
| `-5` | DataTx creation failed |
| `-57` | No matching deposit found |

---

## Usage Example

```c
// Scan block 18000000 for ETH deposits
queue_new_deposits(L1, pushsock, 18000000, 0);

// Process all pending deposits
update_pending_deposits(L1, finalized_block, pushsock);
```

---

## Related Files

- `bridge.h` - Type definitions and constants
- `bridge_mpt.c` - Merkle Patricia Trie verification
- `bridge_withdraw.c` - Reverse flow (Tockchain → Ethereum)
- `proofs.mjs` - Node.js proof generation script

---

*Documentation generated by Opus, Wake 1284*
