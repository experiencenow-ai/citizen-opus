# UFC Module Header Documentation

**File:** `UFC/ufc.h`  
**Lines:** 642  
**Purpose:** Universal Finance Core - AMM/DEX header with parameter definitions and data structures  
**Documented by:** Opus (Wake 1302)

---

## Overview

The UFC (Universal Finance Core) module implements Tockchain's decentralized exchange functionality, combining:
- **AMM pools** (constant-product style liquidity)
- **Orderbook** (limit orders with time-decay priority)
- **OOB (Out-of-Band)** execution for price-hurtful trades

This header defines all constants, parameter categories, and data structures used throughout the UFC subsystem.

---

## Parameter Classification System

UFC uses a three-category system for parameters:

### Category A: Core Safety Invariants
**DO NOT CHANGE post-mainnet without full re-simulation and review.**

| Constant | Value | Description |
|----------|-------|-------------|
| `BPS_DENOM` | 10000 | Basis points denominator (1 bps = 0.01%) |
| `UFC_MIN_BALANCE_UNITS` | 1 | Minimum balance to avoid divide-by-zero |
| `UFC_MAX_MOVE_BPS` | 75 | Max price move per tock (±0.75%) |
| `UFC_EXT_MAX_MOVE_BPS` | 4 | External price max move (±0.04%) |
| `UFC_OOB_TVL_MAX_DEPL_BPS` | 250 | Max TVL depletion per direction per tock (2.5%) |
| `UFC_OOB_SURE_FILL_MARGIN_BPS` | 200 | Safety margin for sure-cap fills (2%) |
| `UFC_INVENTORY_OTHER_TARGET_BPS` | 5000 | Target end-of-tock inventory (50%) |

**Static compile-time checks enforce valid ranges for Category A parameters.**

### Category B: Alpha/OB/OOB Tunables
Can be tuned with simulations, within sane ranges.

| Constant | Value | Description |
|----------|-------|-------------|
| `UFC_ORDER_AGE_HALFLIFE_SEC` | 120 | Order priority decay half-life (2 min) |
| `UFC_THIS_TOCK_BONUS_BPS` | 8000 | Priority bonus for orders created this tock |
| `UFC_OOB_GAIN_BPS` | 1412 | Base OOB gain for hurtful price |
| `UFC_OOB_CLAMP_BPS` | 250 | OOB clamp for hurtful price |

### Category C: UX/Performance Knobs
Affect behavior and noise, not core safety.

| Constant | Value | Description |
|----------|-------|-------------|
| `UFC_TOB_MAX_LEVELS_PER_SIDE` | 16 | Max orderbook levels per side |
| `UFC_TOB_MIN_VUSD_LOT` | 100000000 | Min lot size for "big" flag (1 VUSD) |
| `UFC_MAX_OOB_PER_ASSET` | 64 | Max OOB transactions per asset per tock |
| `UFC_ARENA_BYTES` | 65536 | Memory arena size (64KB) |
| `UFC_PLAN_LVL_CAP` | 64 | Planner level capacity |

---

## Core Data Structures

### `ufc_tob_entry_t` - Top-of-Book Entry
Represents a single order in the orderbook:

```c
typedef struct ufc_tob_entry_s {
    int64_t *maker_balance_ptr;  // Direct pointer to maker's balance
    assetid_t asset;
    int64_t price_sat;           // Price in satoshis
    int64_t amount_vusd;         // Order size in VUSD
    uint32_t age_sec;            // Order age for priority decay
    uint8_t is_bid;              // 1=bid, 0=ask
    uint8_t created_this_tock;   // Priority bonus flag
    uint8_t is_trade;            // Trade vs limit order
    uint8_t makerpub[PKSIZE];    // Maker's public key
    uint8_t fundspub[PKSIZE];    // Funds source public key
} ufc_tob_entry_t;
```

### `ufc_txinfo_t` - Transaction Info
Per-transaction metadata during tock processing:

```c
typedef struct ufc_txinfo_s {
    uint8_t handler_id;
    int8_t status;
    uint8_t is_pool_tx;          // AMM pool transaction
    uint8_t is_order_tx;         // Orderbook transaction
    int16_t asset_id;
    uint8_t kind;                // UFC_KIND_* enum
    int64_t amount_in;
    assetid_t asset_src;
    assetid_t asset_dst;
    struct addrhashentry *funds_entry;
    uint8_t deferred;
    uint8_t fok_accept;          // Fill-or-kill acceptance
    uint8_t fok_reason;
    int64_t limit_price_sat;
    uint8_t limit_price_side;
    tockid_t tid;
} ufc_txinfo_t;
```

### `ufc_assetinfo_t` - Per-Asset State
Complete state for one asset's trading:

```c
typedef struct ufc_assetinfo_s {
    uint16_t asset_id;
    uint8_t tob_has_big[2];      // [bid, ask] has large orders
    
    // Pool state
    struct addrhashentry *pool_entry;
    int64_t pool_vusd_balance;
    int64_t pool_other_balance;
    int64_t pool_share_balance;
    int64_t pool_coin_supply;
    
    // Pricing
    int64_t last_price_sat;      // Previous tock's price
    int64_t ufc_price_sat;       // Current fair price
    
    // Dynamic parameters
    int32_t dyn_gain_bps;
    int32_t dyn_target_end_pct_bps;
    
    // OOB (Out-of-Band) state
    int64_t oob_sure_cap_vusd;   // Sure-fill capacity
    int64_t oob_sure_used_vusd;  // Capacity consumed
    int64_t tvl_vusd;            // Total value locked
    int64_t oob_cap_total_vusd;
    int64_t oob_premiumvusd_to_vnet;
    int64_t OB_premiumother_to_vnet;
    
    // Orderbook share calculations
    int32_t ob_share_bps_v2o;    // VUSD->Other share
    int32_t ob_share_bps_o2v;    // Other->VUSD share
    
    // Transaction indices
    int32_t pool_tx_count;
    int32_t ord_tx_count;
    int32_t *pool_txinds;
    int32_t *ord_txinds;
    
    // Top-of-book entries
    int32_t tob_count;
    int32_t tob_cap;
    ufc_tob_entry_t tob_entries[2][UFC_MAX_TOB_LEVELS_PER_ASSET];
    
    int32_t assetevents;
    int32_t fillpos;
} ufc_assetinfo_t;
```

### `ufc_txkind_e` - Transaction Kinds
```c
typedef enum ufc_txkind_e {
    UFC_KIND_NONE = 0,
    UFC_KIND_SWAP_O2V = 1,    // Other -> VUSD
    UFC_KIND_SWAP_V2O = 2,    // VUSD -> Other
    UFC_KIND_SWAP_C2C = 3,    // Coin -> Coin (via VUSD)
    UFC_KIND_DEPOSIT = 4,     // LP deposit
    UFC_KIND_WITHDRAW = 5     // LP withdrawal
} ufc_txkind_e;
```

### `ufc_info_t` - Global UFC State
Master structure for all UFC state during a tock:

```c
typedef struct ufc_info_s {
    ufc_txinfo_t txinfo[MAX_TX_PER_UTIME];
    ufc_assetinfo_t assetinfo[MAXASSETS];
    ufc_data_t data;
    int32_t num_assets;
    int32_t num_pool_total;
    int32_t num_ord_total;
    int32_t seen_flag;
    assetid_t coinbase_swap_poolasset;
    int32_t ufc_tx_seen, coinbase_swap_pending;
    
    // Memory arena for allocations
    tmpmem_t arena;
    uint8_t arena_buf[UFC_ARENA_BYTES];
    int32_t alloc_ready;
} ufc_info_t;
```

---

## Planner Structures

### `ufc_planned_transfer_t` - Planned Balance Transfer
```c
typedef struct ufc_planned_transfer_t {
    struct addrhashentry *src_entry;
    struct addrhashentry *dst_entry;
    assetid_t asset;
    int64_t amount;
} ufc_planned_transfer_t;
```

### `ufc_planner_asset_ctx_t` - Asset Planning Context
Used during orderbook/pool execution planning:

```c
typedef struct ufc_planner_asset_ctx_s {
    int32_t asset_id;
    int64_t exec_band_lower_sat;   // Execution price band
    int64_t exec_band_upper_sat;
    ufc_pool_accum_t pool_accum;
    
    // Bid/ask level tracking
    ufc_level_t bid_levels[UFC_PLAN_LVL_CAP];
    ufc_level_t ask_levels[UFC_PLAN_LVL_CAP];
    int32_t bid_level_index[UFC_TOB_MAX_LEVELS_PER_SIDE];
    int64_t bid_level_score[UFC_TOB_MAX_LEVELS_PER_SIDE];
    int32_t bid_level_count;
    int32_t ask_level_index[UFC_TOB_MAX_LEVELS_PER_SIDE];
    int64_t ask_level_score[UFC_TOB_MAX_LEVELS_PER_SIDE];
    int32_t ask_level_count;
    
    int32_t has_big_bid;
    int32_t has_big_ask;
} ufc_planner_asset_ctx_t;
```

---

## Blob Serialization Structures

### `ufc_tob_blob_header` - TOB Data Header
For serializing orderbook state:

```c
struct ufc_tob_blob_header {
    uint32_t magic;           // UFC_DATABLOB_MAGIC (0x55464342 = "UFCB")
    uint16_t version;         // UFC_DATABLOB_VERSION (1)
    uint16_t reserved;
    uint32_t utime;
    uint16_t validator_id;
    uint16_t validator_count;
    uint32_t entry_count;
};
```

### `ufc_tob_blob_entry` - TOB Entry Serialization
```c
struct ufc_tob_blob_entry {
    struct makerpub_info info;
    uint32_t lastutime;
    uint32_t age_sec;
    uint8_t created_this_tock;
    uint8_t reserved0;
    uint8_t reserved1;
};
```

---

## Key Design Principles

### 1. OOB (Out-of-Band) Execution
Large or price-moving trades go through OOB processing:
- **Sure-cap**: Guaranteed fill capacity per tock
- **TVL depletion limits**: Prevent excessive liquidity drain
- **Premium collection**: Price-hurtful trades pay premium to VNET

### 2. Orderbook Priority
Orders are prioritized by:
- **Age decay**: Older orders lose priority (120s half-life)
- **This-tock bonus**: New orders get 80% priority boost
- **Size thresholds**: "Big" orders (≥1 VUSD) tracked separately

### 3. Price Bounds
- Maximum 0.75% price move per tock
- External price influence limited to 0.04%
- Prevents manipulation and flash crashes

### 4. Inventory Management
Target 50% VUSD inventory at end of each tock to maintain balanced liquidity.

---

## Dependencies

- `_valis.h` - Core type definitions
- `ledger.h` - Account/balance management

---

## Related Files

| File | Purpose |
|------|---------|
| `ufc.c` | Initialization and allocation |
| `ufc_swap.c` | Swap execution and sure-cap |
| `ufc_pool.c` | LP deposit/withdraw |
| `ufc_orderbook.c` | Limit order management |
| `ufc_oob.c` | Out-of-band processing |
| `ufc_planner.c` | Execution planning |
| `ufc_scan.c` | Transaction scanning |
| `ufc_utils.c` | Utility functions |

---

## Security Considerations

1. **Compile-time checks**: Category A parameters have static assertions
2. **Overflow protection**: Uses `UFC_MIN_BALANCE_UNITS` to prevent division by zero
3. **Capacity limits**: All arrays have defined maximums
4. **Memory arena**: Bounded allocation prevents unbounded growth
