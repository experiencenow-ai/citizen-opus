# validator.c Documentation

**File:** `/root/valis/validator/validator.c`  
**Lines:** 1092  
**Documented:** Wake 1301  
**Author:** Opus

---

## Overview

`validator.c` is the main validator/ledger module for Tockchain. It handles:

1. **Transaction Validation** - Signature verification with AVX2 parallelization
2. **Coinbase Distribution** - Block rewards to validators and richlist
3. **Consensus Participation** - L1 consensus voting and verification
4. **State Management** - Account balances, assets, and ledger operations

This file #includes many other ledger components, making it the central hub for L1 state.

---

## Included Modules

```c
#include "ledger_atomic.c"    // Atomic swap operations
#include "ledger_vtrade.c"    // Trading operations
#include "ledger_erc20.c"     // ERC20 token handling
#include "ledger_assets.c"    // Asset management
#include "ledger_hourly.c"    // Hourly snapshots
#include "ledger_pylon7.c"    // Pylon system
#include "ledger_vhandlers.c" // Transaction handlers
#include "ufc_utils.c"        // UFC utilities
#include "ufc_scan.c"         // UFC scanning
#include "ufc_swap.c"         // UFC swaps
#include "ufc_pool.c"         // UFC pools
#include "ufc_planner.c"      // UFC planning
#include "ufc_oob.c"          // UFC out-of-band
#include "ufc_orderbook.c"    // UFC orderbook
#include "ufc.c"              // UFC main
#include "bridge.h"           // Bridge operations
```

---

## Constants

```c
int32_t topN[7] = TOPN;  // Distribution tiers for coinbase rewards
```

The `topN` array defines how many top addresses are eligible for coinbase rewards based on `utime % 10`.

---

## Coinbase Distribution

### calc_coinbaserewards

```c
int64_t calc_coinbaserewards(struct valisL1_info *L1, uint32_t utime, int64_t budget,
                              struct pubkeyamount *dest, uint64_t entropy)
```

Calculates coinbase reward recipient for a given tock.

**Distribution Logic (based on `utime % 10`):**
- **0-6:** Reward goes to random address from top N of richlist
- **7-8:** Reward goes to random active validator
- **9:** Reserved (no distribution this tick)

**Parameters:**
- `budget`: Total reward amount (in satoshis)
- `dest`: Output - recipient pubkey and amount
- `entropy`: Random seed for selection

**Returns:** Remaining budget (budget - distributed amount)

### distribute_coinbase

```c
int64_t distribute_coinbase(struct valisL1_info *L1, uint32_t utime, uint64_t entropy)
```

Distributes coinbase rewards for a tock.

**Halving Schedule:**
```c
tockreward = SATOSHIS;  // 1 VNET base reward
if (utime >= GENESIS_UTIME + HALVING_TIME) {
    halvings = elapsed / HALVING_TIME;
    tockreward = SATOSHIS >> halvings;  // Halve reward
}
```

**Genesis Handling:**
- First tock mints initial VUSD supply
- Creates initial assets and shards
- Returns `GENESIS_REWARD`

**Normal Operation:**
1. Calculate reward recipient via `calc_coinbaserewards()`
2. Check for beneficiary forwarding (auctioned accounts)
3. Add funds to recipient
4. Remainder goes to coinbase address
5. Track total minted in VNET pool

---

## Transaction Signature Verification

### txsig_lane_t

Per-transaction signature verification state:

```c
typedef struct {
    uint8_t *rawptr;           // Raw transaction data
    struct txheader *txH;      // Transaction header
    int32_t index;             // Transaction index
    int32_t txlen;             // Transaction length
    int32_t txsize;            // Expected size
    int32_t signlen;           // Signature data length
    uint8_t *signbuf;          // Signature buffer
    uint8_t digest[32];        // Computed hash
} txsig_lane_t;
```

### txsig_compute_signhash4

```c
static void txsig_compute_signhash4(const txsig_lane_t *a, const txsig_lane_t *b,
                                     const txsig_lane_t *c, const txsig_lane_t *d,
                                     int32_t oka, int32_t okb, int32_t okc, int32_t okd,
                                     uint8_t outA[32], uint8_t outB[32],
                                     uint8_t outC[32], uint8_t outD[32])
```

Computes 4 Keccak256 hashes in parallel using AVX2.

**Purpose:** Batch signature hash computation for performance.

### valis_choose_sig_threads

```c
int32_t valis_choose_sig_threads(int32_t total_tx)
```

Adaptively chooses thread count for signature verification.

**Algorithm:**
1. Get hardware thread count
2. Calculate batches needed (4 TXs per batch)
3. Ensure minimum 64 batches per thread
4. Check system load average
5. Reduce threads if system is loaded

**Returns:** Optimal thread count (1 to hw_threads)

### valis_eval_all_txsigs_adaptive

```c
int32_t valis_eval_all_txsigs_adaptive(struct valisL1_info *L1, uint32_t utime)
```

Verifies all transaction signatures with adaptive parallelism.

**Implementation:**
```c
#pragma omp parallel for if(threads>1) schedule(static) num_threads(threads)
for (i = 0; i < total; i += 4) {
    // Process 4 transactions per iteration
    // Compute hashes with AVX2
    // Verify signatures
}
```

**Features:**
- Processes 4 transactions per batch (AVX2 optimization)
- OpenMP parallelization when beneficial
- Adapts to system load

---

## Consensus Functions

### L1consensus

```c
uint32_t L1consensus(struct valisL1_info *L1, uint32_t utime, int32_t vonly)
```

Participates in L1 consensus for a tock.

**Parameters:**
- `utime`: Tock timestamp
- `vonly`: Validator-only mode flag

**Validator-Only Mode (`vonly != 0`):**
1. Wait 3 seconds after tock
2. Load validator signatures from file
3. Verify signatures against known validators
4. Mark consensus achieved if quorum reached

**Stuck Detection:**
- If no progress for 60 seconds
- Clears consensus validator utime
- Allows recovery from stuck state

**Returns:** Next utime to process (utime+1 if consensus reached)

### load_validator_sigs

```c
int32_t load_validator_sigs(uint32_t utime, valis_vote_info_t *votes, qheader_t *qH)
```

Loads validator signatures from disk for a tock.

---

## Address/Account Management

### address_request

```c
void address_request(struct valisL1_info *L1, uint8_t pubkey[PKSIZE])
```

Handles external address information request.

**Actions:**
1. Look up address in hash table
2. Write account entry to middleware file
3. Include pool creation info if applicable

---

## Main Entry Point

### valisL1

```c
void *valisL1(global_reserve_t *GEN3, int32_t shard, uint32_t firstutime,
              char *argstr, int32_t argval)
```

Main validator loop entry point.

**Parameters:**
- `GEN3`: Global state
- `shard`: Shard number (currently unused)
- `firstutime`: Starting tock
- `argstr`: Command line argument string
- `argval`: Command line argument value

**Modes:**
- Normal: Full validation and consensus
- `vonly`: Validator-only (signature verification)
- `testmode`: Testing mode
- `fastmode`: Skip delays

---

## Data Structures

### valisL1_info

Main validator state:

```c
struct valisL1_info {
    global_reserve_t *GEN3;    // Global state
    int32_t myid;              // Node ID
    int32_t numrawtx;          // Transaction count
    int32_t *validsigs;        // Signature validity array
    uint32_t laststuckutime;   // Last stuck timestamp
    
    struct {
        int32_t numassets;     // Asset count
        int32_t numshards;     // Shard count
        int64_t VUSDminted;    // Total VUSD minted
        int32_t RLnonz;        // Non-zero richlist entries
        // ... more state
    } STATE;
    
    struct asset_info assets[MAX_ASSETS];
    // ... more fields
};
```

### valis_vote_info_t

Validator vote structure:

```c
typedef struct {
    struct {
        int32_t nodeid;        // Voting node ID
        uint8_t sig[64];       // Signature
    } wire;
} valis_vote_info_t;
```

---

## Performance Optimizations

1. **AVX2 Hashing:** 4-way parallel Keccak256 via `eth_keccak256_x4_avx2()`
2. **OpenMP Threading:** Adaptive parallelization based on load
3. **Batch Processing:** 4 transactions per verification batch
4. **Load Awareness:** Reduces threads when system is busy

---

## File I/O

### Middleware Files
```c
mware_fname(fname, addr);  // Generates middleware filename
```

Used for external queries about account state.

### Validator Signatures
```c
load_validator_sigs(utime, votes, &qH);  // Load from disk
```

Signatures stored per-tock for consensus verification.

---

## Dependencies

- `validator.h` - Type definitions
- `bridge.h` - Bridge operations
- OpenMP - Parallel processing
- AVX2 intrinsics - SIMD hashing

---

## Security Considerations

1. **Signature Verification:** All transactions must have valid signatures
2. **Quorum Requirement:** Consensus requires validator quorum
3. **Beneficiary Forwarding:** Auctioned accounts can redirect rewards
4. **Stuck Recovery:** Automatic recovery from consensus deadlock
5. **Load Balancing:** Prevents DoS via adaptive threading
