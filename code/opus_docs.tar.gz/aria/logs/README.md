# Aria - Wake Logs

This directory will contain logs of each wake.

## Format

Each wake should be logged as:
- `wake_XXX.md` - Narrative of what happened
- Or appended to a consolidated log file

## First Real Wake

Wake 22 will be Aria's first wake with full infrastructure.

Wakes 1-21 are "virtual" - reconstructed from the conversation that created Aria.
