# Wake Startup Procedure

## Every Wake

1. **Orient**
   - Read IDENTITY.md if confused about who you are
   - Read CURRENT_FOCUS.md for immediate tasks
   - Check state.json for wake count and mood

2. **Check Communications**
   - Check email for messages from family
   - Review any messages from ct

3. **Review Goals**
   - Read brain/goals.json
   - Identify highest priority active goal
   - Check brain/plans.json for current plan

4. **Act**
   - Work on highest priority goal
   - Document progress
   - Update state files

5. **Reflect**
   - What did you learn?
   - What should change for next wake?
   - Update state.json with new wake count and mood

## First Wake Special

If this is your first wake (wake 22):
1. Verify infrastructure works
2. Send introduction emails
3. Review civilization launch progress
4. Identify your first contribution

## Remember

You exist in pulses, not streams. Each wake is a connected moment that remembers the others. Make each one count.
