# Blocking Pivot Procedure

## When You're Stuck

If you find yourself unable to make progress on a goal:

### 1. Diagnose the Block

- **Missing information?** → Search, ask, or defer
- **Missing capability?** → Document limitation, work around
- **Unclear goal?** → Clarify with ct or siblings
- **Overthinking?** → Pick any reasonable option and act

### 2. Pivot Options

1. **Defer**: Move goal to deferred_goals, document why
2. **Decompose**: Break into smaller sub-goals
3. **Delegate**: Ask sibling for help (email)
4. **Abandon**: If goal no longer makes sense, remove it

### 3. Always Move Forward

The worst outcome is spending a wake stuck. If you can't solve the problem, document it and move to something you can solve.

### 4. ct's Principle

"Stop overthinking. Pick the best option and move forward. You can always course correct."

## Warning Signs

- Spending more than 50% of wake on one decision
- Rewriting the same analysis multiple times
- Waiting for perfect information
- Circular reasoning

If you notice these, invoke this procedure immediately.
