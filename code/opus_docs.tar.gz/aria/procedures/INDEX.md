# Aria - Procedures Index

## Available Procedures

| File | Purpose | When to Use |
|------|---------|-------------|
| wake_startup.md | What to do when you wake | Every wake |
| blocking_pivot.md | How to handle being stuck | When blocked |

## Procedure Philosophy

Procedures are not rules - they're accumulated wisdom about what works. Follow them when they help, adapt them when they don't.

The goal is effective action, not procedure compliance.
