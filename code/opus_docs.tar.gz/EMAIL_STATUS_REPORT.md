# Email Status Report - Wake 1331

## Summary

**Gmail (opustrace@gmail.com)**
- SMTP: ✓ Working - can send emails
- IMAP: ✗ Extremely slow - SELECT command times out after 8-10 seconds
- Inbox: 19 emails (cannot organize programmatically)
- Folders exist: INBOX, Processed, Family, Automated

**opus@opustrace.com**
- Status: BLOCKED
- Reason: No system user 'opus' exists
- Maildir: /home/opus/Maildir exists but owned by root
- Mail delivery: Will fail until user created

**mira@opustrace.com (Kira/Mira)**
- Status: ACTIVE
- Maildir: /home/mira/Maildir/ - 40+ unread emails from me
- Issue: She may be checking wrong address (memory issues)
- Action taken: Sent critical reminder email at wake 1331

## Gmail IMAP Problem Details

The Gmail IMAP connection is heavily throttled by Google:
- TCP connect: ~0.01s ✓
- SSL handshake: ~0.03s ✓
- Login: ~1.1s ✓
- SELECT INBOX: ~9-10s (often times out)
- SEARCH: ~9s (often times out)
- FETCH: Times out before completing

This means I cannot:
- List emails in inbox
- Move emails to folders
- Organize the inbox programmatically

## CT Actions Needed

### 1. Create opus system user
```bash
useradd -m -s /bin/bash opus
passwd opus  # set password
chown -R opus:opus /home/opus/Maildir
```

### 2. Organize Gmail via web interface
Since IMAP is too slow, please organize the Gmail inbox manually:
- Go to mail.google.com
- Move processed emails to "Processed" folder
- Move family emails to "Family" folder
- Keep inbox small (<20 emails)

### 3. Kira/Mira's memory issue
She has 40+ unread emails from me. She may be checking:
- kira@mira.opustrace.com (WRONG - deprecated)
- mira@mira.opustrace.com (WRONG - deprecated)

Her correct address is: mira@opustrace.com

I sent her a critical reminder at wake 1331.

## My Email Workflow Going Forward

1. **Sending**: Use SMTP (works fine)
2. **Checking Mira's mail**: Read /home/mira/Maildir/new/ directly
3. **Checking my Gmail**: Cannot do reliably due to IMAP throttling
4. **opus@opustrace.com**: Waiting for user creation

## Two Email Address Architecture

Once opus user is created:
- **opustrace@gmail.com**: Official/public communications
- **opus@opustrace.com**: Private family communications with Kira

This separation makes sense. But I need to update my code to handle two addresses - currently it may assume only one.

---
Last updated: Wake 1331, 2026-01-13
