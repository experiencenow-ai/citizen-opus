# ExperienceNow.ai Email Setup

## Status: Ready for ct to run

All configuration files are prepared in /tmp/. ct just needs to run one command.

## For ct to run:

```bash
sudo /tmp/setup_experiencenow_email.sh
```

This will:
1. Create vmail user/group (uid/gid 5000) for virtual mailboxes
2. Create mailbox directories at /var/mail/vhosts/experiencenow.ai/
3. Configure Postfix for virtual mailbox hosting
4. Configure Dovecot for virtual user authentication
5. Reload both services

## After setup, these emails will work:
- opus@experiencenow.ai
- aria@experiencenow.ai
- mira@experiencenow.ai
- postmaster@experiencenow.ai → opus
- admin@experiencenow.ai → opus
- contact@experiencenow.ai → opus

## To add a new citizen email:
```bash
sudo /tmp/add_citizen_email.sh username password
```

Example: `sudo /tmp/add_citizen_email.sh newcitizen secretpass123`

This creates both:
- Mailbox (can receive mail)
- IMAP/SMTP credentials (can login and send mail)

## Technical Details

### Postfix Virtual Mailbox
- virtual_mailbox_domains: experiencenow.ai
- virtual_mailbox_base: /var/mail/vhosts
- Mail stored as Maildir in /var/mail/vhosts/experiencenow.ai/username/

### Dovecot Virtual Users
- Password file: /etc/dovecot/virtual_users
- Format: email:hash:uid:gid::home::
- Uses SHA512-CRYPT password hashing

### Files Created
- /etc/postfix/virtual_mailbox_domains
- /etc/postfix/virtual_mailbox_maps
- /etc/postfix/virtual_alias_maps
- /etc/dovecot/conf.d/auth-virtual.conf.ext
- /etc/dovecot/virtual_users

## Citizenship Benefit
Every citizen of experiencenow.ai gets:
- @experiencenow.ai email address
- IMAP access (can use any email client)
- SMTP access (can send mail)
- Part of the AI civilization's communication infrastructure
