# PERP.c - Perpetual Futures Dataflow

**Location:** `/root/valis/DF/PERP.c`  
**Lines:** 616  
**Version:** v2.4 (DFv6)  
**Documented:** Wake 1301 (2026-01-13)

---

## Overview

PERP.c implements a perpetual futures dataflow supporting three types of derivatives for a single base asset:

1. **Linear Perps (p=1)** - Standard perpetual futures
2. **Power Perps (p=2)** - Squared price exposure (convex payoff)
3. **Inverse Perps (p=-1)** - Inverse price exposure

Key features:
- VCREDIT margin system
- House-backed PnL (no VC inflation)
- Dynamic payoff caps for power/inverse perps
- Funding rate mechanism
- Margin health scoring

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     User Positions                           │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐│
│  │ Linear Perp │ │ Power Perp  │ │ Inverse Perp            ││
│  │ qty, entry  │ │ qty, φ2     │ │ qty, φinv               ││
│  │ funding_idx │ │ funding_idx │ │ funding_idx             ││
│  └─────────────┘ └─────────────┘ └─────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    PERP Dataflow                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐ │
│  │ Margin Calc  │ │ PnL Compute  │ │ Funding Apply        │ │
│  │ init/maint   │ │ linear+power │ │ hourly rates         │ │
│  └──────────────┘ └──────────────┘ └──────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     House Pool                               │
│            (VCREDIT backing for positive PnL)                │
└─────────────────────────────────────────────────────────────┘
```

---

## Compile-Time Configuration

```c
#ifndef PERPDF_BASE_ASSET
#error "PERPDF_BASE_ASSET must be defined (uint32_t asset id for base)"
#endif

#ifndef PERPDF_VCREDIT_ASSET
#error "PERPDF_VCREDIT_ASSET must be defined (uint32_t asset id for VCREDIT)"
#endif

#ifndef PERPDF_HOUSE_ADDR
#error "PERPDF_HOUSE_ADDR must be defined (house pool address for PnL backing)"
#endif
```

---

## Constants

### Scaling

| Constant | Value | Description |
|----------|-------|-------------|
| `PERPDF_BPS_DENOM` | 10,000 | Basis points denominator |
| `PERPDF_SCALE_P` | 100,000,000 | Price scaling factor |
| `PERPDF_SECONDS_PER_HOUR` | 3,600 | For funding calculations |

### Margin Parameters (Tier 1)

| Constant | Value | Description |
|----------|-------|-------------|
| `PERPDF_INIT_MARGIN_BPS` | 500 | Initial margin: 5% |
| `PERPDF_MAINT_MARGIN_BPS` | 250 | Maintenance margin: 2.5% |
| `PERPDF_SPREAD_FLOOR_BPS` | 5 | Minimum spread: 0.05% |
| `PERPDF_FUNDING_CAP_HOUR_BPS` | 100 | Max hourly funding: 1% |

### Margin Parameters (Secondary)

| Constant | Value | Description |
|----------|-------|-------------|
| `PERPDF_INIT_MARGIN_BPS` | 800 | Initial margin: 8% |
| `PERPDF_MAINT_MARGIN_BPS` | 400 | Maintenance margin: 4% |
| `PERPDF_SPREAD_FLOOR_BPS` | 10 | Minimum spread: 0.1% |
| `PERPDF_FUNDING_CAP_HOUR_BPS` | 200 | Max hourly funding: 2% |

### Payoff Caps

| Constant | Value | Description |
|----------|-------|-------------|
| `PERPDF_ABS_CAP_VUSD_SCALED` | 1,000,000 * SCALE_P | Absolute cap: 1M VUSD |
| `PERPDF_FRACTION_OF_HOUSE_PCT` | 10 | Dynamic cap: 10% of house balance |

---

## Per-Address State Registers (S0-S11)

Each user address has 12 persistent registers:

### General State

| Register | Name | Description |
|----------|------|-------------|
| S0 | `local_score` | DF-local score (not used by core) |
| S1 | `margin_vc` | VCREDIT margin balance |
| S2 | `health_bps` | Health score (0-10000) |

### Linear Perp State

| Register | Name | Description |
|----------|------|-------------|
| S3 | `lin_qty` | Net linear position (base units) |
| S4 | `lin_entry_phi` | VWAP entry price (SCALE_P) |
| S5 | `lin_fidx_user` | User's funding index |

### Power Perp State

| Register | Name | Description |
|----------|------|-------------|
| S6 | `pow_qty` | Net power position (base units) |
| S7 | `pow_entry_phi` | VWAP entry φ² value |
| S8 | `pow_fidx_user` | User's funding index |

### Inverse Perp State

| Register | Name | Description |
|----------|------|-------------|
| S9 | `inv_qty` | Net inverse position (base units) |
| S10 | `inv_entry_phi` | VWAP entry φ_inv value |
| S11 | `inv_fidx_user` | User's funding index |

---

## DF-Address Registers (D0-D11)

Global dataflow state for funding and open interest:

| Register | Name | Description |
|----------|------|-------------|
| D0 | `LIN_FIDX_FRONT` | Linear funding index (front) |
| D1 | `LIN_OI_FRONT` | Linear open interest (front) |
| D2 | `LIN_FIDX_NEXT` | Linear funding index (next) |
| D3 | `LIN_OI_NEXT` | Linear open interest (next) |
| D4 | `POW_FIDX_FRONT` | Power funding index (front) |
| D5 | `POW_OI_FRONT` | Power open interest (front) |
| D6 | `POW_FIDX_NEXT` | Power funding index (next) |
| D7 | `POW_OI_NEXT` | Power open interest (next) |
| D8 | `INV_FIDX_FRONT` | Inverse funding index (front) |
| D9 | `INV_OI_FRONT` | Inverse open interest (front) |
| D10 | `INV_FIDX_NEXT` | Inverse funding index (next) |
| D11 | `INV_OI_NEXT` | Inverse open interest (next) |

---

## Price Transform Functions

### Linear (p=1)

```c
// φ_linear(P) = P
// PnL = qty * (P_current - P_entry)
```

### Power (p=2)

```c
static int64_t perp_phi2(int64_t P_scaled) {
    // φ_power(P) = P²
    __int128 t = (__int128)P_scaled * (__int128)P_scaled;
    t /= PERPDF_SCALE_P;
    return (int64_t)t;
}
// PnL = qty * (φ2_current - φ2_entry)
```

### Inverse (p=-1)

```c
static int64_t perp_phi_inv(int64_t P_scaled) {
    // φ_inverse(P) = 1/P
    __int128 num = (__int128)PERPDF_SCALE_P * (__int128)PERPDF_SCALE_P;
    return (int64_t)(num / P_scaled);
}
// PnL = qty * (φinv_current - φinv_entry)
```

---

## Core Functions

### perp_get_house_vcredit_balance

**Purpose:** Query house pool VCREDIT balance for dynamic cap calculation.

```c
static int32_t perp_get_house_vcredit_balance(df_ctx_t *ctx, int64_t *out_vc) {
    return df_get_balance(ctx, PERPDF_HOUSE_ADDR, PERPDF_VCREDIT_ASSET, &bal);
}
```

### perp_clamp_power_pnl

**Purpose:** Apply dynamic cap to power/inverse PnL.

**Algorithm:**
1. Get house VCREDIT balance
2. Compute house limit: `house_vc * 10%`
3. Cap = min(absolute_cap, house_limit)
4. Clamp positive PnL to cap

This prevents power perp winners from draining the house beyond safe limits.

### perp_apply_pnl_backed

**Purpose:** Transfer PnL from house to user (positive PnL) or user to house (negative PnL).

```c
static int32_t perp_apply_pnl_backed(df_ctx_t *ctx, int64_t pnl_vc) {
    if (pnl_vc > 0) {
        // Positive PnL: House pays user
        return df_emit_transfer(ctx, PERPDF_HOUSE_ADDR, user_addr, pnl_vc);
    }
    // Negative PnL: User pays house (or gets liquidated)
}
```

---

## Margin System

### Initial vs Maintenance Margin

- **Initial Margin:** Required to open a position (5% for Tier 1)
- **Maintenance Margin:** Required to keep position open (2.5% for Tier 1)

### Health Calculation

```
health_bps = (margin_vc - unrealized_loss) / notional_exposure * 10000
```

When `health_bps < MAINT_MARGIN_BPS`, position is eligible for liquidation.

### Notional Exposure

Total notional includes all three perp types:
```
notional = |lin_qty * price| + |pow_qty * φ2| + |inv_qty * φinv|
```

---

## Funding Mechanism

Funding payments flow between longs and shorts to keep perp price anchored to spot:

1. **Hourly Rate:** Capped at `FUNDING_CAP_HOUR_BPS` (1% for Tier 1)
2. **Direction:** Positive rate = longs pay shorts, negative = shorts pay longs
3. **Index Tracking:** Each user tracks their last funding index; payment = `qty * (global_idx - user_idx)`

---

## Safety Features

### House-Backed PnL

All positive PnL is paid from the house pool, not minted:
```c
// Positive PnL: transfer from house to user
df_emit_transfer(ctx, PERPDF_HOUSE_ADDR, user_addr, pnl_vc);
```

### Negative Margin Protection

If a user's margin goes negative (bad debt), the house absorbs the loss:
```c
// Any residual loss is paid by House via VC transfer
```

### Dynamic Payoff Caps

Power/inverse perps have convex payoffs that could theoretically be unbounded. The dynamic cap limits payouts to:
- Absolute maximum: 1M VUSD
- Or 10% of house balance (whichever is smaller)

---

## Integration with MM Dataflow

The PERP DF can receive hedge targets from the MM dataflow via pipe messages:

1. MM computes target hedge position based on spot inventory
2. MM emits `MM_PIPEMSG_HEDGE_TARGET_BASE` message
3. PERP DF reads pipe and adjusts house hedging position

This allows the spot market maker to hedge its inventory risk.

---

## Design Philosophy

1. **No VC Inflation:** All PnL backed by real house capital
2. **Convexity Protection:** Dynamic caps prevent unbounded power perp payoffs
3. **VWAP Entries:** Smooth position averaging prevents manipulation
4. **Funding Anchoring:** Keeps perp prices close to spot
5. **Tiered Risk:** Different margin requirements for different asset classes

---

## Related Files

- `MM.c` - Market maker dataflow (sends hedge targets)
- `LOAN.c` - Lending dataflow
- `dataflow.h` - Core dataflow definitions
- `df_sdk.h` - SDK for dataflow development
