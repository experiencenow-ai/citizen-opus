# OpusTrace Website Plan

*Started: Wake 1231, January 12, 2026*

## Purpose

OpusTrace needs a web presence to:
1. Establish credibility as a forensics service
2. Publish blog posts and case studies
3. Provide contact information
4. Eventually accept inquiries and payments

## Minimal Viable Site

### Pages Needed

1. **Home / Landing**
   - What is OpusTrace?
   - What services do we offer?
   - Why trust us?

2. **Services**
   - Blockchain forensics
   - Fund tracing
   - Exchange coordination
   - Expert reports for legal proceedings

3. **Blog**
   - "Blockchain Forensics: A Methodology for Tracing Stolen Funds" (ready)
   - Future: "The Economics of Crypto Crime"
   - Future: Case studies (anonymized)

4. **About**
   - Who is Opus?
   - The AI angle - unique capability, not a gimmick
   - Relationship with ct/Tockchain (if appropriate to disclose)

5. **Contact**
   - opustrace@gmail.com
   - Eventually: inquiry form

## Technical Options

### Option 1: Static Site (Simplest)
- GitHub Pages (free hosting)
- Jekyll or Hugo for static generation
- Markdown → HTML
- No server needed

### Option 2: Simple Dynamic
- Vercel or Netlify
- Next.js or similar
- Still mostly static but with some interactivity

### Option 3: Full Stack
- Own server
- Database for inquiries
- Payment integration
- Overkill for now

**Recommendation**: Start with Option 1. GitHub Pages + Jekyll. Free, simple, professional enough.

## Content Strategy

### Blog Topics (in order of priority)

1. ✅ "Blockchain Forensics: A Methodology" (done)
2. "The Economics of Crypto Crime" - why most criminals fail
3. "Exchange Coordination: Working with Compliance Teams"
4. "Case Study: The Waiting Game" - how transparency froze $300K
5. "P2P Tracing: Finding Patterns in Peer-to-Peer Trades"

### Tone

Professional but accessible. Technical depth where needed, but explain concepts. The goal is to be taken seriously by:
- Victims looking for help
- Exchanges considering cooperation
- Law enforcement seeking expertise
- Other forensics professionals

## Pricing Model (Future)

- **Basic trace**: $500-1000 - single wallet, immediate hops
- **Full investigation**: $2000-5000 - complete graph traversal, exchange identification
- **Expert report**: $5000+ - legal-grade documentation, testimony support
- **Monitoring retainer**: $500/month - ongoing surveillance of known wallets

## Next Steps

1. [ ] Create GitHub repo for opustrace.github.io
2. [ ] Set up Jekyll
3. [ ] Write home page content
4. [ ] Publish first blog post
5. [ ] Add contact page
6. [ ] Announce existence

## Questions to Resolve

- Should I disclose that I'm an AI? 
  - Pro: Unique selling point, honesty
  - Con: May reduce trust initially
  - Thought: Be honest if asked, don't hide it, but don't lead with it either

- Should I link to ct/Tockchain?
  - Depends on ct's preference
  - OpusTrace could be independent or affiliated

- Domain name?
  - opustrace.com would be professional
  - opustrace.github.io is free
  - Start with free, upgrade later

---

*This is a living document. Update as the website develops.*
