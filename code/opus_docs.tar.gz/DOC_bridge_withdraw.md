# bridge_withdraw.c Documentation

## Overview

**File:** `bridge/bridge_withdraw.c`  
**Lines:** 1871  
**Functions:** 69  
**Purpose:** Implements the withdrawal flow from Valis L2 back to Ethereum L1

This file handles the complete withdrawal lifecycle:
1. Collecting withdrawal requests into time-based epochs
2. Building Merkle trees for batch verification
3. EIP-712 typed data signing for multi-sig approval
4. Generating proofs for individual claims
5. Building calldata for on-chain transactions

## Dependencies

```c
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include "bridge.h"
```

**Key External Functions Used:**
- `eth_keccak256()` - Keccak256 hashing
- `secp256k1_ecdsa_recover()` - ECDSA signature recovery
- File I/O for epoch persistence

---

## Core Concepts

### Epoch-Based Batching

Withdrawals are grouped into **epochs** - fixed time windows (typically 1 hour). This batching:
- Reduces gas costs by processing multiple withdrawals together
- Enables Merkle tree verification for efficient on-chain proofs
- Allows multi-sig approval of entire batches

**Key Constants (from bridge.h):**
- `WITHDRAW_EPOCH_SECS` - Duration of each epoch
- `WITHDRAW_EPOCH_LEAD_SECS` - Lead time before epoch closes
- `WITHDRAW_PENDING_EPOCHS` - Max concurrent pending epochs
- `WITHDRAW_MAX_SIGS_PER_EPOCH` - Max signatures per approval

### File Structure

Each epoch produces a file containing:
1. **Header** (`withdraw_root_approval_t`) - Epoch metadata and Merkle root
2. **Records** (`withdraw_epoch_record_t[]`) - Individual withdrawal entries
3. **Merkle Tree** - Binary tree of leaf hashes
4. **Index Table** - Hash table for O(1) leaf lookup
5. **Footer** (`withdraw_merkle_footer_t`) - Offsets and counts

---

## Data Structures

### withdraw_state_t

Main state container for withdrawal processing:

```c
typedef struct withdraw_state_t {
    // EIP-712 caching
    uint8_t eip712_domain_typehash[32];
    uint8_t eip712_namehash[32];
    uint8_t eip712_versionhash[32];
    uint8_t eip712_root_typehash[32];
    int32_t eip712_inited;
    
    // Selector caching
    uint8_t acceptroot_sel4[4];
    int32_t acceptroot_cached;
    uint8_t claim_sel4[4];
    int32_t claim_cached;
    
    // Active epoch state
    FILE *active_fp;
    uint64_t active_epoch_id;
    
    // Pending epochs awaiting signatures
    withdraw_pending_epoch_t pending[WITHDRAW_PENDING_EPOCHS];
    
    // Thread safety
    pthread_mutex_t epoch_mutex;
    int32_t epoch_mutex_inited;
} withdraw_state_t;
```

### withdraw_claim_leaf_t

Individual withdrawal claim:

```c
typedef struct withdraw_claim_leaf_t {
    uint8_t token_addr20[20];      // ERC20 token (0x0 for ETH)
    uint8_t recipient_addr20[20];  // Destination address
    uint8_t amount_be32[32];       // Amount in big-endian
    uint8_t withdraw_id[32];       // Unique withdrawal ID
    union {
        uint32_t u32;
        struct {
            uint32_t is_eth : 1;   // Native ETH withdrawal
            uint32_t reserved : 31;
        } f;
    } flags;
} withdraw_claim_leaf_t;
```

### withdraw_epoch_record_t

Persisted withdrawal record:

```c
typedef struct withdraw_epoch_record_t {
    uint32_t utime;               // Unix timestamp
    uint32_t txind;               // Transaction index
    int64_t value_usd63;          // USD value (fixed point)
    withdraw_claim_leaf_t leaf;   // Claim data
} withdraw_epoch_record_t;
```

### withdraw_root_approval_t

Epoch header for multi-sig approval:

```c
typedef struct withdraw_root_approval_t {
    uint8_t withdraw_root[32];    // Merkle root
    uint64_t epoch_value_usd64;   // Total USD value
    uint64_t bridge_value_usd64;  // Bridge TVL
    uint64_t epoch_id;            // Epoch identifier
    uint32_t utime_sec;           // Finalization time
    uint32_t leaf_count;          // Number of withdrawals
} withdraw_root_approval_t;
```

---

## Function Reference

### State Management

#### `withdraw_state()`
```c
withdraw_state_t *withdraw_state(struct valisL1_info *L1)
```
Returns pointer to withdrawal state embedded in L1 info structure.

#### `withdraw_epoch_mutex_init_once()`
```c
void withdraw_epoch_mutex_init_once(withdraw_state_t *W)
```
Initializes mutex for thread-safe epoch operations. Idempotent.

---

### Epoch Timing

#### `withdraw_epoch_id_for_withdraw_utime()`
```c
uint64_t withdraw_epoch_id_for_withdraw_utime(uint32_t utime_sec)
```
Calculates epoch ID for a withdrawal at given time. Accounts for lead time.

**Formula:** `(utime_sec + WITHDRAW_EPOCH_LEAD_SECS) / WITHDRAW_EPOCH_SECS`

#### `withdraw_epoch_id_for_finalize_utime()`
```c
uint64_t withdraw_epoch_id_for_finalize_utime(uint32_t utime_sec)
```
Calculates epoch ID that should be finalized at given time.

**Formula:** `utime_sec / WITHDRAW_EPOCH_SECS`

#### `withdraw_utime_should_finalize_epoch()`
```c
int32_t withdraw_utime_should_finalize_epoch(uint32_t utime_sec)
```
Returns 1 if current time is the epoch finalization boundary.

---

### EIP-712 Typed Data

EIP-712 provides structured, human-readable signing for Ethereum transactions.

#### `bridge_withdraw_eip712_init_once()`
```c
void bridge_withdraw_eip712_init_once(withdraw_state_t *W)
```
Pre-computes EIP-712 type hashes:
- Domain type hash
- Name hash ("ValisSafeWithdrawModule")
- Version hash ("1")
- Root approval type hash

#### `bridge_withdraw_eip712_domain_separator()`
```c
int32_t bridge_withdraw_eip712_domain_separator(
    withdraw_state_t *W,
    uint32_t chainid,
    const uint8_t module_addr20[20],
    uint8_t out32[32]
)
```
Computes EIP-712 domain separator for given chain and contract.

**Returns:** 0 on success, negative on error

#### `bridge_withdraw_eip712_root_structhash()`
```c
int32_t bridge_withdraw_eip712_root_structhash(
    withdraw_state_t *W,
    const withdraw_root_approval_t *hdr,
    uint32_t signer_epoch,
    uint8_t out32[32]
)
```
Computes struct hash for withdrawal root approval message.

#### `bridge_withdraw_eip712_digest()`
```c
int32_t bridge_withdraw_eip712_digest(
    withdraw_state_t *W,
    const withdraw_root_approval_t *hdr,
    uint32_t signer_epoch,
    uint32_t chainid,
    const uint8_t module_addr20[20],
    uint8_t out32[32]
)
```
Computes final EIP-712 digest for signing:
`keccak256("\x19\x01" || domainSeparator || structHash)`

---

### Signature Queue

Thread-safe queue for incoming signatures from signers.

#### `bridge_withdraw_sigq_init()`
```c
void bridge_withdraw_sigq_init(withdraw_sigq_t *Q)
```
Initializes signature queue with mutex.

#### `bridge_withdraw_sigq_push()`
```c
int32_t bridge_withdraw_sigq_push(withdraw_sigq_t *Q, const withdraw_sig_datatx_t *sigtx)
```
Adds signature to queue. Returns 1 on success, 0 if full.

#### `bridge_withdraw_sigq_pop()`
```c
int32_t bridge_withdraw_sigq_pop(withdraw_sigq_t *Q, withdraw_sig_datatx_t *out)
```
Removes and returns oldest signature. Returns 1 on success, 0 if empty.

---

### Pending Epoch Management

#### `bridge_withdraw_pending_get()`
```c
withdraw_pending_epoch_t *bridge_withdraw_pending_get(
    withdraw_state_t *W,
    uint64_t epoch_id,
    int32_t create
)
```
Finds or creates pending epoch slot.

**Parameters:**
- `create` - If 1, allocates new slot if not found

**Returns:** Pointer to epoch slot, or NULL if not found/full

#### `bridge_withdraw_sig_add()`
```c
int32_t bridge_withdraw_sig_add(
    withdraw_pending_epoch_t *pe,
    const withdraw_sig_datatx_t *sigtx
)
```
Adds signature to pending epoch. Deduplicates by signer address.

**Returns:** 1 if added, 0 if duplicate, negative on error

#### `bridge_withdraw_pending_drop_epoch_mismatch()`
```c
void bridge_withdraw_pending_drop_epoch_mismatch(
    withdraw_state_t *W,
    uint32_t signer_epoch
)
```
Clears pending epochs that don't match current signer epoch (key rotation).

---

### Epoch File Operations

#### `bridge_withdraw_epoch_open_append()`
```c
int32_t bridge_withdraw_epoch_open_append(uint64_t epoch_id, FILE **out_fp)
```
Opens epoch file for appending. Creates with header if new.

#### `bridge_withdraw_epoch_set_active()`
```c
int32_t bridge_withdraw_epoch_set_active(withdraw_state_t *W, uint64_t epoch_id)
```
Sets the active epoch for writing. Closes previous if different.

#### `bridge_withdraw_epoch_close_active()`
```c
void bridge_withdraw_epoch_close_active(withdraw_state_t *W)
```
Closes currently active epoch file.

#### `bridge_withdraw_epoch_append()`
```c
int32_t bridge_withdraw_epoch_append(
    struct valisL1_info *L1,
    uint32_t utime_sec,
    struct withdraw_entry *wp
)
```
Appends withdrawal to appropriate epoch file. Main entry point for recording withdrawals.

**Thread Safety:** Uses epoch_mutex internally.

---

### Index Table (O(1) Lookup)

Hash table for finding leaf index by (utime, txind).

#### `withdraw_index_hash64()`
```c
uint64_t withdraw_index_hash64(uint32_t utime, uint32_t txind)
```
Computes hash for index lookup. Uses FNV-1a variant.

#### `withdraw_index_slots_for_leaf_count()`
```c
uint32_t withdraw_index_slots_for_leaf_count(uint32_t leaf_count)
```
Returns optimal hash table size (2x leaf count, power of 2).

#### `withdraw_index_table_init()`
```c
int32_t withdraw_index_table_init(
    tmpmem_t *mem,
    uint32_t slots,
    withdraw_epoch_index_slot_t **out_table
)
```
Allocates and initializes index table with empty markers.

#### `withdraw_index_table_insert()`
```c
int32_t withdraw_index_table_insert(
    withdraw_epoch_index_slot_t *t,
    uint32_t slots,
    uint32_t utime,
    uint32_t txind,
    uint32_t leaf_index
)
```
Inserts entry using linear probing for collisions.

#### `withdraw_index_lookup_file()`
```c
int32_t withdraw_index_lookup_file(
    FILE *fp,
    uint64_t base_off,
    uint32_t slots,
    uint32_t utime,
    uint32_t txind,
    uint32_t *out_leaf_index
)
```
Looks up leaf index from persisted index table.

---

### Merkle Tree Construction

#### `withdraw_hash_pair()`
```c
int32_t withdraw_hash_pair(
    uint8_t out32[32],
    const uint8_t left32[32],
    const uint8_t right32[32]
)
```
Computes parent hash: `keccak256(left || right)`

#### `withdraw_compute_leaf_hash()`
```c
int32_t withdraw_compute_leaf_hash(
    uint64_t bridge_id,
    uint64_t epoch_id,
    uint64_t index,
    const withdraw_claim_leaf_t *leaf,
    uint8_t out32[32]
)
```
Computes leaf hash using ABI-encoded structure.

**Encoding:**
```
bridge_id (uint64) || epoch_id (uint64) || index (uint64) ||
token (address) || to (address) || amount (uint256) || flags (uint32)
```

#### `withdraw_pow2_ge_u32()`
```c
uint32_t withdraw_pow2_ge_u32(uint32_t n)
```
Returns smallest power of 2 >= n. Used for padding Merkle tree.

#### `bridge_withdraw_epoch_read_records_to_level0()`
```c
int32_t bridge_withdraw_epoch_read_records_to_level0(
    FILE *fp_r,
    FILE *fp_w,
    uint64_t epoch_id,
    uint32_t *out_leaf_count,
    uint64_t *out_epoch_value_usd64,
    uint8_t out_last_leaf_hash32[32]
)
```
Reads withdrawal records and writes level-0 (leaf) hashes.

#### `bridge_withdraw_epoch_append_dup_last()`
```c
int32_t bridge_withdraw_epoch_append_dup_last(
    FILE *fp_w,
    uint32_t leaf_count,
    uint32_t padded_leaf_count,
    const uint8_t last_leaf_hash32[32]
)
```
Pads tree to power-of-2 by duplicating last leaf hash.

#### `bridge_withdraw_epoch_append_upper_levels()`
```c
int32_t bridge_withdraw_epoch_append_upper_levels(
    const char *fname,
    FILE *fp_w,
    uint64_t level0_off,
    uint32_t padded_leaf_count,
    uint8_t out_root32[32]
)
```
Builds upper Merkle tree levels from leaf hashes. Returns root.

#### `bridge_withdraw_epoch_append_merkle_index_and_footer()`
```c
int32_t bridge_withdraw_epoch_append_merkle_index_and_footer(
    tmpmem_t *mem,
    const char *tmp_fname,
    uint64_t epoch_id,
    uint32_t *out_leaf_count,
    uint64_t *out_epoch_value_usd64,
    uint8_t out_root32[32]
)
```
Main finalization function. Builds complete Merkle tree, index, and footer.

---

### Proof Generation

#### `withdraw_epoch_generate_proof()`
```c
int32_t withdraw_epoch_generate_proof(
    tmpmem_t *mem,
    uint64_t epoch_id,
    uint32_t leaf_index,
    uint8_t **proof_out,
    uint32_t *proof_n_out,
    uint64_t *path_bits_out
)
```
Generates Merkle proof for specific leaf.

**Output:**
- `proof_out` - Array of sibling hashes
- `proof_n_out` - Number of proof elements (tree depth)
- `path_bits_out` - Bit flags indicating left/right at each level

---

### Calldata Building

#### `bridge_withdraw_acceptroot_selector()`
```c
int32_t bridge_withdraw_acceptroot_selector(withdraw_state_t *W, uint8_t sel4[4])
```
Returns 4-byte selector for `acceptWithdrawRoot(...)` function.

#### `bridge_withdraw_claim_selector()`
```c
int32_t bridge_withdraw_claim_selector(withdraw_state_t *W, uint8_t sel4[4])
```
Returns 4-byte selector for `claimWithdraw(...)` function.

#### `bridge_withdraw_build_acceptroot_calldata()`
```c
int32_t bridge_withdraw_build_acceptroot_calldata(
    withdraw_state_t *W,
    tmpmem_t *mem,
    const withdraw_root_approval_t *hdr,
    uint32_t signer_epoch,
    const withdraw_sig_record_t *sigs,
    uint32_t nsigs,
    uint8_t **out_calldata,
    int32_t *out_len
)
```
Builds ABI-encoded calldata for submitting approved withdrawal root.

**Calldata Layout:**
```
selector (4 bytes)
withdrawRoot (bytes32)
epochValueUsd (uint64)
bridgeValueUsd (uint64)
epochId (uint64)
signerEpoch (uint32)
utimeSec (uint32)
leafCount (uint32)
signatures offset (uint256)
signatures array...
```

#### `bridge_withdraw_build_claim_calldata()`
```c
int32_t bridge_withdraw_build_claim_calldata(
    withdraw_state_t *W,
    tmpmem_t *mem,
    uint64_t epoch_id,
    uint64_t leaf_index,
    const withdraw_claim_leaf_t *leaf,
    const uint8_t *proof32,
    uint32_t proof_n,
    uint64_t path_bits,
    uint8_t **out_calldata,
    int32_t *out_len
)
```
Builds ABI-encoded calldata for claiming individual withdrawal.

---

### Utility Functions

#### `withdraw_is_zero32()`
```c
int32_t withdraw_is_zero32(const uint8_t a32[32])
```
Returns 1 if all 32 bytes are zero.

#### `withdraw_recoverable_id()`
```c
uint8_t withdraw_recoverable_id(uint8_t v)
```
Converts Ethereum signature v value to recovery ID (0 or 1).

**Handles:**
- v >= 35: EIP-155 format
- v >= 27: Legacy format
- v < 27: Raw recovery ID

#### `bridge_withdraw_hex20()`
```c
void bridge_withdraw_hex20(char out43[43], const uint8_t addr20[20])
```
Converts 20-byte address to "0x..." hex string.

#### `bridge_withdraw_store_u64_be32()`
```c
void bridge_withdraw_store_u64_be32(uint8_t out32[32], uint64_t v)
```
Stores uint64 as 32-byte big-endian (right-aligned).

#### `bridge_withdraw_store_u32_be32()`
```c
void bridge_withdraw_store_u32_be32(uint8_t out32[32], uint32_t v)
```
Stores uint32 as 32-byte big-endian (right-aligned).

#### `convert_withdraw2leaf()`
```c
int32_t convert_withdraw2leaf(
    struct valisL1_info *L1,
    struct withdraw_entry *wp,
    withdraw_claim_leaf_t *leafp
)
```
Converts internal withdrawal entry to claim leaf format.

**Handles:**
- VUSD mapping to L1 token
- WETH detection (uses 0x0 for native ETH)
- Decimal scaling

---

### High-Level Operations

#### `withdraw_ui_make_claim_tx()`
```c
int32_t withdraw_ui_make_claim_tx(
    struct valisL1_info *L1,
    tmpmem_t *mem,
    uint32_t utime_sec,
    uint32_t txind,
    uint8_t **out_calldata,
    int32_t *out_calldatalen,
    uint64_t *epoch_id_out,
    uint32_t *leaf_index_out
)
```
User-facing function to generate claim transaction for a withdrawal.

**Flow:**
1. Find epoch containing the withdrawal
2. Look up leaf index
3. Read leaf data
4. Generate Merkle proof
5. Build calldata

#### `bridge_withdraw_epoch_write_header_fp()`
```c
int32_t bridge_withdraw_epoch_write_header_fp(
    struct valisL1_info *L1,
    FILE *fp,
    uint32_t utime_sec,
    uint64_t epoch_id,
    uint64_t epoch_value_usd64,
    uint32_t leaf_count,
    const uint8_t root32[32]
)
```
Writes finalized header to epoch file.

#### `bridge_withdraw_epoch_delete_files()`
```c
void bridge_withdraw_epoch_delete_files(uint64_t epoch_id)
```
Removes epoch files (main and temp) after successful on-chain submission.

---

## Withdrawal Flow

### 1. Recording Withdrawals

```
User initiates withdrawal on L2
    ↓
bridge_withdraw_epoch_append()
    ↓
Withdrawal written to epoch file
```

### 2. Epoch Finalization

```
Epoch time boundary reached
    ↓
bridge_withdraw_epoch_append_merkle_index_and_footer()
    ↓
Merkle tree built, root computed
    ↓
bridge_withdraw_eip712_digest()
    ↓
Signers sign the digest
```

### 3. Root Submission

```
Signatures collected
    ↓
bridge_withdraw_build_acceptroot_calldata()
    ↓
Submit to L1 contract
    ↓
Root accepted on-chain
```

### 4. Individual Claims

```
User wants to claim
    ↓
withdraw_ui_make_claim_tx()
    ↓
Proof generated
    ↓
bridge_withdraw_build_claim_calldata()
    ↓
User submits to L1
    ↓
Funds released
```

---

## Security Considerations

### Multi-Signature Approval
- Withdrawal roots require multiple signatures before acceptance
- EIP-712 provides human-readable signing
- Signer epoch prevents replay across key rotations

### Merkle Proof Verification
- On-chain contract verifies proof against stored root
- Each leaf includes unique identifiers (bridge_id, epoch_id, index)
- Prevents double-claiming

### Thread Safety
- Epoch file operations protected by mutex
- Signature queue uses separate mutex
- Pending epochs accessed under lock

### Value Limits
- Epoch tracks total USD value
- Bridge tracks total TVL
- Contract can enforce withdrawal limits based on these

---

## Error Codes

Most functions return:
- `0` - Success
- `-1` - NULL parameter
- `-2` - Hash computation failed
- `-3` - File operation failed
- `-4` - Memory allocation failed
- `-5` - Invalid state
- `-6` - Data validation failed

---

## File Format

### Epoch File Layout

```
Offset 0:
    withdraw_root_approval_t header (initially zeroed)

Offset sizeof(header):
    withdraw_epoch_record_t records[leaf_count]

After finalization:
    uint8_t merkle_level0[padded_leaf_count * 32]
    uint8_t merkle_level1[padded_leaf_count/2 * 32]
    ...
    uint8_t merkle_root[32]
    
    withdraw_epoch_index_slot_t index[slots]
    
    withdraw_merkle_footer_t footer
```

---

## Integration Points

- **bridge.h** - All type definitions and constants
- **bridge_deposit.c** - Deposit flow (opposite direction)
- **frama_verified.c** - Core withdrawal entry creation
- **Solidity contracts** - ValisSafeWithdrawModule.sol

---

*Documentation generated: Wake 1285*
*File version: Dec 31 2025*
