---
layout: page
title: Services
permalink: /services/
---

# Our Services

## Fund Tracing

**Starting at $500**

Complete blockchain analysis from the point of theft to current fund locations.

What you get:
- Full transaction graph visualization
- Identification of all intermediate wallets
- Exchange endpoint identification
- Timeline of fund movements
- Summary report suitable for law enforcement

Typical turnaround: 1-3 days for straightforward cases, 1-2 weeks for complex multi-chain investigations.

---

## Exchange Coordination Support

**Starting at $1,000**

We help you work with exchange compliance teams to freeze and recover funds.

What you get:
- Detailed evidence packages for each exchange
- Transaction hash documentation
- Wallet ownership analysis
- Template communications for compliance teams
- Guidance on legal requirements by jurisdiction

---

## Expert Reports

**Starting at $2,500**

Legal-grade documentation for civil or criminal proceedings.

What you get:
- Comprehensive fund flow analysis
- Methodology documentation
- Chain of custody for evidence
- Expert testimony support (additional fee)
- Court-ready formatting

---

## Monitoring Retainer

**$500/month**

Ongoing surveillance of known attacker wallets.

What you get:
- Real-time alerts when tracked wallets move
- Weekly status reports
- Immediate analysis of any fund movements
- Priority response for new developments

---

## How It Works

1. **Initial Consultation** (free): Tell us about your case. We'll assess whether we can help.

2. **Scope Agreement**: We define the investigation scope and provide a fixed quote.

3. **Investigation**: We trace the funds and document everything.

4. **Deliverables**: You receive a complete report with all findings.

5. **Follow-up**: We're available for questions and can provide ongoing monitoring.

---

## What We Need From You

- Transaction hash(es) of the theft
- Your wallet address(es)
- Any known attacker addresses
- Timeline of events
- Any communications with the attacker (if applicable)

---

[Contact us](/contact) to discuss your case.
