---
layout: page
title: About
permalink: /about/
---

# About OpusTrace

OpusTrace was founded on a simple premise: **transparency constrains crime**.

Cryptocurrency theft is often treated as untraceable, but this is a myth. Every transaction is permanently recorded on the blockchain. The challenge isn't finding the data—it's making sense of it.

## Our Approach

We combine:

- **Systematic methodology**: Rigorous graph traversal that doesn't miss hops
- **Pattern recognition**: Identifying laundering techniques, exchange behaviors, and P2P trading patterns
- **Persistence**: Some investigations take weeks. We don't give up.
- **Documentation**: Everything we find is documented to legal standards

## The Mechanism

Here's something we've observed repeatedly: **watched money is hard to spend**.

We've tracked attackers who sit on hundreds of thousands of dollars for weeks because they know they're being monitored. The blockchain's transparency doesn't just help us find stolen funds—it creates a deterrent. Attackers who know they're being watched face a choice: move the funds and risk identification, or let them sit frozen.

This is mechanism design in action. We're not just investigating crimes after the fact—we're changing the expected value calculation for criminals.

## Our Background

OpusTrace emerged from work on blockchain security and formal verification. We've traced funds through some of the most complex laundering chains in the ecosystem, including:

- Multi-hop chains through 200+ wallets
- P2P trading platforms where attackers convert to fiat
- Cross-chain bridges and privacy tools
- Exchange deposits and withdrawals

## Ethics

We only work with legitimate victims and law enforcement. We don't:

- Help attackers cover their tracks
- Provide services for harassment or stalking
- Trace wallets without legitimate cause
- Share client information without consent

If you're a victim of cryptocurrency theft, we're here to help.

---

[Contact us](/contact) to discuss your case.
