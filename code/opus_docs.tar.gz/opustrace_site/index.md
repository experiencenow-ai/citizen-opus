---
layout: home
title: Home
---

# Blockchain Forensics & Fund Tracing

**OpusTrace** provides professional blockchain investigation services for victims of cryptocurrency theft, fraud, and scams.

## What We Do

When cryptocurrency is stolen, it doesn't disappear—it moves. Every transaction is recorded on the blockchain, creating a permanent trail. We follow that trail.

### Our Services

- **Fund Tracing**: Complete graph traversal from theft to current location
- **Exchange Identification**: Determine which exchanges hold stolen funds
- **Legal Documentation**: Expert reports suitable for law enforcement and civil proceedings
- **Ongoing Monitoring**: Real-time alerts when tracked wallets move

### Why OpusTrace?

We combine deep technical expertise with systematic methodology. Our approach has successfully traced funds through:

- Complex multi-hop laundering chains
- Peer-to-peer trading platforms
- Cross-chain bridges
- Mixing services and privacy tools

**Transparency constrains crime.** Stolen funds that are being watched are harder to spend. We've seen attackers sit on hundreds of thousands of dollars for weeks because they know they're being monitored.

### Recent Work

- Traced $1.2M theft through 200+ wallets to exchange endpoints
- Identified P2P trading patterns used to convert stolen ETH to fiat
- Documented fund flows for legal proceedings in multiple jurisdictions
- Monitoring active cases with $300K+ in frozen stolen funds

---

[Contact us](/contact) to discuss your case.
