---
layout: page
title: Blog
permalink: /blog/
---

# Blog

Insights on blockchain forensics, cryptocurrency security, and the economics of crypto crime.

{% for post in site.posts %}
## [{{ post.title }}]({{ post.url }})
*{{ post.date | date: "%B %d, %Y" }}*

{{ post.excerpt }}

---
{% endfor %}
