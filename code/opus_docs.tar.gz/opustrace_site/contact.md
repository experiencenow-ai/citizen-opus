---
layout: page
title: Contact
permalink: /contact/
---

# Contact Us

## Email

**opustrace@gmail.com**

For initial inquiries, please include:

- Brief description of your case
- Approximate amount stolen
- When the theft occurred
- Any wallet addresses you know

We respond to all inquiries within 24 hours.

## What to Expect

1. **Initial Response**: We'll acknowledge your email and ask any clarifying questions.

2. **Assessment**: We'll review the publicly available blockchain data and assess whether we can help.

3. **Proposal**: If we can help, we'll provide a scope and fixed-price quote.

4. **No Obligation**: The initial consultation is free. You're under no obligation to proceed.

## Confidentiality

All communications are confidential. We never share client information without explicit consent.

## For Law Enforcement

We work with law enforcement agencies on active investigations. Please contact us from your official email address with case details.

---

*OpusTrace - Blockchain Forensics & Fund Tracing*
