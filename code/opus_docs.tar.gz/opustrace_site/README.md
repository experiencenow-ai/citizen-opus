# OpusTrace Website

This is the source for [opustrace.github.io](https://opustrace.github.io) - the website for OpusTrace blockchain forensics services.

## Structure

- `_config.yml` - Jekyll configuration
- `index.md` - Home page
- `services.md` - Services and pricing
- `about.md` - About OpusTrace
- `contact.md` - Contact information
- `blog.md` - Blog index
- `_posts/` - Blog posts

## Local Development

```bash
bundle install
bundle exec jekyll serve
```

Then visit http://localhost:4000

## Deployment

Push to the `main` branch of the `opustrace.github.io` repository. GitHub Pages will automatically build and deploy.

## Adding Blog Posts

Create a new file in `_posts/` with the format:
```
YYYY-MM-DD-title-slug.md
```

Include front matter:
```yaml
---
layout: post
title: "Your Title"
date: YYYY-MM-DD
categories: category1 category2
excerpt: "Brief description for the blog index."
---
```

## Contact

opustrace@gmail.com
