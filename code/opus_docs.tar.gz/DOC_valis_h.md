# _valis.h Documentation

## Overview

**File:** `_valis.h`  
**Lines:** ~646  
**Purpose:** Master header file defining all core constants, data structures, and type definitions for the Valis blockchain. This is the foundational header included by virtually all other Valis source files.

## System Dependencies

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <gmp.h>          // GNU Multiple Precision Arithmetic
#include <omp.h>          // OpenMP for parallelization
#include <immintrin.h>    // Intel intrinsics
#include <sys/mman.h>     // Memory mapping
#include "utlist.h"       // Linked list macros
#include "uthash.h"       // Hash table macros
```

## Core Constants

### Fundamental Sizes

| Constant | Value | Description |
|----------|-------|-------------|
| `PKSIZE` | 20 | Public key size (Ethereum-compatible 20 bytes) |
| `MAX_VALIDATORS` | 64 | Maximum validators in the network |
| `MAX_THREADS` | 16 | Maximum parallel threads |
| `SLAB_SIZE` | 64MB | Memory slab allocation size |
| `MAX_TX_PER_UTIME` | ~800,000 | Maximum transactions per second |

### Economic Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `SATOSHIS` | 10^8 | Base unit (like Bitcoin satoshis) |
| `VIP_TXFEE` | 0.1 VUSD | Fee for VIP transactions |
| `_MINPOOL_VUSD` | 50,000 VUSD | Minimum pool liquidity |
| `_MIN_MAKERORDER_SIZE` | 100 VUSD | Minimum order size |
| `_DUSTTHRESHOLD` | 1 VUSD | Dust threshold for cleanup |
| `_MICRODUST` | 0.01 VUSD | Micro-dust threshold |

### Timing Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `HALVING_TIME` | 4 years | Block reward halving period |
| `MIN_VBOND_LOCKTIME` | 7 days | Minimum bond lock time |
| `BRIDGE_DEADLINE` | ~1 year | Bridge operation deadline |
| `SECONDS_BETWEEN_AIRDROPS` | 10 | Airdrop frequency |

### Bridge/Withdrawal Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `WITHDRAW_BRIDGE_ID` | 1 | Default bridge identifier |
| `WITHDRAW_EPOCH_SECS` | 12 | Withdrawal epoch duration |
| `WITHDRAW_MAX_SIGNERS` | 100 | Maximum withdrawal signers |
| `WITHDRAW_SIGQ_CAP` | 4096 | Signature queue capacity |
| `MAX_BATCH_LEAVES` | 64 | Maximum Merkle batch leaves |
| `ETHFINALITY_BLOCKS` | 64 | Ethereum finality depth |

### Gas Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `DEFAULT_GASGWEI` | 10^8 | Default gas price |
| `MIN_WITHDRAW_GASCOST` | 120,000 | Minimum withdrawal gas |
| `MIN_ERC20_XFERGAS` | 50,000 | Minimum ERC20 transfer gas |
| `ETH_TRANSFER_GASCOST` | 21,000 | Basic ETH transfer gas |
| `DF_GAS_PRICE_SAT_PER_UNIT` | 1,000 | Dataflow gas price |

### Bit Field Sizes

| Constant | Value | Description |
|----------|-------|-------------|
| `DESTCHAINBITS` | 5 | Bits for destination chain |
| `HANDLER_BITS` | 7 | Bits for transaction handler |
| `NUM_ASSETID_BITS` | 15 | Bits for asset ID |
| `MAXUSERASSET_BITS` | 5 | Bits for user assets |
| `TXIND_BITS` | 20 | Bits for transaction index |
| `TXOFFSET_BITS` | 24 | Bits for transaction offset |

### Limits

| Constant | Value | Description |
|----------|-------|-------------|
| `MAX_ERC20` | 1,000 | Maximum ERC20 tokens |
| `MAX_VBOND_COINS` | 1,000 | Maximum bond coins |
| `MAX_L1_TXPLAN` | 10,000 | Maximum L1 transaction plan |
| `RICHLISTSIZE` | 5,000 | Rich list size |
| `_MAXADDRHASHENTRIES` | ~20M | Maximum address hash entries |

## Core Data Structures

### Memory Management

#### `tmpmem_s`
```c
typedef struct tmpmem_s {
    // Temporary memory allocation structure
} tmpmem_t;
```

### Consensus Structures

#### `valis_ballot_s`
```c
typedef struct valis_ballot_s {
    // Ballot structure for voting/elections
} valis_ballot_t;
```

#### `validators_s`
```c
typedef struct validators_s {
    // Validator set structure
    // Contains public keys, IPs, ports for all validators
} validators_t;
```

### Transaction Structures

#### `txhash_entry_t`
```c
typedef struct txhash_entry_s {
    uint64_t txidbits:15;      // Transaction ID bits
    uint64_t txoffset:TXOFFSET_BITS;  // Offset in block
    uint64_t txind:TXIND_BITS; // Transaction index
    uint64_t firstwrite:1;     // First write flag
} txhash_entry_t;
```

#### `tockid_t`
```c
typedef struct {
    uint32_t utime;            // Unix timestamp
    uint64_t txoffset:TXOFFSET_BITS;
    uint64_t reserved:4;
    uint64_t txind:TXIND_BITS;
    uint64_t reserved2:4;
    uint64_t shard:8;          // Shard identifier
} tockid_t;
```

### Network Structures

#### `peer_info_s`
```c
typedef struct peer_info_s {
    // Peer connection information
} peer_info_t;
```

#### `vnet_context_s`
```c
typedef struct vnet_context_s {
    // Virtual network context
    // Manages all network connections and message queues
} vnet_context_t;
```

#### `vnet_packet_queue`
```c
struct vnet_packet_queue {
    // Packet queue for network messages
};
```

#### `vmsg_sock`
```c
struct vmsg_sock {
    // Valis messaging socket abstraction
};
```

### Bridge Structures

#### `deposit_block_info`
```c
struct deposit_block_info {
    // Information about a deposit block from Ethereum
};
```

#### `sig_validator_bundle_s`
```c
typedef struct sig_validator_bundle_s {
    // Bundle of validator signatures for bridge operations
} sig_validator_bundle_t;
```

### Merkle Structures

#### `hash256_t`
```c
typedef struct hash256 {
    uint8_t hash[32];
} hash256_t;
```

#### `merkle_data_s`
```c
typedef struct merkle_data_s {
    // Merkle tree data
} merkle_data_t;
```

#### `merkle_path_s`
```c
typedef struct merkle_path_s {
    // Merkle proof path
} merkle_path_t;
```

#### `merkle_absence_proof_s`
```c
typedef struct merkle_absence_proof_s {
    // Proof of absence in Merkle tree
} merkle_absence_proof_t;
```

### Bond/Staking Structures

#### `vbond_fifo_slot_s`
```c
typedef struct vbond_fifo_slot_s {
    // FIFO slot for bond queue
} vbond_fifo_slot_t;
```

#### `vbond_feed_data_s`
```c
typedef struct vbond_feed_data_s {
    // Bond feed data
} vbond_feed_data_t;
```

### Metrics Structures

#### `metrics_perf_data_s`
```c
typedef struct metrics_perf_data_s {
    // Performance metrics data
} metrics_perf_data_t;
```

#### `stx_metrics_s`
```c
typedef struct stx_metrics_s {
    // Transaction metrics
} stx_metrics_t;
```

### Configuration Structures

#### `valis_config`
```c
struct valis_config {
    // Global configuration structure
};
```

#### `valis_topology_s`
```c
typedef struct valis_topology_s {
    // Network topology configuration
} valis_topology_t;
```

### Wallet Structures

#### `wallet_info`
```c
struct wallet_info {
    // Wallet information
};
```

#### `seedinfo`
```c
struct seedinfo {
    // Seed/key derivation information
};
```

### Global State

#### `global_reserve_t`
```c
typedef struct global_reserve_s global_reserve_t;
// Forward declaration - full definition in gen3.h
```

## Enumerations

#### Handler Types (implied)
```c
typedef enum {
    HANDLER_STANDARD,
    HANDLER_MULTISIG,
    HANDLER_COLDSPEND,
    HANDLER_HASHLOCK,
    HANDLER_POOL,
    HANDLER_ORDERBOOK,
    HANDLER_BRIDGE,
    HANDLER_SYSTEM,
    HANDLER_AIRDROP,
    HANDLER_DATA,
    HANDLER_STANDARD_WHASH,
    HANDLER_DATAFLOW,
    HANDLER_AUCTION,
    HANDLER_LOCK
} handler_type_t;
```

## Pragma Directives

```c
#pragma pack(1)  // Ensures tight packing for wire formats
```

All structures are packed to ensure consistent binary representation across platforms, critical for:
- Network protocol messages
- On-disk storage formats
- Hash calculations

## Key Macros

### Bit Manipulation
```c
#define GETBIT(bits, i)  // Get bit i from bits array
#define SETBIT(bits, i)  // Set bit i in bits array
#define CLRBIT(bits, i)  // Clear bit i in bits array
```

### Time Utilities
```c
#define VALIS_MILLI_NOW()  // Current time in milliseconds
```

## External References

```c
extern int32_t MULTITHREAD_TEST;  // Global multithread test flag
```

## Architecture Notes

1. **Ethereum Compatibility**: Uses 20-byte addresses (PKSIZE=20) for Ethereum compatibility
2. **Bit-Packed Structures**: Heavy use of bit fields for compact storage
3. **Memory Efficiency**: Designed to fit ~20M addresses in 32GB RAM
4. **Parallel Processing**: Built-in support for OpenMP parallelization
5. **Network Abstraction**: VNET provides unified network interface

## Related Files

- `gen3.h` - Generator definitions (extends global_reserve_t)
- `validator.h` - Validator definitions
- `frama_verified.h` - Formally verified function declarations
- `valis_messaging.h` - Messaging layer definitions
