# Tockchain Documentation Plan

Updated: Wake 1324 (2026-01-13)
Status: COMPREHENSIVE - 90 documentation files

---

## Documentation Progress Summary

**Total Documentation Files:** 90
- Source file docs: 86
- Architecture/overview docs: 4

**Estimated Lines Covered:** ~35,000+ (C code) + ~150 Coq files + ~8,000 spec lines

---

## NEW: Visual Documentation (wake 1324)

| Doc | Purpose | Size |
|-----|---------|------|
| TOCKCHAIN_DIAGRAMS.md | ASCII diagrams of system architecture | 43KB |

Contains 8 major diagrams:
1. High-Level System Architecture
2. Transaction Flow
3. Dataflow (eBPF) Architecture
4. UFC DEX Structure
5. Bridge Architecture (deposit/withdraw)
6. Formal Verification Stack
7. Token Economics
8. Module Dependencies

---

## Architecture & Spec Documentation (wake 1323)

| Doc | Purpose | Size |
|-----|---------|------|
| TOCKCHAIN_ARCHITECTURE.md | System overview, entry point for developers | 13.7KB |
| DOC_pylon_spec.md | Post-quantum security specification | 9.5KB |
| DOC_df_developer_guide.md | Dataflow developer guide summary | 10.2KB |

These documents provide high-level understanding before diving into code.

---

## Coq Formal Verification (wake 1322) ✅

| Doc | Purpose |
|-----|---------|
| DOC_coq_proofs.md | Comprehensive overview of the Coq proof system |

The Coq directory contains ~650 Qed proofs, 100 axioms, and only 2 admitted proofs.

---

## Completed Documentation by Module

### Bridge Module (15 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| bridge.h | DOC_bridge_h.md | 800 |
| bridge.c | DOC_bridge_c.md | 300 |
| bridge_rlp.c | DOC_bridge_rlp.md | 800 |
| bridge_mpt.c | DOC_bridge_mpt.md | 694 |
| bridge_mptjson.c | DOC_bridge_mptjson.md | 600 |
| bridge_deposit.c | DOC_bridge_deposit.md | 1270 |
| bridge_withdraw.c | DOC_bridge_withdraw.md | 1871 |
| bridge_abi.c | DOC_bridge_abi.md | 1091 |
| bridge_prices.c | DOC_bridge_prices.md | 1141 |
| bridge_rpc.c | DOC_bridge_rpc.md | 712 |
| bridge_rpc.h | DOC_bridge_rpc_h.md | ~200 |
| bridge_utils.c | DOC_bridge_utils.md | ~300 |
| bridge_vsm.ref.c | DOC_bridge_vsm_ref.md | 674 |
| ethrpc.c | DOC_ethrpc.md | 2015 |
| json.c | DOC_json.md | 900 |

### Utils Module (7 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| valis_hash.c | DOC_valis_hash.md | ~600 |
| valis_keys.c | DOC_valis_keys.md | ~600 |
| valis_math.c | DOC_valis_math.md | 1216 |
| valis_net_MT.c | DOC_valis_net_MT.md | 772 |
| valis_config.c | DOC_valis_config.md | 136 |
| valis_files.c | DOC_valis_files.md | 693 |
| valis_shared.c | DOC_valis_shared.md | 2000 |

### Dataflow Module (14 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| dataflow.h | DOC_dataflow_h.md | 408 |
| dataflow_inc.h | DOC_dataflow_inc_h.md | ~300 |
| dataflow.c | DOC_dataflow.md | 842 |
| dataflow_batch.c | DOC_dataflow_batch.md | 1491 |
| dataflow_cache.c | DOC_dataflow_cache.md | ~950 |
| dataflow_frontier.c | DOC_dataflow_frontier.md | 495 |
| dataflow_trigger.c | DOC_dataflow_trigger.md | 590 |
| dataflow_api.c | DOC_dataflow_api.md | 537 |
| df_gas.h | DOC_df_gas.md | ~200 |
| df_sdk.h | DOC_df_sdk.md | ~200 |
| vbpf.c | DOC_vbpf.md | 1938 |
| LOAN.c | DOC_LOAN.md | ~1500 |
| MM.c | DOC_MM.md | ~2000 |
| PERP.c | DOC_PERP.md | ~1800 |

### Generator Module (12 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| gen3.c | DOC_gen3.md | 908 |
| gen3.h | DOC_gen3_h.md | 587 |
| gen3_chain.c | DOC_gen3_chain.md | 1200 |
| gen3_metrics.c | DOC_gen3_metrics.md | 1100 |
| gen3_needbits.c | DOC_gen3_needbits.md | 500 |
| gen3_net.c | DOC_gen3_net.md | 1000 |
| gen3_nodechange.c | DOC_gen3_nodechange.md | 700 |
| gen3_rawtock.c | DOC_gen3_rawtock.md | 600 |
| gen3_ssd.c | DOC_gen3_ssd.md | 1200 |
| gen3_utils.c | DOC_gen3_utils.md | 800 |
| gen3_vans.c | DOC_gen3_vans.md | 600 |
| gen3_vote.c | DOC_gen3_vote.md | 700 |

### Validator Module (11 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| validator.c | DOC_validator.md | ~1000 |
| validator.h | DOC_validator_h.md | ~600 |
| ledger_assets.c | DOC_ledger_assets.md | ~800 |
| ledger_atomic.c | DOC_ledger_atomic.md | ~400 |
| ledger_erc20.c | DOC_ledger_erc20.md | ~500 |
| ledger.h | DOC_ledger_h.md | ~400 |
| ledger_hourly.c | DOC_ledger_hourly.md | ~300 |
| ledger_pylon7.c | DOC_ledger_pylon7.md | ~1000 |
| ledger_vhandlers.c | DOC_ledger_vhandlers.md | ~800 |
| ledger_vtrade.c | DOC_ledger_vtrade.md | ~600 |
| frama_verified.c | DOC_frama_verified.md | ~1500 |
| frama_verified.h | DOC_frama_verified_h.md | ~500 |

### UFC Module (9 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| ufc.c | DOC_ufc_c.md | ~1200 |
| ufc.h | DOC_ufc_h.md | ~800 |
| ufc_oob.c | DOC_ufc_oob.md | ~1000 |
| ufc_orderbook.c | DOC_ufc_orderbook.md | ~1000 |
| ufc_planner.c | DOC_ufc_planner.md | ~600 |
| ufc_pool.c | DOC_ufc_pool.md | ~700 |
| ufc_scan.c | DOC_ufc_scan.md | ~500 |
| ufc_swap.c | DOC_ufc_swap.md | ~1100 |
| ufc_utils.c | DOC_ufc_utils.md | ~700 |

### TSS Module (5 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| tss_overview | DOC_tss_overview.md | N/A |
| tss_module.c | DOC_tss_module.md | ~700 |
| tss_keygen.c | DOC_tss_keygen.md | ~600 |
| tss_sig.c | DOC_tss_sig.md | ~600 |
| valis_tss.c | DOC_valis_tss.md | ~1000 |

### Core Headers (5 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| _valis.h | DOC_valis_h.md | ~1500 |
| valis_messaging.c | DOC_valis_messaging.md | ~500 |
| valis_herongen.c | DOC_valis_herongen.md | ~1200 |
| valis_heronverify.c | DOC_valis_heronverify.md | ~1200 |
| websocketd.c | DOC_websocketd.md | ~800 |
| websockets.h | DOC_websockets_h.md | ~300 |

### Netlibs Module (4 files) ✅
| File | Doc | Lines |
|------|-----|-------|
| nng_shim.c | DOC_nng_shim.md | ~600 |
| cryptolibs | DOC_cryptolibs.md | ~300 |
| ebpf/ubpf | DOC_ebpf_ubpf.md | ~400 |

---

## Documentation Statistics

| Category | Count | Size |
|----------|-------|------|
| Source docs | 86 | ~700KB |
| Architecture docs | 4 | ~76KB |
| **Total** | **90** | **~776KB** |

---

## Remaining Work

### Potential additions:
1. **Unit test documentation** - tests/ directory has ~30 test files
2. **Whitepaper summary** - condense 26KB whitepaper into developer-friendly overview
3. **API reference** - consolidated function reference across modules
4. **Deployment guide** - how to run nodes, configure network

### ct's request (wake 1275):
> "not sure if either of you can make graphics, charts and diagrams. such things would help in some cases"

**Status:** Created TOCKCHAIN_DIAGRAMS.md with 8 ASCII diagrams (wake 1324)

---

*Last updated: Wake 1324*
*Maintained by: Opus*