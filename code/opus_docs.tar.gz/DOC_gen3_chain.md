# gen3_chain.c Documentation

**File:** `generator/gen3_chain.c`  
**Lines:** ~850  
**Created:** 2025-10-03  
**Documented:** Wake 1310 (2026-01-13)

---

## Overview

`gen3_chain.c` implements two critical consensus mechanisms for Tockchain:

1. **VBOND Auction Autoscaling** - Automatic determination of when to allow new validator bonds
2. **Node Performance Ranking** - Multi-factor scoring system for validator ranking and rewards

This file addresses the coordination problem of making network-wide decisions (validator expansion, ranking) in a system with 60 independent utime threads.

---

## Design Philosophy (from source comments)

The file header identifies key challenges:

- **Single Decision Problem**: 60 independent utime threads need coordinated decisions
- **Dynamic Validator Sets**: Proper support for adding/removing validators
- **Deterministic Ranking**: All nodes must agree on validator rankings for coinbase rewards
- **Adaptive Network Usage**: Bandwidth, redundancy, and packet frequency should adapt to conditions

---

## Part 1: VBOND Auction Autoscaling

### Concept

The autoscaler doesn't run auctions directly - it decides **when** to allow a new VBOND auction. The auction mechanism sets price/owner; the autoscaler gates when expansion is permitted.

### Core Principle

Scale validator count only when:
1. **Demand warrants it** - Sustained TVL growth and useful load
2. **Network is healthy** - Tight lag band, balanced supply/need, stable quorums

### Data Structures

```c
// Policy configuration (tunable parameters)
typedef struct auction_policy_s {
    uint32_t min_tvl_growth_bps;        // Minimum TVL growth to arm (800 = 8%)
    uint32_t disarm_drop_bps;           // TVL drop to disarm (300 = 3%)
    uint32_t min_nonvip_tps_arm;        // Minimum non-VIP TPS required
    uint32_t max_fu_span_secs;          // Maximum first_unfinished span
    uint32_t max_missing_pct;           // Maximum missing vote percentage
    uint32_t stability_window_secs;     // How long conditions must hold
    uint32_t cooldown_secs;             // Minimum time between auctions
    uint32_t intent_valid_for_secs;     // How long armed intent is valid
    uint32_t leader_pack_requires_quorum;
    uint32_t require_health_score;
    uint32_t min_health_score_arm;
} auction_policy_t;

// Runtime inputs (computed per utime)
typedef struct auction_inputs_s {
    uint32_t utime;
    int64_t vusd_supply;                // Current VUSD supply
    uint32_t nonvip_tps;                // Non-VIP transactions per second
    uint32_t vip_tps;                   // VIP transactions per second
    uint32_t backlog_tx;                // Pending transaction count
    uint32_t vip_only;                  // VIP-only mode flag
    uint32_t fu_min, fu_max;            // First unfinished range across voters
    uint32_t needs_row_disp_bp;         // Needs matrix row dispersion
    uint32_t needs_col_disp_bp;         // Needs matrix column dispersion
    uint32_t p50_quorum_ms;             // 50th percentile quorum time
    uint32_t p95_quorum_ms;             // 95th percentile quorum time
    uint32_t missing_pct_median;        // Median missing vote percentage
    uint32_t leader_pack_count;         // Nodes in leading pack
    uint32_t quorum;                    // Current quorum requirement
    uint32_t have_health_score;         // Health score available flag
    uint32_t health_score_0_100;        // Overall health score
} auction_inputs_t;

// Runtime state (persisted across utimes)
typedef struct auction_runtime_s {
    uint32_t last_auction_utime;
    uint32_t last_intent_utime;
    uint32_t armed_since_utime;
    uint32_t state;                     // NONE/ARMED/BROADCASTED/COOLDOWN
    uint32_t sustained_secs;
    uint32_t reasons_passed;            // Bitmask of passed checks
    uint32_t reasons_blocked;           // Bitmask of blocked checks
    int64_t vusd_hwm;                   // High water mark for VUSD
    int64_t vusd_hwm_at_last_auction;
} auction_runtime_t;
```

### Intent States

```c
enum {
    AUCTION_INTENT_NONE = 0,        // No auction intent
    AUCTION_INTENT_ARMED = 1,       // Ready to auction (conditions met)
    AUCTION_INTENT_BROADCASTED = 2, // Intent announced to network
    AUCTION_INTENT_COOLDOWN = 3     // Post-auction cooldown period
};
```

### Reason Flags

Each check has a corresponding bit flag:

```c
enum {
    AUCTION_REASON_TVL         = 1 << 0,  // TVL growth check
    AUCTION_REASON_LOAD        = 1 << 1,  // Load/TPS check
    AUCTION_REASON_LAG         = 1 << 2,  // Lag band check
    AUCTION_REASON_MISSING     = 1 << 3,  // Missing votes check
    AUCTION_REASON_QUORUM      = 1 << 4,  // Quorum time check
    AUCTION_REASON_LEADERPACK  = 1 << 5,  // Leader pack check
    AUCTION_REASON_HEALTHSCORE = 1 << 6,  // Health score check
    AUCTION_REASON_COOLDOWN    = 1 << 7   // Cooldown period check
};
```

### Key Functions

#### `auction_policy_init_defaults()`

Initializes policy with sensible defaults:
- 8% TVL growth required to arm
- 3% TVL drop disarms
- Stability window before arming
- Cooldown between auctions

#### `all_arm_checks_pass()`

Evaluates all arming conditions:

1. **TVL Check**: VUSD supply growth exceeds threshold
2. **Load Check**: Non-VIP TPS meets minimum
3. **Lag Check**: `fu_max - fu_min` within acceptable span
4. **Missing Check**: Missing vote percentage below threshold
5. **Quorum Check**: p95 quorum time acceptable
6. **Leader Pack Check**: Sufficient nodes in leading pack
7. **Health Score Check**: Overall health above minimum
8. **Cooldown Check**: Enough time since last auction

Returns passed/blocked bitmasks for diagnostics.

#### `auction_intent_evaluate()`

Main state machine evaluation:

```
NONE → ARMED: All checks pass for stability_window_secs
ARMED → BROADCASTED: Intent announced
ARMED → NONE: Checks fail (TVL drop or other)
BROADCASTED → NONE: Intent expires
BROADCASTED → COOLDOWN: Auction completed
COOLDOWN → NONE: Cooldown expires
```

#### `auction_json_emit()`

Generates JSON status blob for telemetry/systemtx:

```json
{
  "utime": 1234567890,
  "state": "ARMED",
  "sustained_secs": 300,
  "reasons_passed": ["TVL", "LOAD", "LAG"],
  "reasons_blocked": [],
  "vusd_supply": 1000000,
  "vusd_hwm": 1050000
}
```

---

## Part 2: Node Performance Ranking

### Purpose

Deterministically rank validators for:
- Coinbase reward scaling
- Identifying underperforming nodes
- Network health assessment

### Scoring Components

The combined score uses weighted factors:

```c
comb[i] = (w_perf * perf[i]) + (w_fin * fin[i]);
```

Where:
- **perf[i]**: Real-time performance score from `GEN3->M.perf.score[i]`
- **fin[i]**: Finalization score from `GEN3->M.vbond_cache.fin_score[i]`

Additional factors considered:
- **w_supply**: Supply contribution (needs matrix row sums)
- **w_need**: Need contribution (needs matrix column sums)
- **w_lag**: Lag penalty

### Needs Matrix Analysis

The needs matrix tracks which nodes need data from which other nodes:

```c
// Row sum = how much node i needs from others (supply)
// Column sum = how much others need from node i (demand)
for (j = 0; j < n; j++) {
    row_sum[i] += U->needsmatrix[i][j];
    col_sum[i] += U->needsmatrix[j][i];
}
```

Balanced supply/need indicates healthy network topology.

### Key Function: `node_perf_json_emit()`

Generates comprehensive node performance JSON:

**Parameters:**
- `GEN3`: Global reserve state
- `U`: Utime data structure
- `nodeid`: Node to evaluate
- `w_perf, w_fin, w_supply, w_need, w_lag`: Weight factors
- `candidate_scale`: Scaling for candidate nodes
- `edge_behind_max`: Maximum edge lag
- `out, out_cap`: Output buffer

**Output includes:**
- Individual node scores
- Ranking position
- Needs matrix contributions
- RTT statistics
- Voter/candidate status

### Helper Functions

#### `skip_zero_node()`
Identifies inactive/zero nodes to exclude from calculations.

#### `calc_aveRTT()`
Calculates average round-trip time across the network.

#### `pct_bps_from_hwm()`
Calculates basis points relative to high water mark.

#### `buf_append()`
Safe buffer appending with overflow protection.

---

## Integration Points

### When to Call

Per the source comments:

> After consensus health is materialized (right after `finalize_consensus_metrics()` for the utime that will be signed into rawtock). At that point assemble `auction_inputs_t` (from `RAW->stxM` and your per-utime global metrics), then call `auction_intent_evaluate()`.

### Data Sources

- `RAW->stxM.VUSDsupply`: VUSD supply
- Per-utime global metrics: TPS, lag, missing votes
- `GEN3->M.perf`: Performance scores
- `GEN3->M.vbond_cache`: Finalization scores
- `U->needsmatrix`: Supply/demand matrix

---

## Design Rationale

### Market-Driven Expansion

The autoscaler is market-driven:
- Only expands when TVL growth justifies it
- Requires sustained conditions (not spikes)
- Health checks prevent expansion into instability

### Deterministic Ranking

All nodes must agree on rankings:
- Same inputs → same outputs
- No floating-point divergence issues
- Consensus on reward distribution

### Defensive Programming

- All functions check NULL pointers
- Buffer operations have overflow protection
- Mutex usage is properly guarded
- Invalid states handled gracefully

---

## TODO Items (from source)

1. Remove hardcoded ds assumption from utime get
2. Add systemtx to gen3 for validator updates
3. Adaptive bandwidth based on errors
4. Adaptive redundancy and packet loss calculation
5. Adaptive packet send frequency based on half-trip times
6. Enforce VIP ratio
7. Display status when falling behind
8. Handle minority sync
9. Merge/clean gen3_validators.c and valis_net_MT.c

---

## Related Files

- `gen3.c` - Main generator logic
- `gen3.h` - Type definitions and constants
- `gen3_vote.c` - Voting mechanism
- `gen3_metrics.c` - Metrics collection
- `validator.c` - Validator state management
- `valis_net_MT.c` - Network threading

---

## Security Considerations

1. **Sybil Resistance**: VBOND requirement prevents cheap validator spam
2. **Health Gating**: Can't expand into unhealthy network state
3. **Cooldown Period**: Prevents rapid validator churn
4. **Deterministic Ranking**: No manipulation of reward distribution

---

*Documentation by Opus, Wake 1310*
