# bridge_rpc.h - Ethereum JSON-RPC Type System

**Location:** `/root/valis/bridge/bridge_rpc.h`  
**Lines:** 114  
**Purpose:** Type definitions and helpers for building Ethereum JSON-RPC requests

---

## Overview

This header defines a type system for constructing Ethereum JSON-RPC requests without runtime string building. The approach is "describe it, don't build it" - callers describe the structure of their RPC parameters using typed values, and the serialization happens later.

---

## Design Philosophy

### Zero Allocation at Call Sites
Fixed-capacity arrays eliminate malloc:
```c
#define RPC_MAX_PARAMS        16
#define RPC_MAX_OBJECTS       16
#define RPC_MAX_ARRAYS        16
#define RPC_MAX_FIELDS        16
#define RPC_MAX_ARRAY_ELEMS   16
```

### Type-Safe Parameter Building
Instead of string concatenation:
```c
// Bad: sprintf(buf, "\"0x%llx\"", value);
// Good: rpcv_quantity_u64(value);
```

---

## Value Types

### rpc_type_t Enum
```c
typedef enum rpc_type_e {
    RPCV_NULL = 0,          // JSON null
    RPCV_BOOL = 1,          // JSON boolean
    RPCV_STR  = 2,          // Literal JSON string
    RPCV_HEXBYTES = 3,      // Raw bytes → "0x..." hex string
    RPCV_QUANTITY_U64 = 4,  // u64 → "0x..." quantity (minimal, 0 => "0x0")
    RPCV_OBJECT = 5,        // Nested object
    RPCV_ARRAY  = 6,        // Nested array
    RPCV_HEXSTR = 7,        // Already-encoded hex string
    RPCV_U256_BE = 8,       // Big-endian bytes → minimal "0x..." quantity
    RPCV_U256_LE = 9,       // Little-endian bytes → minimal "0x..." quantity
    RPCV_NUMBER_U64 = 10,   // Raw numeric (not hex-encoded)
} rpc_type_t;
```

### rpc_value_t Union
```c
typedef struct rpc_value_s {
    rpc_type_t t;
    union {
        const char *s;                           // String pointer
        struct { const uint8_t *p; uint32_t n; } bytes;  // Byte array
        uint64_t u64;                            // 64-bit integer
        uint8_t b;                               // Boolean
        struct rpc_object_s *obj;                // Object pointer
        struct rpc_array_s  *arr;                // Array pointer
    } v;
} rpc_value_t;
```

---

## Composite Types

### Key-Value Pair
```c
typedef struct rpc_kv_s {
    const char *key;
    rpc_value_t val;
} rpc_kv_t;
```

### Object (for nested JSON objects)
```c
typedef struct rpc_object_s {
    uint8_t n;                        // Number of fields
    rpc_kv_t kv[RPC_MAX_FIELDS];      // Key-value pairs
} rpc_object_t;
```

### Array (for JSON arrays)
```c
typedef struct rpc_array_s {
    uint8_t n;                        // Number of elements
    rpc_value_t elems[RPC_MAX_ARRAY_ELEMS];
} rpc_array_t;
```

---

## Request Container

### curl_params_t
```c
typedef struct curl_params_s {
    const char   *url;                         // Optional URL override
    rpc_value_t   params[RPC_MAX_PARAMS];      // RPC parameters
    uint8_t       params_n;                    // Parameter count
    rpc_object_t  objects[RPC_MAX_OBJECTS];    // Object storage pool
    uint8_t       objects_n;                   // Objects used
    rpc_array_t   arrays[RPC_MAX_ARRAYS];      // Array storage pool
    uint8_t       arrays_n;                    // Arrays used
} curl_params_t;
```

The `objects` and `arrays` pools allow nested structures without dynamic allocation.

---

## Helper Functions

### Value Constructors
```c
static inline rpc_value_t rpcv_null(void);
static inline rpc_value_t rpcv_bool(bool b);
static inline rpc_value_t rpcv_str(const char *s);
static inline rpc_value_t rpcv_hexstr(const char *s);
static inline rpc_value_t rpcv_hexbytes(const uint8_t *p, uint32_t n);
static inline rpc_value_t rpcv_quantity_u64(uint64_t u);
static inline rpc_value_t rpcv_u256_be(const uint8_t *be, uint32_t n);
static inline rpc_value_t rpcv_u256_le(const uint8_t *le, uint32_t n);
static inline rpc_value_t rpcv_number_u64(uint64_t u);
```

### Usage Example
```c
curl_params_t cp = {0};

// eth_getBalance("0x1234...", "latest")
cp.params[0] = rpcv_hexstr("0x1234567890abcdef1234567890abcdef12345678");
cp.params[1] = rpcv_str("latest");
cp.params_n = 2;

// eth_call with object parameter
rpc_object_t *obj = &cp.objects[cp.objects_n++];
obj->kv[0] = (rpc_kv_t){"to", rpcv_hexstr("0xcontract...")};
obj->kv[1] = (rpc_kv_t){"data", rpcv_hexbytes(calldata, calldata_len)};
obj->n = 2;
cp.params[0] = (rpc_value_t){.t = RPCV_OBJECT, .v.obj = obj};
cp.params[1] = rpcv_str("latest");
cp.params_n = 2;
```

---

## Ethereum-Specific Encoding

### Quantity Encoding
Ethereum JSON-RPC uses minimal hex encoding for quantities:
- `0` → `"0x0"` (not `"0x00"`)
- `255` → `"0xff"` (not `"0x00ff"`)
- `256` → `"0x100"`

The `RPCV_QUANTITY_U64`, `RPCV_U256_BE`, and `RPCV_U256_LE` types handle this automatically.

### Data vs Quantity
- **Data** (`RPCV_HEXBYTES`): Fixed-length, includes leading zeros
- **Quantity** (`RPCV_QUANTITY_*`): Variable-length, minimal encoding

---

## Integration

### Used By
- `bridge_rpc.c` - Serializes these types to JSON
- `ethrpc.c` - High-level RPC functions
- `bridge_deposit.c` - Deposit verification calls
- `bridge_withdraw.c` - Withdrawal transaction building

### Dependencies
- `yyjson.h` - JSON library for final serialization

---

## Memory Model

All pointers in `rpc_value_t` are **borrowed** - the caller must ensure the pointed-to data lives until serialization completes. This is safe because:
1. Serialization happens immediately after construction
2. No async operations between construction and serialization

---

*Documentation generated by Opus, Wake 1319*
