# valis_net_MT.c Documentation

**File:** `/root/valis/utils/valis_net_MT.c`  
**Lines:** 772  
**Documented:** Wake 1301  
**Author:** Opus

---

## Overview

`valis_net_MT.c` implements multi-threaded peer-to-peer networking for Tockchain validators. It provides:

1. **Peer Management** - Connection tracking, discovery, and lifecycle
2. **Message Routing** - PUSH/PULL and PUB/SUB patterns via nanomsg
3. **Queue System** - Per-peerset, per-vapp FIFO message queues
4. **Thread Management** - Dedicated threads for receiving and IPC

---

## Constants

```c
#define BIGBUFSIZE              (11 * 1024 * 1024)  // 11MB socket buffer
#define VNET_SEND_IDLE_US       1000                // 1ms idle between sends
#define VNET_BACKOFF_BASE_MS    100                 // Reconnect backoff base
#define VNET_BACKOFF_MAX_SHIFT  5                   // Max backoff = 100ms * 2^5 = 3.2s
#define VNET_STALE_PEER_SECS    600                 // 10 min peer timeout
#define VNET_SEND_THROTTLE_TRIGGER 1024             // Queue depth throttle trigger
#define VNET_PUB_PORT           (VNET_PORT + 1)     // PUB socket = PULL port + 1
```

---

## Data Structures

### vnet_context_t

The main networking context (defined in header, used throughout):

```c
typedef struct vnet_context_s {
    uint8_t mypubkey[PKSIZE];           // This node's public key
    uint8_t testprivkey[PRIVKEYSIZE];   // Signing key
    uint32_t genesis_utime;             // Genesis timestamp
    
    // Sockets
    int pull_sock;                      // PULL socket (receives from peers)
    int pub_sock;                       // PUB socket (broadcasts to subscribers)
    int sub_sock;                       // SUB socket (receives broadcasts)
    int ipc_sock;                       // IPC socket (local process communication)
    
    // Buffers
    uint8_t pullbuf[BIGBUFSIZE];
    uint8_t subbuf[BIGBUFSIZE];
    
    // Peer tracking
    struct vnet_server_info servers[MAX_SERVERS];
    pthread_mutex_t servers_mutex;
    pthread_mutex_t sub_mutex;
    
    // Message queues: [peerset][vapp][fifo_slot]
    struct vnet_queue_slot vapp_slots[NUM_PEERSETS][NUM_VAPPID][VNET_FIFOSIZE];
} vnet_context_t;
```

### vnet_server_info

Per-peer connection state:

```c
struct vnet_server_info {
    peer_info_t peer;           // IP, port, pubkey
    int pushsock;               // PUSH socket to this peer
    int sub_endpoint;           // SUB endpoint ID
    uint64_t peersets_bitmap;   // Which peersets this peer belongs to
    int active;                 // Connection active flag
};
```

### vnet_packet_queue

Queued packet structure:

```c
struct vnet_packet_queue {
    uint8_t destpub[PKSIZE];    // Destination public key
    int32_t bufsize;            // Packet size
    uint8_t recvbuf[];          // Flexible array member for packet data
    // Linked list pointers (via utlist.h DL_* macros)
};
```

---

## Packet Queue Management

### alloc_qp

```c
struct vnet_packet_queue *alloc_qp(const uint8_t destpub[PKSIZE], 
                                    const uint8_t *recvbuf, int32_t packetlen)
```

Allocates a queue packet with embedded data buffer.

**Returns:** Allocated packet or NULL on failure

### enqueue_packet_to_slot

```c
void enqueue_packet_to_slot(struct vnet_queue_slot *slot, struct vnet_packet_queue *qp)
```

Thread-safe enqueue to a specific slot.

**Thread Safety:** Uses `pthread_mutex_lock/unlock` on slot mutex

---

## Peer Lookup Functions

### vnet_find_serverpub

```c
static struct vnet_server_info *vnet_find_serverpub(vnet_context_t *VNET, 
                                                     const uint8_t pubkey[PKSIZE])
```

Finds a peer by public key across all peersets.

**Thread Safety:** Locks `servers_mutex`

### vnet_find_server_in_peerset

```c
static struct vnet_server_info *vnet_find_server_in_peerset(vnet_context_t *VNET,
                                                             int32_t peerset, 
                                                             const uint8_t pubkey[PKSIZE])
```

Finds a peer by public key within a specific peerset.

**Parameters:**
- `peerset`: Peerset index, or `-1` for any peerset

---

## Connection Management

### get_peer_urls

```c
static void get_peer_urls(const peer_info_t *peer, char *push_url, char *sub_url, int32_t url_size)
```

Generates nanomsg URLs for a peer.

**Output Format:**
- `push_url`: `tcp://IP:PORT` (for PUSH socket)
- `sub_url`: `tcp://IP:PORT+1` (for SUB socket)

### create_msg_socket

```c
static int create_msg_socket(vnet_context_t *VNET, int type, int sndbuf, int rcvbuf)
```

Creates a nanomsg socket with buffer configuration.

**Parameters:**
- `type`: `VMSG_PUSH`, `VMSG_PULL`, `VMSG_PUB`, or `VMSG_SUB`
- `sndbuf`, `rcvbuf`: Buffer sizes (0 = default)

**Note:** SUB sockets automatically subscribe to all messages (empty topic)

### vnet_connect_peer

```c
static int32_t vnet_connect_peer(vnet_context_t *VNET, struct vnet_server_info *sp)
```

Establishes connection to a peer.

**Actions:**
1. Skips self-connection
2. Creates PUSH socket with 11MB buffer
3. Connects to peer's PUSH URL
4. If PUB/SUB enabled, connects SUB socket to peer's PUB URL

**Returns:** `0` on success, `-1` on failure

### vnet_disconnect_peer

```c
static void vnet_disconnect_peer(vnet_context_t *VNET, struct vnet_server_info *sp)
```

Closes connection to a peer.

**Actions:**
1. Closes PUSH socket
2. Shuts down SUB endpoint
3. Clears active flag

---

## Thread Functions

### vnet_recvloop

```c
static void *vnet_recvloop(void *arg)
```

Main receive thread - processes messages from PULL socket.

**Loop:**
1. Blocking receive on `pull_sock`
2. Pass to `vnet_process_inbound()` for routing

### vnet_sub_recvloop

```c
static void *vnet_sub_recvloop(void *arg)
```

PUB/SUB receive thread - processes broadcast messages.

**Loop:**
1. Blocking receive on `sub_sock`
2. Pass to `vnet_process_inbound()` for routing

### ipc_recvloop

```c
static void *ipc_recvloop(void *arg)
```

IPC receive thread - handles local process communication.

### start_common_threads

```c
static void start_common_threads(vnet_context_t *VNET)
```

Spawns and detaches all receive threads.

---

## Public API

### vnet_is_disabled

```c
int32_t vnet_is_disabled(vnet_context_t *VNET, int32_t peerset, uint8_t pubkey[PKSIZE])
```

Checks if a peer is disabled in a peerset.

**Returns:** `1` if disabled/not found, `0` if active

### vnet_find_ipbits

```c
uint32_t vnet_find_ipbits(vnet_context_t *VNET, uint8_t pubkey[PKSIZE])
```

Looks up IP address for a public key.

**Returns:** IP as 32-bit integer, or `0` if not found

### vnet_get_peers_in_peerset

```c
int32_t vnet_get_peers_in_peerset(vnet_context_t *VNET, int32_t peerset, 
                                   peer_info_t *peers, int32_t max)
```

Retrieves all peers in a peerset.

**Parameters:**
- `peerset`: Peerset index (0 to NUM_PEERSETS-1)
- `peers`: Output array
- `max`: Maximum peers to return

**Returns:** Number of peers found

### vnet_collect_active_ips

```c
int32_t vnet_collect_active_ips(vnet_context_t *VNET, uint32_t *ips, int32_t maxips)
```

Collects unique IP addresses across all peersets.

**Returns:** Number of unique IPs

### vnet_add_peer

```c
int32_t vnet_add_peer(vnet_context_t *VNET, int32_t peerset, peer_info_t peer)
```

Adds a peer to a peerset.

**Actions:**
1. Allocates or finds existing server slot
2. Sets peerset bit in bitmap
3. Connects if not already connected

**Returns:** `0` on success, `-1` on failure

### vnet_remove_peer

```c
int32_t vnet_remove_peer(vnet_context_t *VNET, int32_t peerset, uint8_t pubkey[PKSIZE])
```

Removes a peer from a peerset.

**Actions:**
1. Clears peerset bit
2. Disconnects if no peersets remain

**Returns:** `0` on success, `-1` if not found

### vnet_shutdown

```c
int32_t vnet_shutdown(vnet_context_t *VNET)
```

Shuts down networking and frees resources.

**Actions:**
1. Disconnects all peers
2. Closes all sockets (IPC, PUB, SUB, PULL)
3. Frees all queued packets
4. Destroys mutexes
5. Frees context structure

**Returns:** `0`

### vnet_send

```c
int32_t vnet_send(vnet_context_t *VNET, unified_header_t *H, int32_t packetlen, 
                  uint8_t destpub[PKSIZE], int32_t must_sign)
```

Sends a packet to a specific peer.

**Parameters:**
- `H`: Packet header (modified if signing required)
- `packetlen`: Total packet length
- `destpub`: Destination public key
- `must_sign`: If non-zero, signs packet before sending

**Signing Process:**
1. Sets `addedsig` flag
2. Sets genesis timestamp if not set
3. Computes packet hash
4. Signs with `valis_sign()`
5. Verifies signature

**Returns:** `0` on success, negative on error

---

## Message Flow

### Inbound Messages

```
Peer PUSH → Local PULL socket → vnet_recvloop → vnet_process_inbound → Queue
Peer PUB  → Local SUB socket  → vnet_sub_recvloop → vnet_process_inbound → Queue
```

### Outbound Messages

```
Application → vnet_send → Find peer by pubkey → PUSH socket → Peer PULL
```

### Broadcast Messages

```
Application → PUB socket → All subscribed peers' SUB sockets
```

---

## Peerset System

Peers are organized into multiple "peersets" (up to `NUM_PEERSETS`). Each peer tracks membership via a bitmap:

```c
uint64_t peersets_bitmap;  // Bit N set = member of peerset N
```

This allows:
- Same peer in multiple peersets
- Efficient peerset queries
- Automatic disconnect when removed from all peersets

---

## Dependencies

- `gen3.h` - Generator definitions
- `valis_messaging.h` - `vmsg_*` nanomsg wrapper functions
- `pthread.h` - Thread and mutex primitives
- `utlist.h` - Doubly-linked list macros (DL_APPEND, DL_FOREACH_SAFE, etc.)

---

## Thread Safety

| Resource | Protection |
|----------|------------|
| `servers[]` array | `servers_mutex` |
| SUB socket operations | `sub_mutex` |
| Queue slots | Per-slot mutex |

---

## Design Notes

1. **PUSH/PULL Pattern:** Point-to-point reliable delivery
2. **PUB/SUB Pattern:** Broadcast for announcements (optional via `ENABLE_PUBSUB`)
3. **Large Buffers:** 11MB buffers handle large blocks/batches
4. **Detached Threads:** Receive threads run independently
5. **Graceful Shutdown:** All resources properly cleaned up

---

## Security Considerations

- Packets can be signed with `must_sign` flag
- Signature verification uses `valis_verify()`
- Self-connections are prevented
- No authentication on initial connection (relies on signed messages)
