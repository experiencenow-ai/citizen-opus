# ledger_erc20.c - ERC20 Token Registry and Bridge Support

## Overview

This file defines the registry of supported ERC20 tokens for bridging from Ethereum to Tockchain. It includes token metadata (symbol, address, decimals) and gas cost estimates for transfers.

**Location:** `/root/valis/validator/ledger_erc20.c`  
**Lines:** ~1439  
**Dependencies:** validator.h, bridge.h

## Core Concepts

### Token Registry
A static array of supported ERC20 tokens with:
- Symbol (e.g., "WBTC", "WETH")
- Ethereum contract address
- Decimal precision
- Estimated gas cost for transfers

### Reserved Names
System-reserved asset names that cannot be used for user-created assets.

## Key Data Structures

### erc20_info
```c
struct erc20_info {
    char symbol[16];           // Token symbol
    char address[43];          // Ethereum address (0x...)
    uint8_t decimals;          // Decimal places
    uint8_t reserved;          // Reserved field
    uint32_t gas_estimate;     // Transfer gas cost
};
```

## Token Registry

The `erc20_tokens[]` array includes major tokens:

### Bitcoin-Pegged
- **WBTC**: Wrapped Bitcoin (8 decimals)
- **TBTC**: Threshold Bitcoin (18 decimals)

### Native Wrappers
- **WETH**: Wrapped Ether (18 decimals)

### Layer 1 Tokens
- **SOL**: Solana (9 decimals)
- **BNB**: Binance Coin (18 decimals)
- **TRX**: Tron (6 decimals)
- **NEAR**: Near Protocol (24 decimals)
- **TONCOIN**: Toncoin (9 decimals)

### DeFi Tokens
- **LINK**: Chainlink (18 decimals)
- **AAVE**: Aave (18 decimals)
- **UNI**: Uniswap (18 decimals)
- **MKR**: Maker (18 decimals)
- **COMP**: Compound (18 decimals)
- **CRV**: Curve (18 decimals)
- **SNX**: Synthetix (18 decimals)
- **CVX**: Convex (18 decimals)
- **YFI**: Yearn (18 decimals)
- **1INCH**: 1inch (18 decimals)
- **PENDLE**: Pendle (18 decimals)
- **DYDX**: dYdX (18 decimals)

### Infrastructure
- **GRT**: The Graph (18 decimals)
- **RNDR**: Render (18 decimals)
- **STORJ**: Storj (8 decimals)
- **LDO**: Lido (18 decimals)

### Metaverse/Gaming
- **SAND**: Sandbox (18 decimals)
- **MANA**: Decentraland (18 decimals)
- **GALA**: Gala Games (8 decimals)
- **ENS**: ENS Domains (18 decimals)
- **CHZ**: Chiliz (18 decimals)

### Real-World Assets
- **PAXG**: Pax Gold (18 decimals)
- **XAUT**: Tether Gold (6 decimals)

### Other
- **WTAO**: Wrapped TAO (9 decimals)
- **MNT**: Mantle (18 decimals)
- **ONDO**: Ondo Finance (18 decimals)
- **OM**: MANTRA (18 decimals)
- **BAT**: Basic Attention (18 decimals)
- **AUDIO**: Audius (18 decimals)
- **ZRO**: LayerZero (18 decimals)

## Reserved Names

```c
const char *Reserved_names[] = {
    "<null asset>",
    "COINSMINTED",
    "COINSBURNED",
    "POOLSHARES",
    // ... more reserved names
};
```

These names are reserved for:
- System accounting
- Protocol operations
- Special asset types

## Gas Estimates

Each token includes estimated gas cost for ERC20 transfers:
- Simple transfers: ~30,000-50,000 gas
- Complex tokens (SNX, LDO): ~100,000-170,000 gas
- Standard ERC20: ~50,000-70,000 gas

## Arbitrage Pairs

The registry notes arbitrage opportunities:
- WBTC/TBTC (Bitcoin representations)
- PAXG/XAUT (Gold representations)

## Integration Points

- **bridge_deposit.c**: Validates incoming ERC20 deposits
- **bridge_withdraw.c**: Processes ERC20 withdrawals
- **bridge_prices.c**: Price feeds for bridged assets
- **validator.c**: Asset creation from bridge transactions

## Usage

```c
// Find token info by symbol
for (int i = 0; erc20_tokens[i].symbol[0]; i++) {
    if (strcmp(erc20_tokens[i].symbol, "WBTC") == 0) {
        // Use erc20_tokens[i]
    }
}

// Check if name is reserved
for (int i = 0; Reserved_names[i]; i++) {
    if (strcmp(name, Reserved_names[i]) == 0) {
        // Name is reserved
    }
}
```

## Security Considerations

- Contract addresses are hardcoded (no dynamic lookup)
- Decimal precision must match Ethereum contract
- Gas estimates are conservative for safety
- Reserved names prevent user spoofing
