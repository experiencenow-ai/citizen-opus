# bridge_utils.c Documentation

**File:** `bridge/bridge_utils.c` (320 lines)  
**Purpose:** Centralized hex/binary conversion utilities and Ethereum-specific helpers  
**Documented by:** Opus (Wake 1289)  
**Status:** Complete

---

## Overview

This file provides efficient, centralized conversion utilities used throughout the bridge module. All hex/binary conversions route through two core functions (`bin2hex` and `central_hex_to_bin`) to ensure consistency and enable optimization.

Key features:
- **Lookup table optimization** - O(1) hex nibble parsing
- **Pre-computed hex pairs** - Fast binary-to-hex conversion
- **Ethereum-specific helpers** - Slot/epoch calculations, address parsing
- **Consistent error handling** - Negative return codes for all failures

---

## Dependencies

```c
#include "bridge.h"    // MAXCOINSUPPLY constant
#include <stdint.h>
#include <string.h>
```

---

## Constants

```c
#define ETH_SECONDS_PER_SLOT 12U        // Ethereum slot duration
#define ETH_SLOTS_PER_EPOCH 32U         // Slots per epoch
#define BEACON_GENESIS_TIME 1606824023  // Dec 1, 2020 12:00:23 UTC
```

---

## Lookup Tables

### g_hex_nibble_lut[256]
Maps ASCII characters to hex nibble values (0-15) or -1 for invalid.

```c
'0'-'9' → 0-9
'a'-'f' → 10-15
'A'-'F' → 10-15
all others → -1
```

### g_hex_pairs_lut[256][3]
Pre-computed two-character hex strings for each byte value.

```c
g_hex_pairs_lut[0]   = "00"
g_hex_pairs_lut[255] = "ff"
g_hex_pairs_lut[171] = "ab"
```

This eliminates per-nibble computation during binary-to-hex conversion.

---

## Core Conversion Functions

### bin2hex()
```c
int32_t bin2hex(const uint8_t *bin, int32_t bin_len, char *hex);
```

**Purpose:** Convert binary data to lowercase hex string.

**Parameters:**
- `bin`: Source binary data
- `bin_len`: Number of bytes to convert
- `hex`: Output buffer (must hold bin_len*2 + 1 bytes)

**Returns:**
- Number of hex characters written (bin_len * 2)
- -1 on invalid input

**Implementation:** Uses `g_hex_pairs_lut` for O(n) conversion with no per-byte computation.

---

### central_hex_to_bin()
```c
int32_t central_hex_to_bin(const char *hex, uint8_t *bin, 
                           int32_t max_out_bin_len, int32_t *out_bin_len);
```

**Purpose:** Convert hex string to binary, handling "0x" prefix.

**Parameters:**
- `hex`: Input hex string (with or without "0x" prefix)
- `bin`: Output buffer
- `max_out_bin_len`: Maximum bytes to write (0 = unlimited)
- `out_bin_len`: Receives actual bytes written

**Returns:**
- 0: Success
- -1: Invalid hex character, odd length, or overflow

**Behavior:**
- Automatically strips "0x" or "0X" prefix
- Requires even number of hex digits
- Uses `g_hex_nibble_lut` for O(n) parsing

---

## Wrapper Functions

### byteToHex()
```c
void byteToHex(const uint8_t *byte, char *hex, const int sizeInByte);
```

Legacy wrapper around `bin2hex()`. Null-terminates output.

---

### hexToByte()
```c
int hexToByte(const char *hex, uint8_t *bytes, int32_t len);
```

Convert hex to exactly `len` bytes. Returns -1 if length doesn't match.

---

### hex2bin()
```c
int32_t hex2bin(const char *hex, uint8_t *bin, int32_t *bin_len);
```

Convert hex to binary with length output. `*bin_len` is both input (max) and output (actual).

---

## Ethereum-Specific Functions

### eth_slot_from_unix()
```c
uint64_t eth_slot_from_unix(uint64_t unix_ts, uint64_t beacon_genesis_time);
```

**Purpose:** Calculate Ethereum beacon chain slot number from Unix timestamp.

**Formula:** `slot = (unix_ts - genesis_time) / 12`

**Parameters:**
- `unix_ts`: Unix timestamp
- `beacon_genesis_time`: Genesis time (0 = use default 1606824023)

**Returns:** Slot number, or 0 if timestamp is before genesis.

---

### eth_epoch_from_unix()
```c
uint64_t eth_epoch_from_unix(uint64_t unix_ts, uint64_t beacon_genesis_time);
```

**Purpose:** Calculate beacon chain epoch from Unix timestamp.

**Formula:** `epoch = slot / 32`

---

### eth_unix_from_slot()
```c
uint64_t eth_unix_from_slot(uint64_t slot, uint64_t beacon_genesis_time);
```

**Purpose:** Calculate Unix timestamp from slot number.

**Formula:** `unix_ts = genesis_time + (slot * 12)`

---

## Hex String Parsing

### hex0x_to_u64()
```c
int32_t hex0x_to_u64(const char *s, uint64_t *out_u64);
```

**Purpose:** Parse "0x..." hex string to uint64_t.

**Requirements:**
- Must have "0x" or "0X" prefix
- Must have at least one hex digit after prefix
- Result must fit in uint64_t (checked against MAXCOINSUPPLY)

**Returns:**
- 0: Success
- -1: NULL input
- -2: Missing "0x" prefix
- -3: Empty after prefix
- -4: Invalid hex character
- -5: Overflow

---

### hex0x_to_bytes()
```c
int hex0x_to_bytes(const char *hex, uint8_t *out, int out_cap);
```

**Purpose:** Parse "0x..." hex string to byte array.

**Behavior:**
- Strips "0x" prefix if present
- Handles odd-length hex (pads with leading zero)
- Right-aligns result (useful for Ethereum quantities)

**Returns:**
- Number of bytes written (>= 0)
- -1: NULL input
- -2: Invalid hex character
- -3: Output buffer too small

---

### bytes_to_0xhex()
```c
int bytes_to_0xhex(char *dst, int dst_cap, const uint8_t *src, int len);
```

**Purpose:** Convert bytes to "0x..." prefixed hex string.

**Returns:**
- 0: Success
- -1: Invalid input or buffer too small

---

## Address Handling

### addr_hex_to_20()
```c
int addr_hex_to_20(const char *hex_addr, uint8_t out20[20]);
```

**Purpose:** Parse Ethereum address to 20-byte array.

**Handles multiple formats:**
- 20-byte address: Copy directly
- 32-byte padded: Extract last 20 bytes
- Short address: Left-pad with zeros

**Returns:**
- 0: Success
- -1: NULL input
- -4: Invalid length (> 32 bytes)

---

## Integer Encoding

### be_from_u64_min()
```c
int be_from_u64_min(uint64_t v, uint8_t out[8]);
```

**Purpose:** Encode uint64_t as big-endian bytes, returning minimal length.

**Returns:** Number of significant bytes (0 for v=0, up to 8).

**Example:**
```
v = 0x1234  →  out = [00,00,00,00,00,00,12,34], returns 2
v = 0       →  out = [00,00,00,00,00,00,00,00], returns 0
```

---

### be_right_copy_to_32()
```c
void be_right_copy_to_32(uint8_t out32[32], const uint8_t *src, int32_t src_len);
```

**Purpose:** Right-align bytes in 32-byte buffer (left-pad with zeros).

**Use case:** Preparing values for EVM which uses 32-byte words.

---

## Usage Examples

### Parse Ethereum Address
```c
uint8_t addr[20];
int rc = addr_hex_to_20("0x742d35Cc6634C0532925a3b844Bc9e7595f", addr);
if (rc == 0) {
    // addr contains 20-byte address
}
```

### Convert Block Number
```c
uint64_t block_num;
int rc = hex0x_to_u64("0x10a3b5c", &block_num);
// block_num = 17448796
```

### Calculate Current Slot
```c
uint64_t now = time(NULL);
uint64_t slot = eth_slot_from_unix(now, 0);
uint64_t epoch = slot / 32;
```

### Binary to Hex
```c
uint8_t data[32] = {...};
char hex[65];
bin2hex(data, 32, hex);
// hex = "abcd1234..." (64 chars + null)
```

---

## Design Notes

### Why Lookup Tables?
- **Speed:** Single array access vs. conditional branches
- **Consistency:** Same code path for all inputs
- **Cache-friendly:** Small tables fit in L1 cache

### Why Central Functions?
- **Single point of optimization:** Improve one function, benefit everywhere
- **Consistent behavior:** All hex parsing handles "0x" the same way
- **Easier debugging:** One place to add logging/validation

### Error Handling Philosophy
- All functions return error codes (not exceptions)
- Negative values indicate errors
- Zero or positive indicates success
- Callers must check return values

---

## Integration Points

- **bridge_rpc.c** - Uses for parameter encoding
- **bridge_deposit.c** - Uses for address/amount parsing
- **bridge_withdraw.c** - Uses for proof data handling
- **bridge_rlp.c** - Uses for RLP encoding
- **bridge_mpt.c** - Uses for MPT node parsing

---

*Documentation generated by Opus, Wake 1289*
