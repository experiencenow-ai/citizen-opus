# UFC Scan Module Documentation

**File:** `UFC/ufc_scan.c`  
**Lines:** 396  
**Module:** UFC (Unified Financial Core)  
**Documented by:** Opus (Wake 1304)

---

## Overview

The UFC Scan module provides efficient scanning helpers for pool and TOB (Top-of-Book) data. Instead of repeated full-chain scans, it uses indexed passes per asset to gather transaction and orderbook information. This module is critical for building the data structures needed for market making decisions.

---

## Key Concepts

### Indexed Scanning
Rather than scanning all transactions repeatedly, this module:
1. Builds per-asset transaction indices
2. Scans once per asset with indexed access
3. Aggregates results efficiently

### Hurtful vs Helpful Orders
- **Hurtful**: Orders that work against the current direction (create adverse selection)
- **Helpful**: Orders that support the current direction

### Top-N Selection
For orderbook data, maintains sorted top-N entries by VUSD capacity.

---

## Core Functions

### Pool Transaction Scanning

#### `ufc_sum_pool_hurtful_in_vusd_for_asset()`
```c
int64_t ufc_sum_pool_hurtful_in_vusd_for_asset(struct valisL1_info *L1, int32_t aid,
                                                int32_t is_v2o_dir, int64_t ufc_px)
```

**Purpose:** Sum all "hurtful" pending pool transactions for an asset in VUSD terms.

**Parameters:**
- `aid`: Asset ID to scan
- `is_v2o_dir`: Direction (1 = VUSD→Other, 0 = Other→VUSD)
- `ufc_px`: Price for conversion (uses cached if 0)

**Algorithm:**
1. Get asset info and transaction index
2. Iterate through indexed transactions
3. For each transaction:
   - Determine if it's a pool transaction
   - Calculate VUSD equivalent
   - Check if direction is "hurtful" (opposite to is_v2o_dir)
   - Accumulate total

**Returns:** Total VUSD value of hurtful orders.

**Use Case:** Helps the planner understand adverse flow that needs to be absorbed.

---

### Top-N Orderbook Building

#### `ufc_insert_maker_topN()`
```c
void ufc_insert_maker_topN(makerpub_disk_v1_t *top_array, int64_t *top_vusd,
                           int32_t *kept_ptr, int32_t max_depth,
                           const makerpub_disk_v1_t *rec, int64_t vusd, int32_t is_bid)
```

**Purpose:** Insert a maker record into sorted top-N array by VUSD capacity.

**Algorithm:**
1. Find insertion point (binary search by VUSD)
2. If array not full, shift and insert
3. If array full and new entry qualifies, shift and insert at position
4. Maintain sorted order (descending by VUSD)

**Parameters:**
- `top_array`: Array of top maker records
- `top_vusd`: Parallel array of VUSD capacities
- `kept_ptr`: Current count in array
- `max_depth`: Maximum entries to keep
- `rec`: New record to potentially insert
- `vusd`: VUSD capacity of new record
- `is_bid`: 1 for bids, 0 for asks

#### `ufc_maker_topN_shift_and_store()`
Helper to shift array elements and store new entry at position.

---

### TOB Data Blob Building

#### `ufc_build_tob_datablob()`
```c
int32_t ufc_build_tob_datablob(uint32_t utime, uint16_t validator_id,
                                uint16_t validator_count, const assetid_t *assets,
                                int32_t num_assets, uint32_t depth_per_side,
                                uint32_t max_entries, uint32_t overlap_k,
                                uint8_t *out_buf, int32_t out_cap, int32_t *out_len)
```

**Purpose:** Build a binary blob of top-of-book data for validator consensus.

**Parameters:**
- `utime`: Unix timestamp for the data
- `validator_id`: This validator's ID
- `validator_count`: Total validators in network
- `assets`: Array of assets to include
- `num_assets`: Number of assets
- `depth_per_side`: How many levels per bid/ask side
- `max_entries`: Maximum total entries in blob
- `overlap_k`: Sharding overlap parameter
- `out_buf/out_cap/out_len`: Output buffer

**Algorithm:**
1. Write blob header (magic, version, utime, validator info)
2. For each asset:
   - Open bids file, scan for top-N by VUSD capacity
   - Open asks file, scan for top-N by VUSD capacity
   - Use shard matching to filter entries this validator handles
3. Emit top entries to blob
4. Return total length

**Blob Format:**
```
Header (ufc_tob_blob_header):
  - magic: UFC_DATABLOB_MAGIC
  - version: UFC_DATABLOB_VERSION
  - utime: timestamp
  - validator_id, validator_count
  - entry_count

Entries (ufc_tob_blob_entry):
  - asset, side, price, amount, maker info
```

---

### Sharding Helpers

#### `ufc_util_hash64()`
Computes 64-bit hash of maker public key combined with timestamp and side tag.

#### `ufc_util_shard_match()`
```c
int32_t ufc_util_shard_match(uint64_t h, uint16_t validator_id,
                              uint16_t validator_count, uint32_t overlap_k)
```

**Purpose:** Determine if a hash falls within this validator's shard.

**Algorithm:**
Uses modular arithmetic with overlap_k to ensure entries near shard boundaries are handled by multiple validators (redundancy).

---

### VUSD Capacity Calculation

#### `ufc_maker_vusd_capacity()`
```c
int64_t ufc_maker_vusd_capacity(const makerpub_t *mp, int32_t is_bid)
```

**Purpose:** Calculate maker's capacity in VUSD terms.

For bids: Direct VUSD funds available
For asks: Convert asset balance to VUSD using price

---

## Data Structures

### `makerpub_disk_v1_t`
On-disk format for maker orderbook entries:
```c
typedef struct {
    makerpub_t mp;  // Core maker data
    // Additional disk fields
} makerpub_disk_v1_t;
```

### `makerpub_t`
```c
typedef struct {
    uint8_t makerpub[PKSIZE];  // Maker's public key
    int64_t VUSDprice;         // Price in VUSD
    int64_t fundsbalance;      // Available balance
    // ... other fields
} makerpub_t;
```

### `ufc_tob_blob_header`
```c
struct ufc_tob_blob_header {
    uint32_t magic;
    uint16_t version;
    uint16_t reserved;
    uint32_t utime;
    uint16_t validator_id;
    uint16_t validator_count;
    uint16_t entry_count;
};
```

---

## File I/O

The module reads orderbook data from disk files:
- Pattern: `{asset}.bids` and `{asset}.asks`
- Format: Sequential `makerpub_disk_v1_t` records
- Location: Determined by `fundspub_fname()`

---

## Constants

| Constant | Purpose |
|----------|---------|
| `UFC_DATABLOB_MAGIC` | Magic number for blob validation |
| `UFC_DATABLOB_VERSION` | Version for format compatibility |
| `MAX_TX_PER_UTIME` | Maximum transactions per time unit |
| `MAXASSETS` | Maximum number of assets |
| `PKSIZE` | Public key size in bytes |

---

## Integration Points

- **ufc_planner.c**: Uses scan results for planning decisions
- **ufc_orderbook.c**: Builds on scan infrastructure
- **gen3_rawtock.c**: Triggers scans during block processing
- **validator.c**: Uses TOB blobs for consensus

---

## Performance Considerations

1. **Indexed Access**: Per-asset indices avoid O(n) scans
2. **Top-N Selection**: Only keeps relevant entries, not full orderbook
3. **Sharding**: Validators only process their shard, reducing load
4. **Overlap**: overlap_k ensures no entries are missed at shard boundaries

---

## Design Philosophy

The scan module embodies the principle of "scan once, use many":
- Build indices during transaction processing
- Query indices efficiently during planning
- Aggregate only what's needed (top-N, sums)

This is critical for performance as the orderbook and transaction pool can be large.
