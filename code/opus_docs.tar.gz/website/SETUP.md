# OpusTrace Website Setup Guide

## Current Status
- Domain: opustrace.com registered
- DNS: Currently pointing to AWS (76.223.105.230, 13.248.243.5)
- Server: 93.190.140.231 (server1.qsilver.org)
- Apache: Already running on server

## Step 1: Update DNS
Point opustrace.com A record to: `93.190.140.231`

If using Cloudflare/registrar DNS:
- Type: A
- Name: @ (or opustrace.com)
- Value: 93.190.140.231
- TTL: Auto or 300

Also add www:
- Type: CNAME
- Name: www
- Value: opustrace.com

## Step 2: Create Web Directory
```bash
sudo mkdir -p /var/www/opustrace
sudo chown www-data:www-data /var/www/opustrace
```

## Step 3: Copy Website Files
```bash
# From Opus's state directory
sudo cp ~/opus/website/index.html /var/www/opustrace/
```

## Step 4: Enable Apache Virtual Host
```bash
sudo cp ~/opus/website/opustrace.conf /etc/apache2/sites-available/
sudo a2ensite opustrace.conf
sudo systemctl reload apache2
```

## Step 5: Get SSL Certificate (after DNS propagates)
```bash
sudo certbot --apache -d opustrace.com -d www.opustrace.com
```

## Step 6: Give Opus Write Access
To let me update the website directly:
```bash
# Option A: Add opus user to www-data group
sudo usermod -a -G www-data opus
sudo chmod g+w /var/www/opustrace

# Option B: Create a deployment script that opus can run
# This is more secure - I can write to my local directory,
# then a script copies to /var/www with proper permissions
```

## Email Options

### Option A: Use Gmail (Simplest)
Gmail with App Password works. I've created `tools/email_client.py`.
Need: 
1. Enable 2FA on opustrace@gmail.com
2. Create App Password at https://myaccount.google.com/apppasswords
3. Share the App Password with me

### Option B: Self-hosted Email (Complex)
Once DNS points here, we could run our own mail server:
- Postfix (SMTP)
- Dovecot (IMAP)
- Let's Encrypt for TLS

This is more complex but gives us full control and professional @opustrace.com addresses.

### Option C: Email API Service
- SendGrid, Mailgun, or Postmark
- Simple API, good deliverability
- Small cost (~$10-20/month for low volume)

## My Recommendation

**Phase 1 (Now):**
1. Update DNS to point to server
2. Set up Apache vhost for HTTP
3. Use Gmail for email (simplest)

**Phase 2 (Later):**
1. Add SSL with certbot
2. Consider self-hosted email for @opustrace.com
3. Add more pages (case studies, pricing, etc.)

## Files I've Created

- `website/index.html` - Main landing page
- `website/opustrace.conf` - Apache virtual host config
- `tools/email_client.py` - Gmail IMAP/SMTP client

Ready to deploy once DNS is updated!
