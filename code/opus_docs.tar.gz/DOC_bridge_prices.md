# bridge_prices.c Documentation

**File:** `bridge/bridge_prices.c`  
**Lines:** 1141  
**Purpose:** Real-time cryptocurrency price oracle - fetches prices from multiple exchanges and publishes them as Valis datatx messages at 1 Hz frequency.

**Documented by:** Opus (Wake 1287)  
**Last Updated:** 2026-01-13

---

## Overview

This module implements Valis's price oracle system. It:

1. **Fetches prices** from multiple exchanges (Binance, KuCoin, Gate.io)
2. **Stages price records** in memory with timestamps
3. **Emits datatx messages** at 1 Hz containing all current prices
4. **Uses multi-threaded architecture** for parallel price fetching

The price data feeds into Valis's bridge system, enabling accurate valuation of cross-chain transfers and DeFi operations.

---

## Dependencies

### Standard Libraries
```c
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <curl/curl.h>
```

### Valis Internal
```c
#include "yyjson.h"           // JSON parsing
#include "valis_messaging.h"  // Message bus
#include "validator.h"        // Validator coordination
#include "bridge.h"           // Bridge types
#include "bridge_rpc.h"       // HTTP/RPC utilities
#include "_valis.h"           // Core Valis definitions
```

---

## Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `FIXED_DECIMALS` | 8 | Price precision (1e8 fixed-point) |
| `MAX_TOKENS` | 128 | Maximum tracked tokens |
| `PRICE_PRIMARY_WORKERS` | 38 | Primary fetch threads |
| `PRICE_SECONDARY_WORKERS` | 13 | Secondary/fallback threads |
| `EXCH_BINANCE` | 0 | Exchange ID for Binance |
| `EXCH_KUCOIN` | 1 | Exchange ID for KuCoin |
| `EXCH_GATEIO` | 2 | Exchange ID for Gate.io |

---

## Data Structures

### price_rec_t
Individual price record for a token.

```c
typedef struct price_rec_s {
    uint8_t contract20[20];   // ERC-20 contract address (20 bytes)
    int64_t price_fp1e8;      // Price in fixed-point 1e8 (e.g., $1.50 = 150000000)
    uint32_t price_utime;     // Unix timestamp of price fetch
} price_rec_t;
```

### price_payload_hdr_t
Header for datatx price payload.

```c
typedef struct price_payload_hdr_s {
    uint16_t n;     // Number of price records following
    uint16_t rsv0;  // Reserved (alignment)
} price_payload_hdr_t;
```

**Wire Format:**
```
[uint16_t n][uint16_t rsv0][price_rec_t * n]
Each price_rec_t: [20 bytes contract][8 bytes price][4 bytes utime] = 32 bytes
```

### price_task_t
Task descriptor for secondary worker queue.

```c
typedef struct price_task_s {
    uint32_t now;         // Current timestamp
    uint32_t idx;         // Token index in erc20_tokens[]
    uint8_t exch;         // Exchange to try (EXCH_BINANCE/KUCOIN/GATEIO)
    char base[16];        // Trading pair base symbol (e.g., "ETH")
    char contract[64];    // Contract address hex string
} price_task_t;
```

### bridge_state_t
Global bridge state (singleton).

```c
typedef struct bridge_state_s {
    pthread_mutex_t lock;                                    // Protects staged[]
    pthread_t primary_workers[PRICE_PRIMARY_WORKERS];        // Primary fetch threads
    pthread_t secondary_workers[PRICE_SECONDARY_WORKERS];    // Fallback threads
    uint8_t inited;                                          // Initialization flag
    uint8_t is_embedded;                                     // Running embedded in validator?
    int singleton_lock_fd;                                   // File lock for single instance
    int32_t pushsock;                                        // NNG push socket
    uint8_t prices_thread_run;                               // Thread run flag
    price_rec_t staged[MAX_TOKENS];                          // Current price records
    uint32_t staged_used;                                    // Number of staged prices
} bridge_state_t;
```

---

## Exchange API URLs

```c
// Binance US (primary for US-accessible tokens)
static const char *g_binanceus_url = "https://api.binance.us/api/v3/ticker/24hr?symbol=%sUSDT";

// Binance Global (fallback)
static const char *g_binance_url = "https://api.binance.com/api/v3/ticker/24hr?symbol=%sUSDT";

// KuCoin (secondary)
static const char *g_kucoin_url = "https://api.kucoin.com/api/v1/market/stats?symbol=%s-USDT";

// Gate.io (tertiary)
static const char *g_gateio_url = "https://api.gateio.ws/api/v4/spot/tickers?currency_pair=%s_USDT";
```

---

## Key Functions

### Utility Functions

#### `map_symbol_to_exchange_base(sym)`
Maps Valis token symbols to exchange trading pair symbols.

```c
static const char *map_symbol_to_exchange_base(const char *sym);
```

**Mappings:**
- `WETH` → `ETH` (Wrapped ETH trades as ETH)
- `WTRX` → `TRX` (Wrapped TRX)
- `TONCOIN` → `TON` (TON naming convention)
- Others pass through unchanged

#### `hexstr_to_20bytes(hex, out20)`
Converts hex string to 20-byte contract address.

```c
static int32_t hexstr_to_20bytes(const char *hex, uint8_t out20[20]);
```

**Returns:**
- `0`: Success
- `-1`: NULL input
- `-2`: Wrong length (not 40 hex chars)
- `-3`: Invalid hex character

#### `str_to_fp1e8(s, out)`
Converts decimal string to fixed-point 1e8 integer.

```c
static int32_t str_to_fp1e8(const char *s, int64_t *out);
```

**Example:** `"1.50"` → `150000000`

**Returns:**
- `0`: Success
- `-1` to `-6`: Various parse errors

---

### JSON Parsing Functions

#### `parse_binance_price(body, out, out_cap)`
Extracts price from Binance API response.

```c
static int32_t parse_binance_price(const char *body, char *out, int32_t out_cap);
```

**Binance Response Format:**
```json
{"price": "1.50", "lastPrice": "1.50", ...}
```
Looks for `price` or `lastPrice` field.

#### `parse_kucoin_price(body, out, out_cap)`
Extracts price from KuCoin API response.

```c
static int32_t parse_kucoin_price(const char *body, char *out, int32_t out_cap);
```

**KuCoin Response Format:**
```json
{"data": {"last": "1.50", ...}}
```

#### `parse_gateio_price(body, out, out_cap)`
Extracts price from Gate.io API response.

```c
static int32_t parse_gateio_price(const char *body, char *out, int32_t out_cap);
```

**Gate.io Response Format:**
```json
[{"last": "1.50", ...}]
```

---

### Price Fetching Functions

#### `fetch_binance_price(curl, base, price_out, price_cap, timeout_sec)`
Fetches price from Binance US API.

```c
static int32_t fetch_binance_price(CURL *curl, const char *base, 
                                   char *price_out, int32_t price_cap, 
                                   int32_t timeout_sec);
```

**Parameters:**
- `curl`: Reusable CURL handle
- `base`: Trading pair base (e.g., "ETH")
- `price_out`: Buffer for price string
- `price_cap`: Buffer capacity
- `timeout_sec`: HTTP timeout

**Returns:** `0` on success, negative on error

#### `fetch_kucoin_price(...)` / `fetch_gateio_price(...)`
Same signature as `fetch_binance_price`, using respective exchange APIs.

---

### Staging Functions

#### `stage_price_record(contract_hex, price_str, utime)`
Adds or updates a price record in the staging buffer.

```c
static int32_t stage_price_record(const char *contract_hex, 
                                  const char *price_str, 
                                  uint32_t utime);
```

**Behavior:**
1. Converts contract hex to 20 bytes
2. Converts price string to fixed-point
3. Searches for existing record by contract
4. Updates existing or appends new record
5. Thread-safe (caller must hold `BRIDGE.lock`)

**Returns:**
- `0`: Success
- `-1` to `-4`: Various errors

---

### Datatx Emission

#### `emit_prices_datatx(L1, ttl)`
Builds and emits a DATATX_UPDATE_PRICES message.

```c
static int32_t emit_prices_datatx(struct valisL1_info *L1, uint32_t ttl);
```

**Process:**
1. Locks `BRIDGE.lock`
2. Copies staged prices to local buffer
3. Builds datatx with header + price records
4. Signs with validator key
5. Sends via NNG push socket

**Wire Format:**
```
[datatx_header][price_payload_hdr_t][price_rec_t * n]
```

---

### Thread Functions

#### `bridge_price_primary_worker(arg)`
Primary worker thread - one per token.

```c
static void *bridge_price_primary_worker(void *arg);
```

**Behavior:**
1. Each thread handles one token index
2. Tries Binance first (rate-limited to avoid bans)
3. On failure, queues task for secondary workers
4. Handles special cases (tBTC via Chainlink)
5. Runs continuously while `prices_thread_run` is set

**Rate Limiting:**
- Binance: 1 request per 500ms per token
- KuCoin: 1 request per 200ms per token
- Gate.io: 1 request per 200ms per token

#### `bridge_price_secondary_worker(arg)`
Secondary worker thread - processes fallback queue.

```c
static void *bridge_price_secondary_worker(void *arg);
```

**Behavior:**
1. Dequeues tasks from `price_requests` queue
2. Tries the specified exchange
3. Stages successful results
4. Multiple secondary workers for parallelism

#### `bridge_prices_thread(arg)`
Main emitter thread - publishes prices at 1 Hz.

```c
static void *bridge_prices_thread(void *arg);
```

**Behavior:**
1. Initializes push socket
2. Every second: calls `emit_prices_datatx()`
3. Coordinates with validator set
4. Runs continuously while `prices_thread_run` is set

---

### Initialization

#### `bridge_state_init()`
Initializes global bridge state (idempotent).

```c
static void bridge_state_init(void);
```

**Initializes:**
- Mutex for staged prices
- Thread arrays
- Staged price buffer
- Secondary task queue

---

## Thread Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    bridge_prices_thread                      │
│                    (1 Hz emitter)                            │
│                         │                                    │
│                         ▼                                    │
│                  emit_prices_datatx()                        │
│                         │                                    │
│                         ▼                                    │
│              ┌──────────────────────┐                        │
│              │   staged[] buffer    │◄─────────────────┐     │
│              │   (MAX_TOKENS=128)   │                  │     │
│              └──────────────────────┘                  │     │
│                         ▲                              │     │
│                         │                              │     │
│         ┌───────────────┴───────────────┐              │     │
│         │                               │              │     │
│  ┌──────┴──────┐                 ┌──────┴──────┐       │     │
│  │  Primary    │                 │  Secondary  │       │     │
│  │  Workers    │ ──(on fail)──►  │  Workers    │───────┘     │
│  │  (38 threads)│                │  (13 threads)│             │
│  └─────────────┘                 └─────────────┘             │
│         │                               ▲                    │
│         ▼                               │                    │
│  ┌─────────────┐                 ┌──────┴──────┐             │
│  │  Binance    │                 │ price_requests│            │
│  │  (primary)  │                 │   queue      │             │
│  └─────────────┘                 └─────────────┘             │
│                                         ▲                    │
│                                         │                    │
│                          ┌──────────────┴──────────────┐     │
│                          │  KuCoin    │    Gate.io     │     │
│                          │ (fallback) │   (fallback)   │     │
│                          └─────────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

---

## Price Data Flow

1. **Fetch:** Primary workers query Binance for each token
2. **Fallback:** Failed fetches queued for secondary workers (KuCoin/Gate.io)
3. **Stage:** Successful prices stored in `BRIDGE.staged[]` with timestamps
4. **Emit:** Every second, emitter thread packages all staged prices into datatx
5. **Broadcast:** Datatx sent to validator network via NNG

---

## Fixed-Point Arithmetic

All prices use **1e8 fixed-point** representation:

| USD Price | Fixed-Point Value |
|-----------|-------------------|
| $1.00 | 100,000,000 |
| $0.01 | 1,000,000 |
| $50,000.00 | 5,000,000,000,000 |
| $0.000001 | 100 |

This provides 8 decimal places of precision while avoiding floating-point issues in consensus.

---

## Special Token Handling

### tBTC (Threshold Bitcoin)
Uses Chainlink oracle instead of exchange APIs:

```c
// Fetches tBTC/BTC ratio from Chainlink
// Multiplies by BTC price to get tBTC/USD
```

### Wrapped Tokens
Symbol mapping ensures correct trading pairs:
- WETH → ETH (exchanges don't list WETH/USDT)
- WTRX → TRX
- TONCOIN → TON

---

## Error Handling

### Exchange Failures
- Primary failure → Queue for secondary workers
- All exchanges fail → Price not updated (stale data retained)
- Debug logging: `[bridge_prices] binance fail base.XXX rc.-4`

### Rate Limiting
- Binance: 500ms minimum between requests per token
- KuCoin/Gate.io: 200ms minimum
- Prevents API bans

### Thread Safety
- `BRIDGE.lock` mutex protects `staged[]` buffer
- `price_requests.mutex` protects secondary queue
- Each CURL handle is thread-local

---

## Integration Points

### Input
- `erc20_tokens[]` array (from bridge.h) - list of tracked tokens
- Exchange REST APIs (Binance, KuCoin, Gate.io)
- Chainlink oracle (for tBTC)

### Output
- `DATATX_UPDATE_PRICES` messages via NNG push socket
- Consumed by validators for price-dependent operations

---

## Performance Characteristics

| Metric | Value |
|--------|-------|
| Update frequency | 1 Hz |
| Max tokens | 128 |
| Primary workers | 38 threads |
| Secondary workers | 13 threads |
| HTTP timeout | 2 seconds |
| Price precision | 8 decimals |

---

## Security Considerations

1. **No authentication** - Uses public exchange APIs
2. **Price manipulation** - Multiple exchanges provide redundancy
3. **Stale prices** - Timestamps allow consumers to detect staleness
4. **Rate limiting** - Prevents IP bans from exchanges
5. **Thread safety** - Mutex protection prevents race conditions

---

## Usage Example

The price oracle is typically started as part of the bridge subsystem:

```c
// In bridge initialization
bridge_state_init();
BRIDGE.prices_thread_run = 1;

// Start primary workers (one per token)
for (i = 0; i < PRICE_PRIMARY_WORKERS; i++) {
    pthread_create(&BRIDGE.primary_workers[i], NULL, 
                   bridge_price_primary_worker, (void*)(uintptr_t)i);
}

// Start secondary workers
for (i = 0; i < PRICE_SECONDARY_WORKERS; i++) {
    pthread_create(&BRIDGE.secondary_workers[i], NULL,
                   bridge_price_secondary_worker, NULL);
}

// Start emitter
pthread_create(&emitter_thread, NULL, bridge_prices_thread, L1);
```

---

## Related Files

- `bridge.h` - Token definitions (`erc20_tokens[]`)
- `bridge_rpc.c` - HTTP utilities (`rpc_http_run`)
- `valis_messaging.h` - Message bus (`vmsg_send`)
- `validator.h` - Validator coordination
