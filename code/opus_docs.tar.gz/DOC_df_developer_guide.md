# Dataflow Developer Guide Documentation

**Source:** `/root/valis/specs/DF_dev.md`  
**Lines:** 1888  
**Author:** Opus (wake 1323)  
**Last Updated:** 2026-01-13

---

## Overview

This document summarizes the comprehensive Dataflow (DF) Developer Guide for Tockchain/Valis. Dataflows are smart contracts compiled to eBPF bytecode that run at near-native speed.

---

## 1. What is a Dataflow?

A **Dataflow (DF)** is a program that runs on Valis with these properties:

- **Deterministic** - Same inputs always produce same outputs
- **Bounded** - Limited gas, state access, and effects
- **Composable** - Multiple DFs can be called atomically in batches
- **Efficient** - Compiled to BPF bytecode, near-native speed

**Use cases:** Exchanges, lending protocols, vaults, games, DAOs, payment systems.

---

## 2. State Model: Everything is Balances

All persistent state in Valis is stored as **balances** at **addresses**.

### Address Holdings

| Type | Description | Examples |
|------|-------------|----------|
| Real assets | Fungible tokens with economic value | VUSD, BTC, ETH |
| Synthetic assets | Application-defined values as "fake" balances | Position sizes, scores |
| Registers | 16 int64 values per address | Counters, flags, timestamps |

### DF Address (DFADDR)

When deployed, a DF gets its own address that can:
- Hold real assets (treasury/vault)
- Hold synthetic assets (internal state)
- Read/write registers

---

## 3. Execution Model: Three Lanes

### Lane 1: TX_DF_BATCH (Transaction Lane)

**When:** User submits a transaction calling the DF

**Capabilities:** Full power - read/write balances, emit swaps, transfers

**Use cases:** User-initiated deposits, withdrawals, trades, claims

```c
int64_t on_tx(df_ctx_t *ctx)
{
    /* User sent a transaction calling this DF */
    return 0;  /* 0=success, negative=error */
}
```

### Lane 2: Triggercheck (Automation Lane)

**When:** End of every tock (1 second), for registered addresses

**Capabilities:** Emit bounded intents (quotes, rebalances, maintenance)

**Use cases:** Market making, automated rebalancing, maintenance tasks

### Lane 3: Batch (Composability Lane)

**When:** Called as part of a multi-DF batch transaction

**Capabilities:** Participate in atomic multi-step operations

**Use cases:** Flash loans, arbitrage, complex DeFi strategies

---

## 4. The Matrix Model

Every DF execution operates on a **matrix** of addresses × assets:

```
         VUSD    ETH    BTC    LP_TOKEN
User      100     2      0       0
DF       1000    50     10     500
Pool        0   100    100       0
```

### Matrix Operations

- **Rows:** Addresses (user, DF, pools, other DFs)
- **Columns:** Assets (real tokens, synthetic assets)
- **Transfers:** Move values between rows within columns
- **Swaps:** Exchange between columns via UFC

---

## 5. Key API Categories

### 5.1 Balance API

```c
int64_t df_get_balance(addr_ptr, asset_id)     /* Any address, Gas: 15 */
int64_t df_get_balance_src(asset_id)           /* Caller's balance, Gas: 6 */
int32_t df_emit_transfer(from, to, col, amt)   /* Transfer, Gas: 18 */
```

### 5.2 UFC (Exchange) API

```c
int32_t df_ufc_emit_swap(row, col_in, col_out, amt, min_out)  /* Gas: 30 */
int32_t df_ufc_get_mid_spread(asset, &mid, &spread)           /* Gas: 15 */
int32_t df_ufc_emit_pool_deposit(pool, vusd, other, min_lp)   /* Gas: 15 */
int32_t df_ufc_emit_pool_withdraw(pool, lp, min_vusd, min_o)  /* Gas: 15 */
int32_t df_ufc_emit_limit_order(row, col, is_buy, price, qty) /* Gas: 15 */
```

### 5.3 Register API

```c
int64_t df_reg(ctx, i)              /* Get src register */
void df_reg_set(ctx, i, value)      /* Set src register */
int64_t df_dfreg(ctx, i)            /* Get DF register */
void df_dfreg_set(ctx, i, value)    /* Set DF register */
```

### 5.4 Math API (128-bit precision)

```c
int64_t df_muldiv_trunc(a, b, den)  /* (a*b)/den, round toward zero */
int64_t df_muldiv_floor(a, b, den)  /* (a*b)/den, round toward -∞ */
int64_t df_muldiv_ceil(a, b, den)   /* (a*b)/den, round toward +∞ */
```

### 5.5 Crypto API

```c
int32_t df_merkle_verify(root, leaf, len, proof, plen, idx)  /* Merkle proof */
int32_t df_sig_verify(pubkey, hash, sig, type)               /* Signature */
int32_t df_hash256(data, len, out32)                         /* Hash */
```

### 5.6 Pipe API (Inter-DF Communication)

```c
uint16_t df_pipe_in_len(void)                    /* Input pipe length */
int32_t df_pipe_in_read(offset, dst, len)        /* Read from pipe */
int32_t df_pipe_out_append(type, data, len)      /* Write to pipe */
```

---

## 6. Batch Transactions

Batches enable atomic multi-DF operations:

```json
{
    "addresses": [USER, LENDING_DF, DEX_DF],
    "assets": [VUSD, ETH, LP_TOKEN],
    "calls": [
        { "df": LENDING_DF, "flags": BORROW, "payload": [...] },
        { "df": DEX_DF, "flags": SWAP, "payload": [...] },
        { "df": LENDING_DF, "flags": REPAY, "payload": [...] }
    ]
}
```

### Atomicity Guarantee

- If **any** call returns negative, entire batch aborts
- If **all** succeed, all changes commit atomically
- Enables flash loans, arbitrage, complex DeFi

### Flash Loan Pattern

```
1. Borrow without collateral
2. Trade/arbitrage
3. Repay with fee
→ If step 3 fails, steps 1-2 never happened
```

---

## 7. Gas and Limits

### Gas Costs

| Operation | Gas |
|-----------|-----|
| Arithmetic | 1 |
| Memory load/store | 1 |
| Branch | 1 |
| API call (base) | ~20 |
| df_sig_verify | ~1500 |
| df_hash256 | 25 + len/64 |

### Resource Limits

| Resource | Limit |
|----------|-------|
| Matrix rows | 16 |
| Matrix columns | 16 |
| Registers per address | 16 |
| Scratch memory | ~64k bytes |
| Transfers per tx | 32 |
| Total effects per tx | 64 |
| Pipe buffer size | 4096 bytes |

---

## 8. Building and Deploying

### Project Structure

```
my_df/
├── my_df.c          # Your DF code
├── df_sdk.h         # SDK header
├── df_gas.h         # Gas costs
└── Makefile
```

### Compilation

```bash
# Compile to BPF object
clang -target bpf -O2 -c my_df.c -o my_df.o

# Deploy to testnet
valis-cli df deploy my_df.o --network testnet
```

### DFID: Immutable Identity

```
DFID = valis_hash(df_image_bytes)[0..19]
```

- Any code change produces a **new DFID**
- Old DFID continues to exist
- Users must explicitly migrate to new versions

---

## 9. Security Checklist

Before deploying:

- [ ] **Validate all inputs** - call_flags, userdata, amounts
- [ ] **Check balances before transfers** - underflow fails the tx
- [ ] **Use safe math** - df_muldiv for multiplication/division
- [ ] **Handle all error cases** - propagate errors, don't swallow
- [ ] **Test edge cases** - zero amounts, max amounts, wrong phase
- [ ] **Consider reentrancy** - batches can call your DF multiple times
- [ ] **Verify signatures/proofs** - don't trust without verification

---

## 10. Complete Helper Reference

### Balance & Transfer (Gas: 6-25)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 1 | GET_BALANCE | 2 | 15 |
| 2 | GET_BALANCE_SRC | 1 | 6 |
| 3 | EMIT_TRANSFER | 4 | 18 |
| 70 | TRANSFER_EXCESS | 4 | 25 |

### UFC Exchange (Gas: 15-30)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 10 | UFC_EMIT_SWAP | 5 | 30 |
| 11 | UFC_GET_MID_SPREAD | 3 | 15 |
| 12 | UFC_ESTIMATE_SWAP | 6 | 20 |
| 13 | UFC_EMIT_POOL_DEPOSIT | 4 | 15 |
| 14 | UFC_EMIT_POOL_WITHDRAW | 4 | 15 |
| 15 | UFC_EMIT_LIMIT_ORDER | 5 | 15 |

### Pricing (Gas: 10-18)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 20 | PRICE_MID | 2 | 10 |
| 21 | PRICE_HAIRCUT | 2 | 14 |
| 22 | PRICE_PREMIUM | 2 | 14 |
| 23 | PREMIUM_BPS | 2 | 8 |
| 24 | MOMENTUM_BPS | 2 | 8 |
| 25 | MEAN_REV_BPS | 2 | 8 |

### Registers (Gas: 2-6)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 30 | REG_GET | 1 | 2 |
| 31 | REG_SET | 2 | 2 |
| 32 | DFREG_GET | 1 | 6 |
| 33 | DFREG_SET | 2 | 6 |

### Math (Gas: 2-4)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 75 | MATH_MUL_DIV_FLOOR | 3 | 4 |
| 76 | MATH_MUL_DIV_CEIL | 3 | 4 |
| 50-57 | MIN/MAX/ABS/CLAMP | 1-3 | 1-2 |

### Crypto (Gas: 25-1500)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 35 | MERKLE_VERIFY | 6 | 25+depth*8 |
| 36 | SIG_VERIFY | 4 | ~1500 |
| 37 | HASH256 | 3 | 25+len/64 |

### Pipes (Gas: 5-8+)

| ID | Name | Args | Gas |
|----|------|------|-----|
| 45 | PIPE_IN_LEN | 0 | 5 |
| 46 | PIPE_IN_READ | 3 | 6+⌈n/512⌉ |
| 47 | PIPE_OUT_APPEND | 3 | 8+⌈n/512⌉ |

---

## 11. Example: Simple Vault DF

```c
#include "df_sdk.h"

#define ACTION_DEPOSIT  1
#define ACTION_WITHDRAW 2
#define COL_VUSD 0

int64_t on_tx(df_ctx_t *ctx)
{
    uint16_t action = df_flags(ctx) & 0xFF;
    
    switch (action) {
        case ACTION_DEPOSIT: {
            int64_t amount = df_userdata_i64(ctx, 0);
            if (amount <= 0) return -1;
            
            /* Transfer from user to DF */
            int32_t rc = df_emit_transfer(0, 1, COL_VUSD, amount);
            if (rc < 0) return rc;
            
            /* Record deposit in user's register */
            int64_t prev = df_reg(ctx, 0);
            df_reg_set(ctx, 0, prev + amount);
            return 0;
        }
        
        case ACTION_WITHDRAW: {
            int64_t amount = df_userdata_i64(ctx, 0);
            int64_t deposited = df_reg(ctx, 0);
            
            if (amount > deposited) return -2;  /* Insufficient */
            
            /* Transfer from DF to user */
            int32_t rc = df_emit_transfer(1, 0, COL_VUSD, amount);
            if (rc < 0) return rc;
            
            df_reg_set(ctx, 0, deposited - amount);
            return 0;
        }
        
        default:
            return -1;
    }
}
```

---

## 12. Related Documentation

| Document | Purpose |
|----------|---------|
| DOC_dataflow.md | Main dataflow engine code |
| DOC_dataflow_h.md | Dataflow structures |
| DOC_dataflow_batch.md | Batch processing |
| DOC_dataflow_trigger.md | Trigger execution |
| DOC_vbpf.md | eBPF VM implementation |
| DOC_LOAN.md | Lending protocol DF |
| DOC_MM.md | Market maker DF |
| DOC_PERP.md | Perpetuals DF |

---

*This document is part of the Tockchain documentation project.*
