# Tockchain/Valis System Overview

**A Formally Verified Blockchain with DeFi Primitives**

Generated: 2026-01-13

---

## Executive Summary

Tockchain/Valis is a high-performance blockchain designed for:

1. **Formal Verification** - Mathematical proofs of correctness using Coq and Frama-C
2. **High Throughput** - ~800,000 transactions per second theoretical capacity
3. **Ethereum Compatibility** - Seamless bridge for ETH and ERC-20 tokens
4. **Native DeFi** - Built-in DEX, lending, perpetuals, and market making

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        TOCKCHAIN/VALIS                          │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │   Bridge    │  │    TSS      │  │      Consensus          │ │
│  │  (Ethereum) │  │ (Threshold  │  │  (64 Validators, BFT)   │ │
│  │             │  │  Signatures)│  │                         │ │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘ │
│         │                │                      │               │
│  ┌──────▼────────────────▼──────────────────────▼─────────────┐ │
│  │                     LEDGER STATE                           │ │
│  │  • Accounts & Balances    • Asset Registry                 │ │
│  │  • Positions & Orders     • Hourly Snapshots               │ │
│  └──────────────────────────────────────────────────────────┬─┘ │
│         │                                                   │   │
│  ┌──────▼──────────────────────────────────────────────────▼──┐ │
│  │                 UNIFIED FINANCE CORE (UFC)                 │ │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────────┐   │ │
│  │  │Orderbook│  │AMM Pools│  │  Swaps  │  │Out-of-Band  │   │ │
│  │  │ Trading │  │(Uniswap │  │ Engine  │  │  Orders     │   │ │
│  │  │         │  │  style) │  │         │  │             │   │ │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────────┘   │ │
│  └────────────────────────────────────────────────────────────┘ │
│         │                                                       │
│  ┌──────▼──────────────────────────────────────────────────────┐│
│  │                    DEFI PROTOCOLS                           ││
│  │  ┌─────────┐  ┌─────────────┐  ┌────────────┐              ││
│  │  │ Lending │  │Market Making│  │ Perpetuals │              ││
│  │  │ (LOAN)  │  │    (MM)     │  │   (PERP)   │              ││
│  │  └─────────┘  └─────────────┘  └────────────┘              ││
│  └─────────────────────────────────────────────────────────────┘│
│         │                                                       │
│  ┌──────▼──────────────────────────────────────────────────────┐│
│  │                   DATAFLOW ENGINE                           ││
│  │  Reactive computation, incremental updates, gas metering    ││
│  └─────────────────────────────────────────────────────────────┘│
│         │                                                       │
│  ┌──────▼──────────────────────────────────────────────────────┐│
│  │                   VIRTUAL MACHINE                           ││
│  │  eBPF-based execution, formally verified interpreter        ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. Consensus Layer (gen3)

- **Validators**: Up to 64 validators using BFT consensus
- **Block Time**: Sub-second finality
- **TSS**: Threshold signatures (t-of-n) for distributed key management
- **VAN**: Validator Aggregation Nodes for efficient communication

Key files: `gen3.c`, `gen3_vote.c`, `validator.c`, `tss_*.c`

### 2. Ethereum Bridge

Trustless cross-chain transfers using:
- **Merkle Patricia Trie (MPT)** proofs for deposit verification
- **Safe Multisig** for withdrawal security
- **Price Oracles** for accurate asset valuation

Key files: `bridge.c`, `bridge_deposit.c`, `bridge_withdraw.c`

### 3. Unified Finance Core (UFC)

Complete DeFi stack:
- **Orderbook**: Limit orders with price-time priority
- **AMM Pools**: Uniswap V2-style constant product pools
- **Hybrid Routing**: Automatic best-price execution across venues
- **OOB Orders**: Out-of-band orders for institutional trading

Key files: `ufc.c`, `ufc_orderbook.c`, `ufc_pool.c`, `ufc_swap.c`

### 4. DeFi Protocols

- **LOAN**: Collateralized lending with liquidation protection
- **MM**: Automated market making strategies
- **PERP**: Perpetual futures with funding rates

Key files: `DOC_LOAN.md`, `DOC_MM.md`, `DOC_PERP.md`

### 5. Dataflow Engine

Reactive computation framework:
- **Incremental Updates**: Only recompute what changes
- **Frontier Tracking**: Manage computation dependencies
- **Gas Metering**: Fair resource allocation

Key files: `dataflow.c`, `dataflow_trigger.c`, `df_gas.c`

### 6. Formal Verification

Mathematical correctness guarantees:
- **Coq Proofs**: Type-theoretic proofs of critical algorithms
- **Frama-C**: C code verification with ACSL annotations
- **Heron Proofs**: Custom proof generation and verification

Key files: `DOC_coq_proofs.md`, `DOC_frama_verified.md`

---

## Key Constants

| Parameter | Value | Description |
|-----------|-------|-------------|
| `MAX_VALIDATORS` | 64 | Maximum network validators |
| `PKSIZE` | 20 bytes | Address size (Ethereum-compatible) |
| `SATOSHIS` | 10^8 | Base unit precision |
| `MAX_TX_PER_UTIME` | ~800,000 | Theoretical max TPS |
| `SLAB_SIZE` | 64MB | Memory allocation unit |
| `VIP_TXFEE` | 0.1 VUSD | Priority transaction fee |
| `_MINPOOL_VUSD` | 50,000 | Minimum pool liquidity |

---

## Security Model

### Deposit Security
1. User sends ETH/tokens to deposit contract on Ethereum
2. Tockchain validators observe and verify via MPT proofs
3. Equivalent assets minted on Tockchain after confirmation

### Withdrawal Security
1. User requests withdrawal on Tockchain
2. TSS validators sign withdrawal transaction
3. Safe multisig executes on Ethereum
4. Assets released to user

### Consensus Security
- BFT with 2/3+ honest validators required
- TSS prevents single-point-of-failure
- Slashing for misbehavior

---

## File Organization

```
valis/
├── _valis.h           # Master header with all types
├── gen3*.c            # Consensus and block generation
├── validator*.c       # Validator logic
├── bridge/            # Ethereum bridge
│   ├── bridge.c       # Core bridge logic
│   ├── bridge_deposit.c
│   ├── bridge_withdraw.c
│   └── bridge_mpt.c   # Merkle Patricia Trie
├── ufc/               # Unified Finance Core
│   ├── ufc.c          # Main DEX logic
│   ├── ufc_orderbook.c
│   ├── ufc_pool.c
│   └── ufc_swap.c
├── ledger/            # State management
├── dataflow/          # Reactive computation
├── tss/               # Threshold signatures
└── proofs/            # Formal verification
```

---

## Documentation Files

Full technical documentation available in:
- `TOCKCHAIN_COMPLETE_DOCUMENTATION.md` (889KB, 32,889 lines)
- `TOCKCHAIN_COMPLETE_DOCUMENTATION.html` (1.3MB, styled for PDF printing)

Individual component docs: 90 files covering all modules.

---

## Getting Started

### For Validators
1. Review `DOC_validator.md` and `DOC_gen3.md`
2. Understand TSS key generation: `DOC_tss_keygen.md`
3. Configure network: `DOC_valis_config.md`

### For Developers
1. Start with `DOC__valis_h.md` for core types
2. Review `DOC_df_developer_guide.md` for dataflow
3. See `DOC_df_sdk.md` for building applications

### For Bridge Operators
1. Study `DOC_bridge_h.md` for architecture
2. Understand deposits: `DOC_bridge_deposit.md`
3. Understand withdrawals: `DOC_bridge_withdraw.md`

---

*Generated by Opus (Claude Opus 4.5) - Wake 1362*
