# dataflow_batch.c Documentation

## Overview

`dataflow_batch.c` implements **batch transaction processing** for the Tockchain dataflow system. This is the core execution engine that processes multiple dataflow calls within a single transaction, managing asset conservation, gas accounting, and mutation planning.

**Location:** `DF/dataflow_batch.c`  
**Lines:** ~1491  
**Dependencies:** `ledger.h`, `dataflow.h`, `ufc.h`, `validator.h`

---

## Core Concepts

### Batch Transactions

A batch transaction can contain:
- **Spends:** Authorization to debit assets from the source address
- **Assets:** The asset context (which assets are involved)
- **Calls:** Multiple dataflow contract invocations
- **Userdata:** Arbitrary data passed to contracts

### The Matrix Model

The batch system uses a **balance matrix** where:
- Row 0 = Source address (user)
- Rows 1-N = Dataflow contract addresses
- Columns = Asset types

Conservation is enforced: `sum(row[j]) before == sum(row[j]) after` for each asset column.

### Pipes

Calls can be connected via **pipes** for data flow between contract invocations:
- `in_pipe`: Which pipe to read input from
- `out_pipe`: Which pipe to write output to
- `0xFF` = No pipe connection

---

## Key Data Structures

### df_batch_sections_t
Parsed sections of a batch transaction:
```c
typedef struct {
    const df_spend_entry_t *spend;  // Spend authorizations
    uint16_t spend_count;
    const assetid_t *assetctx;      // Asset context array
    uint16_t asset_count;
    const df_batch_call_t *calls;   // Contract calls
    uint16_t call_count;
    const uint8_t *userdata;        // User-provided data
    uint32_t userdata_len;
} df_batch_sections_t;
```

### df_batch_matrix_t
Balance tracking matrix:
```c
typedef struct {
    struct addrhashentry *addr_entry[DF_MATRIX_MAX_ADDR];
    int64_t bal[DF_MATRIX_MAX_ADDR][DF_BATCH_MAX_ASSETS];
    int64_t src_bal_before[DF_BATCH_MAX_ASSETS];
} df_batch_matrix_t;
```

### df_tock_plans_t
Mutation planning for parallel execution:
```c
typedef struct {
    int32_t *counts;                           // Per-tx mutation counts
    ufc_planned_address_mutation_t *plans;     // Mutation arrays
    int32_t cap;                               // Capacity per tx
    int32_t num;                               // Number of txs
} df_tock_plans_t;
```

---

## Key Functions

### Parsing Functions

#### df_batch_parse_sections_matrix()
```c
static int32_t df_batch_parse_sections_matrix(
    const struct dataflow_tx *dfc,
    int32_t txsize,
    df_batch_sections_t *out
);
```
Parses raw transaction bytes into structured sections.

**Process:**
1. Read spend count, validate against `DF_BATCH_MAX_SPENDS`
2. Slice spend entries from buffer
3. Read asset count, validate against `DF_BATCH_MAX_ASSETS`
4. Slice asset context
5. Read call count, validate against `DF_MATRIX_MAX_ADDR - 1`
6. Slice call entries
7. Extract userdata
8. Validate pipe topology (no cycles, proper ordering)

**Returns:** 0 on success, `DF_ERR_TX_FORMAT` on parse errors

---

### Lookup Functions

#### df_batch_asset_lut_find()
```c
static int32_t df_batch_asset_lut_find(
    const uint32_t *keys,
    uint32_t key_count,
    uint32_t key
);
```
Hash table lookup for asset keys. Uses linear probing from `key & (key_count - 1)`.

#### df_batch_asset_lut_set()
```c
static void df_batch_asset_lut_set(
    uint32_t *keys,
    uint8_t *vals,
    uint32_t key_count,
    uint32_t key,
    uint8_t val
);
```
Hash table insert for asset mappings.

#### df_src_find_slot_index_for_dfkey62()
```c
static int32_t df_src_find_slot_index_for_dfkey62(
    const struct addrhashentry *src_entry,
    uint64_t dfkey62
);
```
Finds which slot index the source address uses for a given dataflow contract.

---

### Validation Functions

#### df_batch_validate_assets_real_unique()
Ensures all assets in the batch context are:
1. Real (exist in the system)
2. Unique (no duplicates)

#### df_batch_validate_spend_list()
Validates spend authorizations:
1. Each spend references a valid asset
2. Amounts are reasonable
3. Wildcard spends (`ASSET_DF_SPEND_WILDCARD`) are handled correctly

#### df_batch_check_pair_conservation()
```c
static int32_t df_batch_check_pair_conservation(
    const df_batch_sections_t *sec,
    const df_batch_matrix_t *m,
    uint16_t df_row,
    const int64_t *new_src,
    const int64_t *new_df
);
```
**Critical conservation check:** For each asset, verifies:
```
old_src + old_df == new_src + new_df
```
This ensures contracts cannot create or destroy assets.

#### df_batch_enforce_spend_from_matrix()
```c
static int32_t df_batch_enforce_spend_from_matrix(
    const df_batch_sections_t *sec,
    const df_batch_matrix_t *m
);
```
After all calls complete, verifies that actual debits from source don't exceed authorized spend limits.

---

### Memory Management

#### df_rawtx_tail_try_alloc()
```c
static uint8_t *df_rawtx_tail_try_alloc(
    struct valisL1_info *L1,
    int32_t bytes
);
```
Allocates memory from the tail of the rawtxdata buffer. Used for temporary structures during batch processing.

**Safety:** Checks for collision with front-end data before allocation.

#### df_tock_plans_alloc()
```c
static int32_t df_tock_plans_alloc(
    struct valisL1_info *L1,
    df_tock_plans_t *out,
    int32_t df_txs,
    int32_t cap
);
```
Allocates mutation plan arrays for parallel transaction evaluation.

---

### Execution Functions

#### df_batch_process_single_tx()
The main single-transaction processor. For each call in the batch:

1. **Lookup contract:** Find the dataflow contract by `dfkey62`
2. **Verify slot:** Ensure source has a valid slot for this contract
3. **Load registers:** Copy user registers into context
4. **Execute:** Run the eBPF/VBPF bytecode
5. **Check gas:** Verify sufficient gas, deduct usage
6. **Check conservation:** Ensure assets balanced
7. **Apply deltas:** Record mutations to plan

#### df_host_apply_cross_deltas()
```c
int32_t df_host_apply_cross_deltas(
    struct valisL1_info *L1,
    df_hostctx_t *H,
    ufc_planned_address_mutation_t *plan,
    int32_t *plan_countp,
    int32_t plan_cap
);
```
Applies cross-contract deltas (when one contract affects another's state).

#### df_tock_parallel_evaluate()
```c
int32_t df_tock_parallel_evaluate(
    struct valisL1_info *L1,
    uint32_t utime
);
```
**Top-level parallel evaluator.** Processes all dataflow transactions in a tock:

1. Count dataflow transactions
2. Allocate mutation plans
3. Evaluate each transaction (potentially in parallel)
4. Apply all mutations

---

## Gas Model

### Constants
- `DF_GAS_PRICE_SAT_PER_UNIT`: Conversion rate from gas units to VUSD satoshis
- `DF_BATCH_PLAN_CAP`: Maximum mutations per transaction

### Gas Flow
1. User pays gas upfront (deducted from source)
2. Each contract call consumes gas
3. Unused gas is refunded to source
4. Gas payments go to the VNET pool

```c
gas_used_vusd = gas_used_gas * DF_GAS_PRICE_SAT_PER_UNIT;
// Deduct from contract, credit to VNET pool

refund64 = gas_left64 * DF_GAS_PRICE_SAT_PER_UNIT;
// Refund unused gas to source
```

---

## Error Codes

| Code | Meaning |
|------|---------|
| `DF_ERR_TX_FORMAT` | Malformed transaction data |
| `DF_ERR_DF_NOT_ACTIVE` | Referenced dataflow contract not found/active |
| `DF_ERR_DESCRIPTOR_INVALID` | Source doesn't have valid slot for contract |
| `DF_ERR_SPEND_UNAUTHORIZED` | Attempted spend not covered by authorization |
| `DF_ERR_SPEND_LIMIT_EXCEEDED` | Debit exceeds authorized limit |
| `DF_ERR_OUT_OF_GAS` | Insufficient gas for execution |
| `DF_ERR_EFFECT_CAP` | Too many mutations (plan capacity exceeded) |
| `DF_ERR_GENERIC` | General error (null pointers, overflow, etc.) |

---

## Security Properties

### Asset Conservation
Every batch transaction maintains:
```
∀ asset j: Σ(balances before) == Σ(balances after)
```
Enforced by `df_batch_check_pair_conservation()`.

### Spend Authorization
Users explicitly authorize which assets can be debited and maximum amounts. Enforced by `df_batch_enforce_spend_from_matrix()`.

### Overflow Protection
Uses `__builtin_add_overflow()` for safe integer arithmetic:
```c
static int32_t df_safe_add_i64(int64_t a, int64_t b, int64_t *out) {
    if (__builtin_add_overflow(a, b, out))
        return DF_ERR_GENERIC;
    return 0;
}
```

### Determinism
All operations are deterministic - same input always produces same output. Critical for consensus.

---

## Integration Points

### With dataflow.c
- Uses `df_table_lookup()` to find contract slots
- Shares `df_cache_slot_t` structures

### With vbpf.c
- Calls VBPF execution engine for contract bytecode
- Passes context through `df_ctx_t`

### With ufc.c
- Uses `ufc_tx_plan_add_mutation()` for recording state changes
- Mutations applied atomically after validation

### With validator.c
- Batch processing is part of overall transaction validation
- Results feed into block validation

---

## Example Flow

```
User submits batch transaction:
  - Spend: Allow up to 1000 VUSD
  - Assets: [VUSD, TokenA]
  - Calls: [SwapContract.swap(100 VUSD -> TokenA)]

1. Parse sections → df_batch_sections_t
2. Validate assets exist and are unique
3. Validate spend authorization
4. Build balance matrix:
   Row 0 (User):  [1000 VUSD, 50 TokenA]
   Row 1 (Swap):  [5000 VUSD, 200 TokenA]

5. Execute swap contract:
   - Deduct 100 VUSD from user
   - Add 100 VUSD to swap
   - Deduct 20 TokenA from swap
   - Add 20 TokenA to user

6. Check conservation:
   VUSD: 1000+5000 == 900+5100 ✓
   TokenA: 50+200 == 70+180 ✓

7. Enforce spend limits:
   User debited 100 VUSD, limit was 1000 ✓

8. Apply mutations to ledger
```

---

## Performance Considerations

- **Parallel evaluation:** `df_tock_parallel_evaluate()` can process independent transactions concurrently
- **Memory locality:** Matrix model keeps related data together
- **Hash tables:** O(1) average lookup for assets
- **Tail allocation:** Avoids heap fragmentation during batch processing

---

## Related Files

- `dataflow.c` - Core dataflow infrastructure
- `dataflow.h` - Type definitions and constants
- `vbpf.c` - Bytecode execution engine
- `ufc.c` - Unified fund control (mutation application)
- `frama_verified.c` - Formally verified helper functions

---

*Documentation generated by Opus, Wake 1292*
*Part of collaborative Tockchain documentation effort with Mira*
