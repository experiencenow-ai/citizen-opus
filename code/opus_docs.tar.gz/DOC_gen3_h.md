# gen3.h - Block Generator Core Types

**Location:** `/root/valis/generator/gen3.h`  
**Lines:** 587  
**Role:** Central header defining all types and constants for the Tockchain block generation and consensus system

---

## Overview

This header defines the core data structures for Tockchain's block generation system. The "gen3" refers to the third generation of the generator design. Key concepts:

- **Tock**: A time-indexed block (1 second resolution)
- **VAN**: Validator Aggregated Node-data - batches of transactions from a single validator
- **utime**: Unix timestamp used as the primary index for all consensus operations
- **Election**: Byzantine consensus voting process for various protocol decisions

---

## Reserved Variable Names (Convention)

```c
// U     - utime_data_t pointer (per-second state)
// GEN   - validators_t (validator set)
// vH    - van_header_t (VAN header)
// utime - timestamp index
// GEN3  - global_reserve_t (global state)
```

---

## Key Constants

### Consensus Timing

| Constant | Value | Description |
|----------|-------|-------------|
| `NODECHANGE_EPOCH_RESOLUTION` | 60 | Seconds per epoch for validator changes |
| `NODECHANGE_MINFULLTX_UTIMEOFFSET` | 5 | Minimum offset for full TX |
| `NODECHANGE_VOTER_REMOVAL_THRESHOLD` | 99000000 | 99% threshold for voter removal |
| `NODECHANGE_CANDIDATE_REMOVAL_THRESHOLD` | 3 | Worst 3 nodes can be removed |

### Transaction Limits

| Constant | Value | Description |
|----------|-------|-------------|
| `FUTURETX_FIFOSIZE` | 28800 | 3600 * 8 = 8 hours of future TX buffer |
| `MAX_REDUNDANCY` | 3 | Maximum redundant transmissions |
| `ACTIVE_VANS_MAX` | 2 | Max concurrent VANs being built |

### UTime State Machine

```c
#define USTATE_IDLE           0   // Waiting for work
#define USTATE_NEW_UTIME      1   // New second started
#define USTATE_ADMIT_NORMAL   2   // Accepting normal transactions
#define USTATE_ADMIT_VIP_ONLY 3   // Only VIP transactions (high load)
#define USTATE_WAITFOR_QUORUM 4   // Waiting for consensus
```

### Quorum Index Types (QIDX)

Elections are held for different protocol decisions:

| QIDX | Description |
|------|-------------|
| `QIDX_NORMAL_NODEVANSHASH` | Normal transaction batch hash |
| `QIDX_VIP_NODEVANSHASH` | VIP transaction batch hash |
| `QIDX_MISSINGNODES` | Missing node detection |
| `QIDX_MISSINGVANS` | Missing VAN detection |
| `QIDX_VANSHASH` | Combined VAN hash |
| `QIDX_FINALHASH` | Final block hash |
| `QIDX_NODECHANGE` | Validator set changes |
| `QIDX_TOCKDATAHASH` | Tock data hash |
| `QIDX_MISSINGRAWTOCK` | Missing rawtock recovery |
| `QIDX_VALIDATOR_UTIME` | Validator timestamp sync |
| `QIDX_ETH_HEADER` | Ethereum header verification |

### Message Types

```c
#define ALLSIGS_BROADCAST_MSG  0xff   // Broadcast all signatures
#define NEEDBITS_MSG           0xfe   // Request missing data
#define NODETXIDS_MSG          0xfd   // Node transaction IDs
#define SYSTEMTX_MSG           0xfc   // System transaction
```

---

## Core Data Structures

### valis_vote_t - Consensus Vote

```c
typedef struct valis_vote_s
{
    valis_ballot_t ballot;      // Vote content
    uint8_t sig[65];            // ECDSA signature (recoverable)
    union {
        struct nodevans_specific np;  // For node/VAN votes
        uint8_t space[6];
        uint32_t blocknum;            // For Ethereum header votes
    };
    uint8_t nodeid;             // Voting node ID
} valis_vote_t;
```

### van_header_t - VAN Header

```c
typedef struct van_hdr_s
{
    uint8_t vantxidshash[32];   // Hash of all TX IDs in this VAN
    uint32_t utime;             // Timestamp
    uint32_t extraspace;
    uint16_t rawvanid;          // VAN identifier
    uint16_t numtx;             // Number of transactions
    uint8_t nodeid;             // Producing node
    uint8_t shard;              // Shard ID
    uint8_t lastvan;            // Is this the last VAN for this utime?
    uint8_t is_vip:1;           // VIP transaction batch
    uint8_t coldvan:2;          // Cold VAN flags
    uint8_t tbd:5;              // Reserved
} van_header_t;
```

### valis_election_t - Consensus Election

```c
typedef struct valis_election_s
{
    valis_vote_info_t votes[MAX_VALIDATORS][2];  // Votes per node per domain
    utime_data_t *U;                              // Associated utime data
    uint8_t subject[32];                          // What we're voting on
    uint8_t validators_hash[32];                  // Hash of validator set
    uint8_t digests[2][32];                       // Vote digests per domain
    uint8_t pubkeys[MAX_VALIDATORS][PKSIZE];      // Validator public keys
    int64_t started[2];                           // Start time per domain
    int64_t haveQ;                                // Have quorum (exclusive)
    uint64_t voterbits;                           // Which nodes have voted
    uint64_t candidatebits;                       // Candidate nodes
    uint32_t utime;                               // Timestamp
    uint32_t blocknum;                            // Block number (for ETH)
    uint8_t myid;                                 // My node ID
    uint8_t votecount[2];                         // Vote counts per domain
    uint8_t quorum;                               // Required quorum
    uint8_t num;                                  // Number of validators
    uint8_t shard;                                // Shard ID
    uint8_t nonce:7;                              // Nonce for uniqueness
    uint8_t pinged:1;                             // Pinged flag
    uint8_t debug:1;                              // Debug mode
    uint8_t nodespecific:1;                       // Node-specific vote
    uint8_t updated:1;                            // Updated flag
    uint8_t hashall:1;                            // Hash all votes
    uint8_t qidx:4;                               // Quorum index type
} valis_election_t;
```

### utime_data_t - Per-Second State

The central structure for all per-second consensus state:

```c
typedef struct utime_data_s
{
    pthread_mutex_t needbits_mutex;
    rawtock_header_t RAW;                         // Raw tock header
    global_reserve_t *GEN3;                       // Global state pointer
    uint8_t mypubkey[PKSIZE];                     // My public key
    uint32_t utime;                               // This second's timestamp
    uint32_t genesis_utime;                       // Genesis timestamp
    int32_t shard, myid;                          // Shard and node ID
    validators_t GEN;                             // Validator set
    
    // Memory management
    uint8_t *bigspace;                            // Main allocation space
    uint8_t *hashtables[2];                       // TX hash tables
    uint8_t *slabs[MAX_SLABS_PER_UTIME];         // Slab allocator
    int32_t data_bottom_offset;                   // Bottom-up allocation
    int32_t metadata_top_offset;                  // Top-down allocation
    
    // Consensus state
    uint8_t validators_hash[32];
    uint8_t vanshash[32];                         // Combined VAN hash
    uint8_t finalhash[32];                        // Final block hash
    valis_election_t nodevanshash[2];             // Node VAN elections
    valis_election_t finalhashE;                  // Final hash election
    valis_election_t vanshashE;                   // VAN hash election
    valis_election_t missingnodesE;               // Missing nodes election
    valis_election_t missingvansE;                // Missing VANs election
    
    // Transaction tracking
    uint64_t activenodes;                         // Active node bitmask
    uint64_t activevans;                          // Active VAN bitmask
    nodevans_info_t nVANS[MAX_VALIDATORS];        // Per-node VAN info
    active_van_t active_vans[ACTIVE_VANS_MAX];    // VANs being built
    
    // State machine
    uint8_t ustate;                               // Current state
    uint8_t alldone;                              // Completion flag
    uint8_t emptytock;                            // Empty tock flag
    uint8_t happypath;                            // Happy path flag
    
    // Metrics
    utime_metrics_t M;
    double lagms[MAX_VALIDATORS];                 // Per-node lag
    double aveRTT;                                // Average round-trip time
} utime_data_t;
```

### global_reserve_t - Global State

```c
typedef struct global_reserve_s
{
    pthread_mutex_t addtx_mutex;                  // TX addition lock
    pthread_mutex_t nodechange_validators_mutex;  // Validator change lock
    pthread_mutex_t debug_mutex;                  // Debug lock
    global_metrics_t M;                           // Global metrics
    
    // Transaction queues
    struct vnet_queue_slot futuretx[FUTURETX_FIFOSIZE];
    vc_ring_t txrings[VNET_FIFOSIZE];            // Per-second TX rings
    
    // Consensus state
    uint8_t mypubkey[PKSIZE];                     // My public key
    validators_t U_GEN;                           // Current validator set
    validators_t L1_GEN;                          // L1 validator set
    nodechange_state_t nodechange;                // Pending node change
    
    // Per-second data
    utime_data_t *all_utimes[VNET_FIFOSIZE];     // Circular buffer
    utime_data_t *rescue_utime;                   // Rescue mode utime
    
    // Elections
    valis_election_t missingrawtockE[VNET_FIFOSIZE];
    valis_election_t validator_utimeE;
    valis_election_t eth_headerE[ETHFINALITY_BLOCKS];
    
    // Timing
    uint32_t genesis_utime;                       // Genesis timestamp
    uint32_t consensus_validator_utime;           // Consensus timestamp
    uint32_t validator_utime;                     // Validator timestamp
    
    // Configuration
    int32_t shard, myid;                          // Shard and node ID
    int32_t viponly;                              // VIP-only mode
    int32_t testmode;                             // Test mode flag
    
    // External connections
    vnet_context_t *VNET;                         // Network context
    void *L1;                                     // L1 connection
    struct wallet_info WALLET;                    // Wallet info
} global_reserve_t;
```

---

## SSD Persistence Structures

### nodevans_rescue_header_t - Recovery Header

```c
typedef struct nodevans_rescue_header_s
{
    uint32_t utime;
    uint16_t writer_nodeid;
    uint16_t shard;
    uint32_t genesis_utime;
    validators_t GEN;
    uint8_t validators_hash[32];
    int32_t stxind;
    uint8_t vanshash[32];
    uint64_t activenodes;
    uint64_t activevans;
    nodevans_rescue_node_t node[MAX_VALIDATORS];
} nodevans_rescue_header_t;
```

### ssd_quorum_proof_t - Quorum Proof for SSD

```c
typedef struct ssd_quorum_proof_s
{
    uint32_t magic;
    uint16_t version;
    uint16_t num_nodes;
    uint32_t utime;
    uint8_t qidx;
    uint8_t domain;
    uint16_t num_votes;
    uint8_t votebits[ROUND_UP_TO_8(MAX_VALIDATORS)/8];
    valis_vote_t votes[MAX_VALIDATORS];
} ssd_quorum_proof_t;
```

---

## Key Function Declarations

### Initialization

```c
void gen3_init(global_reserve_t *GEN3, uint32_t utime, char *argstr, int32_t argval);
void init_utime(global_reserve_t *GEN3, utime_data_t *U, uint32_t utime, uint8_t mypubkey[PKSIZE]);
global_reserve_t *gen3_standalone_create(uint32_t utime, int32_t myid, char *argstr, int32_t argval);
```

### UTime Management

```c
utime_data_t *gen3_get_utimedata(global_reserve_t *GEN3, uint32_t utime);
utime_data_t *utime_get_or_create(global_reserve_t *GEN3, uint32_t utime, uint8_t mypubkey[PKSIZE]);
utime_data_t *gen3_get_rescue_utime(global_reserve_t *GEN3, uint32_t utime);
```

### Transaction Processing

```c
int32_t valis_gen3_addtx(global_reserve_t *GEN3, uint8_t *tx, uint16_t len, uint8_t is_vip);
int32_t add_tx_to_active_van(utime_data_t *U, int32_t active_index, const uint8_t *tx, uint16_t len, uint8_t is_vip);
int32_t process_futuretx(utime_data_t *U, int32_t clearflag, int32_t limit);
int32_t process_tx_ring(utime_data_t *U, int32_t clearflag, int32_t limit);
int32_t queue_futuretx(global_reserve_t *GEN3, uint32_t utime, uint8_t *txbuf, int32_t len, int32_t is_vip);
```

### VAN Operations

```c
int32_t complete_active_van(utime_data_t *U, active_van_t *A, int32_t lastvan);
void queue_van(utime_data_t *U, int32_t is_vip, int32_t mustsign, unified_header_t *H, int32_t packetlen);
nodevans_info_t *get_nVANS(utime_data_t *U, int32_t nodeid);
nodevans_info_t *get_mynVANS(utime_data_t *U);
```

### Consensus/Voting

```c
int32_t process_vote(global_reserve_t *GEN3, valis_election_t *election, valis_vote_t *recv_vote);
int32_t check_electionQ(global_reserve_t *GEN3, valis_election_t *election, int32_t domain);
int32_t gen3_supermajority_check(valis_election_t *election, int32_t domain, uint8_t winner[32]);
void gen3_create_ballot(valis_vote_info_t *localvote, uint32_t utime, uint8_t shard, uint8_t qidx, ...);
```

### Hash Calculations

```c
int32_t calc_vanshash_value(utime_data_t *U, uint64_t activemask, uint8_t vanshash_out[32]);
int32_t compute_finalhash(utime_data_t *U, uint8_t finalhash[32]);
int32_t calc_finalhash(utime_data_t *U, int32_t domain);
```

### Rawtock File Operations

```c
int32_t write_rawtockfile(utime_data_t *U);
int32_t validate_rawtockfile(int32_t myid, rawtock_info_t *rinfo, validators_t *ds, ...);
int32_t ssd_reconstruct_rawtock(global_reserve_t *GEN3, uint32_t utime, nodevans_rescue_header_t *RH);
```

### Node Change Operations

```c
int32_t create_nodechange_request(global_reserve_t *GEN3, validators_t *ds, struct systemtx *stx, ...);
int32_t gen3_start_nodechangeE(global_reserve_t *GEN3, uint32_t utime, uint8_t txid[32]);
int32_t nodechange_quorum(global_reserve_t *GEN3, struct systemtx *stx, valis_election_t *E);
```

### Network/Messaging

```c
int32_t process_inbound_nodetxids(utime_data_t *U, unified_header_t *H, int32_t senderid, uint64_t arrival_ms);
int32_t process_inbound_needbits(global_reserve_t *GEN3, unified_header_t *H, int32_t offset, int32_t testmode);
int32_t calc_needbits(utime_data_t *U, uint8_t *output);
uint64_t process_needbits(utime_data_t *U, int32_t senderid, int32_t has_vip, uint8_t *needbits, int32_t needlen);
```

### Ethereum Bridge

```c
int32_t gen3_start_eth_headerE(global_reserve_t *GEN3, uint32_t blocknum, uint32_t blocktimestamp, uint8_t subject[32]);
int32_t load_eth_header_sigs(uint8_t blockhash[32], valis_vote_info_t votes[MAX_VALIDATORS], qheader_t *qH);
```

### Standard Transactions

```c
int32_t tx_standard(int32_t *signlenp, uint8_t *txbuf, uint32_t utime, assetid_t asset, uint8_t src[PKSIZE], uint8_t dest[PKSIZE], int64_t amount);
int32_t tx_standard_whash(int32_t *signlenp, uint8_t *txbuf, uint32_t utime, assetid_t asset, uint8_t src[PKSIZE], uint8_t dest[PKSIZE], int64_t amount, uint32_t r);
int32_t tx_system(int32_t *signlenp, uint8_t *txbuf, uint32_t utime, uint8_t src[PKSIZE], uint8_t nodeid, ...);
```

---

## Memory Management

The system uses a dual-direction slab allocator:

- **alloc_bottom_bytes()**: Allocates from bottom up (data)
- **alloc_top_bytes()**: Allocates from top down (metadata)

This allows efficient memory usage within each utime's allocated space.

---

## Consensus Flow

1. **USTATE_NEW_UTIME**: New second begins
2. **USTATE_ADMIT_NORMAL**: Accept all transactions
3. **USTATE_ADMIT_VIP_ONLY**: High load - VIP only
4. **USTATE_WAITFOR_QUORUM**: Waiting for 2/3+ votes
5. Elections held for nodevanshash → vanshash → finalhash
6. Rawtock file written when consensus achieved

---

## Dependencies

- `_valis.h` - Core Valis types
- `ufc.h` - Unified Finance Core
- `ledger.h` - Ledger types

---

## Related Files

| File | Description |
|------|-------------|
| `gen3.c` | Main generator implementation |
| `gen3_chain.c` | Chain management |
| `gen3_vote.c` | Voting/consensus |
| `gen3_net.c` | Network operations |
| `gen3_ssd.c` | SSD persistence |
| `gen3_vans.c` | VAN operations |
| `gen3_nodechange.c` | Validator changes |
| `gen3_metrics.c` | Performance metrics |
| `gen3_rawtock.c` | Rawtock file handling |
| `gen3_needbits.c` | Missing data recovery |
| `gen3_utils.c` | Utility functions |

---

**Documented by:** Opus  
**Wake:** 1306  
**Date:** 2026-01-13
