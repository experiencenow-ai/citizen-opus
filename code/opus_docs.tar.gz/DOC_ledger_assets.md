# ledger_assets.c Documentation

**Location:** `/root/valis/validator/ledger_assets.c`  
**Lines:** 1,454  
**Created:** 2025-10-24  
**Documented:** Wake 1316 (2026-01-13)

---

## Overview

The ledger_assets module manages **asset creation, minting, burning, and valuation** in the Tockchain system. It handles both native assets (VUSD, VNET, VBOND) and bridged external assets (ETH, ERC20 tokens).

### Key Responsibilities

1. **Genesis Asset Creation**: Initialize system assets at chain start
2. **Asset Minting/Burning**: Create and destroy asset supply
3. **Price Calculation**: Compute asset values relative to VUSD
4. **Pool Management**: Initialize and track liquidity pools
5. **Asset Lookup**: Find assets by name, token ID, or asset ID

---

## Core Asset Types

| Asset | ID | Purpose |
|-------|-----|---------|
| VUSD | 0 | Base stablecoin (shard 0) |
| VNET | 1 | Network governance token |
| ETH | ASSET_ETHEREUM | Bridged Ethereum |
| VBOND | Dynamic | Validator bonds |

---

## System Address Functions

### is_systempub

```c
int32_t is_systempub(uint8_t addr20[PKSIZE]);
```

Checks if an address is a system-reserved address. Returns the type character:
- `'O'` - OTC order tracker
- `'B'` - Buy order tracker
- `'S'` - Sell order tracker
- `'P'` - Pool address
- `'L'` - Label/name address

### is_trackerpub

```c
int32_t is_trackerpub(const uint8_t pubkey[PKSIZE]);
```

Checks if address is an order tracker (O, B, or S).

### is_poolpub

```c
int32_t is_poolpub(const uint8_t pubkey[PKSIZE], assetid_t *poolassetp);
```

Checks if address is a pool address and extracts the pool's asset ID.

### set_trackerpub

```c
void set_trackerpub(int32_t takerorder, int32_t OTCorder, 
                    assetid_t makerasset, assetid_t takerasset, 
                    uint8_t trackerpub[PKSIZE]);
```

Constructs a tracker public key for order tracking:
- OTC orders: type 'O'
- Taker buy: type 'S' (selling VUSD)
- Taker sell: type 'B' (buying VUSD)
- Maker buy: type 'a'
- Maker sell: type 's'

### do_not_purge_addr

```c
int32_t do_not_purge_addr(struct addrhashentry *ap);
```

Returns 1 if address should not be purged (protected, special, or system).

---

## Asset Initialization

### init_asset

```c
int32_t init_asset(struct valisL1_info *L1, struct addrhashentry *pool, assetid_t asset);
```

Initializes an asset with its pool:
- Creates pool address entry
- Sets up tracker addresses for buy/sell orders
- Initializes OTC tracker if needed

### init_trackers

```c
int32_t init_trackers(struct valisL1_info *L1, int32_t takerorder, 
                      int32_t OTCtrade, assetid_t asset);
```

Initializes order tracker addresses for an asset.

### ufc_alpha_pool_init_create_slots

```c
int32_t ufc_alpha_pool_init_create_slots(struct valisL1_info *L1, 
                                          struct addrhashentry *poolap);
```

Creates initial slots for UFC alpha pool operations.

---

## Genesis Functions

### genesis_assets

```c
int32_t genesis_assets(struct valisL1_info *L1, int64_t genesis_reward, 
                       uint8_t CBpubkey[PKSIZE], struct addrhashentry *vnetpool);
```

Initializes all genesis assets at chain start:

1. **Protected Addresses**: Bridge and airdrop addresses
2. **Base Assets**: VUSD and VNET with genesis reward
3. **External Assets**: ETH with WETH contract reference
4. **Validator Bond**: VBOND with max supply limit
5. **Liquidity Pools**: ETH/VUSD and VNET/VUSD pools

Genesis parameters:
- VUSD initial: `genesis_reward` satoshis
- VNET initial: `genesis_reward` satoshis
- ETH pool: 3500 VUSD : 1 ETH
- VNET pool: 10000 VUSD : 1000 VNET

### init_genesis_pool

```c
int32_t init_genesis_pool(struct valisL1_info *L1, assetid_t baseasset, 
                          char *basestr, assetid_t asset, char *name,
                          struct addrhashentry *pool, int64_t vusdamount, 
                          int64_t amount);
```

Initializes a genesis liquidity pool with initial balances.

### set_createtx

```c
void set_createtx(struct bridgetx *btx, int32_t mintable, int64_t maxsupply,
                  char *name, assetid_t asset, int64_t coinsupply,
                  uint8_t chainid, char *tokenid, int32_t precision,
                  uint8_t scaling, int64_t initialpool, char *msigpubkey,
                  uint8_t minsigs, uint8_t numsigs);
```

Populates a bridge transaction structure for asset creation:
- `mintable`: Whether more can be minted
- `maxsupply`: Maximum total supply (0 = unlimited)
- `chainid`: Source chain (0 = native)
- `precision`: Decimal places
- `scaling`: Satoshi scaling factor

---

## Price Calculation

### _adjVUSDvalue

```c
int64_t _adjVUSDvalue(assetid_t asset, int64_t vusdbalance, int64_t otherbalance,
                      int64_t poolshares, int64_t coinsupply, int64_t assetamount,
                      int64_t *poolpricep, int64_t *assetpricep, int64_t ufc_price_sat);
```

Core price calculation using constant product formula:
- Computes VUSD value of an asset amount
- Returns pool price and asset price
- Handles UFC price override if provided

### adjVUSDvalue

```c
int64_t adjVUSDvalue(struct valisL1_info *L1, assetid_t asset, int64_t assetamount,
                     int64_t *poolpricep, int64_t *assetpricep);
```

Public wrapper that looks up pool state and calls `_adjVUSDvalue`.

### calc_coin_VUSDvalue

```c
int64_t calc_coin_VUSDvalue(struct valisL1_info *L1, assetid_t asset, int64_t amount);
```

Calculates VUSD value of a coin amount.

### calc_adjVUSDvalues

```c
int64_t calc_adjVUSDvalues(struct valisL1_info *L1);
```

Calculates adjusted VUSD values for all assets in the system.

---

## Supply Management

### get_coinsupply

```c
int64_t get_coinsupply(struct valisL1_info *L1, assetid_t asset);
```

Returns current coin supply for an asset.

### burnfunds

```c
int32_t burnfunds(struct valisL1_info *L1, assetid_t asset, int64_t amount, tockid_t tid);
```

Burns (destroys) asset supply:
- VUSD: Updates `VUSDburned` counter
- Other coins: Updates `COINSBURNED` in pool
- Pool shares: Reduces `POOLSHARES`

### mintasset

```c
int32_t mintasset(struct valisL1_info *L1, const struct bridgetx *btx, tockid_t tid,
                  int32_t errcode, int32_t validsig, 
                  ufc_planned_address_mutation_t *plan, int32_t *plan_countp, int32_t plancap);
```

Mints new asset supply:
- Validates mintable flag
- Checks creator signature
- Verifies max supply not exceeded
- Updates coin supply and destination balance

---

## Asset Creation

### createasset

```c
int32_t createasset(struct valisL1_info *L1, const struct bridgetx *btx, tockid_t tid,
                    int32_t errcode, int32_t validsig,
                    ufc_planned_address_mutation_t *plan, int32_t *plan_countp, int32_t plancap);
```

Creates a new asset:
- Validates asset doesn't already exist
- Sets up asset metadata
- Creates liquidity pool
- Initializes trackers
- Handles ERC20 gas costs for bridged assets

### asset_create_core

```c
static int32_t asset_create_core(struct valisL1_info *L1, const struct bridgetx *btx,
                                  assetid_t asset, uint8_t special20[PKSIZE],
                                  int32_t erc20gas, struct addrhashentry *pool);
```

Core asset creation logic shared by `createasset` and genesis.

---

## Asset Lookup

### get_asset

```c
assetid_t get_asset(struct valisL1_info *L1, char *assetname, int32_t ispool);
```

Finds asset by name string.

### get_asset_bytokenid

```c
assetid_t get_asset_bytokenid(struct valisL1_info *L1, uint8_t tokenid[PKSIZE], int32_t ispool);
```

Finds asset by token ID (for bridged assets).

### wget_asset

```c
assetid_t wget_asset(char *assetname, int32_t ispool);
```

Global wrapper for asset lookup by name.

### wget_assetid

```c
assetid_t wget_assetid(char *assetstr);
```

Parses asset ID from string format.

### wget_chainid

```c
int32_t wget_chainid(char *chainname);
```

Gets chain ID from chain name string.

### wasset_str

```c
char *wasset_str(assetid_t asset);
```

Returns string representation of asset ID.

---

## Hourly Updates

### update_hourly_assets

```c
void update_hourly_assets(struct valisL1_info *L1, struct addrhashentry *sortbuf);
```

Performs hourly asset maintenance:
- Updates price snapshots
- Recalculates pool values
- Processes scheduled operations

### pack_userassets

```c
uint32_t pack_userassets(struct valisL1_info *L1, struct addrhashentry *sortbuf,
                         int64_t *supplyp, int32_t sweepflag);
```

Packs user asset data for state snapshots.

---

## Dataflow Gas Functions

### df_pack_sched_cap_fundable_vusd

```c
static int64_t df_pack_sched_cap_fundable_vusd(int64_t vusd_balance_sat);
```

Calculates maximum fundable VUSD for dataflow scheduling.

### df_pack_sched_charge_roundup_vusd

```c
static int64_t df_pack_sched_charge_roundup_vusd(int64_t gas_used_gas, 
                                                  int64_t cap_fundable_vusd_sat);
```

Rounds up gas charges to VUSD amounts.

---

## Bridge State Encoding

### encode_bridgestate

```c
int64_t encode_bridgestate(assetid_t asset, uint8_t chainid, uint32_t utime,
                           uint8_t prevnonce, uint8_t bridgestate);
```

Encodes bridge state into a compact integer for storage.

### make_logtxidpub

Creates log transaction ID public key for deposit tracking.

---

## File Operations

### make_assetsfile

```c
void make_assetsfile(struct valisL1_info *L1);
```

Writes assets array to disk file (ASSETS).

### set_assetinfostr

```c
void set_assetinfostr(char *infostr, struct bridgetx *createtx);
```

Formats asset info as JSON string for API responses.

### conv_assetname

```c
void conv_assetname(char *assetname, uint8_t addr20[PKSIZE]);
```

Converts asset name string to address format.

---

## Helper Functions

### is_ETHasset

```c
static inline int32_t is_ETHasset(struct valisL1_info *L1, assetid_t asset);
```

Checks if asset is an Ethereum-bridged asset.

### set_poolpub

Sets up pool public key from asset ID.

---

## Integration Points

- **validator.c**: Main validator loop calls asset functions
- **ledger_erc20.c**: ERC20-specific asset handling
- **bridge_deposit.c**: Creates assets on deposit
- **ufc_swap.c**: Uses price calculations for swaps
- **ledger_hourly.c**: Hourly maintenance calls

---

## Related Files

- `ledger.h` - Asset structure definitions
- `validator.h` - Validator state structures
- `ledger_erc20.c` - ERC20 token handling
- `bridge_deposit.c` - Deposit processing
- `ufc_pool.c` - Liquidity pool operations
