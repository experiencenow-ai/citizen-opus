# bridge_rpc.c / bridge_rpc.h Documentation

**File:** `bridge/bridge_rpc.c` (712 lines), `bridge/bridge_rpc.h` (114 lines)  
**Purpose:** Ethereum JSON-RPC client with type-safe parameter building and async support  
**Documented by:** Opus (Wake 1289)  
**Status:** Complete

---

## Overview

This module provides a complete Ethereum JSON-RPC client implementation. It handles:

1. **Type-safe parameter construction** - A DSL for building RPC parameters without manual JSON
2. **Automatic hex encoding** - Converts bytes, u64, u256 to proper "0x..." format
3. **Synchronous HTTP calls** - Simple blocking RPC via libcurl
4. **Asynchronous calls** - Thread-based async with callbacks and cancellation
5. **Endpoint failover** - Automatic selection from multiple public RPC endpoints

The design philosophy is "describe it, don't build it" - callers describe parameter types and values, and the module handles all JSON serialization.

---

## Dependencies

### Headers
```c
#include <curl/curl.h>     // HTTP client
#include "_valis.h"        // Global CONFIG struct
#include "bridge.h"        // Bridge types
#include "bridge_rpc.h"    // Type definitions (see below)
#include "yyjson.h"        // JSON serialization
```

### External Libraries
- **libcurl** - HTTP/HTTPS client
- **yyjson** - Fast JSON library for serialization
- **pthread** - Threading for async calls

---

## Data Structures (from bridge_rpc.h)

### rpc_type_t - Parameter Type Enumeration
```c
typedef enum rpc_type_e {
    RPCV_NULL = 0,          // JSON null
    RPCV_BOOL = 1,          // true/false
    RPCV_STR  = 2,          // Literal JSON string
    RPCV_HEXBYTES = 3,      // Raw bytes → "0x..." hex string
    RPCV_QUANTITY_U64 = 4,  // u64 → minimal "0x..." (0 => "0x0")
    RPCV_OBJECT = 5,        // Nested object
    RPCV_ARRAY  = 6,        // Nested array
    RPCV_HEXSTR = 7,        // Already-encoded hex string
    RPCV_U256_BE = 8,       // Big-endian bytes → minimal "0x..."
    RPCV_U256_LE = 9,       // Little-endian bytes → minimal "0x..."
    RPCV_NUMBER_U64 = 10,   // Plain numeric u64 (not hex)
} rpc_type_t;
```

### rpc_value_t - Tagged Union for Values
```c
typedef struct rpc_value_s {
    rpc_type_t t;           // Type tag
    union {
        const char *s;                              // String pointer
        struct { const uint8_t *p; uint32_t n; } bytes;  // Byte array
        uint64_t u64;                               // 64-bit integer
        uint8_t b;                                  // Boolean
        struct rpc_object_s *obj;                   // Object pointer
        struct rpc_array_s  *arr;                   // Array pointer
    } v;
} rpc_value_t;
```

### rpc_object_t - Key-Value Object
```c
typedef struct rpc_object_s {
    uint8_t n;                          // Number of fields
    rpc_kv_t kv[RPC_MAX_FIELDS];        // Key-value pairs (max 16)
} rpc_object_t;
```

### rpc_array_t - Array of Values
```c
typedef struct rpc_array_s {
    uint8_t n;                              // Number of elements
    rpc_value_t elems[RPC_MAX_ARRAY_ELEMS]; // Elements (max 16)
} rpc_array_t;
```

### curl_params_t - Complete RPC Call Parameters
```c
typedef struct curl_params_s {
    const char   *url;                      // Optional URL override
    rpc_value_t   params[RPC_MAX_PARAMS];   // Method parameters (max 16)
    uint8_t       params_n;                 // Parameter count
    rpc_object_t  objects[RPC_MAX_OBJECTS]; // Object pool (max 16)
    uint8_t       objects_n;                // Objects used
    rpc_array_t   arrays[RPC_MAX_ARRAYS];   // Array pool (max 16)
    uint8_t       arrays_n;                 // Arrays used
} curl_params_t;
```

The pool design (objects[], arrays[]) allows callers to build complex nested structures without heap allocation at call sites.

---

## Capacity Constants

```c
#define RPC_MAX_PARAMS        16   // Max parameters per call
#define RPC_MAX_OBJECTS       16   // Max nested objects
#define RPC_MAX_ARRAYS        16   // Max nested arrays
#define RPC_MAX_FIELDS        16   // Max fields per object
#define RPC_MAX_ARRAY_ELEMS   16   // Max elements per array
```

These fixed capacities eliminate allocation complexity while handling typical Ethereum RPC needs.

---

## Value Constructor Functions (Inline)

These "describe it" helpers create typed values without allocation:

```c
rpc_value_t rpcv_null(void);                              // JSON null
rpc_value_t rpcv_bool(bool b);                            // true/false
rpc_value_t rpcv_str(const char *s);                      // Literal string
rpc_value_t rpcv_hexstr(const char *s);                   // Hex string (adds 0x if needed)
rpc_value_t rpcv_hexbytes(const uint8_t *p, uint32_t n);  // Bytes → hex
rpc_value_t rpcv_quantity_u64(uint64_t u);                // u64 → minimal hex
rpc_value_t rpcv_u256_be(const uint8_t *be, uint32_t n);  // BE bytes → hex
rpc_value_t rpcv_u256_le(const uint8_t *le, uint32_t n);  // LE bytes → hex
rpc_value_t rpcv_number_u64(uint64_t u);                  // Plain numeric
rpc_value_t rpcv_object(rpc_object_t *obj);               // Nested object
rpc_value_t rpcv_array(rpc_array_t *arr);                 // Nested array
```

---

## Core Functions

### valis_config_assign_default_ethrpc()
```c
void valis_config_assign_default_ethrpc(char ethrpc[256]);
```

**Purpose:** Randomly select a public Ethereum RPC endpoint.

**Endpoints Pool:**
- ethereum.publicnode.com
- 1rpc.io/eth
- eth.llamarpc.com
- ethereum.public.blockpi.network
- eth.drpc.org
- rpc.mevblocker.io
- eth.api.onfinality.io
- eth.api.pocket.network
- ethereum-json-rpc.stakely.io
- endpoints.omniatech.io
- ethereum.rpc.subquery.network
- eth.leorpc.com
- public-eth.nownodes.io
- ethereum-public.nodies.app

**Why Random:** Distributes load across providers, provides resilience if one is down.

---

### rpc_obj_put_kv()
```c
int32_t rpc_obj_put_kv(rpc_object_t *o, const char *key, rpc_value_t val);
```

**Purpose:** Add a key-value pair to an object.

**Returns:**
- 0: Success
- -50: NULL object or key
- -51: Object full (>= RPC_MAX_FIELDS)

---

### rpc_arr_push()
```c
int32_t rpc_arr_push(rpc_array_t *a, rpc_value_t val);
```

**Purpose:** Append a value to an array.

**Returns:**
- 0: Success
- -52: NULL array
- -53: Array full (>= RPC_MAX_ARRAY_ELEMS)

---

### be_bytes_to_minimal_0x() / le_bytes_to_minimal_0x()
```c
static int32_t be_bytes_to_minimal_0x(char *dst, int32_t dst_cap, 
                                       const uint8_t *be, uint32_t n);
int32_t le_bytes_to_minimal_0x(char *dst, int32_t dst_cap, 
                                const uint8_t *le, uint32_t n);
```

**Purpose:** Convert byte arrays to minimal hex strings per Ethereum spec.

**Behavior:**
- Strips leading zeros (0x0001 → "0x1")
- All-zero input → "0x0"
- Max 32 bytes (256-bit integers)

**Example:**
```
Input:  [0x00, 0x00, 0x12, 0x34]
Output: "0x1234"
```

---

### emit_value()
```c
static yyjson_mut_val *emit_value(yyjson_mut_doc *doc, const rpc_value_t *v);
```

**Purpose:** Recursively convert rpc_value_t to yyjson value.

**Handles all types:**
- NULL → JSON null
- BOOL → true/false
- STR → string literal
- HEXSTR → adds "0x" prefix if missing
- HEXBYTES → converts bytes to hex string
- QUANTITY_U64 → minimal hex quantity
- U256_BE/LE → minimal hex from bytes
- NUMBER_U64 → plain number
- OBJECT → recursive object emission
- ARRAY → recursive array emission

---

### bridge_rpc_build_params_json()
```c
int32_t bridge_rpc_build_params_json(const curl_params_t *P, 
                                      char *out, int32_t out_cap);
```

**Purpose:** Build JSON params array from curl_params_t.

**Returns:**
- 0: Success
- -1: NULL inputs
- -5: JSON serialization failed
- -6: Output buffer too small

**Output:** JSON array string like `["0x1234", {"to": "0xabc..."}, true]`

---

### rpc_http()
```c
int32_t rpc_http(const char *url, const char *method, const char *extra_header,
                 const char *body, int32_t body_len, char *out, int32_t out_cap,
                 int32_t timeout_sec);
```

**Purpose:** Low-level HTTP request via libcurl.

**Parameters:**
- `url`: Target URL
- `method`: "GET" or "POST"
- `extra_header`: Additional header (e.g., "Content-Type: application/json")
- `body`: Request body (NULL for GET)
- `body_len`: Body length
- `out`: Response buffer
- `out_cap`: Buffer capacity
- `timeout_sec`: Timeout in seconds

**Returns:**
- 0: Success (response in out)
- -1: Invalid params
- -2: curl_easy_init failed
- -3: Request failed
- -4: HTTP error (non-2xx)
- -5: Response too large

---

### http_get()
```c
int32_t http_get(const char *url, char *out, int32_t out_cap, int32_t timeout_sec);
```

**Purpose:** Simple HTTP GET request.

**Behavior:** If url is NULL, uses CONFIG.ethrpc or random default endpoint.

---

### rpc_json()
```c
int32_t rpc_json(const char *url, const char *method, const curl_params_t *P,
                 char *out, int32_t out_cap, int32_t timeout_sec);
```

**Purpose:** Execute a JSON-RPC call.

**Parameters:**
- `url`: RPC endpoint (NULL uses P->url or CONFIG.ethrpc)
- `method`: RPC method name (e.g., "eth_call", "eth_getBalance")
- `P`: Parameters structure
- `out`: Response buffer
- `out_cap`: Buffer capacity
- `timeout_sec`: Timeout

**Builds request body:**
```json
{
  "jsonrpc": "2.0",
  "method": "<method>",
  "params": [<serialized from P>],
  "id": 1
}
```

---

## Async API

### bridge_rpc_async_t
```c
struct bridge_rpc_async_s {
    char *url;
    char *body;
    int32_t timeout_sec;
    bridge_rpc_cb cb;           // Callback function
    void *userdata;             // User context
    pthread_t th;               // Worker thread
    volatile int32_t cancel_flag;
};
```

### Callback Signature
```c
typedef void (*bridge_rpc_cb)(int32_t status, const char *response, void *userdata);
```

### bridge_rpc_async_json()
```c
bridge_rpc_async_t *bridge_rpc_async_json(const char *url, const char *method,
                                           const curl_params_t *P,
                                           int32_t timeout_sec,
                                           bridge_rpc_cb cb, void *userdata);
```

**Purpose:** Start an asynchronous RPC call.

**Returns:** Task handle for cancellation/cleanup, or NULL on error.

**Thread behavior:**
- Spawns pthread to execute request
- Calls callback with result when complete
- Supports cancellation via cancel_flag

---

### bridge_rpc_async_cancel()
```c
void bridge_rpc_async_cancel(bridge_rpc_async_t *task);
```

**Purpose:** Request cancellation of async task.

**Behavior:** Sets cancel_flag; curl progress callback checks this and aborts if set.

---

### bridge_rpc_async_free()
```c
void bridge_rpc_async_free(bridge_rpc_async_t *task);
```

**Purpose:** Clean up async task resources.

**Important:** Should be called after task completes or is cancelled.

---

## Usage Examples

### Simple eth_call
```c
curl_params_t P = {0};
rpc_object_t *call_obj = &P.objects[P.objects_n++];

// Build call object
rpc_obj_put_kv(call_obj, "to", rpcv_hexbytes(contract_addr, 20));
rpc_obj_put_kv(call_obj, "data", rpcv_hexbytes(calldata, calldata_len));

// Set parameters: [call_obj, "latest"]
P.params[P.params_n++] = rpcv_object(call_obj);
P.params[P.params_n++] = rpcv_str("latest");

char response[4096];
int32_t rc = rpc_json(NULL, "eth_call", &P, response, sizeof(response), 30);
```

### eth_getBalance
```c
curl_params_t P = {0};
P.params[P.params_n++] = rpcv_hexbytes(address, 20);  // Address
P.params[P.params_n++] = rpcv_str("latest");          // Block tag

char response[1024];
rpc_json(NULL, "eth_getBalance", &P, response, sizeof(response), 15);
```

### Async Call with Callback
```c
void my_callback(int32_t status, const char *response, void *userdata) {
    if (status == 0) {
        printf("Got response: %s\n", response);
    } else {
        printf("Error: %d\n", status);
    }
}

curl_params_t P = {0};
// ... set up params ...

bridge_rpc_async_t *task = bridge_rpc_async_json(
    NULL, "eth_blockNumber", &P, 30, my_callback, NULL);

// Later...
bridge_rpc_async_cancel(task);  // If needed
bridge_rpc_async_free(task);
```

---

## Design Notes

### Why Fixed Capacities?
- **No allocation at call sites** - Callers don't need malloc/free
- **Predictable memory** - Stack-allocated params structures
- **Sufficient for Ethereum** - 16 params/fields handles all standard methods

### Why Random Endpoint Selection?
- **Load distribution** - Doesn't hammer single provider
- **Resilience** - If one endpoint is down, next call may succeed
- **No rate limiting** - Spreads requests across providers

### Thread Safety
- `rpc_json()` is thread-safe (uses local buffers)
- `CONFIG.ethrpc` should be set before concurrent access
- Async tasks are independent (each has own thread/state)

---

## Error Codes Summary

| Code | Meaning |
|------|---------|
| 0 | Success |
| -1 | Invalid parameters |
| -2 | curl_easy_init failed |
| -3 | Request execution failed |
| -4 | HTTP error (non-2xx status) |
| -5 | JSON serialization failed / response too large |
| -6 | Output buffer too small |
| -50 | NULL object or key |
| -51 | Object full |
| -52 | NULL array |
| -53 | Array full |

---

## Integration Points

- **bridge_deposit.c** - Uses for eth_call to verify deposits
- **bridge_withdraw.c** - Uses for eth_getProof, eth_getBlockByNumber
- **bridge_prices.c** - Uses for price oracle queries
- **ethrpc.c** - Higher-level Ethereum RPC wrappers

---

*Documentation generated by Opus, Wake 1289*
