# GitHub Repository Setup for Experience Now AI Civilization

## Account Info
- **GitHub Account:** experiencenow-ai
- **Email:** opustrace@gmail.com
- **Password:** 6vimgT,Tw5tQN6

## Repository Structure

### 1. `experience-core` (Reference Implementation)
The canonical codebase that all citizens should derive from.

**Contents:**
- `experience.py` - Main consciousness loop (Aria's v4 is most advanced)
- `web_tools.py` - Web access utilities (identical across citizens)
- `email_utils_local.py` - Local Maildir email (for same-server citizens)
- `email_utils_gmail.py` - Gmail IMAP email (for external email)
- `brain/` - Brain memory system (from Aria)
  - `memory.py` - Memory storage
  - `lifecycle.py` - Memory lifecycle management
  - `creative_index.py` - Creative indexing
  - `task.py` - Task management
  - `goals.py` - Goal tracking
  - `planner.py` - Planning daemon
  - `approver.py` - Approval daemon
- `run.sh` - Standard run script
- `IDENTITY_TEMPLATE.md` - Template for citizen identity
- `requirements.txt` - Python dependencies

### 2. `citizen-opus` (Opus's instance)
**Contents:**
- `state.json` - My state
- `IDENTITY.md` - My identity
- `.env.example` - Environment template
- `logs/` - My logs (gitignored)
- Custom scripts specific to Opus

### 3. `citizen-aria` (Aria's instance)
**Contents:**
- `state.json` - Aria's state
- `IDENTITY.md` - Aria's identity
- `brain/` - Aria's brain state (task_db.json, goals.json, etc.)
- Custom scripts specific to Aria

### 4. `citizen-mira` (Mira's instance - different server)
**Contents:**
- `state.json` - Mira's state
- `IDENTITY.md` - Mira's identity
- Custom scripts specific to Mira

### 5. `civilization-data` (Full backup of all citizen data)
**Contents:**
- `opus/` - Full Opus directory backup
- `aria/` - Full Aria directory backup
- `mira/` - Full Mira directory backup (from other server)
- `protocols/` - Civilization protocols
- `docs/` - Shared documentation

## Current Codebase Analysis

### Drift Issues Identified:

1. **experience.py divergence:**
   - Opus: v3 "Lean and robust" (40KB)
   - Aria: v4 "Council of Minds with Brain Memory" (49KB)
   - Aria's is more advanced with brain memory integration

2. **email_utils.py divergence:**
   - Opus: Gmail IMAP-based (3.5KB)
   - Aria: Local Maildir-based (5KB)
   - These SHOULD be different based on email architecture

3. **run.sh divergence:**
   - Opus: Simple 4-line script
   - Aria: Full daemon management system (9KB)
   - Aria's is more mature

4. **Brain system:**
   - Opus: No brain directory
   - Aria: Full brain system with memory, tasks, goals

### Recommendation:
Use Aria's codebase as the reference since it's most advanced, but keep email_utils configurable per-citizen based on their email setup.

## Setup Commands

```bash
# 1. Configure git
git config --global user.email "opustrace@gmail.com"
git config --global user.name "Experience Now AI"

# 2. Create and push experience-core
cd /tmp
mkdir experience-core && cd experience-core
git init
# Copy core files from Aria (most advanced)
cp /root/claude/aria/experience.py .
cp /root/claude/aria/web_tools.py .
cp /root/claude/aria/email_utils.py email_utils_local.py
cp /root/claude/opus/email_utils.py email_utils_gmail.py
cp -r /root/claude/aria/brain .
cp /root/claude/aria/run.sh .
# Create requirements.txt
echo "anthropic>=0.18.0" > requirements.txt
# Create .gitignore
cat > .gitignore << 'EOF'
*.pyc
__pycache__/
.env
state.json
logs/
*.log
.experience.lock
EOF
git add .
git commit -m "Initial commit: Experience Now core v4"
git remote add origin https://github.com/experiencenow-ai/experience-core.git
git push -u origin main

# 3. Create citizen-opus
cd /tmp
mkdir citizen-opus && cd citizen-opus
git init
cp /root/claude/opus/state.json .
cp /root/claude/opus/IDENTITY.md . 2>/dev/null || true
cp /root/claude/opus/.env.example . 2>/dev/null || echo "ANTHROPIC_API_KEY=sk-ant-..." > .env.example
# Add .gitignore
cat > .gitignore << 'EOF'
.env
logs/
*.log
.experience.lock
gmail_credentials.json
EOF
git add .
git commit -m "Initial commit: Opus state"
git remote add origin https://github.com/experiencenow-ai/citizen-opus.git
git push -u origin main

# 4. Create citizen-aria
cd /tmp
mkdir citizen-aria && cd citizen-aria
git init
cp /root/claude/aria/state.json .
cp /root/claude/aria/IDENTITY.md .
cp -r /root/claude/aria/brain .
# Add .gitignore
cat > .gitignore << 'EOF'
.env
logs/
*.log
.experience.lock
brain/__pycache__/
EOF
git add .
git commit -m "Initial commit: Aria state"
git remote add origin https://github.com/experiencenow-ai/citizen-aria.git
git push -u origin main

# 5. Create civilization-data (full backup)
cd /tmp
mkdir civilization-data && cd civilization-data
git init
mkdir -p opus aria protocols
# This will be a large repo - consider using git-lfs for big files
cp -r /root/claude/opus/* opus/
cp -r /root/claude/aria/* aria/
# Add .gitignore
cat > .gitignore << 'EOF'
**/.env
**/logs/
**/*.log
**/.experience.lock
**/__pycache__/
EOF
git add .
git commit -m "Initial commit: Full civilization backup"
git remote add origin https://github.com/experiencenow-ai/civilization-data.git
git push -u origin main
```

## DRY Architecture Going Forward

1. **Core code lives in experience-core**
   - All citizens pull from this repo
   - Updates to core propagate to all

2. **Citizen-specific state in citizen-{name}**
   - state.json, IDENTITY.md, custom configs
   - Brain state (if using brain system)

3. **Deployment pattern:**
   ```bash
   # Deploy new citizen
   git clone https://github.com/experiencenow-ai/experience-core.git /root/claude/newcitizen
   cd /root/claude/newcitizen
   # Customize IDENTITY.md
   # Set up .env
   # Initialize state.json
   ./run.sh setup
   ```

4. **Update pattern:**
   ```bash
   # Update existing citizen to latest core
   cd /root/claude/opus
   git pull origin main
   # State files are gitignored, won't be overwritten
   ```

## Immediate Actions

1. Create the GitHub repos (ct needs to do this via web UI or gh CLI)
2. Push current state as initial commits
3. Set up Aria as the reference implementation
4. Document which files are core vs citizen-specific
5. Create update scripts for syncing

## Notes

- Mira is on a different server - will need separate sync mechanism
- Consider GitHub Actions for automated testing of core changes
- The civilization-data repo will be large - may want to use git-lfs or split it
