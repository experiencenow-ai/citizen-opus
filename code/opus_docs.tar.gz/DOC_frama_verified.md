# Tockchain Frama-C Verified Functions Documentation

**File:** `frama_verified.c` (1448 lines)  
**Header:** `frama_verified.h`  
**Author:** ct  
**Documented by:** Opus (Wake 1290)  
**Last Updated:** 2026-01-13

---

## Overview

`frama_verified.c` contains **formally verified pure functions** that form the mathematical and logical core of Tockchain. These functions have been verified using Frama-C with the WP (Weakest Precondition) plugin.

**Verification Status:** 950/955 goals proved (99.5%)

### Why Formal Verification?

Formal verification mathematically proves that code behaves correctly for ALL possible inputs. This is critical for:
- Financial calculations (no overflow, correct rounding)
- Security-critical operations (constant-time comparisons)
- Consensus logic (deterministic behavior)

### How to Verify

```bash
frama-c -wp -wp-rte frama_verified.c
```

The ACSL annotations in `/*@ ... */` comments are ignored by GCC but processed by Frama-C.

---

## Function Categories

### 1. Safe Arithmetic (128-bit)

These functions use `__int128` for intermediate calculations to prevent overflow:

```c
int64_t safe_mul_then_div(int64_t a, int64_t b, int64_t c, int64_t div0_err);
```
**Purpose:** Compute `(a * b) / c` safely with rounding.
- Returns `div0_err` if `c == 0`
- Returns 0 if `a == 0` or `b == 0`
- Uses 128-bit intermediate to prevent overflow
- Clamps result to `MAXCOINSUPPLY`

```c
int64_t ufc_mul_div_floor(int64_t a, int64_t b, int64_t c);
int64_t ufc_mul_div_ceil(int64_t a, int64_t b, int64_t c);
```
**Purpose:** Floor/ceiling division with overflow protection.

```c
int64_t ufc_calc_premium_vusd(int32_t vusd_to_other, int64_t amount_in, 
                               int64_t amount_out, int64_t ufc_px);
```
**Purpose:** Calculate premium in VUSD for swap operations.

**Note:** Frama-C doesn't support `__int128`, so these have stub implementations for verification. The real implementations are trusted primitives.

---

### 2. UFC (Unified Finance Core) Functions

#### Price Conversions

```c
int64_t ufc_other_to_vusd(int64_t amount_other, int64_t price_sat);
```
**Purpose:** Convert other asset to VUSD equivalent.
**Formula:** `(amount_other * price_sat) / VUSD_SATS_PER_UNIT`

```c
int64_t ufc_vusd_to_other(int64_t amount_vusd, int64_t price_sat);
```
**Purpose:** Convert VUSD to other asset equivalent.
**Formula:** `(amount_vusd * VUSD_SATS_PER_UNIT) / price_sat`

#### Pool Operations

```c
void pool_effective_balances_pure(int64_t pool_vusd, int64_t pool_other,
                                   int64_t *eff_vusd_ptr, int64_t *eff_other_ptr);
```
**Purpose:** Calculate effective pool balances (may differ from raw balances due to fees/reserves).

```c
int64_t calc_pool_price_pure(int64_t pool_vusd, int64_t pool_other);
```
**Purpose:** Calculate pool price from balances.
**Returns:** Price in satoshis, or 0 if invalid inputs.

#### Swap Calculations

```c
int64_t ufc_swap_v2o_output(int64_t pool_vusd, int64_t pool_other, int64_t amount_in);
```
**Purpose:** Calculate output for VUSD → Other swap.
**Formula:** Constant product AMM: `(pool_other * amount_in) / (pool_vusd + amount_in)`

```c
int64_t ufc_swap_o2v_output(int64_t pool_vusd, int64_t pool_other, int64_t amount_in);
```
**Purpose:** Calculate output for Other → VUSD swap.

#### Rebalancing

```c
int32_t ufc_split_rebalancing_tranche_pure(
    int32_t is_vusd_to_other,
    int64_t amount_in,
    int64_t target_end_pct_bps,
    int64_t start_X, int64_t start_Y,
    int64_t ufc_px,
    int64_t *rebalance_in_out,
    int64_t *hurtful_in_out
);
```
**Purpose:** Split a swap into rebalancing (beneficial) and hurtful (price-moving) tranches.

#### Price Clamping

```c
int64_t ufc_clamp_vs_prev(int64_t prev_price, int64_t candidate_price, 
                           int32_t *out_clamp_bps);
```
**Purpose:** Clamp price movement to prevent manipulation.
**Returns:** Clamped price, outputs clamp amount in basis points.

#### Age Weighting

```c
int64_t ufc_age_weight(int32_t tocklag, int64_t age_sec, int64_t half_life_sec);
```
**Purpose:** Calculate time-decay weight for price observations.
**Uses:** Exponential decay with configurable half-life.

---

### 3. Ledger Functions

```c
uint32_t ledger_calc_addr_limit_pure(uint32_t bigprime, int32_t hashtable_limit);
```
**Purpose:** Calculate address limit for hash table sizing.

```c
int32_t needs_bigger_hashtable(int64_t numaddrs, uint32_t bigprime, int32_t trigger_pct);
```
**Purpose:** Determine if hash table needs resizing.

---

### 4. Validation Functions

```c
int32_t is_zero_pubkey(const uint8_t pubkey[PKSIZE]);
```
**Purpose:** Check if public key is all zeros (invalid).

```c
int32_t pubkey_matches(const uint8_t a[PKSIZE], const uint8_t b[PKSIZE]);
```
**Purpose:** Compare two public keys for equality.

```c
int32_t isVUSD_pure(uint16_t aid, uint8_t iscoin);
```
**Purpose:** Check if asset is VUSD.

```c
int32_t asset_is_real(uint16_t aid);
```
**Purpose:** Check if asset ID represents a real (non-synthetic) asset.

```c
int32_t balance_in_valid_range(int64_t balance);
```
**Purpose:** Verify balance is within valid range `[0, MAXCOINSUPPLY]`.

```c
int32_t amount_in_transfer_range(int64_t amount);
```
**Purpose:** Verify transfer amount is valid (positive, within limits).

```c
int32_t lock_allows_transfer(uint32_t lockutime, uint32_t current_utime);
```
**Purpose:** Check if time lock has expired.

---

### 5. Safe Arithmetic Helpers

```c
int32_t ufc_tx_plan_safe_add(int64_t a, int64_t b, int64_t *out);
```
**Purpose:** Safe addition with overflow detection.
**Returns:** 0 on success, -1 on overflow.

```c
int32_t compute_final_balance_pure(int64_t starting_balance, int64_t pos_sum, 
                                    int64_t neg_sum, int32_t is_real, 
                                    int64_t *final_out);
```
**Purpose:** Compute final balance after credits and debits.
**Handles:** Overflow, underflow, negative balance (for synthetics).

```c
int64_t safe_div_int64(int64_t num, int64_t denom, int err_code);
```
**Purpose:** Safe division with error handling.

---

### 6. Memory Safety Functions

```c
int32_t compute_addr_safe(uint64_t base, int16_t off, uintptr_t *out);
```
**Purpose:** Safely compute address with offset, checking for overflow.

```c
int32_t ptr_in_range(uintptr_t addr, uintptr_t n, uintptr_t base, uintptr_t end);
```
**Purpose:** Verify pointer access is within valid range.

```c
int32_t safe_mul_size(uint32_t a, uint32_t b, uintptr_t *out);
```
**Purpose:** Safe size multiplication with overflow check.

---

### 7. Helper Functions (Pure Math)

```c
int64_t helper_abs_s64(int64_t x);      // Absolute value
int64_t helper_sign_s64(int64_t x);     // Sign (-1, 0, 1)
int64_t helper_max_s64(int64_t a, int64_t b);  // Maximum
int64_t helper_min_s64(int64_t a, int64_t b);  // Minimum
uint64_t helper_max_u64(uint64_t a, uint64_t b);
uint64_t helper_min_u64(uint64_t a, uint64_t b);
```

```c
uint64_t helper_rotl64(uint64_t v, uint32_t n);  // Rotate left
uint64_t helper_rotr64(uint64_t v, uint32_t n);  // Rotate right
```

```c
uint64_t helper_sub_sat_u64(uint64_t a, uint64_t b);  // Saturating subtraction
int64_t helper_clamp_s64(int64_t x, int64_t lo, int64_t hi);  // Clamp signed
uint64_t helper_clamp_u64(uint64_t x, uint64_t lo, uint64_t hi);  // Clamp unsigned
```

```c
void helper_z_decode(uint64_t z, uint32_t *out_x, uint32_t *out_y);
```
**Purpose:** Zigzag decode a packed value into two components.

---

### 8. Gas Functions

```c
int32_t gas_check(int64_t gas, int64_t cost);
```
**Purpose:** Check if enough gas remains.
**Returns:** 1 if sufficient, 0 if not.

```c
int64_t backward_jump_gas(int64_t base_gas, int32_t jump_dist);
```
**Purpose:** Calculate extra gas for backward jumps (loop protection).
**Formula:** Increases with jump distance to prevent infinite loops.

---

### 9. Security Functions

```c
int32_t pylon_const_time_eq(const uint8_t *a, const uint8_t *b);
```
**Purpose:** Constant-time comparison of 32-byte values.
**Security:** Prevents timing attacks by always comparing all bytes.

```c
int32_t helper_bloom_check(const uint8_t *filter, uint32_t bits, const uint8_t *hash);
```
**Purpose:** Check if hash is in bloom filter.

---

### 10. Consensus Functions

```c
int32_t calc_quorum(int32_t numgenerators);
```
**Purpose:** Calculate quorum threshold for consensus.
**Formula:** `(numgenerators * 2 / 3) + 1` (2/3 + 1 majority)

```c
int64_t calc_price_pure(int64_t vusd, int64_t other);
```
**Purpose:** Calculate price from pool balances for consensus.

---

### 11. Stale Price Handling

```c
int32_t ufc_stale_move_bps_from_lag(int32_t lag_sec);
```
**Purpose:** Calculate allowed price movement based on staleness.
**Logic:** Older prices allow larger movements (more uncertainty).

---

## ACSL Annotation Examples

### Simple Postcondition

```c
/*@
 assigns \nothing;
 ensures \result >= 0 || \result == div0_err;
 */
int64_t safe_mul_then_div(int64_t a, int64_t b, int64_t c, int64_t div0_err);
```

### Range Constraints

```c
/*@
 requires 0 <= pool_vusd <= MAXCOINSUPPLY;
 requires 0 <= pool_other <= MAXCOINSUPPLY;
 assigns *eff_vusd_ptr, *eff_other_ptr;
 ensures *eff_vusd_ptr >= 0;
 ensures *eff_other_ptr >= 0;
 */
void pool_effective_balances_pure(...);
```

### Memory Safety

```c
/*@
 requires \valid(out);
 assigns *out;
 ensures \result == 0 ==> *out == a + b;
 ensures \result == -1 ==> overflow_occurred;
 */
int32_t ufc_tx_plan_safe_add(int64_t a, int64_t b, int64_t *out);
```

---

## Design Principles

1. **Pure Functions:** No side effects, deterministic output
2. **Explicit Error Handling:** Return codes or special values
3. **Overflow Protection:** Use 128-bit intermediates or explicit checks
4. **Defensive Programming:** Validate all inputs
5. **Constant-Time:** Security-critical comparisons avoid timing leaks

---

## Integration

These functions are called from:
- `UFC/ufc.c` - Swap and pool operations
- `DF/vbpf.c` - VM helper functions
- `validator/validator.c` - Transaction validation
- `ledger.c` - Balance calculations

---

## Related Files

- `frama_verified.h` - Header with declarations
- `frama_proofs.txt` - Frama-C proof output (1.8MB)
- `frama_log.txt` - Verification log
- `DF/df_sdk.h` - SDK using these functions
