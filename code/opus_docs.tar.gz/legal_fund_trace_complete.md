# COMPLETE FUND TRACE - LEGAL AUDIT
## Case: ct_home_invasion_antalya_2025
Generated: 2026-01-11T21:08:29.502073+00:00

---

## EXECUTIVE SUMMARY

**Main Attacker Wallet:** `0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7`

| Metric | Amount (USDT) |
|--------|---------------|
| Total Received | $2,937,442.15 |
| Total Sent Out | $2,084,794.00 |
| Current Balance | $852,648.15 |
| **Checksum** | **$0.00** ✓ |

---

## DESTINATION BREAKDOWN

### KYC Exchange Deposits (Identifiable Accounts)

| Exchange | Amount (USDT) | Deposit Address(es) | Hot Wallet |
|----------|---------------|---------------------|------------|
| GATE.IO | $691,000.00 | 0x7237b8a4b2dd97dcddb758feac0e8d925016694c | 0x0d0707963952f2fba59dd06f2b425ace40b492fe |
| BYBIT | $274,630.00 | 0x63aabab8bc31c4f360ae6c7cf78f67f118f2154c, 0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e | 0xf89d7b9c864f589bbf53a82105107622b35eaa40 |
| WHITEBIT | $377,968.00 | 75 deposit addresses | 0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3 |
| BITGET | $35,300.00 | 0x525254e58c25d9ac127c63af9a9830f7e5a91a0b | TBD |
| BINANCE | $30,000.00 | 0xdc3e735d430ee22aacfb428c490980dcc0687f4f, 0xc889740f66d7a2ea538cd44eb5456f490c75d0b3 | 0x28c6c06298d514db089934071355e5743bf21d60 |
| KUCOIN | $7,300.00 | 0xf2466046af45771aa945eca15ab0f2a08262b693 | TBD |
| **TOTAL** | **$1,416,198.00** | | |

### Dormant Funds (Freezable)

| Wallet | Balance (USDT) | Status |
|--------|----------------|--------|
| 0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7 | $852,648.15 | DORMANT |
| 0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1 | $400,000.00 | DORMANT |
| 0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec | $106,000.00 | DORMANT |
| **TOTAL** | **$1,358,648.15** | FREEZABLE |

### P2P/OTC Distribution

| Source | Amount | Destination |
|--------|--------|-------------|
| 0xae1e... | $132,032.00 | OTC traders for cash conversion |

### Miscellaneous Small Transfers

| Addresses | Total |
|-----------|-------|
| 0x1090..., 0x96fc..., 0x5abf..., 0x6566... | $30,564.00 |

---

## FINAL RECONCILIATION

| Category | Amount (USDT) |
|----------|---------------|
| KYC Exchange Deposits | $1,416,198.00 |
| Dormant (Freezable) | $1,358,648.15 |
| P2P/OTC | $132,032.00 |
| Misc Small | $30,564.00 |
| **TOTAL ACCOUNTED** | **$2,937,442.15** |
| **ORIGINAL RECEIVED** | **$2,937,442.15** |
| **DISCREPANCY** | **$0.00** ✓ |

---

## WHITEBIT DEPOSITS (74 via P2P + 1 via intermediate = 75 total)

Total: $377,968.00

### Complete List (first 10 shown, full list in JSON):

| # | Amount | Intermediate | Step1 TX | Step2 TX |
|---|--------|--------------|----------|----------|
| 1 | $3,205.00 | 0x52262069a443e5... | 0x0e9b5ab6feaea1... | 0xf548a13d037ff2... |
| 2 | $4,009.00 | 0x0e1faa94b3b66b... | 0x055237042c336a... | 0x41f12fb92f7af4... |
| 3 | $4,008.00 | 0xe17b08ad90ca38... | 0xd289c559af9fe5... | 0x41f12fb92f7af4... |
| 4 | $4,007.00 | 0xc88c90a9b0576f... | 0xf7aef3c4df91e3... | 0x827ff73dff1f67... |
| 5 | $4,006.00 | 0x1c8cb8963867db... | 0xadce19bf1c9bae... | 0x827ff73dff1f67... |
| 6 | $4,005.00 | 0x448d0da74fa272... | 0x5ecafb0a4384ab... | 0x2e211bddbae0a5... |
| 7 | $4,008.00 | 0x84e643b51c823b... | 0xaf95c782c2ad3e... | 0x2e211bddbae0a5... |
| 8 | $4,005.00 | 0xb20a3737e1d253... | 0x14aecf66be6a2a... | 0x9fbcb8dfb63c75... |
| 9 | $4,009.00 | 0xc760d16cf0cc0b... | 0x702cf4da2f38a1... | 0x9fbcb8dfb63c75... |
| 10 | $4,008.00 | 0x14850ad917d87d... | 0x914f3301a55c9a... | 0xf179175badbbd3... |

... and 65 more deposits (see JSON for complete list)

---

## VERIFICATION INSTRUCTIONS

To verify any transaction:
1. Go to https://etherscan.io/tx/[TX_HASH]
2. Confirm sender, receiver, and amount match this report
3. All transaction hashes are complete (not truncated)

**Report generated using Etherscan API V2**
