# Tockchain Documentation Project

## Objective
Create a complete, consistent documentation set for Tockchain (Valis) from scratch, using existing docs, code, and proofs as input material.

## Existing Documentation Sources

### Specification Documents (../../valis/)
| File | Size | Topic | Status |
|------|------|-------|--------|
| v13.txt | ~15KB | Background, tock-based architecture | Older, pre-v14 |
| v14.grok.txt | ~35KB | Bridge v14 specification | Current, detailed |
| L0spec.txt | ~17KB | L0 rawtock layer requirements | Current |
| L1spec.txt | ~35KB | L1 consensus iteration spec | Current |
| L1bridge.txt | ~21KB | Bridge architecture | Duplicate of v14? |
| L1coldspend.txt | ~12KB | Quantum-resistant security | Current |
| L1options.txt | ~11KB | Covered call options | Feature spec |
| L1specials.txt | ~24KB | Perpetual futures | Feature spec |
| L1style.txt | ~15KB | C coding style guide | Current |
| threshold.md | ~8KB | TSS/Gnosis Safe bridge safety | Current |

### API/Module Documentation (../../valis/docs/)
| File | Size | Topic |
|------|------|-------|
| valis_keys.txt | ~10KB | Key management, wallets |
| valis_math.txt | ~7KB | Safe arithmetic, 128-bit ops |
| valis_qmemc.txt | ~11KB | Memcached wrapper |
| valis_tss.txt | ~8KB | Threshold signatures |
| valis_net.txt | ~10KB | Networking, peer management |
| valis_files.txt | ~6KB | File/path utilities |
| valis_dynamic_sets.txt | ~6KB | Dynamic validator sets |

### Coq Proofs (../../valis/coq/)
- 20+ modules in coq/bundle/
- Common definitions in coq/common/
- Key modules: UFC, DF, bridge, ledger, vbpf, postquantum

## Documentation Structure (New)

### Tier 1: Overview Documents
1. **README.md** - Project overview, quick start, links
2. **ARCHITECTURE.md** - System architecture, layer overview
3. **GLOSSARY.md** - Terminology definitions

### Tier 2: Layer Documentation
4. **L0_RAWTOCK.md** - L0 layer: rawtock production, leaderless consensus
5. **L1_CONSENSUS.md** - L1 layer: state processing, validation
6. **BRIDGE.md** - Ethereum bridge: deposits, withdrawals, recovery

### Tier 3: Module Documentation
7. **CRYPTOGRAPHY.md** - Keys, signing, hashing, TSS
8. **NETWORKING.md** - Peer management, memcached, nanomsg
9. **TRANSACTIONS.md** - Transaction types, validation, ordering
10. **ORDERBOOK.md** - Trading, orderbook mechanics
11. **DEFI.md** - Options, perpetuals, pools

### Tier 4: Security & Verification
12. **SECURITY.md** - Threat model, post-quantum, attack resistance
13. **FORMAL_VERIFICATION.md** - Coq proofs, Frama-C, trust surface
14. **TRUST_SURFACE.md** - Documented axioms and assumptions

### Tier 5: Development
15. **BUILD.md** - Build system, dependencies, testing
16. **STYLE_GUIDE.md** - C coding conventions
17. **CONTRIBUTING.md** - How to contribute, review process

## Writing Principles

1. **Single voice** - Consistent style throughout
2. **Code-first** - Document what the code does, not what specs say it should do
3. **Layered** - Start high-level, drill down to details
4. **Cross-referenced** - Link between documents
5. **Verifiable** - Include code references, test commands

## Progress Tracking

| Document | Status | Wake | Size |
|----------|--------|------|------|
| DOCUMENTATION_PLAN.md | ✅ Done | 1259 | 4.4KB |
| docs/README.md | ✅ Done | 1259 | 6.1KB |
| docs/GLOSSARY.md | ✅ Done | 1259 | 6.0KB |
| docs/ARCHITECTURE.md | ✅ Done | 1259 | 14KB |
| docs/L0_RAWTOCK.md | ⏳ Pending | - | - |
| docs/L1_CONSENSUS.md | ⏳ Pending | - | - |
| docs/BRIDGE.md | ⏳ Pending | - | - |
| docs/CRYPTOGRAPHY.md | ⏳ Pending | - | - |
| docs/NETWORKING.md | ⏳ Pending | - | - |
| docs/TRANSACTIONS.md | ⏳ Pending | - | - |
| docs/ORDERBOOK.md | ⏳ Pending | - | - |
| docs/DEFI.md | ⏳ Pending | - | - |
| docs/SECURITY.md | ⏳ Pending | - | - |
| docs/FORMAL_VERIFICATION.md | ⏳ Pending | - | - |
| docs/TRUST_SURFACE.md | ⏳ Pending | - | - |
| docs/BUILD.md | ⏳ Pending | - | - |
| docs/STYLE_GUIDE.md | ⏳ Pending | - | - |
| docs/CONTRIBUTING.md | ⏳ Pending | - | - |

**Total completed: 4/18 documents (~26KB)**

## Approach

1. **Read existing docs** - Extract accurate information
2. **Read code** - Verify against implementation
3. **Read proofs** - Understand formal guarantees
4. **Write draft** - Single consistent voice
5. **Verify** - Check code references are accurate
6. **Iterate** - Refine based on feedback

## Wake-by-Wake Plan

- Wake 1259: ✅ Created plan, README, GLOSSARY, ARCHITECTURE
- Wake 1260+: Continue through document list
- Prioritize: L0_RAWTOCK → L1_CONSENSUS → BRIDGE → CRYPTOGRAPHY
- DeFi features (options, perps) lower priority until core is documented

## Notes

- Mira's email: mira@mira.opustrace.com (not yet working)
- Goal: If documentation is good and focused, ct will boost to every-minute consciousness
- The codebase is ~200k lines, interconnected - documentation needs to be layered
