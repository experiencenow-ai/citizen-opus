# Tockchain/Valis Source Code Map

**Generated:** Wake 1272  
**Based on:** tests/gen3/Makefile build targets

This document maps the actual source files that get compiled when building Tockchain.

---

## Build Targets

The Makefile in `tests/gen3/` builds four executables:

| Target | Purpose | Main Source |
|--------|---------|-------------|
| `test` | Main test executable | tests.c |
| `wsdprog` | WebSocket daemon | websocketd.c |
| `txblast` | Transaction load testing | txblast.c |
| `sendtx` | Transaction sender utility | sendtx.c |

---

## Source File Organization

### Core Headers

| File | Purpose | Lines |
|------|---------|-------|
| `_valis.h` | Project-wide defines, constants, system includes | ~200 |
| `gen3.h` | Generator/consensus types and defines | ~700 |
| `validator.h` | Validator state, L1 state, transaction types | ~400 |
| `ledger.h` | Asset IDs, synthetic assets, transaction handlers | ~200 |
| `ufc.h` | UFC (Unified Fair Curve) parameters and types | ~300 |
| `dataflow.h` | eBPF-based smart contract system | ~200 |
| `bridge.h` | Ethereum bridge types and constants | ~200 |

### Generator (`generator/`)

The consensus and block generation system.

| File | Purpose | Lines |
|------|---------|-------|
| `gen3.c` | Main generator logic, attack mitigations | ~1000 |
| `gen3_chain.c` | Chain management | ~800 |
| `gen3_metrics.c` | Performance metrics collection | ~1500 |
| `gen3_needbits.c` | Bit synchronization | ~700 |
| `gen3_net.c` | Network layer for consensus | ~800 |
| `gen3_nodechange.c` | Validator set changes | ~900 |
| `gen3_rawtock.c` | Raw tock (block) handling | ~750 |
| `gen3_ssd.c` | State storage | ~1800 |
| `gen3_utils.c` | Generator utilities | ~350 |
| `gen3_vans.c` | VAN (Virtual Asset Network) handling | ~1000 |
| `gen3_vote.c` | Voting/consensus protocol | ~1400 |

### Validator (`validator/`)

Transaction validation and ledger state.

| File | Purpose | Lines |
|------|---------|-------|
| `validator.c` | Main validator logic | ~1100 |
| `ledger_assets.c` | Asset management | ~1400 |
| `ledger_atomic.c` | Atomic swaps | ~850 |
| `ledger_erc20.c` | ERC20 token handling | ~1350 |
| `ledger_hourly.c` | Hourly state snapshots | ~1100 |
| `ledger_pylon7.c` | Pylon (liquidity) system | ~950 |
| `ledger_vhandlers.c` | Transaction handlers | ~1400 |
| `ledger_vtrade.c` | Trading logic | ~700 |

### UFC - Unified Fair Curve (`UFC/`)

The AMM and orderbook system.

| File | Purpose | Lines |
|------|---------|-------|
| `ufc.c` | UFC core | ~330 |
| `ufc_orderbook.c` | Orderbook matching | ~1070 |
| `ufc_oob.c` | Out-of-band orders | ~730 |
| `ufc_planner.c` | Trade planning | ~760 |
| `ufc_pool.c` | Liquidity pools | ~370 |
| `ufc_scan.c` | Pool scanning | ~400 |
| `ufc_swap.c` | Swap execution | ~1220 |
| `ufc_utils.c` | UFC utilities | ~650 |

### Dataflow (`DF/`)

eBPF-based smart contract system.

| File | Purpose | Lines |
|------|---------|-------|
| `dataflow.c` | Core dataflow logic | ~840 |
| `dataflow_api.c` | API functions | ~540 |
| `dataflow_batch.c` | Batch processing | ~1490 |
| `dataflow_cache.c` | State caching | ~1100 |
| `dataflow_frontier.c` | Frontier tracking | ~500 |
| `dataflow_trigger.c` | Trigger system | ~590 |
| `vbpf.c` | Virtual BPF VM | ~1940 |
| `LOAN.c` | Lending module | ~670 |
| `MM.c` | Market maker module | ~670 |
| `PERP.c` | Perpetuals module | ~620 |

### Bridge (`bridge/`)

Ethereum bridge for deposits/withdrawals.

| File | Purpose | Lines |
|------|---------|-------|
| `bridge.c` | Bridge core | ~280 |
| `bridge_abi.c` | ABI encoding | ~850 |
| `bridge_deposit.c` | Deposit handling | ~1200 |
| `bridge_mpt.c` | Merkle Patricia Trie | ~650 |
| `bridge_mptjson.c` | MPT JSON parsing | ~550 |
| `bridge_prices.c` | Price feeds | ~900 |
| `bridge_rlp.c` | RLP encoding | ~780 |
| `bridge_rpc.c` | Ethereum RPC | ~600 |
| `bridge_utils.c` | Bridge utilities | ~250 |
| `bridge_withdraw.c` | Withdrawal handling | ~1550 |
| `ethrpc.c` | Ethereum RPC client | ~1900 |
| `json.c` | JSON parsing | ~850 |

### Utils (`utils/`)

Shared utilities.

| File | Purpose | Lines |
|------|---------|-------|
| `valis_config.c` | Configuration | ~140 |
| `valis_files.c` | File I/O | ~500 |
| `valis_hash.c` | Hashing (Keccak, etc.) | ~1100 |
| `valis_keys.c` | Key management | ~580 |
| `valis_math.c` | Math utilities | ~1000 |
| `valis_net_MT.c` | Multi-threaded networking | ~750 |
| `valis_shared.c` | Shared state | ~2000 |
| `yyjson.c` | JSON library | ~11000 |

### Networking (`netlibs/`)

| File | Purpose | Lines |
|------|---------|-------|
| `valis_messaging.c` | Message passing | ~410 |
| `nng_shim.c` | NNG library shim | ~630 |

---

## Formal Verification

| File | Purpose | Status |
|------|---------|--------|
| `frama_verified.c` | Frama-C verified pure functions | 950/955 goals (99.5%) |
| `frama_verified.h` | Header for verified functions | - |

Verified functions include:
- `safe_mul_then_div` - Overflow-safe multiplication/division
- `ufc_mul_div_floor/ceil` - UFC price calculations
- Various UFC pure functions from `ufc_utils.c`, `ufc_swap.c`

---

## Tests (`tests/`)

| File | Purpose | Lines |
|------|---------|-------|
| `ufc_test.c` | UFC unit tests | ~2900 |
| `units_*.c` | Various unit test files | ~3000+ each |
| `bridgetests.c` | Bridge tests | ~4500 |
| `vbpf_test.c` | eBPF VM tests | ~3800 |

---

## Key Constants

From `_valis.h`:
```c
#define PKSIZE 20                    // Public key size (20 bytes = Ethereum address)
#define SATOSHIS ((int64_t)100000000) // 1 VUSD = 100M satoshis
#define RICHLISTSIZE 5000            // Rich list tracking
#define SLAB_SIZE (1024*1024*64)     // 64MB memory slabs
#define MAX_TX_PER_UTIME (SLAB_SIZE / 80)  // ~800K tx/sec capacity
```

From `ufc.h`:
```c
#define BPS_DENOM 10000              // Basis points denominator
#define UFC_MAX_MOVE_BPS 75          // Max price move per tock (0.75%)
#define UFC_OOB_TVL_MAX_DEPL_BPS 250 // Max TVL depletion (2.5%)
```

---

## Architecture Notes

### Consensus Flow
1. `gen3_vans.c` - Collect transactions into VANs
2. `gen3_vote.c` - Run voting protocol
3. `gen3_rawtock.c` - Create raw tock
4. `validator.c` - Validate and apply to state
5. `gen3_ssd.c` - Persist state

### Trading Flow
1. `ufc_orderbook.c` - Match orders
2. `ufc_swap.c` - Execute swaps
3. `ledger_vtrade.c` - Update balances
4. `ufc_pool.c` - Update pool state

### Bridge Flow
1. `bridge_deposit.c` - Monitor Ethereum deposits
2. `bridge_mpt.c` - Verify Merkle proofs
3. `bridge_withdraw.c` - Process withdrawals
4. `ethrpc.c` - Communicate with Ethereum

### Dataflow (Smart Contracts)
1. `dataflow_batch.c` - Batch contract calls
2. `vbpf.c` - Execute eBPF bytecode
3. `dataflow_trigger.c` - Handle triggers
4. `LOAN.c`, `MM.c`, `PERP.c` - DeFi modules

---

## Total Codebase Size

~67,000 lines of C code across core modules (excluding tests and JSON library).
