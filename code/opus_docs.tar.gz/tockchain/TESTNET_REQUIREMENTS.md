# Tockchain Testnet Launch Requirements

## Current Status

Based on analysis of the codebase and Coq proofs (pass61):
- **1500+ unit tests passing**
- **20k+ lines of Coq proofs** (mostly without Admitted)
- **Frama-C verification** for C code safety
- **Testnet phase** - nearing mainnet release candidate for non-bridge features

## Categories of Remaining Work

### 1. Coq Proof Completion (from TOP_20.md)

Total estimated effort: ~9.5 units

| Priority | Item | Effort | Description |
|----------|------|--------|-------------|
| 1 | Stride schedule permutation proof | 1.0 | Number theory: prove stride mapping is permutation when gcd(stride, N)=1 |
| 2 | Generator ordering constraints | 1.0 | Connect ordering spec to ledger acceptance constraints |
| 3 | DF parallel batch determinism | 1.5 | Prove parallel DF evaluation = sequential |
| 4 | DF CRV ranking proofs | 0.75 | Close remaining partial proofs |
| 5 | vbpf bounds lemmas | 0.5 | Standardize nat/Z conversions |
| 6 | Orderbook rounding alignment | 0.75 | Align Coq spec with code ceil/floor |
| 7 | EconomicModule rollout | 1.0 | Consolidate economic delta plumbing |
| 8 | Ledger boundedness boundary | 0.5 | Clarify synthetic vs real assets |
| 9 | PQ privileged tx audit | 1.0 | Ensure all privileged ops are PQ-hard |
| 10 | Scope vestiges cleanup | 0.5 | Remove legacy code |

### 2. Axiom/Parameter Inventory

Files with Axioms/Parameters that may need resolution:
- `UFC/UfcSureCap.v` - 22 axioms/parameters
- `UFC/UfcValue.v` - 6
- `UFC/UfcStalePriceError.v` - 4
- `UFC/UfcExecEventBounds.v` - 2
- `UFC/UfcEndOfTock.v` - 2
- `UFC/UfcPremiumAccounting.v` - 1

**Action needed:** Review each axiom - are they:
- Intentional trust assumptions (document in TRUST_SURFACE.md)
- Proofs that need to be completed
- External facts that should be imported

### 3. Testing Gaps

Based on the proofs creating validations, likely testing gaps:

#### Unit Tests Needed
- [ ] Stride ordering edge cases (gcd != 1 scenarios)
- [ ] DF parallel vs sequential equivalence
- [ ] Orderbook rounding boundary conditions
- [ ] Synthetic asset boundedness edge cases
- [ ] PQ-hard authorization paths

#### Integration Tests Needed
- [ ] Full consensus round with all node types
- [ ] Bridge deposit/withdraw cycle
- [ ] Quorum change scenarios
- [ ] Recovery/jumpstart procedures
- [ ] Emergency stop/restart

#### Stress Tests Needed
- [ ] 50k+ TPS sustained load
- [ ] Quorum loss and recovery
- [ ] Network partition scenarios
- [ ] Memcached failure modes

### 4. Feature Completeness

#### Core Features (Status Unknown - Need Verification)
- [ ] L0 rawtock production
- [ ] L1 consensus iteration
- [ ] Leaderless ordering
- [ ] Quorum validation
- [ ] State synchronization

#### Bridge Features
- [ ] Gnosis Safe integration
- [ ] TSS signing
- [ ] Deposit flow
- [ ] Withdrawal flow
- [ ] Emergency recovery
- [ ] Bridgelogs idempotency

#### Security Features
- [ ] Pylon FAST mechanism
- [ ] PQVAULT two-phase
- [ ] Coldspend functionality
- [ ] Emergency stop

### 5. Infrastructure Requirements

#### Network
- [ ] Peer discovery
- [ ] nanomsg configuration
- [ ] memcached cluster setup
- [ ] Ethereum light client integration

#### Monitoring
- [ ] Node health metrics
- [ ] Consensus progress tracking
- [ ] Bridge status dashboard
- [ ] Alert system

#### Operations
- [ ] Node deployment scripts
- [ ] Configuration management
- [ ] Backup/restore procedures
- [ ] Upgrade procedures

### 6. Documentation

- [ ] Node operator guide
- [ ] API documentation
- [ ] Testnet participation guide
- [ ] Security model documentation
- [ ] Emergency procedures

## Recommended Prioritization for Testnet

### Phase 1: Core Functionality (Blocks testnet if missing)
1. Verify L0/L1 consensus works end-to-end
2. Complete stride ordering proof (affects determinism)
3. Verify quorum validation works
4. Basic monitoring/alerting

### Phase 2: Security Hardening
1. PQ privileged tx audit
2. Complete UFC axiom review
3. Integration tests for attack scenarios
4. Emergency stop/restart testing

### Phase 3: Bridge Functionality
1. Gnosis Safe + TSS integration
2. Deposit/withdraw testing
3. Recovery procedure testing
4. Bridgelogs verification

### Phase 4: Performance & Polish
1. 50k TPS stress testing
2. Documentation completion
3. Operator tooling
4. Public testnet launch

## Questions for ct

1. Which features are already working in internal testnet?
2. What's the current node count and configuration?
3. Are there specific testing gaps the proofs revealed?
4. What's the target timeline for public testnet?
5. Is the bridge intended for testnet or mainnet only?
6. What monitoring/alerting exists currently?

## Next Steps

1. **Opus can help with:**
   - Writing additional unit tests
   - Reviewing axioms and documenting trust assumptions
   - Creating integration test scenarios
   - Documentation writing
   - Code review for specific modules

2. **Needs ct input:**
   - Access to run tests locally
   - Current testnet status
   - Priority ordering of remaining work
   - Specific areas where help is most needed
