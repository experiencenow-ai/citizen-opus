# Tockchain/Valis Knowledge Base

## What is Tockchain?

Tockchain (codenamed Valis) is a high-speed blockchain with formal verification, designed to process 50,000+ transactions per second with no transaction fees. The core innovation is the combination of:

1. **Leaderless consensus** - No single node proposes blocks; ordering derived from shared commitments
2. **Formal verification** - 20k+ lines of Coq proofs, Frama-C verification for C code
3. **Post-quantum security** - Pylon mechanism for PQ-safe transactions
4. **Bridge to Ethereum** - Trustless asset transfers via Gnosis Safe + TSS

## Codebase Location

Main repo: `../../valis/`
- ~200k lines of code total
- ~400k lines including headers
- 865 C files
- 20k+ lines of Coq proofs

## Architecture Layers

### L0 - Rawtock Production
- Per-second snapshots of transactions
- Leaderless consensus via `nodetxidshash → vanshash → finalhash` pipeline
- Quorum-validated (>2/3 signatures required)
- Up to ~4000 rollups per rawtock, max 10MB

### L1 - Consensus Layer
- Processes rawtocks into validated state
- Handles quorum detection via memcached + nanomsg
- Supports both full nodes (vonly=0) and validator-only nodes (vonly=1)
- Target: ~5ms/utime (200x realtime) with high cache hits

### Bridge (v14)
- Gnosis Safe (1-of-1) owned by TSS address
- Deposits and withdrawals only (simplified model)
- Users pay actual gas costs
- Two-stage recovery with challenge periods
- Bridgelogs for idempotency (append-only, signed)

## Key Components

### Consensus (`consensus/`, `generator/`)
- `gen3.h` - Main consensus structures
- Leaderless: no single node chooses block ordering
- Stride-based ordering from finalhash

### Transactions (`transactions/`)
- UFC (Unified Fee Controller) - fee handling
- DF (Dynamic Functions) - smart contract-like functionality
- Orderbook - trading functionality
- Coldspend - cold wallet spending

### Cryptography
- K12 (Keccak-based) for hashing
- ECDSA for Ethereum compatibility
- Falcon/Pylon for post-quantum security
- TSS (Threshold Signature Scheme) for bridge

### Networking (`valis_net.c`, `vpeers.h`)
- nanomsg for peer communication
- memcached for data synchronization
- Async operations to overlap latencies

## Formal Verification

### Coq Proofs (`coq/pass61_vfiles/`)
Key modules:
- `UFC/` - Fee controller proofs
- `DF/` - Dynamic functions proofs
- `ledger/` - Ledger boundedness
- `bridge/` - Bridge security
- `vbpf/` - VM bounds
- `postquantum/` - Pylon/PQ proofs

### Frama-C
- WP (Weakest Precondition) for C function safety
- SMT solvers for "auto" tier
- Coq for goals SMT cannot discharge

## Post-Quantum Security

Attacker model: ECDSA is forgeable (all ETH keys compromised)

PQ-safe mechanisms:
- **FAST**: PQ-hard access control for accounts
- **PQVAULT**: Two-phase mechanism, theft-safe even under "ECDSA broken + untrusted generator"
- Hash preimages (256-bit) still treated as secure

## Build System

```bash
cd ../../valis/
make          # builds 't' executable
make clean    # clean build
make run      # run local demo
```

Dependencies: nanomsg, libmemcached, pthread, gmp, math

## Testing

Main test file: `tests/gen3/tests.c`
- 1500+ unit tests
- Includes structure size validation
- Bridge deposit/withdraw tests
- UFC tests

Unit test files: `tests/units_*.c`
- units_assets.c, units_atomic.c, units_bridge.c
- units_datatx.c, units_deposit.c, units_df.c
- units_generator.c, units_hash.c, units_ledger.c
- units_tx.c, units_ufc.c, units_withdraw.c
- And more...

## Documentation

Specs:
- `L0spec.txt` - L0 layer specification
- `L1spec.txt` - L1 consensus specification
- `v14.grok.txt` - Bridge v14 specification

Docs directory:
- `docs/valis_core_ec.txt`
- `docs/valis_files.txt`
- `docs/valis_net.txt`
- `docs/valis_qmemc.txt`
- `docs/valis_tss.txt`

## Status (from Coq pass61)

### Completed
- Leaderless consensus clarified
- PQ attack surface documented
- ECDSA-only surfaces explicitly inventoried
- Pylon v7 security fix for cold-plan injection

### Remaining Work (TOP_20.md)
1. Stride schedule: prove permutation + ordering correctness
2. Generator ordering: connect to ledger acceptance constraints
3. DF: parallel batch evaluation determinism
4. DF: CRV ranking + matrix validity proofs
5. vbpf: bounds lemmas and nat/Z normalization
6. Orderbook rounding: align Coq spec with code
7. EconomicModule typeclass rollout
8. Ledger boundedness: synthetic-vs-real boundary

## Trust Surface

What is trusted (not proved in Coq):
- Keccak256 collision resistance and preimage hardness
- MPT inclusion proof determinism
- Frama-C WP session + replay logs

What is proved:
- EconomicModule instances for UFC, Ledger, DF
- Tx-signature acceptance rules for Pylon
- Various safety properties via Frama-C
