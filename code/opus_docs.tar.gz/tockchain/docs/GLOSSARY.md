# Tockchain Glossary

Terminology used throughout Tockchain documentation and code.

## Core Concepts

### Tock
A one-second time slot in the Tockchain timeline. Each tock is identified by its Unix timestamp (`utime`). The name "Tockchain" derives from this: a chain of tocks.

### Rawtock
The raw output of L0 consensus for a single tock. Contains:
- Up to ~4,000 rollups
- Maximum size: 10MB
- Quorum signatures from >2/3 of validators
- May be empty (explicitly signed empty rawtock)

### Tockdata
The processed state output from L1 for a single tock. Contains:
- Validated transactions
- State deltas
- Quorum signatures

### Tockid
Unique identifier for a processed transaction: `tock.rind.txind`
- `tock`: Unix timestamp of the tock
- `rind`: Rollup index within the tock
- `txind`: Transaction index within the rollup

### Rollup
A batch of transactions submitted to L0. Multiple rollups are combined into each rawtock.

### Utime
Unix timestamp in seconds. Used as the primary time reference throughout the system.

## Consensus

### Quorum
The minimum agreement threshold for consensus decisions. Defined as `floor(2N/3) + 1` where N is the number of validators. Ensures Byzantine fault tolerance up to 1/3 malicious nodes.

### Leaderless Consensus
Tockchain's consensus mechanism where no single node proposes blocks. Instead:
1. All nodes propose their transaction sets
2. Nodes exchange hashes of proposals
3. Agreement emerges from hash aggregation (XOR)
4. Ordering derived from the final agreed hash

### Finalhash
The hash agreed upon by quorum in L0 consensus. Used to derive transaction ordering via stride-based permutation.

### Vanshash
Intermediate hash in the consensus pipeline: `nodetxidshash → vanshash → finalhash`

### Stride
A value derived from finalhash used to determine transaction ordering. When `gcd(stride, N) = 1`, the stride mapping is a permutation (proven in Coq).

### Jumpstart
Recovery mechanism when consensus halts. A snapshot of state is distributed, and nodes restart from that point.

## Layers

### L0 (Layer 0)
The rawtock production layer. Responsible for:
- Collecting transactions into rollups
- Running leaderless consensus
- Producing signed rawtocks
- No transaction validation (deferred to L1)

### L1 (Layer 1)
The state processing layer. Responsible for:
- Validating transactions against state
- Updating balances and state
- Producing signed tockdata
- Supports full nodes and validator-only nodes

### Full Node (vonly=0)
A node that participates in both generation and validation. Uses memcached and nanomsg for consensus communication.

### Validator-Only Node (vonly=1)
A node that only validates locally without participating in generation. Fetches rawtock files and verifies computed tockdata matches published .Q files.

## Bridge

### Bridge
The system enabling asset transfers between Ethereum and Tockchain.

### Deposit
Moving assets from Ethereum to Tockchain:
1. User sends ETH/tokens to Gnosis Safe on Ethereum
2. Bridge detects deposit
3. Wrapped assets (e.g., tETH) minted on Tockchain

### Withdrawal
Moving assets from Tockchain to Ethereum:
1. User burns wrapped assets on Tockchain
2. Validators sign withdrawal request
3. Gnosis Safe releases ETH/tokens on Ethereum

### Gnosis Safe
A smart contract multisig wallet on Ethereum. The bridge uses a 1-of-1 Safe owned by a TSS address, providing a stable bridge address.

### TSS (Threshold Signature Scheme)
Multi-party computation protocol allowing N parties to jointly produce a signature without any single party knowing the full private key. Used for bridge security.

### Bridgelog
Append-only, signed log of bridge operations. Source of truth for idempotency - prevents double-mints and double-releases.

### Challenge Period
Time window during which a withdrawal can be contested. Provides security against fraudulent withdrawals.

## Cryptography

### K12 (KangarooTwelve)
The primary hash function used in Tockchain. A Keccak-based hash optimized for speed.

### ECDSA
Elliptic Curve Digital Signature Algorithm. Used for Ethereum compatibility.

### Falcon
Post-quantum signature scheme. Part of the Pylon mechanism.

### Pylon
Tockchain's post-quantum security mechanism. Provides quantum-resistant operations even if ECDSA is broken.

### FAST
PQ-hard access control mechanism. Part of Pylon.

### PQVAULT
Two-phase mechanism for quantum-resistant asset protection. Theft-safe even under "ECDSA broken + untrusted generator" threat model.

### Pubkey
32-byte public key (256 bits).

### Privkey
32-byte private key (256 bits).

### Pub64
First 8 bytes of pubkey cast to uint64_t. Used as a compact identifier in memcached keys.

## Transactions

### UFC (Unified Fee Controller)
Module handling fee computation and collection. Despite Tockchain having zero transaction fees, UFC manages internal economic mechanics.

### DF (Dynamic Functions)
Smart contract-like functionality. Supports parallel execution with proven determinism.

### Orderbook
On-chain trading mechanism. Supports limit orders, market orders, and various order types.

### Coldspend
Cold wallet spending mechanism with enhanced security.

### Perpetual
Perpetual futures contract. A derivative product on Tockchain.

### Covered Call
Options contract where the underlying asset is held in escrow.

## Infrastructure

### Memcached
Distributed memory caching system. Used for consensus data sharing between nodes (L0 and L1, vonly=0 only).

### Nanomsg
Lightweight messaging library. Used for peer-to-peer notifications (e.g., TOCK_PROCESSED messages).

### Qmemc
Tockchain's wrapper around libmemcached. Provides structured keys, batch operations, and local fallback mode.

### Peer
A node in the Tockchain network, identified by pubkey and IP address.

### Generator
A validator node that participates in block generation (as opposed to validator-only nodes).

## Verification

### Coq
Proof assistant used for formal verification. Tockchain has 20,000+ lines of Coq proofs.

### Frama-C
Framework for C code analysis. Uses weakest precondition (WP) calculus.

### Axiom
An unproven assumption in Coq. Tockchain documents all axioms as part of the trust surface.

### Parameter
A Coq construct similar to axiom, representing an external value or function.

### Admitted
A Coq tactic that accepts a goal without proof. Tockchain avoids Admitted in production proofs.

### Trust Surface
The documented set of assumptions that must be trusted for the system to be secure. Includes axioms, external dependencies, and operational assumptions.

## Files and Paths

### Rawtockfile
File containing a rawtock. Stored in `rawtocks/day<N>/h<H>/` directory structure.

### .Q File
File containing quorum-signed tockdata. Used by validator-only nodes to verify their local computation.

### Basedir
Root directory for Tockchain data: `/var/www/html/VUSD/` (configurable).

### Stocks
Directory for processed tockdata: `<basedir>/stocks/`

### Rawtocks
Directory for raw rawtock data: `<basedir>/rawtocks/`

## Economic

### VUSD
Tockchain's USD-pegged stablecoin. The primary asset on the network.

### VEUR
Tockchain's EUR-pegged stablecoin.

### tETH
Wrapped Ethereum on Tockchain. 1:1 backed by ETH in the bridge.

### Satoshi
Smallest unit: 10^-8 of the base asset. Used internally for precision.

### Stake
Validator's economic commitment. Used for quorum weighting in dynamic validator sets.

## Miscellaneous

### Bachelor Pad
Informal term for the current codebase state - functional but with some organizational debt.

### Valis
Internal codename for Tockchain.

### Chain Number
Identifier for different Tockchain networks (0 = VUSD, 1 = VEUR, etc.).
