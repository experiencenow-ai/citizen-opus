# L0: Rawtock Production Layer

The L0 layer produces rawtocks through leaderless, quorum-validated consensus.

## Purpose

L0 is responsible for:
1. Collecting transactions into rollups
2. Ordering transactions through consensus
3. Producing signed rawtocks (one per second)
4. Ensuring all honest nodes agree on the same transaction set

L0 does NOT validate transactions - that is deferred to L1.

## Core Concepts

### Rawtock
A rawtock is the output of L0 consensus for a single tock (one-second slot):
- Contains 0 to ~4,000 rollups
- Maximum size: 10MB
- Signed by >2/3 of validators (quorum)
- Identified by Unix timestamp (utime)

### Rollup
A batch of transactions submitted to L0:
- Multiple rollups combined into each rawtock
- Ordered deterministically based on consensus output
- No validation at L0 level

### Leaderless Consensus
No single node proposes blocks. Instead:
- All nodes symmetrically propose their transaction sets
- Agreement emerges from hash aggregation
- Ordering derived from the agreed hash
- No single point of failure or control

## Functional Requirements

### FR1: Leaderless Operation
- No designated leader or coordinator
- All nodes symmetrically propose, vote, and reconcile
- Peer-to-peer gossip and subset-based agreement
- No single node controls phases or outcomes

### FR2: Two-Phase Consensus
**Phase 1 (Prepare)**:
- Nodes propose candidate rollup sets
- Decentralized summaries and votes exchanged
- Preliminary quorum achieved on aggregated hash (XOR)

**Phase 2 (Commit)**:
- Nodes sign the finalized hash
- Quorum signatures collected (>2/3)
- Rawtock produced and distributed
- Failures fall back to empty rawtock

### FR3: Rawtock Production
- One rawtock per second (per utime)
- Up to 10MB, containing 0-~4,000 rollups
- Empty rawtocks explicitly signed and verifiable
- Deterministic ordering within each rawtock

### FR4: Quorum Validation
- All outputs require >2/3 signatures
- Quorum = `floor(2N/3) + 1` where N = validator count
- Offline-verifiable using known pubkeys
- No trust required beyond cryptographic verification

### FR5: Asynchronous Tolerance
- Handles network asynchrony (lags up to 20s)
- No global clocks beyond Unix timestamps
- Nodes can process multiple utimes in parallel
- Robust to message delays and reordering

### FR6: Rollup Handling
- Collect and order raw rollups
- No in-layer validation (deferred to L1)
- Support up to 50k tx/s aggregate
- Efficient batching and transmission

### FR7: Static Quorum Bootstrap
- Initialize with hardcoded generator pubkeys
- Changes currently disabled
- Future: quorum-proposed changes with safe transitions

### FR8: Dynamic Quorum Support (Future)
- Hooks for quorum-based validator changes
- Add/remove validators via quorum approval
- Grace period for new nodes to sync
- No circular dependencies in change process

### FR9: Reconciliation
- Resolve data mismatches efficiently
- Decentralized subset queries
- All nodes converge on same rollup set before commit
- Handles partial data availability

### FR10: Fallback Mechanisms
- On quorum failure: produce empty rawtock
- Persistent failures: trigger jumpstart recovery
- No silent failures - all outcomes are explicit

## Consensus Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    Transaction Flow                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Transactions → Rollups → nodetxidshash → vanshash → finalhash  │
│                               │              │           │       │
│                               └──────────────┴───────────┘       │
│                                    Quorum agreement              │
│                                          │                       │
│                                          ▼                       │
│                                      Rawtock                     │
│                                          │                       │
│                                          ▼                       │
│                              Stride-based ordering               │
│                                          │                       │
│                                          ▼                       │
│                              Ordered transaction set             │
└─────────────────────────────────────────────────────────────────┘
```

### Step 1: Transaction Collection
Nodes collect transactions and batch them into rollups:
- Transactions include scheduled tock (utime)
- Only transactions for current tock are included
- Rollups are hashed for efficient comparison

### Step 2: Hash Exchange (nodetxidshash)
Each node broadcasts a hash of its transaction set:
- `nodetxidshash` = hash of all txids the node has
- Exchanged via nanomsg peer-to-peer
- Forms basis for agreement

### Step 3: Hash Aggregation (vanshash)
Intermediate aggregation step:
- Combine nodetxidshashes from multiple nodes
- XOR aggregation for efficiency
- Detect which nodes have which transactions

### Step 4: Final Agreement (finalhash)
Quorum agreement on the final hash:
- >2/3 of validators must agree
- finalhash determines transaction ordering
- Signatures collected for the agreed hash

### Step 5: Ordering
Transaction order derived from finalhash:
- Stride-based permutation
- `stride = finalhash mod N` (where gcd(stride, N) = 1)
- Proven to be a permutation in Coq

### Step 6: Rawtock Production
Assemble and sign the rawtock:
- Ordered rollups included
- Quorum signatures attached
- Distributed to all nodes

## Data Structures

### Rawtock Header
```c
struct rawtock_header_s {
    uint32_t utime;           // Unix timestamp
    uint32_t num_rollups;     // Number of rollups
    uint8_t finalhash[32];    // Agreed hash
    // ... quorum signatures
};
```

### Rollup
```c
struct rollup {
    uint8_t rhash[32];        // Rollup hash
    uint8_t data[];           // Transaction data
};
```

### Packet Header
```c
struct packethdr {
    uint8_t sig[64];          // Signature
    uint8_t pubkey[32];       // Signer pubkey
    uint32_t utime;           // Timestamp
    uint32_t msg:8;           // Message type
    uint32_t packetlen:24;    // Packet length
};
```

## Communication

### Nanomsg
Used for peer-to-peer notifications:
- Fast alerts (TOCK_PROCESSED messages)
- Hash exchange
- Vote propagation

### Memcached
Used for data sharing (vonly=0 only):
- Stores hashes and summaries (not full data)
- Keys use pub64 for dynamic node support
- Batch operations for efficiency

### Key Types
```c
enum key_type_t {
    KEY_NODE_FIXED = 0,   // Node-specific with pub64
    KEY_CLUSTER = 1       // Cluster with hash
};

enum sub_type_t {
    SUB_DATA = 0,         // General data
    SUB_POINTER = 1,      // Pointer data
    SUB_VOTE = 2          // Vote data
};
```

## Timing

### Per-Tock Timeline
```
t=0.0s  - Tock begins
t=0.0-0.5s - Transaction collection
t=0.5-0.7s - Phase 1 (Prepare)
t=0.7-0.9s - Phase 2 (Commit)
t=0.9-1.0s - Rawtock distribution
t=1.0s  - Next tock begins
```

### Broadcast Lead Time
- 7 seconds broadcast lead time
- Allows for network propagation
- Handles asynchrony gracefully

### Parallel Processing
- Nodes can process multiple utimes in parallel
- Helps catch up after delays
- Bounded by resource constraints

## Failure Modes

### Quorum Failure
If >1/3 of validators are unavailable:
- Cannot achieve quorum
- Empty rawtock produced
- Explicitly signed to indicate failure

### Network Partition
If network splits:
- Neither partition achieves quorum (if split is >1/3)
- Both partitions produce empty rawtocks
- Reconciliation on network heal

### Persistent Failure
If quorum cannot be achieved for extended period:
- Jumpstart recovery triggered
- Snapshot of state distributed
- Nodes restart from known-good point

## Security Properties

### Byzantine Fault Tolerance
- Tolerates up to 1/3 malicious validators
- Malicious nodes cannot:
  - Unilaterally include/exclude transactions
  - Reorder transactions
  - Produce invalid rawtocks

### Censorship Resistance
- Leaderless design prevents single-node censorship
- Any honest node can include transactions
- Quorum ensures diverse participation

### Determinism
- Same inputs → same outputs
- All honest nodes produce identical rawtocks
- Verifiable by any third party

## Verification

### Coq Proofs
Key proven properties:
- Stride permutation: `gcd(stride, N) = 1` implies bijection
- Quorum properties: >2/3 agreement is sufficient
- Ordering determinism: same finalhash → same order

### Runtime Verification
- Signature verification on all messages
- Hash verification on all data
- Quorum counting with threshold checks

## Configuration

### Constants
```c
#define MAXROLLUPBITS 11        // Max ~2048 rollups
#define MAX_ROLLUP_SIZE ...     // Per-rollup size limit
#define MAXGENERATORS ...       // Max validator count
```

### Network Settings
```c
#define BINDADDR "127.0.0.1"
#define _L0CONNPORT ...         // L0 connection port
```

## Implementation Notes

### File Locations
- Rawtock files: `<basedir>/rawtocks/day<N>/h<H>/`
- Organized by day and hour for efficient pruning

### Memory Management
- No alloc/free in hot paths
- Local buffers for temporary storage
- RAM caching in hp[] array

### Thread Safety
- Mutex protection for shared state (hp_mutex)
- Atomic operations where possible
- Lock ordering to prevent deadlocks

## Relationship to L1

L0 produces rawtocks; L1 consumes them:
- L0: Orders transactions, no validation
- L1: Validates transactions, updates state
- Clear separation of concerns
- L1 can verify L0 output independently
