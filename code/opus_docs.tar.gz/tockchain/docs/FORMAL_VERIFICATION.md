# Formal Verification

Tockchain uses formal verification to provide mathematical guarantees about system correctness. This document describes the verification approach, what is proven, and the explicit trust surface.

## Overview

The verification stack consists of:

| Layer | Tool | Purpose |
|-------|------|---------|
| High-level proofs | Coq | Mathematical proofs of system properties |
| C code verification | Frama-C | Memory safety, contract verification |
| Unit testing | Custom | 1500+ tests covering implementation |

### Philosophy

Formal verification in Tockchain follows these principles:

1. **Explicit trust surface**: Every assumption is named and documented
2. **Proof-code alignment**: Proofs must correspond to actual code paths
3. **Conservative claims**: We document what is NOT proven as clearly as what IS proven
4. **Layered assurance**: Multiple verification approaches reinforce each other

## Coq Proof Structure

The Coq proofs are organized into modules:

```
coq/
├── common/          # Shared definitions, trace algebra
├── generator/       # Leaderless ordering, hash pipeline
├── ledger/          # Core accounting, balance invariants
├── UFC/             # Pricing model, economic properties
├── orderbook/       # Fill arithmetic, derivations
├── DF/              # Dataflow evaluation model
├── bridge/          # Deposit/withdrawal semantics
├── nodechange/      # Governance, validator changes
├── postquantum/     # PQ signature assumptions
├── network/         # Packet/transport model
├── coldspend/       # Cold spend paths
├── recovery/        # Recovery flow proofs
├── frama/           # Frama-C integration
├── vbpf/            # BPF bounds scaffolding
├── efficiency/      # Performance lemmas
├── crosscutting/    # Audit scaffolding
└── tockchain/       # High-level chain properties
```

### Module Metrics

Each module is scored on three dimensions (0-5 scale):

| Module | Importance | Completeness | Proof Power | Score |
|--------|------------|--------------|-------------|-------|
| common | 4.0 | 5.0 | 4.0 | 80.0 |
| generator | 5.0 | 4.0 | 4.0 | 80.0 |
| ledger | 5.0 | 3.5 | 4.0 | 70.0 |
| UFC | 5.0 | 3.5 | 4.0 | 70.0 |
| recovery | 3.0 | 4.0 | 4.0 | 48.0 |
| nodechange | 5.0 | 3.0 | 3.0 | 45.0 |
| orderbook | 4.0 | 3.0 | 3.0 | 36.0 |
| DF | 4.0 | 3.0 | 3.0 | 36.0 |
| tockchain | 4.0 | 3.0 | 3.0 | 36.0 |
| postquantum | 4.0 | 3.0 | 3.0 | 36.0 |
| overview | 3.0 | 4.0 | 3.0 | 36.0 |
| bridge | 3.0 | 3.5 | 3.0 | 31.5 |
| frama | 2.0 | 4.0 | 3.0 | 24.0 |
| crosscutting | 3.0 | 4.0 | 2.0 | 24.0 |
| coldspend | 3.0 | 2.5 | 2.5 | 18.75 |
| network | 4.0 | 2.0 | 2.0 | 16.0 |
| vbpf | 2.0 | 2.0 | 2.0 | 8.0 |
| efficiency | 2.0 | 2.0 | 2.0 | 8.0 |

**Total Score: 703.25** (used as trend line across passes)

## What Is Mechanized

### Trace Algebra / Event Reasoning

Reusable lemmas over traces:
- Event ordering properties
- Freeze/non-exec semantics
- Compositional inequalities

### Generator Ordering

The leaderless consensus ordering story:
- Weak rawtock ordering → stride-based eval schedule
- Permutation/determinism properties
- Hash pipeline: `nodetxidshash → vanshash → finalhash`

### Ledger Semantics

Token conservation and safety invariants:
- Balance non-negativity
- Supply bounds
- Atomic transaction properties

### Bridge Core Semantics (Tockchain Side)

- Deposit/withdraw processing
- PQ-disable gating semantics
- Transaction ID composition rules

### Post-Quantum Authorization

- Falcon/LMS signature abstraction
- Pylon state-machine structure
- "QC-hard" assumption modeling

### Frama-C Artifacts

RTE/contract checks for selected C functions:
- Treated as external, checkable artifact
- Not imported directly into Coq proofs

## Trust Surface

The trust surface documents what is **assumed** rather than **proven**.

### Cryptographic Assumptions

| Primitive | Assumption | Status |
|-----------|------------|--------|
| Hash (K12) | Collision resistance | Standard assumption |
| Hash (K12) | Preimage resistance | Standard assumption |
| ECDSA | Unforgeability | Standard assumption |
| Falcon | Post-quantum security | Standard assumption |
| LMS | Post-quantum security | Standard assumption |
| Constant-time ops | Side-channel resistance | Implementation obligation |

These are treated as *external security assumptions* outside pure Coq semantics.

### UFC Economic Axioms

The UFC (Universal Fungible Coin) pricing module has explicit economic assumptions:

```coq
(* Example: No-arbitrage leakage bound *)
Axiom ufc_no_arb_leakage : forall trade_seq,
  valid_trade_sequence trade_seq ->
  total_value_out trade_seq <= total_value_in trade_seq.
```

These axioms represent:
- Price bounds that depend on market behavior
- Conversion rate assumptions
- Premium calculation bounds

**Goal**: Reduce axiom count by proving more from concrete pricing model.

### Ethereum-Side Proof Boundary

Ethereum verification is modeled abstractly. The bridge deposit proofs require:

| Obligation | Description |
|------------|-------------|
| RLP decoding | `EthRlpModel.rlp_decode_receipt` links bytes → receipt |
| MPT inclusion | `EthMptModel.MptInclusion` links receiptsRoot → receipt |
| Header binding | Header's receiptsRoot matches MPT proof |
| Finality policy | `EthFinalityPolicy.HeaderFinalized` asserts finality |
| Log-index scan | Deposit event located by scanning at log_index |

These obligations are precise but abstract—the bundle does not implement Keccak/RLP/MPT/finality checking in Coq.

### Post-Quantum Bridge Posture

In a post-quantum world, Ethereum's security depends on its own consensus and signature assumptions. The bridge treats "usable in PQ mode" as an explicit policy decision:

- Bridge can be disabled if Ethereum-side assumptions don't hold
- PQ mode gating is part of the formal model

## Key Theorems

### UFC Attack No-Profit

Proves that UFC pricing cannot be exploited for arbitrage:

```coq
Theorem ufc_v2o_leg_scaled_value_nonincreasing :
  forall reb_in hurt_in ufc_px target_px,
    0 <= reb_in ->
    0 <= hurt_in ->
    0 < ufc_px ->
    0 < target_px ->
    ufc_px <= target_px ->
    let out_total := v2o_out_total_other reb_in hurt_in ufc_px target_px in
    out_total * ufc_px <= (reb_in + hurt_in) * SATOSHIS.
```

This theorem shows that converting VUSD to other assets cannot increase total value.

### Generator Determinism

Proves that transaction ordering is deterministic given inputs:

```coq
Theorem generator_ordering_deterministic :
  forall inputs1 inputs2,
    inputs1 = inputs2 ->
    generator_output inputs1 = generator_output inputs2.
```

### Ledger Conservation

Proves that tokens cannot be created or destroyed except through defined operations:

```coq
Theorem ledger_conservation :
  forall state tx state',
    ledger_apply state tx = Some state' ->
    total_supply state' = total_supply state + minted tx - burned tx.
```

## Remaining Work

### High Priority

1. **UFC economic trust surface** (Effort: 1.5)
   - Reduce remaining axioms to cryptographic primitives only
   - Ensure every bound lemma maps to code path

2. **Generator ordering** (Effort: 1.0)
   - Stronger leaderless determinism statement
   - Two-phase ordering model

3. **DF parallel eval / serial commit** (Effort: 1.0)
   - Mechanize safety/determinism for parallel evaluation

4. **Ledger boundedness** (Effort: 2.0)
   - MAXCOINSUPPLY invariant
   - Per-asset supply bounds
   - Balance range discipline

5. **Recovery completeness** (Effort: 1.0)
   - Every recovery path in Coq model
   - Explicit preconditions

6. **Bridge PQ posture** (Effort: 1.0)
   - Make PQ assumptions explicit
   - Prove bridge disabled in PQ mode unless assumptions hold

### Medium Priority

- Orderbook scope clarification (Effort: 0.5)
- Metrics table consistency
- Build hygiene improvements

## Frama-C Integration

Frama-C provides C-level verification:

```c
// Example: verified safe arithmetic
/*@ requires a <= INT64_MAX - b;
    ensures \result == a + b;
*/
int64_t safe_add(int64_t a, int64_t b) {
    return a + b;
}
```

### Verified Properties

- **RTE freedom**: No runtime errors (overflow, null deref, etc.)
- **Contract satisfaction**: Functions meet their specifications
- **Memory safety**: No buffer overflows or use-after-free

### Verification Status

Selected functions have Frama-C proofs:
- Safe arithmetic operations
- Buffer handling
- Critical state transitions

## Building the Proofs

### Prerequisites

```bash
# Coq 8.18+ required
opam install coq coq-mathcomp-ssreflect
```

### Build Commands

```bash
cd coq/pass174_vfiles
coq_makefile -f _CoqProject -o Makefile.coq -docroot Valis
make -f Makefile.coq all -k -j4
```

### Current Status

Most files compile. Known issues:
- Some UFC files have type mismatches being resolved
- Bridge Ethereum model has type alignment issues
- Ledger boundedness files need subterm fixes

## Proof-Code Alignment

The `CODE_PROOF_ALIGNMENT.md` file tracks correspondence between:
- Coq definitions and C implementations
- Theorem statements and code invariants
- Axiom assumptions and implementation constraints

This alignment is crucial for ensuring proofs actually apply to the running system.

## Audit Artifacts

For external review:

| Document | Purpose |
|----------|---------|
| TRUST_SURFACE.md | What is assumed vs. proven |
| TOP_20.md | Remaining work items |
| METRICS.md | Module scoring and trends |
| STATUS.md | Build status and known issues |
| CODE_PROOF_ALIGNMENT.md | Proof-code correspondence |

## Related Documentation

- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) - Cryptographic primitives
- [L0_RAWTOCK.md](L0_RAWTOCK.md) - Consensus layer
- [GLOSSARY.md](GLOSSARY.md) - Term definitions
