# Bridge Architecture

The Tockchain Bridge enables trustless asset transfers between Ethereum and Tockchain. This document describes the v14 bridge design, which prioritizes security through threshold signatures, idempotent logging, and multi-stage recovery mechanisms.

## Overview

The bridge connects two fundamentally different systems:

| Property | Ethereum | Tockchain |
|----------|----------|-----------|
| Throughput | ~15 TPS | 50,000+ TPS |
| Fees | Variable gas costs | Zero fees |
| Finality | ~12 minutes (64 blocks) | ~1 second |
| Consensus | Proof of Stake | Leaderless BFT |

The bridge must handle this asymmetry while maintaining security guarantees on both sides.

### Key Design Principles

1. **Gnosis Safe Integration**: All bridge funds held in a Gnosis Safe (1-of-1 configuration) owned by a TSS address
2. **Simplified Transaction Model**: Only deposits and withdrawals—no complex cross-chain operations
3. **Direct Fee Model**: Users pay actual gas costs for Ethereum operations
4. **Validator-Based Security**: Supermajority (2/3 + 1) required for all bridge operations
5. **Idempotent Logging**: Append-only bridgelogs as the source of truth

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         ETHEREUM                                 │
│  ┌─────────────────┐    ┌─────────────────┐                     │
│  │ Deposit         │    │ Gnosis Safe     │                     │
│  │ Forwarder       │───▶│ (1-of-1 TSS)    │                     │
│  │ Contract        │    │                 │                     │
│  └────────┬────────┘    └────────┬────────┘                     │
│           │                      │                              │
└───────────│──────────────────────│──────────────────────────────┘
            │                      │
            │ Deposit Events       │ Withdrawal Txs
            ▼                      ▲
┌───────────────────────────────────────────────────────────────────┐
│                      BRIDGE VALIDATORS                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐               │
│  │ Validator 1 │  │ Validator 2 │  │ Validator N │  ...          │
│  │             │  │             │  │             │               │
│  │ ┌─────────┐ │  │ ┌─────────┐ │  │ ┌─────────┐ │               │
│  │ │Bridgelog│ │  │ │Bridgelog│ │  │ │Bridgelog│ │               │
│  │ └─────────┘ │  │ └─────────┘ │  │ └─────────┘ │               │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘               │
│         │                │                │                      │
│         └────────────────┼────────────────┘                      │
│                          │                                       │
│                    TSS Protocol                                  │
│                   (Safeheron MPC)                                │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        TOCKCHAIN                                 │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │                    L1 Consensus                              ││
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       ││
│  │  │ Bridge Mint  │  │ Bridge Burn  │  │ Bridge State │       ││
│  │  │ Transactions │  │ Transactions │  │ Tracking     │       ││
│  │  └──────────────┘  └──────────────┘  └──────────────┘       ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## Transaction Flows

### Deposit Flow (Ethereum → Tockchain)

1. **User deposits to Deposit Forwarder**
   - User sends ETH or ERC20 tokens to the DepositForwarder contract
   - Contract emits `Deposit` event with: depositor, token, recipient, amount, nonce, block

2. **Validators observe deposit**
   - Each validator monitors Ethereum for deposit events
   - Wait for finality (64 blocks, ~12 minutes)
   - Record deposit in local bridgelog

3. **Validators reach consensus**
   - Validators sync bridgelogs to ensure consistent view
   - Supermajority must agree on deposit validity

4. **Mint on Tockchain**
   - Create bridge mint transaction on Tockchain
   - Credit wrapped tokens to recipient address
   - Record completion in bridgelog

```
User                 Ethereum              Validators            Tockchain
  │                     │                      │                     │
  │──deposit ETH/ERC20─▶│                      │                     │
  │                     │──emit Deposit event─▶│                     │
  │                     │                      │──wait 64 blocks────▶│
  │                     │                      │──sync bridgelogs───▶│
  │                     │                      │──consensus──────────│
  │                     │                      │──────mint tokens───▶│
  │                     │                      │                     │
```

### Withdrawal Flow (Tockchain → Ethereum)

1. **User burns on Tockchain**
   - User submits burn transaction on Tockchain
   - Burn destroys wrapped tokens
   - L1 consensus records burn event

2. **Validators observe burn**
   - Validators see burn in Tockchain state
   - Record burn in local bridgelog
   - Wait for Tockchain finality (~1 second)

3. **TSS signature generation**
   - Validators participate in threshold signature protocol
   - 2/3 + 1 validators must participate
   - Produces single ECDSA signature for Gnosis Safe

4. **Execute withdrawal on Ethereum**
   - Submit signed transaction to Gnosis Safe
   - Safe releases ETH/ERC20 to recipient
   - Record completion in bridgelog

```
User                 Tockchain             Validators            Ethereum
  │                     │                      │                     │
  │──burn tokens───────▶│                      │                     │
  │                     │──burn event─────────▶│                     │
  │                     │                      │──sync bridgelogs───▶│
  │                     │                      │──TSS signing────────│
  │                     │                      │──submit to Safe────▶│
  │                     │                      │                     │──release funds
  │                     │                      │                     │
```

## Gnosis Safe + TSS Integration

The bridge uses a novel combination of Gnosis Safe and threshold signatures:

### Why This Architecture?

**Problem**: Traditional multisig bridges require N signatures on-chain, which is expensive and inflexible.

**Solution**: Use a 1-of-1 Gnosis Safe where the single owner is a TSS-controlled address.

```
┌─────────────────────────────────────────────┐
│              Gnosis Safe                     │
│  ┌─────────────────────────────────────────┐│
│  │  Owner: 0xTSS_ADDRESS                   ││
│  │  Threshold: 1                           ││
│  │                                         ││
│  │  Funds: ETH, USDT, USDC, ...           ││
│  └─────────────────────────────────────────┘│
└─────────────────────────────────────────────┘
                    │
                    │ Single signature required
                    ▼
┌─────────────────────────────────────────────┐
│         TSS (Threshold Signature)            │
│  ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐   │
│  │ V1    │ │ V2    │ │ V3    │ │ VN    │   │
│  │ share │ │ share │ │ share │ │ share │   │
│  └───────┘ └───────┘ └───────┘ └───────┘   │
│                                             │
│  Threshold: 2/3 + 1 of N validators         │
│  No single validator has full private key   │
└─────────────────────────────────────────────┘
```

### Benefits

1. **Stable Address**: The Gnosis Safe address never changes, even when validators change
2. **Gas Efficiency**: Only one signature needed on-chain regardless of validator count
3. **Dynamic Signers**: Validator set can change without affecting the Safe address
4. **Security Alignment**: TSS threshold matches consensus quorum (2/3 + 1)

### Key Rotation

When the validator set changes:

1. Generate new TSS key shares among new validator set
2. Update Gnosis Safe owner to new TSS address
3. Old validators cannot sign (don't have shares of new key)
4. Safe address remains constant

## Bridgelogs

Bridgelogs are the source of truth for bridge state. They provide idempotency and enable recovery from any failure.

### Structure

```
bridgeroot/
├── day20280/
│   ├── deposits.20280.log      # Ethereum deposit events
│   ├── tockbridge.20280.log    # Tockchain bridge events
│   ├── withdrawals.20280.log   # Ethereum withdrawal completions
│   ├── condensed.20280.log     # Compressed historical data
│   └── archival.20280.log      # Full historical archive
├── day20281/
│   └── ...
└── ...
```

### Event Types

| Type | Code | Description |
|------|------|-------------|
| Deposit | 1 | Ethereum deposit observed |
| Burn | 2 | Tockchain burn observed |
| Withdrawal | 3 | Ethereum withdrawal completed |
| TockBridge | 4 | Tockchain bridge state change |
| PauseResume | 5 | Bridge pause/resume event |

### Event Structures

```c
// Deposit Event (from Ethereum)
typedef struct {
    uint8_t event_type;     // 1
    uint64_t timestamp;
    char depositor[43];     // Ethereum address
    char token[43];         // Token contract address
    char recipient[67];     // Tockchain recipient
    int64_t amount;
    uint64_t nonce;
    uint64_t block_number;
    char block_hash[67];
    char tx_hash[67];
} DepositEvent;

// Burn Event (from Tockchain)
typedef struct {
    uint8_t event_type;     // 2
    uint64_t timestamp;
    tockid tock_id;         // Tockchain transaction ID
    int64_t amount;
    char recipient[43];     // Ethereum recipient
    char token[43];         // Token to release
} BurnEvent;

// Withdrawal Event (Ethereum completion)
typedef struct {
    uint8_t event_type;     // 3
    uint64_t timestamp;
    char tx_hash[67];       // Ethereum tx hash
    char recipient[43];
    int64_t amount;
    char token[43];
    uint8_t status;         // 0=pending, 1=complete, 2=failed
    uint64_t block_number;
} WithdrawalEvent;
```

### Idempotency

Every operation is idempotent because:

1. **Unique identifiers**: Each event has a unique ID (tx_hash, tock_id)
2. **Hash tables**: Processed events tracked in `processed_deposits`, `processed_burns`
3. **Replay safety**: Re-processing logs produces identical state

```c
// Check if deposit already processed
int is_deposit_processed(BridgeContext *ctx, const char *tx_hash, EventNode *tockbridge_list) {
    HashEntry *entry;
    HASH_FIND_STR(ctx->processed_deposits, tx_hash, entry);
    if (entry) return 1;  // Already in hash table
    
    // Also check tockbridge log for completion
    EventNode *elt;
    DL_FOREACH(tockbridge_list, elt) {
        TockBridgeEvent *tbe = (TockBridgeEvent *)elt->event;
        if (strcmp(tbe->ref_id, tx_hash) == 0) return 1;
    }
    return 0;
}
```

### Log Synchronization

Validators sync bridgelogs to maintain consistent state:

```c
void sync_bridgelogs(BridgeContext *ctx, uint32_t start_day, uint32_t end_day) {
    for (uint32_t day = start_day; day <= end_day; day++) {
        // Fetch logs from peers
        for (int i = 0; i < ctx->num_peers; i++) {
            fetch_peer_logs(ctx, ctx->peer_pubkeys[i], day);
        }
        // Merge and validate
        merge_day_logs(ctx, day);
    }
}
```

## Fee Structure

### Deposit Fees

- **Ethereum gas**: User pays gas for deposit transaction
- **Tockchain mint**: Zero fees (Tockchain has no transaction fees)

### Withdrawal Fees

- **Tockchain burn**: Zero fees
- **Ethereum gas**: User pays actual gas cost for withdrawal
  - Gas cost estimated at time of burn
  - User's withdrawal amount reduced by gas cost
  - Validators execute withdrawal, recoup gas from user's funds

### Fee Estimation

```c
// Estimate withdrawal gas cost
uint64_t estimate_withdrawal_gas(const char *token, int64_t amount) {
    if (is_eth(token)) {
        return 21000;  // Simple ETH transfer
    } else {
        return 65000;  // ERC20 transfer
    }
}
```

## Recovery Mechanisms

### Withdrawal Failure Recovery

If a withdrawal fails on Ethereum:

1. **Detection**: Validator observes failed transaction
2. **Retry**: Automatic retry with higher gas price
3. **Escalation**: After N retries, mark as deferred
4. **Manual resolution**: Deferred withdrawals require operator intervention

```c
void process_deferred_pending(char *scratch) {
    // Check for withdrawals stuck in pending state
    HashEntry *h, *tmp;
    HASH_ITER(hh, global_ctx->processed_burns, h, tmp) {
        if (h->has_deferred && (time(NULL) - h->deferred_since > 3600)) {
            // Attempt retry
            retry_withdrawal(h);
        }
    }
}
```

### Emergency Recovery

Two-stage recovery for catastrophic failures:

**Stage 1: Challenge Period**
1. Any validator can propose emergency action
2. 24-hour challenge period
3. Other validators can block with supermajority

**Stage 2: Execution**
1. If no block, execute emergency action
2. Actions: pause bridge, rotate keys, recover funds

### Snapshot Jumpstart

For complete bridge restart:

1. **Snapshot**: Capture current state of all bridgelogs
2. **Pause**: Halt all bridge operations
3. **Distribute**: Share snapshot to all validators
4. **Verify**: Validators verify snapshot integrity
5. **Resume**: Restart bridge from snapshot state

## Security Properties

### Assumptions

1. **Honest supermajority**: At least 2/3 + 1 validators are honest
2. **Ethereum finality**: 64 blocks provides sufficient finality
3. **TSS security**: Threshold signature scheme is secure
4. **Network**: Validators can communicate (eventually)

### Guarantees

| Property | Guarantee |
|----------|-----------|
| **Safety** | No double-spends if honest supermajority |
| **Liveness** | Deposits/withdrawals complete if network available |
| **Atomicity** | Either both sides complete or neither does |
| **Idempotency** | Replay of operations is safe |

### Attack Resistance

**51% Attack on Tockchain**
- Attacker cannot steal bridge funds (controlled by TSS)
- Attacker could double-spend on Tockchain side
- Bridge pauses if consensus fails

**Validator Compromise**
- Single validator compromise: no impact (needs 2/3 + 1)
- Multiple validator compromise: bridge pauses
- Key rotation removes compromised validators

**Ethereum Reorg**
- 64-block finality window handles normal reorgs
- Deep reorg: bridge pauses, manual resolution

## Supported Assets

### Native Assets

| Asset | Ethereum | Tockchain |
|-------|----------|-----------|
| ETH | Native | Wrapped (WETH) |
| USDT | ERC20 | Wrapped (VUSDT) |
| USDC | ERC20 | Wrapped (VUSDC) |

### Asset Registration

New assets require:
1. Validator consensus on asset support
2. Contract deployment (if ERC20)
3. Bridgelog update with asset parameters

```c
void init_known_assets(BridgeContext *ctx) {
    // Register known assets
    register_asset(ctx, USDT_CONTRACT_ADDR, "VUSDT", 6);
    register_asset(ctx, "0x0", "WETH", 18);  // Native ETH
}
```

## Implementation Files

| File | Purpose |
|------|---------|
| `test/bridge.c` | Main bridge entry point |
| `test/bridgeutils.h` | Data structures and helpers |
| `test/bridge_context.h` | Context management |
| `test/bridge_events.h` | Event parsing |
| `test/bridge_log.h` | Bridgelog operations |
| `test/bridge_monitor.h` | Ethereum monitoring |
| `test/ethrpc.h` | Ethereum RPC client |
| `test/ethtx.h` | Ethereum transaction building |

## Related Documentation

- [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) - TSS and signature details
- [L1_CONSENSUS.md](L1_CONSENSUS.md) - Tockchain consensus
- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [GLOSSARY.md](GLOSSARY.md) - Term definitions
