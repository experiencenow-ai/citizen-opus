# L1: State Processing Layer

The L1 layer processes rawtocks into validated state through deterministic execution.

## Purpose

L1 is responsible for:
1. Validating transactions from rawtocks
2. Updating state (balances, orderbook, positions)
3. Producing signed tockdata
4. Ensuring all honest nodes compute identical state

## Core Concepts

### Tockdata
The output of L1 processing for a single tock:
- Contains validated transactions
- Includes state deltas
- Signed by >2/3 of validators (quorum)
- Stored in .Q files

### L1consensus_iter
The core iteration function that advances consensus on a single utime:
- Detects quorum on rawtock data
- Validates rollups
- Handles EMPTY declarations
- Advances processed utime

### Node Types

**Full Node (vonly=0)**:
- Participates in consensus via memcached and nanomsg
- Generates and validates
- Uses async operations to overlap latencies
- Target: ~5ms/utime (200x realtime)

**Validator-Only Node (vonly=1)**:
- Validates locally without consensus participation
- Fetches rawtock files via wget
- Verifies computed tockdata matches .Q files
- Higher latency due to polling

## Processing Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    L1 Processing Flow                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Rawtock (from L0)                                               │
│       │                                                          │
│       ▼                                                          │
│  ┌─────────────────┐                                             │
│  │ Detect Quorum   │ ← memcached/nanomsg (vonly=0)              │
│  │ on Rawtock      │ ← wget polling (vonly=1)                   │
│  └────────┬────────┘                                             │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐                                             │
│  │ Load Rawtock    │ ← From cache or file                       │
│  │ Data            │                                             │
│  └────────┬────────┘                                             │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐                                             │
│  │ Validate        │ ← Check against current state              │
│  │ Transactions    │ ← Discard invalid                          │
│  └────────┬────────┘                                             │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐                                             │
│  │ Update State    │ ← Balances, orderbook, positions           │
│  │                 │                                             │
│  └────────┬────────┘                                             │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐                                             │
│  │ Produce         │ ← Sign and distribute                      │
│  │ Tockdata        │                                             │
│  └─────────────────┘                                             │
└─────────────────────────────────────────────────────────────────┘
```

## Quorum Detection

### For Full Nodes (vonly=0)

**Hybrid Approach**:
1. **Nanomsg notifications**: Fast alerts (TOCK_PROCESSED messages)
2. **Memcached pulls**: Data recovery and catchup fallback

**Key Points**:
- Memcached stores hashes/summaries, not full data (too large)
- Full rawtock fetched via wget on quorum confirmation
- Keys use pub64 for dynamic node support

### For Validator-Only Nodes (vonly=1)

**Passive Validation**:
1. Poll for rawtock files via wget
2. Load and process locally
3. Verify computed tockdata matches .Q files
4. No memcached or nanomsg participation

### Quorum Separation

Important: Quorum on raw finalhash does NOT imply tockdata readiness.

```
Rawtock Quorum → Load Data → Process → Tockdata Quorum
       │                                      │
       └──────── Separate checks ─────────────┘
```

## Data Loading

### Helper Functions

**detect_rawtock_quorum()**:
- Check if >2/3 validators agree on rawtock hash
- Returns quorum status and agreed hash

**detect_tockdata_quorum()**:
- Check if >2/3 validators agree on tockdata
- Sequential check after rawtock quorum (vonly=0)
- Local verification (vonly=1)

**load_data_for_utime()**:
- Load rawtock data for given utime
- Check cache first (hp[])
- Fall back to file if not cached

**verify_data_once()**:
- Verify data integrity
- Signature verification
- Hash verification

### Caching

**RAM Cache (hp[])**:
- `L1->tocks[3600]` array
- Protected by `L1->hp_mutex[3600]`
- Minimizes redundant requests
- Key for achieving 5ms/utime target

**Cache Strategy**:
```
Request → Check hp[] cache → Hit? Return cached
                              │
                              └── Miss? → Fetch → Cache → Return
```

## Transaction Validation

### Validation Checks
1. **Signature verification**: Valid signature from sender
2. **Balance check**: Sufficient funds for transaction
3. **Nonce check**: Correct sequence number
4. **Format validation**: Well-formed transaction data
5. **Business logic**: Transaction-type-specific rules

### Invalid Transaction Handling
- Invalid transactions are discarded
- Do not create tockid entries
- No state changes from invalid transactions
- Logged for debugging/monitoring

### Transaction Types

**Basic**:
- Transfer: Move assets between accounts
- Deposit: Bridge deposit confirmation
- Withdrawal: Bridge withdrawal request

**Trading**:
- Limit order: Place order in orderbook
- Market order: Execute against orderbook
- Cancel: Cancel existing order

**DeFi**:
- Pool operations: Add/remove liquidity
- Perpetual: Open/close/modify positions
- Options: Exercise, settle

**Administrative**:
- Validator changes (future)
- Parameter updates

## State Updates

### State Components

**Ledger**:
- Account balances for all assets
- Atomic updates per transaction
- Overflow/underflow protection (proven in Coq)

**Orderbook**:
- Open orders by price level
- Maker/taker matching
- Partial fills supported

**Positions**:
- Derivative positions (perpetuals, options)
- Margin tracking
- Liquidation state

**Bridge State**:
- Pending deposits
- Pending withdrawals
- Bridge balance tracking

### Update Atomicity
- All state updates for a transaction are atomic
- Either all succeed or all fail
- No partial state from failed transactions

## Performance

### Target: ~5ms/utime (200x realtime)

**Achieved Through**:
1. **Async operations**: Overlap network latencies
2. **RAM caching**: Minimize redundant requests
3. **Batch operations**: Reduce memcached round trips
4. **No alloc/free**: Use local buffers
5. **Centralized logic**: Eliminate redundancy

### Performance Factors

| Factor | Impact |
|--------|--------|
| Cache hit rate | High impact - target >90% |
| Network latency | Mitigated by async ops |
| Transaction complexity | Varies by type |
| State size | Affects lookup time |

### vonly=1 Performance
- Higher latency due to wget polling
- No network notifications
- Suitable for verification, not generation

## Communication

### Nanomsg (vonly=0 only)
- TOCK_PROCESSED messages for fast alerts
- Non-blocking notifications
- Peer-to-peer communication

### Memcached (vonly=0 only)
- Stores hashes and summaries
- Keys use pub64 for dynamic support
- Async batch operations

### Wget (both modes)
- File fetching only
- Rawtock files and .Q files
- No involvement in consensus logic

### External Wget Thread
- Dedicated thread polling miss queue
- Decouples from iter to avoid fork stalls
- Centralized in poll_miss_queue helper (vonly=0)
- Direct wget for vonly=1

## Data Structures

### L1 State
```c
struct L1_state {
    struct tockdata tocks[3600];     // Cached tockdata
    pthread_mutex_t hp_mutex[3600];  // Per-slot mutex
    uint32_t processed_utime;        // Last processed
    // ... other state
};
```

### Tockdata
```c
struct tockdata {
    uint32_t utime;
    uint8_t hash[32];
    // ... transaction results
    // ... state deltas
    // ... signatures
};
```

## Error Handling

### Recoverable Errors
- Network timeout: Retry with backoff
- Cache miss: Fall back to file
- Temporary quorum failure: Wait and retry

### Non-Recoverable Errors
- Persistent quorum failure: Trigger jumpstart
- Data corruption: Halt and alert
- Consensus divergence: Halt and investigate

### EMPTY Handling
- EMPTY rawtocks are valid
- Explicitly signed
- Produce EMPTY tockdata
- State unchanged for that tock

## Verification

### Runtime Verification
- Signature verification on all messages
- Hash verification on all data
- Quorum counting with threshold checks

### vonly=1 Verification
- Compute tockdata locally
- Compare against published .Q files
- Alert on mismatch

### Coq Proofs
- Ledger boundedness
- State transition correctness
- Determinism of processing

## Configuration

### Timing
```c
#define CACHED_HOURS 2           // Hours of cached data
```

### Ports
```c
#define _L1CONNPORT ...          // L1 connection port
```

### Limits
```c
#define MAX_VALIDATORS 256       // Max validator count
#define MAX_USERDATA 32768       // Max userdata size
```

## File Storage

### Directory Structure
```
<basedir>/stocks/
├── day<N>/
│   └── h<H>/
│       └── <utime>.Q    # Quorum-signed tockdata
```

### .Q Files
- Contain quorum-signed tockdata
- Used by vonly=1 for verification
- Pruned based on retention policy

## Relationship to L0

```
L0 (Rawtock Production)
        │
        │ Rawtocks (ordered transactions)
        ▼
L1 (State Processing)
        │
        │ Tockdata (validated state)
        ▼
    Applications
```

**Separation of Concerns**:
- L0: Ordering only, no validation
- L1: Validation and state updates
- Each layer independently verifiable

## Implementation Notes

### Memory Management
- No alloc/free in hot paths
- Local buffers for temporary storage
- Pre-allocated arrays where possible

### Thread Safety
- Mutex protection for hp[] cache
- Atomic operations where possible
- Lock ordering to prevent deadlocks

### Centralized Logic
- Quorum detection in dedicated functions
- Verification in verify_data_once
- Data loading in load_data_for_utime

### Timestamp Race Handling
- Key: KEY_TYPE_VOTE_TIMESTAMP.utime
- On CAS fail: get existing timestamp
- Ensures consistency in low-contention scenarios
