# Tockchain DeFi: Options and Perpetuals

> **Document Status**: Technical specification  
> **Last Updated**: Wake 1271  
> **Related**: [TRANSACTIONS.md](TRANSACTIONS.md), [ORDERBOOK.md](ORDERBOOK.md), [ARCHITECTURE.md](ARCHITECTURE.md)

## Overview

Tockchain provides two advanced DeFi instruments: **covered call options** and **delta-neutral perpetual futures**. Both leverage the pool-based architecture and end-tock processing to achieve stateless, high-throughput derivatives trading with minimal oracle dependency.

These instruments serve different user needs:
- **Options**: Income generation for capital providers, leveraged speculation for buyers
- **Perpetuals**: Leveraged trading, synthetic asset creation, overcollateralized lending

## Design Philosophy

### Stateless Processing

Unlike traditional DeFi protocols that maintain per-user state, Tockchain's derivatives use:

1. **Pool shares as position representation**: Positions are fungible tokens
2. **End-tock batch processing**: All rebalancing happens deterministically per tock
3. **Special reserved assets**: System-level tracking without user-specific storage

This eliminates state bloat while supporting high-volume trading.

### Oracle Minimization

Both systems reduce oracle dependency through:

1. **Orderbook-derived prices**: `calc_price()` uses actual trade data
2. **Reserve-based adjustments**: Pool utilization affects pricing
3. **Hybrid volatility**: Historical data combined with reserve signals

---

## Part 1: Covered Call Options

### Concept

A covered call allows an asset holder to sell the right (but not obligation) for someone to buy their asset at a predetermined price (strike) before a certain date (expiry). The seller collects a premium upfront.

Tockchain implements this as a **pool-based system**:
- **Writers** deposit collateral into option pools, earning premiums
- **Buyers** purchase options by locking proportional pool collateral
- **Exercise** transfers locked collateral to buyer at strike price

### Pool Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Option Pool                         │
├─────────────────────────────────────────────────────┤
│  Unlocked Reserves    │  Locked Reserves            │
│  (Available for new   │  (Backing active options)   │
│   option sales)       │                             │
├─────────────────────────────────────────────────────┤
│  Pool Shares: Represent pro-rata claim on unlocked  │
│  reserves + accumulated premiums                    │
└─────────────────────────────────────────────────────┘
```

### Option Lifecycle

#### 1. Pool Deposit (Writing)

Writers deposit collateral to earn premiums:

```
Writer → pooltx(deposit) → Receives pool shares
```

Pool shares represent:
- Pro-rata claim on unlocked reserves
- Share of accumulated premiums
- No exposure to locked collateral (isolated)

#### 2. Option Purchase

Buyers initiate options through a dedicated transaction:

```c
struct optiontx {
    COMMON_TX;
    uint8_t poolpub[32];      // Target option pool
    assetid_t underlying;      // Asset being optioned
    int64_t strike;           // Strike price in VUSD
    uint32_t expiry;          // Expiration tock
    int64_t amount;           // Collateral to lock
};
```

On purchase:
1. Premium calculated based on reserve utilization
2. Collateral locked from pool's unlocked reserves
3. Buyer receives option shares (redeemable tokens)
4. Premium distributed to pool share holders

#### 3. Dynamic Premium Pricing

Premium increases as unlocked reserves decrease:

```
Base Premium = Black-Scholes(spot, strike, time, volatility)
Reserve Factor = 1 + (locked / unlocked) * RESERVE_SLOPE
Final Premium = Base Premium * Reserve Factor
```

This creates a natural supply/demand mechanism:
- High demand → More locked → Higher premiums → Attracts writers
- Low demand → More unlocked → Lower premiums → Attracts buyers

#### 4. Exercise or Expiry

**Exercise** (if spot > strike for calls):
```
Buyer → exercisetx → Pays strike price → Receives locked collateral
```

**Expiry** (if spot ≤ strike):
```
End-tock processing → Locked collateral returns to unlocked reserves
```

### Option Representation

Options are represented as **redeemable shares**, enabling:

1. **Tradeability**: Sell options back to pool at current dynamic price
2. **Partial exercise**: Exercise fractional amounts
3. **Composability**: Options can be transferred like any asset

### Expiration Bucketing

To efficiently process expirations, options are bucketed by expiry tock:

```
Bucket 0: Expires this tock
Bucket 1: Expires next tock
...
Bucket N: Expires in N tocks
```

End-tock processing handles all Bucket 0 options, then shifts buckets.

### Covered Puts via Put-Call Parity

Native calls + VUSD enable synthetic puts:

```
Put = Call - Underlying + Strike (in VUSD)
```

A covered put pool holds VUSD as collateral, with exercise delivering the underlying asset.

### Pricing Model

Hybrid pricing combines multiple signals:

```c
int64_t calc_option_premium(
    int64_t spot,           // Current price
    int64_t strike,         // Strike price
    uint32_t time_to_expiry,// Tocks until expiry
    int64_t hist_vol,       // Historical volatility
    int64_t reserve_ratio   // locked / unlocked
) {
    // Base: Black-Scholes approximation
    int64_t base = black_scholes_approx(spot, strike, time_to_expiry, hist_vol);
    
    // Reserve adjustment: Higher utilization = higher premium
    int64_t reserve_adj = (base * reserve_ratio) / SATOSHIS;
    
    // Volatility adjustment: Recent price swings
    int64_t vol_adj = calc_vol_adjustment(hist_vol);
    
    return base + reserve_adj + vol_adj;
}
```

### Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Mass exercise | Circuit breakers pause new options if reserves < threshold |
| Price manipulation | Hybrid pricing reduces single-source dependency |
| Griefing | Minimum option sizes prevent dust attacks |
| Writer dilution | Locked reserves isolated from new deposits |

### Expected Yields

Writers can expect 5-15% APY on covered call strategies, depending on:
- Underlying volatility
- Strike selection (ATM vs OTM)
- Pool utilization rates

---

## Part 2: Delta-Neutral Perpetual Futures

### Concept

Perpetual futures track asset prices indefinitely without expiration. Tockchain's implementation uses **paired long/short pools** with automatic rebalancing to maintain delta neutrality at the system level.

### Pool Architecture

```
┌─────────────────────────────────────────────────────┐
│              Perpetual Pool Pair                    │
├────────────────────┬────────────────────────────────┤
│    LONG Pool       │       SHORT Pool              │
│  (Benefits from    │   (Benefits from              │
│   price increase)  │    price decrease)            │
├────────────────────┴────────────────────────────────┤
│  End-tock rebalancing based on calc_price() delta  │
└─────────────────────────────────────────────────────┘
```

### Position Types

Users enter positions by minting pool shares:

| Position | Action | Profit When |
|----------|--------|-------------|
| Long | Mint LONG shares | Price increases |
| Short | Mint SHORT shares | Price decreases |
| Neutral | Mint both equally | Funding rate arbitrage |

### Leverage Tiers

The system supports discrete leverage tiers that can be blended:

| Tier | Leverage | Liquidation Threshold |
|------|----------|----------------------|
| 1 | 1x | N/A (fully collateralized) |
| 2 | 5x | 80% loss |
| 3 | 10x | 90% loss |
| 4 | 20x | 95% loss |
| 5 | 50x | 98% loss |

**Custom leverage** (1-50x in 1x steps) achieved by blending tiers:
```
7x leverage = 60% in 5x tier + 40% in 10x tier
```

### End-Tock Rebalancing

Every tock, the system:

1. **Calculates price delta**: `delta = calc_price(now) - calc_price(prev)`
2. **Transfers between pools**: Winners gain from losers proportionally
3. **Processes liquidations**: Under-collateralized positions auto-liquidate
4. **Distributes funding**: Imbalanced sides pay the other

```c
void end_tock_perp_update(struct valisL1_info *L1) {
    int64_t price_delta = calc_price(L1, asset) - L1->prev_price[asset];
    int64_t pnl_transfer = (price_delta * total_exposure) / SATOSHIS;
    
    if (price_delta > 0) {
        // Price up: SHORT pays LONG
        transfer_between_pools(SHORT_POOL, LONG_POOL, pnl_transfer);
    } else {
        // Price down: LONG pays SHORT
        transfer_between_pools(LONG_POOL, SHORT_POOL, -pnl_transfer);
    }
    
    process_liquidations(L1, asset);
    distribute_funding(L1, asset);
}
```

### Funding Rate Mechanism

Funding rates balance long/short demand:

```
Funding Rate = Base Rate + (Long OI - Short OI) / Total OI * FUNDING_SLOPE
```

- **Longs dominant**: Longs pay shorts (positive funding)
- **Shorts dominant**: Shorts pay longs (negative funding)
- **Balanced**: Minimal funding

Funding is distributed continuously via end-tock processing.

### Interest Rate Model

Borrowing rates use a kinked utilization curve:

```
if utilization < KINK:
    rate = BASE_RATE + SLOPE1 * utilization
else:
    rate = BASE_RATE + SLOPE1 * KINK + SLOPE2 * (utilization - KINK)
```

Typical parameters:
- `BASE_RATE`: 2% APY
- `SLOPE1`: 10% per utilization point
- `KINK`: 80% utilization
- `SLOPE2`: 100% per utilization point (above kink)

### User-Visible Use Cases

#### Borrowing VUSD Against tETH

```
1. Deposit tETH as collateral
2. Mint SHORT shares (synthetic short position)
3. Receive VUSD (from pool)
4. Use VUSD for spending
5. Later: Return VUSD + interest to close position
```

#### Leveraged Long

```
1. Deposit VUSD collateral
2. Select leverage tier (e.g., 10x)
3. Mint LONG shares
4. Price increases → Position value increases 10x
5. Redeem shares for profit
```

#### Yield Farming (Delta Neutral)

```
1. Deposit equal amounts to LONG and SHORT pools
2. Collect funding rate arbitrage
3. No directional exposure
4. Expected yield: 5-10% APY from funding imbalances
```

### Liquidation System

#### Per-Position Liquidation

When a position's collateral ratio falls below the tier threshold:

```c
if (position_value / collateral < liquidation_threshold[tier]) {
    // Auto-liquidate at end of tock
    liquidate_position(position);
}
```

#### Global Liquidation (Shared Debt)

For extreme scenarios, the system supports global liquidation:
- All positions in a pool share losses proportionally
- Prevents cascade failures
- Insurance fund (`_PERP_BUFFER_VUSD`) absorbs first losses

### Insurance Fund

The `_PERP_BUFFER_VUSD` special asset accumulates:
- Liquidation penalties
- Portion of trading fees
- Protocol revenue

It covers:
- Bad debt from underwater liquidations
- Extreme market moves exceeding collateral
- Oracle failures

### Oracle Security

Price feeds use a hybrid approach:

1. **Primary**: Orderbook-derived `calc_price()`
2. **Secondary**: External oracle (if configured)
3. **Bounds checking**: Reject prices outside reasonable bands
4. **TWAP**: Time-weighted average prevents manipulation

```c
int64_t get_perp_price(struct valisL1_info *L1, assetid_t asset) {
    int64_t orderbook_price = calc_price(L1, asset);
    int64_t twap = calc_twap(L1, asset, TWAP_WINDOW);
    
    // Reject if deviation too large
    if (abs(orderbook_price - twap) > MAX_DEVIATION) {
        return twap;  // Use TWAP as fallback
    }
    
    return orderbook_price;
}
```

### Risk Parameters

| Parameter | Value | Purpose |
|-----------|-------|---------|
| Max leverage | 50x | Limit systemic risk |
| Min collateral | 100 VUSD | Prevent dust positions |
| Funding interval | 1 tock | Continuous settlement |
| TWAP window | 100 tocks | Manipulation resistance |
| Insurance fund target | 1% of OI | Bad debt coverage |

---

## Implementation Details

### Special Assets

Both systems use reserved special assets for tracking:

| Asset | Purpose |
|-------|---------|
| `_OPTION_LOCKED_{ASSET}` | Locked collateral in option pools |
| `_PERP_LONG_{ASSET}` | Long pool shares |
| `_PERP_SHORT_{ASSET}` | Short pool shares |
| `_PERP_BUFFER_VUSD` | Insurance fund |

### Pool Addresses

Deterministic pool addresses via `poolpub[]`:

```c
void calc_pool_address(uint8_t poolpub[32], const char *pool_type, assetid_t asset) {
    // Deterministic derivation from pool type and asset
    sha256_context ctx;
    sha256_init(&ctx);
    sha256_update(&ctx, pool_type, strlen(pool_type));
    sha256_update(&ctx, &asset, sizeof(asset));
    sha256_final(&ctx, poolpub);
}
```

### Transaction Types

#### Option Transactions

| Type | Handler | Purpose |
|------|---------|---------|
| `OPTION_WRITE` | POOL | Deposit to option pool |
| `OPTION_BUY` | HASHLOCK | Purchase option |
| `OPTION_EXERCISE` | HASHLOCK | Exercise option |
| `OPTION_SELL` | POOL | Sell option back to pool |

#### Perpetual Transactions

| Type | Handler | Purpose |
|------|---------|---------|
| `PERP_OPEN` | POOL | Open leveraged position |
| `PERP_CLOSE` | POOL | Close position |
| `PERP_ADD_MARGIN` | STANDARD | Add collateral |
| `PERP_WITHDRAW` | POOL | Withdraw excess margin |

### Code Footprint

The entire perpetual system requires approximately 100 lines of code in the end-tock validator update, leveraging existing:
- `pooltx` for minting/redeeming shares
- `calc_price()` for price discovery
- Special asset tracking for positions

---

## Comparison with Existing DeFi

### Options

| Feature | Tockchain | Opyn | Hegic |
|---------|-----------|------|-------|
| Settlement | On-chain | On-chain | On-chain |
| Fees | Zero | Gas + protocol | Gas + protocol |
| Liquidity | Pool-based | AMM | Pool-based |
| Expiration | Bucketed | Per-option | Per-option |
| State | Stateless | Per-option | Per-option |

### Perpetuals

| Feature | Tockchain | dYdX | GMX |
|---------|-----------|------|-----|
| Settlement | End-tock | Block | Block |
| Fees | Zero | Maker/taker | Swap fee |
| Leverage | 1-50x | 1-20x | 1-50x |
| Oracle | Hybrid | Chainlink | Chainlink |
| Liquidation | Global + per-position | Per-position | Per-position |

---

## Summary

Tockchain's DeFi instruments provide:

1. **Capital efficiency**: Pool-based design maximizes utilization
2. **Zero fees**: No trading or gas costs
3. **Stateless design**: No per-user storage bloat
4. **Oracle minimization**: Orderbook-derived pricing
5. **High throughput**: ~50,000 TPS supports active trading
6. **Risk management**: Insurance funds, circuit breakers, global liquidation

The combination of covered calls (5-15% APY for writers) and perpetuals (leveraged trading, lending, synthetics) provides a complete DeFi toolkit within Tockchain's feeless, high-performance architecture.

---

## See Also

- [TRANSACTIONS.md](TRANSACTIONS.md) - Transaction structure and handlers
- [ORDERBOOK.md](ORDERBOOK.md) - Spot trading mechanics
- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [L1_CONSENSUS.md](L1_CONSENSUS.md) - End-tock processing
