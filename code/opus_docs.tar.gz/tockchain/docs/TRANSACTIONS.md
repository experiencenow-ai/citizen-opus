# Tockchain Transaction System

> **Document Status**: Technical specification  
> **Last Updated**: Wake 1270  
> **Related**: [ARCHITECTURE.md](ARCHITECTURE.md), [L1_CONSENSUS.md](L1_CONSENSUS.md), [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md)

## Overview

Tockchain transactions are fixed-format, handler-dispatched operations that modify the global state. Every transaction shares a common header structure but specializes based on its handler type. The system supports ten handler types, from simple transfers to complex bridge operations.

## Transaction Structure

### Common Header

All transactions begin with a 96-byte header:

```c
struct txheader {
    uint8_t sig[64];      // Ed25519 signature
    union {
        txflags F;        // Handler-specific flags
        lockflags L;      // For lock-based handlers
    };
};
```

The signature covers the entire transaction body (excluding the signature field itself). Flags encode the handler type and operation-specific parameters.

### Handler Types

| Handler ID | Name | Purpose |
|------------|------|---------|
| 0 | STANDARD | Basic transfers |
| 1 | MULTISIG | M-of-N signatures |
| 2 | COLDSPEND | Quantum-resistant fallback |
| 3 | HASHLOCK | Hash time-locked contracts |
| 4 | POOL | Liquidity pool operations |
| 5 | ORDERBOOK | Limit order trading |
| 6 | BRIDGE | Cross-chain operations |
| 7 | SYSTEM | Reserved for protocol |
| 8 | AIRDROP | Batch distributions |
| 9 | DATA | Arbitrary data storage |

### Common Transaction Fields

Most handlers share these fields (COMMON_TX macro):

```c
struct stdtx {
    struct txheader H;
    uint8_t src[32];      // Source public key
    uint8_t dest[32];     // Destination public key
    int64_t amount;       // Amount in satoshis
};
```

The `amount` field uses satoshi units (10^-8 of the base asset). Maximum supply is bounded by `MAXCOINSUPPLY` ((2^62) - 2).

## Handler Specifications

### Handler 0: Standard Transfer

The simplest transaction type. Transfers `amount` of the specified asset from `src` to `dest`.

```c
struct stdtx {
    COMMON_TX;  // H, src[32], dest[32], amount
};
```

**Validation**:
- Signature must verify against `src`
- `src` must have sufficient balance
- `amount` must be positive

### Handler 1: Multisig

M-of-N signature scheme for shared custody.

```c
struct multisigtx {
    LOCKTIME_TX;              // COMMON_TX + locktime
    uint8_t M, N;             // M required of N total
    uint8_t pubkeys_sig65[];  // N pubkeys + M signatures
};
```

**Validation**:
- At least M valid signatures from the N pubkeys
- `locktime` must have passed (if non-zero)
- Total size bounded by transaction limits

### Handler 2: Coldspend

Quantum-resistant fallback mechanism. Allows spending from a hash-locked address using a post-quantum signature scheme.

```c
struct coldspendtx {
    COMMON_TX;
    uint8_t changepkhash[32];  // Hash of change pubkey
};
```

The coldspend system provides a migration path if Ed25519 is compromised by quantum computers. See [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) for details.

### Handler 3: Hashlock

Hash time-locked contracts for atomic swaps and conditional payments.

```c
struct hashlocktx {
    LOCKTIME_TX;
    assetid lockedasset;
    uint16_t hashalgo;
    uint8_t lockerpub[32];
    uint8_t lockhash[32];
    uint8_t unlockerpub[32];
};
```

**States**:
1. **Locked**: Funds held until preimage revealed or timeout
2. **Claimed**: Unlocker provides preimage matching `lockhash`
3. **Refunded**: Locker reclaims after `locktime` expires

**Hash Algorithms** (`hashalgo`):
- 0: SHA-256
- 1: BLAKE2b-256
- 2: Keccak-256 (Ethereum compatibility)

### Handler 4: Pool

Liquidity pool operations for automated market making.

```c
struct pooltx {
    struct txheader H;
    uint8_t src[32];
    int64_t amount;
    uint64_t poolarg64;       // Pool-specific parameter
    assetid destasset;        // Target asset
};
```

**Operations**:
- **Mint**: Deposit assets, receive pool shares
- **Redeem**: Burn shares, receive proportional assets
- **Swap**: Trade one asset for another

Pool addresses use the `PUBKEY_POOL` ('P') prefix. Pool shares are tracked via the special asset `_POOLSHARES`.

### Handler 5: Orderbook

Limit order trading with maker/taker matching.

```c
struct ordertx {
    COMMON_TX;
    uint8_t makerpub[32];     // Maker's pubkey
    uint8_t OTCpub[32];       // OTC restriction (0 = open)
    assetid makerasset;       // Asset being sold
    assetid takerasset;       // Asset being bought
    int64_t VUSDprice;        // Price in VUSD satoshis
};
```

**Order Types**:
- **Ask** (`PUBKEY_ASKORDER` = 'A'): Selling an asset
- **Bid** (`PUBKEY_BIDORDER` = 'B'): Buying an asset

If `OTCpub` is all zeros, anyone can match the order. Otherwise, only the specified pubkey can take it.

**Price Calculation**:
```c
#define CALC_PRICE(vusd, other) \
    ((other) == 0 ? 0 : (((unsigned __int128)(vusd) * SATOSHIS) / (other)))
```

### Handler 6: Bridge

Cross-chain operations for deposits, withdrawals, and asset creation.

```c
struct bridgetx {
    COMMON_TX;
    char name[32];                    // Asset display name
    struct external_asset extasset;   // External chain info
    union {
        struct external_assetargs asset;
        struct external_chainargs chain;
        struct create_args create;
        struct external_exportargs exporttx;
        struct bridgelock_args bridgelock;
    } args;
    union {
        uint8_t qubictx[...];         // Qubic transaction data
        uint8_t externaldata[252];    // Generic external data
    } extdata;
    uint8_t sigs[...][65];            // TSS signatures
};
```

**External Asset Structure**:
```c
struct external_asset {
    uint8_t name[32];         // External symbol (e.g., "ETH")
    uint8_t issuer[32];       // Issuer pubkey
    uint8_t chainid;          // Chain identifier
    uint8_t precision;        // Decimal places
    uint8_t satoshiscaling;   // Conversion factor
    uint8_t tbd;
    uint32_t pad32;
};
```

See [BRIDGE.md](BRIDGE.md) for complete bridge specification.

### Handler 7: System

Reserved for protocol-level operations. Not available for user transactions.

### Handler 8: Airdrop

Batch distribution to multiple recipients in a single transaction.

```c
struct airdroptx {
    struct txheader H;
    uint8_t src[32];
    uint16_t num_recipients;
    struct { uint8_t dest[32]; int64_t amount; } recipients[];
};
```

Efficient for token launches and reward distributions.

### Handler 9: Data

Arbitrary data storage on-chain.

```c
struct datatx {
    COMMON_TX;
    uint8_t data[DATATX_DATASIZE];  // 512 bytes
};
```

Used for:
- Anchoring external data hashes
- Protocol-level metadata
- Timestamping proofs

## Asset System

### Asset Identifiers

Assets are identified by a 32-bit `assetid`:

```c
typedef struct { 
    uint16_t asset;   // Asset index
    uint16_t pool;    // Pool index (0 = base asset)
} assetid;
```

### Native Assets

| ID | Constant | Description |
|----|----------|-------------|
| 0 | ASSET_VUSD | VUSD stablecoin |
| 1 | ASSET_VNET | VNET governance token |
| 2 | ASSET_QUBIC | Bridged Qubic |
| 3 | ASSET_ETHEREUM | Bridged ETH |

### Special Assets

| ID | Constant | Purpose |
|----|----------|---------|
| 32767 | _COINSMINTED | Track minted supply |
| 32766 | _COINSBURNED | Track burned supply |
| 32765 | _POOLSHARES | Pool share accounting |

### Convenience Macros

```c
#define VUSDCOIN    ((assetid){ASSET_VUSD, ASSET_COIN})
#define VNETCOIN    ((assetid){ASSET_VNET, ASSET_COIN})
#define QUBICCOIN   ((assetid){ASSET_QUBIC, ASSET_COIN})
#define ETHCOIN     ((assetid){ASSET_ETHEREUM, ASSET_COIN})
```

## Transaction Lifecycle

### 1. Creation

```
User → Create transaction → Sign with Ed25519 → Submit to node
```

### 2. Propagation

```
Node → Validate format → Add to mempool → Gossip to peers
```

### 3. Inclusion

```
Mempool → Rollup aggregation → L0 rawtock → L1 processing
```

### 4. Finalization

```
L1 validation → State update → Balance changes recorded
```

## Transaction Limits

| Parameter | Value | Notes |
|-----------|-------|-------|
| Max TX size | ~65KB | `MAXTXSIZE` |
| Max per rollup | 2^TX_PER_ROLLUPBITS | Configurable |
| Max supply | (2^62) - 2 | ~4.6 quintillion |
| Max assets | 32,703 | `MAXASSETS` |
| Name length | 1-12 chars | `MINNAMELEN`/`MAXNAMELEN` |

## Transaction Identification

Each transaction is uniquely identified by a `tockid`:

```c
typedef struct { 
    uint32_t utime;                       // Unix timestamp
    uint16_t rind:MAXROLLUPBITS;          // Rollup index
    uint16_t txind:TX_PER_ROLLUPBITS;     // TX index within rollup
} tockid;
```

This provides:
- Temporal ordering (utime)
- Rollup location (rind)
- Position within rollup (txind)

## Balance Tracking

Balance changes are recorded in a structured format:

```c
struct balancechange {
    tockid tid;           // Transaction that caused change
    // Additional fields for balance delta
};

typedef struct { 
    int64_t balance;      // Current balance
    assetid asset;        // Asset identifier
} assetbalance;
```

## Validation Rules

### Format Validation (L0)

1. Transaction size within limits
2. Handler ID valid (0-9)
3. Signature present and correctly formatted
4. Required fields populated

### Semantic Validation (L1)

1. Signature verifies against source pubkey
2. Source has sufficient balance
3. Handler-specific rules satisfied
4. No double-spend (via tockid ordering)

### Handler-Specific Rules

Each handler implements additional validation:

- **Multisig**: M valid signatures from N pubkeys
- **Hashlock**: Preimage matches hash OR timeout expired
- **Pool**: Sufficient liquidity, valid slippage
- **Orderbook**: Price within bounds, assets exist
- **Bridge**: TSS threshold met, external proof valid

## Error Handling

Transactions that fail validation are:
1. Rejected at mempool (format errors)
2. Excluded from rollups (semantic errors)
3. Marked failed in state (execution errors)

Failed transactions do not consume fees (Tockchain is feeless).

## Security Considerations

### Signature Security

- Ed25519 with 128-bit security level
- Coldspend fallback for quantum resistance
- No signature malleability

### Replay Protection

- Unique tockid per transaction
- Timestamp bounds checking
- Nonce-free design (ordering via tockid)

### Asset Safety

- Overflow protection via 128-bit arithmetic
- Supply bounds enforced
- Pool invariants maintained

## Implementation Notes

### MPC Transactions

Transactions from the bridge use MPC (multi-party computation) signing. These are identified by the first 12 bytes of `src` being zero:

```c
int is_mpc_transaction(const uint8_t *src) {
    for (int i = 0; i < 12; i++) {
        if (src[i] != 0) return 0;
    }
    return 1;
}
```

### Gas Limits (Bridge Only)

For Ethereum bridge operations:
- ETH transfer: 21,000 gas
- ERC-20 transfer: 150,000 gas
- Miner20 (custom): 35,000 gas

```c
#define ETH_GASLIMIT_DECIMAL 21000
#define ERC20_GASLIMIT_DECIMAL 150000
#define MINER20_GASLIMIT_DECIMAL 35000
```

## See Also

- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [L1_CONSENSUS.md](L1_CONSENSUS.md) - State processing
- [BRIDGE.md](BRIDGE.md) - Cross-chain operations
- [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) - Signing and hashing
- [ORDERBOOK.md](ORDERBOOK.md) - Trading mechanics (TODO)
- [DEFI.md](DEFI.md) - Options and perpetuals (TODO)
