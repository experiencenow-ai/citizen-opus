# Tockchain Orderbook System

> **Document Status**: Technical specification  
> **Last Updated**: Wake 1270  
> **Related**: [TRANSACTIONS.md](TRANSACTIONS.md), [L1_CONSENSUS.md](L1_CONSENSUS.md), [ARCHITECTURE.md](ARCHITECTURE.md)

## Overview

Tockchain implements an on-chain central limit order book (CLOB) for trading any asset pair. All orders are denominated in VUSD (the native stablecoin), providing a unified price reference. The system supports both open orders (anyone can match) and OTC orders (restricted to specific counterparties).

## Design Principles

1. **VUSD Denomination**: All prices expressed in VUSD satoshis
2. **Deterministic Matching**: Order matching is deterministic and verifiable
3. **Zero Fees**: No trading fees (Tockchain is feeless)
4. **On-Chain Settlement**: Atomic settlement in the same tock
5. **OTC Support**: Private orders for specific counterparties

## Order Structure

### Order Transaction

```c
struct ordertx {
    COMMON_TX;                    // Header, src, dest, amount
    uint8_t makerpub[32];         // Maker's public key
    uint8_t OTCpub[32];           // OTC restriction (0 = open)
    assetid makerasset;           // Asset being sold
    assetid takerasset;           // Asset being bought
    int64_t VUSDprice;            // Price in VUSD satoshis
};
```

### Field Descriptions

| Field | Type | Description |
|-------|------|-------------|
| `makerpub` | bytes32 | Public key of the order creator |
| `OTCpub` | bytes32 | If non-zero, only this pubkey can match |
| `makerasset` | assetid | Asset the maker is selling |
| `takerasset` | assetid | Asset the maker wants to receive |
| `VUSDprice` | int64 | Price per unit in VUSD satoshis |

### Order Types

Orders are distinguished by their destination pubkey prefix:

| Prefix | Constant | Type | Description |
|--------|----------|------|-------------|
| 'A' | `PUBKEY_ASKORDER` | Ask | Selling an asset |
| 'B' | `PUBKEY_BIDORDER` | Bid | Buying an asset |

## Price Calculation

All prices are calculated relative to VUSD using 128-bit arithmetic to prevent overflow:

```c
#define CALC_PRICE(vusd, other) \
    ((other) == 0 ? 0 : (((unsigned __int128)(vusd) * SATOSHIS) / (other)))
```

### Example

To calculate the price of 1 ETH at 3000 VUSD:
```
VUSDprice = 3000 * SATOSHIS = 300,000,000,000 (3000.00000000 in display)
```

### Price Precision

- VUSD uses 8 decimal places (satoshis)
- Maximum trade size: ~100 billion USD equivalent
- Price stored as int64_t (signed for flexibility)

## Order Lifecycle

### 1. Order Creation

```
Maker → Create ordertx → Sign → Submit to network
```

The maker specifies:
- Which asset they're selling (`makerasset`)
- Which asset they want (`takerasset`)
- The price in VUSD (`VUSDprice`)
- The amount they're offering (`amount`)
- Optional OTC restriction (`OTCpub`)

### 2. Order Visibility

Orders appear in the orderbook immediately upon inclusion in a tock:

```
Tock N: Order included → Orderbook updated → Available for matching
```

### 3. Order Matching

Takers submit matching orders that cross with existing orders:

```
Taker → Submit crossing order → Match at maker's price → Atomic settlement
```

### 4. Settlement

Settlement is atomic within the same tock:
- Maker receives `takerasset`
- Taker receives `makerasset`
- Both balances updated simultaneously

### 5. Order Cancellation

Makers can cancel orders by submitting a cancel transaction:

```c
// Cancel order by setting cancel flag
{"command": "maketx", "type": "makerorder", "tx": {..., "cancel": 1}}
```

## Orderbook Structure

### In-Memory Representation

The orderbook maintains a fixed-size array per trading pair:

```c
#define ORDERBOOKSIZE 4
```

This constant defines the depth of the orderbook maintained in the fast path. Deeper orders are stored but may require additional lookups.

### Trade History

Recent trades are tracked for price discovery:

```c
#define TRADEHISTORYSIZE 4
```

## OTC Orders

### Private Trading

When `OTCpub` is non-zero, only the specified public key can match the order:

```c
// Open order (anyone can match)
OTCpub = {0, 0, 0, ..., 0}  // 32 zero bytes

// OTC order (only specific counterparty)
OTCpub = {counterparty_pubkey}  // 32-byte pubkey
```

### Use Cases

1. **Negotiated Trades**: Pre-arranged trades at specific prices
2. **Block Trades**: Large orders without market impact
3. **Atomic Swaps**: Coordinated cross-chain settlements

## Order Validation

### Format Validation

1. Handler ID must be `HANDLER_ORDERBOOK` (5)
2. `makerasset` and `takerasset` must exist
3. `VUSDprice` must be positive
4. `amount` must be positive

### Semantic Validation

1. Maker must have sufficient balance of `makerasset`
2. If OTC, taker must match `OTCpub`
3. Assets must be tradeable (not system-reserved)

### Matching Validation

1. Taker order must cross maker's price
2. Sufficient liquidity on both sides
3. No self-trading (maker ≠ taker)

## Trading Pairs

### VUSD as Quote Currency

All trading pairs use VUSD as the quote currency:

| Pair | Base Asset | Quote Asset |
|------|------------|-------------|
| VNET/VUSD | VNET | VUSD |
| ETH/VUSD | Bridged ETH | VUSD |
| QU/VUSD | Bridged Qubic | VUSD |

### Cross-Pair Trading

To trade non-VUSD pairs (e.g., ETH/VNET):
1. Sell ETH for VUSD
2. Buy VNET with VUSD

Or use atomic multi-order transactions.

## API Integration

### WebSocket Interface

The orderbook is accessible via WebSocket:

```json
{
  "command": "maketx",
  "type": "makerorder",
  "tx": {
    "maker": "COINLIBPCMZHFABKWAFYZLFVNFTBOIVGRSLQPLFTUBKIEMSDVKAXHLEGIMEI",
    "utc": 8,
    "makerasset": "VUSD",
    "takerasset": "VNET",
    "VUSDprice": "1.50000000",
    "cancel": 0,
    "amount": "100.00000000"
  }
}
```

### Order Query

```json
{
  "command": "orderbook",
  "symbol": "VNET"
}
```

### Response Format

```json
{
  "bids": [
    {"price": "1.45000000", "amount": "500.00000000"},
    {"price": "1.44000000", "amount": "1000.00000000"}
  ],
  "asks": [
    {"price": "1.50000000", "amount": "100.00000000"},
    {"price": "1.51000000", "amount": "250.00000000"}
  ]
}
```

## Order Matching Algorithm

### Price-Time Priority

Orders are matched using price-time priority:

1. **Price Priority**: Best price first (lowest ask, highest bid)
2. **Time Priority**: Earlier orders at same price matched first

### Matching Process

```
1. New order arrives
2. Check if it crosses any existing orders
3. If crossing:
   a. Match at maker's price (price improvement for taker)
   b. Execute partial or full fill
   c. Update orderbook
4. If not crossing:
   a. Add to orderbook
   b. Wait for matching order
```

### Partial Fills

Orders can be partially filled:
- Remaining amount stays in orderbook
- Multiple partial fills until fully executed or cancelled

## Performance Characteristics

### Throughput

- Orderbook updates: Per-tock (1 second)
- Matching: Deterministic, O(log n) for sorted orderbook
- Settlement: Atomic, same-tock

### Capacity

- Pairs: Limited by asset count (32,703 max)
- Orders per pair: Bounded by state size
- Trades per tock: Limited by rollup capacity

## Security Considerations

### Front-Running Prevention

Tockchain's consensus model provides natural front-running resistance:
- All transactions in a tock are processed together
- Order within tock is deterministic (by rollup, then by position)
- No mempool visibility for validators

### Price Manipulation

- Large orders visible in orderbook
- Trade history provides price discovery
- No hidden orders (except OTC)

### Self-Trading

Self-trading (wash trading) is prevented:
- Maker and taker pubkeys must differ
- Same-wallet orders cannot match

## Integration with DeFi

### Pool Arbitrage

Orderbook prices can diverge from pool prices, creating arbitrage:
- Arbitrageurs keep prices aligned
- Benefits both orderbook and pool liquidity

### Options and Perpetuals

Orderbook provides price discovery for:
- Option strike prices
- Perpetual funding rates
- Liquidation triggers

See [DEFI.md](DEFI.md) for details on options and perpetuals.

## Example Workflows

### Simple Trade

```
1. Alice places ask: 100 VNET @ 1.50 VUSD
2. Bob places bid: 50 VNET @ 1.50 VUSD
3. Match: Bob buys 50 VNET from Alice at 1.50 VUSD
4. Alice's remaining order: 50 VNET @ 1.50 VUSD
```

### OTC Trade

```
1. Alice places OTC ask: 1000 ETH @ 3000 VUSD, OTCpub = Bob
2. Charlie tries to match → Rejected (not OTCpub)
3. Bob matches → Executed at 3000 VUSD
```

### Order Cancellation

```
1. Alice places ask: 100 VNET @ 1.50 VUSD
2. Price moves against Alice
3. Alice submits cancel: cancel=1
4. Order removed from orderbook
5. VNET returned to Alice's balance
```

## See Also

- [TRANSACTIONS.md](TRANSACTIONS.md) - Transaction structure
- [L1_CONSENSUS.md](L1_CONSENSUS.md) - State processing
- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [DEFI.md](DEFI.md) - Options and perpetuals (TODO)
