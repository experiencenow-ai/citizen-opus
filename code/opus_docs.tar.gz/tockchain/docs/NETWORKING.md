# Networking

Tockchain uses a custom networking layer optimized for high-throughput, low-latency consensus. This document describes the peer management, packet handling, and distributed storage systems.

## Overview

The networking stack consists of:

| Component | Purpose |
|-----------|---------|
| valis_net | Peer management, packet queuing, signed messaging |
| qmemc | Distributed key-value storage via Memcached |
| nanomsg | Low-level message transport |

### Design Principles

1. **Millisecond precision**: Timestamps use milliseconds for accurate lag detection
2. **Signed packets**: All messages are cryptographically signed
3. **Queue-based**: Separate queues for core and VAPP traffic
4. **Fallback support**: Local in-memory mode for testing

## Peer Management (valis_net)

### Network Context

```c
typedef struct valis_net_context_s {
    uint8_t mypubkey[32];           // My public key
    uint32_t myvappid;              // My VAPP ID
    uint32_t mysetid;               // My set ID
    queue_slot_t core_slots[FIFOSIZE];   // Core queue (destvapp==0)
    queue_slot_t vapp_slots[FIFOSIZE];   // VAPP queue (destvapp==my_vapp_id)
} valis_net_context_t;

// Global context
valis_net_context_t G_valis_net_ctx;
```

### Server Tracking

```c
typedef struct valis_net_server_stats {
    uint8_t pubkey[32];             // Server public key
    char ip[64];                    // IP address
    uint16_t port;                  // Port number
    uint64_t last_seen_ms;          // Last activity (milliseconds)
    uint64_t packets_sent;          // Packets sent to this server
    uint64_t packets_recv;          // Packets received from this server
    int64_t avg_lag_ms;             // Average round-trip lag
    uint8_t status;                 // 0=unknown, 1=active, 2=stale
} valis_net_server_stats_t;

// Fixed-size server array
valis_net_server_stats_t SERVERS[MAX_VALIDATORS + 3];
```

### Peer Operations

```c
// Add a peer to the network
int valis_net_add_peer(const uint8_t *pubkey, const char *ip, uint16_t port);

// Remove a peer
int valis_net_remove_peer(const uint8_t *pubkey);

// Get peer stats
int valis_net_get_peer_stats(const uint8_t *pubkey, valis_net_server_stats_t *stats);

// Update peer last-seen time
void valis_net_touch_peer(const uint8_t *pubkey, uint64_t now_ms);
```

### Timestamp Handling

Timestamps use a 32-bit packed format with millisecond precision:

```c
// Pack current time into 32 bits
// Resolves ±2^22 seconds (~48 days) around now_ms
uint32_t pack_time_ms(uint64_t now_ms);

// Unpack to full 64-bit timestamp
uint64_t unpack_time_ms(uint32_t packed, uint64_t now_ms);
```

This allows efficient timestamp transmission while handling wraparound correctly.

## Packet Handling

### Packet Structure

```c
#define MAXPACKETSIZE 65536

typedef struct {
    uint8_t signature[64];          // Ed25519 signature
    uint8_t sender_pubkey[32];      // Sender's public key
    uint32_t timestamp_packed;      // Packed millisecond timestamp
    uint32_t dest_vapp;             // Destination VAPP (0 = core)
    uint32_t message_type;          // Application-defined type
    uint32_t payload_len;           // Payload length
    uint8_t payload[];              // Variable-length payload
} valis_packet_t;
```

### Sending Packets

```c
// Send signed packet to peer
int valis_net_send(
    const uint8_t *dest_pubkey,
    uint32_t dest_vapp,
    uint32_t msg_type,
    const uint8_t *payload,
    uint32_t payload_len
);

// Broadcast to all peers
int valis_net_broadcast(
    uint32_t dest_vapp,
    uint32_t msg_type,
    const uint8_t *payload,
    uint32_t payload_len
);
```

All packets are automatically signed with the node's private key.

### Receiving Packets

```c
// Receive next packet from queue
int valis_net_recv(
    uint32_t vapp_filter,           // 0 = core, else specific VAPP
    valis_packet_t *packet_out,
    uint32_t timeout_ms
);

// Check if packets available
int valis_net_peek(uint32_t vapp_filter);
```

Packets are verified on receipt—invalid signatures are dropped.

### Queue Management

Separate queues for different traffic types:

```c
#define FIFOSIZE 4096

typedef struct {
    valis_packet_t *packet;
    uint64_t recv_time_ms;
    uint8_t processed;
} queue_slot_t;

// Core queue: consensus messages (destvapp == 0)
// VAPP queue: application messages (destvapp == my_vapp_id)
```

## Distributed Storage (qmemc)

qmemc provides a Memcached wrapper for distributed key-value storage.

### Configuration

```c
#define QMEMC_MAX_KEYLEN      64
#define QMEMC_MAX_DATASIZE    32768
#define QMEMC_MAX_BATCHSIZE   876
#define MAX_MEMC_SERVERS      128
```

### Key Types

```c
typedef enum {
    KEY_NODE_FIXED = 0,     // Node-specific with pub64
    KEY_CLUSTER = 1         // Cluster-wide with hash
} key_type_t;

typedef enum {
    SUB_DATA = 0,           // General data
    SUB_POINTER = 1,        // Pointer data
    SUB_VOTE = 2            // Vote data
} sub_type_t;

typedef struct {
    key_type_t type;
    sub_type_t sub_type;
    uint32_t utime;         // Unix timestamp
    uint32_t index;         // Index value
    uint32_t extra;         // Extra field
    union {
        struct {
            uint64_t pub64; // Node public key prefix
        } node_fixed;
        struct {
            uint8_t hash[32];
            uint8_t flag;
        } cluster;
    };
} key_struct_t;
```

### Operations

```c
// Single operations
int qmemc_get(qmemc_t *q, const key_struct_t *key, 
              uint8_t *data_out, uint32_t *len_out);
int qmemc_set(qmemc_t *q, const key_struct_t *key,
              const uint8_t *data, uint32_t len, uint32_t ttl);
int qmemc_delete(qmemc_t *q, const key_struct_t *key);

// Batch operations (reduced latency)
int qmemc_batch_get(qmemc_t *q, const key_struct_t *keys, int count,
                    uint8_t **data_out, uint32_t *lens_out);
int qmemc_batch_set(qmemc_t *q, const key_struct_t *keys, int count,
                    const uint8_t **data, const uint32_t *lens, uint32_t ttl);
```

### Error Codes

| Code | Constant | Meaning |
|------|----------|---------|
| 0 | QMEMC_OK | Success |
| -1 | QMEMC_ERR_GENERAL | Generic error |
| -8 | QMEMC_ERR_BUFFER_SMALL | Buffer too small |
| -9 | QMEMC_ERR_INVALID_PARAM | Invalid parameters |
| -11 | QMEMC_ERR_TIMEOUT | Operation timeout |
| -12 | QMEMC_ERR_NOT_FOUND | Key not found |

### Local Fallback

For testing or small-scale deployments:

```c
#define QMEMC_MAX_LOCALSETS   8
#define QMEMC_MAX_LOCALKEYS   (QMEMC_MAX_LOCALSETS * MAX_MEMC_SERVERS)

typedef struct {
    uint8_t key[QMEMC_MAX_KEYLEN];
    uint32_t key_len;
    uint8_t data[QMEMC_MAX_DATASIZE];
    uint32_t data_len;
} local_key_entry_t;

// Enable local mode
int qmemc_enable_local_mode(qmemc_t *q);
```

Local mode stores data in-memory instead of Memcached.

## Message Transport (nanomsg)

Low-level transport uses nanomsg for reliable messaging:

### Patterns Used

| Pattern | Use Case |
|---------|----------|
| PAIR | Direct peer-to-peer |
| PUBSUB | Broadcast to subscribers |
| REQREP | Request-response |
| PIPELINE | One-way data flow |

### Connection Management

```c
// Create socket
int nn_socket(int domain, int protocol);

// Bind to address
int nn_bind(int sock, const char *addr);

// Connect to peer
int nn_connect(int sock, const char *addr);

// Send/receive
int nn_send(int sock, const void *buf, size_t len, int flags);
int nn_recv(int sock, void *buf, size_t len, int flags);
```

### Address Format

```
tcp://ip:port      # TCP transport
ipc://path         # Unix domain socket
inproc://name      # In-process (threads)
```

## Network Topology

### Validator Network

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Validator 1 │◄───►│ Validator 2 │◄───►│ Validator 3 │
│             │     │             │     │             │
│ ┌─────────┐ │     │ ┌─────────┐ │     │ ┌─────────┐ │
│ │ qmemc   │ │     │ │ qmemc   │ │     │ │ qmemc   │ │
│ └─────────┘ │     │ └─────────┘ │     │ └─────────┘ │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       └───────────────────┼───────────────────┘
                           │
                    ┌──────┴──────┐
                    │  Memcached  │
                    │   Cluster   │
                    └─────────────┘
```

### Message Flow

1. **Consensus messages**: Via valis_net core queue
2. **State sharing**: Via qmemc distributed storage
3. **Client requests**: Via VAPP queues

## Performance Considerations

### Throughput Optimization

- **Batch operations**: Use qmemc_batch_* for multiple keys
- **Queue sizing**: FIFOSIZE tuned for expected message rate
- **Connection pooling**: Reuse nanomsg sockets

### Latency Optimization

- **Millisecond timestamps**: Accurate lag measurement
- **Local fallback**: Avoid network for small deployments
- **Async operations**: Non-blocking where possible

### Scalability Limits

| Resource | Limit | Notes |
|----------|-------|-------|
| Validators | MAX_VALIDATORS + 3 | Fixed server array |
| Memcached servers | 128 | MAX_MEMC_SERVERS |
| Packet size | 64KB | MAXPACKETSIZE |
| Queue depth | 4096 | FIFOSIZE |
| Batch size | 876 | QMEMC_MAX_BATCHSIZE |

## Security

### Packet Authentication

All packets are signed:

```c
// Sign packet before sending
valis_sign(packet->signature, 
           packet_data, packet_len,
           my_privkey);

// Verify on receipt
int valid = valis_verify(packet->signature,
                         packet_data, packet_len,
                         packet->sender_pubkey);
if (!valid) {
    drop_packet(packet);
}
```

### Key Management

- Node keys stored securely
- Peer public keys verified on connection
- Key rotation supported via nodechange protocol

### Thread Safety

Current implementation has partial thread safety:
- Global context requires external synchronization
- Queue operations are not atomic
- Memcached operations are thread-safe

**Note**: Production deployments should add mutex protection for concurrent access.

## Implementation Files

| File | Purpose |
|------|---------|
| valis_net.c | Peer management, packet handling |
| valis_qmemc.c | Memcached wrapper |
| valis_core_defs.h | Constants and shared definitions |

## Related Documentation

- [ARCHITECTURE.md](ARCHITECTURE.md) - System overview
- [L0_RAWTOCK.md](L0_RAWTOCK.md) - Consensus layer using networking
- [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) - Signature details
- [GLOSSARY.md](GLOSSARY.md) - Term definitions
