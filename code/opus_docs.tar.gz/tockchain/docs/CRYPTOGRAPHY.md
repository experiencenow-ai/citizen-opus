# Cryptography

Cryptographic primitives and protocols used in Tockchain.

## Overview

Tockchain uses multiple cryptographic systems:
- **K12**: Primary hash function
- **ECDSA**: Ethereum-compatible signatures
- **Falcon**: Post-quantum signatures
- **TSS**: Threshold signatures for bridge

## Hash Functions

### KangarooTwelve (K12)

The primary hash function throughout Tockchain.

**Properties**:
- Keccak-based (SHA-3 family)
- Optimized for speed
- 256-bit output (32 bytes)
- Collision-resistant

**Usage**:
```c
// Hash data to 32-byte output
KangarooTwelve(input, input_len, output, 32);
```

**Used For**:
- Transaction hashing
- Block hashing
- Key derivation
- Merkle trees

### SHA256

Used for Ethereum compatibility where required.

**Usage**:
- Ethereum address derivation
- Bridge operations
- External system integration

## Key Management

### Key Sizes
All keys are 256 bits (32 bytes):
- Private key: 32 bytes
- Public key: 32 bytes (compressed)
- Signature: 64 bytes

### Key Derivation

**From Seed (55 lowercase letters)**:
```c
bool getSubseedFromSeed(const uint8_t* seed, uint8_t* subseed);
```
- Converts 55 letters ('a'-'z') to bytes (0-25)
- Hashes with K12 to produce 32-byte subseed

**From Subseed to Private Key**:
```c
void getPrivateKeyFromSubSeed(const uint8_t* seed, uint8_t* privateKey);
```
- Hashes subseed with K12
- Retries with XOR tweak if invalid (up to 3 times)

**Private Key Validation**:
```c
int is_valid_ETHprivkey(uint8_t privkey[32]);
```
- Non-zero
- Less than secp256k1 curve order n

### Wallet Structure

```c
struct wallet_info {
    int32_t colddepth;              // Cold branch derivation depth
    uint8_t passhash[32];           // Password hash for encryption
    char seedstr[256];              // Seed string (55 chars or BIP39)
    char fname[512];                // Wallet filename
    struct seedinfo hiddenroot;     // Root seed info
    struct seedinfo cold;           // Cold storage
    struct seedinfo trading;        // Hot/trading
    struct seedinfo derived[64];    // Derived addresses
};
```

### Seed Info Structure

```c
struct seedinfo {
    uint8_t subseed[32];    // Derived subseed
    uint8_t privkey[32];    // Private key
    uint8_t pubkey[32];     // Public key
    uint8_t pkhash[32];     // Hash of public key
    char hotaddr[64];       // Human-readable address
    char pkhashaddr[64];    // Address from pkhash
};
```

## Signatures

### ECDSA (secp256k1)

Standard Ethereum-compatible signatures.

**Signing**:
```c
int32_t sign_fn(const uint8_t priv[32], const uint8_t pubkey[32], 
                const uint8_t hash[32], uint8_t sig[64]);
```

**Verification**:
```c
int32_t verify_fn(const uint8_t pubkey[32], const uint8_t hash[32], 
                  uint8_t sig[64]);
```

**Properties**:
- 64-byte signatures
- Deterministic (RFC 6979)
- Ethereum-compatible

### FourQ Signatures

Alternative curve for internal operations.

**Properties**:
- Faster than secp256k1
- 64-byte signatures
- Used where Ethereum compatibility not required

## Threshold Signatures (TSS)

Multi-party computation for bridge security.

### Purpose
- No single party knows full private key
- Threshold of signers required
- Stable bridge address via Gnosis Safe

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    TSS Signing Flow                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                          │
│  │ Signer1 │  │ Signer2 │  │ Signer3 │  ... (t-of-n threshold) │
│  └────┬────┘  └────┬────┘  └────┬────┘                          │
│       │            │            │                                │
│       └────────────┼────────────┘                                │
│                    │                                             │
│                    ▼                                             │
│            ┌───────────────┐                                     │
│            │  MPC Protocol │                                     │
│            └───────┬───────┘                                     │
│                    │                                             │
│                    ▼                                             │
│            ┌───────────────┐                                     │
│            │   Signature   │  (Single ECDSA signature)          │
│            └───────────────┘                                     │
└─────────────────────────────────────────────────────────────────┘
```

### Key Generation

```c
// Async keygen for t-of-n threshold
int32_t tss_keygen_async(int32_t t, int32_t n, 
                         progress_callback_t cb,
                         tss_result_t *result);
```

**Process**:
1. Each party generates random share
2. Shares combined via MPC protocol
3. Public key derived without exposing private shares
4. Each party stores their key shard

### Signing

```c
// Async signing of 32-byte hash
int32_t tss_sign_async(const uint8_t hash[32],
                       progress_callback_t cb,
                       tss_result_t *result);
```

**Process**:
1. Threshold parties participate
2. MPC protocol produces signature
3. No party learns full private key
4. Output is standard ECDSA signature

### Concurrency Control

```c
// Named semaphore limits concurrent TSS operations
#define TSS_SEM_NAME "/valis_tss_sem"
```

- Caps concurrent operations to prevent overload
- Cross-process coordination if needed

### Storage

Key shards stored in binary files:
- Reduces size vs base64
- Encrypted at rest
- Distributed across signers

## Post-Quantum Security

### Threat Model

Assumption: ECDSA may be broken by quantum computers.

**Attack Scenario**:
- All ECDSA private keys compromised
- Attacker can forge any ECDSA signature
- Hash preimages (256-bit) remain secure

### Pylon Mechanism

Framework for PQ-safe operations:

**FAST (PQ-hard Access Control)**:
- Additional authorization layer
- Requires hash preimage knowledge
- Cannot be forged even with ECDSA broken

**PQVAULT (Two-Phase Protection)**:
- Phase 1: Commit to action with hash
- Phase 2: Reveal preimage to execute
- Theft-safe even under "ECDSA broken + untrusted generator"

### Falcon Signatures

Post-quantum signature scheme:
- Lattice-based
- NIST PQC finalist
- Used in Pylon mechanism

## Address Encoding

### Tockchain Address Format

60-character identity string:
```
ICKZADDSETKCNEDLGQJIPGLAODRBWSYYUZQUZWEHECIUBQIOHXLYVLRCDYMJ
```

**Encoding**:
- Base32-like encoding
- Includes checksum
- Human-readable

### Ethereum-Compatible Address

For bridge operations:
```
0x742d35Cc6634C0532925a3b844Bc9e7595f...
```

**Derivation**:
- Keccak256 hash of public key
- Last 20 bytes
- 0x prefix + hex encoding

## Safe Arithmetic

### 128-bit Operations

For overflow-safe calculations:

```c
// Multiply two 64-bit values into 128-bit result
int portable_mul128(uint64_t a, uint64_t b, uint64_t res[2]);

// Divide 128-bit by 64-bit
int portable_div128(uint64_t num[2], uint64_t den, 
                    uint64_t *q, uint64_t *rem);
```

### Safe Multiply-Then-Divide

```c
// Computes (a * b) / c with 128-bit intermediate
int64_t safe_mul_then_div(int64_t a, int64_t b, int64_t c, 
                          int64_t div0_err);
```

**Error Codes**:
- `div0_err`: Returned on division by zero
- `-1`: Overflow
- `-3`: Non-positive inputs

### Bit Operations

```c
#define SETBIT(bits, bitoffset)   // Set bit
#define GETBIT(bits, bitoffset)   // Check bit
#define CLEARBIT(bits, bitoffset) // Clear bit
```

## Verification

### Signature Verification Flow

```
Message → Hash → Verify(pubkey, hash, sig) → Valid/Invalid
```

### Batch Verification

For efficiency, signatures can be batch-verified:
- Collect multiple (pubkey, hash, sig) tuples
- Verify in single operation
- Faster than individual verification

### Merkle Proofs

For bridge accountability:
- Optional Merkle proofs in BRIDGEIMPORT transactions
- Enable independent verification of Ethereum deposits
- Reduce trust in quorum for deposit verification

## Security Considerations

### Key Storage
- Private keys never logged
- Encrypted at rest
- Secure memory handling

### Randomness
- Cryptographically secure RNG
- Proper seeding
- No predictable values

### Side Channels
- Constant-time operations where possible
- Memory access patterns considered
- Timing attack mitigation

### Key Rotation
- Support for key updates
- Grace periods for transitions
- Old keys invalidated properly

## Dependencies

### External Libraries
- **libsecp256k1**: ECDSA operations
- **libethc**: Ethereum utilities
- **Safeheron MPC**: TSS implementation

### Internal Modules
- **valis_math.c**: Safe arithmetic
- **valis_keys.c**: Key management
- **valis_tss.c**: TSS wrapper

## Constants

```c
#define SATOSHIS ((uint64_t)100000000)  // 10^8 for precision
#define MAX_SAFE_63BITS ((int32_t)((int64_t)1ULL << 62) - 2)
```

## Best Practices

1. **Never reuse nonces** - Deterministic signing (RFC 6979)
2. **Verify before trust** - Always verify signatures
3. **Secure key derivation** - Use proper KDFs
4. **Constant-time comparison** - For sensitive data
5. **Proper entropy** - For key generation
