# Tockchain Architecture

This document describes the high-level architecture of Tockchain (Valis).

## Design Philosophy

Tockchain is built on three core principles:

1. **Structural constraints over institutional constraints** - Security comes from cryptographic proofs and consensus mechanisms, not from trusting institutions
2. **Formal verification** - Critical properties are mathematically proven, not just tested
3. **Zero fees, maximum throughput** - Economic model based on TVL and bridge fees, not transaction fees

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Ethereum                                 │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Gnosis Safe                           │    │
│  │              (1-of-1 owned by TSS)                       │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ Bridge (deposits/withdrawals)
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Tockchain                                 │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    L1 (State Layer)                      │    │
│  │  • Transaction validation                                │    │
│  │  • State updates (balances, orderbook, etc.)            │    │
│  │  • Produces signed tockdata                              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              ▲                                   │
│                              │ rawtocks                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    L0 (Consensus Layer)                  │    │
│  │  • Leaderless consensus                                  │    │
│  │  • Transaction ordering                                  │    │
│  │  • Produces signed rawtocks                              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              ▲                                   │
│                              │ transactions                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Users/Applications                    │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

## Layer 0: Rawtock Production

L0 is responsible for ordering transactions and producing rawtocks through leaderless consensus.

### Key Properties
- **One rawtock per second** - Each Unix timestamp (utime) produces exactly one rawtock
- **Leaderless** - No single node proposes blocks; ordering emerges from collective agreement
- **Quorum-validated** - Requires >2/3 validator signatures
- **No validation** - Transactions are ordered but not validated (deferred to L1)

### Consensus Pipeline

```
Transactions → Rollups → nodetxidshash → vanshash → finalhash → Rawtock
                              │              │           │
                              └──────────────┴───────────┘
                                   Quorum agreement
```

1. **Transaction Collection**: Nodes collect transactions into rollups
2. **Hash Exchange**: Nodes broadcast hashes of their transaction sets
3. **Hash Aggregation**: Hashes are combined (XOR) to produce intermediate hashes
4. **Quorum Detection**: When >2/3 agree on finalhash, rawtock is produced
5. **Ordering**: Transaction order derived from finalhash via stride permutation

### Two-Phase Consensus

**Phase 1 (Prepare)**:
- Nodes propose candidate rollup sets
- Decentralized summaries and votes exchanged
- Preliminary quorum on aggregated hash

**Phase 2 (Commit)**:
- Nodes sign the finalized hash
- Quorum signatures collected
- Rawtock produced and distributed

### Failure Handling
- If quorum fails, an empty rawtock is produced (explicitly signed)
- Persistent failures trigger jumpstart recovery from snapshot

## Layer 1: State Processing

L1 processes rawtocks into validated state through deterministic execution.

### Key Properties
- **Deterministic** - All nodes produce identical state from identical rawtocks
- **Validated** - Transactions checked against current state
- **Signed** - Produces quorum-signed tockdata
- **Two node types** - Full nodes (generate + validate) and validator-only (validate only)

### Processing Pipeline

```
Rawtock → Validate Transactions → Update State → Produce Tockdata
              │                       │
              │                       ├── Balances
              │                       ├── Orderbook
              │                       ├── Positions
              │                       └── Other state
              │
              └── Invalid transactions discarded
```

### Node Types

**Full Node (vonly=0)**:
- Participates in consensus via memcached and nanomsg
- Generates and validates
- Uses async operations to overlap latencies
- Target: ~5ms/utime (200x realtime)

**Validator-Only Node (vonly=1)**:
- Validates locally without consensus participation
- Fetches rawtock files via wget
- Verifies computed tockdata matches published .Q files
- Higher latency due to polling

### State Components
- **Ledger**: Account balances for all assets
- **Orderbook**: Open orders and trading state
- **Positions**: Derivative positions (perpetuals, options)
- **Bridge state**: Pending deposits/withdrawals

## Bridge Architecture

The bridge enables trustless asset transfers between Ethereum and Tockchain.

### Design Principles
- **Gnosis Safe**: Stable address, battle-tested smart contract
- **TSS**: No single party controls bridge funds
- **Bridgelogs**: Append-only logs for idempotency
- **Challenge periods**: Time for fraud detection

### Components

**Ethereum Side**:
- Gnosis Safe (1-of-1 configuration)
- Owned by TSS address (threshold signature)
- Holds all bridged ETH and tokens

**Tockchain Side**:
- Wrapped assets (tETH, etc.)
- Bridge state tracking
- Validator monitoring

### Deposit Flow
```
1. User sends ETH/tokens to Gnosis Safe
2. Ethereum light clients detect deposit
3. Validators sign deposit confirmation
4. Wrapped assets minted on Tockchain
5. Deposit logged in bridgelog
```

### Withdrawal Flow
```
1. User burns wrapped assets on Tockchain
2. Withdrawal logged in bridgelog
3. Challenge period begins
4. Validators sign withdrawal request
5. TSS produces signature for Gnosis Safe
6. ETH/tokens released on Ethereum
```

### Recovery Mechanisms
- **Two-stage recovery**: Challenge periods for dispute resolution
- **Dynamic replacement**: Validators can be replaced via quorum
- **Snapshot jumpstart**: Recovery from known-good state

## Cryptography

### Hash Functions
- **K12 (KangarooTwelve)**: Primary hash function, Keccak-based
- **SHA256**: For Ethereum compatibility where needed

### Signatures
- **ECDSA (secp256k1)**: Ethereum-compatible signatures
- **Falcon**: Post-quantum signatures (Pylon mechanism)
- **TSS**: Threshold signatures for bridge

### Post-Quantum Security
Tockchain assumes ECDSA may eventually be broken:

- **Pylon**: Framework for PQ-safe operations
- **FAST**: PQ-hard access control
- **PQVAULT**: Two-phase protection mechanism

Threat model: Even if all ECDSA keys are compromised AND the generator is untrusted, PQVAULT-protected assets remain safe.

## Networking

### Protocols
- **Nanomsg**: Peer-to-peer messaging (notifications, fast alerts)
- **Memcached**: Distributed data sharing (consensus data)
- **HTTP/wget**: File fetching (rawtocks, tockdata)

### Data Flow
```
┌──────────┐    nanomsg     ┌──────────┐
│  Node A  │◄──────────────►│  Node B  │
└──────────┘                └──────────┘
     │                           │
     │      memcached            │
     └───────────┬───────────────┘
                 │
           ┌─────▼─────┐
           │ Memcached │
           │  Cluster  │
           └───────────┘
```

### Key Patterns
- **Async operations**: Overlap network latencies
- **RAM caching**: Minimize redundant requests (hp[] array)
- **Batch operations**: Reduce round trips to memcached

## Formal Verification

### Coq Proofs
20,000+ lines proving:
- Ledger boundedness (no overflow/underflow)
- UFC fee correctness
- DF parallel determinism
- Bridge security properties
- Stride permutation properties

### Frama-C
C code verification using:
- Weakest precondition (WP) calculus
- SMT solvers for automated proofs
- Coq for complex goals

### Trust Surface
Documented assumptions that must be trusted:
- Cryptographic primitives (K12, ECDSA, Falcon)
- Network timing bounds
- Hardware correctness
- Axioms in Coq proofs (explicitly enumerated)

## Data Storage

### Directory Structure
```
/var/www/html/VUSD/
├── stocks/           # Processed tockdata
│   └── day<N>/
│       └── h<H>/
└── rawtocks/         # Raw rawtock data
    └── day<N>/
        └── h<H>/
```

### File Types
- **Rawtock files**: Raw consensus output
- **.Q files**: Quorum-signed tockdata
- **State snapshots**: For jumpstart recovery

### Pruning
- Old data pruned to manage storage
- Archival tier for historical access
- Condensed logs for fast loading

## Performance

### Targets
| Metric | Target |
|--------|--------|
| Throughput | 50,000+ TPS |
| Block time | 1 second |
| Finality | 3-5 seconds |
| L1 processing | ~5ms/utime |

### Optimizations
- Parallel transaction processing
- Async network operations
- RAM caching with mutex protection
- Batch memcached operations

## Security Model

### Byzantine Fault Tolerance
- Tolerates up to 1/3 malicious validators
- Quorum: `floor(2N/3) + 1`
- No forks - halts on quorum failure

### Attack Resistance
- **Double-spend**: Prevented by deterministic ordering
- **Censorship**: Leaderless consensus prevents single-node censorship
- **Bridge attacks**: TSS + challenge periods + bridgelogs

### Operational Security
- Validator key management
- Network isolation
- Monitoring and alerting

## Future Considerations

### Dynamic Quorums
Currently static validator set; hooks exist for:
- Quorum-based validator changes
- Grace periods for new validators
- Safe transitions without loops

### Scalability
- Sharding (MAX_SHARDS = 32)
- Cross-shard communication
- State partitioning

### Additional Features
- More derivative types
- Cross-chain bridges
- Governance mechanisms
