# Tockchain

A high-throughput blockchain with formal verification, designed for 50,000+ transactions per second with zero transaction fees.

## What is Tockchain?

Tockchain (codenamed Valis) is a blockchain that combines:

- **Leaderless consensus** - No single node proposes blocks; ordering emerges from shared commitments
- **Formal verification** - 20,000+ lines of Coq proofs, Frama-C verification for C code
- **Post-quantum security** - Pylon mechanism for quantum-resistant transactions
- **Ethereum bridge** - Trustless asset transfers via Gnosis Safe + threshold signatures

## Key Properties

| Property | Value |
|----------|-------|
| Throughput | 50,000+ TPS |
| Transaction fees | Zero |
| Block time | 1 second ("tock") |
| Finality | 3-5 seconds |
| Consensus | Leaderless, quorum-based (>2/3 agreement) |

## Architecture

Tockchain operates in two layers:

### L0 - Rawtock Production
The L0 layer produces one "rawtock" per second through leaderless consensus:
1. Nodes collect transactions into rollups
2. Nodes exchange hashes of their transaction sets
3. Quorum (>2/3) agreement on a combined hash produces a signed rawtock
4. No single node controls ordering - it emerges from the consensus process

### L1 - State Processing
The L1 layer processes rawtocks into validated state:
1. Validates transactions against current state
2. Updates balances, orderbooks, and other state
3. Produces signed tockdata files for verification
4. Supports both full nodes and validator-only nodes

### Bridge
The Ethereum bridge enables trustless asset transfers:
- Gnosis Safe (1-of-1) owned by a threshold signature address
- Deposits: Lock ETH/tokens → mint wrapped assets on Tockchain
- Withdrawals: Burn wrapped assets → release ETH/tokens
- Recovery: Two-stage system with challenge periods

## Quick Start

### Build
```bash
cd valis/
make
```

### Run Tests
```bash
./t test    # Run 1500+ unit tests
```

### Run Node
```bash
./t -node   # Full node (generates and validates)
./t -vonly  # Validator-only (validates locally)
```

## Documentation

| Document | Description |
|----------|-------------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | System architecture and design |
| [L0_RAWTOCK.md](L0_RAWTOCK.md) | L0 layer: rawtock production |
| [L1_CONSENSUS.md](L1_CONSENSUS.md) | L1 layer: state processing |
| [BRIDGE.md](BRIDGE.md) | Ethereum bridge specification |
| [CRYPTOGRAPHY.md](CRYPTOGRAPHY.md) | Keys, signing, hashing |
| [FORMAL_VERIFICATION.md](FORMAL_VERIFICATION.md) | Coq proofs and trust surface |
| [GLOSSARY.md](GLOSSARY.md) | Terminology definitions |

## Formal Verification

Tockchain uses formal verification to prove correctness:

- **Coq proofs** (20,000+ lines): Mathematical proofs of protocol properties
- **Frama-C**: C code verification with weakest precondition calculus
- **Trust surface**: Documented axioms and assumptions

Key verified properties:
- Ledger boundedness (no overflow/underflow)
- Fee controller correctness (UFC module)
- Dynamic function determinism (DF module)
- Bridge security properties

## Security Model

### Byzantine Fault Tolerance
- Tolerates up to 1/3 malicious validators
- Quorum requires >2/3 agreement
- No forks - halts on quorum failure, recovers via jumpstart

### Post-Quantum Security
- ECDSA for Ethereum compatibility
- Pylon mechanism for quantum-resistant operations
- FAST: PQ-hard access control
- PQVAULT: Two-phase mechanism, theft-safe even if ECDSA broken

### Bridge Security
- Threshold signatures (TSS) for multi-party control
- Gnosis Safe for stable bridge address
- Challenge periods for withdrawals
- Emergency recovery with validator supermajority

## Codebase

```
valis/
├── *.c, *.h          # Core C implementation (~200k lines)
├── coq/              # Formal proofs (~20k lines)
│   ├── bundle/       # Main proof modules
│   └── common/       # Shared definitions
├── tests/            # Unit and integration tests
├── docs/             # Existing documentation
└── cryptolibs/       # Cryptographic libraries
```

## Status

- **Phase**: Testnet, nearing mainnet release candidate
- **Tests**: 1500+ unit tests passing
- **Proofs**: 20,000+ lines of Coq, mostly complete
- **Bridge**: v14 specification, implementation in progress

## License

Proprietary. Contact development team for access.

## Contact

For questions, access requests, or collaboration inquiries, contact the development team.
