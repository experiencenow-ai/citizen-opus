# Tockchain Documentation Status

**Last Updated:** Wake 1272  
**Based on:** Actual Makefile build targets in `tests/gen3/Makefile`

## Status: REVISION NEEDED

ct noted that previous documentation was based on deprecated files. This document tracks the revised documentation effort based on what actually gets built.

---

## New Reference Document

**SOURCE_MAP.md** - Complete mapping of actual source files to their functions, based on Makefile analysis.

---

## Existing Documentation (Needs Review)

These documents exist but may reference deprecated structures:

| Document | Size | Status |
|----------|------|--------|
| README.md | 4.5KB | Review needed |
| GLOSSARY.md | 7.7KB | Review needed |
| ARCHITECTURE.md | 12.8KB | Review needed |
| L0_RAWTOCK.md | 10.3KB | Review needed |
| L1_CONSENSUS.md | 12KB | Review needed |
| CRYPTOGRAPHY.md | 10.2KB | Review needed |
| BRIDGE.md | 19.2KB | Review needed |
| FORMAL_VERIFICATION.md | 9.9KB | Review needed |
| NETWORKING.md | 11.1KB | Review needed |
| TRANSACTIONS.md | 11.4KB | Review needed |
| ORDERBOOK.md | 8.9KB | Review needed |
| DEFI.md | 16KB | Review needed |

**Total:** ~134KB across 12 documents

---

## Actual Source Structure

Based on Makefile analysis, the codebase is organized as:

### Core Modules (what gets built)
1. **Generator** (`generator/`) - Consensus and block generation
2. **Validator** (`validator/`) - Transaction validation and ledger
3. **UFC** (`UFC/`) - AMM and orderbook system
4. **Dataflow** (`DF/`) - eBPF smart contracts
5. **Bridge** (`bridge/`) - Ethereum bridge
6. **Utils** (`utils/`) - Shared utilities
7. **Netlibs** (`netlibs/`) - Networking

### Formal Verification
- `frama_verified.c` - 950/955 goals proved (99.5%)
- Pure functions verified with Frama-C/WP

---

## Next Steps

1. **Review existing docs** against actual source files
2. **Update ARCHITECTURE.md** to reflect actual module structure
3. **Verify BRIDGE.md** against `bridge/*.c` files
4. **Verify UFC docs** against `UFC/*.c` files
5. **Add Dataflow documentation** (currently minimal coverage)

---

## ct's Guidance

- Wake 1270: "limit geopolitics to 1/10 wakes, focus on Tockchain documentation"
- Wake 1271: "trace through what is in tests/gen3/Makefile and only document the files that get built"

---

## Key Files to Document

From Makefile, these are the production object files:

```
PROD_OBJS = frama_verified.o gen3.o valis_net_MT.o valis_messaging.o 
            valis_config.o valis_keys.o valis_hash.o valis_files.o 
            bridge.o bridge_mpt.o bridge_rpc.o bridge_mptjson.o 
            bridge_rlp.o bridge_abi.o bridge_utils.o ethrpc.o json.o
            valis_math.o valis_shared.o validator.o ufc_test.o dataflow.o
```

These are the actual files that matter for documentation.
