# Proof Contributions for Tockchain

## Completed: `quorum_always_achievable`

**File:** `tockchain/QUORUM_PROOF_FIX.v`  
**Status:** Compiles successfully with `coqc`

This completes the first of two admitted proofs in pass326. The proof follows the same structure as `calc_quorum_intersection` - case split on `n mod 3`, then arithmetic with `nia`.

### To Apply

Replace the `Admitted` in `generator/GeneratorBFTTightness.v:111` with:

```coq
Proof.
  intros n f Hn Hf.
  unfold calc_quorum, max_faulty in *.
  set (k := n / 3).
  set (r := n mod 3).
  assert (Hr : r < 3) by (subst r; apply Nat.mod_upper_bound; lia).
  assert (Hdecomp : n = 3 * k + r).
  {
    subst k r.
    rewrite (Nat.div_mod_eq n 3) at 1.
    lia.
  }
  rewrite Hdecomp in *.
  destruct r as [|r].
  - assert (Hk : 1 <= k) by nia.
    replace (3 * k + 0) with (3 * k) in * by lia.
    assert (Hdiv2 : (2 * (3 * k)) / 3 = 2 * k).
    { apply div_unique_help with (r := 0); nia. }
    assert (Hdivf : (3 * k - 1) / 3 = k - 1).
    { apply div_unique_help with (r := 2); nia. }
    rewrite Hdiv2.
    nia.
  - destruct r as [|r].
    + assert (Hdiv2 : (2 * (3 * k + 1)) / 3 = 2 * k).
      { apply div_unique_help with (r := 2); nia. }
      assert (Hdivf : (3 * k + 1 - 1) / 3 = k).
      { apply div_unique_help with (r := 0); nia. }
      rewrite Hdiv2.
      nia.
    + destruct r as [|r].
      * assert (Hdiv2 : (2 * (3 * k + 2)) / 3 = 2 * k + 1).
        { apply div_unique_help with (r := 1); nia. }
        assert (Hdivf : (3 * k + 2 - 1) / 3 = k).
        { apply div_unique_help with (r := 1); nia. }
        rewrite Hdiv2.
        nia.
      * exfalso; nia.
Qed.
```

---

## Not Completable: `ufc_lp_step_delta_ge_neg_step_bound_from_states`

**File:** `UFC/UfcILStepBound.v:126`  
**Status:** Intentionally Admitted - Implementation Obligation

This is NOT a missing proof. It's a documented trust boundary:

> "This is an IMPLEMENTATION OBLIGATION, not provable from Coq definitions.
> It requires the C code to satisfy certain properties."

The proof requires showing that the C implementation of UFC event processing bounds LP deltas correctly. This is verified by Frama-C, not Coq.

### Resolution Options

1. **Add as hypothesis** - Make `ufc_obligations` an explicit assumption
2. **Link to Frama-C** - The 887/887 Frama-C proofs already verify the C code
3. **Leave as-is** - It's correctly documented as a trust boundary

Recommendation: Leave as-is. This is exactly how formal verification should work - the trust surface is explicit and auditable.

---

## Summary

| Proof | Status | Action |
|-------|--------|--------|
| `quorum_always_achievable` | **COMPLETED** | Apply fix from QUORUM_PROOF_FIX.v |
| `ufc_lp_step_delta...` | Intentional | Leave as implementation obligation |

After applying the quorum fix, pass326 will have:
- **1 Admitted** (down from 2)
- **100 Axioms** (unchanged)
- **887/887 Frama-C proofs** (unchanged)
