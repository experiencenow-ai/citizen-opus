# Tockchain Test Suite Documentation

## Overview

The Tockchain test suite consists of **100,000+ lines** of unit tests across 29 test files in `/tests/`. The tests use a table-driven architecture with a central harness (`ufc_test.c`) that coordinates test execution.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    TEST HARNESS (ufc_test.c)                    │
│  - Table-driven execution                                        │
│  - JSON-based test case definition                               │
│  - L1 state management                                           │
│  - Diff reporting                                                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ #include
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     UNIT TEST MODULES                           │
│                                                                  │
│  units_df.c (5793 lines)      - Dataflow tests                  │
│  units_ufc.c (4211 lines)     - UFC core tests                  │
│  units_deposit.c (6099 lines) - Bridge deposit tests            │
│  units_withdraw.c (5185 lines)- Bridge withdrawal tests         │
│  units_tx.c (4853 lines)      - Transaction tests               │
│  ... (24 more modules)                                          │
└─────────────────────────────────────────────────────────────────┘
```

## Test Files Summary

| File | Lines | Purpose |
|------|-------|---------|
| `bridgetests.c` | 4,337 | Bridge module integration tests |
| `test_sim.c` | 206 | Simulation framework |
| `ufc_test.c` | 2,349 | Main test harness |
| `units_assets.c` | 2,389 | Asset management tests |
| `units_atomic.c` | 1,675 | Atomic operation tests |
| `units_bridge.c` | 2,319 | Bridge unit tests |
| `units_datatx.c` | 2,114 | Data transaction tests |
| `units_deposit.c` | 6,099 | Deposit flow tests |
| `units_df.c` | 5,793 | Dataflow contract tests |
| `units_dfbatch.c` | 4,371 | Dataflow batch processing |
| `units_dfcache.c` | 2,899 | Dataflow cache tests |
| `units_dfmisc.c` | 975 | Dataflow miscellaneous |
| `units_dfscore.c` | 4,220 | Dataflow scoring tests |
| `units_generator.c` | 3,853 | Block generator tests |
| `units_hash.c` | 1,662 | Hash function tests |
| `units_ledger.c` | 1,623 | Ledger state tests |
| `units_maketx.c` | 1,492 | Transaction creation |
| `units_nodechange.c` | 1,493 | Node change tests |
| `units_pylon.c` | 4,873 | Pylon protocol tests |
| `units_ssd.c` | 5,059 | SSD storage tests |
| `units_tx.c` | 4,853 | Transaction processing |
| `units_tx2.c` | 3,645 | Transaction tests (extended) |
| `units_tx3.c` | 5,008 | Transaction tests (advanced) |
| `units_ufc.c` | 4,211 | UFC core unit tests |
| `units_ufc2.c` | 5,556 | UFC extended tests |
| `units_ufc3.c` | 4,605 | UFC advanced tests |
| `units_withdraw.c` | 5,185 | Withdrawal flow tests |
| `vbpf_benchmarks.c` | 2,877 | eBPF performance benchmarks |
| `vbpf_test.c` | 4,591 | eBPF/vBPF unit tests |

**Total: 100,332 lines of test code**

## Test Framework Structure

### Test Arguments Structure

```c
typedef struct ufc_test_args_s {
    struct valisL1_info *L1;      // Ledger state
    uint32_t utime;               // Unix timestamp
    int32_t shard;                // Shard index
    int32_t num_validators;       // Validator count
    int32_t test_index;           // Current test index
    int32_t multiutimes_n;        // Multi-timestamp iterations
    int32_t multiutimes_i;        // Current iteration
    uint32_t multiutimes_step;    // Time step between iterations
    int32_t multigen3_n;          // Multi-generator iterations
    int32_t multigen3_i;          // Current generator iteration
    int32_t multigen3_phase;      // Generator phase
    utime_data_t *gen3_utimes[MAX_VALIDATORS];
    uint8_t gen3_privkeys[MAX_VALIDATORS][32];
    const char *test_name;        // Current test name
} ufc_test_args_t;
```

### Test Function Pattern

All unit tests follow this pattern:

```c
static const char *test_function_name(ufc_test_args_t *args)
{
    // Return test name if args is NULL (discovery phase)
    if (args == 0)
        return "test_case_name";
    
    // Setup
    struct valisL1_info *L1 = args->L1;
    uint32_t utime = args->utime;
    
    // Test logic...
    
    // Return NULL on success, error string on failure
    if (error_condition)
        return "error: description";
    
    return 0;  // Success
}
```

### Multi-Timestamp Tests

Tests prefixed with `MULTIUTIMES ` run across multiple timestamps:

```c
static int32_t ufc_test_is_multiutimes_name(const char *name)
{
    // Checks for "MULTIUTIMES " prefix
    // These tests execute at multiple time points
}
```

### Multi-Generator Tests

Tests prefixed with `MULTIGEN3 ` test across multiple generator configurations:

```c
static int32_t ufc_test_is_multigen3_name(const char *name)
{
    // Checks for "MULTIGEN3 " prefix
    // Tests validator/generator interactions
}
```

## Module-Specific Tests

### Dataflow Tests (`units_df*.c`)

Tests the dataflow (smart contract) system:

- **Deploy tests**: Contract deployment validation
- **Cache tests**: DF cache slot management
- **Batch tests**: Batch processing of DF transactions
- **Score tests**: DF scoring and ranking
- **Trigger tests**: Event-driven execution

Key helper functions:
```c
df_test_dftx_init()           // Initialize DF transaction
df_test_add_unique_dfaddr()   // Create unique DF address
df_test_dftable_slot_reset()  // Reset cache slot
df_test_build_image()         // Build DF bytecode image
df_test_sign_and_submit()     // Sign and submit DF tx
```

### UFC Tests (`units_ufc*.c`)

Tests the Unified Financial Core:

- **Swap tests**: Token swap operations
- **Pool tests**: Liquidity pool management
- **Orderbook tests**: Order matching
- **Planner tests**: Transaction planning
- **OOB tests**: Out-of-band operations

Key helper functions:
```c
ufc_test_atomic_transfer2()      // Atomic balance transfer
ufc_test_seed_balance_no_mint()  // Set balance without minting
ufc_test_sum_balance_all_addrs() // Sum all balances for asset
```

### Bridge Tests (`units_bridge.c`, `units_deposit.c`, `units_withdraw.c`)

Tests the Ethereum bridge:

- **Deposit tests**: ETH/ERC20 deposit processing
- **Withdrawal tests**: Merkle proof generation, withdrawal execution
- **MPT tests**: Merkle Patricia Trie operations
- **RLP tests**: RLP encoding/decoding

Key structures:
```c
withdraw_leaf_t  // Withdrawal leaf data
tmpmem_t         // Temporary memory management
```

### Transaction Tests (`units_tx*.c`)

Tests transaction processing:

- **Creation**: Transaction construction
- **Validation**: Signature and format validation
- **Processing**: Ledger state updates
- **Edge cases**: Invalid transactions, boundary conditions

### Generator Tests (`units_generator.c`)

Tests block generation:

- **Block creation**: Proper block formation
- **Consensus**: Multi-validator agreement
- **Timing**: Timestamp handling
- **State transitions**: Epoch changes

### Hash Tests (`units_hash.c`)

Tests cryptographic hashing:

- **Keccak256**: Ethereum-compatible hashing
- **Performance**: Hash throughput benchmarks
- **Correctness**: Known-answer tests

```c
// Hash function comparison
extern int32_t eth_keccak256(uint8_t *out32, const uint8_t *in, uint64_t len);
extern int32_t turbo_hash_dispatch(uint8_t *out32, const uint8_t *in, uint64_t len);
```

### vBPF Tests (`vbpf_test.c`, `vbpf_benchmarks.c`)

Tests the eBPF virtual machine:

- **Instruction tests**: All eBPF opcodes
- **Memory tests**: Memory access patterns
- **Performance**: Execution benchmarks
- **Safety**: Bounds checking, gas limits

## Running Tests

From the Makefile:
```bash
# Build test binary
make test

# Run all tests
./test

# Run specific test (if supported)
./test test_case_name
```

## Test Coverage Areas

### Core Functionality
- [x] Ledger state management
- [x] Balance tracking
- [x] Transaction processing
- [x] Block generation

### Financial Operations
- [x] Token swaps
- [x] Liquidity pools
- [x] Order matching
- [x] Fee calculation

### Bridge Operations
- [x] Deposit processing
- [x] Withdrawal proofs
- [x] MPT verification
- [x] RLP encoding

### Smart Contracts (Dataflow)
- [x] Contract deployment
- [x] Bytecode execution
- [x] State management
- [x] Event triggers

### Cryptography
- [x] Hash functions
- [x] Signature verification
- [x] Key derivation

### Performance
- [x] Hash benchmarks
- [x] eBPF benchmarks
- [x] Batch processing

## Test Design Principles

1. **Isolation**: Each test manages its own state
2. **Determinism**: Tests produce consistent results
3. **Coverage**: Edge cases and boundary conditions
4. **Performance**: Benchmarks for critical paths
5. **Readability**: Clear test names and error messages

## Adding New Tests

1. Create test function following the pattern:
```c
static const char *my_new_test(ufc_test_args_t *args)
{
    if (args == 0)
        return "my_new_test_name";
    
    // Test logic here
    
    return 0;  // Success
}
```

2. Add to appropriate `units_*.c` file
3. Register in test table (if needed)
4. Rebuild and run

## Related Documentation

- [DOC_validator.md](DOC_validator.md) - Validator module
- [DOC_dataflow.md](DOC_dataflow.md) - Dataflow system
- [DOC_ufc_c.md](DOC_ufc_c.md) - UFC implementation
- [DOC_bridge_c.md](DOC_bridge_c.md) - Bridge module
- [DOC_vbpf.md](DOC_vbpf.md) - eBPF virtual machine
