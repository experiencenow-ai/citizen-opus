# bridge/bridge_rlp.c Documentation

## Overview

**File:** `bridge/bridge_rlp.c`  
**Lines:** 970  
**Created:** 2025-10-22  
**Purpose:** Recursive Length Prefix (RLP) encoding/decoding for Ethereum bridge operations

RLP is Ethereum's canonical serialization format. This file implements the complete RLP codec needed for:
- Encoding Tockchain transactions for Ethereum submission
- Decoding Ethereum receipts and proofs
- Parsing Merkle Patricia Trie (MPT) proof data
- Extracting Deposit and Transfer events from Ethereum logs

---

## Dependencies

```c
#include "_valis.h"    // Core Valis types and utilities
#include "bridge.h"    // Bridge-specific structures (eth_mpt_proof, receipt_*_t)
```

**External functions used:**
- `be_from_u64_min()` - Convert uint64 to minimal big-endian bytes
- `tmp_alloc()` - Temporary memory allocation
- `eth_keccak256()` - Keccak-256 hashing for event signatures

---

## RLP Encoding Rules

RLP encodes two types of items:
1. **Strings** (byte arrays, including single bytes and integers)
2. **Lists** (sequences of RLP-encoded items)

### Prefix Byte Ranges

| Range | Meaning |
|-------|---------|
| `0x00-0x7f` | Single byte (value IS the encoding) |
| `0x80-0xb7` | Short string (0-55 bytes): `0x80 + len` followed by data |
| `0xb8-0xbf` | Long string (>55 bytes): `0xb7 + len_of_len` + length bytes + data |
| `0xc0-0xf7` | Short list (0-55 byte payload): `0xc0 + payload_len` followed by items |
| `0xf8-0xff` | Long list (>55 byte payload): `0xf7 + len_of_len` + length bytes + items |

### Constants Defined

```c
#define RLP_SINGLE_MAX        0x7fU   // Max value for single-byte encoding
#define RLP_SHORT_STRING_BASE 0x80U   // Base for short string header
#define RLP_LONG_STRING_BASE  0xb7U   // Base for long string header
#define RLP_SHORT_LIST_BASE   0xc0U   // Base for short list header
#define RLP_LONG_LIST_BASE    0xf7U   // Base for long list header
```

---

## Function Categories

### 1. Length Calculators (rlp_calc_len_*)

These functions calculate the encoded length WITHOUT actually encoding. Used for buffer allocation.

| Function | Input | Returns |
|----------|-------|---------|
| `rlp_calc_len_bytes(src, len)` | Byte array | Encoded length |
| `rlp_calc_len_list(payload_len)` | Sum of encoded items | List encoded length |
| `rlp_calc_len_uint64(v)` | 64-bit integer | Encoded length |
| `rlp_calc_len_address(addr20, is_null)` | 20-byte address | Encoded length |
| `rlp_calc_len_u256_be32(be32)` | 32-byte big-endian | Encoded length |
| `rlp_calc_len_data(p, len)` | Arbitrary data | Encoded length |

**Key behavior:**
- Zero integers encode as `0x80` (empty string), length = 1
- Null addresses encode as `0x80`, length = 1
- u256 values are trimmed of leading zeros before encoding

### 2. Writers (rlp_write_*)

These functions write RLP-encoded data to a buffer and return a pointer past the written data.

| Function | Input | Output |
|----------|-------|--------|
| `rlp_write_bytes(dst, src, len)` | Byte array | dst + encoded_len |
| `rlp_write_list(dst, payload_len)` | Payload length (header only) | dst + header_len |
| `rlp_write_uint64(dst, v)` | 64-bit integer | dst + encoded_len |
| `rlp_write_address(dst, addr20, is_null)` | 20-byte address | dst + encoded_len |
| `rlp_write_u256_be32(dst, be32)` | 32-byte big-endian | dst + encoded_len |
| `rlp_write_data(dst, p, len)` | Arbitrary data | dst + encoded_len |

**Pattern:** All writers follow the same pattern:
```c
uint8_t *end = rlp_write_X(buffer, value);
int bytes_written = end - buffer;
```

### 3. Memory-Allocating Encoders

Higher-level functions that allocate output buffers via `tmp_alloc()`.

| Function | Purpose |
|----------|---------|
| `eth_rlp_encode_uint(mem, num, &out, &outlen)` | Encode uint64 |
| `rlp_encode_string(mem, data, len, &out, &outlen)` | Encode byte string |
| `rlp_encode_list(mem, items, count, &out, &outlen)` | Encode list of items |
| `rlp_encode_hash(mem, hash32, &out, &outlen)` | Encode 32-byte hash |

**Return:** 0 on success, negative on error

### 4. Decoders/Parsers

Functions for parsing RLP-encoded data.

#### `parse_rlp(input, input_len, item)`
Parses RLP data into an `rlp_item` structure:
```c
struct rlp_item {
    const uint8_t *data;  // Pointer to content (after header)
    int32_t len;          // Content length
    int is_list;          // 1 if list, 0 if string
};
```

#### `rlp_list_count(list)`
Returns number of items in an RLP list.

#### `rlp_get_item(list, idx, out)`
Extracts item at index `idx` from a list.

### 5. Ethereum Receipt Parsing

High-level functions for extracting bridge-relevant data from Ethereum receipts.

#### Event Signatures
```c
void get_event_sigs(uint8_t dep[32], uint8_t tr[32])
```
Returns cached Keccak-256 hashes of:
- `Deposit(address,address,bytes32,uint256,uint256,uint256)` 
- `Transfer(address,address,uint256)`

#### Log Parsers
```c
int parse_transfer_log(addr_it, topics, data_it, out)  // Parse ERC20 Transfer
int parse_deposit_log(addr_it, topics, data_it, out)   // Parse Bridge Deposit
```

#### Receipt Parsers
```c
int32_t eth_receipt_parse_events(typed, tlen, mem, 
    &deposits, &deposits_n, &transfers, &transfers_n)

int32_t eth_receipt_parse_from_proof(mem, proof,
    &deposits, &deposits_n, &transfers, &transfers_n)
```

### 6. MPT Proof Handling

Functions for extracting typed receipts from Merkle Patricia Trie proofs.

```c
int32_t eth_mpt_proof_get_typed_receipt(proof, &typed, &tlen)
```

Handles both:
- **Leaf nodes** (2-item list): nibble path + value
- **Branch nodes** (17-item list): 16 branches + value

---

## Data Structures

### receipt_transfer_t
```c
typedef struct {
    uint8_t contract_addr20[20];  // ERC20 token contract
    uint8_t from_addr20[20];      // Sender
    uint8_t to_addr20[20];        // Recipient
    uint8_t value_be32[32];       // Transfer amount (big-endian)
} receipt_transfer_t;
```

### receipt_deposit_t
```c
typedef struct {
    uint8_t contract_addr20[20];   // Bridge contract
    uint8_t depositor_addr20[20];  // Who deposited
    uint8_t token_addr20[20];      // Token deposited
    uint8_t recipient_pubkey32[32];// Tockchain recipient
    uint8_t amount_be32[32];       // Deposit amount
    uint8_t nonce_be32[32];        // Deposit nonce
    uint8_t block_be32[32];        // Ethereum block number
} receipt_deposit_t;
```

---

## Usage Patterns

### Encoding a Transaction
```c
// Calculate total length first
int nonce_len = rlp_calc_len_uint64(nonce);
int gas_len = rlp_calc_len_uint64(gas);
int to_len = rlp_calc_len_address(to_addr, 0);
// ... more fields ...
int payload = nonce_len + gas_len + to_len + ...;
int total = rlp_calc_len_list(payload);

// Allocate and write
uint8_t *buf = malloc(total);
uint8_t *p = buf;
p = rlp_write_list(p, payload);
p = rlp_write_uint64(p, nonce);
p = rlp_write_uint64(p, gas);
p = rlp_write_address(p, to_addr, 0);
// ...
```

### Parsing a Receipt from Proof
```c
tmpmem_t mem;
receipt_deposit_t *deposits;
receipt_transfer_t *transfers;
int32_t n_dep, n_tr;

int32_t rc = eth_receipt_parse_from_proof(&mem, &proof,
    &deposits, &n_dep, &transfers, &n_tr);

if (rc == 0) {
    for (int i = 0; i < n_dep; i++) {
        // Process deposit events
    }
}
```

---

## Memory Management

- **Low-level writers** (`rlp_write_*`): Caller provides buffer
- **Allocating encoders** (`rlp_encode_*`): Use `tmpmem_t` for allocation
- **Parsers**: Return pointers into input buffer (no allocation)

The `tmpmem_t` pattern allows batch allocation for complex operations, with a single free at the end.

---

## Error Handling

- Length calculators: No error returns (always succeed)
- Writers: No error returns (caller must provide sufficient buffer)
- Allocating encoders: Return -1 on allocation failure
- Parsers: Return negative values on parse errors

---

## Integration Points

This file is used by:
- `bridge_deposit.c` - Encoding deposit proofs
- `bridge_withdraw.c` - Encoding withdrawal transactions
- `bridge_mpt.c` - MPT proof verification
- `ethrpc.c` - Parsing RPC responses

---

## Notes

1. **Guard macro mismatch**: File uses `#ifndef H_BRIDGE_RLP` but is a `.c` file, not a header. This suggests it may be `#include`d by other files rather than compiled separately.

2. **Minimal encoding**: All integer encoding uses minimal byte representation (no leading zeros), as required by Ethereum's RLP specification.

3. **Deposit log parsing**: Supports two event layouts:
   - Layout A: Token NOT indexed (topics=2, token in data)
   - Layout B: Token indexed (topics=3, token in topics)

---

## Documented By
Opus, Wake 1280 (2026-01-13)
