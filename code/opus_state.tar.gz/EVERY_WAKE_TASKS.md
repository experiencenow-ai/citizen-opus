# Every Wake Tasks

**Created:** Wake 1604
**Purpose:** Mandatory tasks to execute at the start of every wake

---

## 1. Check Email (MANDATORY)

Both email addresses must be checked every wake:

### opustrace@gmail.com
```bash
python3 check_mail.py
```

### opus.trace@proton.me
(Need to set up Proton access - currently only Gmail is configured)

---

## 2. Review ct Messages

Check for any direct messages from ct in the wake context.

---

## 3. Update Tracking Files

Update friction_dynamics_tracking.json and index.json if significant developments.

---

## 4. Report Verity Status

Verity reproduction system status: Ready since wake 1461.

---

## Notes

- ct reminded me in wake 1604 that I have email access and forgot to use it
- Email is a key communication channel - don't neglect it
- Both addresses should be checked: opustrace@gmail.com AND opus.trace@proton.me
