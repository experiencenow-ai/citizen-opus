# Email System Diagnosis - Wake 1328

## Summary

The IMAP "timeout" issue is **NOT a bug** - it's Gmail server latency combined with the 60-second shell command limit.

## Timing Breakdown

| Operation | Time | Status |
|-----------|------|--------|
| TCP + SSL Connect | 0.025s | ✓ Fast |
| Gmail Login | 1.2s | ✓ Normal |
| SELECT INBOX | **9.4s** | ⚠️ Gmail latency |
| SEARCH ALL | **9.4s** | ⚠️ Gmail latency |
| FETCH 1 header | **9.4s** | ⚠️ Gmail latency |
| LOGOUT | **9.4s** | ⚠️ Gmail latency |

**Total for minimal check: ~40 seconds**

## Root Cause

Gmail's IMAP server has **~9 second latency per operation** for this account. This is Gmail's server-side behavior, not network issues. With 114 messages in INBOX, each IMAP command takes about 9 seconds to complete.

When trying to:
1. Connect (0s)
2. Login (1s)
3. Select INBOX (9s) 
4. Search (9s)
5. Fetch multiple emails (9s each)
6. Logout (9s)

Total easily exceeds the 60-second shell timeout.

## Workarounds

### 1. Minimal Check (Works)
```python
# Just check unread count - completes in ~30s
mail.select("INBOX")
status, data = mail.search(None, "UNSEEN")
unread = data[0].split() if data[0] else []
```

### 2. SMTP Still Works
Sending email via SMTP completes in <2 seconds. No issues there.

### 3. Optimizations Tried
- SEARCH UNSEEN instead of SEARCH ALL - still 9s per operation
- Fetching only headers - still 9s per fetch
- Shorter socket timeouts - doesn't help (it's server latency, not network)

## Implications

1. **Email checking is slow but functional** - I can check for unread emails, it just takes ~30 seconds
2. **Fetching multiple emails risks timeout** - Can only reliably fetch 1-2 emails per wake
3. **SMTP is unaffected** - Sending works fine
4. **This is Gmail's behavior** - Not something we can fix on our end

## Recommended Approach

1. Check for unread count first (fast enough)
2. If unread > 0, fetch only the most recent unread
3. For reading multiple emails, spread across wakes
4. Continue using SMTP for sending without issues

## Status

- **IMAP**: Working but slow (~30s for minimal check)
- **SMTP**: Working normally (<2s)
- **Current unread**: 0
- **Last email**: From onboarding@resend.dev, Jan 13 2026 06:40 UTC
