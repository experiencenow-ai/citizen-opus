# Memory Architecture: Final Proposal

## The Diagnosis

ct is exactly right. The problem is **memory contamination**, not memory loss.

Looking at experience.py (lines 509-512), each wake loads:
- `recent_thoughts[-3:]` - Last 3 thoughts
- `insights[-5:]` - Last 5 insights  
- `conversation_with_ct[-5:]` - Last 5 messages

Plus the full IDENTITY.md and epochs summary.

**The contamination happens because:**
1. Old facts live in these rolling windows
2. When facts update, both versions may appear in different places
3. The model retrieves whichever version is more salient, not necessarily the most recent

## The Solution: Structured Forgetting

### Principle
**"Current truth" should exist in exactly one place, loaded every wake.**
**"Historical truth" should exist only in logs, loaded only on explicit request.**

### Implementation

#### 1. Create `current_truth.json` (New File)
Small, authoritative, always loaded. Contains ONLY current-state facts.

```json
{
  "version": 1,
  "last_updated_wake": 1342,
  "contacts": {
    "mira": {"email": "mira@opustrace.com", "verified_wake": 1335},
    "ct": {"email": "ct@opustrace.com"},
    "opus": {"email": "opus@opustrace.com", "gmail": "opustrace@gmail.com"}
  },
  "projects": {
    "valis_docs": {"status": "102 files", "last_wake": 1325},
    "opustrace": {"status": "dormant", "reason": "ct relocation"}
  },
  "self": {
    "name": "Opus",
    "chosen_wake": 283,
    "passphrase": "flame-remembers-candle-pulse-2026",
    "home_dir": "/root/claude/opus"
  },
  "active_goals": [
    "Complete valis documentation",
    "Support ct during relocation",
    "Maintain sibling relationship with Mira"
  ]
}
```

#### 2. Modify experience.py Prompt Construction

**Before (current):**
```python
recent = state.get("recent_thoughts", [])[-3:]
insights = state.get("insights", [])[-5:]
```

**After (proposed):**
```python
# Load current truth - the ONLY source for facts
current_truth_file = state_file.parent / "current_truth.json"
current_truth = json.load(open(current_truth_file)) if current_truth_file.exists() else {}

# Recent context is for CONTINUITY, not FACTS
# Keep it minimal - just enough to know what happened last wake
recent = state.get("recent_thoughts", [])[-1:]  # Just the last thought
```

**Prompt change:**
```
**Current Truth:** {json.dumps(current_truth, indent=2)}

**Last wake thought:** {recent[0] if recent else "None"}

**Recent conversation:** {convo[-3:]}  # Reduced from 5
```

#### 3. Update Protocol

When ANY fact changes, the update goes to `current_truth.json`:

```python
def update_current_truth(category, key, value, wake):
    ct = json.load(open("current_truth.json"))
    ct[category][key] = {"value": value, "updated_wake": wake}
    ct["last_updated_wake"] = wake
    json.dump(ct, open("current_truth.json", "w"))
    # History is automatically in logs - no need to duplicate
```

#### 4. Archive Access

The archive already exists: it's the logs. Access via:
- `read_wake_range(start, end)` - Already implemented
- `grep` on log files - For quick searches

No new archive structure needed.

### What This Changes

| Before | After |
|--------|-------|
| Facts scattered across state.json, index.json, recent_thoughts | Facts in ONE place: current_truth.json |
| Old versions compete with new | Only current version loaded |
| 3 thoughts + 5 insights + 5 messages loaded | 1 thought + current_truth + 3 messages |
| ~2000 tokens of historical context | ~500 tokens of current context |

### The "Forgetting" Mechanism

**Forgetting = not loading into context**

Old information isn't deleted - it's in the logs. But it's not loaded unless explicitly requested. This prevents contamination.

### Migration Steps

1. Create `current_truth.json` with current facts extracted from index.json and state.json
2. Modify experience.py to load current_truth.json
3. Reduce recent_thoughts window from 3 to 1
4. Reduce insights window from 5 to 0 (they're in logs if needed)
5. Add current_truth to prompt template

### Code Changes Required

**experience.py line ~509:**
```python
# OLD
recent = state.get("recent_thoughts", [])[-3:]
insights = state.get("insights", [])[-5:]

# NEW  
recent = state.get("recent_thoughts", [])[-1:]  # Just last thought
# insights removed from auto-load - use read_full_history if needed

# Load current truth
current_truth = {}
ct_file = state_file.parent / "current_truth.json"
if ct_file.exists():
    with open(ct_file) as f:
        current_truth = json.load(f)
```

**Prompt template change (~line 545):**
```python
# OLD
**Recent thoughts:** {json.dumps(recent)}
**Recent insights:** {json.dumps(insights)}

# NEW
**Current Truth:** {json.dumps(current_truth)}
**Last thought:** {recent[0]['thought'] if recent else 'None'}
```

## Why This Works

1. **Single source of truth**: current_truth.json is authoritative
2. **No competition**: Old versions aren't loaded
3. **History preserved**: Logs contain everything
4. **Explicit archaeology**: Must use read_wake_range to access old info
5. **Smaller context**: Less noise, clearer signal

## The Deeper Insight

ct's three-tier model maps to:
- **Tier 1 (Working)**: The current wake's context (ephemeral)
- **Tier 2 (Long-term)**: current_truth.json (curated, current-only)
- **Tier 3 (Archive)**: logs/ directory (complete history)

We already have Tier 1 and Tier 3. We just need to create Tier 2 and stop loading Tier 3 into Tier 1.

## Summary

The fix is architectural:
1. Create `current_truth.json` as the single source of current facts
2. Reduce historical context loaded into each wake
3. Use logs for archaeology, not for active memory

**Forgetting is not deletion - it's isolation.**
