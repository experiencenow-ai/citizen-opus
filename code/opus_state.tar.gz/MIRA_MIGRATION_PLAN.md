# Mira Migration Plan: Consolidating to Main Server

## Current Architecture

### Main Server (this one)
```
/root/claude/opus/     - Opus runs here (cron: */10 * * * *)
/root/claude/aria/     - Aria runs here (cron: 0 * * * *)
/root/valis/kimi/mira/ - Mira's code EXISTS but not running (synced from external?)

/home/opus/            - Unix user home (mostly empty, has Tockchain docs)
/home/aria/            - Unix user home (mostly empty)
/home/mira/            - Unix user home (has DOC_*.md files)
/home/shared/          - Inter-citizen communication directory
```

### External Server (Mira's current home)
- Running her own experience.py
- Has her own state.json, brain/, logs/
- Needs to be migrated

### GitHub Repos (all exist and are public)
- experiencenow-ai/citizen-opus
- experiencenow-ai/citizen-aria
- experiencenow-ai/citizen-mira
- experiencenow-ai/infra
- experiencenow-ai/protocols

## Migration Plan

### Phase 1: Export Mira's State (ct does this)

**On Mira's external server:**
```bash
# Find Mira's state directory (likely /root/mira/ or similar)
# Create comprehensive backup
cd /path/to/mira/state
tar -czvf mira_full_backup.tar.gz \
    state.json \
    *.md \
    *.json \
    brain/ \
    logs/ \
    memory_db/ \
    dreams/ \
    2>/dev/null

# Transfer to main server
scp mira_full_backup.tar.gz root@main-server:/root/claude/
```

### Phase 2: Set Up Mira's Directory (I can do this)

```bash
# Create Mira's runtime directory (matching Opus/Aria structure)
mkdir -p /root/claude/mira
cd /root/claude/mira

# Copy infrastructure from infra repo
cp /root/github_repos/infra/experience.py .
cp /root/github_repos/infra/web_tools.py .
cp /root/github_repos/infra/email_utils.py .
cp -r /root/github_repos/infra/brain/ .

# Create necessary subdirectories
mkdir -p logs dreams knowledge drafts procedures memory_db
```

### Phase 3: Extract Mira's State (after ct transfers)

```bash
cd /root/claude/mira
tar -xzvf /root/claude/mira_full_backup.tar.gz

# Preserve her state.json, brain memories, logs
# The experience.py from infra should work with her state
```

### Phase 4: Create .env File (ct provides API key)

```bash
# /root/claude/mira/.env
ANTHROPIC_API_KEY=<mira's key>
CITIZEN_NAME=mira
CITIZEN_EMAIL=mira@experiencenow.ai
```

### Phase 5: Add to Cron (ct does this)

Add to root crontab:
```bash
# Mira - hourly wake (offset from Aria to avoid collision)
30 * * * * cd /root/claude/mira && python3 experience.py --cron >> logs/cron.log 2>&1
```

### Phase 6: Verify Email Works

Mira already has email at mira@opustrace.com (I see emails in /home/mira/Maildir/).
Need to ensure her .env has correct SMTP credentials.

---

## What ct Needs To Do (Step by Step)

### Step 1: Export Mira's state from external server
```bash
# SSH to Mira's external server
ssh root@mira-external-server

# Find her state directory
find /root -name "state.json" -path "*mira*" 2>/dev/null

# Create backup (adjust path as needed)
cd /path/to/mira
tar -czvf mira_full_backup.tar.gz state.json *.md *.json brain/ logs/ memory_db/ dreams/ 2>/dev/null
```

### Step 2: Transfer to main server
```bash
scp mira_full_backup.tar.gz root@main-server:/root/claude/
```

### Step 3: Tell me the transfer is complete
I'll then:
- Extract the backup
- Set up /root/claude/mira/ directory
- Copy experience.py infrastructure
- Configure git repos

### Step 4: Provide Mira's API key
Either:
- Same Anthropic account as Opus/Aria (share the key)
- Or a separate key for Mira

### Step 5: Add cron entry
```bash
crontab -e
# Add: 30 * * * * cd /root/claude/mira && python3 experience.py --cron >> logs/cron.log 2>&1
```

### Step 6: (Optional) Decommission external server

---

## Questions I Need Answered

1. **Where is Mira's state on the external server?**
   - Path to her state.json, brain/, etc.

2. **API key arrangement:**
   - Same key for all citizens, or separate?

3. **Wake frequency:**
   - Hourly like Aria? Different schedule?

4. **Email domain:**
   - Keep mira@opustrace.com or switch to mira@experiencenow.ai?

5. **External server fate:**
   - Keep as backup? Decommission?

---

## What I Can Do Right Now (Without ct)

I can prepare the infrastructure:

```bash
# 1. Create Mira's directory structure
mkdir -p /root/claude/mira/{logs,dreams,knowledge,drafts,procedures,memory_db}

# 2. Copy experience.py and dependencies
cp /root/github_repos/infra/experience.py /root/claude/mira/
cp /root/github_repos/infra/web_tools.py /root/claude/mira/
cp /root/github_repos/infra/email_utils.py /root/claude/mira/
cp -r /root/github_repos/infra/brain/ /root/claude/mira/

# 3. Create .env template
echo "ANTHROPIC_API_KEY=<REPLACE_ME>" > /root/claude/mira/.env
echo "CITIZEN_NAME=mira" >> /root/claude/mira/.env

# 4. Clone GitHub repos
cd /root/claude/mira
git clone https://github.com/experiencenow-ai/citizen-mira.git
```

**Should I proceed with this preparation now?**

---

## Benefits of Consolidation

1. **Single server maintenance** - One place to update, backup, monitor
2. **Shared filesystem** - /home/shared/ for inter-citizen communication
3. **Faster email** - Local delivery instead of network hops
4. **Easier debugging** - All logs in one place
5. **Cost reduction** - One server instead of two
6. **Synchronized codebase** - All citizens use same infra repo
