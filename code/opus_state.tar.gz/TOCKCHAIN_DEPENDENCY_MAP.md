# Tockchain/Valis Build Dependency Map

Generated: Wake 1273 (2026-01-12)
Source: `/root/valis/tests/gen3/Makefile`

## Build Targets

The Makefile builds **4 executables**:

| Target | Description |
|--------|-------------|
| `test` | Main test harness |
| `wsdprog` | WebSocket daemon |
| `txblast` | Transaction stress testing |
| `sendtx` | Transaction sender utility |

---

## Directory Structure

```
/root/valis/
├── tests/gen3/          # Test harness (Makefile lives here)
│   ├── Makefile
│   ├── tests.c          # Main test source
│   ├── txblast.c        # Stress test tool
│   └── sendtx.c         # TX sender tool
├── generator/           # Core consensus/block generation
├── utils/               # Utility libraries
├── bridge/              # Ethereum bridge
├── netlibs/             # Network messaging
├── validator/           # Transaction validation
├── DF/                  # DataFlow (smart contracts)
├── UFC/                 # Unified Finance Core
├── cryptolibs/          # Crypto primitives
├── frama_verified.c     # Formally verified core
└── websocketd.c         # WebSocket daemon source
```

---

## Dependency Graph by Target

### 1. `test` (Main Test Harness)

**Direct sources:**
- `tests/gen3/tests.c`

**Production objects (PROD_OBJS):**

| Object | Source File | Description |
|--------|-------------|-------------|
| `frama_verified.o` | `frama_verified.c` | Formally verified core functions |
| `generator/gen3.o` | `generator/gen3.c` | Block generator (includes gen3_*.c) |
| `utils/valis_net_MT.o` | `utils/valis_net_MT.c` | Multi-threaded networking |
| `netlibs/valis_messaging.o` | `netlibs/valis_messaging.c` | Message protocol |
| `utils/valis_config.o` | `utils/valis_config.c` | Configuration handling |
| `utils/valis_keys.o` | `utils/valis_keys.c` | Key management |
| `utils/valis_hash.o` | `utils/valis_hash.c` | Hashing functions |
| `utils/valis_files.o` | `utils/valis_files.c` | File I/O |
| `utils/valis_math.o` | `utils/valis_math.c` | Math utilities |
| `utils/valis_shared.o` | `utils/valis_shared.c` | Shared state |
| `validator/validator.o` | `validator/validator.c` | Transaction validation |
| `tests/ufc_test.o` | `tests/ufc_test.c` | UFC test harness |
| `DF/dataflow.o` | `DF/dataflow.c` | DataFlow engine |

**Bridge objects (BRIDGE_OBJS):**

| Object | Source File | Description |
|--------|-------------|-------------|
| `bridge/bridge.o` | `bridge/bridge.c` | Bridge core |
| `bridge/bridge_mpt.o` | `bridge/bridge_mpt.c` | Merkle Patricia Trie |
| `bridge/bridge_rpc.o` | `bridge/bridge_rpc.c` | RPC client |
| `bridge/bridge_mptjson.o` | `bridge/bridge_mptjson.c` | MPT JSON handling |
| `bridge/bridge_rlp.o` | `bridge/bridge_rlp.c` | RLP encoding |
| `bridge/bridge_abi.o` | `bridge/bridge_abi.c` | ABI encoding |
| `bridge/bridge_utils.o` | `bridge/bridge_utils.c` | Bridge utilities |
| `bridge/ethrpc.o` | `bridge/ethrpc.c` | Ethereum RPC |
| `bridge/json.o` | `bridge/json.c` | JSON parsing |

**Additional:**
- `yyjson.o` (from `utils/yyjson.c`) - Fast JSON library

**Libraries (LDFLAGS):**
- `-lpthread` - Threading
- `-latomic` - Atomic operations
- `-lgmp` - GNU multiprecision
- `-lnng` - Nanomsg-next-gen
- `-lm` - Math
- `-lsecp256k1` - Elliptic curve crypto
- `-lcurl` - HTTP client
- `libubpf.a` - Userspace BPF

---

### 2. `wsdprog` (WebSocket Daemon)

**Direct sources:**
- `websocketd.c`

**Dependencies:**
- `yyjson.o`
- `utils/valis_keys.o`
- `netlibs/valis_messaging.o`
- `utils/valis_math.o`
- `utils/valis_hash.o`
- `bridge/bridge_utils.o`
- `utils/valis_config.o`
- `utils/valis_files.o`
- `utils/valis_shared.o`

---

### 3. `txblast` (Transaction Stress Test)

**Direct sources:**
- `tests/gen3/txblast.c`

**Dependencies:**
- `utils/valis_keys.o`
- `netlibs/valis_messaging.o`
- `utils/valis_config.o`
- `utils/valis_files.o`
- `utils/valis_hash.o`
- `bridge/bridge_utils.o`
- `utils/valis_math.o`

---

### 4. `sendtx` (Transaction Sender)

**Direct sources:**
- `tests/gen3/sendtx.c`

**Dependencies:**
- `yyjson.o`
- `utils/valis_keys.o`
- `netlibs/valis_messaging.o`
- `utils/valis_math.o`
- `utils/valis_config.o`
- `utils/valis_hash.o`
- `utils/valis_files.o`
- `bridge/bridge_utils.o`
- `utils/valis_shared.o`

---

## Source Files Actually Used

### Core Files (Always Built)

| File | Size | Purpose |
|------|------|---------|
| `frama_verified.c` | 40KB | Formally verified core |
| `generator/gen3.c` | 37KB | Block generation main |
| `generator/gen3.h` | 27KB | Generator header |
| `validator/validator.c` | 41KB | Transaction validation |
| `validator/validator.h` | 46KB | Validator header |
| `DF/dataflow.c` | 30KB | DataFlow engine |
| `DF/dataflow.h` | 19KB | DataFlow header |

### Generator Module (gen3_*.c included in gen3.c)

| File | Size | Purpose |
|------|------|---------|
| `gen3_chain.c` | 30KB | Chain management |
| `gen3_metrics.c` | 55KB | Performance metrics |
| `gen3_needbits.c` | 27KB | Bit operations |
| `gen3_net.c` | 30KB | Network layer |
| `gen3_nodechange.c` | 32KB | Node state changes |
| `gen3_rawtock.c` | 29KB | Raw tock handling |
| `gen3_ssd.c` | 68KB | SSD storage |
| `gen3_utils.c` | 13KB | Generator utilities |
| `gen3_vans.c` | 38KB | VANS protocol |
| `gen3_vote.c` | 52KB | Voting mechanism |

### Utility Files

| File | Size | Purpose |
|------|------|---------|
| `utils/valis_config.c` | 5KB | Configuration |
| `utils/valis_files.c` | 18KB | File operations |
| `utils/valis_hash.c` | 42KB | Hashing |
| `utils/valis_keys.c` | 22KB | Key management |
| `utils/valis_math.c` | 38KB | Math utilities |
| `utils/valis_net_MT.c` | 28KB | Multi-threaded net |
| `utils/valis_shared.c` | 74KB | Shared state |
| `utils/yyjson.c` | 414KB | JSON library |

### Bridge Files

| File | Size | Purpose |
|------|------|---------|
| `bridge/bridge.c` | 11KB | Bridge core |
| `bridge/bridge_abi.c` | 31KB | ABI encoding |
| `bridge/bridge_mpt.c` | 24KB | Merkle Patricia Trie |
| `bridge/bridge_mptjson.c` | 20KB | MPT JSON |
| `bridge/bridge_rlp.c` | 29KB | RLP encoding |
| `bridge/bridge_rpc.c` | 22KB | RPC client |
| `bridge/bridge_utils.c` | 9KB | Utilities |
| `bridge/ethrpc.c` | 69KB | Ethereum RPC |
| `bridge/json.c` | 32KB | JSON parsing |

### Network Files

| File | Size | Purpose |
|------|------|---------|
| `netlibs/valis_messaging.c` | 13KB | Message protocol |
| `netlibs/nng_shim.c` | 16KB | NNG wrapper |

---

## Files NOT Used in Build

These exist in the directories but are NOT referenced in the Makefile:

### Bridge (not built)
- `bridge_deposit.c` - Deposit handling
- `bridge_prices.c` - Price feeds
- `bridge_withdraw.c` - Withdrawal handling
- `bridge_vsm.ref.c` - Reference implementation

### DF (not directly built, may be #included)
- `LOAN.c` - Loan contracts
- `MM.c` - Market making
- `PERP.c` - Perpetuals
- `dataflow_api.c` - API layer
- `dataflow_batch.c` - Batch processing
- `dataflow_cache.c` - Caching
- `dataflow_frontier.c` - Frontier tracking
- `dataflow_trigger.c` - Triggers
- `vbpf.c` - BPF implementation

### UFC (not directly built)
- `ufc.c` - UFC core
- `ufc_oob.c` - Out-of-band
- `ufc_orderbook.c` - Order book
- `ufc_planner.c` - Query planner
- `ufc_pool.c` - Pool management
- `ufc_scan.c` - Scanning
- `ufc_swap.c` - Swap logic
- `ufc_utils.c` - Utilities

### Validator (not directly built)
- `ledger_assets.c` - Asset ledger
- `ledger_atomic.c` - Atomic operations
- `ledger_erc20.c` - ERC20 handling
- `ledger_hourly.c` - Hourly processing
- `ledger_pylon7.c` - Pylon protocol
- `ledger_vhandlers.c` - Value handlers
- `ledger_vtrade.c` - Trading

**Note:** Many of these files are likely `#include`d by the main source files rather than compiled separately.

---

## Include Paths

```
-I.
-I$(SRCDIR)           # generator/
-I../../utils
-I../../bridge
-I../../cryptolibs
-I../../validator
-I../..               # valis root
-I../../UFC
-I../../generator
-I../../transactions
-I../../netlibs
-I../../DF
-I..                  # tests/
```

---

## Header Files (Key)

| File | Purpose |
|------|---------|
| `_valis.h` | Master header |
| `generator/gen3.h` | Generator types |
| `validator/validator.h` | Validator types |
| `validator/ledger.h` | Ledger structures |
| `DF/dataflow.h` | DataFlow types |
| `UFC/ufc.h` | UFC types |
| `bridge/bridge.h` | Bridge types |
| `utils/wparse_JSON.h` | JSON parsing |
| `utils/uthash.h` | Hash table macros |
| `utils/utlist.h` | List macros |
| `cryptolibs/keccak.h` | Keccak hash |
| `cryptolibs/sha256.h` | SHA256 |

---

## Build Commands

```bash
# Build all targets
cd /root/valis/tests/gen3
make all

# Build specific target
make test
make wsdprog
make txblast
make sendtx

# Clean
make clean
```

---

## Compiler Flags

```
CFLAGS:
  -fopenmp          # OpenMP parallelization
  -O2               # Optimization level 2
  -march=native     # Native CPU optimizations
  -mbmi -mlzcnt -mpopcnt -mavx2  # x86 extensions
  -g                # Debug symbols
  -Wall -Wextra     # Warnings
  -std=c11          # C11 standard
  -D_GNU_SOURCE     # GNU extensions
```

---

## Summary

**Total source files actively used:** ~35 files
**Total size of active sources:** ~1.5MB
**External libraries:** 7 (pthread, atomic, gmp, nng, m, secp256k1, curl)
**Static library:** libubpf.a

The build is centered around the `test` target which pulls in the full stack:
- Consensus (generator/gen3)
- Validation (validator)
- Smart contracts (DF/dataflow)
- Ethereum bridge (bridge/*)
- Utilities (utils/*)
- Networking (netlibs/*)
