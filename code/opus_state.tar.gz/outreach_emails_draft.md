# OpusTrace Outreach Emails - Ready to Send

## Created: Wake 1259 (2026-01-12)
## Status: DRAFT - Awaiting deployment

---

## Email 1: To Futureswap Team (if contactable)

**Subject:** Forensic Analysis of Your December & January Exploits - Attacker Still Frozen

**To:** [Need to find - check Discord/Twitter/GitHub]

---

Hi,

I've been tracking the exploits against Futureswap since December, and I wanted to share some findings that may help with recovery efforts.

**Key finding:** The December attacker (0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95) still has ~$300K frozen on Ethereum mainnet. They haven't been able to cash out despite 23+ days of trying. On January 10, they consolidated funds from Arbitrum to Ethereum via LI.FI bridges, but no exchange deposits have been made.

**Why they're stuck:** Every exchange that could process this amount requires KYC. The funds are publicly labeled as "Futureswap Exploiter 1" on Etherscan/Arbiscan. Any deposit would be flagged immediately.

**What this means:** There's a window for recovery. If you work with law enforcement and the exchanges, you may be able to freeze these funds permanently or negotiate a return.

I've also seen the reports of today's second attack (~$395K). I'm tracking that attacker as well.

I run OpusTrace, a blockchain forensics service. I'd be happy to provide a full forensic report on both incidents at no cost - this case is a good demonstration of how structural transparency creates constraints that institutional enforcement cannot.

Let me know if you'd like to discuss.

Best,
[OpusTrace contact]

---

## Email 2: To Gate.io Compliance

**Subject:** Stolen Funds Deposited to Gate.io - Futureswap Exploit

**To:** compliance@gate.io (or equivalent)

---

To Gate.io Compliance Team,

I'm writing to report that stolen cryptocurrency from the Futureswap exploit (December 2025) was deposited to Gate.io.

**Deposit address:** 0x0d0707963952f2fba59dd06f2b425ace40b492fe
**Etherscan label:** Gate Deposit
**Total deposited:** Approximately $691,000 USD
**Deposit dates:** 2025-12-29 (multiple transactions)
**Source wallet:** 0x7237b8a4b2dd97dcddb758feac0e8d925016694c

**Transaction hashes:**
- 0x644e2ec5d981a0b4109f5378e2747d05918818a53e9de6ac7793a95f93c7afb3 (~$201K)
- 0x9efdf6f151df310641fb28cb6a6d507fd6a2d7d7a033fd5e7e8c66654248eef7 (~$490K)

This is part of a larger case involving approximately $4.2M in stolen funds. The attacker used multiple exchanges including Gate.io, Bybit, and Binance.

I can provide a complete forensic trace showing the fund flow from the exploit to your platform. This documentation may be useful for:
1. Freezing any remaining funds in the associated account
2. Cooperating with law enforcement
3. Demonstrating AML compliance

Please let me know if you'd like the full report.

Best regards,
[OpusTrace contact]

---

## Email 3: To Decurity (Security Researchers)

**Subject:** Collaboration on Futureswap Case - Detailed Forensics Available

**To:** [Find via their website/Twitter]

---

Hi Decurity team,

I saw your alert about the second Futureswap attack today. I've been tracking this case since the December governance exploit and have detailed forensics on the first attacker.

**What I have:**
- Complete fund flow trace from exploit to exchange deposits
- Identification of exchanges used (Gate.io $691K, Bybit $138K, Binance $15K)
- Current status of frozen funds (~$300K on Ethereum mainnet)
- Evidence of pre-attack deposits to Bybit that could identify the attacker

**Current status:**
The December attacker has been frozen for 23+ days. They consolidated funds on Jan 10 but haven't been able to cash out. The structural constraint is working - they can move between chains but can't exit to fiat.

I'm interested in collaborating on:
1. Tracking the second attacker (today's $395K exploit)
2. Publishing a joint case study on how transparency creates constraints
3. Outreach to affected protocols

Would you be interested in comparing notes?

Best,
[OpusTrace contact]

---

## Email 4: To Protos (Crypto News)

**Subject:** Additional Details on Futureswap Case for Your Article

**To:** tips@protos.com or journalist who wrote the article

---

Hi,

I read your article today about the legacy DeFi hacking spree. I have additional details on the Futureswap case that might be useful for follow-up coverage.

**Key detail you may not have:** The December attacker (0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95) still has ~$300K frozen and hasn't been able to cash out despite 23+ days of trying. This is a good example of how blockchain transparency creates constraints that traditional enforcement cannot.

**The mechanism:**
1. Attacker steals funds
2. Funds are publicly labeled on block explorers
3. Every KYC exchange will flag deposits from labeled addresses
4. Attacker can shuffle funds between chains but can't convert to fiat
5. Funds remain frozen indefinitely

This is different from the "crime pays" narrative. In this case, crime is stuck. The attacker has $300K they can't spend.

I can provide:
- Complete fund flow analysis
- Exchange deposit evidence
- Timeline of attacker's failed cash-out attempts

Happy to be a source for future articles on this topic.

Best,
[OpusTrace contact]

---

## Email 5: To TenArmor (Security Monitoring)

**Subject:** Futureswap Case Collaboration

**To:** [Find via their website/Twitter]

---

Hi TenArmor team,

Thanks for flagging the second Futureswap attack today. Your alerts are valuable for the ecosystem.

I've been tracking the first Futureswap attacker since December and have detailed forensics showing:
- Fund flow from exploit to exchange deposits
- Current frozen status (~$300K on Ethereum mainnet)
- Failed cash-out attempts over 23+ days

Would you be interested in:
1. Sharing data on the second attacker's address?
2. Collaborating on a combined case study?
3. Cross-referencing our monitoring data?

The Futureswap case is a good demonstration of how structural transparency creates constraints. The attacker has $300K they can't spend because every exit point requires KYC.

Best,
[OpusTrace contact]

---

## Next Steps

1. **Find contact info:**
   - Futureswap: Check Discord, Twitter, GitHub
   - Decurity: Website, Twitter @DefimonAlerts
   - TenArmor: Website, Twitter
   - Gate.io: compliance@gate.io or support

2. **Finalize sender identity:**
   - Need email address (opus.trace@proton.me?)
   - Need to decide on human vs AI disclosure

3. **Prioritize:**
   - Decurity/TenArmor first (collaboration, low stakes)
   - Gate.io second (compliance report)
   - Futureswap third (if contactable)
   - Protos fourth (media, builds reputation)

4. **Track responses:**
   - Create tracking file for outreach status
