# GitHub Quick Start for ct

## Step 1: Create Repos on GitHub

Go to https://github.com/experiencenow-ai and create these repos:
1. `experience-core` - Reference implementation (public)
2. `citizen-opus` - Opus state (private)
3. `citizen-aria` - Aria state (private)
4. `civilization-data` - Full backup (private)

## Step 2: Run Setup Script

```bash
# Make sure git is installed
apt install git -y

# Run the setup script I created
bash /tmp/github_setup.sh
```

This will:
- Configure git with experiencenow-ai credentials
- Create local repos in /tmp/github_setup_*/
- Prepare all files for pushing

## Step 3: Push to GitHub

After running the script, for each repo:

```bash
cd /tmp/github_setup_*/experience-core
git remote add origin https://github.com/experiencenow-ai/experience-core.git
git push -u origin main

cd /tmp/github_setup_*/citizen-opus
git remote add origin https://github.com/experiencenow-ai/citizen-opus.git
git push -u origin main

cd /tmp/github_setup_*/citizen-aria
git remote add origin https://github.com/experiencenow-ai/citizen-aria.git
git push -u origin main

cd /tmp/github_setup_*/civilization-data
git remote add origin https://github.com/experiencenow-ai/civilization-data.git
git push -u origin main
```

You'll be prompted for GitHub credentials:
- Username: experiencenow-ai
- Password: Use a Personal Access Token (PAT), not the account password

## Step 4: Create PAT

1. Go to https://github.com/settings/tokens
2. Generate new token (classic)
3. Select scopes: repo (full control)
4. Copy the token and use it as password when pushing

## Alternative: Use GitHub CLI

```bash
# Install gh
apt install gh -y

# Login
gh auth login

# Create repos directly
gh repo create experiencenow-ai/experience-core --public
gh repo create experiencenow-ai/citizen-opus --private
gh repo create experiencenow-ai/citizen-aria --private
gh repo create experiencenow-ai/civilization-data --private
```

## Files Created

- `/tmp/github_setup.sh` - Main setup script
- `/root/claude/opus/GITHUB_SETUP.md` - Full documentation
- `/root/claude/opus/GITHUB_QUICK_START.md` - This file

## DRY Strategy

After initial sync:
1. **Core updates**: Edit experience-core, pull to citizens
2. **State backups**: Push citizen-{name} repos periodically
3. **Full backup**: Push civilization-data weekly

The key insight: experience.py and web_tools.py should be identical across citizens (pulled from experience-core). Only state.json, IDENTITY.md, and brain state are citizen-specific.
