# TSS (Threshold Signature Scheme) Module Documentation

## Overview

**Directory:** `tss/`  
**Total Lines:** ~10,486  
**Purpose:** Implements threshold signature schemes for multi-party computation (MPC) signing, enabling distributed key generation and signing without any single party holding the complete private key.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `valis_tss.c` | 225 | High-level Valis TSS API wrapper |
| `sig.c` | 1829 | Multi-party signing protocol (GG20) |
| `keygen.c` | 1185 | Distributed key generation |
| `valis_herongen.c` | 1201 | Heron-specific key generation |
| `valis_heronverify.c` | 1850 | Heron signature verification |
| `heronMPC.h` | 809 | MPC protocol definitions |
| `heronglue.h` | 119 | Glue code for Heron integration |
| `libethc.h` | 2406 | Ethereum cryptographic utilities |
| `ethtx.h` | 236 | Ethereum transaction structures |
| `mpcnet.h` | 626 | MPC networking layer |

## Core Concepts

### Threshold Signatures
A (t, n) threshold signature scheme allows:
- n parties to collectively hold a key
- Any t+1 parties can sign
- Fewer than t+1 parties cannot sign or recover the key

### GG20 Protocol
The implementation uses the GG20 (Gennaro-Goldfeder 2020) protocol for ECDSA threshold signatures, which provides:
- Security against malicious adversaries
- Efficient signing with minimal rounds
- Compatible with secp256k1 (Ethereum/Bitcoin curves)

## valis_tss.c - High-Level API

### Constants

```c
#define MAX_PARTIES 128
#define MAX_PARTY_ID_LENGTH 64
#define MAX_SIGN_KEY_SIZE 800000
#define MAX_TSS_THREADS 8  // Global cap
```

### Data Structures

#### `valis_tss_results`
```c
typedef struct {
    int32_t status;           // -3 busy, -2 waiting, 0 init, 1 running, 2 done, -1 error
    int32_t rounds_completed; // Progress tracking
    int32_t msgs_sent;        // Statistics
    int32_t msgs_received;    // Statistics
    time_t start_time;        // Start timestamp
    time_t end_time;          // End timestamp
    int32_t recovery_id;      // Signing: >=0 done; keygen: 0
    void (*callback)(valis_tss_results *this, void *user_data);
    void *user_data;          // For callback
    uint8_t pubkey[65];       // Group pubkey (uncompressed)
    char address[43];         // "0x..." Ethereum address
    int32_t signkey_len;      // Length of key share
    uint8_t sig[64];          // Signature: r (32) + s (32)
    uint8_t flex_data[];      // FAM: binary signkey (keygen)
} valis_tss_results;
```

#### `valis_tss_thread_arg`
```c
typedef struct {
    uint8_t hash[32];                    // Message hash to sign
    valis_tss_results *results;          // Caller-provided results buffer
    char address[43];                    // For key load/store
    int32_t is_keygen;                   // 1 = keygen, 0 = sign
    char workspace_id[64];               // For keygen
    int32_t t, n;                        // Threshold parameters
} valis_tss_thread_arg;
```

### API Functions

#### `valis_tss_query_sizes`
```c
int32_t valis_tss_query_sizes(int32_t num_parties, 
                              int32_t *sign_results_total_size,
                              int32_t *keygen_results_total_size)
```
**Purpose:** Query required buffer sizes for results structures.

**Parameters:**
- `num_parties`: Number of parties in the scheme
- `sign_results_total_size`: Output for signing results size
- `keygen_results_total_size`: Output for keygen results size

**Returns:** 0 on success, -1 if num_parties invalid

#### `load_key`
```c
int32_t load_key(const char *address, valis_tssenv *env)
```
**Purpose:** Load a previously generated key share from disk.

#### `store_key`
```c
int32_t store_key(valis_tssenv *env, const char *workspace_id, 
                  int32_t t, int32_t n, valis_tss_results *results)
```
**Purpose:** Store a newly generated key share to disk and populate results.

## sig.c - Multi-Party Signing

### Constants

```c
#define SIGNKEY_BUFSIZE 500000
#define P2P_BUFFER_SIZE SIGNKEY_BUFSIZE
#define BROADCAST_BUFFER_SIZE 4096
#define SIGNROUNDS 8
#define MAX_MESSAGES_PER_ROUND (1 + MAX_PARTIES)
#define MAX_SIGNMESSAGE_SIZE 65536
#define DEFAULT_BASEPORT 31500
```

### Data Structures

#### `SignMsg`
```c
typedef struct {
    char src[MAX_PARTY_ID_LENGTH];
    uint8_t bc_msg[MAX_SIGNMESSAGE_SIZE];     // Broadcast message
    size_t bc_msg_len;
    uint8_t p2p_msgs[MAX_PARTIES-1][MAX_SIGNMESSAGE_SIZE];  // P2P messages
    size_t p2p_lens[MAX_PARTIES-1];
    char dest_ids[MAX_PARTIES-1][MAX_PARTY_ID_LENGTH];
    int round;
} SignMsg;
```

#### `GG20Context`
```c
typedef struct {
    mpc_eth_context_handle handle;
    const char *party_id, **party_ids;
    SignMsg *queue;
    int32_t num_parties;
    int32_t index;
    char sign_key_base64[MAX_SIGN_KEY_SIZE];
    mpc_cpp_sign_context_handle sign_ctx;
    PartyIncomingQueue signing_queue;
    int pull_sock;
    int push_socks[MAX_PARTIES];
    pthread_mutex_t queue_mutex;
    pthread_t recv_thread;
    uint16_t baseport;
} GG20Context;
```

### Signing Protocol Flow

1. **Initialization**: Load key shares, establish network connections
2. **Round 1-8**: Exchange messages according to GG20 protocol
3. **Aggregation**: Combine partial signatures
4. **Output**: Final (r, s, v) signature

## keygen.c - Distributed Key Generation

### Data Structures

#### `keygenmsg`
```c
struct keygenmsg {
    uint8_t bc_msg[MAX_MESSAGE_SIZE];        // Broadcast message
    size_t bc_msg_len;
    uint8_t p2p_msgs[MAX_PARTIES-1][MAX_P2PMESSAGE_SIZE];  // P2P messages
    size_t p2p_lens[MAX_PARTIES-1];
    char dest_ids[MAX_PARTIES-1][MAX_PARTY_ID_LENGTH];
    int32_t num_p2p_msgs, round;
};
```

#### `InitParamsCopy`
```c
typedef struct {
    char *workspace_id;
    uint32_t threshold;
    int32_t num_parties;
    char **party_ids;
    char **party_indices;
    int curve_type;
} InitParamsCopy;
```

### Key Generation Flow

1. **Setup**: Initialize workspace, establish party connections
2. **Round 1**: Generate and share commitments
3. **Round 2-N**: Exchange Feldman VSS shares
4. **Verification**: Verify all shares are consistent
5. **Output**: Each party has their key share, all know the public key

## Heron Integration

### valis_herongen.c
Generates keys specifically for the Heron bridge protocol, integrating with Valis's bridge architecture.

### valis_heronverify.c
Verifies signatures created by the Heron TSS scheme, ensuring bridge transactions are properly authorized.

## Network Layer (mpcnet.h)

Uses nanomsg for peer-to-peer communication:
- **PUSH/PULL** sockets for reliable message delivery
- **TCP** transport for cross-machine communication
- **IPC** transport for local testing

### Port Allocation
```c
#define DEFAULT_BASEPORT 31500
// Each party uses: baseport + party_index
```

## Cryptographic Dependencies

### libethc.h
Provides Ethereum-compatible cryptographic primitives:
- `eth_keccak256()` - Keccak-256 hashing
- `bin2hex()` / `hex2bin()` - Encoding utilities
- Address derivation from public keys

### secp256k1
External library for elliptic curve operations on the secp256k1 curve.

## Usage Example

### Key Generation
```c
// Allocate results buffer
int32_t sign_size, keygen_size;
valis_tss_query_sizes(3, &sign_size, &keygen_size);
valis_tss_results *results = malloc(keygen_size);

// Start keygen
valis_tss_thread_arg arg = {
    .is_keygen = 1,
    .t = 1,  // threshold
    .n = 3,  // parties
    .results = results
};
strcpy(arg.workspace_id, "keygen_session_1");

// Run keygen (blocking or threaded)
// ... results->pubkey and results->flex_data populated
```

### Signing
```c
// Load key share
load_key("0x1234...", &env);

// Prepare signing
valis_tss_thread_arg arg = {
    .is_keygen = 0,
    .results = results
};
memcpy(arg.hash, message_hash, 32);

// Run signing
// ... results->sig contains (r, s), results->recovery_id contains v
```

## Security Considerations

1. **Key Share Storage**: Key shares must be stored securely; compromise of t+1 shares compromises the key
2. **Network Security**: MPC messages should be encrypted in transit
3. **Abort Handling**: Protocol handles malicious abort but may require restart
4. **Randomness**: Requires high-quality randomness for security

## Integration with Valis

The TSS module is used for:
1. **Bridge Signing**: Multi-party authorization of bridge withdrawals
2. **Validator Keys**: Distributed validator key management
3. **Emergency Recovery**: Multi-sig recovery mechanisms

## Related Files

- `bridge/bridge_withdraw.c` - Uses TSS for withdrawal authorization
- `validator/validator.c` - May use TSS for validator operations
- `gen3/gen3.c` - Generator integration with TSS
