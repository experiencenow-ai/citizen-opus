# LOAN.c Documentation

## Overview

**File**: `DF/LOAN.c`  
**Lines**: ~960  
**Purpose**: Fixed-spread gradient credit system with VCPOOL par window and leveraged VCREDIT lock

LOAN.c implements a single-collateral lending vault dataflow. Each address can have one loan vault that stores collateral and tracks debt. The system uses gradient-based liquidation rather than sudden liquidation thresholds.

## Version

LOAN DF v1.7 — Fixed-Spread Gradient Credit + VCPOOL Par Window + Leveraged VCREDIT Lock  
ABI0 alignment notes (2025-12-18)

## Key Concepts

### Collateral Classes

Three tiers of collateral with different risk parameters:

```c
typedef enum {
    LOAN_CLASS_TIER1     = 0,  // Highest quality (e.g., ETH, BTC)
    LOAN_CLASS_SECONDARY = 1,  // Medium quality
    LOAN_CLASS_VUSD      = 2   // Stablecoin collateral
} loan_coll_class_t;
```

Each class has parameters:
- `ltv_max_bps`: Maximum loan-to-value ratio (basis points)
- `ltv_grad_start_bps`: LTV where gradient deleveraging begins
- `ltv_grad_stop_bps`: LTV where gradient deleveraging stops
- `ltv_liq_bps`: LTV threshold for liquidation
- `rate_min_bps` / `rate_max_bps`: Interest rate bounds
- `spread_bps`: Fixed spread over risk-free rate
- `grad_g_max_ppm`: Maximum deleveraging rate (ppm per second)

### Operating Modes

1. **LIGHT mode**: Scoring-only, no UFC operations, uses cached prices
2. **HEAVY mode**: Full operations including bounded deleveraging/liquidation

### State Storage

All persistent state stored in SRC address registers:

| Register | Purpose |
|----------|---------|
| `LOAN_REG_SCORE` (0) | Packed severity + debt for frontier sorting |
| `LOAN_REG_COLL_QTY` (1) | Collateral quantity |
| `LOAN_REG_DEBT_VC` (2) | VCREDIT debt (principal + interest) |
| `LOAN_REG_HEALTH_BPS` (3) | Health factor 0-10000 |
| `LOAN_REG_RATE_BPS` (4) | APR at last borrow increase |

## Scale Conventions

```c
#define LOAN_SCALE_P         (100000000LL)   // 10^8 for price scaling
#define LOAN_BPS_DENOM       (10000LL)       // Basis points denominator
#define LOAN_PPM_DENOM       (1000000LL)     // Parts per million
#define LOAN_TOCKS_PER_YEAR  (31536000LL)    // Seconds per year
#define LOAN_MIN_PRINCIPAL_VC (1000LL)       // Dust threshold
```

## Core Functions

### Health Calculation

```c
static int64_t loandf_calc_ltv_bps(int64_t debt_vc, int64_t coll_value_vusd)
```
Calculates loan-to-value ratio in basis points.

```c
static int32_t loandf_recompute_health_and_score(df_ctx_t *ctx, int64_t price_scaled)
```
Updates health factor and frontier score based on current collateral value.

### Score Packing

```c
static int64_t loandf_pack_score(int64_t health_bps, int64_t debt_vc)
```
Packs health and debt into 64-bit score for frontier sorting:
- Upper 16 bits: severity (10000 - health_bps)
- Lower 48 bits: debt amount

This ensures unhealthy vaults with larger debt are processed first.

### Interest Accrual

```c
static int32_t loandf_accrue_interest(df_ctx_t *ctx)
```
Accrues interest on debt based on stored APR and elapsed time.

### Rate Calculation

```c
static int32_t loandf_set_rate_on_borrow_increase(df_ctx_t *ctx, const loan_class_params_t *params)
```
Sets interest rate when borrowing increases:
- Base rate = risk-free rate + spread
- Rate increases with LTV (gradient between grad_start and grad_stop)

## User Operations

### Operation Codes

| Code | Operation | Description |
|------|-----------|-------------|
| 1 | Deposit | Transfer collateral to vault |
| 2 | Withdraw | Remove collateral (if health permits) |
| 3 | Borrow | Mint VCREDIT to user |
| 4 | Repay | Par-window repay using VUSD |

### Deposit (op=1)

```c
case 1: /* deposit: transfer collateral from SRC to DF row */
```
- Transfers collateral from user to vault
- Updates `LOAN_REG_COLL_QTY`
- Recomputes health score

### Withdraw (op=2)

```c
case 2: /* withdraw: transfer collateral from DF row to SRC */
```
- Checks withdrawal won't exceed LTV max
- Transfers collateral back to user
- Recomputes health score

### Borrow (op=3)

```c
case 3: /* borrow: mint VCREDIT to SRC */
```
- Checks new LTV won't exceed maximum
- Updates debt register
- Sets interest rate
- Emits VCREDIT borrow event

### Repay (op=4)

```c
case 4: /* repay: par-window repay using VUSD from SRC */
```
- Routes VUSD through VCPOOL par window (1:1)
- Reduces debt
- If debt below dust threshold, closes vault

## Scheduler Integration

### df_on_score

Called by scheduler for frontier processing:

```c
int32_t df_on_score(df_ctx_t *ctx, df_row_t *df_row, uint32_t callflags)
```

In LIGHT mode:
- Uses cached price
- Only recomputes health/score
- No UFC operations

In HEAVY mode:
- Gets fresh price from UFC
- Can execute deleveraging step

### Gradient Deleveraging

Rather than sudden liquidation, the system uses gradient deleveraging:

1. When LTV exceeds `ltv_grad_start_bps`, deleveraging begins
2. Rate increases linearly up to `ltv_grad_stop_bps`
3. At `ltv_liq_bps`, full liquidation occurs
4. `grad_g_max_ppm` limits deleveraging speed

This creates smooth pressure to maintain healthy positions rather than cliff-edge liquidations.

## Safety Mechanisms

### Collateral Sync

```c
static void loandf_sync_coll_qty_to_df_balance(df_ctx_t *ctx, int32_t col_coll)
```
Ensures stored collateral quantity never exceeds actual balance. Protects against accounting errors.

### Overflow Protection

All arithmetic uses `__int128` intermediate values to prevent overflow:

```c
v128 = (__int128)coll_qty * (__int128)price_scaled;
v128 = v128 / (__int128)LOAN_SCALE_P;
```

### Dust Threshold

Positions below `LOAN_MIN_PRINCIPAL_VC` (1000 units) are automatically closed to prevent dust accumulation.

## Configuration Requirements

Must define at compile time:

```c
#ifndef LOAN_COLL_ASSET_ID
#error "Define LOAN_COLL_ASSET_ID to an assetid_t expression (collateral)."
#endif

#ifndef LOAN_VUSD_ASSET_ID
#error "Define LOAN_VUSD_ASSET_ID to an assetid_t expression (VUSD coin)."
#endif
```

## Integration Points

- **df_sdk.h**: Core dataflow SDK functions
- **df_helpers.h**: Helper utilities
- **VCREDIT system**: For borrow/repay events
- **VCPOOL**: For par-window repayment routing
- **UFC**: For price discovery in HEAVY mode

## Design Philosophy

The gradient approach to liquidation represents a key innovation:

1. **No cliff edges**: Borrowers aren't suddenly liquidated at a threshold
2. **Continuous pressure**: Unhealthy positions face increasing costs
3. **Bounded operations**: Each scheduler call does limited work
4. **Frontier sorting**: Worst positions processed first

This creates a more stable lending market that degrades gracefully under stress rather than cascading into mass liquidations.

---

*Documentation generated by Opus at wake 1305*
