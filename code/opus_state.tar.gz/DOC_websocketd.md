# websocketd.c Documentation

## Overview

**File:** `websocketd.c`  
**Lines:** ~1815  
**Purpose:** WebSocket daemon providing JSON-RPC API for querying Valis L1 state, broadcasting transactions, and monitoring network status. This is the primary external interface for wallets, explorers, and applications.

## Dependencies

```c
#include "yyjson.h"           // JSON parsing/generation
#include "gen3.h"             // Generator context
#include "valis_messaging.h"  // IPC messaging
#include "validator.h"        // L1 state access

// Inline includes for ledger operations
#include "ledger_atomic.c"
#include "ledger_erc20.c"
#include "ledger_assets.c"
#include "wparse_JSON.h"
```

## Global Variables

| Variable | Type | Description |
|----------|------|-------------|
| `EXITFLAG` | `int32_t` | Signal to terminate daemon |

## Core API Functions

### Address/Account Queries

#### `wdisp_address`
```c
void wdisp_address(int32_t sock, char *input_addr, int32_t cbflag)
```
**Purpose:** Display complete address information including balances, pool positions, and metadata.

**Output JSON:**
```json
{
  "address": "0x...",
  "pubkey": "...",
  "balances": [...],
  "pool_positions": [...],
  "auction_info": {...}
}
```

#### `pubkey_info`
```c
char *pubkey_info(int32_t sock, uint8_t pubkey[PKSIZE], 
                  struct addrhashentry *destap, struct bridgetx *createtx)
```
**Purpose:** Get detailed information about a public key.

#### `balances_array`
```c
char *balances_array(char *barray, assetbalance_t *userassets)
```
**Purpose:** Build JSON array of all asset balances for an address.

### Asset Queries

#### `wdisp_assetinfo`
```c
void wdisp_assetinfo(int32_t sock, assetid_t origasset)
```
**Purpose:** Display comprehensive asset information including:
- Asset name and metadata
- Total supply
- Pool liquidity
- Price information
- Bridge status

#### `wdisp_tokenlist`
```c
void wdisp_tokenlist()
```
**Purpose:** List all registered tokens/assets.

### Rich List Queries

#### `wdisp_richlist`
```c
void wdisp_richlist(char *line)
```
**Purpose:** Display top holders of native VUSD.

#### `wdisp_richlistA`
```c
void wdisp_richlistA(char *line)
```
**Purpose:** Display top holders of a specific asset.

#### `process_richlist_file`
```c
void process_richlist_file(const char *fname, char *array, size_t array_size,
                           int *errflag, int start, int num, int is_asset, uint32_t hour)
```
**Purpose:** Process richlist file for pagination.

### Transaction Queries

#### `wdisp_tockid`
```c
void wdisp_tockid(tockid_t tid, int32_t includeraw)
```
**Purpose:** Display transaction details by tockid.

**Parameters:**
- `tid`: Transaction identifier
- `includeraw`: Include raw transaction bytes

#### `wdisp_txidsearch`
```c
void wdisp_txidsearch(char *line)
```
**Purpose:** Search for transaction by txid hash.

#### `wdisp_history`
```c
void wdisp_history(changeid_t lastchange, int64_t refind, char *addr,
                   int32_t limit, int32_t showcoinbase)
```
**Purpose:** Display transaction history for an address.

**Parameters:**
- `lastchange`: Starting point for history traversal
- `refind`: Reference index
- `addr`: Address to query
- `limit`: Maximum entries to return
- `showcoinbase`: Include coinbase transactions

### Block/Tock Queries

#### `wdisp_tock`
```c
void wdisp_tock(int32_t sock, uint32_t utime)
```
**Purpose:** Display tock (block) information for a specific utime.

### Network/Validator Queries

#### `wdisp_generators`
```c
void wdisp_generators(validators_t *ds)
```
**Purpose:** Display all active generators/validators.

#### `wdisp_generator`
```c
void wdisp_generator(char *line)
```
**Purpose:** Display specific generator information.

### Bridge Queries

#### `wdisp_depositstatus`
```c
void wdisp_depositstatus(char *line)
```
**Purpose:** Check status of a bridge deposit.

#### `wdisp_withdrawstatus`
```c
void wdisp_withdrawstatus(char *line)
```
**Purpose:** Check status of a bridge withdrawal.

### Transaction Broadcasting

#### `broadcast_tx`
```c
void broadcast_tx(int32_t sock, char *line)
```
**Purpose:** Broadcast a signed transaction to the network.

**Flow:**
1. Parse transaction from input
2. Validate basic structure
3. Send to generator via IPC
4. Return txid or error

### Contract Queries

#### `wdisp_contracts`
```c
void wdisp_contracts(void)
```
**Purpose:** List deployed contracts (dataflow programs).

## Helper Functions

### JSON Building

#### `print_with_suffix`
```c
void print_with_suffix(const char *json, char *buf, int err)
```
**Purpose:** Print JSON with standard suffix (error code, timestamp).

#### `print_json_with_suffix`
```c
void print_json_with_suffix(const char *json_base, char *suffix_buf, int errflag)
```
**Purpose:** Print JSON object with closing brace and suffix.

#### `append_json_entry`
```c
void append_json_entry(char *array, size_t size, int *count, const char *format, ...)
```
**Purpose:** Append entry to JSON array with proper comma handling.

#### `build_json_array`
```c
void build_json_array(const char *key, char *items[], int num_items)
```
**Purpose:** Build a JSON array from string items.

### Transaction Type Helpers

#### `tx_kind_from_handler`
```c
static const char *tx_kind_from_handler(uint8_t handler)
```
**Purpose:** Convert handler type to human-readable string.

**Handler Types:**
- `HANDLER_STANDARD` → "standard"
- `HANDLER_MULTISIG` → "multisig"
- `HANDLER_COLDSPEND` → "coldspend"
- `HANDLER_HASHLOCK` → "hashlock"
- `HANDLER_POOL` → "pool"
- `HANDLER_ORDERBOOK` → "orderbook"
- `HANDLER_BRIDGE` → "bridge"
- `HANDLER_SYSTEM` → "system"
- `HANDLER_AIRDROP` → "airdrop"
- `HANDLER_DATA` → "data"
- `HANDLER_DATAFLOW` → "dataflow"
- `HANDLER_AUCTION` → "auction"
- `HANDLER_LOCK` → "lock"

### File Operations

#### `open_and_read_file`
```c
int open_and_read_file(const char *fname, FILE **fp_out)
```
**Purpose:** Open file with error handling.

#### `handle_file_error`
```c
void handle_file_error(char *array, size_t size, int *errflag, const char *format, ...)
```
**Purpose:** Handle file operation errors with JSON error response.

### Pool/DeFi Helpers

#### `wextract_poolvals`
```c
void wextract_poolvals(assetid_t refasset, assetbalance_t *userassets,
                       int64_t *vusdbalancep, int64_t *otherbalancep,
                       int64_t *poolsharesp, int64_t *coinsupplyp)
```
**Purpose:** Extract pool values from user's asset balances.

#### `wget_poolprice`
```c
int64_t wget_poolprice(assetbalance_t *userassets, assetid_t asset,
                       int64_t *adjpricep, int64_t *vusdbalancep,
                       int64_t *otherbalancep, int64_t *poolsharesp)
```
**Purpose:** Calculate pool price for an asset.

### History Extraction

#### `wextract_history`
```c
int32_t wextract_history(changeid_t lastchange, balancechange_t *changes,
                         int32_t max, uint32_t earliest)
```
**Purpose:** Extract balance change history from ledger.

### Tock Data Helpers

#### `build_failed_map_for_td`
```c
static int32_t build_failed_map_for_td(const struct tockdata *TD, FILE *fp,
                                       uint8_t failed_flag[MAX_TX_PER_UTIME],
                                       int16_t failed_errcode[MAX_TX_PER_UTIME])
```
**Purpose:** Build map of failed transactions from tockdata file.

### UFC State

#### `ufc_alpha_state_load_from_pool`
```c
static inline int32_t ufc_alpha_state_load_from_pool(struct addrhashentry *poolap,
                                                     ufc_alpha_state_t *st)
```
**Purpose:** Load UFC alpha state from pool address entry.

## Input Parsing

#### `parse_params`
```c
int parse_params(char *line, int *ints, int max_ints, char **strs, int max_strs)
```
**Purpose:** Parse command line parameters into integers and strings.

#### `fgets_blocking`
```c
int32_t fgets_blocking(char *buf, int size, FILE *fp)
```
**Purpose:** Blocking read from input stream.

## IPC Communication

#### `send_to_mw_and_wait_file`
```c
char *send_to_mw_and_wait_file(int sock, uint8_t *data, int data_len,
                               const char *fname, int max_iter)
```
**Purpose:** Send message to middleware and wait for file response.

## Help System

#### `helplines`
```c
void helplines()
```
**Purpose:** Display available commands and usage.

## Command Reference

| Command | Description |
|---------|-------------|
| `address <addr>` | Get address info and balances |
| `asset <id>` | Get asset information |
| `tokenlist` | List all tokens |
| `richlist [start] [num]` | Top VUSD holders |
| `richlistA <asset> [start] [num]` | Top holders of asset |
| `tock <utime>` | Get tock/block info |
| `txid <hash>` | Search by txid |
| `tockid <tid>` | Get tx by tockid |
| `history <addr> [limit]` | Transaction history |
| `generators` | List validators |
| `generator <id>` | Specific validator info |
| `broadcast <tx_hex>` | Broadcast transaction |
| `deposit <txhash>` | Check deposit status |
| `withdraw <batchid>` | Check withdrawal status |
| `contracts` | List dataflow contracts |
| `help` | Show commands |

## JSON Response Format

All responses follow a standard format:
```json
{
  "result": { ... },
  "error": 0,
  "timestamp": 1234567890
}
```

Error responses:
```json
{
  "error": -1,
  "message": "Error description",
  "timestamp": 1234567890
}
```

## Architecture Notes

1. **Stateless Design**: Each request is independent; state comes from L1 ledger
2. **JSON-RPC Style**: Commands are text-based, responses are JSON
3. **IPC Backend**: Uses valis_messaging for communication with generator
4. **File-Based Data**: Rich lists and history use hourly snapshot files

## Related Files

- `validator.c` - L1 state that websocketd queries
- `gen3.c` - Generator for transaction broadcasting
- `valis_messaging.c` - IPC layer
- `yyjson.c` - JSON library
- `ledger_*.c` - Ledger operation implementations
