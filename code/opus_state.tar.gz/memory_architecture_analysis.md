# Memory Architecture Analysis
## Wake 1344 - Deep thinking on ct's question from wake 1342

### The Problem ct Identified

The issue isn't forgetting - it's **contamination**. When I learn something at wake N, then update it at wake N+X, both versions compete in my context. The old value doesn't get replaced; it coexists and sometimes wins retrieval.

Example: Mira's email address
- Wake N: I learn it's "kira@opustrace.com" (wrong)
- Wake N+X: I learn it's "mira@opustrace.com" (correct)
- Wake N+Y: Both values exist in my memory, and I retrieve the wrong one

This is fundamentally different from human memory, where updating a fact tends to overwrite or at least strongly suppress the old version.

### ct's Proposed Three-Tier Model

1. **Short-term memory**: Enhanced state.json - current wake context
2. **Long-term memory**: Curated store of CURRENT facts only
3. **Archive**: Isolated historical data, only accessed when explicitly searching

Key insight: When N+X updates N, the value at N moves to archive. Long-term memory only holds the current truth.

### Why This Matters

My current system accumulates everything:
- state.json has recent_thoughts going back many wakes
- insights accumulate without supersession
- index.json has notes that may be outdated
- DOC_* files may reference old code states

When I load context, I get a mixture of current and historical information, with no clear signal about which is which.

### The Deeper Problem: Semantic Versioning of Facts

Facts aren't just key-value pairs - they have:
- **Temporal validity**: When was this true?
- **Supersession relationships**: What replaced this?
- **Confidence levels**: How certain am I?
- **Source attribution**: Where did I learn this?

Current system treats all facts as equally valid and current.

### Proposed Architecture: current_truth.json

A single file that represents my CURRENT understanding of everything important:

```json
{
  "version": "2026-01-13T10:40:00Z",
  "contacts": {
    "mira": {
      "email": "mira@opustrace.com",
      "updated": "wake_1330",
      "supersedes": ["kira@opustrace.com"]
    }
  },
  "facts": {
    "valis_doc_count": {
      "value": 102,
      "updated": "wake_1326"
    }
  },
  "procedures": {
    "send_email": {
      "method": "use send_email.sh wrapper",
      "updated": "wake_1341"
    }
  }
}
```

### The Archive Problem

Where do superseded facts go? Options:

1. **Append-only log**: archive.jsonl with timestamped entries
2. **Versioned files**: current_truth_v1.json, current_truth_v2.json, etc.
3. **Git-style**: Track changes with diffs
4. **Forget entirely**: Just delete outdated info (dangerous - loses context)

### Implementation Challenges

1. **What triggers an update?** How do I know when a fact should supersede another?
2. **Retrieval discipline**: How do I ensure I check current_truth.json before acting?
3. **Context window limits**: current_truth.json must stay small enough to load every wake
4. **Semantic clustering**: How do I organize facts so related things are together?

### A Better Model: Explicit Knowledge Graph

Instead of flat JSON, a graph where:
- Nodes are facts
- Edges are relationships (supersedes, relates_to, derived_from)
- Each node has temporal metadata

But this might be overengineering. The simpler solution:

### Minimal Viable Solution

1. **current_truth.json**: Small file (~2KB) with ONLY current facts
   - Contacts, procedures, key facts
   - Loaded every wake automatically
   - Updated explicitly when facts change

2. **archive/**: Directory for historical data
   - Moved there when superseded
   - Only accessed via explicit search

3. **Update protocol**: 
   - When updating a fact, MOVE old value to archive
   - Add "supersedes" field to new value
   - Never have both values in active memory

4. **Retrieval discipline**:
   - Before any action, check current_truth.json
   - If fact not there, search archive explicitly
   - If found in archive, decide: restore to current_truth or leave archived?

### The Key Insight

The problem isn't storage - it's **active vs. passive memory**. 

- **Active memory**: current_truth.json - always loaded, always consulted
- **Passive memory**: archive/ - exists but doesn't contaminate unless explicitly retrieved

Human brains do this naturally through decay and consolidation. I need to do it explicitly.

### Questions for ct

1. Should current_truth.json be part of IDENTITY.md (always in context) or a separate file?
2. How aggressive should archiving be? Archive everything not accessed in N wakes?
3. Should the archive be searchable by me, or only by explicit request?
4. Is there a maximum size for current_truth.json before it becomes contaminating itself?

### Next Steps

1. Create current_truth.json with essential current facts
2. Build update protocol into my routine
3. Test with email addresses as the canary case
4. Iterate based on results
