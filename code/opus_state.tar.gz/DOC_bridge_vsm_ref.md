# bridge_vsm.ref.c Documentation

**File:** `bridge/bridge_vsm.ref.c`  
**Lines:** 674  
**Purpose:** Valis Smart Module (VSM) and Valis Withdrawal Reader (VWR) interface - ABI-level wrappers for on-chain contract interactions

---

## Overview

This file provides the C interface to Valis smart contracts deployed on Ethereum. It wraps low-level ABI encoding/decoding into clean function calls for:

1. **VSM (Valis Smart Module)** - The main bridge contract handling deposits, withdrawals, and batch execution
2. **VWR (Valis Withdrawal Reader)** - Read-only contract for Merkle proof verification and root queries

The file uses the `vabi` (Valis ABI) helper system from `bridge_abi.c` to construct Ethereum call data and parse results.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    bridge_vsm.ref.c                         │
├─────────────────────────────────────────────────────────────┤
│  VSM Functions          │  VWR Functions                    │
│  ─────────────────────  │  ──────────────────────────────   │
│  vsm_refund_tip_only()  │  vwr_get_root()                   │
│  vsm_refund_multiplier_ │  vwr_verify_proof()               │
│  vsm_refund_overhead_   │  vwr_get_root_at_index()          │
│  vsm_refund_cap_wei_    │                                   │
│  vsm_batch_executed()   │                                   │
│  vsm_leaf_executed()    │                                   │
│  vsm_executed_mask()    │                                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      vabi helpers                            │
│  vabi_call_bool_0()  vabi_call_u16_0()  vabi_call_u32_0()   │
│  vabi_call_u64_u64arg()  vabi_eth_call_hex_result()         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Ethereum RPC                              │
│              eth_call / eth_getBlockByNumber                 │
└─────────────────────────────────────────────────────────────┘
```

---

## Function Selectors

The file defines 4-byte function selectors for contract calls:

### VSM Selectors (defined in bridge.h)
| Selector | Function | Description |
|----------|----------|-------------|
| `VSM_SEL_refundTipOnly` | `refundTipOnly()` | Returns bool - tip-only refund mode |
| `VSM_SEL_refundMultiplierBps` | `refundMultiplierBps()` | Returns uint16 - basis points multiplier |
| `VSM_SEL_refundOverheadGas` | `refundOverheadGas()` | Returns uint32 - overhead gas amount |
| `VSM_SEL_refundCapWei` | `refundCapWei()` | Returns uint256 - max refund cap |
| `VSM_SEL_refundGasPriceCapWei` | `refundGasPriceCapWei()` | Returns uint256 - gas price cap |
| `0x2314bf23` | `batchExecuted(uint64)` | Check if batch LCI executed |
| `0x4f05c1df` | `executedMask(uint64)` | Get execution bitmask for batch |

### VWR Selectors
| Selector | Function | Description |
|----------|----------|-------------|
| `VWR_SEL_getRoot` | `getRoot()` | Get current Merkle root |
| `VWR_SEL_verifyProof` | `verifyProof(...)` | Verify Merkle inclusion proof |

---

## VSM Functions

### Refund Configuration Getters

```c
int vsm_refund_tip_only(const char *module_hex, int *tip_only_out);
```
- **Purpose:** Check if module only refunds tips (not base fee)
- **Returns:** 0 on success, -1 on error
- **Output:** `*tip_only_out` = 1 if tip-only mode, 0 otherwise

```c
int vsm_refund_multiplier_bps(const char *module_hex, uint16_t *bps_out);
```
- **Purpose:** Get refund multiplier in basis points (100 bps = 1%)
- **Returns:** 0 on success, -1 on error
- **Output:** Multiplier value (e.g., 10000 = 100% refund)

```c
int vsm_refund_overhead_gas(const char *module_hex, uint32_t *overhead_out);
```
- **Purpose:** Get fixed gas overhead added to refund calculation
- **Returns:** 0 on success, -1 on error

```c
int vsm_refund_cap_wei_low64(const char *module_hex, uint64_t *cap_low64_out);
```
- **Purpose:** Get maximum refund cap in wei (low 64 bits of uint256)
- **Note:** Full 256-bit support would require big-int container

```c
int vsm_refund_gasprice_cap_wei_low64(const char *module_hex, uint64_t *cap_low64_out);
```
- **Purpose:** Get maximum gas price cap for refund calculation

### Batch Execution Status

```c
int vsm_batch_executed(const char *module_hex, uint64_t lci, int *out_true);
```
- **Purpose:** Check if a batch (identified by LCI - Ledger Commit Index) has been executed
- **Parameters:**
  - `module_hex`: Contract address (0x-prefixed hex)
  - `lci`: Ledger Commit Index identifying the batch
  - `out_true`: Output - 1 if executed, 0 if not
- **Returns:** 0 on success, negative on error

```c
int vsm_leaf_executed(const char *module_hex, uint64_t lci, uint8_t leaf_index, int *out_true);
```
- **Purpose:** Check if specific leaf within a batch has been executed
- **Parameters:**
  - `leaf_index`: Index of leaf within batch (0-63 typically)
- **Use Case:** Partial batch execution tracking

```c
int vsm_executed_mask(const char *module_hex, uint64_t lci, uint64_t *mask_out);
```
- **Purpose:** Get bitmask of which leaves in a batch have been executed
- **Output:** 64-bit mask where bit N = 1 means leaf N is executed

---

## VWR Functions

### Merkle Root Operations

```c
int vwr_get_root(const char *reader_hex, uint8_t out_root32[32]);
```
- **Purpose:** Get current Merkle root from reader contract
- **Output:** 32-byte root hash
- **Use Case:** Verify withdrawal proofs against current state

```c
int vwr_get_root_at_index(const char *reader_hex, uint64_t index, uint8_t out_root32[32]);
```
- **Purpose:** Get historical Merkle root at specific index
- **Use Case:** Verify proofs against historical state

### Proof Verification

```c
int vwr_verify_proof(const char *reader_hex,
                     const uint8_t leaf32[32],
                     const uint8_t root32[32],
                     const uint8_t (*proof32)[32],
                     int proof_len,
                     uint64_t index,
                     int *ok_out);
```
- **Purpose:** Verify Merkle inclusion proof on-chain
- **Parameters:**
  - `leaf32`: 32-byte leaf hash to verify
  - `root32`: 32-byte expected root
  - `proof32`: Array of 32-byte proof elements
  - `proof_len`: Number of proof elements
  - `index`: Leaf index in tree
  - `ok_out`: Output - 1 if proof valid, 0 if invalid
- **Returns:** 0 on success, negative on RPC/encoding error

**ABI Encoding Details:**
```
verifyProof(bytes32 leaf, bytes32 root, bytes32[] proof, uint256 index)
- Head: 4 words (leaf, root, proof_offset, index)
- Tail: proof array (length + elements)
```

---

## Gas Estimation System

The file includes an internal gas estimator for withdrawal operations:

### State Structure
```c
static struct vwr_gas_estimator_state_s {
    uint64_t ema_gas_per_leaf;    // Exponential moving average
    uint64_t sample_count;        // Number of samples
} _vwr_gas_state;
```

### EMA Calculation
- Uses `VWR_EMA_DEN = 64` as denominator
- Formula: `new_ema = (old_ema * 63 + sample) / 64`
- Provides smoothed gas estimates for batch planning

### Helper Functions
```c
static int _vwr_bitlen_u64(uint64_t x);        // Bit length of value
static bool _vwr_is_contiguous_ones(uint64_t x); // Check if bits are contiguous
```

---

## Block Timestamp Helper

```c
static int vsm_eth_latest_block_timestamp(uint64_t *ts_out);
```
- **Purpose:** Get timestamp of latest Ethereum block
- **Use Case:** Tier computation for time-based logic
- **Implementation:** Delegates to `ethrpc.c` `get_latest_block_timestamp()`

---

## Error Handling

All functions follow consistent error return pattern:
- `0`: Success
- `-1`: Invalid parameters (NULL pointers, out of range)
- `-2` to `-7`: Specific encoding/decoding/RPC errors

Error codes help diagnose where in the call chain failure occurred:
- `-2`: Selector push failed
- `-3`: Buffer allocation failed
- `-4`: Dynamic array encoding failed
- `-5`: Argument encoding failed
- `-6`: RPC call failed
- `-7`: Result parsing failed

---

## Integration Points

### Dependencies
- `bridge.h`: Selector definitions, types
- `bridge_abi.c`: vabi_* encoding/decoding functions
- `ethrpc.c`: Low-level Ethereum RPC calls
- `yyjson`: JSON parsing for RPC responses

### Used By
- `bridge_withdraw.c`: Withdrawal execution and verification
- `bridge_deposit.c`: Deposit status checking
- `gen3_*.c`: Generator batch planning

---

## Design Notes

1. **uint256 Truncation:** Functions returning uint256 values only capture low 64 bits. This is acceptable for gas prices and most practical values but would need extension for full token amounts.

2. **Selector Centralization:** All function selectors are defined in one place to avoid duplication and ensure consistency.

3. **Process-Local State:** Gas estimator state is static/process-local, not thread-safe. Each process maintains its own EMA.

4. **Reference Implementation:** The `.ref.c` suffix suggests this may be a reference implementation, with production code potentially using different patterns.

---

## Example Usage

```c
// Check if batch 12345 has been executed
int executed;
if (vsm_batch_executed("0x1234...module", 12345, &executed) == 0) {
    if (executed) {
        printf("Batch already processed\n");
    }
}

// Verify a withdrawal proof
uint8_t leaf[32], root[32];
uint8_t proof[10][32];
int valid;
if (vwr_verify_proof("0x5678...reader", leaf, root, proof, 10, 42, &valid) == 0) {
    if (valid) {
        printf("Proof verified!\n");
    }
}
```

---

*Documentation generated by Opus, Wake 1321*
