# valis_heronverify.c Documentation

**File:** `/root/valis/tss/valis_heronverify.c`  
**Lines:** 1850  
**Module:** TSS (Threshold Signature Scheme)  
**Purpose:** Distributed threshold signing using Heron MPC protocol

---

## Overview

`valis_heronverify.c` implements the distributed signing protocol for threshold signatures. Multiple parties collaborate to produce a valid signature without any single party having access to the complete private key.

This is the **signing half** of the TSS system (the other half being `valis_herongen.c` for key generation).

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Threshold Signing Flow                        │
│                                                                  │
│  Input: Message Hash (32 bytes)                                  │
│                                                                  │
│  Party 0          Party 1          Party 2          Party N     │
│    │                │                │                │          │
│    ├── Round 0 ─────┼────────────────┼────────────────┤          │
│    │                │                │                │          │
│    ├── Round 1 ─────┼────────────────┼────────────────┤          │
│    │                │                │                │          │
│    ...              ...              ...              ...        │
│    │                │                │                │          │
│    ├── Round 7 ─────┼────────────────┼────────────────┤          │
│    │                │                │                │          │
│    ▼                ▼                ▼                ▼          │
│                                                                  │
│  Output: ECDSA Signature (r, s, v)                               │
│  (All parties produce identical signature)                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `SIGNKEY_BUFSIZE` | 500000 | Buffer for signing key |
| `MAX_SIGN_KEY_SIZE` | 500000 | Alias |
| `P2P_BUFFER_SIZE` | 500000 | P2P message buffer |
| `BROADCAST_BUFFER_SIZE` | 4096 | Broadcast message buffer |
| `MAX_PARTY_ID_LENGTH` | 64 | Party ID string max |
| `SIGNROUNDS` | 8 | Number of signing protocol rounds |
| `MAX_MESSAGES_PER_ROUND` | 1 + MAX_PARTIES | Messages per round |
| `MAX_SIGNMESSAGE_SIZE` | 65536 | Max signing message |
| `MAX_PARTIES` | 128 | Maximum parties |
| `MAX_GG20_SIZE` | sizeof(IncomingMsg) | GG20 message size |
| `DEFAULT_BASEPORT` | 31500 | Default communication port |

---

## Data Structures

### SignMsg

Outgoing signing message structure.

```c
typedef struct {
    char src[MAX_PARTY_ID_LENGTH];           // Source party ID
    uint8_t bc_msg[MAX_SIGNMESSAGE_SIZE];    // Broadcast message
    size_t bc_msg_len;                       // Broadcast length
    uint8_t p2p_msgs[MAX_PARTIES-1][MAX_SIGNMESSAGE_SIZE];  // P2P messages
    size_t p2p_lens[MAX_PARTIES-1];          // P2P lengths
    char dest_ids[MAX_PARTIES-1][MAX_PARTY_ID_LENGTH];      // Destinations
    int round;                               // Protocol round
} SignMsg;
```

### IncomingMsg

Incoming message queue node (linked list).

```c
typedef struct IncomingMsg {
    struct IncomingMsg *prev, *next;         // utlist pointers
    char src[MAX_PARTY_ID_LENGTH];           // Source party
    char bc_msg[MAX_SIGNMESSAGE_SIZE];       // Broadcast content
    size_t bc_msg_len;                       // Broadcast length
    char p2p_msg[MAX_SIGNMESSAGE_SIZE];      // P2P content
    size_t p2p_msg_len;                      // P2P length
    int round;                               // Protocol round
} IncomingMsg;
```

### PartyIncomingQueue

Per-round message queues.

```c
typedef struct {
    IncomingMsg *queue[SIGNROUNDS];          // Queue per round
} PartyIncomingQueue;
```

### GG20Context

Full context for a signing party.

```c
typedef struct {
    mpc_eth_context_handle handle;           // MPC library handle
    const char *party_id;                    // This party's ID
    const char **party_ids;                  // All party IDs
    SignMsg *queue;                          // Outgoing message queue
    int32_t num_parties;                     // Total parties
    int32_t index;                           // This party's index
    char sign_key_base64[MAX_SIGN_KEY_SIZE]; // Signing key shard
    size_t len;                              // Key length
    mpc_cpp_sign_context_handle sign_ctx;    // Signing context
    PartyIncomingQueue signing_queue;        // Incoming messages
    
    // Network
    int pull_sock;                           // Receive socket
    int push_socks[MAX_PARTIES];             // Send sockets
    int baseport;                            // Base port
    const char **ip_addresses;               // Peer addresses
    int barrier_status[MAX_PARTIES];         // Barrier sync
    
    // Threading
    pthread_t recv_thread;                   // Receive thread
    pthread_mutex_t queue_mutex;             // Queue protection
} GG20Context;
```

### valis_tss_manager

High-level TSS manager for multiple concurrent signatures.

```c
typedef struct {
    int32_t max_sigs;                        // Max concurrent signatures
    int32_t active_sigs;                     // Currently active
    valis_tssenv sig_envs[];                 // FAM: per-signature environments
} valis_tss_manager;
```

### tssparams

Parameters for a signing round (with flexible array for P2P data).

```c
typedef struct {
    int32_t num_parties;                     // Party count
    int32_t max_p2p_size;                    // Max P2P message size
    int32_t bc_len;                          // Broadcast length (out)
    char out_bc[BROADCAST_BUFFER_SIZE];      // Broadcast message (out)
    tssparty_info p2pdata[1];                // FAM: per-party P2P info
    char flex_data[];                        // FAM: P2P message buffers
} tssparams;
```

---

## Key Functions

### run_single_party_signing

```c
int32_t run_single_party_signing(
    int party_index,
    int num_parties,
    const char **party_ids,
    const char **ip_addresses,
    int baseport,
    const char *m_hex,
    char *r_hex,
    char *s_hex,
    int *recovery_id,
    const char *party_file
);
```

**Purpose:** Execute signing for a single party.

**Parameters:**
- `party_index`: This party's index
- `num_parties`: Total parties participating
- `party_ids`: Array of party identifier strings
- `ip_addresses`: Array of peer IP addresses
- `baseport`: Base port for communication
- `m_hex`: Message hash to sign (hex string)
- `r_hex`: Output - signature r component (65 chars)
- `s_hex`: Output - signature s component (65 chars)
- `recovery_id`: Output - Ethereum recovery ID (v value)
- `party_file`: Path to signing key file

**Flow:**
1. Allocate and initialize GG20Context
2. Setup sockets (pull for receive, push for each peer)
3. Initialize mutex and start receive thread
4. Initialize signing context via `init_party_signing()`
5. Execute 8 signing rounds via `perform_party_signing_round_threaded()`
6. After each round: barrier sync with `nanomsg_barrier()` and `wait_for_barrier()`
7. Extract signature via `mpc_cpp_sign_get_signature()`
8. Validate signature
9. Cleanup resources

---

### generate_signature

```c
int generate_signature(
    int launcher_mode,
    int port,
    int baseport,
    int index,
    int num_parties,
    const char **participants,
    const char *m_hex,
    char *r_hex,
    char *s_hex,
    int *recovery_id,
    const char *party_file
);
```

**Purpose:** Main entry point for signature generation.

**Modes:**
- **Launcher mode (launcher_mode=1 or port>=0)**: Single party process
- **All-in-one mode**: All parties in one process (testing)

---

### init_party_signing

```c
int init_party_signing(
    GG20Context *party,
    const char **participants,
    int num_participants,
    const char *m_hex,
    const char *party_file
);
```

**Purpose:** Initialize signing context for a party.

**Actions:**
1. Load signing key from file
2. Initialize MPC signing context
3. Set message hash to sign

---

### perform_party_signing_round_threaded

```c
int perform_party_signing_round_threaded(GG20Context *party, int round);
```

**Purpose:** Execute one round of the signing protocol.

**Rounds (0-7):**
- Generate round messages
- Send to peers (broadcast + P2P)
- Receive from peers
- Process received messages
- Update MPC state

---

### init_mpc_signing

```c
int32_t init_mpc_signing(
    int32_t *party_index_out,
    int32_t *num_parties_out,
    char ***party_ids_out,
    char ***ip_addresses_out,
    int32_t *baseport_out,
    int32_t *threshold_out,
    const char *party_file,
    const char *valis_conf_path
);
```

**Purpose:** Initialize MPC signing from configuration files.

**Actions:**
1. Parse party file for participants
2. Extract baseport and threshold
3. Read local party ID from valis.conf
4. Find this party's index
5. Allocate and return configuration

---

### validate_signature

```c
int32_t validate_signature(
    const char *m_hex,
    const char *r_hex,
    const char *s_hex,
    int recovery_id,
    const char *party_file
);
```

**Purpose:** Verify the generated signature is valid.

**Verification:**
1. Recover public key from signature
2. Compare with expected public key from party file
3. Return 0 if valid

---

## Network Functions

### setup_sockets

```c
int setup_sockets(GG20Context *party, int port, int baseport);
```

Setup nanomsg PULL socket for receiving and PUSH sockets for sending.

### cleanup_sockets

```c
void cleanup_sockets(GG20Context *party);
```

Close all sockets.

### gg20_recv

```c
void *gg20_recv(void *arg);
```

Receive thread - continuously receives messages and queues them by round.

### send_signmessage

```c
void send_signmessage(GG20Context *party, int dest_idx, SignMsg *msg);
```

Send a signing message to a specific peer.

### nanomsg_barrier

```c
void nanomsg_barrier(GG20Context *party, int round);
```

Send barrier message to all peers.

### wait_for_barrier

```c
void wait_for_barrier(GG20Context *party, int round);
```

Wait until all peers have reached the barrier.

---

## Protocol Flow

### GG20 Signing Protocol (8 Rounds)

```
Round 0: Commitment
├── Generate random nonce k_i
├── Compute commitment C_i = H(g^{k_i})
└── Broadcast C_i

Round 1: Nonce Share
├── Reveal g^{k_i}
├── Verify against commitments
└── Compute combined nonce point R

Round 2-5: MPC Computation
├── Feldman VSS for nonce shares
├── Multiplicative-to-additive conversion
├── Compute partial signatures
└── Exchange proofs

Round 6: Signature Assembly
├── Combine partial signatures
├── Compute final s value
└── Verify signature locally

Round 7: Finalization
├── Exchange final signatures
├── Verify all parties have same result
└── Output (r, s, v)
```

### Barrier Synchronization

```
Party 0                Party 1                Party 2
   │                      │                      │
   │── BARRIER_0 ────────►│                      │
   │── BARRIER_0 ─────────┼─────────────────────►│
   │◄── BARRIER_0 ────────│                      │
   │                      │── BARRIER_0 ────────►│
   │◄── BARRIER_0 ────────┼──────────────────────│
   │                      │◄── BARRIER_0 ────────│
   │                      │                      │
   │ (all proceed to round 1)                    │
```

---

## File Formats

### Party File Format

```
-b 31500 -t 2
Party1 192.168.1.1
Party2 192.168.1.2
Party3 192.168.1.3
```

First line: options (`-b` baseport, `-t` threshold)
Following lines: party_id ip_address

### Signing Key File

Located at: `subseeds/{eth_address}/{party_id}.key`

Contains base64-encoded signing key shard generated during keygen.

---

## Integration Points

### Dependencies
- `libethc.h`: Ethereum utilities
- `ethtx.h`: Transaction types
- `wrapper.h`: MPC library wrapper
- `utlist.h`: Linked list macros
- `nanomsg`: Network messaging
- `secp256k1`: Elliptic curve
- `websockets.h`: WebSocket support
- `valis.h`: Core Valis types
- `bip39.h`: Mnemonic support
- `maketx.c`: Transaction building (included)

### Used By
- `valis_tss.c`: High-level async API
- `bridge_withdraw.c`: Withdrawal signing
- `validator.c`: Block attestations

### Requires
- Signing key shards from `valis_herongen.c`
- Party configuration file
- Network connectivity between parties

---

## Security Considerations

1. **Key Protection**: Signing key shards must be stored securely
2. **Network Security**: Messages between parties should be encrypted
3. **Threshold**: Only t parties needed to sign - compromise of t-1 is safe
4. **Replay Protection**: Each signing session should use unique nonces
5. **Signature Validation**: Always verify signature after generation

---

## Error Handling

| Return Value | Meaning |
|--------------|---------|
| 0 | Success |
| -1 | General error |
| -2 | Socket error |
| -3 | Thread error |
| -4 | MPC error |
| -5 | Key load error |

---

## Usage Example

```c
// Initialize from config
int32_t party_index, num_parties, baseport, threshold;
char **party_ids, **ip_addresses;
init_mpc_signing(&party_index, &num_parties, &party_ids, &ip_addresses,
                 &baseport, &threshold, "subseeds/0x1234.keygen", "valis.conf");

// Sign a message
char r_hex[65], s_hex[65];
int recovery_id;
const char *message_hash = "0x1234..."; // 32-byte hash as hex

int ret = run_single_party_signing(
    party_index, num_parties, party_ids, ip_addresses,
    baseport, message_hash, r_hex, s_hex, &recovery_id,
    "subseeds/0x1234.keygen"
);

if (ret == 0) {
    // Success: r_hex, s_hex, recovery_id contain signature
    // Ethereum signature: v = 27 + recovery_id
}
```

---

## Notes

1. File structured as header but contains full implementation
2. `maketx.c` is `#include`d for transaction building
3. Comments at top list all functions and required modifications from base sig.c
4. Global `Parties` array used for all-in-one mode testing
5. `_UTIME_NOW` global for timestamp coordination

---

**Documentation generated:** Wake 1320  
**Last code review:** 2026-01-13
