# UFC Pool Module Documentation

**File:** `UFC/ufc_pool.c`  
**Lines:** 371  
**Module:** UFC (Unified Financial Core)  
**Documented by:** Opus (Wake 1304)

---

## Overview

The UFC Pool module manages liquidity pool operations - deposits, redemptions, and pool state queries. It implements the core AMM (Automated Market Maker) pool mechanics where users can provide liquidity and receive pool share tokens in return.

---

## Key Concepts

### Pool Structure
Each asset (except VUSD) has an associated liquidity pool containing:
- **VUSD Balance**: The stablecoin side of the pool
- **Other Balance**: The asset side (e.g., VNET, bridged tokens)
- **Pool Shares**: Total LP tokens outstanding
- **Pool Address**: Deterministic address derived from asset ID

### Pool Shares
LP tokens represent proportional ownership of pool assets:
- Minted on deposit
- Burned on redemption
- Track ownership without tracking individual deposits

---

## Core Functions

### Pool State Queries

#### `get_poolptr()`
```c
struct addrhashentry *get_poolptr(struct valisL1_info *L1, assetid_t asset)
```

**Purpose:** Get the address hash entry for an asset's pool.

**Process:**
1. Validate asset (not VUSD, must be ASSET_COIN)
2. Derive pool public key via `set_poolpub()`
3. Look up in address hash table

**Returns:** Pool address entry or NULL if not found.

#### `get_poolvals()`
```c
struct addrhashentry *get_poolvals(struct valisL1_info *L1, assetid_t asset,
                                    int64_t *vusdbalancep, int64_t *otherbalancep,
                                    int64_t *poolsharesp, int64_t *coinsupplyp)
```

**Purpose:** Get pool pointer and all balance values in one call.

**Outputs:**
- Pool address entry
- VUSD balance in pool
- Other asset balance in pool
- Total pool shares outstanding
- Asset's total coin supply

#### `extract_poolvals()`
```c
int64_t extract_poolvals(struct valisL1_info *L1, struct addrhashentry *pool,
                          assetid_t poolasset, int64_t *vusdbalancep,
                          int64_t *totalpoolsharesp)
```

**Purpose:** Extract pool values from an already-known pool pointer.

**Returns:** Other asset balance (or negative error code).

#### `get_poolprice()`
```c
int64_t get_poolprice(struct valisL1_info *L1, assetid_t asset)
```

**Purpose:** Get current pool price for an asset.

**Algorithm:**
1. Check cached `ufc_price` in L1->assets
2. If not cached, calculate from pool balances
3. Apply vcredit price cap if applicable

**Returns:** Price in satoshis per unit.

---

### Pool Deposit

#### `pooldeposit()`
```c
int64_t pooldeposit(int32_t actualflag, struct valisL1_info *L1,
                    struct addrhashentry *srcptr, struct addrhashentry *pool,
                    assetid_t src, int64_t amount, assetid_t dest,
                    int64_t poolvusdbalance, int64_t poolotherbalance,
                    int64_t poolshares, tockid_t tid, int64_t amount2,
                    ufc_planned_transfer_t plan[], int32_t *plan_count)
```

**Purpose:** Deposit assets into pool, receive LP tokens.

**Parameters:**
- `actualflag`: 0 = simulation, 1 = execute
- `srcptr`: Depositor's address
- `pool`: Pool address
- `src`: Source asset being deposited
- `amount`: Amount of source asset
- `dest`: Pool asset (determines which pool)
- `amount2`: Optional second asset amount (for dual-sided deposits)
- `plan/plan_count`: Transfer plan output

**Algorithm:**
1. Validate inputs and determine deposit amounts (dx_vusd, dy_other)
2. Get UFC price and OOB price for valuation
3. Calculate TVL before deposit
4. Compute deposit value in VUSD terms
5. For existing pools:
   - Target 50/50 balance
   - Calculate excess on one side
   - Apply price adjustment for imbalanced deposits
   - Compute effective value considering slippage
6. Calculate new shares proportional to value added
7. Generate transfer plan if actualflag=1

**Returns:** New shares minted (or negative error code).

**Key Feature:** Imbalanced deposits (single-sided) are penalized via the excess calculation, encouraging balanced liquidity provision.

---

### Pool Redemption

#### `poolredeem()`
```c
int64_t poolredeem(int32_t actualflag, struct valisL1_info *L1,
                   struct addrhashentry *destptr, struct addrhashentry *pool,
                   assetid_t poolasset, int64_t shares,
                   int64_t poolvusdbalance, int64_t poolotherbalance,
                   int64_t poolshares, tockid_t tid, int64_t vusdpercentage,
                   ufc_planned_transfer_t plan[], int32_t *plan_count)
```

**Purpose:** Redeem LP tokens for underlying pool assets.

**Parameters:**
- `destptr`: Recipient address
- `shares`: Number of LP tokens to redeem
- `vusdpercentage`: Optional - convert some other asset to VUSD (0-SATOSHIS scale)

**Algorithm:**
1. Validate share amount and pool state
2. Check minimum LP supply constraint
3. Calculate proportional slice (floor rounding - pool keeps dust)
4. Generate transfer plan:
   - Burn pool's POOLSHARES
   - Burn user's pool tokens
   - Transfer VUSD to user
   - Transfer other asset to user
5. If vusdpercentage > 0, add swap of other→VUSD

**Returns:** VUSD value of redemption (or negative error code).

**Key Feature:** The `vusdpercentage` parameter allows atomic redemption + swap, useful for users who want to exit entirely to VUSD.

---

### Transaction Validation

#### `pool_tx_common_precheck()`
```c
int32_t pool_tx_common_precheck(struct valisL1_info *L1, const struct txheader *txH,
                                 tockid_t tid, int32_t sigstatus,
                                 const struct pooltx **out_ptx,
                                 struct addrhashentry **out_fundsptr,
                                 int64_t *out_balance)
```

**Purpose:** Common validation for pool transactions.

**Validates:**
- Transaction structure
- Signature status
- Funds availability

---

## Constants

| Constant | Purpose |
|----------|---------|
| `UFC_MIN_LP_SUPPLY` | Minimum LP tokens that must remain (prevents dust pools) |
| `BPS_DENOM` | Basis points denominator (10000) |
| `SATOSHIS` | Price scaling factor |
| `MAXASSETS` | Maximum number of assets |

---

## Mathematical Operations

- `ufc_mul_div_floor(a, b, c)`: (a × b) / c with floor rounding
- `ufc_mul_div_ceil(a, b, c)`: (a × b) / c with ceiling rounding
- `calc_price(vusd, other)`: Calculate spot price from balances
- `calc_pool_price()`: Calculate pool price with state lookup

---

## Transfer Planning

Pool operations use a transfer plan system:
```c
typedef struct {
    struct addrhashentry *from;
    struct addrhashentry *to;
    assetid_t asset;
    int64_t amount;
} ufc_planned_transfer_t;
```

This allows:
1. Simulation (actualflag=0) to check validity
2. Atomic execution of multiple transfers
3. Clear audit trail of balance changes

---

## Data Flow

```
User Request (deposit/redeem)
         │
         ▼
┌─────────────────┐
│ Validation      │  ← Check balances, shares, constraints
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Value Calc      │  ← TVL, prices, share math
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Transfer Plan   │  ← Build atomic transfer list
└────────┬────────┘
         │
         ▼
   Execute if actualflag=1
```

---

## Integration Points

- **ufc.h**: Type definitions and constants
- **validator.h**: Transaction validation
- **ufc_swap.c**: Swap operations (used in redemption with vusdpercentage)
- **ledger_*.c**: Balance updates via transfer plan execution

---

## Design Notes

1. **Floor Rounding**: Redemptions use floor rounding, so pools accumulate dust over time (favorable to remaining LPs)

2. **Minimum LP Supply**: Prevents pools from being drained to zero, which could cause division issues

3. **Imbalanced Deposit Penalty**: Single-sided deposits get fewer shares due to the excess calculation, incentivizing balanced liquidity

4. **Atomic Operations**: Transfer plans ensure all-or-nothing execution

5. **Price Capping**: vcredit assets have price caps applied to prevent manipulation

---

## Error Codes

| Code | Meaning |
|------|---------|
| -1 | Zero amount |
| -2 | Invalid asset ID |
| -3 | Negative pool balance |
| -4 | Invalid source asset |
| -5 | Negative pool balance (redeem) |
| -6 | Zero output amounts |
| -9 to -15 | Various calculation failures |
| -900 | Null transaction header |
