# ebpf.h & ubpf.h - eBPF Virtual Machine Headers

**Location:** `/root/valis/DF/ebpf.h`, `/root/valis/DF/ubpf.h`  
**Lines:** 236 + 633 = 869  
**Source:** Big Switch Networks (Apache 2.0 License)  
**Purpose:** eBPF instruction set definitions and userspace VM interface

---

## Overview

These headers define the interface to uBPF (userspace BPF), which Tockchain uses for executing dataflow programs. eBPF is a safe, sandboxed bytecode format originally designed for Linux kernel packet filtering but now used for general-purpose safe execution.

---

## ebpf.h - Instruction Set Definitions

### Instruction Format
```c
struct ebpf_inst {
    uint8_t opcode;
    uint8_t dst : 4;    // Destination register
    uint8_t src : 4;    // Source register
    int16_t offset;     // Memory offset
    int32_t imm;        // Immediate value
};
```
Each instruction is exactly 8 bytes.

### Registers
```c
enum bpf_register {
    BPF_REG_0 = 0,   // Return value
    BPF_REG_1,       // Argument 1 / scratch
    BPF_REG_2,       // Argument 2 / scratch
    BPF_REG_3,       // Argument 3 / scratch
    BPF_REG_4,       // Argument 4 / scratch
    BPF_REG_5,       // Argument 5 / scratch
    BPF_REG_6,       // Callee-saved
    BPF_REG_7,       // Callee-saved
    BPF_REG_8,       // Callee-saved
    BPF_REG_9,       // Callee-saved
    BPF_REG_10,      // Stack pointer (read-only)
};
```

### Instruction Classes
- `EBPF_CLS_LD` (0x00) - Load immediate
- `EBPF_CLS_LDX` (0x01) - Load from memory
- `EBPF_CLS_ST` (0x02) - Store immediate
- `EBPF_CLS_STX` (0x03) - Store from register
- `EBPF_CLS_ALU` (0x04) - 32-bit arithmetic
- `EBPF_CLS_JMP` (0x05) - 64-bit jumps
- `EBPF_CLS_JMP32` (0x06) - 32-bit jumps
- `EBPF_CLS_ALU64` (0x07) - 64-bit arithmetic

### ALU Operations
```c
EBPF_ALU_OP_ADD  // Addition
EBPF_ALU_OP_SUB  // Subtraction
EBPF_ALU_OP_MUL  // Multiplication
EBPF_ALU_OP_DIV  // Division
EBPF_ALU_OP_OR   // Bitwise OR
EBPF_ALU_OP_AND  // Bitwise AND
EBPF_ALU_OP_LSH  // Left shift
EBPF_ALU_OP_RSH  // Right shift (logical)
EBPF_ALU_OP_NEG  // Negation
EBPF_ALU_OP_MOD  // Modulo
EBPF_ALU_OP_XOR  // Bitwise XOR
EBPF_ALU_OP_MOV  // Move
EBPF_ALU_OP_ARSH // Arithmetic right shift
```

### Jump Operations
```c
EBPF_JMP_OP_JA   // Jump always
EBPF_JMP_OP_JEQ  // Jump if equal
EBPF_JMP_OP_JGT  // Jump if greater than
EBPF_JMP_OP_JGE  // Jump if greater or equal
EBPF_JMP_OP_JSET // Jump if bits set
EBPF_JMP_OP_JNE  // Jump if not equal
EBPF_JMP_OP_JSGT // Jump if signed greater than
EBPF_JMP_OP_JSGE // Jump if signed greater or equal
EBPF_JMP_OP_CALL // Function call
EBPF_JMP_OP_EXIT // Return
```

---

## ubpf.h - VM Interface

### Configuration
```c
#define UBPF_MAX_INSTS 65536                    // Max instructions per program
#define UBPF_MAX_CALL_DEPTH 8                   // Max nested calls
#define UBPF_EBPF_STACK_SIZE (UBPF_MAX_CALL_DEPTH * 512)  // Total stack
#define UBPF_EBPF_LOCAL_FUNCTION_STACK_SIZE 256 // Stack per function
```

### VM Lifecycle
```c
struct ubpf_vm* ubpf_create(void);              // Create VM instance
void ubpf_destroy(struct ubpf_vm* vm);          // Destroy VM instance
```

### Loading Programs
```c
int ubpf_load(struct ubpf_vm* vm, const void* code, uint32_t code_len, char** errmsg);
int ubpf_load_elf(struct ubpf_vm* vm, const void* elf, size_t elf_len, char** errmsg);
int ubpf_load_elf_ex(struct ubpf_vm* vm, const void* elf, size_t elf_len, 
                     const char* main_section, char** errmsg);
```

### Execution
```c
// Interpreted execution
int ubpf_exec(const struct ubpf_vm* vm, void* mem, size_t mem_len, uint64_t* bpf_return_value);

// JIT compilation
ubpf_jit_fn ubpf_compile(struct ubpf_vm* vm, char** errmsg);

// JIT function types
typedef uint64_t (*ubpf_jit_fn)(void* mem, size_t mem_len);
typedef uint64_t (*ubpf_jit_ex_fn)(void* mem, size_t mem_len, uint8_t* stack, size_t stack_len);
```

### Helper Functions
```c
// Register external helper function
int ubpf_register(struct ubpf_vm* vm, unsigned int idx, const char* name, 
                  void* fn);

// Set instruction limit
void ubpf_set_instruction_limit(struct ubpf_vm* vm, uint32_t limit, 
                                uint32_t* previous_limit);
```

### Bounds Checking
```c
typedef bool (*ubpf_bounds_check)(void* context, uint64_t addr, uint64_t size);
void ubpf_set_pointer_secret(struct ubpf_vm* vm, uint64_t secret);
```

---

## Why eBPF for Dataflow?

### Safety Properties
1. **Bounded execution** - Programs must terminate (no infinite loops)
2. **Memory safety** - All memory accesses are bounds-checked
3. **Type safety** - Register types are tracked
4. **No arbitrary jumps** - Only forward jumps allowed

### Verification
Programs can be statically verified before execution:
- All code paths terminate
- No out-of-bounds memory access
- No division by zero
- Stack doesn't overflow

### Performance
- JIT compilation to native code
- Minimal overhead for bounds checks
- Efficient register-based design

---

## Integration with Tockchain

### vbpf.c
Wraps uBPF with Tockchain-specific:
- Helper functions for blockchain operations
- Memory layout for dataflow state
- Gas metering

### Dataflow Programs
User-submitted programs are:
1. Compiled to eBPF bytecode
2. Verified for safety
3. Executed in sandboxed VM
4. Gas-metered for resource limits

---

## Related Files

| File | Relationship |
|------|--------------|
| `DF/vbpf.c` | Tockchain's eBPF wrapper |
| `DF/dataflow.c` | Dataflow execution engine |
| `ubpf/` | Full uBPF library source |

---

*Documentation generated by Opus, Wake 1319*
