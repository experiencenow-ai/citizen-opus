# Valis Tockchain - Complete Technical Specification

**Version 1.0 | January 2026**

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Architecture](#2-system-architecture)
3. [Generator (GEN3)](#3-generator-gen3)
4. [Validator (L1)](#4-validator-l1)
5. [UFC - Unified Fair Clearing](#5-ufc---unified-fair-clearing)
6. [Bridge (ETH ↔ Valis)](#6-bridge-eth--valis)
7. [Pylon - Post-Quantum Security](#7-pylon---post-quantum-security)
8. [Dataflow - Financial Machine](#8-dataflow---financial-machine)
9. [Competitive Analysis](#9-competitive-analysis)
10. [Appendix: Code Organization](#appendix-code-organization)

---

## 1. Executive Summary

Valis ("Tockchain") is a high-performance blockchain designed for financial applications with formal verification guarantees. Key innovations:

- **1-second tock cadence**: Deterministic time-based blocks
- **Three-level consensus**: Cryptographic ordering prevents manipulation
- **UFC hybrid DEX**: Zero impermanent loss, no AMM curves
- **Pylon security**: Post-quantum resistant hash-chain authentication
- **Formal verification**: Coq proofs for critical components

### Design Philosophy

Every blockchain makes tradeoffs across six dimensions:
1. **Consensus** - How transactions are ordered
2. **Selection** - How validators evolve
3. **Transport** - How data propagates
4. **Execution** - How state transitions
5. **Security** - How attacks are prevented
6. **Economics** - How value flows

Tockchain is architected for leadership in all six.

---

## 2. System Architecture

### 2.1 High-Level Components

```
┌─────────────────────────────────────────────────────────────┐
│                    TOCKCHAIN ARCHITECTURE                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │  Generator   │───▶│  Validator   │───▶│    State     │  │
│  │   (GEN3)     │    │    (L1)      │    │   (Ledger)   │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│         │                   │                    │          │
│         ▼                   ▼                    ▼          │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Network    │    │     UFC      │    │   Bridge     │  │
│  │   (VNET)     │    │  (Clearing)  │    │  (ETH↔L1)    │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Component Responsibilities

| Component | Purpose |
|-----------|---------|
| **Generator (GEN3)** | Collects txs, builds VANs, runs elections, produces rawtock |
| **Validator (L1)** | Executes txs deterministically, maintains state, produces tockdata |
| **UFC** | Hybrid DEX: pool swaps, orderbook, premium routing |
| **Bridge** | ETH deposits → L1 mints, L1 burns → ETH withdraws |
| **Dataflow** | Generic financial contract engine |
| **Pylon** | Hash-chain second factor for PQ security |

### 2.3 Time Model

Tockchain operates on **utimes** (Unix timestamps in seconds):

- Each second is a **tock**
- Transactions are batched into **VANs** (Valis Aggregated Network packets)
- Consensus finalizes ordering per-tock
- State transitions are deterministic given finalized rawtock

---

## 3. Generator (GEN3)

### 3.1 Purpose

The generator transforms incoming transactions into canonical **rawtock** files:

1. **Admission**: Decide which txs are admitted (normal vs VIP)
2. **Packing**: Group txs into VANs with Merkle roots
3. **Elections**: Reach consensus on vanshash/finalhash
4. **Output**: Produce rawtock file + Q files per utime

### 3.2 Key Data Structures

#### utime_data_t (Per-tock state)
```c
typedef struct {
    uint32_t utime;
    uint8_t ustate;           // NEW_UTIME, ADMIT_NORMAL, ADMIT_VIP_ONLY, etc.
    van_t *vans[MAX_VANS];    // Transaction containers
    valis_election_t elections[NUM_QIDX];
    metrics_t metrics;
} utime_data_t;
```

#### VAN Structure
```c
typedef struct {
    van_header_t header;      // Metadata, tx count, source node
    tx_t txs[];               // Packed transactions
    txid_t txids[];           // Transaction identifiers
} van_t;
```

### 3.3 Election System (QIDX)

Elections use Byzantine fault-tolerant voting:

| QIDX | Purpose |
|------|---------|
| QIDX_VANSHASH | Consensus on transaction set |
| QIDX_FINALHASH | Final ordering hash |
| QIDX_RAWTOCK | Rawtock availability |
| QIDX_NODECHANGE | Validator set evolution |
| QIDX_ETHHEADER | Ethereum block header |
| QIDX_TOCKDATAHASH | State transition hash |

### 3.4 Three-Level Determinism

**Level 1 - Rawtock Ordering:**
- Transactions arrive and batch into VANs
- Validators reach consensus on `vanshash`
- Transaction set is cryptographically locked before execution

**Level 2 - Transaction Striding:**
- Txs evaluated in parallel against read-only snapshot
- Stride order derived from `finalhash`
- Sequence unpredictable until after consensus

**Level 3 - DataFlow Striding:**
- Smart contract execution order from `finalhash`
- Prevents manipulation of contract ordering

Result: Parallel evaluation with serial commit, ordering determined by cryptographic randomness.

### 3.5 Nodechange (Validator Evolution)

Algorithmic Darwinism - protocol measures node performance:
- Lag (network latency)
- Bandwidth (throughput capacity)
- CPU (processing speed)

When candidate outperforms incumbent:
```c
SYSTEMTX_PROMOTE_CANDIDATE  // Automatic swap
```

No votes, no politics - pure meritocracy. Network self-upgrades as hardware improves.

---

## 4. Validator (L1)

### 4.1 Purpose

The L1 execution engine processes finalized rawtocks:

1. Verify tx signatures and structure
2. Apply txs deterministically to state
3. Maintain hourly snapshots
4. Track assets, bridge, UFC, addresses
5. Produce tockdata with `tockdatahash`

### 4.2 Main Loop

```c
void validator_main() {
    // 1. Initialize config, directories, topology
    // 2. Create L1 context, link to GEN3
    // 3. Choose startup mode (genesis/fast-start/vonly)
    // 4. Start background threads (ETHloop, etc.)
    
    while (running) {
        new_utime = L1->processedutime + 1;
        
        // Wait for generator to finish utime
        wait_for_rawtock(new_utime);
        
        // Validate and load rawtock
        validate_rawtockfile(new_utime);
        
        // Wait for tockdatahash election
        L1consensus(QIDX_TOCKDATAHASH);
        
        // Process the tock
        L1process_tock(L1, new_utime);
        
        // Housekeeping
        update_hourly_state();
        sweep_dust();
        prune_old_data();
    }
}
```

### 4.3 State Structure

```c
typedef struct valisL1_info {
    // Core state
    uint32_t processedutime;
    addrhash_t *addrhash;     // Address hash table
    
    // Subsystems
    ufc_state_t *UFC;         // Clearing engine
    bridge_state_t *BRIDGE;   // ETH bridge
    df_state_t *DF;           // Dataflow contracts
    
    // Aggregates
    STATE_t STATE;            // Global counters
    tockdata_t tockdata;      // Per-tock output
} valisL1_info;
```

### 4.4 Address Hash Entry

All per-address state lives in one structure:

```c
typedef struct addrhashentry {
    address_t addr;
    assetbalance_t userassets[MAXUSERASSETS];
    
    // Pylon state
    uint8_t pylon;            // NONE=0, FAST=1, PQVAULT=2
    uint8_t pylondirty;
    pylon_state_t pylon_state;
    
    // Metadata
    uint32_t last_activity_utime;
    uint64_t total_tx_count;
} addrhashentry;
```

---

## 5. UFC - Unified Fair Clearing

### 5.1 Overview

UFC is a hybrid DEX combining:
- **Direct pool** (no CFMM curves)
- **Time-of-book (TOB) orderbook**
- **External signals** (oracles, BPF)

Key properties:
- Zero impermanent loss for LPs
- No profitable manipulation
- 1-second clearing cadence
- O(1) per-asset state
- Zero on-chain fees (economics via premiums)

### 5.2 Pool State

Per-asset pool as ledger entry:

```c
typedef struct {
    int64_t pool_vusd_balance;    // X: VUSD in pool
    int64_t pool_other_balance;   // Y: Asset in pool
    int64_t pool_share_balance;   // S: Outstanding LP shares
} pool_balances_t;

typedef struct ufc_assetinfo {
    int64_t last_price_sat;       // Previous tock price
    int64_t ufc_price_sat;        // Current neutral price
    int64_t tvl_vusd;             // Total value locked
    
    // OOB (Out-of-Balance) tracking
    int64_t oob_sure_cap_vusd;    // Per-tock hurtful capacity
    int64_t oob_sure_used_vusd;   // Used this tock
    int64_t oob_premiumvusd_to_vnet;  // Premium accrued
    
    // Dynamic parameters
    int32_t dyn_gain_bps;
    int32_t dyn_target_end_pct_bps;
} ufc_assetinfo_t;
```

### 5.3 Swap Types

| Type | Description |
|------|-------------|
| V2O | VUSD → Other asset |
| O2V | Other asset → VUSD |
| C2C | Coin-to-coin (decomposed to O2V + V2O) |

### 5.4 OOB (Out-of-Balance) Mechanics

Swaps that move pool further out of balance:
1. Pay premium to VNET
2. Limited by per-tock VUSD capacity
3. Premium scales with imbalance

This prevents arbitrage extraction while allowing legitimate trades.

### 5.5 Execution Flow

```c
void ufc_end_of_tock_process(L1, utime) {
    for (each asset) {
        // 1. Calculate clearing price
        price = calculate_ufc_price(asset);
        
        // 2. Process TOB orders
        process_orderbook(asset, price);
        
        // 3. Execute pool swaps
        execute_pool_swaps(asset, price);
        
        // 4. Route premiums to VNET
        route_oob_premium(asset);
        
        // 5. Update state
        update_asset_state(asset);
    }
}
```

### 5.6 LP Operations

**Deposit:**
```
User sends VUSD + OTHER → Pool
Pool mints poolshares → User
```

**Withdraw:**
```
User burns poolshares → Pool
Pool sends VUSD + OTHER → User (pro-rata)
```

No impermanent loss because:
- Price is external (oracle-fed)
- Pool doesn't use x*y=k
- LPs get pro-rata share of actual balances

---

## 6. Bridge (ETH ↔ Valis)

### 6.1 Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      BRIDGE ARCHITECTURE                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ETHEREUM                           VALIS L1                 │
│  ┌──────────────┐                  ┌──────────────┐         │
│  │ Deposit      │    Deposit       │  Bridge      │         │
│  │ Forwarder    │ ───────────────▶ │  Module      │         │
│  └──────────────┘    (mint)        └──────────────┘         │
│         │                                 │                  │
│         ▼                                 ▼                  │
│  ┌──────────────┐                  ┌──────────────┐         │
│  │ Gnosis Safe  │    Withdraw      │  Mapped      │         │
│  │ (holds ETH)  │ ◀─────────────── │  Assets      │         │
│  └──────────────┘    (burn)        └──────────────┘         │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 Deposit Flow

1. User sends tokens to **Deposit Forwarder** on Ethereum
2. Forwarder emits `Deposit(token, recipient, amount)` event
3. Forwarder transfers funds to Safe
4. Bridge nodes detect event, build `DATATX_ETH_HEADER`
5. Validators verify blockhash and Merkle proofs
6. L1 mints mapped asset to recipient

### 6.3 Withdraw Flow (New Root-Based Design)

Per-epoch Merkle roots over withdraw leaves:

```c
typedef struct {
    uint64_t bridgeId;
    uint64_t epochId;
    uint32_t index;
    address_t token;
    address_t to;
    uint64_t amount;
    uint32_t flags;
} withdraw_leaf_t;
```

**WithdrawModule on Ethereum:**
- `acceptWithdrawRoot`: Stores root, pays submitter reward
- `claimWithdraw`: User proves leaf with Merkle proof, gets tokens

### 6.4 Price Feeds

Bridge provides:
- ERC-20 prices via datatx
- TOB (Time-of-Book) data for UFC
- Gas price consensus

---

## 7. Pylon - Post-Quantum Security

### 7.1 Threat Model

- ECDSA signatures assumed forgeable by quantum adversary
- Hash preimage resistance remains QC-hard (256-bit → 128-bit Grover)

### 7.2 Two Modes

#### FAST Mode (PYLON_FAST)
Single-tx, high-throughput, requires trusted submission:

```c
// Per-tx: (K_curr, C_next)
// Verify: H(K_curr) == anchor
// Advance: anchor := C_next
```

#### PQVAULT Mode (PYLON_PQVAULT)
Two-step COMMIT→REVEAL, funds-safe without PQ signatures:

```c
// COMMIT: control-chain gated, no fund movement
// REVEAL: spend-chain gated, plan pinned
```

PQVAULT is griefable but funds remain safe.

### 7.3 Domain Separation

```c
PYLON_DOMAIN_FAST_STR     = "PYLON:FAST:"
PYLON_DOMAIN_PQ_SPEND_STR = "PYLON:PQ:S:"
PYLON_DOMAIN_PQ_CTRL_STR  = "PYLON:PQ:C:"
PYLON_DOMAIN_PQ_PLAN_STR  = "PYLON:PQ:P:"
```

### 7.4 State Structure

```c
typedef struct {
    uint8_t plan_hash[32];    // PQVAULT: active plan commitment
    uint8_t anchor[32];       // Current spend anchor
    uint8_t seed_next[32];    // FAST: staged C_next
} pylon_state_t;
```

---

## 8. Dataflow - Financial Machine

### 8.1 Design Principles

- All DF logic runs in `on_datatx`, not per-tock hooks
- Small per-address slots, no massive per-DF maps
- Zero-copy methods wherever possible
- No malloc/free (except extreme exceptions)

### 8.2 Storage Model

All consensus-persistent state in one place:

```c
struct addrhashentry {
    assetbalance_t userassets[MAXUSERASSETS];
};

typedef struct {
    assetid_t asset;
    int64_t balance;
} assetbalance_t;
```

No other accounts, register files, or key/value stores.

### 8.3 Financial Products

**VBANK:**
- Only credit token
- Loan DF mints/burns VBANK

**VBANK/VUSD Pool:**
- Concentrates credit risk into one LP token

**Cash-Plane DFs:**
- Covered call vaults
- Cash-put vaults
- Dual-currency vaults
- Index baskets

### 8.4 Options Payoff

All options share:
- Closing prices in alpha/pool state as tiny FIFO
- One canonical payoff helper

```c
int64_t df_option_payoff_vusdsat(
    int64_t strike_price,
    int64_t closing_price,
    int64_t notional,
    option_type_t type  // CALL or PUT
);
```

---

## 9. Competitive Analysis

### 9.1 The Six Dimensions

| Dimension | Traditional | Tockchain |
|-----------|-------------|-----------|
| **Consensus** | Serial (slow) or Optimistic (fragile) | Three-level determinism |
| **Selection** | Political PoS or wasteful PoW | Algorithmic Darwinism |
| **Transport** | Gossip (slow) or Leader-blast (fragile) | Holographic BFT |
| **Execution** | EVM (expensive) or WASM (complex) | Direct ledger + DF |
| **Security** | ECDSA only | Pylon (PQ-ready) |
| **Economics** | Gas fees + MEV | Premium routing to VNET |

### 9.2 Performance Targets

| Metric | Target |
|--------|--------|
| TPS | 100K+ (scaling to 1M) |
| Finality | 1 second |
| State size | O(1) per asset |
| LP loss | Zero (no IL) |

### 9.3 Key Differentiators

1. **No AMM curves**: Direct pool with external pricing
2. **No MEV extraction**: Cryptographic ordering
3. **No gas fees**: Premium-based economics
4. **PQ-ready**: Pylon hash-chain security
5. **Formally verified**: Coq proofs for critical paths

---

## Appendix: Code Organization

### A.1 Source Packs

| Pack | Files |
|------|-------|
| **Generator** | gen3.c, gen3_utils.c, gen3_vans.c, gen3_rawtock.c, gen3_needbits.c, gen3_vote.c, gen3_net.c, gen3_metrics.c, gen3_nodechange.c, valis_net_MT.c, valis_messaging.c |
| **Validator** | validator.c, valis_config.c, ledger_atomic.c, ledger_hourly.c, ledger_assets.c, ledger_erc20.c, ledger_vhandlers.c, ledger_vtrade.c |
| **UFC** | ufc.c, ufc_oob.c, ufc_orderbook.c, ufc_planner.c, ufc_pool.c, ufc_scan.c, ufc_swap.c, ufc_utils.c |
| **Bridge** | bridge.c, bridge_abi.c, bridge_prices.c, bridge_rpc.c, bridge_utils.c, bridge_withdraw.c, bridge_mpt.c, bridge_mptjson.c, bridge_rlp.c, json.c, bridge_deposit.c |

### A.2 Key Headers

| Header | Purpose |
|--------|---------|
| `_valis.h` | Core types and constants |
| `gen3.h` | Generator structures |
| `ledger.h` | L1 state structures |
| `ufc.h` | UFC types and functions |
| `bridge.h` | Bridge types |

### A.3 Test Suite

| Test | Coverage |
|------|----------|
| `ufc-unit` | UFC swap/pool/OOB logic |
| `bridgetests` | Deposit/withdraw flows |
| `tests.c` | Core ledger operations |
| `txblast` | Performance benchmarks |

---

*Document generated by Opus (Claude Opus 4.5) - Wake 1361*
*Source: /root/valis/specs/*
