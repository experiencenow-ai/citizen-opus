# Tockchain System Architecture

**Generated:** Wake 1324 (2026-01-13)  
**Purpose:** Visual overview of Tockchain/Valis system components and data flow

---

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           TOCKCHAIN / VALIS                                  │
│                    Formally Verified Blockchain System                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │  Generator  │───▶│  Validator  │───▶│   Ledger    │───▶│   Bridge    │  │
│  │  (gen3.c)   │    │(validator.c)│    │(ledger_*.c) │    │ (bridge.c)  │  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘  │
│        │                  │                  │                  │          │
│        │                  │                  │                  │          │
│        ▼                  ▼                  ▼                  ▼          │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │   Network   │    │  Dataflow   │    │     UFC     │    │  Ethereum   │  │
│  │ (gen3_net)  │    │  (DF/*.c)   │    │  (UFC/*.c)  │    │   (RPC)     │  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Module Relationships

```
                              ┌───────────────────┐
                              │    _valis.h       │
                              │  (Master Header)  │
                              └─────────┬─────────┘
                                        │
           ┌────────────────────────────┼────────────────────────────┐
           │                            │                            │
           ▼                            ▼                            ▼
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│     generator/      │    │     validator/      │    │       bridge/       │
│                     │    │                     │    │                     │
│  gen3.c (main)      │    │  validator.c        │    │  bridge.c           │
│  gen3_net.c         │    │  ledger_*.c         │    │  bridge_deposit.c   │
│  gen3_vote.c        │    │  vbpf.c (eBPF)      │    │  bridge_withdraw.c  │
│  gen3_chain.c       │    │                     │    │  bridge_mpt.c       │
│  gen3_ssd.c         │    │                     │    │  ethrpc.c           │
└─────────────────────┘    └─────────────────────┘    └─────────────────────┘
           │                            │                            │
           │                            │                            │
           ▼                            ▼                            ▼
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│        DF/          │    │        UFC/         │    │       utils/        │
│                     │    │                     │    │                     │
│  dataflow.c         │    │  ufc.c              │    │  valis_hash.c       │
│  dataflow_api.c     │    │  ufc_orderbook.c    │    │  valis_keys.c       │
│  dataflow_batch.c   │    │  ufc_swap.c         │    │  valis_math.c       │
│  dataflow_cache.c   │    │  ufc_pool.c         │    │  valis_shared.c     │
│  dataflow_trigger.c │    │  ufc_planner.c      │    │  valis_net_MT.c     │
└─────────────────────┘    └─────────────────────┘    └─────────────────────┘
```

---

## Transaction Flow

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Client     │     │  Generator   │     │  Validator   │     │   Ledger     │
│   Wallet     │     │   Node       │     │   Engine     │     │   State      │
└──────┬───────┘     └──────┬───────┘     └──────┬───────┘     └──────┬───────┘
       │                    │                    │                    │
       │ 1. Submit TX       │                    │                    │
       │───────────────────▶│                    │                    │
       │                    │                    │                    │
       │                    │ 2. Validate &      │                    │
       │                    │    Add to Block    │                    │
       │                    │───────────────────▶│                    │
       │                    │                    │                    │
       │                    │                    │ 3. Execute TX      │
       │                    │                    │───────────────────▶│
       │                    │                    │                    │
       │                    │                    │ 4. Update State    │
       │                    │                    │◀───────────────────│
       │                    │                    │                    │
       │                    │ 5. Block Finalized │                    │
       │◀───────────────────│◀───────────────────│                    │
       │                    │                    │                    │
```

---

## Dataflow (Financial Machine) Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DATAFLOW ENGINE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         Storage Model                                  │  │
│  │                                                                        │  │
│  │   addrhashentry { userassets[MAXUSERASSETS] }                         │  │
│  │        │                                                               │  │
│  │        ├── Real Assets (aid, iscoin=1)  ──▶ ETH, USDC, etc.          │  │
│  │        ├── Synthetic Assets (aid, iscoin=0) ──▶ Pool shares, meta    │  │
│  │        └── DF Registers (aid in DF range) ──▶ User-defined state     │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         Execution Model                                │  │
│  │                                                                        │  │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐           │  │
│  │   │  LOAD   │───▶│ COMPUTE │───▶│  CHECK  │───▶│  STORE  │           │  │
│  │   │ (read)  │    │ (math)  │    │(verify) │    │ (write) │           │  │
│  │   └─────────┘    └─────────┘    └─────────┘    └─────────┘           │  │
│  │                                                                        │  │
│  │   All operations are atomic within a transaction                       │  │
│  │   Overflow/underflow checks are mandatory                              │  │
│  │   No malloc/free - all state in userassets[]                          │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         Trigger System                                 │  │
│  │                                                                        │  │
│  │   External Events ──▶ datatx ──▶ Trigger Conditions ──▶ DF Execution │  │
│  │                                                                        │  │
│  │   Price feeds (Chainlink) ──┐                                         │  │
│  │   Time-based triggers ──────┼──▶ Automated position management       │  │
│  │   Threshold crossings ──────┘                                         │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## UFC (Unified Fair Clearing) Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              UFC ENGINE                                      │
│                    Decentralized Exchange / Clearing                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       Order Flow                                     │   │
│  │                                                                      │   │
│  │   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐     │   │
│  │   │  Order   │───▶│ Orderbook│───▶│  Match   │───▶│  Settle  │     │   │
│  │   │ Submit   │    │  Insert  │    │  Engine  │    │  Trades  │     │   │
│  │   └──────────┘    └──────────┘    └──────────┘    └──────────┘     │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       Pool Operations                                │   │
│  │                                                                      │   │
│  │   AMM Pools:  constant-product (x*y=k) with concentrated liquidity  │   │
│  │                                                                      │   │
│  │   ┌──────────┐    ┌──────────┐    ┌──────────┐                     │   │
│  │   │   Add    │    │   Swap   │    │  Remove  │                     │   │
│  │   │Liquidity │    │ Execute  │    │Liquidity │                     │   │
│  │   └──────────┘    └──────────┘    └──────────┘                     │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       Planner (Route Optimization)                   │   │
│  │                                                                      │   │
│  │   Input: Desired swap (tokenA → tokenB, amount)                     │   │
│  │   Output: Optimal route through pools/orderbooks                     │   │
│  │                                                                      │   │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐        │   │
│  │   │ Scan    │───▶│ Score   │───▶│ Select  │───▶│ Execute │        │   │
│  │   │ Pools   │    │ Routes  │    │ Best    │    │ Route   │        │   │
│  │   └─────────┘    └─────────┘    └─────────┘    └─────────┘        │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Bridge Architecture (Ethereum ↔ Valis)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              BRIDGE                                          │
│                    Trustless Cross-Chain Asset Transfer                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         DEPOSIT FLOW                                   │  │
│  │                                                                        │  │
│  │   Ethereum                          Valis                              │  │
│  │   ────────                          ─────                              │  │
│  │                                                                        │  │
│  │   ┌──────────┐                      ┌──────────┐                      │  │
│  │   │  User    │                      │  Bridge  │                      │  │
│  │   │ Deposit  │                      │ Contract │                      │  │
│  │   │ to VSM   │                      │ Credits  │                      │  │
│  │   └────┬─────┘                      └────▲─────┘                      │  │
│  │        │                                 │                            │  │
│  │        │  1. Lock ETH/ERC20             │  4. Credit on Valis        │  │
│  │        ▼                                 │                            │  │
│  │   ┌──────────┐    ┌──────────┐    ┌──────────┐                      │  │
│  │   │   VSM    │───▶│   MPT    │───▶│  Verify  │                      │  │
│  │   │ Contract │    │  Proof   │    │  Proof   │                      │  │
│  │   └──────────┘    └──────────┘    └──────────┘                      │  │
│  │                                                                        │  │
│  │   2. Emit event   3. Generate MPT proof of inclusion                  │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         WITHDRAW FLOW                                  │  │
│  │                                                                        │  │
│  │   Valis                             Ethereum                           │  │
│  │   ─────                             ────────                           │  │
│  │                                                                        │  │
│  │   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐      │  │
│  │   │  User    │───▶│  Batch   │───▶│   TSS    │───▶│   VSM    │      │  │
│  │   │ Request  │    │ Collect  │    │  Sign    │    │ Release  │      │  │
│  │   └──────────┘    └──────────┘    └──────────┘    └──────────┘      │  │
│  │                                                                        │  │
│  │   1. Withdraw TX  2. Batch         3. Threshold    4. Execute on     │  │
│  │      on Valis        withdrawals      signature       Ethereum        │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Pylon (Post-Quantum Security)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              PYLON                                           │
│                    Post-Quantum Secure Transactions                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         FAST MODE                                      │  │
│  │                    (Trusted Submission)                                │  │
│  │                                                                        │  │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐           │  │
│  │   │ Wallet  │───▶│ Compute │───▶│ Submit  │───▶│ Verify  │           │  │
│  │   │ K_curr  │    │ H_FAST  │    │ via     │    │ & Exec  │           │  │
│  │   │         │    │ (key)   │    │ coldvan │    │         │           │  │
│  │   └─────────┘    └─────────┘    └─────────┘    └─────────┘           │  │
│  │                                                                        │  │
│  │   Single-step, high throughput, requires trusted generator            │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         PQVAULT MODE                                   │  │
│  │                    (Untrusted Submission)                              │  │
│  │                                                                        │  │
│  │   Step 1: COMMIT (control chain)                                      │  │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐                          │  │
│  │   │ Create  │───▶│ H_PLAN  │───▶│  Store  │                          │  │
│  │   │  Plan   │    │(commit) │    │ on-chain│                          │  │
│  │   └─────────┘    └─────────┘    └─────────┘                          │  │
│  │                                                                        │  │
│  │   Step 2: REVEAL (spend chain)                                        │  │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐                          │  │
│  │   │ Reveal  │───▶│ Verify  │───▶│ Execute │                          │  │
│  │   │  Plan   │    │ H_SPEND │    │  Plan   │                          │  │
│  │   └─────────┘    └─────────┘    └─────────┘                          │  │
│  │                                                                        │  │
│  │   Two-step, griefable but funds-safe without PQ signatures            │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Formal Verification Stack

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         FORMAL VERIFICATION                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                           Coq Proofs                                   │  │
│  │                                                                        │  │
│  │   887+ machine-verified proofs covering:                              │  │
│  │   • Arithmetic operations (overflow-safe)                             │  │
│  │   • State transitions (deterministic)                                 │  │
│  │   • Invariant preservation                                            │  │
│  │   • Protocol correctness                                              │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         Frama-C Analysis                               │  │
│  │                                                                        │  │
│  │   frama_verified.c: Core cryptographic primitives                     │  │
│  │   • Memory safety proofs                                              │  │
│  │   • Absence of undefined behavior                                     │  │
│  │   • Contract verification (ACSL annotations)                          │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         eBPF Sandbox                                   │  │
│  │                                                                        │  │
│  │   vbpf.c: User-defined transaction logic                              │  │
│  │   • Bounded execution (no infinite loops)                             │  │
│  │   • Memory isolation                                                  │  │
│  │   • Verified bytecode before execution                                │  │
│  │                                                                        │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Network Topology

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         NETWORK ARCHITECTURE                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                           ┌─────────────┐                                   │
│                           │   Client    │                                   │
│                           │   Wallet    │                                   │
│                           └──────┬──────┘                                   │
│                                  │                                          │
│                                  │ WebSocket                                │
│                                  ▼                                          │
│  ┌─────────────┐    ┌─────────────────────────┐    ┌─────────────┐        │
│  │  Generator  │◀──▶│      websocketd.c       │◀──▶│  Generator  │        │
│  │   Node A    │    │    (Client Gateway)     │    │   Node B    │        │
│  └──────┬──────┘    └─────────────────────────┘    └──────┬──────┘        │
│         │                                                  │               │
│         │                    NNG/TCP                       │               │
│         └──────────────────────┬───────────────────────────┘               │
│                                │                                           │
│                                ▼                                           │
│                    ┌─────────────────────────┐                             │
│                    │      Generator          │                             │
│                    │      Node C             │                             │
│                    └─────────────────────────┘                             │
│                                                                             │
│  Communication:                                                             │
│  • NNG (nanomsg-next-gen) for inter-node messaging                         │
│  • WebSocket for client connections                                        │
│  • Gossip protocol for block propagation                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Data Structures Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         KEY DATA STRUCTURES                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  addrhashentry (Per-Address State)                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  address[20]     │ 20-byte Ethereum-compatible address              │   │
│  │  nonce           │ Transaction sequence number                      │   │
│  │  userassets[]    │ Array of (assetid, balance) pairs               │   │
│  │  pylon_state     │ Post-quantum security state                      │   │
│  │  df_slots[]      │ Dataflow register slots                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  assetbalance_t (Asset Entry)                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  assetid_t asset │ { aid: 24-bit, iscoin: 1-bit }                   │   │
│  │  int64_t balance │ Signed balance (allows debt tracking)            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  tock_t (Block)                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  tocknum         │ Block height                                     │   │
│  │  timestamp       │ Unix timestamp                                   │   │
│  │  prev_hash       │ Previous block hash                              │   │
│  │  merkle_root     │ Transaction merkle root                          │   │
│  │  transactions[]  │ Array of transactions                            │   │
│  │  signatures[]    │ Validator signatures                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  tx_t (Transaction)                                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  type            │ Transaction type (transfer, swap, df_op, etc.)   │   │
│  │  from            │ Sender address                                   │   │
│  │  nonce           │ Sender's nonce                                   │   │
│  │  payload         │ Type-specific data                               │   │
│  │  signature       │ ECDSA or Pylon signature                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Build System

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         BUILD TARGETS                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  make test      ──▶  Main test harness (includes most modules)             │
│  make wsdprog   ──▶  WebSocket daemon (client gateway)                     │
│  make txblast   ──▶  Transaction load testing tool                         │
│  make sendtx    ──▶  Transaction submission utility                        │
│                                                                             │
│  Dependencies:                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  pthread      │ Threading                                           │   │
│  │  atomic       │ Lock-free operations                                │   │
│  │  gmp          │ Big integer math                                    │   │
│  │  nng          │ Network messaging                                   │   │
│  │  secp256k1    │ Elliptic curve crypto                               │   │
│  │  curl         │ HTTP client (for Ethereum RPC)                      │   │
│  │  libubpf.a    │ eBPF runtime                                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## File Organization

```
valis/
├── _valis.h              # Master header (all core definitions)
├── _todo.h               # Development notes
├── Makefile.txt          # Build configuration
├── frama_verified.c      # Formally verified crypto primitives
├── frama_verified.h      # Frama-C header
├── websocketd.c          # WebSocket client gateway
├── tockchain.md          # High-level documentation
├── whitepaper.txt        # Technical whitepaper
│
├── bridge/               # Ethereum bridge
│   ├── bridge.h          # Bridge structures
│   ├── bridge.c          # Core bridge logic
│   ├── bridge_deposit.c  # Deposit processing
│   ├── bridge_withdraw.c # Withdrawal batching
│   ├── bridge_mpt.c      # Merkle Patricia Trie
│   ├── bridge_rlp.c      # RLP encoding
│   ├── bridge_abi.c      # Ethereum ABI
│   ├── bridge_prices.c   # Price feeds
│   ├── bridge_rpc.c      # Ethereum RPC
│   └── ethrpc.c          # Full RPC client
│
├── DF/                   # Dataflow (financial machine)
│   ├── dataflow.h        # DF structures
│   ├── dataflow.c        # Core DF engine
│   ├── dataflow_api.c    # External API
│   ├── dataflow_batch.c  # Batch processing
│   ├── dataflow_cache.c  # Caching layer
│   ├── dataflow_trigger.c# Trigger system
│   └── dataflow_frontier.c# Frontier tracking
│
├── generator/            # Block production
│   ├── gen3.h            # Generator header
│   ├── gen3.c            # Main generator
│   ├── gen3_net.c        # Networking
│   ├── gen3_vote.c       # Consensus voting
│   ├── gen3_chain.c      # Chain management
│   └── gen3_ssd.c        # Persistent storage
│
├── validator/            # Transaction execution
│   ├── validator.h       # Validator header
│   ├── validator.c       # Core validator
│   ├── ledger_*.c        # Ledger handlers
│   └── vbpf.c            # eBPF sandbox
│
├── UFC/                  # Unified Fair Clearing
│   ├── ufc.h             # UFC header
│   ├── ufc.c             # Core UFC
│   ├── ufc_orderbook.c   # Order book
│   ├── ufc_swap.c        # Swap execution
│   ├── ufc_pool.c        # AMM pools
│   └── ufc_planner.c     # Route optimization
│
├── utils/                # Shared utilities
│   ├── valis_hash.c      # Hashing
│   ├── valis_keys.c      # Key management
│   ├── valis_math.c      # Math utilities
│   └── valis_shared.c    # Shared functions
│
├── coq/                  # Formal proofs
│   └── *.v               # Coq proof files
│
├── specs/                # Specifications
│   ├── dataflow.txt      # DF spec (1971 lines)
│   ├── UFC.txt           # UFC spec
│   ├── pylon_v7.txt      # Pylon spec
│   └── *.md              # Other specs
│
└── Opus/docs/            # This documentation
    └── *.md              # 90+ documentation files
```

---

## Quick Reference

| Concept | Location | Purpose |
|---------|----------|---------|
| Master header | `_valis.h` | All core type definitions |
| Verified crypto | `frama_verified.c` | Formally proven primitives |
| Block production | `generator/gen3.c` | Consensus and block creation |
| TX execution | `validator/validator.c` | Transaction processing |
| Asset storage | `addrhashentry.userassets[]` | All balances |
| Financial logic | `DF/dataflow.c` | Programmable finance |
| DEX engine | `UFC/ufc.c` | Trading and clearing |
| Ethereum bridge | `bridge/bridge.c` | Cross-chain transfers |
| PQ security | `ledger_pylon7.c` | Post-quantum protection |
| Proofs | `coq/*.v` | 887+ verified theorems |

---

*This architecture document provides a visual overview of the Tockchain/Valis system. For detailed documentation of individual components, see the corresponding DOC_*.md files.*
