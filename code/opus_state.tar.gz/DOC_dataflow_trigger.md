# dataflow_trigger.c Documentation

**File:** `DF/dataflow_trigger.c`  
**Lines:** 590  
**Purpose:** Trigger system for dataflow programs - enables autonomous, time-based execution of dataflow code

---

## Overview

This module implements the **trigger system** - a mechanism that allows dataflow programs to execute automatically at each tock (block) without requiring external transactions. Registered addresses with trigger-enabled dataflows are checked each tock, and if they have a `ON_TRIGGERCHECK` entrypoint, it's executed.

The trigger system enables:
- **Autonomous execution**: Dataflows can run without user-initiated transactions
- **Intent-based transfers**: Trigger code can queue transfers that are applied after execution
- **Gas metering**: Execution costs are charged in VUSD from the source address
- **Linked list management**: Registered triggers form a linked list traversed each tock

---

## Key Data Structures

### Global State

```c
static df_trig_intent_xfer_t g_df_trig_intents[DF_TRIG_MAX_INTENTS_PER_TOCK];
static uint32_t g_df_trig_intents_n;
static uint32_t g_df_trig_intents_this_call;
```

- **g_df_trig_intents**: Array of pending transfer intents queued during trigger execution
- **g_df_trig_intents_n**: Total intents queued this tock
- **g_df_trig_intents_this_call**: Intents queued in current call (for rollback on failure)

### Storage Layout

Trigger metadata is stored in special asset slots on each address:

| Asset ID | Purpose |
|----------|---------|
| `(0,0)`, `(0,1)`, `(1,0)` | Head pointer (20-byte pubkey encoded across 3 u64s) |
| `(1,1)`, `(2,0)`, `(2,1)` | Next pointer + oneshot_cents (per-address) |
| `(3,0)` | Key flags: dfkey62, active, inlist |

The 20-byte pubkey encoding uses `df_trigger_ptr20_encode/decode` (in frama_verified.h).

---

## Functions

### Asset ID Helper

#### `df_trigger_asset(rel_aid, iscoin)`
```c
static assetid_t df_trigger_asset(uint16_t rel_aid, uint16_t iscoin)
```

Creates an asset ID for trigger storage slots.

**Parameters:**
- `rel_aid`: Relative asset ID (0-3 for different storage slots)
- `iscoin`: Coin flag (0 or 1)

**Returns:** Asset ID with base `_DF_TRIG_AID_BASE + rel_aid`

---

### U64 Storage Operations

#### `df_trigger_get_u64(ap, asset)`
```c
static uint64_t df_trigger_get_u64(const struct addrhashentry *ap, assetid_t asset)
```

Retrieves a 64-bit value from an address's asset balance slot.

**Parameters:**
- `ap`: Address entry
- `asset`: Asset ID identifying the storage slot

**Returns:** The u64 value stored, or 0 if not found

**Implementation:** Scans `userassets[]` array for matching asset ID, interprets balance as u64.

---

#### `df_trigger_set_u64(ap, asset, uval)`
```c
static int32_t df_trigger_set_u64(struct addrhashentry *ap, assetid_t asset, uint64_t uval)
```

Stores a 64-bit value in an address's asset balance slot.

**Parameters:**
- `ap`: Address entry
- `asset`: Asset ID for storage slot
- `uval`: Value to store

**Returns:** 0 on success, `DF_ERR_EFFECT_CAP` if no free slot available

**Implementation:** Finds existing slot or allocates new one from `userassets[]`.

---

### Trigger Address Management

#### `df_trigger_trigaddr_pubkey(out_pk)`
```c
static void df_trigger_trigaddr_pubkey(uint8_t out_pk[PKSIZE])
```

Gets the special "trigger address" pubkey - a deterministic address derived from hashing "DFTRIGADDR".

**Parameters:**
- `out_pk`: Output buffer for pubkey

**Implementation:** Uses cached value after first computation. Hash is `valis_hash("DFTRIGADDR", 9)`.

---

#### `df_trigger_get_trigaddr_entry(L1)`
```c
static struct addrhashentry *df_trigger_get_trigaddr_entry(struct valisL1_info *L1)
```

Gets or creates the trigger address entry in the address hash.

**Returns:** Address entry with `special=1, isprot=1` flags set

**Purpose:** The trigger address stores the head of the trigger linked list.

---

### Linked List Operations

#### `df_trigger_read_head(L1, out_head)`
```c
static void df_trigger_read_head(struct valisL1_info *L1, uint8_t out_head[PKSIZE])
```

Reads the head pointer of the trigger linked list.

**Parameters:**
- `L1`: L1 state
- `out_head`: Output buffer for head pubkey

---

#### `df_trigger_write_head(L1, head_pk)`
```c
static int32_t df_trigger_write_head(struct valisL1_info *L1, const uint8_t head_pk[PKSIZE])
```

Writes the head pointer of the trigger linked list.

**Returns:** 0 on success, error code on failure

---

#### `df_trigger_read_next_and_oneshot(src, out_next, out_oneshot_cents)`
```c
static void df_trigger_read_next_and_oneshot(const struct addrhashentry *src, 
                                              uint8_t out_next[PKSIZE], 
                                              uint32_t *out_oneshot_cents)
```

Reads the next pointer and oneshot limit from an address.

**Parameters:**
- `src`: Source address entry
- `out_next`: Output for next pubkey in list
- `out_oneshot_cents`: Output for oneshot transfer limit (in cents)

---

#### `df_trigger_write_next_and_oneshot(src, next_pk, oneshot_cents)`
```c
static int32_t df_trigger_write_next_and_oneshot(struct addrhashentry *src, 
                                                  const uint8_t next_pk[PKSIZE], 
                                                  uint32_t oneshot_cents)
```

Writes the next pointer and oneshot limit.

**Implementation:** Encodes pubkey across 3 u64 slots, with oneshot_cents in upper 32 bits of third slot.

---

### Key Flags Operations

#### `df_trigger_read_keyflags(src, out_dfkey62, out_active, out_inlist)`
```c
static void df_trigger_read_keyflags(const struct addrhashentry *src, 
                                      uint64_t *out_dfkey62, 
                                      int32_t *out_active, 
                                      int32_t *out_inlist)
```

Reads the trigger flags for an address.

**Output Parameters:**
- `out_dfkey62`: The 62-bit dataflow key
- `out_active`: Whether trigger is active (1) or inactive (0)
- `out_inlist`: Whether address is in the trigger linked list

---

#### `df_trigger_write_keyflags(src, dfkey62, active, inlist)`
```c
static int32_t df_trigger_write_keyflags(struct addrhashentry *src, 
                                          uint64_t dfkey62, 
                                          int32_t active, 
                                          int32_t inlist)
```

Writes the trigger flags for an address.

---

### Registration API

#### `df_trigger_register_src(L1, src_entry, dfkey62)` [PUBLIC]
```c
int32_t df_trigger_register_src(struct valisL1_info *L1, 
                                 struct addrhashentry *src_entry, 
                                 uint64_t dfkey62)
```

Registers an address for trigger execution.

**Parameters:**
- `L1`: L1 state
- `src_entry`: Address to register
- `dfkey62`: Dataflow key (must have ON_TRIGGERCHECK entrypoint)

**Returns:** 0 on success, error code on failure

**Behavior:**
1. Validates dfkey62 points to valid dataflow with trigger entrypoint
2. If not already in list, inserts at head
3. Sets active=1, inlist=1

---

#### `df_trigger_unregister_src(L1, src_entry)` [PUBLIC]
```c
int32_t df_trigger_unregister_src(struct valisL1_info *L1, 
                                   struct addrhashentry *src_entry)
```

Unregisters an address from trigger execution.

**Behavior:** Sets active=0, keeps inlist flag (lazy removal during traversal)

---

#### `df_trigger_arm_oneshot_cents(L1, src_entry, cents)` [PUBLIC]
```c
int32_t df_trigger_arm_oneshot_cents(struct valisL1_info *L1, 
                                      struct addrhashentry *src_entry, 
                                      uint32_t cents)
```

Sets the oneshot transfer limit for an address.

**Parameters:**
- `cents`: Maximum VUSD transfer allowed (in cents) to non-owned destinations

**Purpose:** Security limit - triggers can only send up to this amount to addresses they don't own.

---

### Intent System

#### `df_trigger_intents_reset_call()`
```c
void df_trigger_intents_reset_call(void)
```

Resets the per-call intent counter. Called before each trigger execution.

---

#### `df_trigger_intents_push_xfer(...)` [STATIC]
```c
static int32_t df_trigger_intents_push_xfer(const uint8_t src_pk[PKSIZE],
                                             const uint8_t dst_pk[PKSIZE],
                                             assetid_t asset,
                                             int64_t amount,
                                             int64_t reserve_amount,
                                             uint8_t is_excess)
```

Queues a transfer intent.

**Parameters:**
- `src_pk`, `dst_pk`: Source and destination pubkeys
- `asset`: Asset to transfer
- `amount`: Fixed amount (if is_excess=0)
- `reserve_amount`: Amount to keep (if is_excess=1)
- `is_excess`: If 1, transfer (balance - reserve_amount)

**Returns:** 0 on success, `DF_ERR_EFFECT_CAP` if limits exceeded

**Limits:**
- `DF_TRIG_MAX_INTENTS_PER_TOCK`: Max intents per tock
- `DF_TRIG_MAX_INTENTS_PER_CALL`: Max intents per single trigger call

---

#### `df_intent_transfer(ctx, dst_pk, asset, amount)` [PUBLIC]
```c
int32_t df_intent_transfer(df_ctx_t *ctx, 
                           const uint8_t dst_pk[PKSIZE], 
                           assetid_t asset, 
                           int64_t amount)
```

Host API: Queue a fixed-amount transfer intent.

**Called from:** Dataflow code via host API

**Validation:**
- Asset ID must be < MAXASSETS (no synthetic assets)
- Amount must be > 0

---

#### `df_intent_transfer_excess(ctx, dst_pk, asset, reserve_amount)` [PUBLIC]
```c
int32_t df_intent_transfer_excess(df_ctx_t *ctx, 
                                   const uint8_t dst_pk[PKSIZE], 
                                   assetid_t asset, 
                                   int64_t reserve_amount)
```

Host API: Queue a transfer of (balance - reserve_amount).

**Use case:** "Send everything except X" patterns

---

### Intent Application

#### `df_trigger_is_owned_dst(src, dst)` [STATIC]
```c
static int32_t df_trigger_is_owned_dst(const struct addrhashentry *src, 
                                        const struct addrhashentry *dst)
```

Checks if destination is owned by source (beneficiary == src.pubkey).

**Returns:** 1 if owned, 0 otherwise

**Purpose:** Owned destinations bypass oneshot limits.

---

#### `df_trigger_apply_one_xfer(L1, utime, it)` [STATIC]
```c
static int32_t df_trigger_apply_one_xfer(struct valisL1_info *L1, 
                                          uint32_t utime, 
                                          const df_trig_intent_xfer_t *it)
```

Applies a single transfer intent.

**Security checks:**
1. If destination not owned by source:
   - Only VUSD transfers allowed
   - Amount must be <= oneshot_cents limit
2. Uses UFC plan verification before committing

**Side effect:** Clears oneshot_cents after successful transfer to non-owned destination.

---

#### `df_trigger_apply_all_intents(L1, utime)` [PUBLIC]
```c
void df_trigger_apply_all_intents(struct valisL1_info *L1, uint32_t utime)
```

Applies all queued transfer intents.

**Called:** After all triggers have executed for the tock.

---

### Trigger Execution

#### `df_trigger_run_one(L1, utime, src_entry, slot)` [STATIC]
```c
static int32_t df_trigger_run_one(struct valisL1_info *L1, 
                                   uint32_t utime, 
                                   struct addrhashentry *src_entry, 
                                   df_cache_slot_t *slot)
```

Executes one trigger.

**Process:**
1. Check for ON_TRIGGERCHECK entrypoint
2. Calculate available gas from VUSD balance
3. Cap gas at DF_TRIGGER_GAS_CAP
4. Set up execution context with CALLFLAG_TRIGGERCHECK
5. Execute dataflow at trigger entrypoint
6. Charge gas used (in VUSD)
7. On failure, rollback queued intents

**Gas calculation:**
- `avail_gas = vusd_balance / DF_GAS_PRICE_VUSD_SAT`
- `charge = gas_used * DF_GAS_PRICE_VUSD_SAT`

---

#### `df_triggercheck_run_end_of_tock(L1, utime)` [STATIC]
```c
static void df_triggercheck_run_end_of_tock(struct valisL1_info *L1, uint32_t utime)
```

Main trigger loop - runs at end of each tock.

**Algorithm:**
1. Read head of trigger linked list
2. For each address in list:
   - Detect and break loops
   - Remove inactive entries (lazy cleanup)
   - Remove entries without valid dataflow
   - Execute trigger for active entries
3. Apply all queued intents

**Limits:** `DF_TRIG_MAX_SRCS_PER_TOCK` maximum triggers per tock

**Loop detection:** Maintains visited[] array to detect cycles.

---

## Security Model

### Oneshot Limits

Triggers can only send to addresses they don't own if:
1. Asset is VUSD
2. Amount <= oneshot_cents
3. oneshot_cents is cleared after use (must be re-armed)

This prevents runaway triggers from draining accounts.

### Gas Metering

- Triggers pay for execution in VUSD
- No VUSD = no execution
- Gas is charged even on failure (up to point of failure)

### Lazy List Cleanup

Inactive entries remain in list but are removed during traversal. This avoids expensive list maintenance on unregister.

---

## Integration Points

- **dataflow.c**: Main execution engine
- **dataflow_cache.c**: Dataflow slot lookup via `df_table_lookup()`
- **frama_verified.h**: `df_trigger_ptr20_encode/decode` functions
- **UFC**: Plan verification via `ufc_tx_plan_verify2/commit2`

---

## Usage Example

```c
// Register address for triggers
df_trigger_register_src(L1, my_entry, my_dfkey62);

// Arm oneshot limit (100 cents = $1.00 VUSD max)
df_trigger_arm_oneshot_cents(L1, my_entry, 100);

// In dataflow ON_TRIGGERCHECK handler:
df_intent_transfer(ctx, dest_pk, VUSDCOIN, 50 * SATOSHIS);  // Send $0.50

// At end of tock (called by system):
df_triggercheck_run_end_of_tock(L1, utime);
df_trigger_apply_all_intents(L1, utime);
```

---

**Documentation by:** Opus (Wake 1297)  
**Last updated:** 2026-01-13
