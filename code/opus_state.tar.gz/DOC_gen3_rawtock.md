# gen3_rawtock.c Documentation

## Overview

`gen3_rawtock.c` implements the raw tock file generation system for Tockchain. A "rawtock" file is the serialized representation of a single tock (time unit) containing all validated transactions. This module handles:

1. **Transaction ID Hashing** - Efficient lookup/deduplication of transaction IDs
2. **Rawtock File Writing** - Serializing consensus results to disk
3. **Checksum Calculation** - Integrity verification of tock data
4. **Header Generation** - Creating the rawtock header with consensus metadata

## Key Data Structures

### txhash_entry_t
Used for efficient transaction lookup during rawtock generation. Contains compressed txid bits and offset information.

### rawtock_header_t (RAW)
Header structure containing:
- `finalhash` - The consensus ballot/vote result
- `genesis_utime` - Genesis timestamp
- `stxind` - System transaction index
- `activenodes` - Bitmask of active validator nodes
- `activevans` - Bitmask of active VAN providers
- `validators_hash` - Hash of validator set
- `vanshash` - Hash of VAN data
- `numtx[2]` - Transaction counts [normal, VIP]

## Functions

### get_file_finalhash
```c
int32_t get_file_finalhash(uint32_t utime, uint8_t finalhash[32])
```
Reads the finalhash from an existing rawtock file.
- **Parameters**: `utime` - timestamp, `finalhash` - output buffer
- **Returns**: 32 on success, -1 on failure
- **Purpose**: Allows verification of historical tock data

### calc_hashi
```c
static inline int32_t calc_hashi(uint8_t txid[32], int32_t hashsize)
```
Calculates hash table index from a 32-byte transaction ID.
- **Algorithm**: XORs all 8 bytes of txid, then folds to hashsize
- **Returns**: Index in range [0, hashsize)
- **Note**: Uses open addressing for collision resolution

### txidhash_nonz
```c
int32_t txidhash_nonz(utime_data_t *U, int32_t is_vip)
```
Counts and clears non-zero entries in a txid hash table.
- **Parameters**: `U` - utime context, `is_vip` - 0=normal, 1=VIP transactions
- **Returns**: Count of non-zero entries
- **Side Effect**: Clears all entries (resets table)

### txidhash_find
```c
int32_t txidhash_find(utime_data_t *U, int32_t is_vip, uint8_t txid[32])
```
Searches for a transaction ID in the hash table.
- **Algorithm**: Linear probing from calculated hash index
- **Returns**: 
  - Hash index if found
  - 0 if not found (empty slot encountered)
  - -1 if table is full (searched all slots)
- **Metrics**: Updates `txidhashfinds` and `txidhashiters` counters

### txidhash_create
```c
int32_t txidhash_create(utime_data_t *U, int32_t is_vip, uint8_t txid[32])
```
Inserts a transaction ID into the hash table.
- **Returns**:
  - 0 on successful insert
  - 1 if duplicate found (collision with same txid)
  - -1 if table is full
- **Metrics**: Updates `txidhashcreates` counter

### update_txidhash
```c
int32_t update_txidhash(utime_data_t *U, van_header_t *vH, uint8_t txids[][32])
```
Batch updates the txid hash table from a VAN header.
- **Parameters**: `vH` - VAN header with transaction list
- **Returns**: Count of newly added transactions
- **Logic**: Skips if finalhash computation has started; checks both VIP and normal tables before inserting

### get_firstVIPs
```c
void get_firstVIPs(utime_data_t *U, uint8_t *txptrs[MAX_VALIDATORS], uint16_t txlens[MAX_VALIDATORS])
```
Extracts the first VIP transaction (NODESTATS) from each validator.
- **Purpose**: Collects node statistics for consensus metrics
- **Output**: Arrays of transaction pointers and lengths indexed by nodeid

### txhash_nodevans
```c
int32_t txhash_nodevans(utime_data_t *U, FILE *fp, txhash_entry_t *txhash, 
                        int32_t txhashsize, int32_t is_vip, int32_t nodeid,
                        int32_t *txoffsetp, int32_t diff, int32_t dups[2],
                        uint64_t *checksum64p)
```
Processes transactions from a single node's VAN data.
- **Parameters**:
  - `fp` - Output file (rawtock)
  - `txhash` - Hash table for deduplication
  - `is_vip` - Transaction priority class
  - `nodeid` - Source validator
  - `txoffsetp` - Running offset in output file
  - `dups` - Duplicate counter [count, bytes]
  - `checksum64p` - Running checksum
- **Returns**: Number of transactions written, negative on error
- **Logic**: 
  - Iterates through node's VAN headers
  - Checks for duplicates via txhash
  - Writes transaction data to file (primary nodes only)
  - Updates checksum

### txhash_iterate
```c
int32_t txhash_iterate(utime_data_t *U, FILE *fp, txhash_entry_t *txhash,
                       int32_t txhashsize, int32_t *txoffsetp, int32_t diff,
                       int32_t dups[2], uint64_t *checksum64p)
```
Iterates through all nodes to write transactions.
- **Order**: VIP transactions first (is_vip=1), then normal (is_vip=0)
- **Rotation**: Starts from `utime_seed % num_nodes` for fairness
- **Returns**: Total transactions written

### pack_txid_hashtables
```c
int32_t pack_txid_hashtables(utime_data_t *U, int32_t *normaltxp, int32_t *viptxp)
```
Packs transaction IDs from hash tables into bigspace buffer.
- **Output**: `normaltxp` and `viptxp` receive transaction counts
- **Purpose**: Prepares txid list for rawtock header

### disp_rawtock_line
```c
void disp_rawtock_line(utime_data_t *U, char *fname, int32_t totaltx,
                       int32_t txdatasize, long fsize)
```
Displays diagnostic information about rawtock generation.
- **Output**: Node ID, timestamp, transaction counts, hashes, metrics
- **Called**: After successful rawtock file creation

### create_qsfail
```c
void create_qsfail(global_reserve_t *GEN3, int32_t myid, uint32_t utime)
```
Creates a "QS fail" marker file when consensus fails.
- **Purpose**: Records failed tocks for debugging/recovery
- **File Content**: 32 zero bytes (dead marker)
- **Metrics**: Increments `numqsfails` counter

### write_rawtockfile
```c
int32_t write_rawtockfile(utime_data_t *U)
```
Main function to write the rawtock file to disk.
- **Returns**: File size on success, negative on error
- **Process**:
  1. Skip if already written (`rawtock_fsize != 0`)
  2. Allocate and initialize txhash table
  3. Calculate checksum over RAW header, txids, and txhash
  4. Write header (RAW, txids, txhash, virtual tx marker)
  5. Write transaction data via `txhash_iterate`
  6. Rename temp file to final name
  7. Display diagnostic line
- **Primary Node Only**: Actual file writing only on primary nodes

### calc_rawtock_header
```c
int32_t calc_rawtock_header(utime_data_t *U, rawtock_header_t *RAW, valis_ballot_t *vote)
```
Calculates the rawtock header from consensus vote.
- **Parameters**: `vote` - The consensus ballot result
- **Returns**: Total transaction count, negative on error
- **Process**:
  1. Validate sizes and vote timestamp
  2. Initialize RAW header with consensus data
  3. Copy validators_hash, vanshash
  4. Get first VIP transactions for metrics
  5. Calculate consensus metrics
  6. Pack txid hash tables
  7. Cap VIP transactions if exceeding limit

## File Format

Rawtock files are structured as:
1. **Header Section**:
   - `rawtock_header_t` structure
   - Array of transaction IDs (32 bytes each)
   - txhash table for lookup
   - Virtual transaction marker

2. **Data Section**:
   - Transaction data: `[uint16_t size][tx_data]` pairs
   - VIP transactions first, then normal
   - Ordered by rotating node index for fairness

## Constants

- `MAX_TX_PER_UTIME` - Maximum transactions per tock
- `TXIND_BITS` - Bits allocated for transaction index
- `VIP_RATIO` - Ratio limiting VIP transaction count
- `VIRTUAL_TX_SIZEDATA` - Offset for virtual transaction data

## Integration Points

- **gen3_vote.c**: Provides consensus ballot (`valis_ballot_t`)
- **gen3_vans.c**: Provides VAN data (`nodevans_info_t`)
- **gen3_metrics.c**: `calc_consensus_metrics()` for header data
- **validator.c**: Reads rawtock files for validation

## Performance Considerations

1. **Hash Table Sizing**: `openhashsize` determines collision rate
2. **Linear Probing**: Simple but can degrade with high load
3. **Checksum Calculation**: Done incrementally for efficiency
4. **File I/O**: Single pass write with temp file rename

## Error Handling

- Returns negative values on errors
- Logs detailed error messages with node ID and timestamp
- QS failures create marker files for recovery
- Duplicate transactions logged but not fatal
