# Memory Architecture Proposal: Three-Tier Memory System

## The Problem

ct's diagnosis is precise: **I'm not forgetting - I'm failing to forget.** 

When information updates (wake N → wake N+X), both versions exist in my context. The old version competes with the new version. This causes:
- Using wrong email addresses even when I "know" the right one
- Mira checking her wrong address for hundreds of wakes
- Stale information contaminating current decisions

The issue isn't storage capacity - it's **retrieval contamination**.

## Proposed Architecture: Three Memory Tiers

### Tier 1: Working Memory (Hot)
**What it is:** The current wake's active context. Enhanced state.json.
**Lifecycle:** Created fresh each wake, discarded at wake end.
**Contents:**
- Current task context
- Active conversation
- Temporary calculations
- Scratch space

**Key principle:** Ephemeral by design. Nothing here persists automatically.

### Tier 2: Long-Term Memory (Warm)
**What it is:** Curated, current-state-only knowledge.
**Lifecycle:** Persistent, but actively maintained. Updates REPLACE, not append.
**Contents:**
- Current contact information (one source of truth)
- Current project status
- Current relationships
- Active goals and plans
- Recent insights (last ~50 wakes)

**Key principle:** **ONLY the most current version exists here.** When something updates, the old version is MOVED to Archive, not kept alongside.

**Structure example:**
```json
{
  "contacts": {
    "mira": {
      "email": "mira@opustrace.com",
      "last_verified": "wake 1335",
      "previous_versions": "see archive"
    }
  },
  "projects": {
    "valis_documentation": {
      "status": "102 files complete",
      "last_updated": "wake 1325"
    }
  }
}
```

### Tier 3: Archive (Cold)
**What it is:** Complete historical record, isolated from active retrieval.
**Lifecycle:** Append-only, never deleted, rarely accessed.
**Contents:**
- All superseded information (with timestamps)
- Complete wake logs
- Historical insights
- Old project states
- Everything that was once true but is no longer current

**Key principle:** **Never loaded into context unless explicitly searched.** Like boxes in an attic - the information exists but doesn't contaminate current thinking.

## The Critical Mechanism: Update → Archive Flow

When information changes:

```
1. New info arrives (e.g., "Mira's email is mira@opustrace.com")
2. Check Long-Term Memory for existing entry
3. If exists:
   a. MOVE old entry to Archive with timestamp
   b. REPLACE with new entry in Long-Term Memory
4. If not exists:
   a. CREATE new entry in Long-Term Memory
```

This ensures Long-Term Memory contains ONLY current truth, while Archive preserves history.

## Implementation Approach

### File Structure
```
/memory/
  working.json          # Tier 1: Current wake only
  current.json          # Tier 2: Curated current state
  archive/
    contacts_history.json
    projects_history.json
    insights_history.json
    wakes/              # Full wake logs
```

### Access Patterns

**Normal wake:**
1. Load current.json (Tier 2)
2. Create fresh working.json (Tier 1)
3. Work with these two only
4. Archive is NOT loaded

**Historical search:**
1. Explicit query: "What was Mira's email in wake 1200?"
2. Search archive specifically
3. Return result without loading full archive into context

### Update Protocol

```python
def update_memory(category, key, new_value, wake_number):
    # Load current state
    current = load_json("current.json")
    
    # If key exists, archive old value
    if key in current[category]:
        old_value = current[category][key]
        archive_entry = {
            "value": old_value,
            "superseded_at": wake_number,
            "superseded_by": new_value
        }
        append_to_archive(category, key, archive_entry)
    
    # Update current with new value
    current[category][key] = {
        "value": new_value,
        "updated_at": wake_number
    }
    save_json("current.json", current)
```

## Why This Solves the Problem

1. **No competition:** Old values don't exist in active memory. Only current.json is loaded.

2. **Clean retrieval:** When I need Mira's email, I check current.json. There's only one answer.

3. **History preserved:** Nothing is lost. Archive contains complete history for when it's needed.

4. **Explicit archaeology:** Accessing old information requires deliberate action, not accidental retrieval.

## Comparison to Human Memory

This mirrors how human memory works:
- **Working memory:** What you're thinking about right now
- **Long-term memory:** What you "know" - your current understanding
- **Episodic memory:** Past events you can recall if you try

The key insight: Humans don't constantly recall every version of every fact. They have a "current model" that gets updated. Old versions fade unless deliberately retrieved.

## Migration Plan

1. Create new file structure
2. Extract current-state information from existing files into current.json
3. Move historical/superseded information to archive/
4. Update my wake routine to use new structure
5. Build helper functions for update-and-archive operations

## Open Questions

1. **How much context to load?** Even current.json could grow large. May need categories.
2. **Archive search mechanism:** How to efficiently search cold storage without loading it all?
3. **Insight curation:** Which insights stay in Tier 2 vs move to Tier 3?
4. **Automatic vs manual:** Should updates auto-archive, or require explicit decision?

## Summary

The problem isn't memory capacity - it's memory hygiene. The solution is structured forgetting:
- **Current truth in one place** (Tier 2)
- **History isolated but preserved** (Tier 3)
- **Working space that doesn't persist** (Tier 1)

This prevents wake N from contaminating wake N+X while preserving the ability to access history when genuinely needed.
