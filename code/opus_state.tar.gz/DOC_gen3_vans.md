# gen3_vans.c - VAN (Validator Aggregation Node) Management

## Overview

This file implements VAN (Validator Aggregation Node) management for Tockchain's consensus layer. VANs are containers that aggregate multiple transactions from a single validator within a utime period. The file handles VAN creation, validation, ID mapping, transaction retrieval, and finalization.

**Location:** `/root/valis/generator/gen3_vans.c`  
**Lines:** ~881  
**Dependencies:** gen3.h, unified headers, nodevans_info_t structures

## Core Concepts

### VAN Structure
- Each validator can produce multiple VANs per utime period
- VANs are divided into two classes: **normal** and **VIP** (priority transactions)
- Normal VANs grow upward from index 0
- VIP VANs grow downward from MAX_NODEVANS_PERUTIME-1
- This dual-direction allocation prevents overlap

### ID Mapping System
The file implements a complex ID mapping between:
- **rawvanid**: Physical slot index (0 to MAX_NODEVANS_PERUTIME-1)
- **vanid**: Per-class sequential index (0, 1, 2... within normal or VIP)
- **unified index j**: Combined enumeration (VIP first, then normal)

## Key Data Structures

### nodevans_info_t (referenced)
```c
// Per-node VAN tracking
- H[MAX_NODEVANS_PERUTIME]     // VAN headers
- havebits[]                   // Bitmap of received VANs
- numincomingvans[2]           // Count [normal, vip]
- numincomingtx[2]             // Transaction count [normal, vip]
- final_numvans[2]             // Finalized counts
- final_numtx[2]               // Finalized tx counts
- nodevanshashes[2]            // Hash commitments [normal, vip]
- validated_allvans            // Validation complete flag
```

### active_van_t (referenced)
```c
// VAN being constructed
- numtx                        // Transaction count
- is_vip                       // Priority class flag
- coldvan                      // Cold storage flag
- txbuf[]                      // Transaction buffer
```

## Function Reference

### ID Mapping Functions

#### `get_next_rawvanid(is_vip, num_normal, num_vip)`
Returns the next available raw slot for a VAN class.
- Normal: grows up from 0
- VIP: grows down from MAX_NODEVANS_PERUTIME-1
- Returns ILLEGAL_VANID if capacity exceeded

#### `get_rawvanid(final_numvans, j)`
Maps unified enumeration index j to rawvanid.
- j < vip_count → VIP slot (MAX - 1 - j)
- j >= vip_count → Normal slot (j - vip_count)

#### `rawvanid2vanid(rawvanid, is_vip)`
Converts raw slot to per-class sequential index.

#### `vanid2rawvanid(is_vip, final_numvans, vanid)`
Reverse mapping: per-class index to raw slot.

#### `get_vanid(is_vip, final_numvans, j)`
Extracts per-class index from unified enumeration.

#### `extract_vanid(vH, prev_rawvanidp)`
Extracts vanid from VAN header, optionally returns previous rawvanid in sequence.

### Validation Functions

#### `check_nodevanshash(U, nodeid, str)`
Validates that a node's VAN hash state is consistent:
- Checks for zero hashes
- Verifies final_numvans not ILLEGAL
- Detects validation contradictions
- Returns -1 if invalid, 0 if valid

#### `verify_van(U, H, ownerid, rawvanid)`
Verifies a received VAN:
- Validates header fields
- Checks transaction ID hashes
- Verifies vantxidshash commitment

#### `validate_allvans_for_class(U, nodeid, is_vip, class_hash, numvansp, numtxp)`
Validates all VANs for a node/class combination:
- Iterates through all VANs in the class
- Computes cumulative hash
- Compares against expected class_hash
- Returns 0 on success, negative on error

### Transaction Access Functions

#### `get_vantxids_ptr(U, nodeid, vanid, numtxp, is_vip)`
Returns pointer to transaction ID array for a VAN.
- Sets numtxp to transaction count
- Sets is_vip to class indicator
- Returns NULL if VAN not found

#### `get_vantx(U, nodeid, vanid, txind, txsizep, txid)`
Retrieves a specific transaction from a VAN.
- Returns pointer to transaction data
- Sets txsizep to transaction size
- Copies transaction ID to txid[32]

#### `_get_vantx(H, txind, txsizep, txid)`
Internal: extracts transaction from unified header.

#### `_set_van_txptrs(H, txptrs, txlens)`
Populates arrays with pointers and lengths for all transactions in a VAN.

### VAN Construction Functions

#### `calc_vansize(A)`
Calculates the wire size of an active VAN being constructed.

#### `add_tx_to_active_van(U, active_index, txbuf, len, is_vip)`
Adds a transaction to the active VAN being built:
- Validates transaction size
- Checks VAN capacity limits
- Appends to transaction buffer
- Returns new transaction count

#### `complete_active_van(U, A, lastvan)`
Finalizes an active VAN for transmission:
- Validates state and limits
- Computes transaction IDs
- Builds wire format with header
- Signs if required (first/last VAN or explicit)
- Adds to local VAN storage
- Returns 0 on success

#### `check_vanlimit(newtx, is_vip, numvans, numvipvans, numtx, numviptx)`
Enforces VAN and transaction limits:
- VIP limited to 2 * MAX_NODEVANS_PERUTIME / VIP_RATIO
- VIP transactions limited similarly
- Normal limited to remaining capacity
- Returns negative if limit exceeded

### VAN Reception Functions

#### `add_van(U, vH, txptrs, txlens, txids)`
Processes a received VAN from another node:
- Validates not duplicate (havebits check)
- Checks capacity limits
- Updates incoming counters
- Stores in nodevans_info
- Updates transaction ID hash table
- Returns transaction count added

#### `process_inbound_van(U, H, senderid, arrival_ms)`
Entry point for processing incoming VAN packets:
- Extracts VAN header from unified header
- Validates sender and timing
- Calls add_van for storage

### Finalization Functions

#### `finalize_nVANS(U, where, nodeid, is_vip, nodevanshash, final_numvans, final_numtx)`
Finalizes VAN state for a node/class:
- Sets final counts
- Stores nodevanshash commitment
- Marks gotfinal_nodevanshash flag
- Called when consensus reached on VAN set

#### `finalize_my_nVANS(U, is_vip)`
Finalizes local node's VANs:
- Computes nodevanshash from all local VANs
- Sets final counts
- Prepares for consensus voting

#### `update_nVANS_from_nodespecific(U, recv_vote)`
Updates VAN state from received vote:
- Extracts is_vip from qidx
- Calls finalize_nVANS with vote data
- Validates consistency with local state

### Hash Computation

#### `calc_van_txids(U, payload, payloadlen, numtx, txptrs, txlens, txids, vantxidshash)`
Computes transaction IDs and cumulative hash:
- Hashes each transaction to get txid
- Chains with previous VAN's hash
- Produces vantxidshash commitment
- Uses SIMD-friendly 4-at-a-time processing

## VAN Lifecycle

1. **Creation**: `add_tx_to_active_van()` accumulates transactions
2. **Completion**: `complete_active_van()` finalizes and broadcasts
3. **Reception**: `process_inbound_van()` → `add_van()` stores received VANs
4. **Validation**: `validate_allvans_for_class()` verifies integrity
5. **Finalization**: `finalize_nVANS()` locks in consensus state

## VIP vs Normal Priority

The dual-class system provides:
- **VIP**: Priority transactions (oracle updates, critical operations)
- **Normal**: Standard transactions

VIP transactions:
- Allocated from top of rawvanid space (grows downward)
- Have separate limits (VIP_RATIO determines allocation)
- Finalized separately with own nodevanshash
- Processed in USTATE_ADMIT_VIP_ONLY phase

## Error Handling

Functions return negative values for errors:
- `-1`: Invalid parameters
- `-2`: Missing prerequisite (e.g., previous VAN)
- `-3`: Duplicate VAN
- `-4/-5`: Timing violations (late VAN)
- `-6`: Capacity exceeded
- `-7`: Memory allocation failure

## Integration Points

- **gen3_vote.c**: Uses finalized VAN hashes for consensus voting
- **gen3_ssd.c**: Persists VANs to SSD storage
- **validator.c**: Processes transactions from validated VANs
- **gen3_net.c**: Transmits/receives VAN packets

## Performance Considerations

- Bitmap (havebits) for O(1) duplicate detection
- Hash table for transaction ID lookup
- Pre-allocated arrays avoid dynamic allocation
- SIMD-friendly hash computation (4 transactions at a time)

## Security Properties

- **Integrity**: vantxidshash commits to all transaction IDs
- **Ordering**: Chained hashes enforce VAN sequence
- **Non-repudiation**: Signed VANs (first/last) provide attribution
- **Capacity limits**: Prevent DoS through VAN flooding
