# Tockchain Build System Documentation

## Overview

The Tockchain build system uses GNU Make with a sophisticated configuration for handling C/C++ mixed compilation, multiple network targets, and AppImage packaging for distribution.

## Build Configuration

### Compiler Settings

```makefile
CC = gcc -I. -Icryptolibs -Iutils -Inetlibs -Ivalidator -Itransactions -Ibridge -Igenerator -Ivapps -Icore
CXX = g++
CFLAGS = -Wall -Wextra -g
CXXFLAGS = -Wall -Wextra -g -std=c++11
```

### Include Paths

The build includes headers from multiple directories:
- `.` - Root directory
- `cryptolibs/` - Cryptographic libraries
- `utils/` - Utility functions
- `netlibs/` - Network libraries
- `validator/` - Validator module
- `transactions/` - Transaction handling
- `bridge/` - Ethereum bridge
- `generator/` - Block generator
- `vapps/` - Valis applications
- `core/` - Core functionality

## Network Targets

The build supports multiple network configurations via the `NETWORK` define:

```makefile
NETWORK ?= DEVNET  # Default

# Available networks:
# - DEVNET   - Development network
# - TESTNET2 - Test network 2
# - MININET1 - Minimal test network
```

Build for specific network:
```bash
make NETWORK=TESTNET2 valis
```

## Build Targets

### Primary Executables

| Target | Source | Purpose |
|--------|--------|---------|
| `valis` | `main.c` | Main validator/generator node |
| `txblast` | `main.c` + `-DTXBLAST` | Transaction load testing |
| `wsdprog` | `websocketd.c` | WebSocket daemon (vpoint) |
| `mtx` | `vapps/maketx.c` | Transaction creation tool |
| `vcli` | `vapps/cli.c` | Command-line interface |
| `l1` | `main.c` + `-DVALISL1` | L1 validator mode |
| `keygen` | `vapps/keygen.c` | Key generation utility |
| `msigd` | `vapps/sig.c` | Multi-signature daemon |

### AppImage Packages

| AppImage | Binary | Distribution Name |
|----------|--------|-------------------|
| `generator.AppImage` | `valis` | Block generator |
| `vpoint.AppImage` | `wsdprog` | WebSocket endpoint |
| `validator.AppImage` | `l1` | Validator node |
| `vcli.AppImage` | `vcli` | CLI tool |
| `keygen.AppImage` | `keygen` | Key generator |
| `msigd.AppImage` | `msigd` | Multi-sig daemon |

## Library Dependencies

### Static Libraries (Linked Statically)

```makefile
BASE_LIBS = -Wl,-Bstatic -lsecp256k1 -lgmp -luuid -lsnappy -lm -Wl,-Bdynamic
```

- `secp256k1` - Elliptic curve cryptography
- `gmp` - GNU Multiple Precision arithmetic
- `uuid` - UUID generation
- `snappy` - Compression
- `m` - Math library

### Network Libraries (Dynamic)

```makefile
NET_LIBS = -lmemcached -lnanomsg -lwebsockets -lnng -lcurl -levent
```

- `memcached` - Caching
- `nanomsg` - Messaging
- `websockets` - WebSocket support
- `nng` - Nanomsg-next-generation
- `curl` - HTTP client
- `event` - Event handling

### Safeheron Libraries (TSS)

```makefile
SAFEHERON_LIBS = -Wl,--whole-archive -lMultiPartySig -lSafeheronCryptoSuites $(EXTRA_SAFEHERON_LIBS) -Wl,--no-whole-archive -lcrypto
```

- `MultiPartySig` - Multi-party signature
- `SafeheronCryptoSuites` - Cryptographic primitives
- `crypto` - OpenSSL crypto

### Protobuf Libraries

```makefile
PROTOBUF_LIBS = -lprotobuf -lprotobuf-lite
```

## Build Process

### Object File Compilation

Each executable has a two-step build:

1. **Compile to object file**:
```makefile
valis.o: main.c
    $(CC) $(CFLAGS) $(ABI_FLAGS) -D$(NETWORK) -O1 -fopenmp -c main.c -o valis.o
```

2. **Link to executable**:
```makefile
valis: valis.o K12fast.o libwrapper.a
    $(CXX) -fopenmp -o valis valis.o K12fast.o $(LINK_FLAGS) $(LIB_PATHS) -lwrapper $(SAFEHERON_LIBS) $(BASE_LIBS) $(NET_LIBS) $(CPP_LIBS) $(PROTOBUF_LIBS) $(RPATH)
```

### Critical Build Flags

```makefile
# ABI compatibility (critical for protobuf)
ABI_FLAGS = -D_GLIBCXX_USE_CXX11_ABI=0

# Linker flags for ABI issues
LINK_FLAGS = -Wl,--no-as-needed -Wl,--allow-multiple-definition -Wl,-export-dynamic

# Runtime library path
RPATH = -Wl,-rpath,\$$ORIGIN
```

### Wrapper Library

The C++ wrapper for Safeheron is built as a static library:

```makefile
wrapper.o: cryptolibs/heronglue.cpp cryptolibs/heronglue.h
    g++ -Wall -Wextra -g -DDEVNET -O1 -fopenmp -c cryptolibs/heronglue.cpp -o wrapper.o

libwrapper.a: wrapper.o
    ar rcs libwrapper.a wrapper.o
```

### KangarooTwelve Hash

Two versions of the K12 hash are built:

```makefile
K12.o: cryptolibs/K12.c
    $(CC) $(CFLAGS) -c cryptolibs/K12.c -o K12.o

K12fast.o: cryptolibs/K12.c
    $(CC) $(CFLAGS) -O1 -c cryptolibs/K12.c -o K12fast.o
```

## AppImage Creation

AppImages are self-contained executables for Linux distribution:

```makefile
generator.AppImage: valis
    @mkdir -p generator.AppDir/usr/bin generator.AppDir/usr/lib
    @cp valis generator.AppDir/usr/bin/
    @ln -sf usr/bin/valis generator.AppDir/AppRun
    @echo "[Desktop Entry]..." > generator.AppDir/generator.desktop
    @./copy_deps.sh valis generator.AppDir
    @patchelf --set-rpath \$$ORIGIN/../lib generator.AppDir/usr/bin/valis
    @$(APPIMAGE_TOOL) generator.AppDir generator.AppImage
```

The `copy_deps.sh` script copies all shared library dependencies into the AppImage.

## Build Commands

```bash
# Build all targets
make all

# Build specific target
make valis

# Build for specific network
make NETWORK=TESTNET2 valis

# Clean build artifacts
make clean

# Build with extra Safeheron libs
make EXTRA_SAFEHERON_LIBS="-lSomeLib" valis
```

## Compilation Defines

| Define | Purpose |
|--------|---------|
| `DEVNET` | Development network configuration |
| `TESTNET2` | Test network 2 configuration |
| `MININET1` | Minimal network configuration |
| `TXBLAST` | Transaction blaster mode |
| `WEBSOCKETD` | WebSocket daemon mode |
| `VALISL1` | L1 validator mode |
| `MAKETX` | Transaction maker mode |

## Directory Structure

```
valis/
├── Makefile.txt          # Build configuration
├── main.c                # Main entry point
├── websocketd.c          # WebSocket daemon
├── cryptolibs/           # Crypto libraries
│   ├── K12.c             # KangarooTwelve
│   ├── heronglue.cpp     # Safeheron wrapper
│   └── ...
├── utils/                # Utility functions
├── netlibs/              # Network libraries
├── validator/            # Validator module
├── bridge/               # Ethereum bridge
├── generator/            # Block generator
├── vapps/                # Applications
│   ├── maketx.c          # Transaction maker
│   ├── cli.c             # CLI
│   ├── keygen.c          # Key generator
│   └── sig.c             # Signature daemon
└── tests/                # Test suite
```

## Troubleshooting

### ABI Issues

If you see symbol errors related to protobuf or C++ standard library:
- Ensure `ABI_FLAGS = -D_GLIBCXX_USE_CXX11_ABI=0` is set
- Use `--allow-multiple-definition` linker flag

### Missing Libraries

Check library paths:
```bash
ldconfig -p | grep <library_name>
```

### AppImage Issues

If AppImage fails to run:
1. Check `copy_deps.sh` copied all dependencies
2. Verify `patchelf` set correct rpath
3. Test with `./generator.AppImage --appimage-extract` to inspect

## Related Documentation

- [TOCKCHAIN_ARCHITECTURE.md](TOCKCHAIN_ARCHITECTURE.md) - System architecture
- [DOC_test_suite.md](DOC_test_suite.md) - Test framework
- [DOC_cryptolibs.md](DOC_cryptolibs.md) - Cryptographic libraries
