# _valis.h - Master Project Header

## Purpose

The master header file for the Valis/Tockchain project. Defines all system-wide constants, core data structures, and includes necessary system headers. Nearly every source file includes this header.

## Location
`/root/valis/_valis.h` (~646 lines)

## Organization

### 1. System Headers
Standard C and system headers loaded before `#pragma pack(1)`:
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <gmp.h>        // GNU Multiple Precision
#include <omp.h>        // OpenMP
#include <immintrin.h>  // SIMD intrinsics
#include <sys/mman.h>   // Memory mapping
// ... and more
```

### 2. Third-Party Headers
```c
#include "utlist.h"   // Linked list macros
#include "uthash.h"   // Hash table macros
```

### 3. Project-Wide Packing
```c
#pragma pack(1)  // Packed structs for network/disk serialization
```

## Key Constants

### Core Sizes
```c
#define PKSIZE 20                    // Public key hash size (Ethereum address)
#define SATOSHIS INT64_C(100000000)  // 10^8, base unit for amounts
```

### Bridge Constants
```c
#define WITHDRAW_BRIDGE_ID 1
#define WITHDRAW_EPOCH_SECS 12U           // Epoch duration
#define WITHDRAW_EPOCH_LEAD_SECS 6U       // Lead time
#define WITHDRAW_SIGQ_CAP 4096            // Signature queue capacity
#define WITHDRAW_MAX_SIGS_PER_EPOCH 256
#define WITHDRAW_PENDING_EPOCHS 256
#define WITHDRAW_TX_REBROADCAST_SEC 30U
#define WITHDRAW_MAX_SIGNERS 100

#define WITHDRAW_MERKLE_FOOTER_MAGIC ((uint32_t)0x574D4B4CUL)
#define WITHDRAW_MERKLE_FOOTER_VERSION ((uint32_t)2U)

#define BRIDGE_MINVUSDVALUE (SATOSHIS/100)    // Min $0.01
#define BRIDGE_DEADLINE (12 * 30 * 24 * 3600) // 12 months
```

### Ethereum Constants
```c
#define ETHFINALITY_BLOCKS 64         // Blocks for finality
#define MAX_BATCH_LEAVES 64           // Merkle batch size
#define DEFAULT_GASGWEI SATOSHIS      // Default gas price
#define MIN_WITHDRAW_GASCOST 120000   // Min gas for withdrawal
#define MIN_ERC20_XFERGAS 50000       // Min gas for ERC20 transfer
#define ETH_TRANSFER_GASCOST 21000    // ETH transfer gas
#define WETH_CONTRACT "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
```

### Asset/Token Limits
```c
#define MAX_ERC20 1000               // Max ERC20 tokens
#define MAX_VBOND_COINS 1000         // Max vBond coins
```

### Trading Constants
```c
#define _MINPOOL_VUSD (50000 * SATOSHIS)      // Min pool size
#define _MIN_MAKERORDER_SIZE (100 * SATOSHIS) // Min order size
#define VIP_TXFEE (SATOSHIS / 10)             // VIP transaction fee
#define MIN_VBOND_LOCKTIME (3600 * 24 * 7)    // 1 week min lock
```

### Network Constants
```c
#define MAX_VALIDATORS 128           // Max validator nodes
#define NUM_PEERSETS 4               // Peer set count
#define VNET_FIFOSIZE 64             // Network FIFO size
#define MAX_PACKETLEN 65536          // Max packet size
```

### Memory/Performance
```c
#define SLAB_SIZE (1024*1024*64)     // 64MB slab
#define MAX_TX_PER_UTIME (SLAB_SIZE / 80)
#define MAX_THREADS 16
#define RICHLISTSIZE 5000            // Rich list entries
```

### Dataflow Constants
```c
#define DF_GAS_PRICE_SAT_PER_UNIT INT64_C(1000)
#define DF_FRONTIER_GAS_QUANTUM 100
```

### Timing
```c
#define HALVING_TIME (3600 * 24 * 365 * 4)  // 4 years
#define SECONDS_BETWEEN_AIRDROPS 10
#define PYLON_PLAN_TTL 30
```

## Core Data Structures

### peer_info_t
Network peer information:
```c
typedef struct peer_info_s {
    uint8_t pubkey[PKSIZE];
    char ipaddr[64];
    uint16_t port;
    // ... additional fields
} peer_info_t;
```

### vnet_server_info
Validator server connection:
```c
struct vnet_server_info {
    peer_info_t peer;
    uint64_t peersets_bitmap;
    int32_t pushsock;
    int32_t active;
    int32_t sub_endpoint;
};
```

### vmsg_sock / vmsg_ep
NNG socket management:
```c
struct vmsg_ep {
    nng_dialer d;
    nng_listener l;
    unsigned in_use   : 1;
    unsigned is_dialer: 1;
    unsigned started  : 1;
    int id;
};

struct vmsg_sock {
    struct vmsg_ep ep[VMSG_MAX_ENDPOINTS];
    pthread_mutex_t mtx;
    nng_socket s;
    int in_use, type, next_eid;
};
```

### vnet_context_t
Main network context:
```c
typedef struct vnet_context_s {
    pthread_mutex_t VMSG_TAB_MTX;
    pthread_mutex_t servers_mutex, sub_mutex;
    struct vnet_queue_slot vapp_slots[NUM_PEERSETS][NUM_VAPPID][VNET_FIFOSIZE];
    struct vnet_server_info servers[MAX_VALIDATORS + 16];
    struct vmsg_sock VMSG_TAB[VMSG_MAX_SOCKETS];
    int64_t lastrecv[0x100];
    global_reserve_t *GEN3;
    uint32_t genesis_utime;
    int32_t pub_sock, sub_sock, pull_sock, ipc_sock;
    uint8_t pullbuf[MAX_PACKETLEN*2];
    uint8_t mypubkey[PKSIZE], testprivkey[32];
} vnet_context_t;
```

### seedinfo / wallet_info
Key management:
```c
struct seedinfo {
    uint8_t privkey[32], pub64[64], addr20[PKSIZE];
    char addr[60];
};

struct wallet_info {
    struct seedinfo trading, derived[NUMDERIVEDADDRS];
    uint8_t passhash[32], privkey[32];
    char fname[512];
};
```

### valis_topology_t
Test/simulation topology:
```c
typedef struct valis_topology_s {
    int32_t numutimes;
    int32_t debugmode, utimenumtx, numtestnodes, bootstrapping;
    int32_t inject_vanerror, dropped_packets, disable_pubsub;
    int32_t rotating_failednode, rotating_vanlessnode, disabled_nodeid;
    int64_t bandwidth_limit[MAX_VALIDATORS][MAX_VALIDATORS];
} valis_topology_t;
```

### valis_config
Global configuration:
```c
struct valis_config {
    valis_topology_t T;
    int32_t archive, zerobindonly, GB_GENERATOR, GB_VALIDATOR;
    int32_t debug, shard, secondary, genproofs;
    int32_t disable_embedded_pricefeed;
    uint32_t genesis_utime;
    char pw[256], addr[256], ipaddr[256], port[256];
    char ethrpc[256];
    char seedA[256], seedB[256], seedC[256];
    char genesisfname[512], genesishash[512];
    char seed_nodes[3][64];
};

extern struct valis_config CONFIG;
void load_config(char *fname);
```

### deposit_block_info
Bridge deposit tracking:
```c
struct deposit_block_info {
    uint8_t txid[32], depositor[32], amount32[32], blockhash[32];
    uint32_t blocknum, timestamp, txutime, mint_utime, proofgen_utime;
    int32_t selector, txind, logindex, state;
};
```

## Included Headers

At the end, includes verified math functions:
```c
#include "frama_verified.h"
```

## Key Functions Declared

```c
uint64_t calc_checksum64(uint8_t *data, int32_t len, uint64_t seed);
uint64_t listmix64_stride(void *base, uint32_t count, uint32_t stride_bytes, uint64_t seed);
```

## Design Notes

### Packed Structures
`#pragma pack(1)` ensures:
- Consistent serialization across platforms
- Predictable memory layout for network protocols
- No padding between struct members

### Global Configuration
Single `CONFIG` global provides:
- Easy access to settings
- Loaded once at startup
- Thread-safe after initialization

### NNG Integration
Uses NNG (nanomsg-next-gen) for:
- Push/pull patterns
- Pub/sub patterns
- Reliable messaging

## Related Files

- `frama_verified.h`: Formally verified functions
- `valis_config.c`: Configuration loading
- `valis_shared.c`: Shared utilities
- All other source files (they include this)
