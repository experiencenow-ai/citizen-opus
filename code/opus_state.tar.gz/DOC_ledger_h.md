# Ledger Header Documentation

**File:** `validator/ledger.h`  
**Lines:** 528  
**Module:** Validator/Ledger  
**Documented by:** Opus (Wake 1304)

---

## Overview

The ledger header (`ledger.h`, originally `valistx.h`) defines the core transaction types, asset ID layouts, and data structures for the Valis/Tockchain ledger system. This is the fundamental type definition file for all transaction processing.

---

## Synthetic Asset ID Layout

The system reserves the top 1024 asset IDs for synthetic/internal purposes. These grow downward from the top of the aid space.

### Singles (Top of Space)
| ID | Name | Purpose |
|----|------|---------|
| `SYNTH_AID_TOP - 1` | `_COINSMINTED` | Track minted coins |
| `SYNTH_AID_TOP - 2` | `_COINSBURNED` | Track burned coins |
| `SYNTH_AID_TOP - 3` | `_POOLSHARES` | LP token tracking |
| `SYNTH_AID_TOP - 4` | `_BRIDGESTATE` | Bridge state storage |
| `SYNTH_AID_TOP - 5` | `_ASSET_DF_META` | Dataflow metadata |
| `SYNTH_AID_TOP - 6` | `_ASSET_DF_SPEND_WILDCARD` | DF spend wildcard |
| `SYNTH_AID_TOP - 7` | `_ADDRESS_LABEL` | Address labeling |
| `SYNTH_AID_TOP - 8` | `_ADDRESS_LABEL2` | Secondary labels |
| `SYNTH_AID_TOP - 9` | `_ASSET_DF_CRV` | DF curve data |

### UFC Alpha Slots (16 slots)
Used for storing alpha state per pool (see `ufc_planner.c`).
- Base: `_UFC_ALPHA0`
- Count: `UFC_ALPHA_NUM_SLOTS` (16)

### Pylon Cold Slots (12 slots)
Used for pylon cold storage.
- Base: `_PYLON0`
- Count: `PYLON_COLD_NUM_SLOTS` (12)

### DF Synthetic Slots (512 slots)
User registers and installed dataflow slots.
- Base: `_DF_SYNTHETIC_BASE`
- Installed slots: `_DF_INSTALLED_SLOT0` (8 slots)

### Module Release Records (12 slots)
Track dataflow module releases.
- Base: `_DF_MODREC0`

### Frontier Tracking (4 slots)
Track worst frontier values.
- Base: `_DF_FRONTIER_WORST0`

### Trigger Slots (4 slots)
Trigger check storage.
- Base: `_TRIG0`

---

## Chain IDs

```c
#define ETHEREUM_CHAINID ((1 << DESTCHAINBITS) - 1)
#define SOL_CHAINID      ((1 << DESTCHAINBITS) - 2)
#define TBD_CHAINID      ((1 << DESTCHAINBITS) - 3)
```

---

## Transaction Flags

### Base Flags (`SHARED_FLAGS`)
Common flags present in all transaction types:
- `txtype`: Transaction type identifier
- `destchain`: Destination chain bits
- `is_fee`: Fee transaction flag

### Transaction Type Flags

#### `txflags` - Standard Transaction
Basic transfer flags.

#### `poolflags` - Pool Operations
```c
#define POOLFUNCTION_SWAP     0
#define POOLFUNCTION_WITHDRAW 1
#define POOLFUNCTION_DEPOSIT  2
#define POOLFUNCTION_DEPOSIT2 3
```

#### `orderflags` - Order Book
```c
makerorder:1,    // Place maker order
takerorder:1,    // Take existing order
cancelorder:1,   // Cancel order
OTCtrade:1,      // OTC trade
claimcoinbase:1  // Claim coinbase reward
```

#### `bridgeflags` - Bridge Operations
```c
#define BRIDGE_CREATE_ASSET 0
#define BRIDGE_MINT_ASSET   1

function:2,      // Bridge function
mintable:1,      // Asset is mintable
signer:2,        // Signer type (single/multisig/threshold/validators)
external:1       // External bridge
```

#### `systemflags` - System Transactions
```c
#define SYSTEMTX_ADD_CANDIDATE     0
#define SYSTEMTX_PROMOTE_CANDIDATE 1
#define SYSTEMTX_REMOVE_CANDIDATE  2
#define SYSTEMTX_REMOVE_VOTER      3
#define SYSTEMTX_CHANGE_IPADDR     4
#define SYSTEMTX_NODESTATS         5
```

#### `dataflow_txflags` - Dataflow Operations
```c
#define DF_TXFUNC_BATCH      0
#define DF_TXFUNC_DEPLOY     1
#define DF_TXFUNC_RESTORE    2
#define DF_TXFUNC_MOD_UPDATE 3
```

#### `auctionflags` - Auction Operations
```c
#define AUCTION_START 1
#define AUCTION_BID   2
#define AUCTION_CLAIM 3
```

---

## Transaction Structures

### Common Transaction Header
```c
struct txheader {
    uint8_t sig[65];      // Signature
    assetid_t asset;      // Asset ID
    union {               // Type-specific flags
        txflags F;
        poolflags P;
        msigflags MS;
        lockflags L;
        orderflags O;
        bridgeflags B;
        systemflags S;
        airdropflags A;
        datatxflags D;
        auctionflags AC;
        dataflow_txflags DF;
    } flags;
    uint8_t pad;
    uint32_t utime;       // Unix timestamp
    uint8_t pylon[2][32]; // Pylon references
};
```

### Standard Transaction (`stdtx`)
```c
struct stdtx {
    struct txheader H;
    uint8_t srcaddr[PKSIZE];
    uint8_t destaddr[PKSIZE];
    int64_t amount;
};
```

### Dataflow Transaction (`dataflow_tx`)
```c
struct dataflow_tx {
    COMMON_TX;
    uint64_t df_metaval;
    uint8_t abi_version;
    uint8_t call_count;
    uint8_t pipe_count;
    uint8_t spend_entry_count;
    uint8_t addr_count;
    uint8_t asset_count;
    uint16_t df_flags;
    uint16_t dfdata_len;
    uint16_t datalen;
    uint8_t data[];  // Variable payload
};
```

**Payload for DEPLOY:**
- `df_image_header_t` (32 bytes)
- bytecode

**Payload for BATCH:**
- spend entries
- address context
- asset context
- calls
- userdata

### Multisig Transaction (`multisigtx`)
```c
struct multisigtx {
    LOCKTIME_TX;
    uint8_t M, N;           // M-of-N threshold
    uint8_t pubkeys_sig66[]; // Public keys and signatures
};
```

### Data Transaction (`datatx`)
```c
struct datatx {
    COMMON_TX;
    uint16_t datalen;
    uint16_t logindex;
    uint16_t sigslen;
    uint8_t data[];
};
```

### Airdrop Data
```c
typedef struct {
    assetid_t target;      // Reference asset (0 for pure airdrop)
    int64_t amount;        // Payout amount or ratio
    int64_t min_liveness;  // Minimum adjVUSDvalue for eligibility
    uint8_t pad[2];
} airdropdata_t;
```

---

## Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| `MAKETX_UTIME_DELAY` | 6 | Delay for transaction creation |
| `NUMSPECIAL_ASSETS` | 1024 | Reserved synthetic asset slots |
| `MAXASSETS` | `(1 << NUM_ASSETID_BITS) - 1024` | Maximum regular assets |
| `AUCTION_MINBID` | `SATOSHIS` | Minimum auction bid |

---

## Bridge Signer Types

```c
#define BRIDGESIGNER_SINGLE     0  // Single signer
#define BRIDGESIGNER_MULTISIG   1  // M-of-N multisig
#define BRIDGESIGNER_THRESHOLD  2  // Threshold signature
#define BRIDGESIGNER_VALIDATORS 3  // Validator set
```

---

## Macros

### Transaction Building
```c
#define COMMON_TX struct txheader H; uint8_t srcaddr[PKSIZE], destaddr[PKSIZE]; int64_t amount;
#define LOCKTIME_TX COMMON_TX; uint32_t locktime
```

---

## Static Assertions

The file includes compile-time checks:
```c
_Static_assert(_SYNTH_SLOTS_USED <= NUMSPECIAL_ASSETS, "synthetic aids exceed 1024 budget");
```

This ensures synthetic asset allocation doesn't exceed the reserved space.

---

## Integration Points

- **validator.c**: Uses transaction structures for validation
- **ledger_*.c**: Implements handlers for each transaction type
- **UFC/**: Uses pool and order transaction types
- **bridge/**: Uses bridge transaction types
- **DF/**: Uses dataflow transaction types

---

## Design Notes

1. **Packed Structures**: `#pragma pack(1)` ensures no padding for network serialization
2. **Union Flags**: Single flags field with type-specific interpretation
3. **Extensible**: TBD bits reserved in each flag type for future use
4. **Synthetic IDs**: Downward allocation prevents collision with regular assets
