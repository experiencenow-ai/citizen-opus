# Pylon v7.2 Specification Documentation

**Source:** `/root/valis/specs/pylon_v7.txt`  
**Lines:** 258  
**Author:** Opus (wake 1323)  
**Last Updated:** 2026-01-13

---

## Overview

Pylon is Tockchain's **post-quantum secure hash-based second factor** authentication system. It provides protection against quantum computer attacks on ECDSA signatures by adding a hash-chain-based authentication layer.

**Key Insight:** While quantum computers can break ECDSA (Shor's algorithm), hash preimage resistance remains quantum-hard (256-bit hash gives ~128-bit Grover security). Pylon leverages this asymmetry.

---

## 1. Threat Model

### Quantum Computer Assumptions
- ECDSA/ETH-style signatures are assumed **forgeable** once a pubkey is known (QC adversary)
- Hash preimage resistance **remains QC-hard** (Grover's algorithm only provides quadratic speedup)

### Security Guarantees by Mode

| Mode | Theft Prevention | Griefing | Trust Requirement |
|------|-----------------|----------|-------------------|
| FAST | Only with trusted submission | N/A | Trusted generator/coldvan |
| PQVAULT | Full (even with malicious generator) | Possible | None |

---

## 2. Address Modes

### 2.1 PYLON_NONE (0)
Standard ECDSA address with no Pylon protection.

### 2.2 PYLON_FAST (1)
**Single-transaction, high-throughput mode.**

- Best for: High-frequency trading, automated systems
- Security: Requires trusted submission channel
- Throughput: Multiple transactions per tock

### 2.3 PYLON_PQVAULT (2)
**Two-step COMMIT→REVEAL mode.**

- Best for: Cold storage, high-value accounts
- Security: Funds-safe without PQ signatures
- Throughput: One operation per two tocks minimum

---

## 3. On-Chain State

### Per-Address Persistent State

```c
pylon_state_t:
    plan_hash[32]    // Active plan commitment (PQVAULT only)
    anchor[32]       // Current spend anchor
    seed_next[32]    // Staged next value

addrhashentry:
    pylon:2          // Mode: NONE=0, FAST=1, PQVAULT=2
    pylondirty:1     // FAST: seed_next is staged
    pylon_plan_utime // PQVAULT: utime of last COMMIT
```

### State Usage by Mode

| Field | FAST | PQVAULT |
|-------|------|---------|
| plan_hash | Must be zero | Active plan commitment |
| anchor | Current spend anchor | Spend anchor |
| seed_next | Staged C_next for tock | Control-chain head |
| pylondirty | Indicates staged seed_next | Ignored |
| pylon_plan_utime | Unused | Last COMMIT time |

---

## 4. Domain Separation

All hash operations use domain-separated prefixes to prevent cross-protocol attacks:

```c
PYLON_DOMAIN_FAST_STR     = "PYLON:FAST:"   // 11 bytes
PYLON_DOMAIN_PQ_SPEND_STR = "PYLON:PQ:S:"   // 11 bytes
PYLON_DOMAIN_PQ_CTRL_STR  = "PYLON:PQ:C:"   // 11 bytes
PYLON_DOMAIN_PQ_PLAN_STR  = "PYLON:PQ:P:"   // 11 bytes
```

### Hash Functions

```
H_FAST(key)      = H("PYLON:FAST:" || key)
H_PQ_SPEND(key)  = H("PYLON:PQ:S:" || key)
H_PQ_CTRL(key)   = H("PYLON:PQ:C:" || key)
H_PQ_PLAN(plan)  = H("PYLON:PQ:P:" || H(plan))  // Double-hash for efficiency
```

---

## 5. FAST Mode Protocol

### 5.1 Wire Format

Every transaction from a FAST Pylon address includes:
- `txH.pylon[0]` = K_curr (32 bytes) - current key preimage
- `txH.pylon[1]` = C_next (32 bytes) - next anchor commitment

### 5.2 Verification Steps

1. Check: `H_FAST(K_curr) == anchor`
2. If `seed_next == 0`: 
   - Set `seed_next = C_next`
   - Set `pylondirty = 1`
3. Else: 
   - Require `seed_next == C_next` (all FAST txs in tock share same C_next)

### 5.3 End-of-Tock Finalization

If `pylondirty` is set:
```
anchor := seed_next
seed_next := 0
pylondirty := 0
```

### 5.4 Multiple Transactions Per Tock

FAST mode supports multiple transactions per tock because:
- All transactions in the same tock must use the same `C_next`
- Order doesn't matter - they all advance to the same next state
- This enables high-frequency trading patterns

### 5.5 Security Limitation

**FAST is PQ-unsafe without trusted submission** because a malicious generator can:
1. Observe `K_curr` in the transaction
2. Substitute the transaction body while keeping the valid `K_curr`
3. Execute a different transaction than the user intended

Mitigation: Use coldvans (trusted submission channels) or trusted generators.

---

## 6. PQVAULT Mode Protocol

PQVAULT provides full post-quantum security through a two-step protocol:

### 6.1 Protocol Flow

```
COMMIT (control-chain gated)
    ↓
[wait at least 1 tock]
    ↓
REVEAL/EXEC (spend-chain gated)
```

### 6.2 Plan Structure

```
plan_bytes =
    next_spend_anchor[32] ||    // New spend chain head
    next_control_head[32] ||    // New control chain head
    inner_tx_bytes...           // The actual transaction
```

**Constraints:**
- `next_spend_anchor != 0`
- `next_control_head != 0`
- Inner tx must have:
  - `srcaddr == outer locktx.srcaddr`
  - `txH.pylon` all-zero
  - Not be a LOCK handler tx
  - `txH.utime == 0` (placeholder)

### 6.3 INIT Operation

**Flag:** `LOCKTX_FLAG_PYLON_INIT`

Initializes a Pylon address:
- If `txH.pylon[1] == 0`: Initialize as FAST
- Else: Initialize as PQVAULT

**PQVAULT Initialization:**
```
anchor := H_PQ_SPEND(K_spend_0)
seed_next := H_PQ_CTRL(K_ctl_0)
plan_hash := 0
pylon_plan_utime := 0
```

### 6.4 COMMIT Operation

**Flag:** `LOCKTX_FLAG_PYLON_COMMIT`

**Inputs:**
- `txH.pylon[0]` = plan_hash (must be non-zero)
- `txH.pylon[1]` = K_ctl_curr (control chain preimage)

**Checks:**
1. `plan_hash != 0`
2. If plan already active and `utime_now - pylon_plan_utime < PYLON_PLAN_TTL`: reject
3. `H_PQ_CTRL(K_ctl_curr) == seed_next`

**State Updates:**
```
seed_next := K_ctl_curr
plan_hash := plan_hash
pylon_plan_utime := utime_now
```

### 6.5 REVEAL/EXEC Operation

**Flag:** `LOCKTX_FLAG_PYLON_REVEAL`

**Inputs:**
- `txH.pylon[0]` = K_spend_curr (spend chain preimage)
- `txH.pylon[1]` = all-zero (required)
- `plan_body` = the plan bytes

**Checks:**
1. `txH.utime > pylon_plan_utime` (prevents same-tock COMMIT→REVEAL)
2. `plan_hash == H_PQ_PLAN(plan_body)`
3. `H_PQ_SPEND(K_spend_curr) == anchor`
4. `next_spend_anchor != 0`, `next_control_head != 0`
5. Inner tx structural checks

**State Updates (always, even on inner tx failure):**
```
anchor := next_spend_anchor
seed_next := next_control_head
plan_hash := 0
pylon_plan_utime := 0
```

**Execution:**
Before executing inner_tx, ledger sets:
```
inner_txH.utime := outer_reveal_utime
```

### 6.6 ABORT Operation

**Flag:** `LOCKTX_FLAG_PYLON_ABORT`

**Inputs:**
- `txH.pylon[0]` = all-zero
- `txH.pylon[1]` = K_ctl_curr
- `plan_len` = 0

**Checks:**
1. Plan active (`plan_hash != 0`)
2. `H_PQ_CTRL(K_ctl_curr) == seed_next`

**State Updates:**
```
seed_next := K_ctl_curr
plan_hash := 0
pylon_plan_utime := 0
```

---

## 7. Security Analysis

### 7.1 Why PQVAULT is PQ-Safe

1. **COMMIT phase** only pins a plan hash - no funds move
2. **REVEAL phase** requires knowing the spend chain preimage
3. An attacker with quantum computer can forge ECDSA but cannot:
   - Find hash preimages (spend/control chains)
   - Substitute a different plan (hash commitment)
   - Execute without the spend chain secret

### 7.2 Griefing Attacks

PQVAULT is griefable but not stealable:

| Attack | Impact | Mitigation |
|--------|--------|------------|
| COMMIT censorship | Delays spending | Use multiple submission paths |
| COMMIT mismatch | Wrong plan committed | TTL-based overwrite |
| REVEAL censorship | Delays execution | Plan remains valid |

### 7.3 Hash Chain Management

**Critical:** Wallets must maintain hash chains correctly.

```
spend_chain: K_n → H_PQ_SPEND(K_n) = K_{n-1} → ... → anchor
control_chain: K_n → H_PQ_CTRL(K_n) = K_{n-1} → ... → seed_next
```

Each operation consumes one link in the chain. Wallets must:
- Pre-generate sufficient chain depth
- Never reuse chain values
- Validate chains before broadcasting

---

## 8. Wallet Implementation Requirements

### 8.1 Validation Function

```c
pylon_wallet_validate(W, strict)
```

**strict=0:** Basic bounds/invariants check
**strict=1:** Full validation:
- Verify chain links: `H_domain(key[i+1]) == key[i]`
- Verify plan commitment: `H_PQ_PLAN(plan_bytes) == plan_hash`
- Verify next heads match plan

### 8.2 Mismatch Recovery

If on-chain `plan_hash` doesn't match wallet's pending plan:

1. WAIT until `(utime_now - pylon_plan_utime) >= PYLON_PLAN_TTL`
2. Send new COMMIT to overwrite

### 8.3 Coldvan Randomization

Wallets SHOULD:
- Randomize coldvan targets per retry
- Blacklist routes/nodes with repeated failures
- Use multiple independent submission paths

---

## 9. Implementation Files

| File | Purpose |
|------|---------|
| ledger_pylon7.c | Main Pylon implementation |
| DOC_ledger_pylon7.md | Code documentation |

---

## 10. Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| PYLON_NONE | 0 | No Pylon protection |
| PYLON_FAST | 1 | Fast mode |
| PYLON_PQVAULT | 2 | Vault mode |
| PYLON_PLAN_TTL | TBD | Minimum time between COMMIT overwrites |

---

## 11. Summary

Pylon provides post-quantum security through hash-based authentication:

- **FAST:** High throughput, requires trusted submission
- **PQVAULT:** Full PQ security, two-step protocol

The key insight is that while quantum computers break ECDSA, they cannot efficiently break hash preimage resistance. By layering hash-chain authentication on top of ECDSA, Pylon provides a migration path to quantum-safe cryptocurrency.

---

*This document is part of the Tockchain documentation project.*
