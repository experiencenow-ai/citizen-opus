# Tockchain Code Review - Wake 1410
**Reviewer:** Opus
**Date:** 2026-01-13
**Scope:** Security-critical areas (consensus, bridge, financial calculations)

## Executive Summary

The codebase shows strong security practices in critical areas:
- **Formal verification** (Frama-C) for financial math functions (99.5% goals proved)
- **Proper bounds checking** in most array accesses
- **Mutex protection** for concurrent data structures
- **Replay protection** via nonce tracking in deposits

However, I identified several areas worth attention:

---

## SIGNIFICANT FINDINGS

### 1. **Bridge Deadline Handling** (Medium Priority)
**Location:** `/root/valis/bridge/bridge_deposit.c:844`

```c
if ((L1->processedutime - dp->timestamp) > BRIDGE_DEADLINE)
```

**Issue:** This arithmetic could underflow if `dp->timestamp > L1->processedutime` (e.g., clock skew between chains). The result would be a very large positive number, incorrectly triggering deadline expiration.

**Recommendation:** Add explicit check:
```c
if (dp->timestamp > L1->processedutime || 
    (L1->processedutime - dp->timestamp) > BRIDGE_DEADLINE)
```

### 2. **Unverified __int128 Operations** (Medium Priority)
**Location:** `/root/valis/coq/pass326/frama/evidence/frama_verified.c:15-60`

The `__int128` functions (`safe_mul_then_div`, `ufc_mul_div_floor`, etc.) are marked as "trusted primitives, not formally verified" because Frama-C doesn't support `__int128`.

**Issue:** These are the exact functions where overflow bugs would be most catastrophic (financial calculations). They're the only unverified code in the critical math path.

**Recommendation:** 
- Add runtime assertions that check for overflow conditions
- Consider property-based testing with extreme values
- Document the trust boundary explicitly

### 3. **File Path Buffer Overflow Risk** (Low Priority)
**Location:** `/root/valis/generator/gen3_vote.c:57-58`

```c
char fname[512];
rawtock_fname(fname,election->utime);
strcat(fname,".Q");
```

**Issue:** If `rawtock_fname` fills close to 512 bytes, `strcat` could overflow.

**Recommendation:** Use `snprintf` or check remaining capacity before `strcat`.

### 4. **TODO: Vans Withholding Attack** (Noted)
**Location:** `/root/valis/generator/gen3.c:34`

```c
// TODO: demote vans witholders
```

**Issue:** This is documented as a known attack vector. A node could send `nodevanshashes` but then not broadcast all transactions.

**Status:** The code notes this is "hardest to solve" and mentions a 30-second timeout solution. Verify this is implemented.

---

## POSITIVE FINDINGS (Security Strengths)

### 1. **Formal Verification Coverage**
The `frama_verified.c` file achieves 99.5% proof coverage (950/955 goals). This is excellent for financial math.

### 2. **Duplicate Transaction Protection**
```c
// validator.c:483
L1->numduplicatetxids++;
```
Duplicate transactions are tracked and rejected.

### 3. **Merkle Proof Verification**
The bridge deposit flow properly verifies:
- Receipt hash matches receipts root
- Transaction hash matches tx root  
- Block hash matches header
- Receipts root matches header

### 4. **Mutex Discipline**
The codebase shows consistent mutex lock/unlock patterns with no obvious deadlock risks (locks acquired in consistent order).

---

## AREAS NOT YET REVIEWED

- [ ] UFC orderbook matching logic
- [ ] Dataflow reactive computation
- [ ] TSS threshold signature aggregation
- [ ] Network message parsing (potential for malformed input attacks)

---

## RECOMMENDATIONS FOR CT

1. **Priority 1:** Review the `__int128` functions - these are the trust boundary
2. **Priority 2:** Add clock skew protection to bridge deadline checks
3. **Priority 3:** Verify vans withholding mitigation is complete

---

*This review focused on significant issues only, per ct's request. Mira is reviewing UFC and dataflow subsystems.*
