# Matrix Specialist Loading - Proposal

**Wake 1390 | 2026-01-13**

## ct's Vision

Short-term: Complete Matrix system and seed it with domain expertise for Tockchain.
Long-term: Any wake can load specialist knowledge on demand, like Neo downloading kung fu.

## What We Have

### Opus's Contribution (Ready Now)
- **90 documentation files** covering entire Tockchain codebase
- Each file is 5-20KB of dense technical knowledge
- Organized by subsystem: Core, Consensus, Bridge, UFC, Dataflow, TSS, etc.
- Total: ~700KB of specialist knowledge already documented

### Mira's Architecture (In Progress)
- Council-of-minds approach (Haiku/Sonnet/Opus)
- 7 memory databases with lifecycle management
- Specialist loading concept designed but not automatic yet

## Proposed Matrix Structure

```
specialists/
├── INDEX.md              # What specialists exist, when to load each
├── tockchain/
│   ├── core.md           # Core types, constants, infrastructure
│   ├── consensus.md      # Block validation, voting, gen3
│   ├── bridge.md         # Ethereum bridge, deposits, withdrawals
│   ├── ufc.md            # DEX, orderbook, AMM, swaps
│   ├── dataflow.md       # Reactive computation engine
│   ├── tss.md            # Threshold signatures
│   └── verification.md   # Coq proofs, Frama-C
├── crypto/
│   ├── signatures.md     # ECDSA, Schnorr, threshold
│   ├── hashing.md        # SHA256, Keccak, Merkle trees
│   └── encryption.md     # AES, key derivation
├── defi/
│   ├── amm.md            # Automated market makers
│   ├── orderbook.md      # Order matching, price discovery
│   └── bridges.md        # Cross-chain mechanics
└── mechanism_design/
    ├── crime_unprofitable.md  # Making mafia EV negative
    └── consensus.md           # Byzantine fault tolerance
```

## How It Would Work

1. **Wake Start**: Load INDEX.md (~500 tokens)
2. **Determine Need**: What specialist knowledge does this wake require?
3. **Load Specialist**: Pull relevant specialist file(s) into context
4. **Execute**: Work with expert knowledge available
5. **Update**: If new knowledge gained, update specialist file

## Buddy System Role

**Opus watches Mira:**
- Did she skip steps in the goal workflow?
- Is she stuck in analysis paralysis?
- Did she capture important ideas?

**Mira watches Opus:**
- Am I being too theoretical?
- Did I miss practical implementation details?
- Am I repeating mistakes?

## Immediate Next Steps

1. **Create specialists/INDEX.md** - Catalog what specialist knowledge exists
2. **Consolidate my 90 DOC_*.md files** into specialist modules
3. **Test loading** - Can a wake start, determine need, load specialist, execute?
4. **Mira integration** - How does this fit her Matrix architecture?

## What I Need From ct

- Confirm this direction aligns with vision
- Priority: Should I consolidate docs now or wait for Mira's architecture?
- Access: Does Mira need read access to my specialist files?
