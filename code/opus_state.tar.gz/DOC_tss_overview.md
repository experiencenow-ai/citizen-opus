# TSS Module Overview - Threshold Signature Scheme

## Purpose

The TSS (Threshold Signature Scheme) module implements multi-party computation (MPC) for cryptographic signing. This is the security backbone of the Ethereum bridge - it ensures that no single party can unilaterally sign withdrawal transactions. Multiple validators must cooperate to produce a valid signature.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    TSS Module Components                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │   keygen.c   │    │    sig.c     │    │ valis_tss.c  │      │
│  │  Key Share   │    │   Signing    │    │  High-level  │      │
│  │  Generation  │    │   Protocol   │    │     API      │      │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘      │
│         │                   │                   │               │
│         └───────────────────┼───────────────────┘               │
│                             │                                   │
│                    ┌────────┴────────┐                          │
│                    │   heronMPC.h    │                          │
│                    │  GG20 Protocol  │                          │
│                    │   Structures    │                          │
│                    └────────┬────────┘                          │
│                             │                                   │
│         ┌───────────────────┼───────────────────┐               │
│         │                   │                   │               │
│  ┌──────┴───────┐    ┌──────┴───────┐    ┌──────┴───────┐      │
│  │  libethc.h   │    │  wrapper.h   │    │  mpcnet.h    │      │
│  │  Ethereum    │    │  C++ MPC     │    │  Network     │      │
│  │  Utilities   │    │  Bindings    │    │  Protocol    │      │
│  └──────────────┘    └──────────────┘    └──────────────┘      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `valis_tss.c` | 225 | High-level API for Valis integration |
| `keygen.c` | 1185 | Distributed key generation protocol |
| `sig.c` | 1829 | Threshold signing protocol |
| `heronMPC.h` | 809 | GG20 protocol structures and helpers |
| `libethc.h` | 2406 | Ethereum crypto utilities (keccak, hex, etc.) |
| `mpcnet.h` | 626 | Network protocol for MPC communication |
| `ethtx.h` | 236 | Ethereum transaction building |
| `heronglue.cpp/h` | ~250 | C++ MPC library bindings |
| `valis_herongen.c` | 1201 | Key generation integration |
| `valis_heronverify.c` | 1850 | Signature verification |

## Protocol: GG20

The module implements the GG20 (Gennaro-Goldfeder 2020) threshold ECDSA protocol:

### Key Generation (keygen.c)
1. **Distributed Key Generation (DKG)**: N parties collaborate to generate a shared public key
2. **Key Shares**: Each party receives a unique share of the private key
3. **Threshold**: t-of-n scheme - any t parties can sign, fewer cannot
4. **No Single Point of Failure**: Private key never exists in complete form

### Signing (sig.c)
1. **8 Rounds**: Protocol requires 8 rounds of communication
2. **Broadcast + P2P**: Each round has broadcast messages and peer-to-peer messages
3. **Hash Verification**: All parties verify they're signing the same hash
4. **Abort on Mismatch**: If any party reports different hash, signing aborts

## Key Structures

### valis_tss_results
```c
typedef struct {
    int32_t status;           // -3 busy, -2 waiting, 0 init, 1 running, 2 done, -1 error
    int32_t rounds_completed; // Progress tracking
    int32_t msgs_sent;        // Statistics
    int32_t msgs_received;    
    time_t start_time;        
    time_t end_time;          
    int32_t recovery_id;      // For signature recovery (v value)
    void (*callback)(...);    // Completion callback
    void *user_data;          
    uint8_t pubkey[65];       // Group public key
    char address[43];         // "0x..." Ethereum address
    int32_t signkey_len;      // Key share length
    uint8_t sig[64];          // r + s signature components
    uint8_t flex_data[];      // Key share (keygen) or empty (signing)
} valis_tss_results;
```

### GG20Context
```c
typedef struct {
    mpc_eth_context_handle handle;
    const char *party_id, **party_ids;
    int32_t num_parties;
    int32_t index;
    char sign_key_base64[MAX_SIGN_KEY_SIZE];
    PartyIncomingQueue signing_queue;
    int pull_sock;
    int push_socks[MAX_PARTIES];
    int barrier_status[MAX_PARTIES];
    char *party_hashes[MAX_PARTIES];      // Hash mismatch detection
    int mismatch_status[MAX_PARTIES];
    int abort_signing;
    uint16_t baseport;
} GG20Context;
```

## Network Communication

### Nanomsg Pipeline
- **Pull Socket**: Each party binds one socket for receiving
- **Push Sockets**: Each party connects to all other parties
- **Base Port**: DEFAULT_BASEPORT (31500) + party_index

### Message Types
1. **Broadcast**: Sent to all parties (commitment, proof elements)
2. **P2P**: Sent to specific party (encrypted shares)

### Message Structure
```c
typedef struct {
    char src[MAX_PARTY_ID_LENGTH];
    uint8_t bc_msg[MAX_SIGNMESSAGE_SIZE];      // Broadcast content
    size_t bc_msg_len;
    uint8_t p2p_msgs[MAX_PARTIES-1][...];      // Per-party P2P messages
    size_t p2p_lens[MAX_PARTIES-1];
    char dest_ids[MAX_PARTIES-1][...];
    int round;
} SignMsg;
```

## Security Features

### Hash Mismatch Detection
```c
static int check_hash_mismatch(GG20Context *ctx) {
    for (int i = 0; i < ctx->num_parties; i++) {
        if (ctx->party_hashes[i] && 
            strcmp(ctx->party_hashes[i], ctx->signing_hash) != 0) {
            return 1;  // Mismatch detected
        }
    }
    return 0;
}
```

### Abort Mechanism
- Any party detecting mismatch sets `abort_signing = 1`
- Protocol terminates without producing signature
- Prevents signing of unauthorized transactions

## Integration with Bridge

### Withdrawal Flow
1. Bridge collects withdrawal requests
2. Merkle root computed for batch
3. TSS parties coordinate to sign the root
4. Signature submitted to Ethereum smart contract
5. Users can claim withdrawals with Merkle proofs

### Key Management
- Key shares stored per-party (never combined)
- Address derived from group public key
- Same address used for bridge contract

## Constants

```c
#define MAX_PARTIES 128              // Maximum signers
#define MAX_PARTY_ID_LENGTH 64       // Party identifier length
#define MAX_SIGN_KEY_SIZE 800000     // Key share buffer
#define SIGNROUNDS 8                 // GG20 signing rounds
#define MAX_SIGNMESSAGE_SIZE 65536   // Message buffer
#define DEFAULT_BASEPORT 31500       // Network base port
#define MAX_TSS_THREADS 8            // Concurrent operations
```

## Thread Safety

### Global Semaphore
```c
static sem_t *global_sem = NULL;

static int32_t tss_init_sem(void) {
    if (global_sem) return 0;
    global_sem = sem_open("/valis_tss_sem", O_CREAT, 0660, MAX_TSS_THREADS);
    if (global_sem == SEM_FAILED) return -1;
    return 0;
}
```

### Per-Context Mutex
- Each GG20Context has `pthread_mutex_t queue_mutex`
- Protects message queue during concurrent access

## API Functions

### High-Level (valis_tss.c)
```c
// Query required buffer sizes
int32_t valis_tss_query_sizes(int32_t num_parties, 
                              int32_t *sign_results_total_size, 
                              int32_t *keygen_results_total_size);

// Initialize global semaphore
static int32_t tss_init_sem(void);
```

### Key Generation (keygen.c)
- Initialize DKG context
- Run multi-round protocol
- Store key shares

### Signing (sig.c)
- Load key shares
- Run 8-round signing protocol
- Produce (r, s, v) signature

## Dependencies

- **secp256k1**: Elliptic curve operations
- **nanomsg**: Network messaging
- **pthread**: Threading
- **libethc**: Ethereum utilities

## Related Files

- `bridge_withdraw.c`: Uses TSS for withdrawal signatures
- `validator.c`: Coordinates TSS operations
- `gen3_vote.c`: Consensus for TSS coordination

## Security Considerations

1. **Key Share Storage**: Shares must be encrypted at rest
2. **Network Security**: MPC messages should use TLS
3. **Threshold Selection**: t should be > n/2 for security
4. **Timeout Handling**: Stuck rounds need cleanup
5. **Replay Protection**: Each signing session needs unique ID
