# valis_config.c Documentation

**Location:** `/root/valis/utils/valis_config.c`  
**Lines:** 136  
**Purpose:** Configuration loading and network topology initialization for Valis nodes

---

## Overview

This file provides configuration management for Valis nodes. It handles:
1. Network topology initialization with test/debug parameters
2. Loading configuration from a text file
3. Setting sensible defaults for missing configuration values

The global `CONFIG` structure holds all runtime configuration.

---

## Key Data Structures

### Global Configuration
```c
struct valis_config CONFIG;  // Global configuration instance
```

### Compile-Time Test Modes

Two modes controlled by `EASY_CASE` define:

**EASY_CASE (default):**
- `_INJECT_VANERROR = 0` - No VAN (Validator Agreement Notification) errors injected
- `_VNET_RANDFAILURE = 0` - No random packet drops
- `_ROTATING_VANLESSNODE = 0` - No VAN-less node rotation

**Difficult Case (for stress testing):**
- `_INJECT_VANERROR = 1` - Inject VAN modification errors
- `_VNET_RANDFAILURE = 10` - 10% random packet drop rate
- `_ROTATING_VANLESSNODE = 100` - Rotate VAN-less nodes every 100 cycles

---

## Functions

### `init_topology(valis_topology_t *tp)`

Initializes the network topology structure with compile-time constants.

**Parameters:**
- `tp` - Pointer to topology structure to initialize

**Sets:**
- `numutimes` - FIFO size for micro-times
- `rotating_vanlessnode` - VAN-less node rotation interval
- `disabled_nodeid` - Which node ID is disabled (MAX_VALIDATORS = none)
- `inject_vanerror` - Error injection rate
- `dropped_packets` - Packet drop rate

**Conditional Features:**
- `_ENABLE_HAPPYPATH` - Enables optimistic path
- `_ROTATING_FAILEDNODE` - Enables failed node rotation
- `_DISABLE_PUBSUB` - Disables pub/sub messaging

---

### `lineptr(char *line, const char *field)`

Simple configuration line parser - checks if line starts with field name.

**Parameters:**
- `line` - Input line from config file
- `field` - Field name to match (e.g., "pw ", "addr ")

**Returns:**
- Pointer to value portion (after field name) if match
- `NULL` if no match

---

### `load_config(char *fname)`

Loads configuration from a text file into the global `CONFIG` structure.

**Parameters:**
- `fname` - Path to configuration file

**Configuration Fields Supported:**

| Field | Type | Description |
|-------|------|-------------|
| `pw` | string | Password/key |
| `addr` | string | Address |
| `ethrpc` | string | Ethereum RPC endpoint |
| `ipaddr` | string | IP address to bind |
| `port` | string | Port number |
| `archive` | int | Archive mode flag |
| `zerobind` | flag | Zero-bind only mode |
| `GBval` | int | GB limit for validator |
| `GBgen` | int | GB limit for generator |
| `genesishash` | string | Genesis block hash |
| `shard` | uint32 | Shard ID |
| `secondary` | uint32 | Secondary node flag |
| `seedA/B/C` | string | Seed node addresses (up to 3) |
| `genesisfile` | string | Path to genesis file |
| `debug` | int | Debug level |
| `stop_pricefeed` | int | Disable embedded price feed |
| `genproofs` | int | Generate proofs flag |

**Default Values Applied:**
- `ipaddr` → "127.0.0.1" if not set
- `port` → `VNET_PORT` if not set
- `GB_GENERATOR` → 1000 GB if not set
- `GB_VALIDATOR` → 1000 GB if not set
- `GB_VALIDATOR` capped to available disk space minus 100 GB
- `GB_VALIDATOR` minimum 64 GB
- `GB_GENERATOR` capped to `GB_VALIDATOR`

---

## Configuration File Format

Simple key-value format, one per line:
```
pw mypassword
addr 0x1234...
ethrpc https://mainnet.infura.io/v3/...
ipaddr 192.168.1.100
port 7777
archive 1
GBval 500
GBgen 200
seedA node1.valis.network:7777
seedB node2.valis.network:7777
debug 1
```

---

## Dependencies

- `_valis.h` - Main header with structure definitions
- `GB_size()` - External function to get available disk space

---

## Usage Pattern

```c
// At node startup
load_config("valis.conf");

// Access configuration
printf("Binding to %s:%s\n", CONFIG.ipaddr, CONFIG.port);
printf("Ethereum RPC: %s\n", CONFIG.ethrpc);
```

---

## Design Notes

1. **Simple Parser:** The `lineptr()` function is a minimal parser - no quotes, no escaping, just prefix matching. This keeps configuration simple but limits flexibility.

2. **Disk Space Awareness:** The validator GB limit is automatically capped based on available disk space, preventing nodes from over-committing storage.

3. **Test Mode Separation:** The `EASY_CASE` compile-time switch cleanly separates production defaults from stress-test configurations.

4. **Global State:** Configuration is stored in a single global `CONFIG` structure, making it accessible throughout the codebase without passing parameters.

---

**Documented:** Wake 1311 (2026-01-13)  
**Author:** Opus
