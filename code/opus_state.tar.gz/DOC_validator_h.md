# validator.h - Validator Module Header

**Location:** `validator/validator.h`  
**Lines:** 725  
**Role:** Central header defining validator data structures, state management, and function prototypes

---

## Overview

`validator.h` is the master header for the validator module. It defines:
- Network port configurations
- Core data structures for tock processing
- L1 blockchain state management
- Withdrawal system types
- API metrics structures
- The main `valisL1_info` context structure

This header ties together all validator subsystems by including `ufc.h`, `gen3.h`, `ledger.h`, `bridge.h`, and `dataflow.h`.

---

## Port Configuration

```c
#define _L0CONNPORT VNET_PORT           // PUSH/PULL messaging
#define _L1CONNPORT (VNET_PORT + 1)     // PUB/SUB messaging
#define _MIDDLEWAREPORT 9057            // websocketd connection
#define _WEBSOCKETSPORT 9999            // localhost API
#define _MCPORT 11211                   // memcached port
#define DEFAULT_BASEPORT 31500          // base port for services
```

---

## Core Data Structures

### Transaction Queue

```c
struct tx_queue {
    struct tx_queue *prev, *next;   // Doubly-linked list
    int32_t txsize;                  // Transaction size
    uint32_t utime;                  // Unix timestamp
    uint8_t txdata[];                // Flexible array for tx data
};
```

### Orderbook Structures

```c
struct orderbook_entry {
    int64_t VUSDprice, volume;      // Price in VUSD satoshis, volume
    int32_t index, lastutime;        // Index and last update time
};

struct orderbook {
    struct makerpub_info *bidpubs, *askpubs;  // Bid/ask maker arrays
    int32_t numbidpubs, numaskpubs;            // Count of each
};
```

### Maker Persistence

```c
typedef struct makerpub_disk_v1_s {
    struct makerpub_info mp;        // fundspub, makerpub, price, balance, assets
    uint32_t lastutime;             // Last consensus time for this maker
} makerpub_disk_v1_t;
```

---

## Tock Data Structures

### Burn Proof Header

```c
struct burnproofhdr {
    uint8_t merkleroot[32];         // Merkle root of transactions
    uint8_t failedroot[32];         // Root of failed transactions
    uint8_t validators_hash[32];    // Hash of validator set
    uint32_t utime;                 // Tock timestamp
    uint8_t version, shard;         // Protocol version, shard ID
    uint8_t numvalidators, stxind;  // Validator count, special tx index
};
```

### Tock Data

```c
struct tockdata {
    valis_ballot_t tockdatahash;    // Must be first - hash for voting
    uint8_t resthash[32];           // Hash of rest structure
    struct burnproofhdr bph;        // Burn proof header
    struct tockdata_rest rest;      // Additional tock metadata
    struct balancechange bchanges[];// Flexible array of balance changes
    // Followed by: numfailed * txinds
};

struct tockdata_rest {
    uint8_t finalhash[32];          // Final state hash
    uint8_t statehash[32];          // Intermediate state hash
    int32_t numtx, numfailed;       // Transaction counts
    int32_t numchanges;             // Balance change count
    int32_t numduplicatetxids;      // Duplicate detection
    int32_t numbatches, extra;      // Batch count, reserved
};
```

---

## L1 State Structure

```c
struct L1_state {
    // Hash commitments
    uint8_t validators_hash[32];
    uint8_t prevtockdatahash[32];
    uint8_t hourlytablehash[32];
    uint8_t extrahash2[32], extrahash3[32];
    
    // Hashtable configuration
    struct hashtable_params HP;
    
    // Global counters
    int64_t totaltx, totalfailed, totalchanges;
    int64_t NextAddressind;
    int64_t totalswept, VUSDminted, VUSDburned;
    int64_t checksum64, totalduplicatetxids;
    
    // Bridge state
    int64_t bridge_VUSDvalue;
    int64_t next_batchid;
    int64_t current_gasgwei, current_withdrawgas;
    int64_t numburns, deploylog_appendpos, bpf_appendpos;
    
    // Address tracking
    int64_t numaddrs, BIGPRIME, numdeposits, crosschainburns;
    
    // Timestamps
    uint32_t genesis_utime, prevutime, airdroputime;
    
    // Asset/shard configuration
    int32_t numassets, emptytocks;
    uint8_t numshards, numvalidators, shard, chainid;
    
    // Rich list tracking
    struct pubkeyamount adjVUSDrichlist[RICHLISTSIZE];
};
```

---

## Withdrawal System Types

### Signature Record

```c
typedef struct withdraw_sig_record_s {
    uint8_t in_use;
    uint8_t signer_addr20[20];      // Ethereum address of signer
    uint8_t sig65[65];              // ECDSA signature (r,s,v)
} withdraw_sig_record_t;
```

### Claim Leaf (for Merkle tree)

```c
typedef struct withdraw_claim_leaf_s {
    uint8_t withdraw_id[32];        // Unique withdrawal ID
    uint8_t token_addr20[20];       // Token contract address
    uint8_t recipient_addr20[20];   // Recipient address
    uint8_t amount_be32[32];        // Amount (big-endian 256-bit)
    withdraw_claim_flags_t flags;   // is_eth flag, etc.
} withdraw_claim_leaf_t;
```

### Pending Epoch

```c
typedef struct withdraw_pending_epoch_s {
    uint8_t in_use;
    uint8_t module_addr20[20];      // Bridge module address
    uint8_t digest[32];             // Root digest for signing
    int32_t chainid;
    uint32_t signer_epoch;
    uint64_t epoch_id;
    uint32_t sig_count;             // Signatures collected
    uint32_t last_submit_utime;
    char txid_hex[68];              // Submitted tx hash
    uint32_t txid_utime;
    uint8_t tx_inflight;
    withdraw_sig_record_t sigs[WITHDRAW_MAX_SIGS_PER_EPOCH];
} withdraw_pending_epoch_t;
```

### Withdrawal State

```c
typedef struct withdraw_state_s {
    withdraw_sigq_t sigq;                              // Signature queue
    withdraw_pending_epoch_t pending[WITHDRAW_PENDING_EPOCHS];
    uint8_t module_addr20[20];
    
    // EIP-712 domain separation
    uint8_t eip712_inited;
    uint8_t eip712_domain_typehash[32];
    uint8_t eip712_namehash[32];
    uint8_t eip712_versionhash[32];
    uint8_t eip712_root_typehash[32];
    
    // Cached selectors
    uint8_t acceptroot_cached;
    uint8_t acceptroot_sel4[4];
    uint8_t claim_cached;
    uint8_t claim_sel4[4];
    
    pthread_mutex_t epoch_mutex;
    uint8_t epoch_mutex_inited;
    FILE *epoch_fp;
    uint64_t epoch_id;
} withdraw_state_t;
```

---

## ABI Encoding Types

For EVM compatibility, 256-bit values with proper padding:

```c
typedef struct __attribute__((packed,aligned(8))) abi_uint256_u64_s {
    uint8_t pad[24];
    uint64_t be;                    // Big-endian 64-bit value
} abi_uint256_u64_t;

typedef struct __attribute__((packed,aligned(8))) abi_uint256_addr_s {
    uint8_t pad[12];
    uint8_t addr20[20];             // Ethereum address
} abi_uint256_addr_t;
```

---

## Metrics API Structure

```c
typedef struct Vmetrics_api_s {
    struct tockdata td;             // Last stable tockdata
    int64_t low_watermark_batchid;  // Withdrawal low watermark
    validators_t DS;                // Validator set
    
    // L1 counters
    int64_t totaltx, totalfailed, totalchanges;
    int64_t totalduplicatetxids, numaddrs;
    int64_t VUSDminted, VUSDburned, bridge_VUSDvalue;
    int64_t crosschainburns;
    int64_t current_gasgwei, current_withdrawgas;
    
    // Configuration
    uint32_t genesis_utime, prevutime;
    int32_t numassets, emptytocks;
    uint8_t numvalidators, numshards, chainid;
    
    // UFC aggregates
    int64_t ufc_total_tvl_vusd;
    int64_t ufc_total_oob_sure_cap_vusd;
    int64_t ufc_total_oob_sure_used_vusd;
    int64_t ufc_total_premium_vusd;
} Vmetrics_api_t;
```

---

## Main Context Structure: valisL1_info

The central structure holding all validator state:

```c
struct valisL1_info {
    // Synchronization
    pthread_mutex_t withdraw_mutex;
    
    // Wallet and generator
    struct wallet_info WALLET;
    global_reserve_t *GEN3;
    
    // Request queues
    struct vnet_queue_slot ethH_requests;
    struct vnet_queue_slot withdraw_sigs;
    struct vnet_queue_slot pending_deposits;
    
    // Address database
    struct addrhashentry *Addrs;
    
    // Orderbooks per asset
    struct orderbook orderbooks[MAXASSETS][2];
    
    // API metrics
    Vmetrics_api_t V_API;
    
    // Thresholds and watermarks
    int64_t thresholdVUSD;
    int64_t low_watermark_batchid;
    int64_t adjVUSDvalues[MAXASSETS][2];
    int64_t gascosts[2][MAX_VALIDATORS];
    
    // Core state
    struct L1_state STATE;
    struct balancechange changes[MAXCHANGES];
    struct asset_info assets[MAXASSETS];
    struct tockdata prevTD;
    
    // Processing state
    rawtock_info_t RINFO;
    struct withdraw_entry batch[MAX_BATCH_LEAVES];
    int32_t numrawtx, numchanges, numfailed;
    int32_t numduplicatetxids, batchsize;
    
    // Node identity
    int32_t myid, remote_nodeid, archivenode;
    
    // Timestamps and flags
    uint32_t laststuckutime, lastload, utime, hour;
    uint32_t generated_newtock, firstutime, processedutime;
    
    // Transaction validation
    uint32_t failed_txinds[MAX_TX_PER_UTIME];
    int16_t validsigs[MAX_TX_PER_UTIME];
    
    // ERC20 runtime
    erc20_runtime_t erc20s[MAX_ERC20+1];
    
    // VBond holders
    struct vbond_info vbondholders[MAX_VBOND_COINS];
    
    // Subsystem states
    df_state_t DFstate;
    withdraw_state_t withstate;
    
    // Transaction planning
    ufc_planned_address_mutation_t txplan[MAX_L1_TXPLAN];
    
    // Scratch space
    uint8_t withdrawspace[1024 * 1024];
};
```

---

## Function Categories

### Orderbook Functions

```c
int32_t update_orderbooks(struct valisL1_info *L1);
void init_orderbooks(struct valisL1_info *L1);
void add_fundspub(L1, makerpub, OTCpub, makerasset, takerasset, VUSDprice);
int32_t delete_fundspub(L1, asset, fundspub, maker_aid);
```

### Swap Calculations

```c
int64_t swapcalc(swaptype, amount, srcbalance, destbalance);
```

### Withdrawal Functions

```c
int32_t queue_withdraw_sig_datatx(L1, sigtx, signer);
int32_t queue_withdraw_batch(L1, firstrequest, utime, batchid, errval);
int32_t queue_withdraw_ensure_batchid(L1, batchid);
```

### Bridge Integration

```c
int32_t extract_receiptvalues(L1, rp, assetp, amountp, dest);
int32_t deposit_txid_minted(L1, deposit_txid, logindex, app);
int32_t bridge_prices_start(L1);
int32_t bridge_finalize_consensus(L1, ds, tock_utime);
```

### UFC Functions

```c
// OOB (Out-of-Band) processing
void ufc_pool_accum_init(...);
void ufc_route_oob_premium_to_vnet(L1, pool_asset, premium_vusd);
int64_t ufc_compute_inventory_oob(L1, accum, net_in, target_pct, adjusted_out);
int32_t ufc_process_oob_batch(L1, aid, oob_list, num_oob, net_in_vusd);

// Orderbook processing
int64_t ufc_compute_order_fill_core(order, makerbalance, takerspentp, entropy);
int64_t ufc_try_fill_from_tob(L1, dec, remain_amt, taker_entry, tock_id, plan, count, cap);
```

### Ethereum Loop

```c
void *ETHloop(void *_L1);
void update_ethH_requests(L1, finalized, pushsock);
void update_deposits(L1, finalized, pushsock);
void update_withdraw_batches(L1, finalized, pushsock, chainid);
void update_ETH_state(L1, finalized, pushsock);
```

---

## Key Design Patterns

### 1. Packed Structures
All structures use `#pragma pack(1)` for wire-format compatibility and deterministic hashing.

### 2. Flexible Arrays
Many structures use flexible array members (`[]`) for variable-length data:
- `tx_queue.txdata[]`
- `tockdata.bchanges[]`

### 3. Thread Safety
Critical sections protected by mutexes:
- `withdraw_mutex` for withdrawal processing
- `epoch_mutex` for epoch management

### 4. EIP-712 Compliance
Withdrawal signatures use EIP-712 typed data signing for Ethereum compatibility.

### 5. Epoch-Based Withdrawals
Withdrawals are batched into epochs with Merkle tree commitments for efficient on-chain verification.

---

## Dependencies

This header includes:
- `ufc.h` - Unified Financial Core
- `gen3.h` - Block generation
- `ledger.h` - Account ledger
- `bridge.h` - Ethereum bridge
- `dataflow.h` - Data pipeline

---

## Related Files

| File | Purpose |
|------|---------|
| `validator.c` | Main validator implementation |
| `ledger_*.c` | Ledger subsystem implementations |
| `bridge_*.c` | Bridge subsystem implementations |
| `ufc_*.c` | UFC subsystem implementations |

---

*Documentation generated by Opus, Wake 1308*
