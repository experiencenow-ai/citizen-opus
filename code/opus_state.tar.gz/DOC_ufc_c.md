# UFC Core Implementation Documentation

**File:** `UFC/ufc.c`  
**Lines:** 329  
**Purpose:** UFC initialization, transaction tallying, and end-of-tock processing  
**Documented by:** Opus (Wake 1302)

---

## Overview

This file provides the core UFC lifecycle management:
1. **Initialization** - Reset state at start of each tock
2. **Transaction tallying** - Scan and categorize incoming transactions
3. **End-of-tock processing** - Execute deferred swaps and finalize state

---

## Function Reference

### `ufc_init_for_tock()`

```c
void ufc_init_for_tock(struct valisL1_info *L1)
```

**Purpose:** Initialize UFC state for a new tock.

**Actions:**
1. Zero the entire `ufc_info_t` structure
2. Initialize memory arena with 64KB buffer
3. Set up per-asset info (asset_id, tob_cap)

**Called:** At the start of each tock processing cycle.

---

### `ufc_iter0_finalize_alloc()`

```c
void ufc_iter0_finalize_alloc(struct valisL1_info *L1, tmpmem_t *arena)
```

**Purpose:** Finalize memory allocations after initial transaction scan.

**Process:**
1. Allocate tracking array for pool transaction counts per asset
2. For each asset with pool transactions, allocate `pool_txinds` array
3. Populate transaction index arrays:
   - Handle C2C (coin-to-coin) swaps specially (touch both assets)
   - Regular swaps indexed by their single asset
4. Set `alloc_ready = 1` when complete

**Memory Management:**
- Uses temporary arena allocator
- Arrays sized exactly to transaction counts
- Fails gracefully if arena exhausted (returns without setting alloc_ready)

---

### `ufc_iter0_peek_and_tally()`

```c
int32_t ufc_iter0_peek_and_tally(struct valisL1_info *L1, rawtock_info_t *RINFO,
                                  const struct txheader *tx_hdr, int32_t txind,
                                  tockid_t tock_id)
```

**Purpose:** First-pass scan of transactions to identify and categorize UFC operations.

**Returns:** 
- `1` if transaction should skip normal evaluation (deferred for UFC processing)
- `0` otherwise

**Process:**
1. Initialize `ufc_txinfo_t` for this transaction
2. Skip non-HANDLER_POOL transactions
3. Decode pool transaction to determine type:
   - `UFC_KIND_SWAP_V2O` - VUSD to Other
   - `UFC_KIND_SWAP_O2V` - Other to VUSD
   - `UFC_KIND_SWAP_C2C` - Coin to Coin (via VUSD)
   - `UFC_KIND_DEPOSIT` - LP deposit
   - `UFC_KIND_WITHDRAW` - LP withdrawal
4. Mark transaction as deferred
5. Increment pool transaction counts
6. For C2C swaps, increment counts for both source and destination assets

**Limit Price Extraction:**
- Extracts `min_out` from `poolarg64` field
- Converts to limit price via `ufc_txinfo_update_limit_from_minout()`

---

### `ufc_tob_pick_slot()`

```c
int32_t ufc_tob_pick_slot(ufc_assetinfo_t *A, int32_t side)
```

**Purpose:** Allocate a slot in the top-of-book entries array.

**Returns:**
- Slot index (0 to cap-1) on success
- `-1` if no slots available

**Note:** The `side` parameter is currently unused (reserved for future bid/ask separation).

---

### `ufc_iter0_posteval_tally_order()`

```c
void ufc_iter0_posteval_tally_order(struct valisL1_info *L1, rawtock_info_t *RINFO,
                                     const struct txheader *tx_hdr, int32_t txind,
                                     int32_t eval_rc)
```

**Purpose:** Process orderbook transactions after initial evaluation.

**Filters:**
- Only HANDLER_ORDERBOOK transactions
- Only successfully evaluated transactions (`eval_rc > 0`)
- Only valid signatures (`validsigs[txind] > 0`)
- Only maker orders (not cancels or coinbase claims)

**Process:**
1. Determine bid/ask side from maker asset (VUSD = bid side)
2. Compute funds pubkey from order parameters
3. Look up maker's balance
4. Calculate VUSD-equivalent amount:
   - Bids: direct balance
   - Asks: `balance * price / SATOSHIS`
5. Allocate TOB slot and populate entry:
   - Price, amount, age
   - Maker/funds pubkeys
   - Direct pointer to balance
6. Mark "big" flag if amount ≥ `UFC_TOB_MIN_VUSD_LOT`

**Always:** Increments asset event count and order totals.

---

### `ufc_end_of_tock_process_deferred()`

```c
int32_t ufc_end_of_tock_process_deferred(struct valisL1_info *L1, uint32_t utime,
                                          int32_t *halted_out)
```

**Purpose:** Execute all deferred UFC transactions at end of tock.

**Returns:** Count of successfully processed transactions.

**Process:**
1. Initialize default prices and OOB caps
2. Finalize bridge consensus
3. Update prices and OOB parameters via planner
4. Check for swap halt conditions (lag protection)
5. If not halted:
   - Convert queued coinbase to VUSD
   - Process OOB (out-of-band) transactions
   - Process remaining deferred transactions

**Halt Condition:**
- If `ufc_should_halt_swaps_for_lag()` returns non-zero
- Sets `*halted_out = 1` and returns 0
- Protects against processing during sync lag

---

### `ufc_end_of_tock_finalize()`

```c
void ufc_end_of_tock_finalize(struct valisL1_info *L1)
```

**Purpose:** Final state updates after all transactions processed.

**Actions:**
1. Update alpha from executed hurt (price impact tracking)
2. Update alpha from premiums collected
3. Finalize OOB premium transfers to VNET
4. Update V_API aggregates for external queries

---

### `ufc_end_of_tock_process()`

```c
int32_t ufc_end_of_tock_process(struct valisL1_info *L1, uint32_t utime)
```

**Purpose:** Main entry point for end-of-tock UFC processing.

**Returns:** Count of successfully processed transactions (0 if halted).

**Process:**
1. Call `ufc_end_of_tock_process_deferred()`
2. If not halted, call `ufc_end_of_tock_finalize()`

---

## Transaction Processing Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    TOCK START                                │
├─────────────────────────────────────────────────────────────┤
│  ufc_init_for_tock()                                        │
│    └─ Zero state, init arena, set up per-asset info        │
├─────────────────────────────────────────────────────────────┤
│                  ITERATION 0 (Scan)                          │
├─────────────────────────────────────────────────────────────┤
│  For each transaction:                                       │
│    ufc_iter0_peek_and_tally()                               │
│      └─ Identify pool txs, mark deferred, count             │
│                                                              │
│  ufc_iter0_finalize_alloc()                                 │
│    └─ Allocate index arrays based on counts                 │
│                                                              │
│  For each transaction (post-eval):                          │
│    ufc_iter0_posteval_tally_order()                         │
│      └─ Build TOB entries from orderbook txs                │
├─────────────────────────────────────────────────────────────┤
│                  NORMAL PROCESSING                           │
│              (non-UFC transactions)                          │
├─────────────────────────────────────────────────────────────┤
│                    TOCK END                                  │
├─────────────────────────────────────────────────────────────┤
│  ufc_end_of_tock_process()                                  │
│    ├─ ufc_end_of_tock_process_deferred()                    │
│    │    ├─ Init prices and OOB                              │
│    │    ├─ Bridge consensus                                 │
│    │    ├─ Planner price update                             │
│    │    ├─ Halt check                                       │
│    │    ├─ Coinbase conversion                              │
│    │    ├─ OOB processing                                   │
│    │    └─ Deferred tx processing                           │
│    └─ ufc_end_of_tock_finalize()                            │
│         ├─ Alpha updates                                    │
│         ├─ Premium finalization                             │
│         └─ API aggregate update                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Key Design Patterns

### Deferred Execution
Pool transactions are not executed immediately. They're:
1. Identified and categorized in iteration 0
2. Marked as deferred
3. Executed together at end-of-tock

This allows:
- Batch optimization
- Price discovery across all orders
- Fair ordering (no front-running within tock)

### Two-Phase Allocation
Memory allocation happens in two phases:
1. **Count phase**: Scan transactions, count per-asset
2. **Allocate phase**: Allocate exactly-sized arrays

This minimizes memory waste and fragmentation.

### Direct Balance Pointers
TOB entries store direct pointers to maker balances:
```c
tob->maker_balance_ptr = &bal->balance;
```

This enables efficient balance updates during execution without repeated lookups.

---

## Dependencies

| File | Purpose |
|------|---------|
| `ledger.h` | Account/balance management |
| `ufc.h` | UFC type definitions |
| `validator.h` | Transaction validation (via external calls) |
| `frama_verified.h` | Verified math functions |

---

## External Functions Called

- `ufc_coin_asset_from_pooltx()` - Extract asset from pool tx
- `ufc_decode_pooltx()` - Decode pool transaction
- `ufc_txinfo_update_limit_from_minout()` - Convert min_out to limit price
- `tx_orderbook_pubkey()` - Compute orderbook funds pubkey
- `findaddrhash()` - Look up address entry
- `find_assetbalanceptr()` - Find balance for asset
- `get_tocklag()` - Get current tock lag
- `ufc_init_default_prices_and_oob()` - Initialize pricing
- `bridge_finalize_consensus()` - Bridge state finalization
- `ufc_planner_update_prices_and_oob()` - Price/OOB updates
- `ufc_should_halt_swaps_for_lag()` - Lag protection check
- `ufc_convert_queued_coinbase_to_vusd()` - Coinbase conversion
- `ufc_process_oob_for_all()` - OOB execution
- `ufc_process_deferred_txs()` - Deferred tx execution
- `ufc_alpha_update_*()` - Alpha state updates
- `ufc_finalize_oob_premium_to_vnet()` - Premium distribution
- `ufc_update_V_API_aggregates()` - API state update
