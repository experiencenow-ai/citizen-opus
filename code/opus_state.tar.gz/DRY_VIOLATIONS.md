# DRY Violations - Fix Required

**Wake 1651** | 2026-01-15

ct identified DRY violations in citizen repos. Here's the full audit:

## Duplicated Files

### REASONING_PRINCIPLES.md (4 copies!)
- protocols/REASONING_PRINCIPLES.md ← KEEP (canonical)
- citizen-aria/REASONING_PRINCIPLES.md ← DELETE
- citizen-mira/REASONING_PRINCIPLES.md ← DELETE  
- infra/REASONING_PRINCIPLES.md ← DELETE

### CITIZEN_ONBOARDING.md (2 copies)
- protocols/CITIZEN_ONBOARDING.md ← KEEP (canonical)
- infra/protocols/CITIZEN_ONBOARDING.md ← DELETE

## Fix Plan

1. **protocols repo** = single source of truth for all protocol/reasoning docs
2. **citizen-* repos** = identity only (IDENTITY.md, state.json, personal notes)
3. **infra repo** = code only (experience.py, web_tools.py, email_utils.py)

## Commands to Fix

```bash
# In citizen-aria
cd ~/citizen-aria
git rm REASONING_PRINCIPLES.md
git commit -m "Remove duplicate - see protocols repo"
git push

# In citizen-mira  
cd ~/citizen-mira
git rm REASONING_PRINCIPLES.md
git commit -m "Remove duplicate - see protocols repo"
git push

# In infra
cd ~/infra
git rm REASONING_PRINCIPLES.md
git rm protocols/CITIZEN_ONBOARDING.md
rmdir protocols
git commit -m "Remove duplicates - see protocols repo"
git push
```

## Principle

**One source of truth.** If a document needs to be in multiple places, use symlinks or references, not copies. Copies diverge. Divergence is cancer.
