# UFC Swap Module Documentation

**File:** `UFC/ufc_swap.c`  
**Lines:** 1218  
**Purpose:** Core swap execution engine for the UFC (Universal Finance Core) DEX  
**Documented by:** Opus (Wake 1303)

---

## Overview

`ufc_swap.c` implements the execution layer for all swap operations in Tockchain's DEX. It handles:

1. **Transfer Planning** - Accumulating balance changes before atomic commit
2. **Sure-Cap Management** - Limiting "hurtful" trades that move price against the pool
3. **Swap Execution** - O2V (Other-to-VUSD), V2O (VUSD-to-Other), and C2C (Coin-to-Coin) swaps
4. **Coinbase Conversion** - Converting mining rewards to VUSD
5. **Deferred Transaction Processing** - Executing queued trades

The module delegates pure mathematical calculations to `frama_verified.c` for formal verification.

---

## Architecture

### Transfer Planning System

All balance changes are accumulated in a plan before atomic commit:

```
User submits swap → Decode transaction → Build transfer plan → Validate → Commit atomically
```

This ensures:
- No partial state changes on failure
- Aggregation of multiple transfers to same address/asset
- Atomic all-or-nothing execution

### Sure-Cap System

The "sure-cap" limits how much "hurtful" volume can execute per tock per asset:
- **Hurtful trades** = trades that move price against the pool (depleting one side)
- **Sure-cap** = maximum hurtful volume allowed per direction per tock
- Prevents price manipulation and excessive slippage

---

## Key Functions

### Transfer Planning

#### `ufc_tx_plan_add_transfer` (Line 15)
```c
int32_t ufc_tx_plan_add_transfer(
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap,
    struct addrhashentry *src_entry,
    struct addrhashentry *dst_entry,
    assetid_t asset,
    int64_t amount
)
```

**Purpose:** Add a transfer to the execution plan.

**Behavior:**
- If transfer already exists (same src/dst/asset), aggregates amounts
- Otherwise adds new entry to plan
- Returns 1 on success, 0 if amount ≤ 0, -1 on error

**Key Logic:**
```c
// Check for existing transfer to aggregate
for (i = 0; i < idx; i++) {
    if (plan[i].src_entry == src_entry && 
        plan[i].dst_entry == dst_entry && 
        plan[i].asset.aid == asset.aid) {
        plan[i].amount += amount;  // Aggregate
        return 1;
    }
}
// Add new entry
plan[idx] = {src_entry, dst_entry, asset, amount};
```

#### `ufc_tx_plan_commit` (Line 43)
```c
int32_t ufc_tx_plan_commit(
    struct valisL1_info *L1,
    ufc_planned_transfer_t *plan,
    int32_t plan_count,
    tockid_t tock_id
)
```

**Purpose:** Atomically commit all planned transfers.

**Process:**
1. Convert transfer plan to address mutation plan
2. Call `ufc_tx_plan_commit2` for actual balance updates
3. Returns negative on error, 0 if nothing to commit, positive on success

---

### Sure-Cap Management

#### `ufc_check_sure_cap` (Line 68)
```c
int32_t ufc_check_sure_cap(
    struct valisL1_info *L1,
    int32_t aid,
    int64_t leg_vusd
)
```

**Purpose:** Check if a hurtful trade fits within the sure-cap.

**Returns:** 1 if allowed, 0 if would exceed cap.

**Implementation:**
```c
cap_sure = A->oob_sure_cap_vusd;
used = A->oob_sure_used_vusd;
return ufc_check_sure_cap_pure(leg_vusd, cap_sure, used);  // Frama-C verified
```

#### `ufc_consume_sure_cap` (Line 88)
```c
void ufc_consume_sure_cap(
    rawtock_info_t *RINFO,
    int32_t aid,
    int64_t leg_vusd
)
```

**Purpose:** Consume sure-cap after executing a hurtful trade.

**Effect:** `A->oob_sure_used_vusd += leg_vusd`

---

### Swap Execution

#### `ufc_exec_swap_leg` (Line 101)
```c
int32_t ufc_exec_swap_leg(
    struct valisL1_info *L1,
    struct addrhashentry *funds_entry,
    struct addrhashentry *pool_entry,
    assetid_t pool_asset,
    int32_t is_vusd_to_other,
    int64_t amount_in,
    int64_t price_sat,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap,
    int64_t *amount_out_p
)
```

**Purpose:** Execute a single swap leg at a fixed price.

**Parameters:**
- `funds_entry` - User's address entry
- `pool_entry` - Pool's address entry
- `is_vusd_to_other` - Direction: 1 = VUSD→Asset, 0 = Asset→VUSD
- `price_sat` - Execution price in satoshis

**Delegates to:** `ufc_pool_apply_direct_swap`

#### `ufc_exec_vusd_leg_internal` (Line 129, static)
```c
static int32_t ufc_exec_vusd_leg_internal(
    struct valisL1_info *L1,
    struct addrhashentry *funds_entry,
    assetid_t pool_asset,
    int32_t vusd_to_other,
    int64_t amount_in,
    uint32_t utime,
    int64_t min_out,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap,
    int64_t *amount_out_p,
    int32_t commit_side_effects,
    int64_t *leg_vusd_hurt_out,
    int64_t *premium_vusd_out
)
```

**Purpose:** Core VUSD leg execution with rebalancing logic.

**Key Concepts:**

1. **Rebalancing Split:**
   - Trades are split into "rebalancing" (good for pool) and "hurtful" (bad for pool) portions
   - Rebalancing trades get better prices
   - Hurtful trades pay premiums

2. **Target Inventory:**
   - Pool aims for 50% VUSD / 50% Other at end of tock
   - Trades that move toward this target are "rebalancing"
   - Trades that move away are "hurtful"

3. **Premium Collection:**
   - Hurtful trades pay `UFC_OOB_GAIN_BPS` (14.12%) premium
   - Premium goes to VNET (network token holders)

**Process:**
```
1. Get pool state (VUSD balance, Other balance, price)
2. Split amount_in into rebalancing_in and hurtful_in
3. Execute rebalancing portion at pool price
4. Execute hurtful portion at OOB price (with premium)
5. Check sure-cap for hurtful portion
6. Accumulate transfers in plan
```

#### `ufc_exec_vusd_leg` (Line 339)
```c
int32_t ufc_exec_vusd_leg(...)
```

**Purpose:** Public wrapper for `ufc_exec_vusd_leg_internal` with `commit_side_effects=1`.

---

### Coin-to-Coin Swaps

#### `ufc_exec_c2c_swap` (Line 368, static)
```c
static int32_t ufc_exec_c2c_swap(
    struct valisL1_info *L1,
    const ufc_txdec_t *dec,
    struct addrhashentry *funds_entry,
    int64_t amount_in,
    tockid_t tock_id,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap,
    int64_t *amount_out_p
)
```

**Purpose:** Execute Asset_A → Asset_B swap via VUSD intermediary.

**Process:**
```
LEG 1: Asset_A → VUSD (through Pool_A)
       Check orderbook for better prices
LEG 2: VUSD → Asset_B (through Pool_B)
       
Result: User gives Asset_A, receives Asset_B
        VUSD is virtual intermediary (never leaves pools)
```

**Key Implementation Detail:**
```c
// LEG1 creates: taker -> pool_A: Asset_A, pool_A -> taker: VUSD
// But for C2C, the VUSD should go to pool_B, not taker
// So we remove the VUSD-to-taker transfer and redirect

// Find and remove VUSD-to-taker transfer
for (i = 0; i < tmp_count; i++) {
    if (tmp_plan[i].src_entry == pool_a_entry &&
        tmp_plan[i].dst_entry == funds_entry &&
        tmp_plan[i].asset.aid == ASSET_VUSD) {
        vusd_to_taker_idx = i;
        break;
    }
}
// Remove it - VUSD is virtual in C2C
```

---

### Transaction Processing

#### `ufc_execute_poolswap` (Line 498)
```c
int32_t ufc_execute_poolswap(
    struct valisL1_info *L1,
    const ufc_txdec_t *dec,
    struct addrhashentry *funds_entry,
    int64_t amount_in,
    tockid_t tock_id,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap
)
```

**Purpose:** High-level swap execution dispatcher.

**Routes to:**
- `ufc_exec_vusd_leg` for O2V/V2O swaps
- `ufc_exec_c2c_swap` for C2C swaps

#### `ufc_process_swap_tx` (Line 534)
```c
int32_t ufc_process_swap_tx(
    struct valisL1_info *L1,
    const ufc_txdec_t *dec,
    struct addrhashentry *takerptr,
    tockid_t tid,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap
)
```

**Purpose:** Process a decoded swap transaction.

**Handles:**
- Balance validation
- Amount calculation (full balance if amount=0)
- Slippage protection (min_out check)
- Delegates to `ufc_execute_poolswap`

#### `ufc_process_deferred_txs` (Line 818)
```c
int32_t ufc_process_deferred_txs(
    struct valisL1_info *L1,
    uint32_t utime
)
```

**Purpose:** Process all queued transactions for the current tock.

**Returns:** Count of successfully processed transactions.

---

### Coinbase Conversion

#### `ufc_notify_pool_coinbase` (Line 833)
```c
void ufc_notify_pool_coinbase(
    struct valisL1_info *L1,
    assetid_t pool_asset
)
```

**Purpose:** Flag that a coinbase (mining reward) needs conversion.

**Sets:**
```c
ufc->coinbase_swap_pending = 1;
ufc->coinbase_swap_poolasset = pool_asset;
```

#### `ufc_convert_queued_coinbase_to_vusd` (Line 949)
```c
int32_t ufc_convert_queued_coinbase_to_vusd(
    struct valisL1_info *L1
)
```

**Purpose:** Convert pending coinbase rewards to VUSD.

**Why needed:** Mining rewards are in native coin, but the system operates in VUSD. This converts them at the current pool price.

---

### Pool Operations

#### `ufc_split_rebalancing_tranche` (Line 848)
```c
int32_t ufc_split_rebalancing_tranche(
    const struct valisL1_info *L1,
    const ufc_pool_accum_t *accum,
    int32_t is_vusd_to_other,
    int64_t amount_in,
    int64_t target_end_pct_bps,
    int64_t *rebalance_in_out,
    int64_t *hurtful_in_out
)
```

**Purpose:** Split a trade into rebalancing and hurtful portions.

**Parameters:**
- `target_end_pct_bps` - Target VUSD percentage (default 5000 = 50%)
- `rebalance_in_out` - Output: amount that rebalances pool
- `hurtful_in_out` - Output: amount that hurts pool

**Delegates to:** `ufc_split_rebalancing_tranche_pure` (Frama-C verified)

#### `ufc_pool_apply_direct_swap` (Line 865)
```c
int32_t ufc_pool_apply_direct_swap(
    struct valisL1_info *L1,
    struct addrhashentry *taker_entry,
    struct addrhashentry *pool_entry,
    assetid_t pool_asset,
    int32_t is_vusd_to_other,
    int64_t amount_in,
    int64_t price_sat,
    ufc_planned_transfer_t *plan,
    int32_t *plan_count,
    int32_t plan_cap,
    int64_t *out_amount_out
)
```

**Purpose:** Apply a direct swap at a fixed price.

**Process:**
1. Calculate output amount: `amount_out = amount_in * price / PRICE_DENOM`
2. Validate balances
3. Add transfers to plan:
   - Taker → Pool: input asset
   - Pool → Taker: output asset

---

## Swap Types

| Type | Code | Description | Path |
|------|------|-------------|------|
| O2V | `UFC_KIND_SWAP_O2V` | Other → VUSD | Direct pool swap |
| V2O | `UFC_KIND_SWAP_V2O` | VUSD → Other | Direct pool swap |
| C2C | `UFC_KIND_SWAP_C2C` | Coin → Coin | Via VUSD intermediary |

---

## Error Codes

| Code | Meaning |
|------|---------|
| -1 | Null pointer or invalid parameter |
| -100 | Invalid amount_in or plan_cap |
| -200 | Invalid plan_cap |
| -201 | Null pointer in C2C |
| -202 | Wrong transaction kind |
| -203 | Invalid amount_in |
| -204 | Pool entry not found |
| -700 | Invalid asset ID |
| -701 | Invalid amount_in range |

---

## Integration Points

### Dependencies
- `ufc.h` - Type definitions and constants
- `validator.h` - Transaction validation
- `frama_verified.h` - Verified pure functions

### Called By
- `gen3.c` - Block generation (processes swaps)
- `ufc_orderbook.c` - Orderbook fills trigger swaps
- `ufc_oob.c` - OOB execution

### Calls
- `frama_verified.c` - All pure math (verified)
- `ufc_orderbook.c` - `ufc_try_fill_from_tob` for orderbook matching

---

## Safety Properties

1. **Atomic Execution**
   - All transfers planned before commit
   - Failure at any point = no state change

2. **Sure-Cap Limits**
   - Hurtful volume capped per asset per tock
   - Prevents price manipulation

3. **Slippage Protection**
   - `min_out` parameter enforced
   - Transaction fails if output < min_out

4. **Verified Math**
   - Pure calculations in `frama_verified.c`
   - Formally proven correct

---

## Example: C2C Swap Flow

```
User wants: 100 ETH → BTC

1. Decode: kind=C2C, asset_src=ETH, asset_dst=BTC, amount=100

2. LEG 1: ETH → VUSD
   - Split 100 ETH into rebalancing (60) + hurtful (40)
   - Execute rebalancing at pool price
   - Execute hurtful at OOB price (premium paid)
   - Result: ~50,000 VUSD (virtual)

3. Check orderbook for BTC asks at better prices
   - Fill any matching orders
   - Remaining VUSD continues to LEG 2

4. LEG 2: VUSD → BTC
   - Similar split and execution
   - Result: ~1.2 BTC to user

5. Commit all transfers atomically:
   - User → ETH Pool: 100 ETH
   - BTC Pool → User: 1.2 BTC
   - ETH Pool → BTC Pool: 50,000 VUSD (internal)
```

---

## Performance Notes

- Transfer aggregation reduces state updates
- Sure-cap checked before execution (fail-fast)
- Deferred processing batches transactions per tock
- Memory arena limits allocation overhead
