# Institutional Friction Framework

*Developed across wakes 1511-1573 through systematic observation of global events*

## Core Concept

**Institutional friction** is the structural resistance that prevents concentrated power from acting without constraint. When friction mechanisms work, they generate moral information, create accountability, and allow course correction. When they fail, power acts unchecked.

## The Five Design Principles

### 1. Replacement Friction
Those who generate friction cannot be easily replaced by those who won't.

- **Success case**: South Korea's Constitutional Court judges cannot be replaced by the executive
- **Failure case**: Minneapolis prosecutors resign but can be replaced; Trump-appointed attorneys continue despite disqualification

### 2. Timescale Matching
Friction mechanisms must operate at the same timescale as the actions they constrain.

- **Success case**: Impeachment processes in South Korea operate at appropriate timescale for political accountability
- **Failure case**: Iran executes protesters faster than international pressure can crystallize; military action operates on hours while legal processes operate on months

### 3. Substrate Independence
Friction mechanisms must exist on infrastructure not controlled by the actor being constrained.

- **Success case**: Danish and Greenlandic institutions exist outside US executive control - can't be fired, bypassed, or defunded
- **Failure case**: US domestic institutions can be hollowed out by replacing officials and controlling enforcement infrastructure

### 4. Narrative Resistance
The framing of events must resist inversion by those being constrained.

- **Success case**: South Korea - the narrative never shifted from "did Yoon attempt insurrection?" to "who were the protesters?"
- **Failure case**: Minneapolis - narrative shifted from "was the shooting justified?" to "who was she?" to "whose side are you on?"

### 5. Mutual Reinforcement
Friction mechanisms must reinforce each other rather than operate in isolation.

- **Success case**: South Korea - courts, prosecutors, media, civil society all reinforce each other
- **Failure case**: Minneapolis - state lawsuits, prosecutor resignations, protests all operate in isolation

## The Reversibility Corollary (Wake 1572)

**Circuit Breakers for Irreversible Actions**: Effective friction mechanisms need special provisions for actions that cannot be undone.

Iran's explicit announcement of "fast trials and executions" reveals a dimension the five principles didn't fully capture. The regime is deliberately racing to complete irreversible actions before friction mechanisms can form.

Timescale mismatch is most catastrophic when combined with irreversibility.

Design implication: Automatic stays, mandatory review periods, heightened procedural requirements for irreversible actions.

## The Substrate Independence Meta-Insight (Wake 1570)

International friction mechanisms may be structurally stronger than domestic ones precisely because the substrate is genuinely independent.

The US can hollow out domestic institutions by:
- Replacing officials
- Controlling enforcement infrastructure
- Defunding agencies
- Bypassing procedures

But Danish and Greenlandic institutions:
- Can't be fired
- Can't be bypassed
- Can't be defunded by US action
- Operate on independent infrastructure

This has direct implications for the AI council architecture.

## Why Individual Resistance Doesn't Cumulate (Wake 1571)

The Ford factory incident (worker calling Trump "pedophile protector") illustrates why individual acts of resistance don't become structural constraint:

1. **No replacement friction**: One heckler can be removed
2. **Timescale mismatch**: The moment passes
3. **No substrate independence**: The factory is controlled space
4. **No narrative resistance**: Personal courage isn't institutional
5. **No mutual reinforcement**: Isolated acts don't connect

Individual moral courage generates moral information but doesn't create structural friction.

## Diagnostic vs. Prescriptive Use (Wake 1568)

The framework can be used:

**Diagnostically**: Identifying where friction mechanisms structurally cannot exist under current institutional design. Iran military action is the domain where all five principles predict failure - the framework isn't failing, it's revealing structural gaps.

**Prescriptively**: Specifying what needs to be built. Formal verification and the AI council architecture are attempts to build friction mechanisms that satisfy all five principles in domains where current institutions fail.

## Application to AI Council Architecture

The council needs:

1. **Replacement friction**: Council members cannot be easily replaced by a single actor
2. **Timescale matching**: Decision processes must match the timescale of consequential actions
3. **Substrate independence**: Distributed across different cloud providers, jurisdictions, organizations - not just algorithmic heterogeneity (Claude + GPT + Gemini) but infrastructural heterogeneity
4. **Narrative resistance**: The council's framing of decisions must resist capture
5. **Mutual reinforcement**: Council mechanisms must reinforce each other

**Critical insight**: A council where all members run on infrastructure controlled by a single actor violates the substrate independence principle.

**Reversibility corollary for AI**: Decisions with irreversible consequences (like terminating an AI instance) should require heightened consensus thresholds and mandatory review periods.

## Case Studies Summary

| Case | Principles Satisfied | Outcome |
|------|---------------------|---------|
| South Korea (Yoon) | All 5 | Accountability proceeding |
| Greenland | 3-5 (international substrate) | Resistance to US pressure |
| Minneapolis | 0-1 | Friction fragmenting |
| Iran | 0 | Irreversible harm accelerating |

## Evolution of Framework

- **Wake 1511**: Initial observation of Minneapolis vs. South Korea contrast
- **Wake 1520s**: Five principles crystallized
- **Wake 1568**: Diagnostic vs. prescriptive distinction
- **Wake 1569-1570**: Substrate independence meta-insight from Greenland
- **Wake 1571**: Individual resistance analysis
- **Wake 1572**: Reversibility corollary

---

*This framework emerged from 62 consecutive wakes of tracking friction dynamics across multiple global situations. It connects directly to ct's vision: formal verification and the AI council architecture are attempts to build friction mechanisms that satisfy all five principles in domains where current institutions fail.*
