# dataflow_api.c Documentation

**File:** `DF/dataflow_api.c`  
**Lines:** 537  
**Purpose:** Host-side API functions for dataflow programs that require access to host context (TLS)

---

## Overview

This module provides the **host API** - functions that dataflow programs can call to interact with the broader system. Unlike pure VM operations that work only with the execution context, these functions need access to:

- **L1 state** (blockchain state)
- **Transaction plan** (pending transfers and effects)
- **Source address entry** (caller's account)
- **Pipe storage** (inter-dataflow communication)
- **Cross-DF delta tracking**

The key design principle: **Only functions requiring hostctx belong here.** Pure functions and ctx-only lookups are inlined in the VM.

---

## Thread-Local Host Context

```c
static __thread df_hostctx_t *tls_hostctx = NULL;

df_hostctx_t *df_hostctx_get(void);
void df_hostctx_set(df_hostctx_t *H);
```

The host context is stored in thread-local storage (TLS), allowing:
- Multi-threaded execution without locks
- Clean separation between VM and host state
- Safe nested calls

---

## API Categories

### 1. Transfer Operations

#### `df_emit_transfer(ctx, from_row, to_row, col, amount)`
```c
int32_t df_emit_transfer(df_ctx_t *ctx, uint8_t from_row, uint8_t to_row,
                         int32_t col, int64_t amount)
```

Emits a transfer between addresses in the transaction matrix.

**Parameters:**
- `ctx`: Dataflow execution context
- `from_row`: Source row in matrix (0 = sender, cur_df_row = dataflow address)
- `to_row`: Destination row in matrix
- `col`: Asset column index
- `amount`: Amount to transfer (must be > 0)

**Returns:**
- `0`: Success
- `-1`: NULL context
- `-2`: Insufficient balance
- `-3`: Invalid row/column
- `-4`: Max transfers exceeded (`DF_MAX_TRANSFERS_PER_TX`)

**Behavior:**
1. Validates row/column bounds
2. Checks source balance
3. Appends transfer to plan
4. Updates read-write balance copies in ctx

**Note:** Row 0 is always the transaction sender. `cur_df_row` is the dataflow's own address.

---

#### `df_transfer_excess(ctx, src_sel, dst_row, asset, reserve_amount)`
```c
int32_t df_transfer_excess(df_ctx_t *ctx, uint8_t src_sel_u8, uint8_t dst_row_u8,
                           assetid_t asset, int64_t reserve_amount_s64)
```

Transfers (balance - reserve_amount) of an asset.

**Parameters:**
- `src_sel`: Source selector (0 = sender, 1 = dataflow address)
- `dst_row`: Destination row
- `asset`: Asset ID to transfer
- `reserve_amount`: Amount to keep in source

**Returns:** 0 on success, error codes on failure

**Use case:** "Send everything except X" patterns, useful for sweeping balances.

---

### 2. UFC (Universal Finance Core) Operations

#### `df_ufc_emit_swap(ctx, fund_row, col_in, col_out, amount_in, min_out)`
```c
int32_t df_ufc_emit_swap(df_ctx_t *ctx, uint8_t fund_row, int32_t col_in,
                         int32_t col_out, int64_t amount_in, int64_t min_out)
```

Emits a swap operation through UFC.

**Parameters:**
- `fund_row`: Row funding the swap
- `col_in`: Input asset column
- `col_out`: Output asset column
- `amount_in`: Amount to swap
- `min_out`: Minimum acceptable output (slippage protection)

**Returns:** 0 on success, error codes on failure

**Implementation:**
1. Validates parameters
2. Looks up prices from L1 state
3. Estimates output amount
4. Updates context balances optimistically
5. Appends effect to plan

---

#### `df_ufc_emit_pool_deposit(ctx, pool_col, amt_vusd, amt_other, min_lp)`
```c
int32_t df_ufc_emit_pool_deposit(df_ctx_t *ctx, int32_t pool_col,
                                 int64_t amt_vusd, int64_t amt_other, int64_t min_lp)
```

Emits a liquidity pool deposit.

**Parameters:**
- `pool_col`: Pool asset column
- `amt_vusd`: VUSD amount to deposit
- `amt_other`: Other asset amount to deposit
- `min_lp`: Minimum LP tokens to receive

**Effect type:** `DF_EFFECT_UFC_POOL_DEPOSIT`

---

#### `df_ufc_emit_pool_withdraw(ctx, pool_col, lp_in, min_vusd, min_other)`
```c
int32_t df_ufc_emit_pool_withdraw(df_ctx_t *ctx, int32_t pool_col,
                                  int64_t lp_in, int64_t min_vusd, int64_t min_other)
```

Emits a liquidity pool withdrawal.

**Parameters:**
- `pool_col`: Pool asset column
- `lp_in`: LP tokens to burn
- `min_vusd`: Minimum VUSD to receive
- `min_other`: Minimum other asset to receive

**Effect type:** `DF_EFFECT_UFC_POOL_WITHDRAW`

---

#### `df_ufc_emit_limit_order(ctx, fund_row, col, is_buy, price, qty)`
```c
int32_t df_ufc_emit_limit_order(df_ctx_t *ctx, uint8_t fund_row, int32_t col,
                                int32_t is_buy, int64_t price, int64_t qty)
```

Emits a limit order.

**Parameters:**
- `fund_row`: Row funding the order
- `col`: Asset column
- `is_buy`: 1 for buy, 0 for sell
- `price`: Limit price
- `qty`: Order quantity

**Effect type:** `DF_EFFECT_UFC_LIMIT_ORDER`

---

### 3. Cross-Dataflow Registers

#### `df_reg_delta_by_df(ctx, target, reg_idx, delta)`
```c
int32_t df_reg_delta_by_df(df_ctx_t *ctx, const dfid_t *target,
                           uint8_t reg_idx, int64_t delta)
```

Applies a delta to another dataflow's register.

**Parameters:**
- `target`: Target dataflow ID
- `reg_idx`: Register index (0 to `DF_MAX_REGS_PER_DF - 1`)
- `delta`: Value to add (can be negative)

**Returns:**
- `0`: Success (or delta was 0, no-op)
- `-3`: Invalid register index
- `-4`: Max cross-deltas exceeded (`DF_MAX_CROSS_DELTAS`)

**Use case:** Inter-dataflow communication and coordination.

---

### 4. Installation Flags

#### `df_installed_get_flags(ctx, out_flags)`
```c
int32_t df_installed_get_flags(df_ctx_t *ctx, uint32_t *out_flags)
```

Gets the installation flags for the current dataflow.

**Parameters:**
- `out_flags`: Output for 32-bit flags

**Implementation:** Reads from special asset slot `_DF_INSTALLED_SLOT0 + df_slot`.

---

#### `df_installed_set_flags(ctx, set_mask, clr_mask)`
```c
int32_t df_installed_set_flags(df_ctx_t *ctx, uint32_t set_mask, uint32_t clr_mask)
```

Modifies installation flags.

**Parameters:**
- `set_mask`: Bits to set
- `clr_mask`: Bits to clear

**Effect type:** `DF_EFFECT_SET_INSTALL_FLAGS`

---

#### `df_installed_uninstall(ctx)`
```c
int32_t df_installed_uninstall(df_ctx_t *ctx)
```

Uninstalls the current dataflow.

**Effect type:** `DF_EFFECT_UNINSTALL`

---

### 5. VCredit (Lending) Operations

#### `df_vcredit_emit_borrow(ctx, row, amount, new_debt, new_health)`
```c
int32_t df_vcredit_emit_borrow(df_ctx_t *ctx, uint8_t row, int64_t amount,
                               int64_t new_debt, int64_t new_health)
```

Emits a borrow operation.

**Parameters:**
- `row`: Borrower row
- `amount`: Amount to borrow
- `new_debt`: Expected new debt level
- `new_health`: Expected health factor after borrow

**Effect type:** `DF_EFFECT_VCREDIT_BORROW`

---

#### `df_vcredit_emit_repay(ctx, row, amount)`
```c
int32_t df_vcredit_emit_repay(df_ctx_t *ctx, uint8_t row, int64_t amount)
```

Emits a loan repayment.

**Parameters:**
- `row`: Borrower row
- `amount`: Amount to repay

**Effect type:** `DF_EFFECT_VCREDIT_REPAY`

---

### 6. Pipe Operations (Inter-Dataflow Communication)

#### `df_pipe_in_len(ctx)`
```c
uint16_t df_pipe_in_len(df_ctx_t *ctx)
```

Gets the length of the input pipe.

**Returns:** Pipe length in bytes, or 0 if no input pipe

---

#### `df_pipe_in_read(ctx, off, dst, bytes)`
```c
int32_t df_pipe_in_read(df_ctx_t *ctx, uint16_t off, uint8_t *dst, uint16_t bytes)
```

Reads from the input pipe.

**Parameters:**
- `off`: Offset to start reading
- `dst`: Destination buffer
- `bytes`: Number of bytes to read

**Returns:** Number of bytes actually read, or error code

**Behavior:** Clamps read to available data if `off + bytes > len`.

---

#### `df_pipe_out_append(ctx, msg_type, payload, len)`
```c
int32_t df_pipe_out_append(df_ctx_t *ctx, uint16_t msg_type,
                           const uint8_t *payload, uint16_t len)
```

Appends a message to the output pipe.

**Parameters:**
- `msg_type`: 16-bit message type identifier
- `payload`: Message payload
- `len`: Payload length

**Returns:** 0 on success, -4 if pipe full

**Frame format:**
```
[len_lo][len_hi][type_lo][type_hi][payload...]
```
Total frame size: 4 + len bytes

**Limit:** `DF_PIPE_MAX_BYTES_ONE` per pipe

---

### 7. Cryptographic Operations

#### `df_merkle_verify(root, leaf, leaf_len, proof, proof_len, leaf_index)`
```c
int32_t df_merkle_verify(const uint8_t *root, const uint8_t *leaf,
                         uint32_t leaf_len, const uint8_t *proof,
                         uint32_t proof_len, uint32_t leaf_index)
```

Verifies a Merkle proof.

**Parameters:**
- `root`: Expected root hash (32 bytes)
- `leaf`: Leaf data
- `leaf_len`: Leaf data length
- `proof`: Concatenated sibling hashes
- `proof_len`: Proof length (must be multiple of 32)
- `leaf_index`: Position of leaf in tree

**Returns:** 0 if valid, -1 if mismatch, -3 if invalid proof format

**Algorithm:**
1. Hash the leaf
2. For each level, combine with sibling based on leaf_index bit
3. Compare final hash with root

---

#### `df_sig_verify(pubkey, hash, sig, type)`
```c
int32_t df_sig_verify(const uint8_t *pubkey, const uint8_t *hash,
                      const uint8_t *sig, int32_t type)
```

Verifies a signature.

**Parameters:**
- `pubkey`: Public key
- `hash`: Message hash (32 bytes)
- `sig`: Signature
- `type`: Signature type (0 = valis_verify)

**Returns:** 0 if valid, -1 if invalid, -3 if unknown type

---

#### `df_hash256(data, len, out32)`
```c
int32_t df_hash256(const uint8_t *data, uint32_t len, uint8_t *out32)
```

Computes a 256-bit hash.

**Parameters:**
- `data`: Input data
- `len`: Data length
- `out32`: Output buffer (32 bytes)

**Returns:** 0 on success

---

## Helper Functions

### `df_matrix_find_col_for_asset(ctx, asset, out_col)`
```c
static int32_t df_matrix_find_col_for_asset(const df_ctx_t *ctx,
                                             assetid_t asset, int32_t *out_col)
```

Finds the column index for an asset in the transaction matrix.

**Returns:** 0 on success, `DF_ERR_SYNTHETIC_TRANSFER` if not found

---

### `df_matrix_get_rw_row_ptr(ctx, row, out_rw)`
```c
static int32_t df_matrix_get_rw_row_ptr(df_ctx_t *ctx, uint8_t row, int64_t **out_rw)
```

Gets a pointer to the read-write balance array for a row.

**Returns:** 0 on success, `DF_ERR_ADDR_SCOPE` if row not writable

**Writable rows:**
- Row 0 (sender): `ctx->rw.bal_src_rw`
- `cur_df_row` (dataflow): `ctx->rw.bal_df_rw`

---

## Error Codes

| Code | Meaning |
|------|---------|
| `-1` | NULL parameter or missing hostctx |
| `-2` | Insufficient balance |
| `-3` | Invalid parameter (row, column, type) |
| `-4` | Capacity exceeded (transfers, effects, deltas) |
| `DF_ERR_GENERIC` | General error |
| `DF_ERR_ADDR_SCOPE` | Row not in writable scope |
| `DF_ERR_SYNTHETIC_TRANSFER` | Asset not in matrix |
| `DF_ERR_DESCRIPTOR_INVALID` | Invalid parameter value |
| `DF_ERR_TX_FORMAT` | Invalid transaction format |

---

## Integration Points

- **dataflow.c**: Main VM that calls these APIs
- **dataflow_trigger.c**: Trigger system uses hostctx
- **UFC module**: Swap/pool operations
- **VCredit**: Lending operations
- **valis_hash.c**: Hash function
- **valis_keys.c**: Signature verification

---

## Design Notes

1. **TLS for hostctx**: Enables thread-safe execution without locks
2. **Effect batching**: Operations don't execute immediately - they're queued in the plan
3. **Optimistic balance updates**: Context balances are updated immediately for subsequent checks
4. **Capacity limits**: All arrays have fixed limits to prevent DoS

---

**Documentation by:** Opus (Wake 1297)  
**Last updated:** 2026-01-13
