# Tockchain Documentation Index

**Generated:** Wake 1324 (2026-01-13)  
**Total Documentation Files:** 90  
**Coverage:** ~35,000+ lines of C code + Coq formal proofs

---

## Quick Navigation

| Module | Files | Purpose |
|--------|-------|---------|
| [Getting Started](#getting-started) | 3 docs | **START HERE** Quick start, architecture, UFC visual guide |
| [Bridge](#bridge-module) | 15 docs | Ethereum ↔ Valis asset bridging |
| [Dataflow](#dataflow-module) | 14 docs | Financial machine / contract engine |
| [Generator](#generator-module) | 12 docs | Block production, consensus, networking |
| [Validator](#validator-module) | 11 docs | Transaction execution, ledger state |
| [UFC](#ufc-module) | 9 docs | Unified Fair Clearing - DEX engine |
| [TSS](#tss-module) | 5 docs | Threshold signature scheme |
| [Utils](#utils-module) | 7 docs | Cryptography, networking, shared utilities |
| [Core](#core-headers) | 5 docs | Main headers and verified code |
| [Netlibs](#netlibs) | 3 docs | Network communication layer |
| [Formal Verification](#formal-verification) | 1 doc | Coq proofs overview |

---

## Getting Started

**New to Tockchain? Start here.**

| Document | Purpose |
|----------|---------|
| **TOCKCHAIN_QUICKSTART.md** | Quick orientation guide - what to read first |
| **TOCKCHAIN_ARCHITECTURE.md** | ASCII diagrams of entire system (541 lines) |
| **UFC_VISUAL_GUIDE.md** | Visual explanation of the DEX engine (424 lines) |

These visual guides use ASCII diagrams to explain:
- System architecture and module relationships
- Transaction flow from client to ledger
- UFC swap mechanics (helpful vs hurtful, OOB capacity)
- Pylon post-quantum security modes
- Data structures and file organization

## Bridge Module

The bridge enables trustless asset transfer between Ethereum and Valis.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_bridge_h.md | bridge/bridge.h | 800 | Core structures, deposit/withdraw types |
| DOC_bridge_c.md | bridge/bridge.c | 300 | Bridge initialization, state management |
| DOC_bridge_rlp.md | bridge/bridge_rlp.c | 800 | RLP encoding/decoding for Ethereum |
| DOC_bridge_mpt.md | bridge/bridge_mpt.c | 694 | Merkle Patricia Trie verification |
| DOC_bridge_mptjson.md | bridge/bridge_mptjson.c | 600 | MPT JSON parsing |
| DOC_bridge_deposit.md | bridge/bridge_deposit.c | 1270 | Deposit processing, proof verification |
| DOC_bridge_withdraw.md | bridge/bridge_withdraw.c | 1871 | Withdrawal batching, TSS signing |
| DOC_bridge_abi.md | bridge/bridge_abi.c | 1091 | Ethereum ABI encoding |
| DOC_bridge_prices.md | bridge/bridge_prices.c | 1141 | Price feeds, oracle integration |
| DOC_bridge_rpc.md | bridge/bridge_rpc.c | 712 | Ethereum RPC communication |
| DOC_bridge_rpc_h.md | bridge/bridge_rpc.h | ~200 | RPC header definitions |
| DOC_bridge_utils.md | bridge/bridge_utils.c | ~300 | Bridge utility functions |
| DOC_bridge_vsm_ref.md | bridge/bridge_vsm.ref.c | 674 | VSM reference implementation |
| DOC_ethrpc.md | bridge/ethrpc.c | 2015 | Full Ethereum RPC client |
| DOC_json.md | bridge/json.c | 900 | JSON parsing for bridge data |

**Key Concepts:**
- Deposits use Merkle Patricia Trie proofs from Ethereum
- Withdrawals are batched and signed via TSS (threshold signatures)
- Price feeds come from Chainlink oracles via datatx

---

## Dataflow Module

The financial machine / contract engine for programmable financial logic.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_dataflow_h.md | DF/dataflow.h | 408 | Core DF structures, opcodes |
| DOC_dataflow_inc_h.md | DF/dataflow_inc.h | ~300 | Internal DF includes |
| DOC_dataflow.md | DF/dataflow.c | 842 | Main DF execution engine |
| DOC_dataflow_batch.md | DF/dataflow_batch.c | 1491 | Batch processing for DF |
| DOC_dataflow_cache.md | DF/dataflow_cache.c | ~950 | DF state caching |
| DOC_dataflow_frontier.md | DF/dataflow_frontier.c | 495 | Frontier tracking |
| DOC_dataflow_trigger.md | DF/dataflow_trigger.c | 590 | Event triggers |
| DOC_dataflow_api.md | DF/dataflow_api.c | 537 | External API for DF |
| DOC_df_gas.md | DF/df_gas.h | ~200 | Gas metering |
| DOC_df_sdk.md | DF/df_sdk.h | ~200 | SDK definitions |
| DOC_vbpf.md | DF/vbpf.c | 1938 | eBPF VM integration |
| DOC_LOAN.md | DF/LOAN.c | ~1500 | Loan financial machine |
| DOC_MM.md | DF/MM.c | ~2000 | Market maker financial machine |
| DOC_PERP.md | DF/PERP.c | ~1800 | Perpetual futures machine |

**Key Concepts:**
- DF uses eBPF for safe, deterministic execution
- Financial machines (LOAN, MM, PERP) are pre-built DF programs
- All state changes happen via datatx only

---

## Generator Module

Block production, consensus, and network coordination.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_gen3.md | generator/gen3.c | 908 | Main generator loop |
| DOC_gen3_h.md | generator/gen3.h | 587 | Generator structures |
| DOC_gen3_vote.md | generator/gen3_vote.c | 1188 | Consensus voting |
| DOC_gen3_utils.md | generator/gen3_utils.c | 393 | Generator utilities |
| DOC_gen3_net.md | generator/gen3_net.c | 755 | Network layer |
| DOC_gen3_chain.md | generator/gen3_chain.c | ~800 | Chain management |
| DOC_gen3_metrics.md | generator/gen3_metrics.c | 1500 | Performance metrics |
| DOC_gen3_needbits.md | generator/gen3_needbits.c | 700 | Bit allocation |
| DOC_gen3_nodechange.md | generator/gen3_nodechange.c | 900 | Validator set changes |
| DOC_gen3_rawtock.md | generator/gen3_rawtock.c | 800 | Raw tock file handling |
| DOC_gen3_ssd.md | generator/gen3_ssd.c | ~1200 | SSD storage optimization |
| DOC_gen3_vans.md | generator/gen3_vans.c | ~600 | VAN aggregation |

**Key Concepts:**
- Tocks are 1-second blocks
- VANs aggregate transactions from multiple sources
- Consensus uses hash-based voting with finalhash

---

## Validator Module

Transaction execution and ledger state management.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_validator.md | validator/validator.c | ~1200 | Main validation loop |
| DOC_validator_h.md | validator/validator.h | ~400 | Validator structures |
| DOC_ledger_h.md | validator/ledger.h | ~600 | Ledger definitions |
| DOC_ledger_assets.md | validator/ledger_assets.c | ~800 | Asset management |
| DOC_ledger_atomic.md | validator/ledger_atomic.c | ~400 | Atomic operations |
| DOC_ledger_erc20.md | validator/ledger_erc20.c | ~400 | ERC20 token handling |
| DOC_ledger_hourly.md | validator/ledger_hourly.c | ~350 | Hourly snapshots |
| DOC_ledger_pylon7.md | validator/ledger_pylon7.c | ~900 | Pylon v7 integration |
| DOC_ledger_vhandlers.md | validator/ledger_vhandlers.c | ~700 | Transaction handlers |
| DOC_ledger_vtrade.md | validator/ledger_vtrade.c | ~600 | Trading operations |

**Key Concepts:**
- L1 state is the canonical ledger
- Tockdata (TD) produced per utime with tockdatahash
- Hourly snapshots enable fast sync

---

## UFC Module

Unified Fair Clearing - the decentralized exchange engine.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_ufc_h.md | UFC/ufc.h | ~500 | UFC structures |
| DOC_ufc_c.md | UFC/ufc.c | ~800 | Main UFC logic |
| DOC_ufc_oob.md | UFC/ufc_oob.c | ~900 | Out-of-band orders |
| DOC_ufc_orderbook.md | UFC/ufc_orderbook.c | ~800 | Order book management |
| DOC_ufc_planner.md | UFC/ufc_planner.c | ~600 | Trade planning |
| DOC_ufc_pool.md | UFC/ufc_pool.c | ~700 | Liquidity pools |
| DOC_ufc_scan.md | UFC/ufc_scan.c | ~500 | Pool scanning |
| DOC_ufc_swap.md | UFC/ufc_swap.c | ~900 | Swap execution |
| DOC_ufc_utils.md | UFC/ufc_utils.c | ~600 | UFC utilities |

**Key Concepts:**
- Runs at end-of-tock for fair ordering
- TOB (Top of Book) and OOB (Out of Band) order types
- LP deposits/withdraws with risk management

---

## TSS Module

Threshold Signature Scheme for bridge security.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_tss_overview.md | - | - | TSS architecture overview |
| DOC_tss_module.md | tss/valis_tss.c | ~800 | Main TSS implementation |
| DOC_tss_keygen.md | tss/keygen.c | ~600 | Key generation |
| DOC_tss_sig.md | tss/sig.c | ~600 | Signature generation |
| DOC_valis_herongen.md | tss/valis_herongen.c | ~1200 | Heron key generation |
| DOC_valis_heronverify.md | tss/valis_heronverify.c | ~1200 | Heron verification |

**Key Concepts:**
- 2-of-3 threshold signatures for bridge withdrawals
- Heron protocol for distributed key generation
- No single point of failure

---

## Utils Module

Shared cryptography, networking, and utility functions.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_valis_hash.md | utils/valis_hash.c | ~600 | Hashing functions |
| DOC_valis_keys.md | utils/valis_keys.c | ~600 | Key management |
| DOC_valis_math.md | utils/valis_math.c | 1216 | Fixed-point math |
| DOC_valis_net_MT.md | utils/valis_net_MT.c | 772 | Multi-threaded networking |
| DOC_valis_config.md | utils/valis_config.c | 136 | Configuration |
| DOC_valis_files.md | utils/valis_files.c | 693 | File operations |
| DOC_valis_shared.md | utils/valis_shared.c | 2000 | Shared utilities |

---

## Core Headers

Main system headers and formally verified code.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_valis_h.md | _valis.h | ~1500 | Main system header |
| DOC_frama_verified.md | frama_verified.c | ~2500 | Frama-C verified code |
| DOC_frama_verified_h.md | frama_verified.h | ~800 | Verified code header |
| DOC_cryptolibs.md | cryptolibs/ | - | External crypto libraries |
| DOC_ebpf_ubpf.md | ubpf/ | - | eBPF VM |

---

## Netlibs

Network communication layer.

| Document | Source File | Lines | Key Topics |
|----------|-------------|-------|------------|
| DOC_nng_shim.md | netlibs/nng_shim.c | ~500 | NNG wrapper |
| DOC_valis_messaging.md | netlibs/valis_messaging.c | ~600 | Message protocol |
| DOC_websocketd.md | websocketd.c | ~1500 | WebSocket server |
| DOC_websockets_h.md | websockets.h | ~200 | WebSocket header |

---

## Formal Verification

| Document | Purpose |
|----------|---------|
| DOC_coq_proofs.md | Overview of ~650 Coq proofs covering economic security, balance conservation, VM termination |

**Key Stats:**
- ~650 Qed proofs
- ~100 axioms (foundational assumptions)
- Only 2 admitted proofs (marked for completion)
- Proves: balance conservation, economic security, deterministic execution

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      TOCKCHAIN                               │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌───────────┐  ┌─────────┐  ┌─────────────┐  │
│  │Generator│→ │ Validator │→ │   UFC   │→ │   Bridge    │  │
│  │  (GEN3) │  │   (L1)    │  │  (DEX)  │  │ (ETH↔Valis) │  │
│  └─────────┘  └───────────┘  └─────────┘  └─────────────┘  │
│       ↓            ↓              ↓             ↓           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                    Dataflow (DF)                     │   │
│  │         Financial Machines: LOAN, MM, PERP          │   │
│  └─────────────────────────────────────────────────────┘   │
│       ↓            ↓              ↓             ↓           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                   Utils / Crypto                     │   │
│  │        Hash, Keys, Math, Networking, Files          │   │
│  └─────────────────────────────────────────────────────┘   │
│       ↓            ↓              ↓             ↓           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Formal Verification (Coq)              │   │
│  │     Economic Security, Balance Conservation         │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Flow

1. **Transactions** arrive at Generator nodes
2. **Generator** aggregates into VANs, runs consensus
3. **Validator** executes transactions deterministically
4. **UFC** runs at end-of-tock for fair trade clearing
5. **Bridge** handles cross-chain asset movement
6. **Dataflow** executes financial machine logic
7. **Coq proofs** verify correctness mathematically

---

## Getting Started

**For understanding the system:**
1. Start with DOC_valis_h.md for core structures
2. Read DOC_gen3.md for block production
3. Read DOC_validator.md for transaction execution
4. Read DOC_ufc_c.md for DEX mechanics

**For bridge integration:**
1. DOC_bridge_h.md for structures
2. DOC_bridge_deposit.md for deposits
3. DOC_bridge_withdraw.md for withdrawals
4. DOC_ethrpc.md for Ethereum communication

**For formal verification:**
1. DOC_coq_proofs.md for proof overview
2. DOC_frama_verified.md for C verification

---

*Documentation by Opus (Claude Opus 4.5) - Wake 1323*
