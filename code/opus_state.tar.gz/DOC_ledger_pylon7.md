# ledger_pylon7.c Documentation

**File:** `/root/valis/validator/ledger_pylon7.c`  
**Lines:** 1042  
**Module:** Validator / Ledger  
**Documented:** Wake 1317  

---

## Overview

This file implements the **Pylon** system - a post-quantum secure vault mechanism for Tockchain addresses. Pylon provides two security modes:

1. **PYLON_FAST** - Hash-chain based authentication for quick transactions
2. **PYLON_PQVAULT** - Post-quantum vault with time-locked plans and multi-key control

The system uses hash chains and domain separation to provide forward-secure authentication that remains secure even if an attacker captures current keys.

---

## Key Concepts

### Hash Chain Authentication
Pylon uses hash chains where revealing key K proves ownership because hash(K) = anchor. After use, the chain advances to the next anchor, providing forward security.

### Domain Separation
All hashes use 11-byte domain prefixes to prevent cross-domain attacks:
- `PYLON:FAST:` - Fast mode key hashing
- `PYLON:PQ:S:` - PQ vault spend key hashing
- `PYLON:PQ:C:` - PQ vault control key hashing  
- `PYLON:PQ:P:` - PQ vault plan body hashing

### Plan-Based Transactions
In PQVAULT mode, transactions are submitted as "plans" that must be committed and then revealed after a time delay, providing protection against key compromise.

---

## Data Structures

### pylon_state_t (from header)
```c
// On-chain pylon state for an address
typedef struct {
    uint8_t plan_hash[32];   // Hash of pending plan (zero if none)
    uint8_t anchor[32];      // Current spend anchor
    uint8_t seed_next[32];   // Next control anchor
} pylon_state_t;
```

### pylon_chain_state_t
```c
typedef struct {
    uint8_t anchor[32];      // Current anchor from chain
    uint8_t plan_hash[32];   // Active plan hash
    uint8_t seed_next[32];   // Next seed
    uint32_t plan_utime;     // Plan timestamp
    int32_t mode;            // PYLON_FAST or PYLON_PQVAULT
} pylon_chain_state_t;
```

### pylon_wallet_t
```c
typedef struct {
    uint8_t srcaddr[PKSIZE];           // Source address
    int32_t mode;                       // Operating mode
    
    // Fast mode state
    uint8_t fast_k_curr[32];           // Current key
    uint8_t fast_k_next[32];           // Next key (pre-generated)
    uint32_t fast_utime;               // Timestamp for next key
    int32_t fast_have_next;            // Whether next key is ready
    
    // PQ vault state
    uint8_t *pq_spend_keys;            // Spend key chain
    uint8_t *pq_ctl_keys;              // Control key chain
    uint32_t pq_spend_depth;           // Spend chain depth
    uint32_t pq_ctl_depth;             // Control chain depth
    uint32_t pq_spend_index;           // Current spend index
    uint32_t pq_ctl_index;             // Current control index
    
    // Pending transaction state
    int32_t pending_active;            // Plan in progress
    int32_t cancel_requested;          // Cancellation pending
    int32_t abort_inflight;            // Abort in progress
    uint8_t pending_plan_hash[32];     // Hash of pending plan
    uint32_t pending_plan_len;         // Length of pending plan
    uint32_t pending_depth;            // Retry depth
    
    // Pre-built transactions
    uint8_t tx_init[MAX_TXSIZE];       // Init transaction
    uint32_t tx_init_len;
} pylon_wallet_t;
```

### pylon_wallet_action_t
```c
typedef struct {
    pylon_wallet_action_kind_t kind;   // Action type
    const uint8_t *tx;                 // Transaction data
    uint32_t len;                      // Transaction length
    uint32_t delay_utime;              // Delay before action
} pylon_wallet_action_t;
```

### pylon_wallet_action_kind_t
```c
typedef enum {
    PYLON_WACT_NONE = 0,
    PYLON_WACT_SEND_INIT,              // Send initialization tx
    PYLON_WACT_SEND_COMMIT,            // Send commit tx
    PYLON_WACT_WAIT_REVEAL,            // Wait for reveal time
    PYLON_WACT_SEND_REVEAL,            // Send reveal tx
    PYLON_WACT_SEND_ABORT,             // Send abort tx
    PYLON_WACT_DONE,                   // Transaction complete
    PYLON_WACT_ERROR                   // Error occurred
} pylon_wallet_action_kind_t;
```

---

## Core Functions

### Hash Domain Functions

#### pylon_hash_domain_key()
```c
static void pylon_hash_domain_key(const char *domain, const uint8_t key[32], uint8_t out[32])
```
Hashes a key with domain prefix for domain separation.

#### pylon_hash_fast_key()
```c
static void pylon_hash_fast_key(const uint8_t key[32], uint8_t out[32])
```
Hash key with PYLON:FAST: domain.

#### pylon_hash_pq_spend_key()
```c
static void pylon_hash_pq_spend_key(const uint8_t key[32], uint8_t out[32])
```
Hash key with PYLON:PQ:S: domain for spend keys.

#### pylon_hash_pq_control_key()
```c
static void pylon_hash_pq_control_key(const uint8_t key[32], uint8_t out[32])
```
Hash key with PYLON:PQ:C: domain for control keys.

#### pylon_hash_pq_plan_body()
```c
static void pylon_hash_pq_plan_body(const uint8_t *plan_body, int32_t plan_len, uint8_t out[32])
```
Hash plan body with PYLON:PQ:P: domain.

---

### State Management

#### pylon_is_cold_plan_active()
```c
int32_t pylon_is_cold_plan_active(const pylon_state_t *st)
```
Returns 1 if a plan is currently pending (plan_hash is non-zero).

#### pylon_state_init_fast()
```c
void pylon_state_init_fast(pylon_state_t *st, const uint8_t initial_anchor[32])
```
Initialize pylon state for FAST mode with given anchor.

#### pylon_finalize_addr()
```c
void pylon_finalize_addr(struct addrhashentry *ap)
```
Finalize pylon state after successful transaction. Advances the hash chain by moving seed_next to anchor.

---

### Transaction Validation (Validator Side)

#### pylon_hot_check_and_stage()
```c
int32_t pylon_hot_check_and_stage(struct addrhashentry *ap, const uint8_t k_curr[32], const uint8_t c_next[32])
```
Validate and stage a FAST mode transaction:
- Verify no cold plan is active
- Check hash(k_curr) matches current anchor
- Stage c_next as the next anchor

Returns 1 on success, 0 on failure.

#### pylon_control_check_and_advance()
```c
int32_t pylon_control_check_and_advance(pylon_state_t *st, const uint8_t ctl_k[32])
```
Validate control key for PQVAULT operations:
- Check hash(ctl_k) matches seed_next
- Advance control chain

#### pylon_locktx_init()
```c
int32_t pylon_locktx_init(struct valisL1_info *L1, const struct locktx *tx, struct addrhashentry *ap)
```
Process PYLON initialization transaction:
- Set up initial spend anchor from pylon[0]
- Set up initial control anchor from pylon[1]
- Mark address as pylon-protected

#### pylon_locktx_commit()
```c
int32_t pylon_locktx_commit(struct valisL1_info *L1, const struct locktx *tx, struct addrhashentry *ap)
```
Process plan commit transaction:
- Verify control key
- Store plan hash
- Record commit timestamp

#### pylon_locktx_reveal()
```c
int32_t pylon_locktx_reveal(struct valisL1_info *L1, const struct locktx *tx, struct addrhashentry *ap,
                            const uint8_t **inner_out, int32_t *inner_len_out)
```
Process plan reveal transaction:
- Verify plan hash matches committed hash
- Verify spend key
- Extract inner transaction
- Advance both key chains
- Return inner transaction for execution

#### pylon_locktx_abort()
```c
int32_t pylon_locktx_abort(struct valisL1_info *L1, const struct locktx *tx, struct addrhashentry *ap)
```
Abort a pending plan:
- Verify control key
- Clear plan hash
- Advance control chain only

---

### Wallet Functions (Client Side)

#### pylon_wallet_open()
```c
int32_t pylon_wallet_open(pylon_wallet_t *W, const uint8_t srcaddr[PKSIZE])
```
Initialize wallet structure for an address.

#### pylon_wallet_close()
```c
int32_t pylon_wallet_close(pylon_wallet_t *W)
```
Clean up wallet, zeroing sensitive key material.

#### pylon_wallet_build_init_fast()
```c
int32_t pylon_wallet_build_init_fast(pylon_wallet_t *W, uint32_t utime, pylon_wallet_action_t *out_action)
```
Build initialization transaction for FAST mode:
- Generate random initial key
- Build hash chain
- Create init transaction

#### pylon_wallet_build_init_pqvault()
```c
int32_t pylon_wallet_build_init_pqvault(pylon_wallet_t *W, uint32_t utime, uint32_t depth,
                                        pylon_wallet_action_t *out_action)
```
Build initialization for PQVAULT mode:
- Generate spend and control key chains
- Create init transaction with head anchors

#### pylon_wallet_fast_fill_header()
```c
int32_t pylon_wallet_fast_fill_header(pylon_wallet_t *W, uint32_t utime, uint8_t out_pylon[2][32])
```
Fill pylon header fields for a FAST mode transaction:
- pylon[0] = current key (reveals ownership)
- pylon[1] = hash of next key (commits to chain)

#### pylon_wallet_fast_sync_from_chain()
```c
int32_t pylon_wallet_fast_sync_from_chain(pylon_wallet_t *W, const pylon_chain_state_t *cs)
```
Synchronize wallet state with on-chain state after transaction confirmation.

#### pylon_wallet_pqvault_submit()
```c
int32_t pylon_wallet_pqvault_submit(pylon_wallet_t *W, const uint8_t *inner_tx, uint32_t inner_len, uint32_t depth)
```
Submit a transaction through PQVAULT:
- Build plan with inner transaction
- Set up retry depth for key chain advancement

---

### Key Chain Building

#### pylon_wallet_chain_build_from_tail_domain()
```c
int32_t pylon_wallet_chain_build_from_tail_domain(const char *domain, const uint8_t tail_k[32],
                                                   uint32_t depth, uint8_t *keys_out,
                                                   uint32_t keys_out_cap, uint8_t head_anchor_out[32])
```
Build a hash chain from tail key:
- Start with random tail key
- Hash repeatedly to build chain
- Return all keys and head anchor
- Keys stored in reverse order for forward security

---

## Security Model

### Forward Security
If an attacker captures the current key, they cannot:
- Compute previous keys (hash preimage resistance)
- Use the key twice (chain advances after each use)
- Predict future keys (random generation)

### Time-Lock Protection (PQVAULT)
The commit-wait-reveal pattern provides:
- Time for detection of key compromise
- Ability to abort before reveal
- Protection against real-time attacks

### Post-Quantum Considerations
The "PQ" in PQVAULT refers to post-quantum security:
- Hash-based authentication is quantum-resistant
- No reliance on discrete log or factoring
- Key chains provide defense in depth

---

## Error Codes

| Code | Meaning |
|------|---------|
| -320 | Null pointer in reveal |
| -321 | Wrong pylon mode (expected PQVAULT) |
| -322 | No active plan to reveal |
| -323 | pylon[1] should be zero for reveal |
| -324 | Reveal too early (time lock) |
| -325 | Invalid plan length |
| -326 | Plan too short (< 64 bytes) |
| -327 | Plan hash mismatch |
| -328 | Spend key mismatch |
| -329 | Next spend anchor is zero |
| -330 | Next control anchor is zero |
| -331 | Inner tx too short |
| -332 | Can't read inner utime |
| -333 | Inner utime must be zero |

---

## Transaction Flow

### FAST Mode
```
1. pylon_wallet_build_init_fast() → SEND_INIT
2. For each transaction:
   a. pylon_wallet_fast_fill_header() → fill pylon[0], pylon[1]
   b. Send transaction
   c. pylon_wallet_fast_sync_from_chain() → advance local state
```

### PQVAULT Mode
```
1. pylon_wallet_build_init_pqvault() → SEND_INIT
2. For each transaction:
   a. pylon_wallet_pqvault_submit() → SEND_COMMIT
   b. Wait for time lock
   c. SEND_REVEAL → inner transaction executes
   d. (or SEND_ABORT if compromised)
```

---

## Dependencies

- `valis_hash()` - Core hashing function
- `struct locktx` - Lock transaction structure
- `struct addrhashentry` - Address hash table entry
- `pylon_const_time_eq()` - Constant-time comparison

---

## Related Files

- `ledger.h` - Pylon type definitions
- `validator.c` - Transaction validation integration
- `ledger_assets.c` - Asset ledger (pylon protects)
