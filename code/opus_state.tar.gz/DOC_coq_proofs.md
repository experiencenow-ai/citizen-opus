# Tockchain Coq Formal Verification System

**Location:** `/valis/coq/`  
**Pass:** 326  
**Documentation by:** Opus (wake 1322)

---

## Overview

Tockchain uses Coq for formal verification of its core economic and security properties. This is not just testing or auditing—it's mathematical proof that certain properties hold under all possible inputs and execution paths.

### Key Statistics

| Metric | Count |
|--------|-------|
| **Qed Proofs** | ~650 |
| **Axioms** | 100 |
| **Admitted** | 2 |
| **Files** | ~150 |
| **Modules** | 15 |

The 2 admitted proofs are:
1. `quorum_always_achievable` — BFT liveness (straightforward arithmetic)
2. `ufc_lp_step_delta...` — implementation obligation

---

## Module Architecture

```
                         ┌──────────────────┐
                         │    overview/     │
                         └────────┬─────────┘
                                  │
        ┌─────────────────────────┼─────────────────────────┐
        ▼                         ▼                         ▼
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│ crosscutting │◄────────│   common/    │────────►│  tockchain/  │
└──────────────┘         └──────────────┘         └──────────────┘
        │                        │                        │
        ▼                        ▼                        ▼
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│   bridge/    │         │    UFC/      │◄───────►│  generator/  │
└──────────────┘         └──────────────┘         └──────────────┘
                                │                        │
       ┌────────────────────────┼────────────────────────┤
       ▼                        ▼                        ▼
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│  orderbook/  │────────►│   ledger/    │◄────────│  nodechange/ │
└──────────────┘         └──────────────┘         └──────────────┘
                                │
       ┌────────────────────────┼────────────────────────┐
       ▼                        ▼                        ▼
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│    vbpf/     │         │ postquantum/ │         │   network/   │
└──────────────┘         └──────────────┘         └──────────────┘
```

---

## Module Purposes

| Module | Purpose | Key Theorems |
|--------|---------|--------------|
| **common/** | Core types, trace algebra | `TraceAlgebra.no_arb_leakage` |
| **UFC/** | Economic security | `ufc_kernel_roundtrip_profit_le_0` |
| **generator/** | Consensus, RNG | `GeneratorClaims` |
| **nodechange/** | Validator evolution | `NodechangeSpec` |
| **ledger/** | Balance atomicity | `LedgerConservation` |
| **DF/** | Smart contract execution | `DataflowSafety` |
| **bridge/** | Ethereum interop | `BridgeWithdrawalEndToEnd` |
| **orderbook/** | Fill calculation | `OrderbookProofs` |
| **vbpf/** | VM memory/gas safety | `VbpfTermination` |
| **postquantum/** | PQ crypto | `Falcon512Scope` |
| **recovery/** | SSD rescue | `RecoveryProofs` |
| **coldspend/** | Cold balance sweep | `ColdspendProofs` |
| **tockchain/** | Scheduling, commitment | `TockchainCommitment` |
| **efficiency/** | TPS model | `EfficiencyModel` |
| **frama/** | C code linkage | `FramaCLink` |

---

## Core Proof Methodology: TraceAlgebra

The fundamental proof pattern in Tockchain is **TraceAlgebra**:

```coq
1. Define event-level deltas (lp_delta, premium_delta)
2. Prove event-level: lp + premium >= 0
3. Apply TraceAlgebra.no_arb_leakage_for_extension
4. Get trace-level monotonicity for free
```

This pattern allows proving that economic invariants hold across arbitrary execution traces, not just single events.

---

## Key Theorems

### 1. UFC Economic Security (`UfcEconomicSecurity.v`)

**Theorem: Roundtrip Non-Profit**
```coq
Theorem ufc_kernel_roundtrip_profit_le_0 :
  forall v_in ... v_out,
  (* conditions *)
  v_out <= v_in.
```
*Meaning: Any attempt to arbitrage VUSD↔OTHER returns at most what you put in.*

**Theorem: Attacker Pays Premium**
```coq
Theorem ufc_kernel_v2o_attacker_pays_premium :
  forall v_in out_total ufc_px,
  (* conditions *)
  (- v_in * SATOSHIS + out_total * ufc_px) <= 
    - (v2o_premium_vusd v_in out_total ufc_px) * SATOSHIS.
```
*Meaning: Any trade that benefits the pool costs the attacker at least the premium.*

**Theorem: Coinbase Value Preserved**
```coq
Theorem ufc_kernel_coinbase_winner_value_preserved :
  forall w px,
  0 < px ->
  value_at_px (convert_all_vnet_to_vusd w px) px = value_at_px w px.
```
*Meaning: Coinbase conversion preserves winner's value exactly.*

### 2. Ledger Conservation (`LedgerConservation.v`)

**Theorem: No Double Mint**
```coq
Theorem no_double_mint : (* Level A - proven from definitions *)
```
*Meaning: The same mint event cannot be applied twice.*

**Theorem: All Handlers Conserve**
```coq
Theorem all_handlers_conserve : (* Level B - proven assuming axioms *)
```
*Meaning: Every ledger operation preserves total balance.*

### 3. VBPF Termination (`VbpfTermination.v`)

**Theorem: Always Terminates**
```coq
Theorem vbpf_always_terminates : (* Level B *)
```
*Meaning: Smart contract execution always terminates (no infinite loops).*

### 4. Generator Consensus (`GeneratorClaims.v`)

**Theorem: Quorum Intersection Has Honest**
```coq
Theorem quorum_intersection_has_honest : (* Level A *)
```
*Meaning: Any two quorums share at least one honest validator.*

---

## Axiom Categories

The 100 axioms fall into these categories:

| Category | Count | Justification |
|----------|-------|---------------|
| **Frama-C Verified** | 29 | C functions verified by Frama-C/WP |
| **UFC Economic** | 17 | Economic model assumptions |
| **Nodechange** | 14 | Validator set semantics |
| **Ledger** | 11 | Handler conservation |
| **Bridge** | 10 | SPV/Merkle soundness |
| **Crypto** | 8 | Standard cryptographic assumptions |
| **Generator** | 7 | Honest node behavior |
| **Recovery** | 7 | SSD rescue semantics |
| **Network** | 3 | Message delivery |
| **Post-Quantum** | 2 | PQ crypto assumptions |
| **VBPF** | 1 | Instruction gas costs |
| **Efficiency** | 1 | TPS model |

### Cryptographic Axioms (Standard Assumptions)

These are the same assumptions all cryptography relies on:

1. **Hash Collision Resistance** - KangarooTwelve 256-bit output, 2^128 birthday bound
2. **Hash Preimage Resistance** - 2^256 classical, 2^128 quantum (Grover)
3. **SchnorrQ Unforgeability** - EUF-CMA under discrete log on FourQ
4. **Falcon-512 Unforgeability** - NIST PQC standard, NTRU lattices

### Frama-C Linked Axioms

These axioms are proven in C code via Frama-C/WP, then linked to Coq:

```coq
Axiom ufc_v2o_fill_no_arb :
  forall ..., v2o_fill_no_arb_property ...
```

The C implementation is verified separately, and the axiom states that the Coq model matches the verified C.

---

## Trust Levels

### Level A: Proven from Definitions
No axioms required. Pure mathematical derivation.
- `no_double_mint`
- `quorum_intersection_has_honest`

### Level B: Proven Assuming Axioms
Relies on cryptographic or implementation axioms.
- `ufc_event_no_arb_leakage`
- `all_handlers_conserve`
- `vbpf_always_terminates`
- `no_privileged_nodeid`
- `promotion_requires_better_metrics`

### Level C: Abstract Model
High-level properties of the abstract model.
- `pylon_domain_separation_complete`
- `dataflow_is_deterministic`
- `recovery_events_economically_inert`

---

## Frama-C Integration

The `/coq/pass326/frama/` directory contains the bridge between Coq proofs and C code:

- **FramaVerifiedContracts.v** - Axioms about Frama-C verified functions
- **FramaCLink.v** - Links C implementation to Coq model
- **evidence/frama_verified.c** - The actual verified C code

This creates a chain:
```
Coq Theorem → Coq Axiom → Frama-C Proof → C Implementation
```

---

## Building the Proofs

```bash
cd /valis/coq/pass326
make
```

The `_CoqProject` file defines the compilation order (~150 files).

---

## Why This Matters

Traditional blockchain security relies on:
1. Testing (covers some cases)
2. Auditing (human review)
3. Bug bounties (adversarial discovery)

Tockchain's formal verification provides:
1. **Mathematical certainty** - Properties hold for ALL inputs
2. **Compositional reasoning** - Module proofs combine
3. **Explicit assumptions** - Every axiom is documented and justified
4. **Implementation linkage** - Proofs connect to actual C code

The 650 Qed proofs mean 650 properties that are mathematically guaranteed, not just tested.

---

## Key Files for Understanding

1. **ARCHITECTURE.md** - Module dependency graph
2. **FILE_SUMMARY.md** - What each file does (by compilation order)
3. **AXIOM_REGISTRY.md** - All 100 axioms listed
4. **AXIOM_JUSTIFICATION.md** - Why each axiom is reasonable
5. **CLAIMS.md** - Summary of what's proven
6. **UfcEconomicSecurity.v** - The "headline" economic theorems

---

## Connection to ct's Vision

This formal verification is the technical foundation for ct's vision of making organized crime structurally unprofitable. The proofs show that:

1. **Arbitrage is unprofitable** - You can't extract value through trading
2. **Premiums protect the system** - Attackers pay for any benefit
3. **Balances are conserved** - No money appears or disappears
4. **Contracts terminate** - No infinite loops or resource exhaustion

These aren't just claims—they're mathematical theorems. This is Type 1 trust (formal verification) rather than Type 2 trust (accumulated character).

---

*Documentation created wake 1322. This represents the formal verification heart of Tockchain.*
