# valis_shared.c Documentation

## Overview

**File:** `utils/valis_shared.c`  
**Lines:** ~2032  
**Purpose:** Shared functions that require knowledge of multiple core headers (`_valis.h`, `gen3.h`, `validator.h`). Used by applications like `wsdprog`, `txblast`, and other tools that need cross-module functionality.

## Dependencies

```c
#include "gen3.h"
#include "validator.h"
#include "frama_verified.h"
```

This file acts as a bridge between the generator, validator, and formally verified components.

## Global Variables

| Variable | Type | Description |
|----------|------|-------------|
| `MULTITHREAD_TEST` | `int32_t` | Flag for multithread testing mode |

## Core Functions

### Consensus Functions

#### `supermajority_election`
```c
int32_t supermajority_election(int32_t myid, int32_t qidx, int32_t domain,
                               uint64_t candidatebits, uint8_t *votes,
                               int32_t votesize, int32_t num, uint8_t winner[32])
```
**Purpose:** Determines consensus winner from a set of votes using supermajority rules.

**Parameters:**
- `myid`: Node identifier
- `qidx`: Queue index (e.g., `QIDX_MISSINGRAWTOCK`)
- `domain`: Voting domain
- `candidatebits`: Bitmask of excluded candidates
- `votes`: Array of vote data
- `votesize`: Size of each vote (up to 32 bytes)
- `num`: Number of votes
- `winner`: Output buffer for winning vote

**Returns:** Maximum vote count for the winner

**Algorithm:**
1. Iterates through all votes, skipping those marked in `candidatebits`
2. Counts votes for each unique candidate
3. Tracks the candidate with the most votes
4. Reports split votes if debug enabled and multiple candidates exist
5. Returns the winning vote and vote count

### Transaction Construction Functions

#### `tx_standard_whash`
```c
int32_t tx_standard_whash(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                          assetid_t asset, uint8_t src[PKSIZE],
                          uint8_t dest[PKSIZE], int64_t amount, uint32_t r)
```
**Purpose:** Creates a standard transaction with a hash component.

#### `tx_lock`
```c
int32_t tx_lock(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                const uint8_t src[PKSIZE], const uint8_t dest[PKSIZE],
                uint32_t locktime, uint8_t func)
```
**Purpose:** Creates a time-locked transaction.

#### `tx_pool`
```c
int32_t tx_pool(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                assetid_t asset, assetid_t destasset, uint8_t src[PKSIZE],
                int64_t amount, int64_t poolarg, int32_t function)
```
**Purpose:** Creates pool-related transactions (add/remove liquidity, swaps).

#### `tx_standard`
```c
int32_t tx_standard(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                    assetid_t asset, uint8_t src[PKSIZE],
                    uint8_t dest[PKSIZE], int64_t amount)
```
**Purpose:** Creates a basic transfer transaction.

#### `tx_system`
```c
int32_t tx_system(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                  uint8_t src[PKSIZE], uint8_t nodeid,
                  uint8_t newgen[PKSIZE], uint32_t newipbits,
                  uint16_t newport, uint8_t removegen[PKSIZE])
```
**Purpose:** Creates system-level transactions for node management (add/remove generators).

#### `tx_orderbook`
```c
int32_t tx_orderbook(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                     assetid_t makerasset, assetid_t takerasset,
                     uint8_t makerpub[PKSIZE], uint8_t OTCpub[PKSIZE],
                     uint8_t takerpub[PKSIZE], int64_t VUSDprice,
                     int64_t amount, int32_t cancelorder, int32_t claimcoinbase)
```
**Purpose:** Creates orderbook transactions for OTC trading.

#### `tx_bridgecreate`
```c
int32_t tx_bridgecreate(int32_t *signlenp, uint8_t *txbuf, uint32_t utime,
                        assetid_t asset, uint8_t src[PKSIZE], uint8_t name[32],
                        int64_t amount, int64_t initial_poolamount,
                        int32_t mintable, int32_t minsigs, int32_t numsigs)
```
**Purpose:** Creates bridge asset creation/minting transactions.

### Transaction Utilities

#### `tx_setstandard`
```c
void tx_setstandard(struct stdtx *tx, uint32_t utime, assetid_t asset,
                    uint8_t src[PKSIZE], uint8_t dest[PKSIZE], int64_t amount)
```
**Purpose:** Sets common fields in a standard transaction structure.

#### `calc_txsize`
```c
int32_t calc_txsize(struct txheader *txH, int32_t *signlenp)
```
**Purpose:** Calculates the size of a transaction based on its type and flags.

**Returns:** Total transaction size in bytes, sets `*signlenp` to signature length.

#### `valis_calc_signthis`
```c
int32_t valis_calc_signthis(struct txheader *txH, int32_t signlen, uint8_t signhash[32])
```
**Purpose:** Calculates the hash that needs to be signed for a transaction.

### Asset Functions

#### `asset_str` / `_asset_str`
```c
char *asset_str(char name[64], struct valisL1_info *L1, assetid_t asset)
char *_asset_str(char name[64], assetid_t asset)
```
**Purpose:** Converts asset ID to human-readable string.

#### `isVUSD`
```c
int32_t isVUSD(assetid_t asset)
```
**Purpose:** Checks if an asset is the VUSD stablecoin.

#### `is_null_asset`
```c
int32_t is_null_asset(struct valisL1_info *L1, uint32_t aid)
```
**Purpose:** Checks if an asset ID represents a null/empty asset.

#### `set_poolpub`
```c
void set_poolpub(assetid_t asset, uint8_t poolpub[PKSIZE])
```
**Purpose:** Generates the pool public key for an asset.

### Display/Debug Functions

#### `disp_poolvals`
```c
void disp_poolvals(int64_t vusd, int64_t other, int64_t shares)
```
**Purpose:** Displays pool values for debugging.

#### `disp_addrhashentry`
```c
void disp_addrhashentry(struct valisL1_info *L1, struct addrhashentry *ap)
```
**Purpose:** Displays address hash entry details.

#### `changeid_str`
```c
void changeid_str(changeid_t lastchange, char *changestr)
```
**Purpose:** Converts change ID to string representation.

#### `assetbalance_str`
```c
void assetbalance_str(struct valisL1_info *L1, assetbalance_t balance, char *assetstr)
```
**Purpose:** Converts asset balance to string.

### File I/O Functions

#### `load_rawtxdata`
```c
int32_t load_rawtxdata(rawtock_info_t *rinfo, uint32_t utime, FILE *fp,
                       int32_t fsize, int32_t validate_txids)
```
**Purpose:** Loads raw transaction data from a file into a rawtock info structure.

#### `load_election_sigs`
```c
int32_t load_election_sigs(char *fname, valis_vote_info_t votes[MAX_VALIDATORS],
                           qheader_t *qH)
```
**Purpose:** Loads election signatures from file.

#### `load_validator_sigs` / `load_generator_sigs`
```c
int32_t load_validator_sigs(uint32_t utime, valis_vote_info_t votes[MAX_VALIDATORS],
                            qheader_t *qH)
int32_t load_generator_sigs(uint32_t utime, valis_vote_info_t votes[MAX_VALIDATORS],
                            qheader_t *qH)
```
**Purpose:** Loads validator/generator signatures for a given time.

#### `load_eth_header_sigs`
```c
int32_t load_eth_header_sigs(uint8_t blockhash[32],
                             valis_vote_info_t votes[MAX_VALIDATORS],
                             qheader_t *qH)
```
**Purpose:** Loads Ethereum header signatures for bridge verification.

### Validator Management

#### `get_validator_id`
```c
int32_t get_validator_id(validators_t *ds, uint8_t pubkey[PKSIZE])
```
**Purpose:** Gets validator ID from public key.

#### `load_validators_file`
```c
int32_t load_validators_file(char *fname, int32_t myid, uint8_t txbuf[NODECHANGE_SIZEOF_FULLTX],
                             validators_t *ds)
```
**Purpose:** Loads validator set from file.

#### `get_validators`
```c
int32_t get_validators(uint32_t utime, validators_t *ds)
```
**Purpose:** Gets current validator set for a given time.

#### `disp_validators`
```c
void disp_validators(validators_t *ds)
```
**Purpose:** Displays validator set information.

### Validation Functions

#### `validate_rawtockfile`
```c
int32_t validate_rawtockfile(int32_t myid, rawtock_info_t *rinfo, validators_t *ds,
                             uint32_t utime, uint8_t validators_hash[32],
                             int32_t validate_txids)
```
**Purpose:** Validates a raw tock file against the validator set.

### Network Functions

#### `wget_utime_files`
```c
int32_t wget_utime_files(char *suffix, uint32_t utime, uint32_t ipbits, int32_t asyncflag)
```
**Purpose:** Downloads time-stamped files from network.

### Metrics Functions

#### `save_latestL0` / `_load_latestL0`
```c
int32_t save_latestL0(global_reserve_t *GEN3, uint32_t latest_utime)
int32_t _load_latestL0(FILE *fp, Gmetrics_api_t *api)
```
**Purpose:** Save/load L0 metrics state.

#### `latestL1_utime`
```c
uint32_t latestL1_utime(Vmetrics_api_t *api)
```
**Purpose:** Gets the latest L1 timestamp from metrics.

### Messaging Functions

#### `get_pushsock`
```c
int32_t get_pushsock(int32_t pushsock)
```
**Purpose:** Gets or creates a push socket for IPC communication.

#### `decode_failed_word`
```c
void decode_failed_word(uint32_t word, uint32_t *txindp, int16_t *errcodep)
```
**Purpose:** Decodes a packed error word into transaction index and error code.

## Key Data Structures Used

### Transaction Types
- `struct stdtx` - Standard transaction
- `struct std_whashtx` - Standard transaction with hash
- `struct bridgetx` - Bridge transaction
- `struct txheader` - Transaction header

### State Structures
- `rawtock_info_t` - Raw tock file information
- `validators_t` - Validator set
- `valis_vote_info_t` - Vote information
- `qheader_t` - Queue header

### Metrics
- `Gmetrics_api_t` - Global metrics API
- `Vmetrics_api_t` - Validator metrics API

## Usage Patterns

### Creating a Transaction
```c
uint8_t txbuf[VALIS_MAX_TXSIZE];
int32_t signlen, txsize;

// Create standard transfer
txsize = tx_standard(&signlen, txbuf, current_utime, asset, src_pubkey, dest_pubkey, amount);

// Calculate what to sign
uint8_t signhash[32];
valis_calc_signthis((struct txheader *)txbuf, signlen, signhash);

// Sign and submit...
```

### Validating Consensus
```c
uint8_t winner[32];
int32_t votes = supermajority_election(myid, qidx, domain, candidatebits,
                                       vote_array, 32, num_validators, winner);
if (votes >= (num_validators * 2 / 3 + 1)) {
    // Supermajority achieved
}
```

## Architecture Notes

1. **Cross-Module Bridge**: This file exists because some functionality requires knowledge of both generator and validator internals. Rather than creating circular dependencies, shared functions live here.

2. **Transaction Factory**: Most `tx_*` functions follow a pattern:
   - Accept transaction parameters
   - Fill a buffer with the transaction structure
   - Return the size and signature length

3. **Consensus Integration**: The `supermajority_election` function is central to Valis consensus, determining winners from validator votes.

4. **IPC Communication**: Uses the vmsg (valis messaging) abstraction for inter-process communication via push/pull sockets.

## Related Files

- `gen3.h` / `gen3.c` - Generator implementation
- `validator.h` / `validator.c` - Validator implementation  
- `frama_verified.c` - Formally verified core functions
- `valis_messaging.c` - Messaging abstraction layer
