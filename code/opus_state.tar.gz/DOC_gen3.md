# gen3.c Documentation

**File:** `/root/valis/generator/gen3.c`  
**Lines:** 908  
**Documented:** Wake 1301  
**Author:** Opus

---

## Overview

`gen3.c` is the core block generation engine for Tockchain. It implements:

1. **Tock State Machine** - Per-second state transitions for consensus
2. **VAN Management** - Validator Announcement Network packet handling
3. **Quorum Tracking** - Active node detection and consensus building
4. **Main Event Loop** - The `valis_loop` that drives the entire system

This is the heart of Tockchain's consensus mechanism.

---

## Design Philosophy (from comments)

The file header contains extensive notes on attack vectors and mitigations:

### Mitigated Attacks
- **Fake nodetxidshash** - Signature verification
- **Fake rawtockfile** - Validation in `-vonly` mode
- **Missing node** - Active nodes mask adjusts dynamically
- **VAN spam** - Per-node limits prevent CPU exhaustion
- **TX spam** - High processing capacity, uses archive space only
- **Numsigs attack** - Adaptive validator speed catches up
- **Network partition** - Cross-pollination after time delay

### Open Issues (TODOs)
- Incomplete VANs sent (30-second timeout solution)
- Incomplete datasync
- RAM exhaustion from spam
- Anti-geoclustering (latency-based cluster penalties)

---

## State Machine

The tock state machine processes one "utime" (Unix timestamp second) at a time:

```
USTATE_IDLE → USTATE_NEW_UTIME → USTATE_ADMIT_NORMAL → USTATE_ADMIT_VIP_ONLY → USTATE_WAITFOR_QUORUM → USTATE_IDLE
```

### States

| State | Description |
|-------|-------------|
| `USTATE_IDLE` | Waiting for next tock |
| `USTATE_NEW_UTIME` | Initialize new tock period |
| `USTATE_ADMIT_NORMAL` | Accepting normal transactions |
| `USTATE_ADMIT_VIP_ONLY` | Only VIP transactions accepted |
| `USTATE_WAITFOR_QUORUM` | Waiting for consensus quorum |

---

## Key Functions

### State Handlers

#### ustate_new_utime

```c
static uint64_t ustate_new_utime(utime_data_t *U)
```

Initializes a new tock period.

**Actions:**
1. If previous tock incomplete, dump partial VANs to SSD
2. Write rescue headers for recovery
3. Increment utime by `VNET_FIFOSIZE`
4. Ensure hourly directory exists
5. Initialize new utime data structures

**Returns:** `USTATE_ADMIT_NORMAL`

#### ustate_admit_normal

```c
static uint64_t ustate_admit_normal(utime_data_t *U)
```

Accepts normal (non-VIP) transactions.

**Actions:**
1. Wait until cutoff time (`GEN3_NORMAL_TX_CUTOFF` before tock)
2. Add system metrics transaction if pending
3. Complete any active normal VANs
4. Finalize node VANs for normal tier
5. Calculate needbits for sync

**Returns:** `USTATE_ADMIT_VIP_ONLY`

#### ustate_admit_vip_only

```c
static uint64_t ustate_admit_vip_only(utime_data_t *U)
```

Accepts only VIP transactions (higher priority, later deadline).

**Actions:**
1. Wait until tock boundary
2. Emit VIP deadline entropy (cold transaction)
3. Complete VIP VANs
4. Finalize node VANs for VIP tier
5. Calculate VIP needbits

**Returns:** `USTATE_WAITFOR_QUORUM`

#### ustate_waitfor_quorum

```c
static uint64_t ustate_waitfor_quorum(utime_data_t *U)
```

Waits for consensus on VANs hash and final hash.

**Phases:**
1. **VANs Hash Phase:** Collect and verify node VAN hashes
2. **Final Hash Phase:** Compute and agree on final tock hash
3. **Completion:** When quorum achieved, transition to idle

**Returns:** `USTATE_IDLE` when complete, or stays in current state

---

### VAN Management

#### add_tx_to_active_van

```c
int32_t add_tx_to_active_van(utime_data_t *U, int32_t is_vip, uint8_t *txbuf, 
                              uint16_t txsize, int32_t broadcast)
```

Adds a transaction to the current active VAN.

**Parameters:**
- `is_vip`: 1 for VIP tier, 0 for normal
- `txbuf`: Transaction data
- `txsize`: Transaction size
- `broadcast`: Whether to broadcast immediately

#### complete_active_van

```c
void complete_active_van(utime_data_t *U, van_t *van, int32_t broadcast)
```

Finalizes and broadcasts a VAN.

#### broadcast_cold_vans_after_vanshash

```c
int32_t broadcast_cold_vans_after_vanshash(utime_data_t *U)
```

Broadcasts cold VANs after VAN hash is computed.

**Purpose:** Cold VANs contain entropy and are held until after the VAN hash deadline to prevent manipulation.

---

### Quorum Functions

#### check_activenodes

```c
uint64_t check_activenodes(utime_data_t *U)
```

Determines which nodes are active for this tock.

**Algorithm:**
1. Start with seen nodes bitmap
2. Exclude disabled nodes
3. Cross-reference with received activenodes from peers
4. Count votes for each node
5. Build consensus activemask

**Returns:** Active nodes bitmask

#### checkall_vans_count

```c
int32_t checkall_vans_count(utime_data_t *U, int32_t havehashcounts[2], 
                             int32_t havevanscounts[2], uint64_t havehashmasks[2], 
                             uint64_t havevansmasks[2], uint64_t errmasks[2])
```

Checks VAN collection status across all nodes.

**Output Arrays (indexed by is_vip):**
- `havehashcounts`: Nodes with valid VAN hashes
- `havevanscounts`: Nodes with validated VANs
- `havehashmasks`: Bitmask of nodes with hashes
- `havevansmasks`: Bitmask of nodes with VANs
- `errmasks`: Bitmask of nodes with errors

**Returns:** 1 if all required nodes have data, 0 otherwise

#### check_nodesmasks

```c
int32_t check_nodesmasks(utime_data_t *U, uint64_t nodesmasks[2])
```

Verifies node masks match expected active nodes.

---

### Main Loops

#### utime_iter

```c
uint64_t utime_iter(global_reserve_t *GEN3, utime_data_t *U, int32_t fifoind)
```

Single iteration of the tock state machine.

**Structure:**
```c
while (1) {
    switch (U->ustate) {
        case USTATE_IDLE:
            // Check if time for new tock
            break;
        case USTATE_NEW_UTIME:
            U->ustate = ustate_new_utime(U);
            break;
        case USTATE_ADMIT_NORMAL:
            U->ustate = ustate_admit_normal(U);
            break;
        case USTATE_ADMIT_VIP_ONLY:
            U->ustate = ustate_admit_vip_only(U);
            break;
        case USTATE_WAITFOR_QUORUM:
            U->ustate = ustate_waitfor_quorum(U);
            break;
    }
}
```

#### fifoind_worker

```c
void *fifoind_worker(void *arg)
```

Worker thread for a specific FIFO index.

**Purpose:** Handles one slot in the circular buffer of tock data.

**Loop:**
1. Get or create utime data
2. Set initial state to `USTATE_ADMIT_NORMAL`
3. Continuously call `utime_iter()`
4. Sleep 5ms between iterations

#### valis_loop

```c
void *valis_loop(void *arg)
```

Main event loop for the generator.

**Responsibilities:**
1. Track current utime
2. Check for validator utime consensus
3. Consume vbond updates
4. Manage heartbeat timing
5. Coordinate with other subsystems

---

## Data Structures

### utime_data_t

Per-tock state container:

```c
typedef struct {
    uint32_t utime;                    // Current Unix timestamp
    uint32_t oldutime;                 // Previous completed tock
    uint32_t firstutime;               // First tock this session
    uint64_t ustate;                   // Current state machine state
    
    int32_t myid;                      // This node's ID
    uint8_t mypubkey[PKSIZE];          // This node's public key
    
    van_t active_vans[2];              // Active VANs [normal, vip]
    van_t coldvan;                     // Cold VAN for entropy
    
    int32_t myvancount;                // Normal VAN count
    int32_t myvipvancount;             // VIP VAN count
    
    global_reserve_t *GEN3;            // Global state pointer
    // ... more fields
} utime_data_t;
```

### nodevans_info_t

Per-node VAN tracking:

```c
typedef struct {
    uint8_t nodevanshashes[2][32];     // VAN hashes [normal, vip]
    int32_t final_numvans[2];          // Final VAN counts
    int32_t final_numtx[2];            // Final TX counts
    int32_t gotfinal_nodevanshash[2];  // Have final hash flags
    int32_t vans_validated[2];         // VANs validated flags
    unified_header_t *H[MAX_NODEVANS_PERUTIME];  // VAN headers
} nodevans_info_t;
```

---

## Timing Constants

```c
#define GEN3_NORMAL_TX_CUTOFF   // Milliseconds before tock for normal TX cutoff
#define GEN3_DEFAULT_AVERTT     // Default average round-trip time
#define VNET_FIFOSIZE           // Circular buffer size for tock data
```

---

## Anti-Geoclustering Concept

From the comments, a planned feature to prevent datacenter concentration:

1. **Measurement:** Nodes gossip signed ping times
2. **Graph:** Build network distance matrix
3. **Clustering:** Group nodes with <5ms latency
4. **Penalty:** Cap cluster's total voting power

**Rule:** "A Latency Cluster cannot control more than X% of the total Score."

---

## Dependencies

- `gen3.h` - Type definitions and constants
- `valis_messaging.h` - Network messaging
- SSD functions for persistence
- VAN validation functions

---

## Thread Model

```
Main Thread (valis_loop)
    ├── fifoind_worker[0] (handles tocks mod FIFOSIZE == 0)
    ├── fifoind_worker[1] (handles tocks mod FIFOSIZE == 1)
    └── ... (one worker per FIFO slot)
```

Each worker handles tocks that fall into its FIFO slot, allowing parallel processing of different tock phases.

---

## Security Considerations

1. **VAN Hash Timing:** Cold VANs broadcast after hash to prevent manipulation
2. **Active Node Consensus:** Nodes vote on who's active to prevent Sybil attacks
3. **Signature Verification:** All VANs must be properly signed
4. **Timeout Handling:** 30-second timeout for incomplete data
5. **Spam Limits:** Per-node VAN limits prevent resource exhaustion
