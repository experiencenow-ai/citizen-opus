# MM.c - Market Maker Dataflow

**Location:** `/root/valis/DF/MM.c`  
**Lines:** 994  
**Version:** v8.4 (ABI0-aligned)  
**Documented:** Wake 1301 (2026-01-13)

---

## Overview

MM.c implements a professional spot market maker execution engine for Tockchain. It provides automated two-sided quoting with:

- **Volatility-adjusted spreads** - Wider spreads in volatile conditions
- **Inventory skew** - Adjusts quotes to rebalance positions
- **Gamma hedging** - Optional perpetual futures hedging via pipe messages
- **Circuit breakers** - Halts quoting in extreme volatility

This is a **keeper-driven** dataflow - it executes only when triggered by `df_on_dataflowtx`, not on a schedule.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Keeper Transaction                       │
│         (Contains mmdf_wire_exec_t strategy params)          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      MM Dataflow                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐ │
│  │ Stale Check  │ │ Vol Signals  │ │ Quote Computation    │ │
│  │ validity_win │ │ onchain+ext  │ │ spread + skew        │ │
│  └──────────────┘ └──────────────┘ └──────────────────────┘ │
│                                                              │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐ │
│  │ Limit Orders │ │ Gamma Hedge  │ │ Pipe Messages        │ │
│  │ bid + ask    │ │ PERP target  │ │ to/from PERP DF      │ │
│  └──────────────┘ └──────────────┘ └──────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   UFC Limit Order Book                       │
│            (Receives bid/ask quotes)                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Compile-Time Configuration

The market maker requires two asset IDs defined at compile time:

```c
#ifndef MM_BASE_ASSET_ID
#error "MM_BASE_ASSET_ID must be defined as an assetid_t literal"
#endif

#ifndef MM_VUSD_ASSET_ID
#error "MM_VUSD_ASSET_ID must be defined as an assetid_t literal for VUSD coin"
#endif
```

---

## Constants

### Spread Parameters

| Constant | Value | Description |
|----------|-------|-------------|
| `MM_BASE_SPREAD_BPS` | 20 | Base spread: 0.20% |
| `MM_VOL_MULTIPLIER` | 1 | +1 bps spread per 1 bps volatility |
| `MM_MAX_SPREAD_BPS` | 2500 | Maximum spread: 25% |
| `MM_VOL_CIRCUIT_BREAKER_BPS` | 8000 | Halt at 80% volatility |

### Hedging Parameters

| Constant | Value | Description |
|----------|-------|-------------|
| `MM_HEDGE_REBALANCE_THRESHOLD_VUSD_SCALED` | 100 * SATOSHIS | 100 VUSD minimum rebalance |

### Pipe Message Types

| Constant | Value | Description |
|----------|-------|-------------|
| `MM_PIPEMSG_PERP_EXPOSURE_BASE` | 0x4D10 | Receive PERP exposure from PERP DF |
| `MM_PIPEMSG_HEDGE_TARGET_BASE` | 0x4D11 | Send hedge target to PERP DF |

---

## Opcodes

| Opcode | Value | Description |
|--------|-------|-------------|
| `MM_OP_EXECUTE` | 1 | Execute market making strategy |
| `MM_OP_CONFIG` | 2 | Update persistent configuration |
| `MM_OP_PULSE` | 3 | Gamma hedging pulse only |
| `MM_OP_EXIT` | 4 | Exit all positions |

---

## Persistent State Registers (S0-S7)

The MM uses 8 persistent registers for configuration and state:

| Register | Name | Description |
|----------|------|-------------|
| S0 | `MM_S_META` | Metadata/version |
| S1 | `MM_S_CAPITAL_HINT_VUSD` | Capital allocation hint |
| S2 | `MM_S_INVENTORY_BASE` | Tracked base inventory |
| S3 | `MM_S_LAST_CENTER_PRICE` | Last computed center price |
| S4 | `MM_S_VOL_THRESHOLD_LOW_BPS` | Low vol threshold for hedging |
| S5 | `MM_S_VOL_THRESHOLD_HIGH_BPS` | High vol threshold for hedging |
| S6 | `MM_S_HEDGE_RATIO_MIN_PCT` | Min hedge ratio % |
| S7 | `MM_S_HEDGE_RATIO_MAX_PCT` | Max hedge ratio % |

---

## Wire Formats

### mmdf_wire_exec_t (Execute Command)

```c
typedef struct mmdf_wire_exec_s {
    uint32_t validity_window;       // Blocks until stale
    uint32_t tx_ref_block;          // Reference block number
    int16_t alpha_prediction_bps;   // Price prediction adjustment
    uint16_t volatility_signal_bps; // External volatility signal
    int64_t price_barrier_hi;       // Upper price limit
    int64_t price_barrier_lo;       // Lower price limit
    uint8_t k_skew;                 // Inventory skew factor (0-255)
    uint8_t k_hedge;                // Hedge ratio override (0-200, 0=use S4-S7)
    uint8_t min_edge_bps;           // Minimum edge to quote (0-255)
    uint8_t exec_style;             // Execution style flags
} mmdf_wire_exec_t;
```

### Pipe Messages

```c
// Receive from PERP DF
typedef struct mmdf_pipe_perp_exposure_s {
    assetid_t base_asset;
    int64_t qty_base;
} mmdf_pipe_perp_exposure_t;

// Send to PERP DF
typedef struct mmdf_pipe_hedge_target_s {
    assetid_t base_asset;
    int64_t target_qty_base;
} mmdf_pipe_hedge_target_t;
```

---

## Core Functions

### mmdf_compute_quotes

**Purpose:** Compute bid and ask prices based on market conditions.

**Algorithm:**
1. Get mid price from oracle
2. Apply alpha prediction adjustment
3. Compute volatility from on-chain signals + external signal
4. Check circuit breaker (halt if vol ≥ 80%)
5. Calculate spread: `base_spread + vol * multiplier`
6. Compute inventory deviation from 50/50 target
7. Apply skew based on inventory imbalance
8. Generate final bid/ask prices

**Spread Formula:**
```
spread_bps = BASE_SPREAD + effective_vol * VOL_MULTIPLIER
spread_bps = clamp(spread_bps, 0, MAX_SPREAD)
half_spread = spread_bps / 2

bid_offset = -half_spread - skew_offset
ask_offset = +half_spread - skew_offset

bid_price = center_price * (1 + bid_offset/10000)
ask_price = center_price * (1 + ask_offset/10000)
```

### mmdf_get_onchain_vol_bps

**Purpose:** Aggregate on-chain volatility signals.

**Signals Combined:**
- `df_mean_rev_bps()` - Mean reversion signal
- `df_oracle_div_bps()` - Oracle divergence
- `df_premium_bps()` - Premium/discount to fair value
- `df_flow_bps()` - Order flow imbalance

Returns the maximum of all signals, clamped to [0, 100000] bps.

### mmdf_gamma_pulse

**Purpose:** Compute and emit gamma hedging target.

**Algorithm:**
1. Get current base inventory
2. Compute target hedge ratio based on volatility (interpolate between S6-S7 based on S4-S5 thresholds)
3. Calculate target hedge quantity: `target = -inventory * ratio / 100`
4. Read current PERP exposure from pipe
5. If delta exceeds threshold, emit hedge target message

### mmdf_handle_execute

**Purpose:** Main execution handler for MM_OP_EXECUTE.

**Flow:**
1. Parse wire format from userdata
2. Check staleness (reject if too old)
3. Get column indices for base and VUSD assets
4. Compute quotes
5. Apply price barriers
6. Emit limit orders to UFC
7. Optionally trigger gamma pulse

---

## Helper Functions

### Safe Arithmetic

| Function | Description |
|----------|-------------|
| `mmdf_abs_i64(x)` | Absolute value with INT64_MIN handling |
| `mmdf_clamp_i64(x, lo, hi)` | Clamp to range |
| `mmdf_saturating_add_i64(a, b)` | Add with saturation |
| `mmdf_muldiv_floor_pos(a, b, den)` | (a * b) / den, floor, positive only |
| `mmdf_muldiv_ceil_pos(a, b, den)` | (a * b) / den, ceiling, positive only |
| `mmdf_apply_bps_floor(price, bps)` | Apply basis point offset (floor) |
| `mmdf_apply_bps_ceil(price, bps)` | Apply basis point offset (ceiling) |

### 128-bit Arithmetic

Uses `__int128` for intermediate calculations to prevent overflow:

```c
__int128 t = (__int128)a * (__int128)b;
t /= (__int128)den;
```

---

## Integration with PERP DF

The MM can optionally integrate with a PERP (perpetual futures) dataflow for gamma hedging:

1. **Receiving Exposure:** MM reads `MM_PIPEMSG_PERP_EXPOSURE_BASE` messages from the pipe to know current PERP position
2. **Sending Targets:** MM emits `MM_PIPEMSG_HEDGE_TARGET_BASE` messages when rebalancing is needed
3. **Threshold:** Only rebalances when delta exceeds 100 VUSD equivalent

This allows the spot MM to hedge its inventory risk through perpetual futures.

---

## Safety Features

### Staleness Check
```c
rc = mmdf_check_stale(ctx, w.tx_ref_block, w.validity_window);
if (rc != 0) return -2;  // Reject stale transactions
```

### Circuit Breaker
```c
if (effective_vol_bps >= MM_VOL_CIRCUIT_BREAKER_BPS) {
    return -3;  // Halt quoting in extreme volatility
}
```

### Price Barriers
```c
// Clamp quotes to keeper-specified barriers
mmdf_clamp_pair_i64(&bid_price, &ask_price, 
                     w.price_barrier_lo, w.price_barrier_hi);
```

### Minimum Edge
```c
if (spread_bps < (int64_t)w.min_edge_bps) {
    return 1;  // Don't quote if edge too small
}
```

---

## Usage Pattern

A keeper transaction to execute market making:

```c
// Prepare execution parameters
mmdf_wire_exec_t exec = {
    .validity_window = 10,           // Valid for 10 blocks
    .tx_ref_block = current_block,
    .alpha_prediction_bps = 0,       // No directional view
    .volatility_signal_bps = 50,     // 0.5% external vol signal
    .price_barrier_hi = INT64_MAX,
    .price_barrier_lo = 0,
    .k_skew = 128,                   // Medium inventory skew
    .k_hedge = 0,                    // Use persistent config
    .min_edge_bps = 5,               // Minimum 5 bps edge
    .exec_style = 0
};

// Submit as dataflowtx with opcode MM_OP_EXECUTE
```

---

## Design Philosophy

1. **Keeper-Driven:** No autonomous execution - requires explicit triggers
2. **Stateless Strategy:** All strategy params in transaction, only safety config persisted
3. **Defensive Math:** Saturating arithmetic, 128-bit intermediates, explicit clamping
4. **Composable:** Pipe integration with PERP DF for hedging
5. **Fail-Safe:** Circuit breakers, staleness checks, minimum edge requirements

---

## Related Files

- `PERP.c` - Perpetual futures dataflow (receives hedge targets)
- `LOAN.c` - Lending dataflow
- `df_sdk.h` - Dataflow SDK definitions
- `df_helpers.h` - Helper macros and functions
