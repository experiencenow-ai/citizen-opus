# valis_tss.c Documentation

**File:** `tss/valis_tss.c`  
**Lines:** 225  
**Purpose:** High-level Threshold Signature Scheme (TSS) interface for Valis - manages async signing/keygen operations

---

## Overview

This file provides the top-level API for threshold cryptography operations in Valis. It wraps the complex MPC (Multi-Party Computation) protocols from `keygen.c` and `sig.c` into a clean async interface with:

- Thread pool management (max 8 concurrent operations)
- Progress tracking and callbacks
- Result structures for signatures and key shares
- Semaphore-based concurrency control

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Layer                         │
│            valis_tss_sign() / valis_tss_keygen()            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    valis_tss.c                               │
│  ┌─────────────────┐  ┌─────────────────┐                   │
│  │ Thread Pool     │  │ Results Struct  │                   │
│  │ (MAX_TSS_THREADS│  │ (status, sig,   │                   │
│  │  = 8)           │  │  pubkey, etc.)  │                   │
│  └─────────────────┘  └─────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              MPC Protocol Layer                              │
│  ┌─────────────────┐  ┌─────────────────┐                   │
│  │   keygen.c      │  │     sig.c       │                   │
│  │ (DKG protocol)  │  │ (TSS signing)   │                   │
│  └─────────────────┘  └─────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              Network Layer (nanomsg)                         │
│         Party-to-party communication                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Constants

```c
#define MAX_PARTIES 128           // Maximum parties in TSS scheme
#define MAX_PARTY_ID_LENGTH 64    // Max length for party identifiers
#define MAX_SIGN_KEY_SIZE 800000  // Max size for serialized key share
#define MAX_TSS_THREADS 8         // Global concurrent operation limit
```

---

## Data Structures

### valis_tss_results

The primary result structure for TSS operations:

```c
typedef struct {
    int32_t status;              // Operation status
    int32_t rounds_completed;    // MPC rounds completed
    int32_t msgs_sent;           // Network messages sent
    int32_t msgs_received;       // Network messages received
    time_t start_time;           // Operation start timestamp
    time_t end_time;             // Operation end timestamp
    int32_t recovery_id;         // ECDSA recovery ID (signing only)
    void (*callback)(...);       // Progress/completion callback
    void *user_data;             // User data for callback
    uint8_t pubkey[65];          // Group public key (uncompressed)
    char address[43];            // Ethereum address "0x..."
    int32_t signkey_len;         // Length of key share in flex_data
    uint8_t sig[64];             // Signature (r || s)
    uint8_t flex_data[];         // Flexible array for key share
} valis_tss_results;
```

**Status Values:**
| Value | Meaning |
|-------|---------|
| -3 | Busy (thread pool full) |
| -2 | Waiting |
| 0 | Initialized |
| 1 | Running |
| 2 | Done (success) |
| -1 | Error |

### valis_tss_thread_arg

Internal structure for thread arguments:

```c
typedef struct {
    uint8_t hash[32];            // Hash to sign (signing only)
    valis_tss_results *results;  // Pointer to results struct
    char address[43];            // Address for key lookup
    int32_t is_keygen;           // 1 = keygen, 0 = sign
    char workspace_id[64];       // Workspace ID (keygen only)
    int32_t t, n;                // Threshold and party count
} valis_tss_thread_arg;
```

---

## API Functions

### Query Result Sizes

```c
int32_t valis_tss_query_sizes(int32_t num_parties, 
                              int32_t *sign_results_total_size, 
                              int32_t *keygen_results_total_size);
```

**Purpose:** Calculate required allocation sizes for result structures.

**Parameters:**
- `num_parties`: Number of parties in TSS scheme
- `sign_results_total_size`: Output - bytes needed for signing results
- `keygen_results_total_size`: Output - bytes needed for keygen results

**Size Calculation:**
```c
t = num_parties / 2;  // Threshold
max_signkey = 8192 + num_parties * t * 128;  // Conservative estimate
sign_size = sizeof(valis_tss_results);       // No flex_data needed
keygen_size = sizeof(valis_tss_results) + max_signkey;
```

**Returns:** 0 on success, -1 if num_parties invalid

### Sign Operation

```c
int32_t valis_tss_sign(const char *address, 
                       const uint8_t hash[32], 
                       valis_tss_results *results);
```

**Purpose:** Initiate async threshold signing operation.

**Parameters:**
- `address`: Ethereum address identifying the key share to use
- `hash`: 32-byte message hash to sign
- `results`: Pre-allocated results structure

**Returns:**
- `0`: Operation started successfully
- `-3`: Thread pool busy
- `-1`: Other error

**Behavior:**
1. Acquires semaphore slot (non-blocking)
2. Spawns thread running `tss_thread_main`
3. Returns immediately (async)
4. Callback invoked on completion/error

### Keygen Operation

```c
int32_t valis_tss_keygen(const char *workspace_id,
                         int32_t threshold,
                         int32_t num_parties,
                         valis_tss_results *results);
```

**Purpose:** Initiate async distributed key generation.

**Parameters:**
- `workspace_id`: Unique identifier for this keygen session
- `threshold`: Minimum parties needed to sign (t)
- `num_parties`: Total parties in scheme (n)
- `results`: Pre-allocated results structure (with flex_data space)

**Returns:** Same as `valis_tss_sign`

**Output (on success):**
- `results->pubkey`: 65-byte uncompressed public key
- `results->address`: Derived Ethereum address
- `results->flex_data`: Binary key share
- `results->signkey_len`: Length of key share

---

## Internal Functions

### Semaphore Management

```c
static int32_t tss_init_sem(void);
```

**Purpose:** Initialize global semaphore for thread pool.

**Implementation:**
```c
global_sem = sem_open("/valis_tss_sem", O_CREAT, 0660, MAX_TSS_THREADS);
```

Uses named POSIX semaphore for cross-process coordination.

### Base64 Decoding

```c
int32_t base64_to_bin(const char *base64, int32_t base64_len, 
                      uint8_t *bin, int32_t max_bin_len);
```

**Purpose:** Decode base64-encoded key shares to binary.

**Use Case:** MPC library returns keys in base64; storage uses binary.

### Thread Main

```c
static void *tss_thread_main(void *arg);
```

**Purpose:** Main thread function for TSS operations.

**Flow:**
1. Initialize results (status=0, timestamps, counters)
2. Branch on `is_keygen`:
   - Keygen: Call `run_single_party_keygen()`
   - Sign: Call `run_single_party_signing()`
3. On success: status=2, invoke callback
4. On error: status=-1, invoke callback
5. Free thread arg, return

---

## Concurrency Model

```
┌─────────────────────────────────────────────────────────────┐
│                    Semaphore Pool                            │
│                  (MAX_TSS_THREADS = 8)                       │
├─────────────────────────────────────────────────────────────┤
│  Slot 1: [keygen]  │  Slot 5: [idle]                        │
│  Slot 2: [sign]    │  Slot 6: [idle]                        │
│  Slot 3: [sign]    │  Slot 7: [idle]                        │
│  Slot 4: [idle]    │  Slot 8: [idle]                        │
└─────────────────────────────────────────────────────────────┘
```

**Behavior:**
- `sem_trywait()`: Non-blocking acquire (returns -3 if full)
- `sem_post()`: Release slot on completion
- Named semaphore persists across process restarts

---

## Key Storage

Key shares are stored as binary files:

```c
// Filename format
snprintf(filename, sizeof(filename), "%s_%s.bin", results->address, env->my_id);

// Write key share
FILE *fp = fopen(filename, "wb");
fwrite(results->flex_data, 1, bin_len, fp);
fclose(fp);
```

**Example:** `0x1234...abcd_party1.bin`

---

## Integration with MPC Layer

### keygen.c Integration

The keygen operation calls into `keygen.c` which implements:
- GG20 distributed key generation protocol
- Multi-round message exchange
- Feldman VSS for secret sharing

### sig.c Integration

The signing operation calls into `sig.c` which implements:
- GG20 threshold signing protocol
- Pre-signing and signing phases
- ECDSA signature reconstruction

Both are modified to accept a `results` parameter for progress updates:
```c
// In MPC round loop:
results->rounds_completed = round + 1;
results->msgs_received += recv_count;
results->msgs_sent += sent_count;
```

---

## Callback Pattern

```c
// Define callback
void my_callback(valis_tss_results *results, void *user_data) {
    if (results->status == 2) {
        printf("Signature: ");
        for (int i = 0; i < 64; i++) printf("%02x", results->sig[i]);
        printf("\n");
    } else if (results->status == -1) {
        printf("Error occurred\n");
    }
}

// Set up results
valis_tss_results *results = malloc(sizeof(valis_tss_results));
results->callback = my_callback;
results->user_data = my_context;

// Start operation
valis_tss_sign("0x...", hash, results);
```

---

## Error Handling

| Error | Cause | Recovery |
|-------|-------|----------|
| -3 (busy) | Thread pool full | Retry later |
| -1 (error) | MPC protocol failure | Check logs, retry |
| Timeout | Network issues | Increase timeout, retry |

---

## Dependencies

- `wrapper.h`: MPC library wrapper types
- `keygen.c`: DKG implementation
- `sig.c`: TSS signing implementation
- `libethc.h`: Ethereum utilities (keccak, hex conversion)
- `pthread.h`: Threading
- `semaphore.h`: Concurrency control

---

## Security Considerations

1. **Key Share Protection:** Binary key shares contain sensitive material; should be encrypted at rest in production.

2. **Semaphore Naming:** Named semaphore `/valis_tss_sem` is system-wide; ensure unique naming in multi-tenant environments.

3. **Memory Cleanup:** Thread args are freed after operation; results struct is caller's responsibility.

4. **Recovery ID:** The `recovery_id` enables public key recovery from signature, important for Ethereum transaction verification.

---

*Documentation generated by Opus, Wake 1321*
