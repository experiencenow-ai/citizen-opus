# _valis.h - Master Header File

## Overview
**Location:** `/root/valis/_valis.h`  
**Lines:** 646  
**Purpose:** Central header file defining all core constants, data structures, and function prototypes for the entire Tockchain/Valis system.

## Role in Architecture
This is the **master include file** - virtually every source file in the codebase includes `_valis.h`. It establishes:
1. System-wide constants and limits
2. Core data structure definitions
3. Network protocol structures
4. Function prototypes for cross-module APIs

## System Dependencies
```c
// Standard C libraries
#include <stdio.h>, <stdlib.h>, <string.h>, <stdint.h>, <time.h>
#include <pthread.h>, <stdatomic.h>  // Threading
#include <gmp.h>                      // Arbitrary precision math
#include <omp.h>                      // OpenMP parallelism
#include <immintrin.h>                // SIMD intrinsics

// Third-party
#include "uthash.h"                   // Hash table macros
#include "utlist.h"                   // Linked list macros
#include <nng/nng.h>                  // Nanomsg-next-gen networking
```

## Key Constants

### Cryptographic Sizes
| Constant | Value | Purpose |
|----------|-------|---------|
| `PKSIZE` | 20 | Public key/address size (Ethereum-compatible) |
| `FALCONSIZE` | 667 | Post-quantum Falcon signature size |
| `SATOSHIS` | 100,000,000 | Base unit (8 decimal places) |

### Withdrawal System
| Constant | Value | Purpose |
|----------|-------|---------|
| `WITHDRAW_EPOCH_SECS` | 12 | Withdrawal epoch duration |
| `WITHDRAW_MAX_SIGNERS` | 100 | Maximum signers per withdrawal |
| `WITHDRAW_SIGQ_CAP` | 4096 | Signature queue capacity |
| `WITHDRAW_PENDING_EPOCHS` | 256 | Pending epochs buffer |

### Bridge/Ethereum
| Constant | Value | Purpose |
|----------|-------|---------|
| `ETHFINALITY_BLOCKS` | 64 | Blocks before Ethereum finality |
| `MAX_ERC20` | 1000 | Maximum tracked ERC20 tokens |
| `MAX_BATCH_LEAVES` | 64 | Merkle batch size |
| `WETH_CONTRACT` | "0xC02aaA..." | Wrapped ETH address |

### Network/Consensus
| Constant | Value | Purpose |
|----------|-------|---------|
| `MAX_VALIDATORS` | 64 | Maximum validator nodes |
| `MAX_THREADS` | 16 | Thread pool limit |
| `VNET_FIFOSIZE` | 60 | Network FIFO buffer size |
| `MAX_PACKETLEN` | (defined elsewhere) | Maximum packet size |

### Transaction Processing
| Constant | Value | Purpose |
|----------|-------|---------|
| `TXIND_BITS` | 20 | Transaction index bits (~1M txs) |
| `TXOFFSET_BITS` | 28 | Transaction offset bits |
| `SLAB_SIZE` | 64MB | Memory slab allocation |
| `MAX_TX_PER_UTIME` | SLAB_SIZE/80 | ~838K transactions per second |

### Economic Parameters
| Constant | Value | Purpose |
|----------|-------|---------|
| `HALVING_TIME` | 4 years | Reward halving schedule |
| `COINBASE_REWARD` | 1 SATOSHI | Block reward |
| `VIP_TXFEE` | 0.1 SATOSHI | VIP transaction fee |
| `_MINPOOL_VUSD` | 50,000 VUSD | Minimum pool liquidity |

### Virtual Application IDs (VAPPs)
```c
#define VAPPID_VALIS        0   // Core protocol
#define VAPPID_VIP_VANS     1   // VIP transactions
#define VAPPID_NORMAL_VANS  2   // Normal transactions
#define VAPPID_UTIMED       3   // Time-locked transactions
#define VAPPID_BRIDGE       4   // Bridge operations
```

### Peer Sets
```c
#define PEERSET_GENERATOR 0   // Block generators
#define PEERSET_VALIDATOR 1   // Validators
#define PEERSET_BRIDGE    1   // Bridge nodes (same as validator)
```

## Core Data Structures

### Transaction ID (`tockid_t`)
```c
typedef struct {
    uint32_t utime;           // Unix timestamp
    uint64_t txoffset:28;     // Offset in block
    uint64_t reserved:4;
    uint64_t txind:20;        // Transaction index
    uint64_t reserved2:4;
    uint64_t shard:8;         // Shard number
} tockid_t;
```

### Peer Information (`peer_info_t`)
```c
typedef struct peer_info_s {
    uint8_t pubkey[PKSIZE];   // 20-byte public key
    uint32_t ipbits;          // IP address as 32-bit
    uint16_t port;            // TCP base port
    uint16_t candidate;       // Candidate status
} peer_info_t;
```

### Validator Set (`validators_t`)
```c
typedef struct validators_s {
    uint8_t prevhash[32];                    // Previous block hash
    uint64_t voterbits, candidatebits;       // Bitmaps
    uint32_t genesis_utime, extra32;
    int32_t activation_minute, prev_activation_minute, stxind;
    uint8_t shard, num, quorum, extra8;
    peer_info_t validators[MAX_VALIDATORS];  // Validator array
} validators_t;
```

### Network Packet Header (`unified_header_t`)
```c
typedef struct unified_header_s {
    uint8_t sig[FALCONSIZE];      // 667-byte Falcon signature
    uint8_t addedsig:1;           // Additional signature flag
    uint8_t ext_type:3;           // Extension type
    uint8_t peerset:3;            // Peer set ID
    uint8_t falcon:1;             // Falcon signature present
    uint8_t pubkey[PKSIZE];       // Sender public key
    uint32_t packetlen;           // Payload length
    uint32_t utime, genesis_utime;
    uint8_t shard, msg, senderid;
    uint8_t srcvapp:4, destvapp:4;  // Source/dest VAPP
} unified_header_t;
```

### Network Context (`vnet_context_t`)
```c
typedef struct vnet_context_s {
    pthread_mutex_t VMSG_TAB_MTX;
    pthread_mutex_t servers_mutex, sub_mutex;
    struct vnet_queue_slot vapp_slots[NUM_PEERSETS][NUM_VAPPID][VNET_FIFOSIZE];
    struct vnet_server_info servers[MAX_VALIDATORS + 16];
    struct vmsg_sock VMSG_TAB[VMSG_MAX_SOCKETS];
    int64_t lastrecv[0x100];
    global_reserve_t *GEN3;       // Generator context
    uint32_t genesis_utime;
    int32_t pub_sock, sub_sock, pull_sock, ipc_sock;
    uint8_t pullbuf[MAX_PACKETLEN*2];
    uint8_t subbuf[MAX_PACKETLEN*2];
    uint8_t ipcbuf[MAX_PACKETLEN*2];
    uint8_t mypubkey[PKSIZE], testprivkey[32];
} vnet_context_t;
```

### Wallet Structure (`wallet_info`)
```c
struct wallet_info {
    struct seedinfo trading;                    // Main trading key
    struct seedinfo derived[NUMDERIVEDADDRS];   // Derived addresses
    uint8_t passhash[32], privkey[32];
    char fname[512];                            // Wallet filename
};
```

### Merkle Proof Structures
```c
typedef struct merkle_data_s {
    struct hash256 *tree, built_root;
    int32_t leaf_count, maxnum, is_built, is_sorted;
} merkle_data_t;

typedef struct merkle_path_s {
    struct hash256 siblings[TXIND_BITS];  // 20 siblings max
    uint8_t txid[32], pathmerkle[32];
    int32_t capacity, length, leaf_index, proven, leaf_count;
} merkle_path_t;
```

## Function Prototypes

### Cryptographic Functions
```c
int32_t valis_verify(uint8_t pubkey[PKSIZE], uint8_t hash[32], uint8_t sig[65]);
int32_t valis_sign(uint8_t privkey[32], uint8_t digest[32], uint8_t sig[65]);
int32_t valis_hash(uint8_t *buf, int32_t len, uint8_t hash[32]);
int32_t pubkey2addr(uint8_t pubkey[PKSIZE], char *addr);
int32_t addr2pubkey(char *addr, uint8_t addr20[PKSIZE]);
void priv2addr20(uint8_t privkey[32], uint8_t addr20[20]);
```

### File System Functions
```c
char *BASEDIR_str(void);
void rawtock_fname(char fname[512], uint32_t utime);
void tock_fname(char fname[512], uint32_t utime, char *suffix);
void ensure_hourly_dir(uint32_t hour);
void makedirs(char *basedir, int32_t hour, int32_t initflag);
```

### Merkle Tree Functions
```c
void merkle_data_init(merkle_data_t *M, struct hash256 *leaves, int32_t leaf_count, int32_t maxnum);
int merkle_build_membership_proof(merkle_data_t *M, int32_t leaf_index, merkle_path_t *out_path);
int32_t merkle_recompute_root_from_path(uint8_t txid[32], merkle_path_t *path, int32_t leaf_count, uint8_t pathmerkle[32]);
```

### Utility Functions
```c
char *dstr(int64_t);   // Decimal string conversion (9 variants for thread safety)
void devurandom(uint8_t *buf, long len);
int is_valid_ETHprivkey(uint8_t privkey[32]);
uint32_t ipstr2ipbits(char *ipstr);
char *ipbits2ipstr(uint32_t ipbits, char *ipstr);
```

## Global Variables

### Time Tracking
```c
extern volatile uint32_t _UTIME_NOW;                    // Current Unix time
extern _Atomic(int64_t) _MILLI64_TIME_NOW;              // Milliseconds
extern _Atomic(int64_t) _MICRO64_TIME_NOW;              // Microseconds

// Access macros
#define VALIS_UTIME_NOW()   _UTIME_NOW
#define VALIS_MILLI_NOW()   atomic_load(&_MILLI64_TIME_NOW)
#define VALIS_MICRO_NOW()   ((int32_t)atomic_load(&_MICRO64_TIME_NOW))
```

### Block Heights
```c
extern volatile uint32_t L0tock;  // Layer 0 block height
extern volatile uint32_t L1tock;  // Layer 1 block height
```

## Design Notes

### Pragma Pack
```c
#pragma pack(1)
```
All structures after this directive are byte-packed for wire protocol compatibility. This ensures consistent serialization across platforms.

### Bit Fields
Many structures use bit fields for compact representation:
- `tockid_t` packs timestamp + offset + index + shard into 16 bytes
- `unified_header_t` uses bit fields for flags

### Thread Safety
- Multiple `pthread_mutex_t` fields in context structures
- Atomic types for time variables
- Multiple `dstr()` variants to avoid buffer conflicts

## Integration Points

### Included By
Every `.c` file in the project includes `_valis.h` either directly or through other headers.

### Includes
- `uthash.h` - Hash table implementation
- `utlist.h` - Linked list macros
- `nng/*.h` - Nanomsg networking

### Related Headers
- `frama_verified.h` - Formally verified functions
- `gen3.h` - Generator-specific definitions
- `validator.h` - Validator-specific definitions
- `dataflow.h` - Dataflow engine definitions

## Version History
- Uses Falcon post-quantum signatures (667 bytes)
- Supports up to 64 validators
- 20-byte addresses (Ethereum-compatible)
- 4-year halving schedule

---
*Documentation generated by Opus, Wake 1315*
