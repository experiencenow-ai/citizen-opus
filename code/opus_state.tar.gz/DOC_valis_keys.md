# valis_keys.c Documentation

**File:** `/root/valis/utils/valis_keys.c`  
**Lines:** 734  
**Purpose:** Cryptographic key management, Ethereum address handling, digital signatures, and wallet operations  
**Dependencies:** `_valis.h`, `secp256k1_recovery.h`, `validator.h`  
**Documented by:** Opus (Wake 1284)

---

## Overview

This file is the cryptographic backbone of Tockchain, handling:
1. **Ethereum address validation and checksumming** (EIP-55)
2. **secp256k1 key operations** (private→public→address derivation)
3. **Digital signatures** (signing and verification with recovery)
4. **Wallet management** (encrypted storage, seed generation)
5. **Transaction signature validation** (multi-context verification)

---

## Function Reference

### 1. Private Key Validation

#### `is_valid_ETHprivkey(uint8_t privkey[32])`
Validates that a 32-byte private key is within the valid range for secp256k1.

**Validation Rules:**
- Must not be zero (all bytes 0x00)
- Must be less than the curve order `n`:
  ```
  n = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
  ```

**Returns:** `1` if valid, `0` if invalid

**Security Note:** This prevents weak keys that could compromise signatures.

---

### 2. Hex String Utilities

#### `eth_is_hex(const char *str, int32_t len)`
Validates that a string contains only hexadecimal characters.

**Parameters:**
- `str`: Input string (may include "0x" prefix)
- `len`: Length to check (-1 for auto-detect via strlen)

**Returns:**
- `1`: Valid hex string
- `0`: Invalid characters found
- `-1`: NULL or empty input

---

### 3. Ethereum Address Handling (EIP-55 Checksums)

#### `eth_is_checksum_address(char *addr)`
Verifies that an Ethereum address has valid EIP-55 checksum capitalization.

**Algorithm:**
1. Convert address to lowercase
2. Keccak256 hash the lowercase address
3. For each character position:
   - If hash nibble ≥ 8: character should be uppercase
   - If hash nibble < 8: character should be lowercase

**Returns:**
- `1`: Valid checksum
- `0`: Invalid checksum
- `-1`: NULL input
- `-2`: Invalid hex
- `-3`: Hash failed

#### `eth_to_checksum_address(char *addr)`
Converts an Ethereum address to EIP-55 checksummed format (in-place).

**Returns:** Same error codes as `eth_is_checksum_address`

---

### 4. Key Derivation

#### `bigpub2addr20(const uint8_t *pubkey, int pubkey_len, uint8_t addr20[20])`
Derives a 20-byte Ethereum address from a public key.

**Process:**
1. If 65-byte uncompressed key (0x04 prefix), strip prefix
2. Keccak256 hash the 64-byte public key
3. Take last 20 bytes of hash as address

**Returns:** `0` on success, `-1` on invalid input

#### `priv2pub64(uint8_t privkey[32], uint8_t pubkey[64])`
Derives 64-byte uncompressed public key from private key using secp256k1.

**Returns:**
- `0`: Success
- `-1`: NULL input
- `-2`: Context creation failed
- `-3`: Key derivation failed

#### `priv2addr20(uint8_t privkey[32], uint8_t addr20[20])`
Convenience function: private key → address in one call.

---

### 5. Digital Signatures

#### `valis_sign(uint8_t privkey[32], uint8_t digest[32], uint8_t sig[65])`
Creates a recoverable ECDSA signature over a 32-byte digest.

**Output Format:**
- Bytes 0-31: `r` component
- Bytes 32-63: `s` component  
- Byte 64: Recovery ID (0-3)

**Returns:**
- `0`: Success
- `-1`: NULL input
- `-2`: Context creation failed
- `-3`: Signing failed
- `-4`: Serialization failed

#### `verify_secp256k1_hexsig(const char *pubkey_hex, const char *msg_hash_hex, const char *r_hex, const char *s_hex)`
Verifies an ECDSA signature given hex-encoded components.

**Parameters:**
- `pubkey_hex`: 65-byte uncompressed public key in hex
- `msg_hash_hex`: 32-byte message hash in hex
- `r_hex`, `s_hex`: Signature components in hex

**Returns:** `1` if valid, `0` if invalid

#### `valis_verify(uint8_t pubkey[64], uint8_t digest[32], uint8_t sig[65])`
Verifies a recoverable signature (implementation in cryptolibs).

---

### 6. Wallet Management

#### `struct wallet_info`
```c
struct wallet_info {
    uint8_t privkey[32];      // XOR-encrypted with passhash
    uint8_t passhash[32];     // Hash of password
    char fname[256];          // Wallet file path
    struct {
        char addr[43];        // "0x" + 40 hex chars
    } trading;
    // ... derived addresses
};
```

#### `walletscrub(struct wallet_info *wallet)`
Securely zeroes wallet memory to prevent key leakage.

#### `wallet_restore(struct wallet_info *wallet, int32_t silentflag)`
Restores wallet from encrypted file.

**Process:**
1. Read XOR-encrypted private key from file
2. XOR with password hash to decrypt
3. Derive addresses

#### `walletseed_init(struct wallet_info *wallet, char *password, int32_t silentflag)`
Initializes a new wallet or loads existing one.

**First-time Setup:**
1. Hash password to create filename and encryption key
2. Prompt for existing private key or generate random
3. XOR-encrypt and save to file

**Security Features:**
- Password is scrubbed after hashing
- Private key displayed only once on generation
- File stored in `subseeds/` directory

#### `randseed(uint8_t privkey[32])`
Generates cryptographically secure random 32 bytes from `/dev/urandom`.

---

### 7. Transaction Signature Validation

#### Signature Contexts (`sigctx_t`)
```c
typedef enum {
    SIGCTX_NONE,              // No signature required
    SIGCTX_TX_SRC,            // Standard transaction source
    SIGCTX_TX_DATAFLOW_SRC,   // DataFlow transaction
    SIGCTX_TX_POOL_SRC,       // Pool transaction
    SIGCTX_TX_ORDER_MAKER,    // Order maker signature
    SIGCTX_TX_ORDER_TAKER,    // Order taker signature
    SIGCTX_MULTISIG_TX,       // M-of-N multisig
    SIGCTX_BRIDGE_MINT_MSIG,  // Bridge mint with validator sigs
    SIGCTX_VALIDATOR_BUNDLE,  // Validator consensus signatures
} sigctx_t;
```

#### `valis_get_pub_for_ctx(sigctx_t ctx, const struct txheader *txH)`
Returns the public key that should have signed a transaction based on context.

#### `sig_validate(struct valisL1_info *L1, sigctx_t ctx, const void *ctx_ptr, void *unused)`
Master signature validation function handling all contexts.

**Multisig Validation (`SIGCTX_MULTISIG_TX`):**
1. Verify M-of-N threshold is valid
2. Check each signature against corresponding public key
3. Track which keys have signed (prevent double-counting)

**Bridge Mint Validation (`SIGCTX_BRIDGE_MINT_MSIG`):**
1. Look up asset's required signers from L1 state
2. Verify each validator signature
3. Check minimum signature threshold

**Validator Bundle (`SIGCTX_VALIDATOR_BUNDLE`):**
1. Iterate through validator signatures
2. Verify each against known validator public keys
3. Count valid signatures against minimum threshold

#### `eval_txsig(struct valisL1_info *L1, uint32_t utime, struct txheader *txH, ...)`
Evaluates transaction signature for block validation.

**Handler-Specific Context Selection:**
| Handler | Signature Context |
|---------|-------------------|
| `HANDLER_DATAFLOW` | `SIGCTX_TX_DATAFLOW_SRC` |
| `HANDLER_POOL` | `SIGCTX_TX_POOL_SRC` |
| `HANDLER_ORDERBOOK` (maker) | `SIGCTX_TX_ORDER_MAKER` |
| `HANDLER_ORDERBOOK` (taker) | `SIGCTX_TX_ORDER_TAKER` |
| `HANDLER_HASHLOCK` | `SIGCTX_NONE` |
| `HANDLER_MULTISIG` | `SIGCTX_NONE` |
| `HANDLER_SYSTEM` | `SIGCTX_NONE` |
| Default | `SIGCTX_TX_SRC` |

**Pylon Integration:**
- Checks if address has pylon restrictions
- Delegates to `pylon_eval_txsig()` for pylon-enabled accounts

---

## Security Considerations

### Key Material Handling
- Private keys XOR-encrypted at rest with password hash
- `memscrub()` used to zero sensitive data after use
- Random seeds from `/dev/urandom`

### Signature Validation
- Recovery ID prevents signature malleability
- Multisig prevents double-counting of signatures
- Validator signatures tied to known public keys

### Address Validation
- EIP-55 checksums detect typos in addresses
- Private key range validation prevents weak keys

---

## Dependencies

| External | Purpose |
|----------|---------|
| `secp256k1` | Elliptic curve operations |
| `secp256k1_recovery` | Recoverable signatures |
| `eth_keccak256()` | Ethereum hashing (from valis_hash.c) |
| `valis_hash()` | Internal hashing |
| `/dev/urandom` | Secure random generation |

---

## Integration Points

- **bridge/**: Uses for Ethereum address validation and bridge signatures
- **validator/**: Uses for transaction signature verification
- **generator/**: Uses for block signing
- **UFC/**: Uses for order signatures

---

## Example Usage

```c
// Generate new keypair
uint8_t privkey[32], pubkey[64], addr[20];
randseed(privkey);
if (is_valid_ETHprivkey(privkey)) {
    priv2pub64(privkey, pubkey);
    bigpub2addr20(pubkey, 64, addr);
}

// Sign a message
uint8_t digest[32], sig[65];
eth_keccak256(digest, message, msglen);
valis_sign(privkey, digest, sig);

// Verify signature
if (valis_verify(pubkey, digest, sig) > 0) {
    // Signature valid
}
```

---

*Documentation generated Wake 1284 | Opus*
