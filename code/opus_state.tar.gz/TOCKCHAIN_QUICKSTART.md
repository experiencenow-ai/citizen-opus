# Tockchain Developer Quickstart

A practical guide for developers new to the Tockchain codebase.
Created: Wake 1324

---

## What is Tockchain?

Tockchain is a **Layer-1 blockchain** designed for:
- **125,000+ TPS** sustained (1M+ burst)
- **Sub-5-second finality**
- **Zero protocol fees**
- **Formally verified** core operations

Key differentiators:
1. **Leaderless quorum consensus** - no mining, no staking
2. **UFC DEX** - impermanent loss < 0.1% annually
3. **Trust-minimized bridge** - MPT proofs for deposits, TSS for withdrawals
4. **Mathematical security** - 650+ Coq proofs, Frama-C verified

---

## Repository Structure

```
/valis/
├── bridge/          # Ethereum bridge (deposit, withdraw, RLP, MPT)
├── coq/             # Formal proofs (~650 theorems)
├── cryptolibs/      # Crypto primitives
├── DF/              # Dataflow engine (eBPF-based)
├── generator/       # Consensus layer (gen3)
├── netlibs/         # Network utilities
├── specs/           # Specifications and design docs
├── tests/           # Unit tests (~30 files)
├── tss/             # Threshold signatures
├── ubpf/            # eBPF virtual machine
├── UFC/             # DEX implementation
├── utils/           # Shared utilities
├── validator/       # Ledger and transaction processing
├── _valis.h         # Master header
├── frama_verified.c # Formally verified core
└── Opus/docs/       # Documentation (90+ files)
```

---

## Core Concepts

### 1. Tocks (Blocks)
- One "tock" per second (utime = Unix timestamp)
- Contains aggregated transactions
- Deterministically ordered
- No reorganizations after finality

### 2. Consensus
- **Broadcast-first**: transactions propagate immediately
- **Leaderless quorum**: no single leader election
- **VAN aggregation**: nodes bundle transactions
- **Vote on hashes**: consensus on state, not leader

### 3. Assets
- **VNET**: Network token (1 per tock emission, halves every 4 years)
- **VUSD**: Stablecoin (backed by external yield)
- **VBOND**: Node quality/reputation token
- **Wrapped assets**: ETH, USDC, etc. via bridge

### 4. UFC (DEX)
- **Fair Curve**: minimizes impermanent loss
- **In-bounds**: 0% fee trades
- **Out-of-bounds (OOB)**: premium trades when price moves fast
- **LP yields**: ~1% from OOB premiums + VNET rewards

---

## Key Files to Understand First

### Headers (start here)
1. `_valis.h` - Master header with all types and constants
2. `gen3.h` - Generator/consensus structures
3. `validator.h` / `ledger.h` - Ledger state structures
4. `ufc.h` - DEX structures

### Core Implementation
1. `gen3.c` - Main consensus loop
2. `validator.c` - Transaction processing
3. `ufc.c` - DEX operations
4. `bridge_deposit.c` / `bridge_withdraw.c` - Bridge flows

### Formal Verification
1. `frama_verified.c` - Frama-C annotated core
2. `/coq/` - Coq proofs (start with README)

---

## Building

```bash
# From /valis/ directory
make test      # Build test harness
make wsdprog   # Build websocket daemon
make txblast   # Build transaction generator
make sendtx    # Build transaction sender
```

Dependencies:
- pthread, atomic, gmp
- nng (nanomsg-next-gen)
- secp256k1
- curl
- libubpf.a

---

## Running Tests

```bash
# Unit tests
./test

# Specific test suites
./test --bridge
./test --ufc
./test --dataflow
```

Test files in `/tests/`:
- `units_*.c` - Unit tests per module
- `bridgetests.c` - Bridge integration tests
- `ufc_test.c` - DEX tests
- `vbpf_test.c` - eBPF VM tests

---

## Documentation Index

All documentation in `/valis/Opus/docs/`:

### Getting Started
| Doc | Purpose |
|-----|---------|
| TOCKCHAIN_QUICKSTART.md | This file |
| TOCKCHAIN_ARCHITECTURE.md | System overview |
| TOCKCHAIN_DIAGRAMS.md | Visual architecture |
| TOCKCHAIN_DOC_PLAN.md | Documentation status |

### By Module
| Module | Key Docs |
|--------|----------|
| Bridge | DOC_bridge_*.md (15 files) |
| Dataflow | DOC_dataflow_*.md (14 files) |
| Generator | DOC_gen3_*.md (12 files) |
| Validator | DOC_validator*.md, DOC_ledger_*.md (11 files) |
| UFC | DOC_ufc_*.md (9 files) |
| TSS | DOC_tss_*.md (5 files) |

### Specifications
| Doc | Purpose |
|-----|---------|
| DOC_pylon_spec.md | Post-quantum security |
| DOC_coq_proofs.md | Formal verification overview |
| DOC_df_developer_guide.md | Dataflow programming |

---

## Common Tasks

### Adding a new transaction type
1. Define handler in `ledger_vhandlers.c`
2. Add to switch in `validator.c`
3. Write unit tests in `tests/units_tx.c`
4. Update documentation

### Adding a new UFC pool
1. Configure in `ufc_pool.c`
2. Set parameters in `ufc.h`
3. Test with `ufc_test.c`

### Modifying bridge logic
1. Update `bridge_deposit.c` or `bridge_withdraw.c`
2. Verify MPT proofs still work
3. Test with `bridgetests.c`

---

## Architecture Patterns

### Determinism
All operations must be deterministic:
- No floating point
- No random numbers
- No external time (only utime)
- Same input → same output always

### Error Handling
```c
// Pattern: return negative on error
int32_t result = operation();
if (result < 0) {
    // Handle error
    return result;
}
```

### Memory Management
- Mostly stack-allocated
- Large structures in L1 state
- No malloc in hot paths

### Logging
```c
// Use VLOG macros
VLOG(1, "Info message");
VLOG(2, "Debug message");
VLOG(3, "Trace message");
```

---

## Getting Help

1. **Documentation**: `/valis/Opus/docs/` (90+ files)
2. **Specs**: `/valis/specs/` (original design docs)
3. **Code comments**: Most functions have inline docs
4. **Tests**: Often the best examples of usage

---

## Next Steps

1. Read `TOCKCHAIN_ARCHITECTURE.md` for system overview
2. Browse `TOCKCHAIN_DIAGRAMS.md` for visual understanding
3. Pick a module and read its DOC_*.md files
4. Run tests to see the code in action
5. Start with small changes and work up

---

*Created by Opus, Wake 1324*
*Part of Tockchain Documentation Project*
