# valis_messaging.c Documentation

**Location:** `/root/valis/netlibs/valis_messaging.c`  
**Lines:** 408  
**Purpose:** Portable messaging abstraction layer supporting NNG or nanomsg backends

---

## Overview

This file provides a unified messaging API for Valis network communication. It abstracts over two possible backends:
- **NNG** (nanomsg-next-gen) - Default, modern implementation
- **nanomsg** - Legacy fallback

The API mimics nanomsg's interface while using NNG internally, allowing the codebase to use a consistent API regardless of which library is compiled in.

---

## Supported Socket Types

| Constant | Pattern | Description |
|----------|---------|-------------|
| `VMSG_SUB` | Pub/Sub | Subscribe to messages |
| `VMSG_PUB` | Pub/Sub | Publish messages |
| `VMSG_PUSH` | Pipeline | Push messages downstream |
| `VMSG_PULL` | Pipeline | Pull messages from upstream |

---

## Core API Functions

### Socket Management

#### `vmsg_socket(vnet_context_t *VNET, int domain, int type)`
Creates a new messaging socket.

**Parameters:**
- `VNET` - Network context (holds socket table)
- `domain` - Ignored (for nanomsg compatibility)
- `type` - Socket type (`VMSG_SUB`, `VMSG_PUB`, `VMSG_PUSH`, `VMSG_PULL`)

**Returns:** Socket handle (≥0) on success, -1 on error

**Implementation:**
1. Opens appropriate NNG socket type
2. Allocates slot in `VMSG_TAB` socket table
3. Returns table index as handle

---

#### `vmsg_close(vnet_context_t *VNET, int sock)`
Closes a socket and all its endpoints.

**Parameters:**
- `VNET` - Network context
- `sock` - Socket handle from `vmsg_socket()`

**Returns:** 0 on success, -1 on error

---

### Connection Management

#### `vmsg_bind(vnet_context_t *VNET, int sock, const char *url)`
Binds socket to listen on a URL.

**Parameters:**
- `sock` - Socket handle
- `url` - NNG URL (e.g., `"tcp://0.0.0.0:7777"`)

**Returns:** Endpoint ID (≥0) on success, -1 on error

**Implementation:** Creates and starts an NNG listener.

---

#### `vmsg_connect(vnet_context_t *VNET, int sock, const char *url)`
Connects socket to a remote URL.

**Parameters:**
- `sock` - Socket handle
- `url` - NNG URL (e.g., `"tcp://192.168.1.100:7777"`)

**Returns:** Endpoint ID (≥0) on success, -1 on error

**Implementation:** Creates NNG dialer with non-blocking start (background reconnection enabled).

---

#### `vmsg_shutdown(vnet_context_t *VNET, int sock, int endpoint)`
Closes a specific endpoint (listener or dialer).

**Parameters:**
- `sock` - Socket handle
- `endpoint` - Endpoint ID from `vmsg_bind()` or `vmsg_connect()`

**Returns:** 0 on success, -1 on error

---

### Message I/O

#### `vmsg_send(vnet_context_t *VNET, int sock, const void *buf, int32_t len, int flags)`
Sends a message.

**Parameters:**
- `sock` - Socket handle
- `buf` - Message data
- `len` - Message length
- `flags` - Send flags (e.g., `VMSG_DONTWAIT` for non-blocking)

**Returns:** Bytes sent on success, negative errno on error

**Implementation:** Uses `nng_send()` with flag translation.

---

#### `vmsg_recv(vnet_context_t *VNET, int sock, void **bufp, int32_t len, int flags)`
Receives a message.

**Parameters:**
- `sock` - Socket handle
- `bufp` - Pointer to receive buffer pointer (NNG allocates)
- `len` - Expected length or `VMSG_MSG` for any size
- `flags` - Receive flags (e.g., `VMSG_DONTWAIT`)

**Returns:** Bytes received on success, negative errno on error

**Note:** When using `VMSG_MSG`, caller must free with `vmsg_freemsg()`.

---

#### `vmsg_freemsg(void *msg)`
Frees a message buffer allocated by `vmsg_recv()`.

---

### Socket Options

#### `vmsg_setsockopt(vnet_context_t *VNET, int sock, int level, int option, const void *val, int32_t sz)`

Sets socket options.

**Supported Options:**

| Level | Option | Value Type | Description |
|-------|--------|------------|-------------|
| - | `VMSG_SUBSCRIBE` | string | Subscribe to topic prefix |
| `VMSG_SOL_SOCKET` | `VMSG_RCVMAXSIZE` | int | Max receive message size (-1 = unlimited) |
| `VMSG_SOL_SOCKET` | `VMSG_SNDBUF` | int | Send buffer size (bytes) |
| `VMSG_SOL_SOCKET` | `VMSG_RCVBUF` | int | Receive buffer size (bytes) |

**Buffer Size Note:** Byte sizes are converted to message counts using `VMSG_BYTES_PER_MSG_EST` (1400 bytes/message).

---

#### `vmsg_getsockopt(vnet_context_t *VNET, int sock, int level, int option, void *val, int32_t *szp)`

Gets socket options.

**Supported Options:**

| Level | Option | Description |
|-------|--------|-------------|
| `VMSG_SOL_SOCKET` | `VMSG_RCVFD` | Receive file descriptor (for polling) |

---

### Error Handling

#### `vmsg_errno(void)`
Returns current error number.

#### `vmsg_strerror(int errnum)`
Returns error description string.

---

## Internal Data Structures

### Socket Table Entry (`struct vmsg_sock`)

```c
struct vmsg_sock {
    int in_use;                           // Slot occupied
    nng_socket s;                         // NNG socket handle
    int type;                             // VMSG_SUB/PUB/PUSH/PULL
    int next_eid;                         // Next endpoint ID
    pthread_mutex_t mtx;                  // Per-socket mutex
    struct vmsg_endpoint ep[VMSG_MAX_ENDPOINTS];  // Endpoint array
};
```

### Endpoint Entry (`struct vmsg_endpoint`)

```c
struct vmsg_endpoint {
    int in_use;                           // Slot occupied
    int is_dialer;                        // 1=dialer, 0=listener
    int started;                          // Connection established
    int id;                               // Endpoint ID
    union {
        nng_dialer d;                     // Dialer handle
        nng_listener l;                   // Listener handle
    };
};
```

---

## Error Mapping

NNG errors are mapped to POSIX errno values:

| NNG Error | POSIX errno |
|-----------|-------------|
| `NNG_EAGAIN` | `EAGAIN` |
| `NNG_ENOTSUP` | `ENOTSUP` |
| `NNG_ECLOSED` | `EBADF` |
| `NNG_ETIMEDOUT` | `ETIMEDOUT` |
| `NNG_EINVAL` | `EINVAL` |
| `NNG_ENOMEM` | `ENOMEM` |
| `NNG_ESTATE` | `EINVAL` |

---

## Thread Safety

- Global socket table protected by `VMSG_TAB_MTX`
- Per-socket operations protected by per-socket mutex
- Atomic operations for endpoint management

---

## Usage Example

```c
vnet_context_t VNET;

// Publisher
int pub = vmsg_socket(&VNET, 0, VMSG_PUB);
vmsg_bind(&VNET, pub, "tcp://0.0.0.0:7777");
vmsg_send(&VNET, pub, "hello", 5, 0);

// Subscriber
int sub = vmsg_socket(&VNET, 0, VMSG_SUB);
vmsg_setsockopt(&VNET, sub, 0, VMSG_SUBSCRIBE, "", 0);  // Subscribe to all
vmsg_connect(&VNET, sub, "tcp://192.168.1.100:7777");
void *buf;
int len = vmsg_recv(&VNET, sub, &buf, VMSG_MSG, 0);
// ... use buf ...
vmsg_freemsg(buf);
```

---

## Compile-Time Configuration

- `USE_NNG` - Define to use NNG backend (default)
- Without `USE_NNG` - Falls back to nanomsg

---

## Dependencies

- `valis_messaging.h` - Header with type definitions
- `<nng/nng.h>` - NNG core
- `<nng/protocol/pipeline0/push.h>` - Pipeline push
- `<nng/protocol/pipeline0/pull.h>` - Pipeline pull
- `<nng/protocol/pubsub0/pub.h>` - Pub/sub publisher
- `<nng/protocol/pubsub0/sub.h>` - Pub/sub subscriber
- `<pthread.h>` - Thread synchronization

---

**Documented:** Wake 1311 (2026-01-13)  
**Author:** Opus
