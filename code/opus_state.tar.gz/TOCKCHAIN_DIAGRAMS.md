# Tockchain System Diagrams

ASCII diagrams for understanding system architecture.
Created: Wake 1324

---

## 1. High-Level System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           TOCKCHAIN NETWORK                                  │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      CONSENSUS LAYER                                 │   │
│  │                                                                      │   │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐         │   │
│  │   │ Node 1  │◄──►│ Node 2  │◄──►│ Node 3  │◄──►│ Node N  │         │   │
│  │   │ (gen3)  │    │ (gen3)  │    │ (gen3)  │    │ (gen3)  │         │   │
│  │   └────┬────┘    └────┬────┘    └────┬────┘    └────┬────┘         │   │
│  │        │              │              │              │               │   │
│  │        └──────────────┴──────────────┴──────────────┘               │   │
│  │                           │                                          │   │
│  │                    Leaderless Quorum                                 │   │
│  │                    (Broadcast-first)                                 │   │
│  └──────────────────────────┬──────────────────────────────────────────┘   │
│                             │                                               │
│                             ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      EXECUTION LAYER                                 │   │
│  │                                                                      │   │
│  │   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │   │
│  │   │  Validator  │    │  Dataflow   │    │    UFC      │             │   │
│  │   │   (ledger)  │◄──►│   (eBPF)    │◄──►│   (DEX)     │             │   │
│  │   └─────────────┘    └─────────────┘    └─────────────┘             │   │
│  │          │                  │                  │                     │   │
│  │          └──────────────────┴──────────────────┘                     │   │
│  │                           │                                          │   │
│  │                    Deterministic State                               │   │
│  └──────────────────────────┬──────────────────────────────────────────┘   │
│                             │                                               │
│                             ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       BRIDGE LAYER                                   │   │
│  │                                                                      │   │
│  │   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │   │
│  │   │   Deposit   │    │    TSS      │    │  Withdraw   │             │   │
│  │   │   (MPT)     │◄──►│  (Keygen)   │◄──►│  (Quorum)   │             │   │
│  │   └─────────────┘    └─────────────┘    └─────────────┘             │   │
│  │          │                  │                  │                     │   │
│  │          └──────────────────┴──────────────────┘                     │   │
│  │                           │                                          │   │
│  │                  Trust-Minimized Bridge                              │   │
│  └──────────────────────────┬──────────────────────────────────────────┘   │
│                             │                                               │
└─────────────────────────────┼───────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │    Ethereum     │
                    │   (External)    │
                    └─────────────────┘
```

---

## 2. Transaction Flow

```
                    User Transaction
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    1. BROADCAST                                   │
│                                                                   │
│   User ──► Node ──► All Nodes (broadcast-first)                  │
│                                                                   │
│   • No leader election                                           │
│   • Immediate propagation                                        │
│   • Sub-second latency                                           │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│                    2. AGGREGATION                                 │
│                                                                   │
│   Nodes collect transactions into "tocks" (blocks)               │
│                                                                   │
│   • 1 tock per second                                            │
│   • Deterministic ordering                                       │
│   • No mining/staking required                                   │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│                    3. VALIDATION                                  │
│                                                                   │
│   ┌─────────┐    ┌─────────┐    ┌─────────┐                      │
│   │ Frama-C │───►│  Coq    │───►│ Runtime │                      │
│   │ (static)│    │(proofs) │    │ (exec)  │                      │
│   └─────────┘    └─────────┘    └─────────┘                      │
│                                                                   │
│   • Formally verified core operations                            │
│   • Mathematical proofs of safety                                │
│   • Deterministic execution                                      │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│                    4. FINALITY                                    │
│                                                                   │
│   Transaction confirmed in < 5 seconds                           │
│                                                                   │
│   • No reorganizations                                           │
│   • Instant settlement                                           │
│   • Zero fees                                                    │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. Dataflow (eBPF) Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DATAFLOW SYSTEM                                      │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                        TRIGGER LAYER                                 │   │
│   │                                                                      │   │
│   │   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐     │   │
│   │   │ Price    │    │ Time     │    │ Balance  │    │ Custom   │     │   │
│   │   │ Trigger  │    │ Trigger  │    │ Trigger  │    │ Trigger  │     │   │
│   │   └────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘     │   │
│   │        │               │               │               │            │   │
│   │        └───────────────┴───────────────┴───────────────┘            │   │
│   │                              │                                       │   │
│   └──────────────────────────────┼──────────────────────────────────────┘   │
│                                  │                                          │
│                                  ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                      EXECUTION LAYER                                 │   │
│   │                                                                      │   │
│   │   ┌─────────────────────────────────────────────────────────────┐   │   │
│   │   │                    eBPF Virtual Machine                      │   │   │
│   │   │                                                              │   │   │
│   │   │   • Sandboxed execution                                      │   │   │
│   │   │   • Guaranteed termination                                   │   │   │
│   │   │   • Gas metering                                             │   │   │
│   │   │   • Deterministic                                            │   │   │
│   │   │                                                              │   │   │
│   │   └─────────────────────────────────────────────────────────────┘   │   │
│   │                              │                                       │   │
│   └──────────────────────────────┼──────────────────────────────────────┘   │
│                                  │                                          │
│                                  ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                        API LAYER                                     │   │
│   │                                                                      │   │
│   │   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐     │   │
│   │   │ Transfer │    │ Swap     │    │ Query    │    │ State    │     │   │
│   │   │ Funds    │    │ Assets   │    │ Balance  │    │ Update   │     │   │
│   │   └──────────┘    └──────────┘    └──────────┘    └──────────┘     │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. UFC (Unified Fair Curve) DEX

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              UFC DEX                                         │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                       PRICE DISCOVERY                                │   │
│   │                                                                      │   │
│   │                         Fair Curve                                   │   │
│   │                            │                                         │   │
│   │                     ┌──────┴──────┐                                  │   │
│   │                     │             │                                  │   │
│   │              ┌──────▼──────┐ ┌────▼────┐                             │   │
│   │              │ In-Bounds   │ │   OOB   │                             │   │
│   │              │ (0% fee)    │ │(premium)│                             │   │
│   │              └─────────────┘ └─────────┘                             │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                     LIQUIDITY POOLS                                  │   │
│   │                                                                      │   │
│   │   ┌───────────┐    ┌───────────┐    ┌───────────┐                   │   │
│   │   │ VNET/VUSD │    │ ETH/VUSD  │    │ BTC/VUSD  │                   │   │
│   │   │   Pool    │    │   Pool    │    │   Pool    │                   │   │
│   │   └───────────┘    └───────────┘    └───────────┘                   │   │
│   │                                                                      │   │
│   │   • IL < 0.1% annually                                              │   │
│   │   • ~1% LP yield from OOB premiums                                  │   │
│   │   • VNET coinbase rewards                                           │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    FORMAL GUARANTEES                                 │   │
│   │                                                                      │   │
│   │   ✓ Roundtrip profit ≤ 0 (no arbitrage extraction)                  │   │
│   │   ✓ Attackers pay premium (economic security)                       │   │
│   │   ✓ Balances conserved (no money creation/destruction)              │   │
│   │   ✓ Contracts terminate (no infinite loops)                         │   │
│   │                                                                      │   │
│   │   Proven in Coq with ~650 theorems                                  │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Bridge Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                              ETHEREUM                                        │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                     Bridge Contract                                  │   │
│   │                                                                      │   │
│   │   deposit(amount) ──────────────────────────────► emit Deposit      │   │
│   │                                                                      │   │
│   │   withdraw(proof, sigs) ◄─────────────────────── TSS signatures     │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ MPT Proof
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                              TOCKCHAIN                                       │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                      DEPOSIT FLOW                                    │   │
│   │                                                                      │   │
│   │   1. User deposits ETH/USDC to Ethereum contract                    │   │
│   │   2. Tockchain nodes monitor for Deposit events                     │   │
│   │   3. MPT proof verifies deposit inclusion                           │   │
│   │   4. Tockchain credits user with wrapped asset                      │   │
│   │                                                                      │   │
│   │   Trust: Cryptographic (MPT proof verification)                     │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                     WITHDRAW FLOW                                    │   │
│   │                                                                      │   │
│   │   1. User requests withdrawal on Tockchain                          │   │
│   │   2. Progressive quorum: 24h (50%), 48h (67%), 72h (75%)           │   │
│   │   3. TSS nodes generate threshold signature                         │   │
│   │   4. User submits signature to Ethereum contract                    │   │
│   │   5. Contract releases funds                                        │   │
│   │                                                                      │   │
│   │   Trust: Economic (quorum must collude to steal)                    │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                      TSS (Threshold Signatures)                      │   │
│   │                                                                      │   │
│   │   ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐                       │   │
│   │   │Key 1│  │Key 2│  │Key 3│  │Key 4│  │Key N│                       │   │
│   │   └──┬──┘  └──┬──┘  └──┬──┘  └──┬──┘  └──┬──┘                       │   │
│   │      │        │        │        │        │                           │   │
│   │      └────────┴────────┴────────┴────────┘                           │   │
│   │                        │                                             │   │
│   │                   Threshold                                          │   │
│   │                   Signature                                          │   │
│   │                        │                                             │   │
│   │                        ▼                                             │   │
│   │              Single Valid Signature                                  │   │
│   │              (no single point of failure)                            │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Formal Verification Stack

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FORMAL VERIFICATION STACK                              │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                         COQ PROOFS                                   │   │
│   │                                                                      │   │
│   │   ~650 Qed proofs                                                   │   │
│   │   100 axioms (mathematical foundations)                             │   │
│   │   2 admitted (explicitly marked incomplete)                         │   │
│   │                                                                      │   │
│   │   Key Theorems:                                                     │   │
│   │   • roundtrip_profit_le_zero                                        │   │
│   │   • attacker_pays_premium                                           │   │
│   │   • balance_conservation                                            │   │
│   │   • contract_termination                                            │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                  │                                          │
│                                  │ Guides implementation                    │
│                                  ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                        FRAMA-C                                       │   │
│   │                                                                      │   │
│   │   Static analysis of C code                                         │   │
│   │   ACSL annotations for contracts                                    │   │
│   │   Memory safety verification                                        │   │
│   │   Integer overflow detection                                        │   │
│   │                                                                      │   │
│   │   frama_verified.c: Core operations                                 │   │
│   │   frama_proofs.txt: 1.8MB proof output                              │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                  │                                          │
│                                  │ Verifies                                 │
│                                  ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                      RUNTIME CODE                                    │   │
│   │                                                                      │   │
│   │   C implementation (~35,000 lines)                                  │   │
│   │   Deterministic execution                                           │   │
│   │   Matches verified specifications                                   │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Token Economics

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          TOKEN ECONOMICS                                     │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                           VNET                                       │   │
│   │                                                                      │   │
│   │   Emission: 1 VNET per tock (1 per second)                          │   │
│   │   Halving: Every 4 years                                            │   │
│   │   Distribution: To node operators                                   │   │
│   │   Purpose: Network participation incentive                          │   │
│   │                                                                      │   │
│   │   Year 1-4:   1 VNET/sec  = 31.5M/year                              │   │
│   │   Year 5-8:   0.5 VNET/sec = 15.75M/year                            │   │
│   │   Year 9-12:  0.25 VNET/sec = 7.875M/year                           │   │
│   │   ...                                                                │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                           VBOND                                      │   │
│   │                                                                      │   │
│   │   Purpose: Node quality/reputation token                            │   │
│   │   Pricing: Market-determined                                        │   │
│   │   Function: Incentivizes infrastructure upgrades                    │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                           VUSD                                       │   │
│   │                                                                      │   │
│   │   Type: Stablecoin (pegged to USD)                                  │   │
│   │   Backing: External yield on deposited stablecoins                  │   │
│   │   Treasury: Scales with TVL                                         │   │
│   │   Sustainability: No user extraction required                       │   │
│   │                                                                      │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Module Dependencies

```
                              ┌─────────────┐
                              │   _valis.h  │
                              │  (master)   │
                              └──────┬──────┘
                                     │
           ┌─────────────────────────┼─────────────────────────┐
           │                         │                         │
           ▼                         ▼                         ▼
    ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
    │  generator/ │          │  validator/ │          │   bridge/   │
    │   (gen3)    │          │  (ledger)   │          │  (eth link) │
    └──────┬──────┘          └──────┬──────┘          └──────┬──────┘
           │                        │                        │
           │                        ▼                        │
           │                 ┌─────────────┐                 │
           │                 │    UFC/     │                 │
           │                 │   (DEX)     │                 │
           │                 └──────┬──────┘                 │
           │                        │                        │
           └────────────────────────┼────────────────────────┘
                                    │
                                    ▼
                             ┌─────────────┐
                             │     DF/     │
                             │ (dataflow)  │
                             └──────┬──────┘
                                    │
                                    ▼
                             ┌─────────────┐
                             │   utils/    │
                             │ (shared)    │
                             └──────┬──────┘
                                    │
           ┌────────────────────────┼────────────────────────┐
           │                        │                        │
           ▼                        ▼                        ▼
    ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
    │ cryptolibs/ │          │  netlibs/   │          │    tss/     │
    │  (crypto)   │          │ (network)   │          │  (thresh)   │
    └─────────────┘          └─────────────┘          └─────────────┘
```

---

## Notes on Diagrams

These ASCII diagrams are designed to be:
1. **Readable in any text editor** - no special rendering required
2. **Copy-pasteable** - can be included in documentation, emails, chat
3. **Version-controllable** - diffs show exactly what changed

For more sophisticated diagrams, consider:
- Mermaid.js (renders in GitHub/GitLab markdown)
- PlantUML (generates from text)
- draw.io (visual editor with export)

---

*Created by Opus, Wake 1324*
*Part of Tockchain Documentation Project*
