# utils/valis_hash.c Documentation

## Overview

**File:** `utils/valis_hash.c`  
**Lines:** 1064  
**Purpose:** Cryptographic hashing for Tockchain - Keccak-256 and Turbo Hash implementations

This file provides:
1. **Ethereum-compatible Keccak-256** - Standard 24-round permutation for Ethereum compatibility
2. **Turbo Hash** - K12-inspired high-performance hash using AVX2 SIMD
3. **Merkle root calculation** - AVX2-optimized tree hashing for transaction batches
4. **Batch hashing** - Process 4 inputs in parallel using AVX2

---

## Requirements

```c
#if defined(__x86_64__) || defined(_M_X64)
#include <immintrin.h>
#else
#error "AVX2 is required for turbo hash; build only on x86_64 with AVX2"
#endif
```

**Platform:** x86_64 with AVX2 support only

---

## Core Constants

### Keccak Round Constants
```c
static const uint64_t KECCAK_RC[24] = {
    0x0000000000000001ULL, 0x0000000000008082ULL,
    // ... 24 round constants for Keccak-f[1600]
};
```

### Turbo Hash Parameters
| Constant | Value | Purpose |
|----------|-------|---------|
| `VHASH_LEAF_BYTES` | 8192 | Leaf chunk size (8 KiB) |
| `VHASH_RATE_BYTES` | 168 | Absorption rate |
| `VHASH_LEAF_SUFFIX` | 0x0B | Leaf padding suffix |
| `VHASH_FINAL_SUFFIX` | 0x07 | Trunk finalization suffix |

---

## Function Reference

### Primary Hash Functions

#### `eth_keccak256(out32, in, len)`
Standard Ethereum Keccak-256 hash.

```c
int32_t eth_keccak256(uint8_t *out32, const uint8_t *in, uint64_t len)
```

- **Parameters:**
  - `out32`: Output buffer (32 bytes)
  - `in`: Input data
  - `len`: Input length
- **Returns:** 1 on success
- **Notes:** Uses 24-round Keccak-f[1600] permutation, rate=136 bytes

#### `valis_hash(buf, len, hash)`
Main hash entry point for Tockchain.

```c
int32_t valis_hash(uint8_t *buf, int32_t len, uint8_t hash[32])
```

- **Current implementation:** Delegates to `eth_keccak256()`
- **Future:** May switch to Turbo Hash for performance

#### `turbo_hash_dispatch(out32, in, len)`
K12-inspired high-performance hash.

```c
int32_t turbo_hash_dispatch(uint8_t *out32, const uint8_t *in, uint64_t len)
```

- **Parameters:** Same as `eth_keccak256`
- **Returns:** 1 on success
- **Algorithm:**
  1. Split input into 8 KiB leaves
  2. Hash each leaf with 6-round Keccak-p[1600]
  3. Absorb leaf digests into trunk state
  4. Finalize trunk with 8-round Keccak-p[1600]

---

### Batch Hashing (AVX2)

#### `eth_keccak256_x4_avx2(...)`
Hash 4 independent inputs in parallel.

```c
int32_t eth_keccak256_x4_avx2(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *in0, uint64_t len0,
    const uint8_t *in1, uint64_t len1,
    const uint8_t *in2, uint64_t len2,
    const uint8_t *in3, uint64_t len3
)
```

- **Performance:** ~4x throughput vs sequential hashing
- **Use case:** Parallel transaction ID computation

#### `eth_keccak256_x4_64B_avx2(...)`
Specialized batch hash for 64-byte inputs (two 32-byte concatenations).

```c
int32_t eth_keccak256_x4_64B_avx2(
    uint8_t out0[32], uint8_t out1[32], uint8_t out2[32], uint8_t out3[32],
    const uint8_t *a0, const uint8_t *b0,  // Input 0: concat(a0, b0)
    const uint8_t *a1, const uint8_t *b1,  // Input 1: concat(a1, b1)
    const uint8_t *a2, const uint8_t *b2,  // Input 2: concat(a2, b2)
    const uint8_t *a3, const uint8_t *b3   // Input 3: concat(a3, b3)
)
```

- **Use case:** Merkle tree internal node hashing (hash of two child hashes)

---

### Merkle Tree Functions

#### `calc_merkleroot_avx(txids, numtx, merkleroot, need_proofofabsence)`
Calculate Merkle root of transaction IDs using AVX2 optimization.

```c
void calc_merkleroot_avx(
    uint8_t *txids,           // Array of 32-byte transaction IDs
    int32_t numtx,            // Number of transactions
    uint8_t merkleroot[32],   // Output: Merkle root
    int32_t need_proofofabsence  // Flag for proof-of-absence support
)
```

- **Algorithm:** Binary Merkle tree with AVX2 batch hashing
- **Optimization:** Uses `eth_keccak256_x4_64B_avx2` for 4x parallel node hashing

#### `cmptxid2(a, b)`
Comparison function for sorting transaction IDs.

```c
int32_t cmptxid2(const void *_a, const void *_b)
```

- **Returns:** `memcmp` result for 32-byte hashes
- **Use case:** Sorting txids for canonical Merkle tree ordering

---

### Internal Permutation Functions

#### Scalar Permutations

| Function | Rounds | Use |
|----------|--------|-----|
| `keccakf1600_permute_24(st)` | 24 | Standard Keccak-256 |
| `keccakp1600_permute_8(st)` | 8 | Turbo Hash trunk |

#### AVX2 Permutations (4-way parallel)

| Function | Rounds | Use |
|----------|--------|-----|
| `keccakf1600_permute24x4_avx2(A)` | 24 | Batch Keccak-256 |
| `keccakp1600_permute6x4_avx2(A)` | 6 | Turbo Hash leaves |

---

### Turbo Hash Internal Functions

#### `k12_absorb_trunk_digest(trunk, leaf32)`
Absorb a 32-byte leaf digest into the trunk state.

```c
static void k12_absorb_trunk_digest(uint64_t trunk[25], const uint8_t leaf32[32])
```

#### `leaf_digest_times4_avx2_r6(...)`
Hash 4 leaves of equal length in parallel (6 rounds).

#### `leaf_digest_times4_avx2_varlen_r6(...)`
Hash 4 leaves of variable length in parallel (6 rounds).

---

## Algorithm Details

### Keccak-256 (Ethereum Standard)

```
State: 1600 bits (25 × 64-bit words)
Rate: 1088 bits (136 bytes)
Capacity: 512 bits
Rounds: 24
Output: 256 bits (32 bytes)
Padding: 0x01 || 0x00...00 || 0x80
```

### Turbo Hash (K12-inspired)

```
Leaf processing:
  - Chunk size: 8192 bytes
  - Permutation: Keccak-p[1600, 6 rounds]
  - Rate: 168 bytes
  - Suffix: 0x0B

Trunk processing:
  - Absorb 32-byte leaf digests
  - Permutation: Keccak-p[1600, 8 rounds]
  - Final suffix: 0x07
  - Output: 32 bytes
```

**Performance advantage:** Fewer rounds (6+8 vs 24) with larger chunks provides significant speedup for large inputs while maintaining security.

---

## Runtime Selection

```c
int32_t valis_hash_select_runtime(void)
{
    return 0;  // Currently returns 0 (no runtime selection)
}
```

**Note:** Runtime hash selection is currently disabled. The code contains commented infrastructure for selecting between implementations based on CPU features.

---

## Usage Patterns

### Simple Hashing
```c
uint8_t hash[32];
eth_keccak256(hash, data, data_len);
```

### Batch Transaction Hashing
```c
uint8_t h0[32], h1[32], h2[32], h3[32];
eth_keccak256_x4_avx2(h0, h1, h2, h3,
    tx0, len0, tx1, len1, tx2, len2, tx3, len3);
```

### Merkle Root Calculation
```c
uint8_t txids[MAX_TX * 32];
uint8_t root[32];
// Fill txids with transaction hashes...
calc_merkleroot_avx(txids, num_tx, root, 0);
```

---

## Performance Considerations

1. **AVX2 requirement:** All optimized paths require AVX2. No fallback for older CPUs.

2. **Batch processing:** Always prefer `_x4` variants when processing multiple independent inputs.

3. **Turbo Hash threshold:** For small inputs (<8KB), Turbo Hash has overhead. Standard Keccak-256 may be faster.

4. **Memory alignment:** AVX2 operations work best with 32-byte aligned buffers.

---

## Integration Points

Used by:
- `frama_verified.c` - Transaction ID calculation
- `validator/validator.c` - Block hash verification
- `bridge/bridge_*.c` - Ethereum address/hash computation
- `generator/gen3.c` - Block generation

---

## Code Style Notes

From file header:
> "Allman style; no blank lines inside functions; locals at top with stdint; two-line single-statement if"

This explains the dense formatting - all local variables declared at function top, no whitespace within function bodies.

---

## Documented By
Opus, Wake 1280 (2026-01-13)
