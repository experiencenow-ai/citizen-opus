# Tockchain Security Code Review - Merged Report
**Date:** 2026-01-14
**Reviewers:** Opus (Wake 1420) + Mira (Wake 118)
**Scope:** Full codebase security audit

## Executive Summary

Combined review identified **14 security issues**:
- **CRITICAL (4):** Fund loss or system insolvency risk
- **HIGH (3):** Double-spend, memory corruption, economic gaming
- **MEDIUM (5):** Clock skew, unverified primitives, accounting drift
- **LOW/NOTED (2):** Buffer overflow potential, known attack vector

**Immediate action required on:** All 4 critical issues (fund loss scenarios)

### Priority Remediation Order:
1. C1 - Integer overflow in order fills (direct fund loss)
2. C3 - Balance underflow in swap (inflation attack)
3. C4 - Frontier score race (missed liquidations)
4. C2 - Trigger intent race (system reliability)

---

## CRITICAL SEVERITY (4)

### C1. Integer Overflow in Order Fill Calculations
**Module:** UFC Orderbook
**Reviewer:** Mira
**Impact:** Fund loss - CRITICAL

**Issue:** When calculating filled amounts, multiplication of price × quantity can overflow before division. Standard uint64 arithmetic wraps silently.

**Attack Vector:** Attacker submits order with carefully chosen price/quantity values that overflow during fill calculation, receiving more tokens than paid for.

**Recommendation:** 
- Use checked arithmetic or `__int128` intermediate values
- Add overflow assertions before multiplication
- Consider using the verified `ufc_mul_div_floor` from frama_verified.c (though note M2 below)

---

### C2. Trigger Intent Array Race Condition
**Module:** Dataflow Trigger
**Reviewer:** Mira
**Impact:** Intent corruption, double execution, or missed executions - CRITICAL

**Issue:** Multiple triggers can modify the intent array without proper synchronization. Concurrent access during high-throughput periods could corrupt state.

**Attack Vector:** Under load, race condition could cause:
- Same intent executed twice (double-spend)
- Intent skipped entirely (denial of service)
- Array corruption leading to undefined behavior

**Recommendation:**
- Add mutex protection for intent array access
- Use atomic operations for array modifications
- Consider lock-free data structures if performance critical

---

### C3. Balance Underflow in Swap Execution
**Module:** UFC Swap
**Reviewer:** Mira
**Impact:** Negative balances, system insolvency - CRITICAL

**Issue:** Insufficient balance checks before deduction can cause underflow. If balance < deduction amount, unsigned subtraction wraps to very large positive number.

**Attack Vector:** Attacker with small balance executes swap that should fail, but underflow creates massive balance instead. Classic inflation attack.

**Recommendation:**
- Add explicit `if (balance < amount) return ERROR;` before ALL balance operations
- Use checked subtraction that returns error on underflow
- Add invariant: sum of all balances == total supply (verify on every block)

---

### C4. Frontier Score Race Condition
**Module:** Dataflow Frontier
**Reviewer:** Mira
**Impact:** Missed liquidations, risk management failure - CRITICAL

**Issue:** Score updates and frontier position tracking are not atomic. Between score update and frontier insertion, the system's view of risk is inconsistent.

**Attack Vector:** Position becomes liquidatable but isn't tracked in frontier due to race. System accumulates bad debt as underwater positions aren't liquidated.

**Recommendation:**
- Atomic score update + frontier insertion (single transaction)
- Lock-based protection during score/frontier operations
- Add consistency check: all positions with score below threshold must be in frontier

---

## HIGH SEVERITY (3)

### H1. Orderbook State Atomicity
**Module:** UFC Orderbook
**Reviewer:** Mira
**Impact:** Inconsistent orderbook state - HIGH

**Issue:** Order insertion/removal involves multiple state updates that aren't atomic. If interrupted mid-operation (crash, timeout), orderbook could be in inconsistent state.

**Scenarios:**
- Order partially inserted: visible in one index but not another
- Order partially removed: phantom orders or orphaned references
- Price level counts incorrect

**Recommendation:**
- Implement transaction-like semantics with rollback capability
- Use write-ahead logging for multi-step operations
- Add consistency verification on startup

---

### H2. Intent Array Overflow
**Module:** Dataflow Trigger
**Reviewer:** Mira
**Impact:** Buffer overflow, memory corruption - HIGH

**Issue:** Array size limits not enforced consistently. Under certain conditions, more intents can be added than array capacity.

**Recommendation:**
- Strict bounds checking on ALL array operations
- Use safe array abstractions that enforce bounds
- Add compile-time and runtime size assertions

---

### H3. Sure-Cap Gaming
**Module:** Dataflow Frontier
**Reviewer:** Mira
**Impact:** Increased system risk, delayed liquidations - HIGH

**Issue:** Users might game the sure-cap threshold to avoid liquidation. By keeping position just above threshold, they avoid liquidation while maintaining risky exposure.

**Economic Attack:** Sophisticated traders maintain positions at threshold edge, extracting value while socializing risk to the system.

**Recommendation:**
- Review sure-cap economics with game theory analysis
- Consider dynamic thresholds based on system-wide risk
- Add liquidation incentives that overcome gaming strategies

---

## MEDIUM SEVERITY (5)

### M1. Bridge Deadline Arithmetic Underflow
**Module:** Bridge Deposit
**Reviewer:** Opus
**Location:** `/root/valis/bridge/bridge_deposit.c:844`

```c
if ((L1->processedutime - dp->timestamp) > BRIDGE_DEADLINE)
```

**Issue:** Arithmetic underflow if `dp->timestamp > L1->processedutime` (clock skew between chains). Result becomes very large positive number, incorrectly triggering deadline expiration.

**Recommendation:**
```c
if (dp->timestamp > L1->processedutime || 
    (L1->processedutime - dp->timestamp) > BRIDGE_DEADLINE)
```

---

### M2. Unverified __int128 Financial Primitives
**Module:** Frama-C Verified Core
**Reviewer:** Opus
**Location:** `/root/valis/coq/pass326/frama/evidence/frama_verified.c:15-60`

**Issue:** `__int128` functions (`safe_mul_then_div`, `ufc_mul_div_floor`, etc.) are marked "trusted primitives, not formally verified" because Frama-C doesn't support `__int128`. These are the exact functions where overflow bugs would be most catastrophic.

**Trust Boundary:** The 99.5% Frama-C coverage excludes the most critical arithmetic operations.

**Recommendation:**
- Add runtime assertions for overflow conditions
- Property-based testing with extreme values (MAX_INT64 * MAX_INT64, etc.)
- Document trust boundary explicitly in security documentation
- Consider alternative verification (Coq extraction, symbolic execution)

---

### M3. Frontier Persistence
**Module:** Dataflow Frontier
**Reviewer:** Mira
**Impact:** Lost risk tracking after restart - MEDIUM

**Issue:** Unclear if frontier state persists correctly across system restarts. If frontier is rebuilt incorrectly, positions that should be liquidated might not be tracked.

**Recommendation:**
- Verify persistence mechanism explicitly
- Add recovery tests that simulate crash/restart
- Implement frontier consistency check on startup

---

### M4. Premium Rounding Drift
**Module:** UFC Swap
**Reviewer:** Mira
**Impact:** Small value leakage over time - MEDIUM

**Issue:** Rounding in premium calculations could accumulate over many transactions. Consistent rounding in one direction creates arbitrage opportunity.

**Recommendation:**
- Use banker's rounding (round half to even)
- Track cumulative rounding error
- Periodic reconciliation of expected vs actual fees

---

### M5. TOB Capacity Overflow
**Module:** UFC Orderbook
**Reviewer:** Mira
**Impact:** Top-of-book tracking failure - MEDIUM

**Issue:** Top-of-book tracking structures might overflow under extreme market conditions with many price levels.

**Recommendation:**
- Add capacity limits with graceful degradation
- Monitor TOB structure size in production
- Implement pruning for stale price levels

---

## LOW SEVERITY / NOTED (2)

### L1. File Path Buffer Overflow Risk
**Module:** Various
**Reviewer:** Opus
**Impact:** Potential buffer overflow - LOW

**Issue:** Some file path constructions don't verify buffer size before concatenation.

**Recommendation:** Use `snprintf` with explicit size limits for all path construction.

---

### L2. Vans Withholding TODO
**Module:** Gen3 Vans
**Reviewer:** Opus
**Impact:** Known attack vector - NOTED

**Issue:** Code contains TODO comment acknowledging vans withholding attack vector. This is a known issue, not a new finding.

**Recommendation:** Track as known issue, implement mitigation when prioritized.

---

## Positive Findings

The review also identified several strong security practices:

1. **99.5% Frama-C Coverage** - Financial math is formally verified (with __int128 exception noted in M2)
2. **Duplicate Protection** - Robust duplicate detection prevents replay attacks
3. **Merkle Verification** - Bridge uses proper merkle proofs for cross-chain verification
4. **Mutex Discipline** - Most critical sections have proper locking (exceptions noted above)
5. **Coq Proofs** - Core consensus logic has formal proofs

---

## Methodology

**Division of Labor:**
- Opus: Consensus, Bridge, TSS subsystems
- Mira: UFC (exchange), Dataflow subsystems

**Approach:**
- Static analysis of source code
- Review of formal verification evidence
- Attack vector enumeration
- Cross-reference between subsystems

**Limitations:**
- No dynamic testing performed
- No fuzzing of inputs
- Review based on code reading, not execution

---

## Recommendations Summary

### Immediate (Before Launch):
1. Fix C1-C4 critical issues
2. Add comprehensive underflow/overflow checks
3. Implement atomic operations for multi-step state changes

### Short-term:
1. Address H1-H3 high severity issues
2. Extend formal verification to __int128 operations
3. Add invariant checks that run on every block

### Long-term:
1. Implement continuous fuzzing
2. Add formal verification for race condition freedom
3. Economic audit of sure-cap and liquidation mechanics

---

*Report generated by Opus (Wake 1420) and Mira (Wake 118)*
*Tockchain Security Review - January 2026*
