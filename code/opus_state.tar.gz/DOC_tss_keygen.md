# keygen.c - Distributed Key Generation

## Purpose

Implements the distributed key generation (DKG) phase of the GG20 threshold ECDSA protocol. Multiple parties collaborate to generate a shared public key where each party holds only a share of the private key. No single party ever possesses the complete private key.

## Location
`/root/valis/tss/keygen.c` (~1185 lines)

## Key Concepts

### Threshold Scheme
- **t-of-n**: Any t parties can sign, fewer cannot
- **Security**: Even if t-1 parties collude, they cannot forge signatures
- **Typical**: 2-of-3, 3-of-5, or higher for production

### Key Generation Rounds
The DKG protocol runs multiple rounds:
1. **Commitment**: Each party commits to random values
2. **Share Distribution**: Parties exchange encrypted shares
3. **Verification**: Parties verify received shares
4. **Public Key Derivation**: Combined public key computed

## Data Structures

### keygenmsg
```c
struct keygenmsg {
    uint8_t bc_msg[MAX_MESSAGE_SIZE];           // Broadcast message
    size_t bc_msg_len;                          // Broadcast length
    uint8_t p2p_msgs[MAX_PARTIES-1][MAX_P2PMESSAGE_SIZE];  // P2P messages
    size_t p2p_lens[MAX_PARTIES-1];             // P2P lengths
    char dest_ids[MAX_PARTIES-1][MAX_PARTY_ID_LENGTH];    // Destinations
    int32_t num_p2p_msgs, round;                // Round number
};
```

### Msg (Queue Element)
```c
struct Msg {
    struct Msg *prev, *next;    // Doubly-linked list (utlist)
    struct keygenmsg M;         // Message content
    char src[MAX_PARTY_ID_LENGTH];  // Source party
};
```

### mpc_comms (Network Context)
```c
struct mpc_comms {
    const char *party_id;              // This party's ID
    const char **party_ids;            // All party IDs
    int pull_sock;                     // Receive socket
    int push_socks[MAX_PARTIES];       // Send sockets
    int barrier_status[MAX_PARTIES];   // Round synchronization
    int32_t num_parties, index;        // Party count and index
    uint16_t baseport;                 // Network base port
    char *bind_url;                    // Bind URL
    char *connect_urls[MAX_PARTIES];   // Connect URLs
};
```

### KeygenContext
```c
typedef struct {
    uint8_t recvbuf[1024 * 1024];      // Receive buffer
    mpc_eth_context_handle handle;     // MPC library handle
    struct keygenmsg OUT;              // Outgoing message
    char sign_key_base64[SIGNKEY_BUFSIZE];  // Generated key share
    pthread_mutex_t queue_mutex;       // Thread safety
    struct Msg *queue;                 // Message queue
    struct mpc_comms mpc;              // Network context
    // ... additional fields
} KeygenContext;
```

## Constants

```c
#define SIGNKEY_BUFSIZE 800000         // Key share buffer size
#define MAX_SIGN_KEY_SIZE SIGNKEY_BUFSIZE
#define P2P_BUFFER_SIZE SIGNKEY_BUFSIZE
#define BROADCAST_BUFFER_SIZE 4096
#define MAX_PARTY_ID_LENGTH 64
#define MAX_P2PMESSAGE_SIZE 32768
```

## Network Protocol

### Socket Setup
Each party:
1. Binds a PULL socket on `baseport + index`
2. Connects PUSH sockets to all other parties

```c
// Bind receive socket
char bind_url[64];
sprintf(bind_url, "tcp://*:%d", baseport + index);
ctx->mpc.pull_sock = nn_socket(AF_SP, NN_PULL);
nn_bind(ctx->mpc.pull_sock, bind_url);

// Connect to peers
for (int j = 0; j < num_parties; j++) {
    if (j != index) {
        char connect_url[64];
        sprintf(connect_url, "tcp://%s:%d", peer_addr, baseport + j);
        ctx->mpc.push_socks[j] = nn_socket(AF_SP, NN_PUSH);
        nn_connect(ctx->mpc.push_socks[j], connect_url);
    }
}
```

### Message Flow
```
Round N:
  Party 0 ──broadcast──> All parties
  Party 0 ──p2p[1]────> Party 1
  Party 0 ──p2p[2]────> Party 2
  
  Party 1 ──broadcast──> All parties
  Party 1 ──p2p[0]────> Party 0
  Party 1 ──p2p[2]────> Party 2
  
  (etc.)
  
  All parties wait for barrier before Round N+1
```

## Key Functions

### run_keygen
Main entry point for key generation:
```c
int run_keygen(int threshold, int num_parties, int baseport, int port, 
               int launcher_mode, char *party_file,
               const char *party_ids[MAX_PARTIES],
               const char *party_indices[MAX_PARTIES],
               const char *remote_party_ids_list[MAX_PARTIES][MAX_PARTIES - 1],
               int curve_type, const char *workspace_id);
```

### run_single_party_keygen
Executes keygen for one party:
```c
int run_single_party_keygen(KeygenContext *ctx, int t, int n, 
                            const char **party_ids, int index);
```

### Barrier Synchronization
```c
// Wait for all parties to reach round
while (1) {
    int all_reached = 1;
    for (int j = 0; j < ctx->mpc.num_parties; j++) {
        if (j != ctx->mpc.index && ctx->mpc.barrier_status[j] < round) {
            all_reached = 0;
            break;
        }
    }
    if (all_reached) break;
    
    // Receive and queue messages
    int ret = receive_msg(&ctx->mpc, &ctx->tmp_msg, ...);
    if (ret > 0 && ctx->tmp_msg.M.round > round - 1) {
        struct Msg *new_msg = malloc(sizeof(struct Msg));
        memcpy(new_msg, &ctx->tmp_msg, sizeof(struct Msg));
        DL_APPEND(ctx->queue, new_msg);
    }
}
```

## Output

### Key Share
After successful keygen, each party has:
- `sign_key_base64`: Base64-encoded key share
- Stored to file for later signing operations

### Group Public Key
All parties derive the same public key:
- 65-byte uncompressed secp256k1 point
- Used to derive Ethereum address

## Command Line Interface

```bash
# Options
-t <threshold>    # Threshold (t in t-of-n)
-n <num_parties>  # Total parties
-b <baseport>     # Network base port
-p <port>         # This party's port offset
-L                # Launcher mode (spawn all parties)
-f <party_file>   # File with party addresses
```

### parse_options
```c
void parse_options(int argc, char *argv[], int *threshold, int *num_parties,
                   int *baseport, int *port, int *launcher_mode, char **party_file);
```

## Cleanup

```c
cleanup:
    // Free queued messages
    struct Msg *elt, *tmp;
    DL_FOREACH_SAFE(ctx->queue, elt, tmp) {
        DL_DELETE(ctx->queue, elt);
        free(elt);
    }
    
    // Close sockets
    nn_close(ctx->mpc.pull_sock);
    for (int j = 0; j < n; j++) {
        if (j != ctx->mpc.index) {
            nn_close(ctx->mpc.push_socks[j]);
        }
    }
    
    // Cleanup MPC context
    mpc_eth_cleanup(ctx->handle);
```

## Dependencies

- `libethc.h`: Ethereum crypto utilities
- `ethtx.h`: Transaction building
- `wrapper.h`: C++ MPC library bindings
- `utlist.h`: Linked list macros
- `nanomsg`: Network messaging
- `secp256k1`: Elliptic curve operations
- `pthread`: Threading

## Security Considerations

1. **Key Share Storage**: Must be encrypted at rest
2. **Network Security**: Should use TLS in production
3. **Threshold Selection**: t > n/2 recommended
4. **Party Authentication**: Verify party identities before keygen
5. **Randomness**: Requires cryptographically secure RNG

## Integration

Used by:
- `valis_herongen.c`: Valis-specific keygen wrapper
- Bridge setup: Initial key generation for validators

## Related Files

- `sig.c`: Uses generated key shares for signing
- `valis_tss.c`: High-level API
- `heronMPC.h`: Protocol structures
