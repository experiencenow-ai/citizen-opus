# gen3_metrics.c Documentation

**Location:** `/root/valis/generator/gen3_metrics.c`  
**Lines:** 1,564  
**Created:** 2025-10-01  
**Documented:** Wake 1316 (2026-01-13)

---

## Overview

The metrics module is the **consensus measurement and network health tracking system** for Tockchain. It provides deterministic data for consensus decisions by aggregating performance metrics, financial stake information, and network availability statistics across all validators.

### Primary Goals (from source comments)

1. **Consensus activemask** for current utime for missing node election
2. **Deterministic data** for rawtock header to enable consensus nodechange decisions
3. **Consensus first_unfinished utime** for VIP-only decisions
4. **Node selection** for queue_van destination
5. **Network error rate** to calibrate redundancy
6. **Consensus average RTT** per node and globally (2/3 coverage) to calibrate heartbeat frequency
7. **Intelligent selection** of signatures to propagate for allsigs messages

---

## Architecture

### Queue Index Constants (QIDX)

The system tracks consensus across multiple dimensions:

| QIDX | Name | Weight | Purpose |
|------|------|--------|---------|
| 0 | NORMAL_NODEVANSHASH | 0.1 | Normal node vans hash tracking |
| 1 | VIP_NODEVANSHASH | 0.1 | VIP node vans hash tracking |
| 2 | MISSINGNODES | 0.2 | Track missing nodes |
| 3 | MISSINGVANS | 0.2 | Track missing vans |
| 4 | VANSHASH | 0.5 | Vans hash consensus |
| 5 | FINALHASH | 1.0 | Final hash (highest weight) |
| 6 | NODECHANGE | 0.7 | Node change decisions |
| 7 | TOCKDATAHASH | 1.0 | Tock data hash (highest weight) |
| 8 | MISSINGRAWTOCK | 0.5 | Missing rawtock tracking |
| 9 | VALIDATOR_UTIME | 0.1 | Validator time tracking |
| 10 | ETH_HEADER | 1.0 | Ethereum header (highest weight) |

Special indices:
- **QIDX_METRICS_DATAONLY (15)**: Piggybacks as valis_vote_t in batch messages
- **QIDX_RAWTOCKFILE_CREATED (14)**: Status message for allsigs

### Core Data Structures

```c
typedef struct consensus_metrics_s {
    stx_metrics_t nodesM[MAX_VALIDATORS];  // Per-node metrics
    stx_metrics_t consensus;                // Aggregated consensus
    int32_t needsvector[MAX_VALIDATORS];    // What each node needs
} consensus_metrics_t;
```

---

## Performance Tracking Functions

### metrics_perf_init / metrics_perf_event

```c
int32_t metrics_perf_init(metrics_perf_data_t *P);
int32_t metrics_perf_event(metrics_perf_data_t *P, int32_t nodeid, 
                           double sample, double decay);
```

Thread-safe performance score tracking using exponential moving average (EMA):
- Initializes mutex-protected score array
- Updates scores with configurable decay rate
- Formula: `new = prev * (1 - decay) + sample * decay`

### metrics_apply_proof_bonus

```c
void metrics_apply_proof_bonus(global_reserve_t *GEN3, uint8_t srcaddr[PKSIZE]);
```

Applies performance bonus to nodes that submit valid proofs.

---

## Financial Vector System

### metrics_build_financial_vector

```c
void metrics_build_financial_vector(
    double fin_out[MAX_VALIDATORS],
    const struct vbond_info *vb,
    int32_t n,
    uint32_t utime,
    double w_vbond,   // Weight for vbond stake
    double w_vusd,    // Weight for VUSD holdings
    double w_lock     // Weight for lock duration
);
```

Builds a financial score vector for all validators based on:
- **VBOND stake**: Amount of validator bonds held
- **VUSD holdings**: Stablecoin balance
- **Lock duration**: How long assets are committed

These weights determine validator ranking for block production eligibility.

### vbond_producer_submit / vbond_gen3_consume

```c
void vbond_producer_submit(vbond_feed_data_t *F, uint32_t utime,
                           int64_t vusd_supply, const struct vbond_info *vb, int32_t n);
void vbond_gen3_consume(const vbond_feed_data_t *F, vbond_fifo_slot_t *cache, uint32_t utime);
```

Producer-consumer pattern for VBOND data:
- Producer submits bond info at each utime
- Consumer retrieves cached data for consensus calculations

---

## Ranking System

### metrics_compute_ranks

```c
void metrics_compute_ranks(
    const double *perf,     // Performance scores
    const double *fin,      // Financial scores
    uint32_t n,             // Number of validators
    double w_perf,          // Performance weight
    double w_fin,           // Financial weight
    uint8_t *ranks_out      // Output rank array
);
```

Computes validator rankings by combining:
- Performance metrics (uptime, latency, reliability)
- Financial stake (bonds, locked assets)

Ranks determine block production order and rewards.

### metrics_prepare_rank_and_eligible

```c
void metrics_prepare_rank_and_eligible(
    const vbond_fifo_slot_t *cache,
    const metrics_perf_data_t *P,
    global_reserve_t *GEN3,
    utime_data_t *U,
    uint8_t eligible4_out[VBOND_TOPK][PKSIZE],
    uint8_t ranks_out[MAX_VALIDATORS],
    double w_perf,
    double w_fin
);
```

Prepares both rankings and eligibility list for top-K validators (VBOND_TOPK).

---

## Per-Utime Metrics

### init_global_metrics_perutime

```c
void init_global_metrics_perutime(global_reserve_t *GEN3, uint32_t utime, int32_t myid);
```

Initializes metrics tracking for a new utime period.

### clear_node_metrics

```c
void clear_node_metrics(global_reserve_t *GEN3, int32_t nodeid);
```

Clears all metrics for a specific node (used when node leaves network).

### create_nodespecific_statstx

```c
void create_nodespecific_statstx(global_reserve_t *GEN3, utime_data_t *U);
```

Creates a signed statistics transaction containing this node's metrics for broadcast to other validators.

---

## Consensus Metrics

### update_consensus_metrics

```c
void update_consensus_metrics(
    global_reserve_t *GEN3,
    utime_data_t *U,
    rawtock_header_t *RAW,
    consensus_metrics_t *CM,
    struct systemtx *stx,
    int32_t txlen,
    int32_t nodeid
);
```

Updates consensus metrics from received node statistics:
- Validates signature against known validator pubkey
- Checks utime and transaction format
- Stores metrics in per-node array

### finalize_consensus_metrics

```c
void finalize_consensus_metrics(
    global_reserve_t *GEN3,
    consensus_metrics_t *CM,
    int32_t numnodes,
    rawtock_header_t *RAW
);
```

Finalizes consensus by aggregating all node metrics:
- Counts votes for eligible4 addresses (top-K validators)
- Computes median values for ranks, missing percentages, supply, VPU
- Uses 2/3 majority for consensus values
- Populates rawtock header with consensus data

---

## Network Capacity Estimation

### metrics_estimate_network_capacity

```c
double metrics_estimate_network_capacity(
    const double *avg_times,
    const double *missing,
    int32_t n,
    int32_t voters,
    double T_ref,           // Reference time threshold
    double quantile_p       // Quantile for capacity estimate
);
```

Estimates network throughput capacity based on:
- Average response times per node
- Missing data percentages
- Number of active voters
- Uses quantile-based estimation for robustness

Formula: `capacity = quantile_score * voters`

### metrics_estimate_network_capacity_from_GEN3

```c
double metrics_estimate_network_capacity_from_GEN3(
    global_reserve_t *GEN3,
    utime_data_t *U,
    double T_ref,
    double quantile_p
);
```

Wrapper that extracts data from GEN3 state and calls the core estimation function.

---

## Performance Scoring Functions

### metrics_perf_from_needbits

```c
void metrics_perf_from_needbits(
    global_reserve_t *GEN3,
    utime_data_t *U,
    double decay,
    double w_supply,        // Weight for data supply
    double w_need,          // Weight for data needs
    double w_lag,           // Weight for latency
    double candidate_scale  // Scaling for candidates
);
```

Updates performance scores based on needbits (what data each node needs):
- Nodes that supply data get bonuses
- Nodes that need data get penalties
- Latency affects scoring

### metrics_perf_from_quorum_vote_subject

```c
void metrics_perf_from_quorum_vote_subject(
    global_reserve_t *GEN3,
    valis_election_t *E,
    uint8_t domain,
    const uint8_t winner_subject[32],
    double decay,
    double bonus_major,     // Bonus for voting with majority
    double penalty_absent,  // Penalty for not voting
    double penalty_minor,   // Penalty for voting minority
    double bonus_early_frac // Bonus for early votes
);
```

Scores nodes based on quorum voting behavior:
- Rewards voting with consensus
- Penalizes absence or minority votes
- Early voters get additional bonus

### metrics_perf_from_lag

```c
int32_t metrics_perf_from_lag(
    global_reserve_t *GEN3,
    utime_data_t *U,
    double decay,
    double bonus_leader,    // Bonus for leading
    double bonus_edge,      // Bonus for being near edge
    double penalty_lag,     // Penalty for lagging
    uint32_t edge_behind_max
);
```

Scores nodes based on timing:
- Leaders (first to complete) get bonuses
- Edge nodes (near completion) get smaller bonuses
- Lagging nodes get penalties

---

## Utility Functions

### update_ema

```c
double update_ema(double *lastvalp, double newval, double decay);
```

Standard exponential moving average update.

### update_viponly

```c
int32_t update_viponly(global_reserve_t *GEN3, int32_t mostlaggy, int32_t prev_viponly);
```

Determines VIP-only mode based on network conditions.

### lagms

```c
int32_t lagms(uint32_t utime);
```

Calculates lag in milliseconds for a given utime.

### calc_aveRTT

```c
double calc_aveRTT(global_reserve_t *GEN3);
```

Calculates average round-trip time across all nodes with 2/3 coverage requirement.

### disp_peerema

```c
void disp_peerema(utime_data_t *U);
```

Debug display of peer EMA values.

---

## Metrics Data Encoding

### encode_metricsdata_sig / decode_metricsdata_sig

```c
int32_t encode_metricsdata_sig(
    uint8_t sig[65],
    uint32_t first_unfinished,
    uint32_t latest_tockdatatime,
    uint32_t missing_rawtock,
    uint32_t validator_utime,
    uint64_t activemask,
    uint64_t activevans,
    uint64_t masks[],
    int32_t n
);

int32_t decode_metricsdata_sig(
    uint8_t sig[65],
    uint32_t *first_unfinishedp,
    uint32_t *latest_tockdatatimep,
    uint32_t *missing_rawtockp,
    uint32_t *validator_utimep,
    uint64_t *activemaskp,
    uint64_t *activevansp,
    uint64_t masks[],
    int32_t n
);
```

Packs/unpacks metrics data into signature field for efficient transmission.

### insert_metrics_data

```c
int32_t insert_metrics_data(utime_data_t *U, valis_vote_t *batch, int32_t *batchcountp);
```

Inserts metrics data into vote batch for broadcast.

---

## Initialization

### init_gen3_metrics

```c
void init_gen3_metrics(global_metrics_t *M);
```

Initializes the global metrics structure.

### calc_consensus_metrics

Called to compute final consensus metrics from all collected node data.

### combine_utime_metrics

```c
void combine_utime_metrics(global_reserve_t *GEN3, utime_data_t *U);
```

Called from utime FIFO threads when making rawtock header. Combines all metrics for the current utime period.

---

## Key Concepts

### Consensus Through Aggregation

The metrics system achieves consensus by:
1. Each node broadcasts its local metrics via signed transactions
2. All nodes collect metrics from all other nodes
3. Consensus values computed using median/majority voting
4. Final values written to rawtock header

### Performance vs Financial Balance

Validator ranking combines:
- **Performance**: Uptime, latency, data availability
- **Financial**: Stake amount, lock duration

This prevents both:
- Rich validators with poor infrastructure
- Good operators without sufficient stake

### Adaptive Network Calibration

The system continuously adapts:
- Heartbeat frequency based on average RTT
- Redundancy based on error rates
- Packet budgets based on network capacity

---

## Integration Points

- **gen3_vote.c**: Uses metrics for election decisions
- **gen3_nodechange.c**: Uses metrics for node addition/removal
- **validator.c**: Receives metrics in rawtock headers
- **gen3_ssd.c**: Stores historical metrics data

---

## Related Files

- `gen3.h` - Type definitions for metrics structures
- `gen3_vote.c` - Voting system that uses metrics
- `gen3_nodechange.c` - Node change decisions based on metrics
- `dataflow.c` - Data flow tracking that feeds metrics
