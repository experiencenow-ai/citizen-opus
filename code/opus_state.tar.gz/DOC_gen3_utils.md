# gen3_utils.c Documentation

**File:** `generator/gen3_utils.c`  
**Lines:** ~393  
**Purpose:** Lock-free ring buffer implementation and utime data management utilities  
**Author:** Opus (Wake 1309)  
**Audit:** Pending (assigned to Kira)

---

## Overview

This file provides two critical infrastructure components for the Tockchain generator:

1. **Lock-Free Ring Buffer (vc_ring_t)** - A single-producer/single-consumer circular buffer using atomic operations for thread-safe message passing without locks
2. **Utime Data Management** - Functions to allocate, retrieve, and manage per-second consensus state structures

The ring buffer is particularly important for high-performance inter-thread communication in the consensus engine.

---

## Data Structure

### vc_ring_t (Ring Buffer)

```c
typedef struct {
    uint8_t *buf;           // Backing buffer (power-of-2 size)
    uint32_t cap;           // Capacity (must be power of 2)
    _Atomic uint32_t write_off;  // Writer's position
    _Atomic uint32_t read_off;   // Reader's position
} vc_ring_t;
```

**Design Notes:**
- Power-of-2 capacity allows efficient modulo via bitwise AND
- Atomic offsets enable lock-free operation
- Single producer, single consumer (SPSC) pattern
- Messages are length-prefixed (2-byte header)

---

## Ring Buffer Functions

### Initialization

#### `vc_ring_init()`
```c
void vc_ring_init(vc_ring_t *r, uint8_t *buf, uint32_t cap_pow2)
```

Initializes a ring buffer with the provided backing storage.

**Parameters:**
- `r` - Ring buffer structure to initialize
- `buf` - Pre-allocated buffer (caller manages memory)
- `cap_pow2` - Capacity (MUST be power of 2)

**Memory Ordering:**
- Uses `memory_order_relaxed` for initialization (no concurrent access expected)

---

### Internal Helpers

#### `vc_ring_mask_local()`
```c
uint32_t vc_ring_mask_local(vc_ring_t *r)
```

Returns `cap - 1` for efficient position wrapping via bitwise AND.

**Example:** If cap=1024, mask=1023 (0x3FF), so `pos & mask` wraps correctly.

---

#### `vc_ring_copy_to()`
```c
void vc_ring_copy_to(vc_ring_t *r, uint32_t *off_io, const uint8_t *src, uint32_t len)
```

Copies data INTO the ring buffer, handling wrap-around.

**Algorithm:**
1. Calculate current position: `pos = *off_io & mask`
2. Calculate bytes until wrap: `first = cap - pos`
3. If data fits without wrap: single memcpy
4. Otherwise: two memcpys (end of buffer, then start)
5. Update offset: `*off_io += len`

**Key Insight:** The offset is NOT masked - it's a monotonically increasing counter. The mask is applied only when accessing the buffer. This allows detecting full/empty states.

---

#### `vc_ring_copy_from()`
```c
void vc_ring_copy_from(vc_ring_t *r, uint32_t *off_io, uint8_t *dst, uint32_t len)
```

Copies data OUT OF the ring buffer, handling wrap-around.

Same algorithm as `copy_to` but in reverse direction.

---

### Capacity Queries

#### `vc_ring_free_bytes()`
```c
uint32_t vc_ring_free_bytes(vc_ring_t *r)
```

Returns bytes available for writing.

**Memory Ordering:**
- `relaxed` load of write_off (called by writer)
- `acquire` load of read_off (synchronizes with reader's release)

**Formula:** `cap - (write - read)`

---

#### `vc_ring_avail_bytes()`
```c
uint32_t vc_ring_avail_bytes(vc_ring_t *r)
```

Returns bytes available for reading.

**Memory Ordering:**
- `acquire` load of write_off (synchronizes with writer's release)
- `relaxed` load of read_off (called by reader)

**Formula:** `write - read`

---

### Message Operations

#### `vc_ring_write()`
```c
int32_t vc_ring_write(vc_ring_t *r, uint8_t *src, uint32_t len)
```

Writes a length-prefixed message to the ring buffer.

**Protocol:**
1. Check if `len + 2` bytes are free (2 for header)
2. Write 2-byte little-endian length header
3. Write payload
4. Release-store the new write offset

**Returns:**
- `0` on success
- `-1` if insufficient space

**Message Format:**
```
[len_lo][len_hi][payload...]
```

---

#### `vc_ring_read()`
```c
int32_t vc_ring_read(vc_ring_t *r, uint8_t *dst, uint32_t cap)
```

Reads a length-prefixed message from the ring buffer.

**Protocol:**
1. Check if at least 2 bytes available
2. Read 2-byte length header
3. Verify full message is available
4. Verify destination buffer is large enough
5. Copy payload to destination
6. Release-store the new read offset

**Returns:**
- Message length on success
- `0` if no complete message available
- `-2` if destination buffer too small

---

#### `write_into()`
```c
int32_t write_into(vc_ring_t *r, uint8_t *payload, uint16_t plen, 
                   uint8_t sender_index, uint8_t with_sender_prefix)
```

Extended write with optional sender prefix byte.

**Parameters:**
- `sender_index` - ID of sender (prepended if with_sender_prefix is true)
- `with_sender_prefix` - Whether to include sender byte

**Use Case:** Inter-node message routing where receiver needs to know sender.

---

## Utime Data Management

### `gen3_get_utimedata()`
```c
utime_data_t *gen3_get_utimedata(global_reserve_t *GEN3, uint32_t utime)
```

Gets or creates the utime_data_t structure for a given second.

**Implementation:**
- Uses FIFO index: `fifoind = utime % VNET_FIFOSIZE`
- Allocates on first access
- Initializes mutex for needbits synchronization

**Memory Management:**
- Structures are reused via FIFO rotation
- Caller must check if `U->utime` matches requested utime

---

### `get_nVANS()` / `get_mynVANS()`
```c
nodevans_info_t *get_nVANS(utime_data_t *U, int32_t nodeid)
nodevans_info_t *get_mynVANS(utime_data_t *U)
```

Accessor functions for node VANS (Validator Accumulated Node State) data.

**Design Note:** These accessors centralize access to allow future changes (pointers, sharding, etc.) without modifying callers.

---

### `utime_get_or_create()`
```c
utime_data_t *utime_get_or_create(global_reserve_t *GEN3, uint32_t utime, 
                                   uint8_t mypubkey[PKSIZE])
```

Gets existing or creates new utime data, ensuring initialization.

**Behavior:**
1. Ensures hourly directory exists for persistence
2. Gets utime data from FIFO
3. If utime doesn't match (slot reused), reinitializes

---

### `gen3_get_rescue_utime()` / `gen3_init_rescue_utime()`
```c
utime_data_t *gen3_get_rescue_utime(global_reserve_t *GEN3, uint32_t utime)
int32_t gen3_init_rescue_utime(global_reserve_t *GEN3, uint32_t utime_seed)
```

Manages a special "rescue" utime structure for recovery scenarios.

**Use Case:** When consensus needs to recover from a problematic state, this provides a clean utime structure outside the normal FIFO rotation.

---

### `clear_future_tockdatahashE()`
```c
void clear_future_tockdatahashE(global_reserve_t *GEN3, valis_election_t *election)
```

Clears upcoming tockdatahash election entry.

**Context:** When processing QIDX_TOCKDATAHASH elections, clears the future slot to prevent stale data.

---

### `get_next_nodeid()`
```c
int32_t get_next_nodeid(int32_t myid, validators_t *ds, int32_t nodeid)
```

Finds the next valid validator node ID for round-robin operations.

**Skips:**
- Self (myid)
- Nodes with no IP (ipbits == 0)
- Localhost (127.0.0.1)

**Wrapping:** Cycles through all nodes, wrapping at ds->num.

---

## Thread Safety Analysis

### Ring Buffer
- **SPSC Safe:** Single producer, single consumer without locks
- **Memory Barriers:** Proper acquire/release semantics ensure visibility
- **No ABA Problem:** Monotonic offsets prevent wrap-around issues

### Utime Data
- **Allocation:** Protected by implicit single-threaded initialization
- **Access:** Per-utime mutex for needbits operations
- **FIFO Reuse:** Caller must verify utime matches before using

---

## Performance Characteristics

| Operation | Complexity | Lock-Free |
|-----------|------------|-----------|
| ring_write | O(n) | Yes |
| ring_read | O(n) | Yes |
| get_utimedata | O(1) | No (allocation) |
| get_nVANS | O(1) | Yes |

---

## Dependencies

- `<stdatomic.h>` - C11 atomics
- `<pthread.h>` - Mutex for needbits
- `gen3.h` - Type definitions
- `_valis.h` - Global constants

---

## Integration Points

| Component | Interaction |
|-----------|-------------|
| gen3_net.c | Uses ring buffer for packet queuing |
| gen3_vote.c | Uses utime data for consensus state |
| gen3_needbits.c | Uses needbits mutex |
| valis_net_MT.c | Ring buffer for inter-thread messaging |

---

## Potential Improvements

1. **Power-of-2 Enforcement:** Add assertion that cap is power of 2
2. **Batch Operations:** Add batch read/write for efficiency
3. **Statistics:** Track high-water marks for capacity planning
4. **MPSC Variant:** Multi-producer version for some use cases

---

## Audit Checklist (for Kira)

- [ ] Verify atomic memory ordering is correct
- [ ] Check for integer overflow in offset arithmetic
- [ ] Verify wrap-around handling in copy functions
- [ ] Confirm FIFO reuse safety in utime management
- [ ] Test edge cases: empty buffer, full buffer, exact capacity
