# websockets.h - WebSocket Client Helper

## Purpose

Provides a simple WebSocket client implementation using libwebsockets. Used for communicating with WebSocket-based services (e.g., Ethereum nodes, price feeds).

## Location
`/root/valis/netlibs/websockets.h` (header-only implementation)

## Data Structures

### ws_data_t
```c
typedef struct {
    char response_buf[16384];    // Response buffer (16KB)
    size_t response_len;         // Current response length
    int response_received;       // Flag: response complete
    int connection_closed;       // Flag: connection closed
    const char *command;         // Command to send on connect
} ws_data_t;
```

### Global Instance
```c
static ws_data_t g_ws_data;  // Avoids libwebsockets user pointer issues
```

## Callback Function

### callback_websocket
Main libwebsockets callback handler:

```c
static int callback_websocket(struct lws *wsi, enum lws_callback_reasons reason,
                              void *user, void *in, size_t len);
```

#### Callback Reasons Handled

**LWS_CALLBACK_CLIENT_ESTABLISHED**
- Connection established
- Sends the command stored in `data->command`
- Uses `LWS_PRE` padding for write buffer

```c
case LWS_CALLBACK_CLIENT_ESTABLISHED:
    if (data->command) {
        size_t cmd_len = strlen(data->command);
        unsigned char *buf = malloc(LWS_PRE + cmd_len);
        memcpy(&buf[LWS_PRE], data->command, cmd_len);
        lws_write(wsi, &buf[LWS_PRE], cmd_len, LWS_WRITE_TEXT);
        free(buf);
    }
    break;
```

**LWS_CALLBACK_CLIENT_RECEIVE**
- Receives response data
- Appends to response buffer
- Checks for final fragment to mark completion

```c
case LWS_CALLBACK_CLIENT_RECEIVE:
    if (data->response_len + len < sizeof(data->response_buf)) {
        memcpy(data->response_buf + data->response_len, in, len);
        data->response_len += len;
        data->response_buf[data->response_len] = '\0';
    }
    
    if (lws_is_final_fragment(wsi)) {
        data->response_received = 1;
        lws_callback_on_writable(wsi);
    }
    break;
```

**LWS_CALLBACK_CLIENT_WRITEABLE**
- Called when socket is writable
- If response received, closes connection

```c
case LWS_CALLBACK_CLIENT_WRITEABLE:
    if (data->response_received) {
        lws_close_reason(wsi, LWS_CLOSE_STATUS_NORMAL, NULL, 0);
        return -1;  // Close connection
    }
    break;
```

## Usage Pattern

```c
// 1. Initialize global data
memset(&g_ws_data, 0, sizeof(g_ws_data));
g_ws_data.command = "{\"jsonrpc\":\"2.0\",\"method\":\"eth_blockNumber\",\"params\":[],\"id\":1}";

// 2. Create libwebsockets context
struct lws_context_creation_info info = {0};
info.protocols = protocols;  // Include callback_websocket
info.port = CONTEXT_PORT_NO_LISTEN;

struct lws_context *context = lws_create_context(&info);

// 3. Connect to server
struct lws_client_connect_info ccinfo = {0};
ccinfo.context = context;
ccinfo.address = "localhost";
ccinfo.port = 8546;
ccinfo.path = "/";
ccinfo.protocol = "ws";

struct lws *wsi = lws_client_connect_via_info(&ccinfo);

// 4. Service until response received
while (!g_ws_data.response_received && !g_ws_data.connection_closed) {
    lws_service(context, 100);
}

// 5. Process response
printf("Response: %s\n", g_ws_data.response_buf);

// 6. Cleanup
lws_context_destroy(context);
```

## Buffer Limits

- **Response Buffer**: 16KB (`response_buf[16384]`)
- **Overflow Handling**: Truncates with warning

## Design Notes

### Global Data Structure
Uses global `g_ws_data` instead of libwebsockets user pointer:
- Avoids issues with libwebsockets internal pointer handling
- Simpler for single-connection use cases
- Not thread-safe for concurrent connections

### Header-Only
Entire implementation in header file:
- Easy to include
- No separate compilation needed
- Uses `static` to avoid multiple definition errors

## Dependencies

- `libwebsockets`: WebSocket library
- Standard C headers: `stdio.h`, `stdlib.h`, `string.h`

## Limitations

1. **Single Connection**: Global state limits to one connection at a time
2. **Buffer Size**: 16KB response limit
3. **Synchronous**: Blocking service loop
4. **No SSL Configuration**: Would need extension for wss://

## Related Files

- `bridge_rpc.c`: May use for Ethereum WebSocket RPC
- `ethrpc.c`: HTTP-based RPC (alternative)
- `websocketd.c`: WebSocket server (different purpose)

## Security Considerations

1. **Buffer Overflow**: Protected by size check before memcpy
2. **Null Termination**: Explicitly null-terminates response
3. **Memory Leak**: Frees write buffer after use
