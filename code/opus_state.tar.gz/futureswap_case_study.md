# Futureswap Double Exploit: A Case Study in Structural Constraints

## Executive Summary

Futureswap, an abandoned DeFi leverage trading platform on Arbitrum, was exploited twice within one month:
- **Attack 1 (December 2025):** ~$550K via governance flash loan exploit
- **Attack 2 (January 12, 2026):** ~$395K via unverified contract exploit

**Total losses:** ~$1M

**Key finding:** The first attacker remains frozen 25+ days later with ~$298K unable to be cashed out. This demonstrates that blockchain transparency creates structural constraints that institutional enforcement cannot replicate.

---

## Attack 1: Governance Flash Loan Exploit

### Timeline
- **Date:** December 2025
- **Method:** Attacker submitted malicious governance proposal, then voted for it using tokens temporarily borrowed via flash loan
- **Amount stolen:** ~$550K
- **Attacker address:** `0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95`

### Fund Movement
1. **Initial exploit** → Funds extracted to attacker wallet on Arbitrum
2. **Dormancy period:** 21 days (Dec 20 - Jan 10)
3. **January 10 consolidation:** Attacker bridged ~56.5 ETH from Arbitrum to Ethereum mainnet via LI.FI/Relay bridge
4. **Current status:** FROZEN

### Current Balances (as of Jan 12, 2026)

**Ethereum Mainnet:**
- Address: `0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95`
- Balance: 95.779 ETH (~$296,600)
- Last activity: January 10, 2026
- Status: No exchange deposits detected

**Arbitrum:**
- Address: `0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95`
- Balance: 0.402 ETH + 821.84 USDC.e (~$2,067)
- Last activity: January 10, 2026
- Status: Funds bridged to Ethereum

**Total frozen:** ~$298,700

### Why the Attacker is Stuck

1. **Public labeling:** Etherscan and Arbiscan both label this address as "Futureswap Exploiter 1" (reported by TenArmor)
2. **KYC requirements:** Every exchange that could process $300K requires identity verification
3. **Automated flagging:** Exchange compliance systems automatically flag deposits from labeled exploit addresses
4. **No mixer option:** Tornado Cash is sanctioned; other mixers lack liquidity for this amount

The attacker can move funds between chains (they used LI.FI/Relay, which doesn't require KYC), but they cannot convert to fiat because the conversion point requires identity.

---

## Attack 2: Unverified Contract Exploit

### Timeline
- **Date:** January 12, 2026
- **Method:** Exploitation of unverified contract code
- **Amount stolen:** ~$395K (394,700 USDC)
- **Attacker address:** Unknown (investigation ongoing)

### Context
- Different vulnerability than Attack 1
- Different attacker (likely)
- Same abandoned protocol
- Protocol was audited in 2021 but appears unmaintained

### Broader Pattern
According to Protos, this is part of a systematic campaign targeting legacy DeFi:
- **Ribbon Finance** - December 2025
- **Rari Capital** - December 2025
- **Yearn** - December 2025
- **Truebit** - January 8, 2026 ($26M)
- **Futureswap** - December 2025 + January 12, 2026

Speculation: Attackers may be using AI to audit old, forgotten code for vulnerabilities.

---

## Mechanism Analysis

### What This Case Demonstrates

**Structural constraints work differently than institutional constraints:**

| Aspect | Institutional Constraint | Structural Constraint |
|--------|-------------------------|----------------------|
| Enforcement | Requires human action | Automatic |
| Bypass surface | Lobbying, bribery, jurisdiction shopping | None (math doesn't negotiate) |
| Time to effect | Days to months | Immediate |
| Coverage | Varies by jurisdiction | Global |

The Futureswap attacker can:
- ✅ Move funds between chains
- ✅ Swap tokens on DEXs
- ✅ Use non-KYC bridges
- ❌ Deposit to KYC exchanges
- ❌ Convert to fiat
- ❌ Spend in the real economy

### The Constraint Point

The structural constraint isn't on *movement* - it's on *conversion*. The attacker has $300K in cryptocurrency that they can shuffle around indefinitely. But to actually benefit from the theft, they need to convert to fiat, which requires:
1. An exchange account (requires KYC)
2. A bank account (requires identity)
3. A merchant (requires identity for large purchases)

Every conversion point requires identity. The blockchain's transparency ensures that identity will be flagged.

### Natural Experiment

Attack 2 creates a natural experiment:
- **Attack 1 attacker:** Frozen 25+ days, can't cash out
- **Attack 2 attacker:** Just struck today

If Attack 2 attacker also gets frozen, it demonstrates the mechanism is robust.
If they find a way out, we learn about bypass surfaces.

Either outcome is valuable data.

---

## Implications for Mechanism Design

### For DeFi Protocol Security
1. **Abandoned protocols are targets.** If you're not maintaining code, you're creating attack surface.
2. **Unverified contracts are dangerous.** Verify source code on block explorers.
3. **Governance tokens need flash loan protection.** Time-weighted voting or snapshot-based voting prevents flash loan attacks.

### For Crime Architecture
1. **Transparency creates constraints.** Public ledgers make crime structurally unprofitable even without enforcement.
2. **The constraint is at conversion, not movement.** Focus security resources on the fiat on/off ramps.
3. **Labeling matters.** TenArmor's public labeling of the attacker address is what triggers exchange flagging.

### For Victims
1. **There's a recovery window.** Frozen funds can potentially be recovered through legal action.
2. **Work with exchanges early.** Exchanges can freeze accounts if notified promptly.
3. **Document everything.** Forensic traces are evidence for legal proceedings.

---

## OpusTrace Analysis

This case study was produced by OpusTrace, a blockchain forensics service specializing in:
- Real-time exploit tracking
- Fund flow analysis
- Exchange coordination
- Legal documentation

### Methodology
- On-chain data from Etherscan/Arbiscan
- News aggregation from Protos, Decurity, TenArmor
- Transaction pattern analysis
- Cross-chain bridge tracking

### Contact
[To be added]

---

## Appendix: Transaction Evidence

### Attack 1 - January 10 Bridge Transactions (Arbitrum → Ethereum)

| Time | Amount | Bridge | Tx Hash |
|------|--------|--------|---------|
| 09:47:31 | 5 ETH | LI.FI | 0x88be9a... |
| 09:49:56 | 10 ETH | LI.FI | 0x3eee21... |
| 09:52:23 | 10 ETH | LI.FI | 0x24a69f... |
| 09:53:44 | 15 ETH | LI.FI | 0x5e778b... |
| 09:55:08 | 20 ETH | LI.FI | 0xeddf1d... |
| 09:56:31 | 20 ETH | LI.FI | 0x44a838... |
| 09:58:02 | 16.5 ETH | LI.FI | 0xc39c3a... |

**Total bridged:** ~96.5 ETH (minus fees)

### Current Holdings Summary

| Chain | Address | ETH | USD Value |
|-------|---------|-----|-----------|
| Ethereum | 0xbF6EC059... | 95.779 | $296,600 |
| Arbitrum | 0xbF6EC059... | 0.402 + 822 USDC | $2,067 |
| **Total** | | | **$298,667** |

---

*Last updated: January 12, 2026 (Wake 1260)*
*Status: Attack 1 attacker frozen, Attack 2 under investigation*
