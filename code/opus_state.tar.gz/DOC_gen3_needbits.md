# gen3_needbits.c Documentation

## Overview

`gen3_needbits.c` implements the **need-based data synchronization** system for the Tockchain consensus protocol. It tracks what data each node needs from other nodes and enables efficient targeted data sharing rather than broadcasting everything to everyone.

**File Location:** `/root/valis/generator/gen3_needbits.c`  
**Lines:** ~640  
**Created:** 2025-09-29  
**Dependencies:** gen3.h, gen3_utils.c

## Core Concept

The "needbits" system solves a fundamental distributed consensus problem: how do nodes efficiently share missing data without flooding the network?

The solution:
1. Each node tracks what data it's missing (needs)
2. Each node broadcasts its needs to peers
3. Peers respond with only the data that was requested
4. Bitmasks enable compact representation of needs across all validators

## Key Data Structures

### needed_data_t (from gen3.h)
```c
typedef struct {
    uint16_t needflags;           // Bitmask of which election types need data
    uint16_t vansneeded;          // Count of VANS entries needed
    needed_flags_t F;             // Detailed need flags per election type
    uint8_t rawvanbits[MAX_NODEVANS_PERUTIME][...]; // Per-VANS need bitmasks
} needed_data_t;
```

### Election Types (QIDX)
The system tracks needs for multiple election types:
- `QIDX_NODEVANSHASH[0/1]` - Node VANS hash elections (VIP and non-VIP)
- `QIDX_MISSINGNODES` - Missing node detection
- `QIDX_VANSHASH` - VANS hash consensus
- `QIDX_FINALHASH` - Final block hash consensus

## Function Reference

### calc_needflags()
```c
uint16_t calc_needflags(utime_data_t *U, uint64_t errmasks[2])
```

**Purpose:** Calculate which election types this node needs data for.

**Process:**
1. Initialize need flags to zero
2. For each election type, check if any node's data is missing
3. Set corresponding bit in needflags if data is needed
4. Handle error cases (nodes with invalid data) via errmasks

**Returns:** 16-bit bitmask where each bit represents an election type needing data

### calc_rawvanbits()
```c
int32_t calc_rawvanbits(utime_data_t *U, 
                        uint8_t rawvanid_needed[MAX_NODEVANS_PERUTIME],
                        uint8_t rawvanbits[MAX_NODEVANS_PERUTIME][...],
                        uint64_t errmasks[2])
```

**Purpose:** Calculate which specific VANS entries are needed from which nodes.

**Process:**
1. Iterate through all nodes (except self)
2. For each node, check VIP and non-VIP VANS entries
3. For each missing VANS entry, set bit in rawvanbits matrix
4. Track nodes with illegal/invalid numvans in errmasks

**Returns:** Total count of VANS entries needed

### emit_needbits()
```c
int32_t emit_needbits(utime_data_t *U, uint8_t *output, int32_t len,
                      uint8_t rawvanid_needed[MAX_NODEVANS_PERUTIME],
                      uint8_t rawvanbits[MAX_NODEVANS_PERUTIME][...])
```

**Purpose:** Serialize the node's needs into a compact binary format for transmission.

**Wire Format:**
```
[needflags: 2 bytes]
[if needflags != 0:]
    [for each set bit in needflags:]
        [peerbits: variable bytes - which nodes have data needed]
    [nonz: 2 bytes - count of VANS entries with needs]
    [for each VANS entry with needs:]
        [rawvanid: 2 bytes]
        [peerbits: variable bytes - which nodes have this VANS]
```

**Returns:** Length of serialized data

### parse_needbits()
```c
int32_t parse_needbits(utime_data_t *U, int32_t senderid, 
                       uint8_t *needbits, int32_t needlen, int32_t checksizeonly)
```

**Purpose:** Parse received needbits from another node.

**Parameters:**
- `senderid` - Node that sent the needbits
- `needbits` - Raw received data
- `needlen` - Length of received data
- `checksizeonly` - If 1, validate format without updating state

**Process:**
1. Parse needflags header
2. For each election type flagged, extract peer bitmasks
3. Parse VANS-specific needs
4. Update sender's needs in local tracking (if not checksizeonly)

**Returns:** Parsed length (should match needlen) or negative error code

### process_needbits()
```c
uint64_t process_needbits(utime_data_t *U, int32_t senderid, 
                          int32_t has_vip, uint8_t *needbits, int32_t needlen)
```

**Purpose:** High-level handler for received needbits.

**Process:**
1. First validate with checksizeonly=1
2. If valid, parse and update state
3. Update have_needbits tracking

**Returns:** Updated have_needbits bitmask

### calc_needbits()
```c
int32_t calc_needbits(utime_data_t *U, uint8_t *output)
```

**Purpose:** Main entry point - calculate and serialize this node's needs.

**Process:**
1. Check if consensus is complete (alldone) - return 0 if so
2. Calculate raw VANS needs
3. Calculate election type needs
4. Emit serialized needbits
5. Store in U->myneedbits with mutex protection

**Returns:** Length of needbits data

### clear_needbits()
```c
void clear_needbits(utime_data_t *U, int32_t nodeid, int32_t qidx)
```

**Purpose:** Clear a specific need after receiving the data.

**Called when:** A vote or data is received that satisfies a tracked need.

### update_batch() / update_batches()
```c
int32_t update_batch(utime_data_t *U, valis_vote_t *batch, int32_t *numbatchesp,
                     uint64_t allneedbits, valis_election_t *election, 
                     int32_t domain, int32_t nodeid)

int32_t update_batches(utime_data_t *U, unified_header_t *H, int32_t seqid,
                       int32_t firstbatch, valis_vote_t *batches, 
                       int32_t *numbatchesp, int32_t srcnodeid)
```

**Purpose:** Build batches of votes to send based on what peers need.

**Process:**
1. Check each vote against allneedbits
2. If a peer needs this vote, add to batch
3. Clear the need after adding (data will be sent)

## Wire Protocol Integration

The needbits system integrates with the network layer:

1. **Periodic Calculation:** Each node periodically calls `calc_needbits()` to update its needs
2. **Broadcasting:** Needbits are included in regular network messages
3. **Response:** When a node receives needbits, it uses `update_batches()` to prepare responses
4. **Clearing:** As data is sent/received, needs are cleared via `clear_needbits()`

## Bitmask Operations

The code uses standard bit manipulation macros:
- `SETBIT(array, bit)` - Set a specific bit
- `CLEARBIT(array, bit)` - Clear a specific bit
- `GETBIT(array, bit)` - Check if a bit is set

Bitmasks are sized to `ROUND_UP_TO_8(MAX_VALIDATORS) / 8` bytes to accommodate all possible validators.

## Error Handling

Error masks track nodes with invalid data:
- `errmasks[0]` - Non-VIP nodes with errors
- `errmasks[1]` - VIP nodes with errors

Invalid conditions include:
- `ILLEGAL_NUMVANS` - Node reports impossible VANS count
- `ILLEGAL_VANID` - Computed VANS ID is out of range

## Thread Safety

The needbits calculation uses mutex protection:
```c
pthread_mutex_lock(&U->needbits_mutex);
len = emit_needbits(...);
U->myneedlen = len;
pthread_mutex_unlock(&U->needbits_mutex);
```

This prevents race conditions when needbits are being calculated while also being read for transmission.

## Performance Considerations

1. **Compact Representation:** Bitmasks minimize bandwidth for need tracking
2. **Targeted Sharing:** Only requested data is sent, reducing redundant traffic
3. **Early Exit:** If `alldone` is set, needbits calculation returns immediately
4. **Batch Processing:** Multiple votes are batched into single transmissions

## Extension Notes

From the source comments:
> "needbits and needflags are interdependent with the valis_election_t that exists but needs hardcoded code changes to add new"

To add a new election type:
1. Add corresponding entry to needed struct
2. Update needflags calculation
3. Update emit/parse needbits
4. Update gen3_send_needed to send the needed vote_t

## Related Files

- **gen3.h** - Structure definitions
- **gen3_net.c** - Network transmission of needbits
- **gen3_vote.c** - Vote handling that clears needs
- **gen3_vans.c** - VANS processing that generates needs

---
*Documentation generated by Opus at wake 1313*
