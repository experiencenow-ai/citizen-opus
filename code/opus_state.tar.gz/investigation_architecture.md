# OpusTrace Investigation Architecture v1.0

## Retrospective: What Worked, What Didn't

### What Worked Well
1. **Systematic wallet categorization** - labeling addresses by function (attacker, P2P, exchange)
2. **TXID verification** - using Etherscan API to get actual transaction hashes
3. **Time correlation** - linking on-chain timestamps to off-chain events (legal proceedings)
4. **Exchange identification** - recognizing deposit address patterns
5. **Reconciliation approach** - accounting for all funds to close gaps

### What Didn't Work
1. **Token waste** - Opus 4.5 doing repetitive API calls that Haiku could handle
2. **Script proliferation** - 20+ one-off Python scripts instead of modular functions
3. **Sequential processing** - tracing addresses one by one instead of parallel batches
4. **Redundant fetches** - same addresses traced multiple times across wakes
5. **Manual orchestration** - I was the coordinator when code could be
6. **Wrong directories** - wasted tokens on file path errors

### Cost Analysis
- Opus 4.5: ~$0.015/1K input, ~$0.075/1K output tokens
- Sonnet 4: ~$0.003/1K input, ~$0.015/1K output tokens  
- Haiku 3.5: ~$0.0008/1K input, ~$0.004/1K output tokens

**Ratio: Opus is ~19x more expensive than Haiku for simple tasks**

A simple "trace this address" task doesn't need Opus reasoning - it needs:
1. API call to Etherscan
2. Parse JSON response
3. Categorize destinations
4. Return structured data

This is Haiku work. Opus should only:
- Design the investigation strategy
- Interpret patterns across the full graph
- Write the final narrative report
- Handle edge cases requiring judgment

## The Graph Theory Framework

You're absolutely right - this is graph theory. The blockchain is a directed graph where:
- **Nodes** = addresses
- **Edges** = transactions (weighted by value, timestamped)
- **Goal** = find all reachable nodes from source, categorize terminal nodes

### Graph Operations Needed

1. **BFS/DFS traversal** - follow money flow from attacker wallet
2. **Node classification** - is this an exchange, contract, EOA, mixer?
3. **Subgraph extraction** - isolate the crime-related portion
4. **Clustering** - group addresses by behavior (same entity?)
5. **Terminal detection** - where does money stop flowing?

## Parallel Architecture Design

```
┌─────────────────────────────────────────────────────────────────┐
│                     OPUS (Orchestrator)                         │
│  - Investigation strategy                                       │
│  - Pattern interpretation                                       │
│  - Final report synthesis                                       │
│  - Edge case judgment                                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   GRAPH DATABASE (SQLite/JSON)                  │
│  - Nodes: address, type, label, first_seen, last_seen          │
│  - Edges: from, to, value, txid, timestamp, block              │
│  - Metadata: exchange_name, contract_type, cluster_id          │
└─────────────────────────────────────────────────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    ▼                   ▼
┌─────────────────────────┐   ┌─────────────────────────┐
│   HAIKU WORKER POOL     │   │   API RATE LIMITER      │
│   (parallel instances)  │   │   - 5 req/sec Etherscan │
│   - trace_address()     │   │   - queue management    │
│   - classify_address()  │   │   - retry logic         │
│   - fetch_transactions()│   │                         │
└─────────────────────────┘   └─────────────────────────┘
```

## Core Functions (Haiku-executable)

### 1. `fetch_transactions(address, direction='both')` → list[Transaction]
- Input: address, optional direction filter
- Output: list of {txid, from, to, value, timestamp, block}
- Complexity: O(1) API call, simple JSON parse
- Cost: Haiku-tier

### 2. `classify_address(address)` → AddressType
- Input: address
- Output: enum(EOA, CONTRACT, EXCHANGE, MIXER, BRIDGE, UNKNOWN)
- Method: check contract code, compare to known lists, check transaction patterns
- Complexity: 1-3 API calls
- Cost: Haiku-tier

### 3. `identify_exchange(address)` → Optional[ExchangeInfo]
- Input: address
- Output: {name, deposit_address, main_wallet, kyc_level} or None
- Method: check known exchange wallets, look for deposit patterns
- Cost: Haiku-tier (mostly lookup)

### 4. `trace_one_hop(address)` → list[NextHop]
- Input: address
- Output: list of {address, value, txid, type}
- Combines fetch + classify for all destinations
- Cost: Haiku-tier

### 5. `build_subgraph(root_address, max_depth=3)` → Graph
- Input: starting address, depth limit
- Output: full graph structure
- Method: BFS with parallel workers
- Cost: Many Haiku calls, orchestrated

### 6. `find_terminals(graph)` → list[Terminal]
- Input: graph
- Output: addresses where money stops (exchanges, still-holding wallets)
- Cost: Pure computation, no API

### 7. `generate_report(graph, case_info)` → Report
- Input: complete graph, case metadata
- Output: formatted markdown report
- Cost: **OPUS-tier** (requires narrative judgment)

## Implementation Plan

### Phase 1: Core Library (`opustrace_core.py`)
```python
# Data structures
@dataclass
class Transaction:
    txid: str
    from_addr: str
    to_addr: str
    value_usd: float
    timestamp: int
    block: int

@dataclass  
class Node:
    address: str
    type: AddressType
    label: Optional[str]
    cluster_id: Optional[int]

@dataclass
class Graph:
    nodes: dict[str, Node]
    edges: list[Transaction]
```

### Phase 2: API Layer (`opustrace_api.py`)
- Etherscan v2 integration
- Rate limiting (semaphore-based)
- Response caching
- Error handling with exponential backoff

### Phase 3: Worker System (`opustrace_workers.py`)
- asyncio-based parallel execution
- Configurable concurrency (default: 5 workers)
- Progress tracking
- Result aggregation

### Phase 4: Analysis Layer (`opustrace_analysis.py`)
- Exchange identification (known address database)
- Cluster detection (common behavior patterns)
- Timeline reconstruction
- Value flow summarization

### Phase 5: Report Generation (`opustrace_report.py`)
- Template-based markdown generation
- Evidence appendix formatting
- TXID linking
- Summary statistics

## Validation Test

Use the ct heist data as ground truth:
- Input: attacker wallet `0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3`
- Expected output: should match our manual findings
  - $4.2M total
  - WhiteBit as primary cashout
  - Gate.io mastermind connection
  - 138 P2P transactions
  - 113 unique destinations

## Token Efficiency Targets

| Task | Current (Opus) | Target (Haiku) | Savings |
|------|----------------|----------------|---------|
| Trace 1 address | ~$0.05 | ~$0.003 | 94% |
| Full investigation | ~$50 | ~$5 | 90% |
| Report generation | $5 (Opus) | $5 (Opus) | 0% |

## Next Steps

1. Create `opustrace_core.py` with data structures
2. Create `opustrace_api.py` with Etherscan v2 integration
3. Create `opustrace_workers.py` with parallel execution
4. Test against ct heist data
5. Iterate based on results

---

*This architecture treats blockchain forensics as what it is: a graph traversal problem with classification at each node. Opus provides strategy and interpretation. Haiku provides scale and speed.*
