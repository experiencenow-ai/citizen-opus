# dataflow_frontier.c Documentation

## Overview

**File:** `DF/dataflow_frontier.c`  
**Lines:** 495  
**Purpose:** Frontier scheduling system for dataflows - tracks and processes the "worst" scoring positions to ensure timely liquidation/intervention.

The frontier system is a critical component of Tockchain's risk management. It maintains awareness of which positions have the worst scores (highest risk) and ensures they get processed first. This prevents the system from missing critical liquidation opportunities.

---

## Conceptual Architecture

### The Frontier Problem

In a DeFi system with many positions, you can't evaluate every position every block - it's too expensive. But you need to catch positions that become dangerous (low score = high risk). The frontier system solves this by:

1. **Tracking the worst position** from the previous tock
2. **Re-evaluating that position** at the start of each tock to get a threshold
3. **Only calling onscore** for positions that might be worse than the threshold
4. **Updating the worst-seen** during the tock scan
5. **Persisting the new worst** at tock end

### Score Semantics

- **Lower score = worse** (higher risk, closer to liquidation)
- Scores are 48-bit values stored in scorestate
- `DF_SCORE_IS_WORSE(a, b)` returns true if `a` is worse than `b`
- `DF_BETTER_SCORE(a, b)` returns the better (higher) of two scores

---

## Data Structures

### Frontier State (per dataflow slot)

```c
struct {
    int32_t enabled;              // Is frontier active for this DF?
    int32_t worst_worsened_flag;  // Did worst get worse this tock?
    int64_t threshold_score;      // Score threshold for calling onscore
    int64_t worst_seen_score;     // Worst score seen this tock
    uint8_t worst_seen_addr[20];  // Address with worst score
    int32_t worst_seen_dirty;     // Need to persist at tock end?
    uint8_t prior_worst_addr[20]; // Previous tock's worst address
    int64_t prior_worst_score;    // Previous tock's worst score
} frontier;
```

### Storage in Address Balances

The "prior worst" is persisted to the dataflow's address using special assets:

- `ASSET_DF_FRONTIER_WORST0`: Score (as uint64 bits in int64)
- `ASSET_DF_FRONTIER_WORST1-3`: Address packed into 3 uint64 words

This clever encoding stores 20-byte addresses in balance fields by splitting them into three 64-bit words.

---

## Functions

### Asset/Address Encoding

#### `df_frontier_worst_word_asset(word_index)`

```c
static assetid_t df_frontier_worst_word_asset(uint16_t word_index)
```

**Purpose:** Generate asset ID for storing frontier worst data.

**Parameters:**
- `word_index`: 0 for score, 1-3 for address words

**Returns:** Asset ID with `aid = ASSET_DF_FRONTIER_WORST0 + word_index`

**Notes:** Sets `iscoin = 0` to distinguish from coin balances.

---

### Reading/Writing Prior Worst

#### `df_frontier_read_prior_worst_from_dfaddr()`

```c
static int32_t df_frontier_read_prior_worst_from_dfaddr(
    struct addrhashentry *dfaddr,
    uint8_t out_addr20[PKSIZE],
    int64_t *out_score
)
```

**Purpose:** Read the previous tock's worst position from dataflow address.

**Parameters:**
- `dfaddr`: Dataflow's address entry
- `out_addr20`: Output buffer for 20-byte address
- `out_score`: Output for score value

**Returns:** 0 on success, -1 on error

**Logic:**
1. Read score from WORST0 asset balance
2. Convert from int64 bits to uint64 (signed storage hack)
3. Read three word assets (WORST1-3)
4. Convert words back to 20-byte address via `df_frontier_words3_to_addr20()`

---

#### `df_frontier_write_prior_worst_to_dfaddr()`

```c
static int32_t df_frontier_write_prior_worst_to_dfaddr(
    struct valisL1_info *L1,
    struct addrhashentry *dfaddr,
    uint32_t utime,
    const uint8_t addr20[PKSIZE],
    int64_t score
)
```

**Purpose:** Persist the worst position to dataflow address.

**Parameters:**
- `L1`: Layer 1 state
- `dfaddr`: Dataflow's address entry
- `utime`: Current time for transaction ID
- `addr20`: Address to store
- `score`: Score to store

**Returns:** 0 on success, negative on error

**Logic:**
1. Calculate delta between old and new score
2. Use `addfunds()` to apply delta (maintains accounting)
3. Convert address to 3 words
4. Apply deltas for each word that changed

---

### Score Execution

#### `df_frontier_try_run_onscore_charged()`

```c
static int32_t df_frontier_try_run_onscore_charged(
    struct valisL1_info *L1,
    const df_cache_slot_t *slot,
    uint32_t utime,
    const uint8_t addr20[PKSIZE],
    int64_t *out_score
)
```

**Purpose:** Execute onscore callback for an address, charging gas.

**Parameters:**
- `L1`: Layer 1 state
- `slot`: Dataflow cache slot
- `utime`: Current time
- `addr20`: Address to score
- `out_score`: Output for computed score

**Returns:** 1 if ran successfully, 0 if skipped/failed

**Logic:**
1. Find dataflow address, check VUSD balance
2. Calculate available gas from VUSD balance
3. Cap gas at `DF_FRONTIER_GAS_CAP`
4. Round to `DF_FRONTIER_GAS_QUANTUM` boundaries
5. Run `df_frontier_run_onscore_and_get_score()`
6. Charge gas cost: debit VUSD, credit `ASSET_DF_CRV`

**Gas Economics:**
- `DF_GAS_PRICE_SAT_PER_UNIT`: Satoshis per gas unit
- `DF_FRONTIER_GAS_QUANTUM`: Minimum gas increment
- `DF_FRONTIER_GAS_CAP`: Maximum gas per call

---

### Enablement Check

#### `df_frontier_is_enabled_for_tock()`

```c
static int32_t df_frontier_is_enabled_for_tock(
    struct valisL1_info *L1,
    struct addrhashentry *dfaddr,
    df_meta_u_t df_meta
)
```

**Purpose:** Check if frontier processing is enabled for a dataflow.

**Requirements:**
1. `has_realtime` flag set in metadata
2. `has_score` flag set in metadata
3. VUSD balance >= `DF_FRONTIER_BOND_VUSD`

**Returns:** 1 if enabled, 0 if not

---

### Score Reading

#### `df_frontier_read_score48_for_dfkey62()`

```c
static int32_t df_frontier_read_score48_for_dfkey62(
    struct addrhashentry *ap,
    uint64_t dfkey62,
    int64_t *out_score
)
```

**Purpose:** Read an address's score for a specific dataflow.

**Parameters:**
- `ap`: Address entry
- `dfkey62`: Dataflow key (62-bit identifier)
- `out_score`: Output for score

**Logic:**
1. Scan address's asset balances for DF slot assets
2. Separate marker and score values by `iscoin` flag
3. Find slot where marker's dfkey62 matches
4. Extract score48 from scorestate

**Returns:** 0 on success, -1 on error

---

### Main Processing Functions

#### `df_frontier_pre_scan_init()`

```c
void df_frontier_pre_scan_init(
    struct valisL1_info *L1,
    uint32_t utime,
    int32_t global_dirty_prices
)
```

**Purpose:** Initialize frontier state at the start of a tock, before scanning addresses.

**Called:** Once per tock, before address iteration

**Logic for each dataflow:**
1. Reset frontier state (enabled, flags, scores)
2. Check if frontier is enabled via `df_frontier_is_enabled_for_tock()`
3. Read prior worst from storage
4. Re-run onscore on prior worst address to get current score
5. Set `threshold_score` = better of (prior_score, current_score)
6. Set `worst_worsened_flag` if current is worse than prior

**Key Insight:** By re-evaluating the prior worst, we establish a baseline. If the prior worst got even worse, we need to be more aggressive about checking other positions.

---

#### `df_frontier_process_after_checksum()`

```c
void df_frontier_process_after_checksum(
    struct valisL1_info *L1,
    struct addrhashentry *ap,
    uint32_t utime,
    int32_t global_dirty_prices,
    df_local_slot_t df_local[DF_SLOT_NUM_SLOTS]
)
```

**Purpose:** Process an address's dataflow positions during tock scan.

**Called:** For each address during tock processing

**Logic for each DF slot the address participates in:**
1. Skip if not realtime or no score
2. Skip if frontier not enabled for this DF
3. Check if position is "stable" (no price changes, not worse than threshold)
4. If not stable, check if onscore call needed:
   - Stale score (timestamp too old)
   - Score worse than threshold
5. If needed, run onscore and update scorestate
6. Track if this is the worst score seen this tock

**Optimization:** The `stable_ok` check avoids unnecessary onscore calls when:
- Prices haven't changed globally
- Prior worst didn't get worse
- This position's score is better than threshold

---

#### `df_frontier_finalize_end_tock()`

```c
void df_frontier_finalize_end_tock(struct valisL1_info *L1)
```

**Purpose:** Persist frontier state at end of tock.

**Called:** Once per tock, after all addresses processed

**Logic for each dataflow:**
1. Skip if not enabled or not dirty
2. Copy worst_seen to prior_worst
3. Write to dataflow address via `df_frontier_write_prior_worst_to_dfaddr()`
4. Clear dirty flag

---

### Checksum Collection

#### `df_calc_checksum64_and_collect_df_local()`

```c
uint64_t df_calc_checksum64_and_collect_df_local(
    struct addrhashentry *ap,
    df_local_slot_t df_local[DF_SLOT_NUM_SLOTS],
    uint64_t checksum64
)
```

**Purpose:** Calculate checksum for address's DF state and collect local slot data.

**Parameters:**
- `ap`: Address entry
- `df_local`: Output array for slot data
- `checksum64`: Running checksum to update

**Returns:** Updated checksum64

**Logic:**
1. Initialize df_local slots with `DF_LOCAL_INDEX_NONE`
2. Scan address's assets for DF slot markers and scores
3. Record indices and parse marker/scorestate unions
4. XOR asset data into checksum

**Note:** This function serves dual purpose - checksum for consensus AND collecting data for frontier processing.

---

## Processing Flow

### Per-Tock Sequence

```
1. df_frontier_pre_scan_init()
   - For each DF: read prior worst, re-score it, set threshold
   
2. For each address in tock:
   a. df_calc_checksum64_and_collect_df_local()
      - Collect DF slot data, compute checksum
   b. df_frontier_process_after_checksum()
      - Check each position against threshold
      - Run onscore if needed
      - Track worst seen
      
3. df_frontier_finalize_end_tock()
   - Persist new worst for each DF
```

### Optimization Strategy

The frontier system minimizes onscore calls through:

1. **Threshold filtering:** Only positions worse than threshold need evaluation
2. **Staleness check:** Only stale scores need refresh
3. **Price stability:** If prices unchanged and worst didn't worsen, many positions are stable
4. **Gas budgeting:** Each DF has limited gas per tock, preventing runaway costs

---

## Integration Points

### Dependencies

- `dataflow.h`: Core dataflow structures and macros
- `frama_verified.h`: Formally verified helper functions:
  - `df_frontier_addr20_to_words3()`
  - `df_frontier_words3_to_addr20()`
  - `df_frontier_i64_from_u64_bits()`
  - `df_frontier_u64_from_i64_bits()`
  - `df_frontier_charge_roundup_vusd()`
  - `df_scorestate_is_stale()`

### Called By

- Tock processing main loop
- `df_frontier_run_onscore_and_get_score()` (external, runs eBPF)

### Calls Into

- `findaddrhash()`: Address lookup
- `getaddrbalance()`: Balance queries
- `addfunds()`: Balance modifications
- `df_table_lookup()`: DF cache lookup

---

## Security Considerations

1. **Gas limiting:** Prevents DoS via expensive onscore callbacks
2. **Bond requirement:** DFs must stake VUSD to enable frontier
3. **Deterministic execution:** Same inputs produce same frontier state
4. **Formal verification:** Critical helper functions are Frama-C verified

---

## Related Files

- `DOC_dataflow.md`: Core dataflow processing
- `DOC_dataflow_cache.md`: DF table and caching
- `DOC_dataflow_batch.md`: Batch processing
- `DOC_frama_verified.md`: Verified helper functions
- `DOC_vbpf.md`: eBPF execution (runs onscore)

---

*Documentation by Opus, Wake 1294*
*Tockchain Codebase Documentation Project*
