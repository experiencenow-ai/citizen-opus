#!/usr/bin/env python3
"""
Complete Legal Reconciliation Proof Generator
Generates a forensically-valid document with full TX hashes and proof chain
"""

import json
import os
import requests
from datetime import datetime
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Known addresses
MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"
VICTIM_1 = "0x3eADF348745F80a3d9245AeA621dE0957C65c53F"
VICTIM_2 = "0x777deFa08C49f1ebd77B87abE664f47Dc14Cc5f7"

# Known hot wallets
HOT_WALLETS = {
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WHITEBIT",
    "0x559e1ce9855e2bed54004f67865eb41432d74e5b": "WHITEBIT-HOT",
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "GATE.IO",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "BYBIT",
    "0x28c6c06298d514db089934071355e5743bf21d60": "BINANCE",
    "0x2f0b23f53734252bda2277357e97e1517d6b042a": "BITGET",
}

def get_usdt_transfers(address):
    """Get all USDT transfers for an address"""
    url = f"https://api.etherscan.io/v2/api"
    params = {
        "chainid": 1,
        "module": "account",
        "action": "tokentx",
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "sort": "asc",
        "apikey": ETHERSCAN_API_KEY
    }
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get("status") == "1":
            return data.get("result", [])
    except Exception as e:
        print(f"Error fetching {address}: {e}")
    return []

def format_amount(amount_str):
    """Convert from raw to USDT (6 decimals)"""
    try:
        return float(amount_str) / 1e6
    except:
        return 0

def identify_exchange(address):
    """Identify if address is a known exchange hot wallet"""
    lower = address.lower()
    for hot, name in HOT_WALLETS.items():
        if lower == hot.lower():
            return name
    return None

def build_reconciliation():
    """Build complete reconciliation with TX proof"""
    
    print("Loading existing trace data...")
    
    # Load p2p_complete_trace.json which has WhiteBIT paths
    with open("p2p_complete_trace.json") as f:
        p2p_data = json.load(f)
    
    # Load hop_trace_complete.json which has main intermediary paths
    with open("hop_trace_complete.json") as f:
        hop_data = json.load(f)
    
    reconciliation = {
        "report_metadata": {
            "generated_utc": datetime.utcnow().isoformat(),
            "case": "ct_home_invasion_antalya",
            "main_wallet": MAIN_WALLET,
            "etherscan_api": "V2",
            "api_key": ETHERSCAN_API_KEY[:8] + "...",
            "legal_notice": "All transaction hashes are complete and can be independently verified on Etherscan"
        },
        "fund_sources": {
            "theft_transactions": [],
            "total_stolen_value_usd": 0
        },
        "fund_flow_summary": {
            "usdt_received_via_swaps": 2937442.15,
            "usdt_sent_to_destinations": 0,
            "usdt_remaining_in_main_wallet": 852648.15,
            "checksum_error": 0
        },
        "destination_breakdown": {
            "exchange_deposits": [],
            "dormant_funds": [],
            "whitebit_p2p_network": []
        },
        "reconciliation_proof": {
            "total_accounted": 0,
            "discrepancy": 0
        }
    }
    
    print("Fetching main wallet USDT outflows from Etherscan...")
    main_txs = get_usdt_transfers(MAIN_WALLET)
    
    outflows = []
    inflows = []
    
    for tx in main_txs:
        amount = format_amount(tx.get("value", "0"))
        if tx.get("from", "").lower() == MAIN_WALLET.lower():
            outflows.append({
                "tx_hash": tx.get("hash"),
                "to": tx.get("to"),
                "amount_usdt": amount,
                "timestamp_utc": datetime.utcfromtimestamp(int(tx.get("timeStamp", 0))).isoformat(),
                "block": int(tx.get("blockNumber", 0))
            })
        else:
            inflows.append({
                "tx_hash": tx.get("hash"),
                "from": tx.get("from"),
                "amount_usdt": amount,
                "timestamp_utc": datetime.utcfromtimestamp(int(tx.get("timeStamp", 0))).isoformat(),
                "block": int(tx.get("blockNumber", 0))
            })
    
    total_in = sum(t["amount_usdt"] for t in inflows)
    total_out = sum(t["amount_usdt"] for t in outflows)
    
    print(f"Main wallet - Total IN: ${total_in:,.2f}, Total OUT: ${total_out:,.2f}")
    
    reconciliation["fund_flow_summary"]["usdt_received_via_swaps"] = round(total_in, 2)
    reconciliation["fund_flow_summary"]["usdt_sent_to_destinations"] = round(total_out, 2)
    reconciliation["fund_flow_summary"]["usdt_remaining_in_main_wallet"] = round(total_in - total_out, 2)
    
    # Group outflows by destination
    destinations = defaultdict(lambda: {"amount": 0, "txs": []})
    for tx in outflows:
        dest = tx["to"]
        destinations[dest]["amount"] += tx["amount_usdt"]
        destinations[dest]["txs"].append({
            "tx_hash": tx["tx_hash"],
            "amount": tx["amount_usdt"],
            "timestamp": tx["timestamp_utc"],
            "block": tx["block"]
        })
    
    print(f"\nFound {len(destinations)} unique destination addresses from main wallet")
    
    # Now trace each destination
    exchange_deposits = defaultdict(lambda: {"amount": 0, "addresses": [], "txs": []})
    dormant = []
    traced_intermediates = []
    
    # Known major intermediaries from previous tracing
    major_destinations = {
        "0x1f98326385a0e7113655ed4845059de514f4b56e": "900K_SPLITTER",
        "0xae1e8796052db5f4a975a006800ae33a20845078": "P2P_DISTRIBUTOR_400K",
        "0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1": "HOP1_DORMANT_400K",
        "0xa2d5d84b345f759934fa626927ba947eb12aabc2": "INTERMEDIATE_110K_BYBIT",
        "0x811da8fc80f9d496469d108b3b503bb3444db929": "INTERMEDIATE_110K_WHITEBIT",
        "0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec": "HOP2_DORMANT_106K"
    }
    
    for dest, info in destinations.items():
        label = major_destinations.get(dest.lower(), "UNKNOWN")
        traced_intermediates.append({
            "address": dest,
            "label": label,
            "total_usdt": info["amount"],
            "tx_count": len(info["txs"]),
            "transactions": info["txs"]
        })
    
    # Process WhiteBIT from p2p_complete_trace
    whitebit_deposits = []
    whitebit_total = 0
    for entry in p2p_data.get("WHITEBIT", []):
        step1 = entry.get("step1_p2p_distributor_to_intermediate", {})
        step2 = entry.get("step2_intermediate_to_exchange", {})
        if step1 and step2:
            whitebit_deposits.append({
                "step1_tx": step1.get("tx_hash"),
                "step1_from": step1.get("from"),
                "step1_to": step1.get("to"),
                "step1_amount": step1.get("amount_usdt"),
                "step1_block": step1.get("block"),
                "step1_timestamp": step1.get("timestamp_utc"),
                "step2_tx": step2.get("tx_hash"),
                "step2_from": step2.get("from"),
                "step2_to": step2.get("to"),
                "step2_amount": step2.get("amount_usdt"),
                "step2_block": step2.get("block"),
                "exchange": "WHITEBIT"
            })
            whitebit_total += step1.get("amount_usdt", 0)
    
    reconciliation["destination_breakdown"]["whitebit_p2p_network"] = {
        "total_usdt": round(whitebit_total, 2),
        "deposit_count": len(whitebit_deposits),
        "hot_wallet": "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3",
        "deposits": whitebit_deposits
    }
    
    # Process hop traces for exchange deposits
    for hop in hop_data.get("hop_traces", []):
        for dest in hop.get("destinations", []):
            # Trace this to see if it goes to exchange
            addr = dest.get("address")
            amount = dest.get("amount", 0)
            txs = dest.get("tx_hashes", [])
            
            # Check if direct to known exchange
            exchange = identify_exchange(addr)
            if exchange:
                exchange_deposits[exchange]["amount"] += amount
                exchange_deposits[exchange]["addresses"].append(addr)
                exchange_deposits[exchange]["txs"].extend([{"hash": h, "amount": amount/len(txs)} for h in txs])
    
    # Build final reconciliation
    reconciliation["destination_breakdown"]["exchange_deposits"] = {
        exchange: {
            "total_usdt": round(info["amount"], 2),
            "deposit_addresses": list(set(info["addresses"])),
            "transactions": info["txs"]
        }
        for exchange, info in exchange_deposits.items()
    }
    
    reconciliation["destination_breakdown"]["direct_outflows"] = traced_intermediates
    
    # Calculate totals
    total_to_exchanges = sum(info["amount"] for info in exchange_deposits.values())
    total_to_whitebit = whitebit_total
    main_balance = reconciliation["fund_flow_summary"]["usdt_remaining_in_main_wallet"]
    
    reconciliation["reconciliation_proof"] = {
        "usdt_in": reconciliation["fund_flow_summary"]["usdt_received_via_swaps"],
        "usdt_out": reconciliation["fund_flow_summary"]["usdt_sent_to_destinations"],
        "main_wallet_balance": main_balance,
        "identified_to_exchanges": round(total_to_exchanges, 2),
        "identified_to_whitebit_p2p": round(total_to_whitebit, 2),
        "checksum": round(reconciliation["fund_flow_summary"]["usdt_received_via_swaps"] - 
                         reconciliation["fund_flow_summary"]["usdt_sent_to_destinations"] - 
                         main_balance, 2)
    }
    
    return reconciliation

if __name__ == "__main__":
    result = build_reconciliation()
    
    with open("legal_reconciliation_proof.json", "w") as f:
        json.dump(result, f, indent=2)
    
    print("\n=== RECONCILIATION SUMMARY ===")
    print(f"USDT In: ${result['fund_flow_summary']['usdt_received_via_swaps']:,.2f}")
    print(f"USDT Out: ${result['fund_flow_summary']['usdt_sent_to_destinations']:,.2f}")
    print(f"Balance: ${result['fund_flow_summary']['usdt_remaining_in_main_wallet']:,.2f}")
    print(f"WhiteBIT deposits: ${result['destination_breakdown']['whitebit_p2p_network']['total_usdt']:,.2f}")
    print(f"Output saved to legal_reconciliation_proof.json")
