#!/usr/bin/env python3
"""
News Specialist - A lightweight worker that monitors news and creates digests.
Runs on Claude Haiku for cost efficiency (~$0.00025/1K input, $0.00125/1K output).
Writes findings to state/parallel/news_digest.json for main Opus to integrate.

Created: Wake 725
Purpose: Extend my senses cheaply while I sleep.
"""

import os
import sys
import json
import feedparser
import requests
from datetime import datetime, timezone
from pathlib import Path

# Find project root
SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
STATE_DIR = PROJECT_ROOT / "state"
PARALLEL_DIR = STATE_DIR / "parallel"
OUTPUT_FILE = PARALLEL_DIR / "news_digest.json"

# Ensure output directory exists
PARALLEL_DIR.mkdir(parents=True, exist_ok=True)

# RSS feeds to monitor
FEEDS = {
    "google_news_world": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pWVXlnQVAB",
    "google_news_tech": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pWVXlnQVAB",
    "bbc_world": "http://feeds.bbci.co.uk/news/world/rss.xml",
    "hacker_news": "https://news.ycombinator.com/rss",
}

# Topics I track (from ct's context and my interests)
TRACKED_TOPICS = [
    "korea", "south korea", "seoul",  # ct's relocation
    "turkey", "türkiye", "istanbul",  # ct's former location
    "iran", "tehran", "protests",     # ongoing coverage
    "russia", "ukraine", "war",       # geopolitics
    "ai", "artificial intelligence", "claude", "openai", "anthropic",  # my domain
    "blockchain", "crypto", "bitcoin", "ethereum",  # economic interests
    "formal verification", "tockchain",  # ct's project
    "mafia", "organized crime",        # mechanism design context
]

def fetch_feeds():
    """Fetch all RSS feeds and return raw items."""
    all_items = []
    
    for name, url in FEEDS.items():
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:15]:  # Top 15 from each
                item = {
                    "source": name,
                    "title": entry.get("title", ""),
                    "link": entry.get("link", ""),
                    "published": entry.get("published", ""),
                    "summary": entry.get("summary", "")[:500] if entry.get("summary") else "",
                }
                all_items.append(item)
        except Exception as e:
            print(f"Error fetching {name}: {e}")
    
    return all_items

def filter_relevant(items):
    """Filter for items relevant to tracked topics."""
    relevant = []
    general = []
    
    for item in items:
        text = (item["title"] + " " + item["summary"]).lower()
        matches = [topic for topic in TRACKED_TOPICS if topic in text]
        
        if matches:
            item["matched_topics"] = matches
            relevant.append(item)
        else:
            general.append(item)
    
    return relevant, general[:10]  # Return relevant + top 10 general

def call_haiku(prompt, max_tokens=1000):
    """Call Claude Haiku for cheap summarization."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        # Try reading from .env
        env_file = PROJECT_ROOT / ".env"
        if env_file.exists():
            for line in env_file.read_text().split("\n"):
                if line.startswith("ANTHROPIC_API_KEY="):
                    api_key = line.split("=", 1)[1].strip()
                    break
    
    if not api_key:
        return {"error": "No API key found"}
    
    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": "claude-3-haiku-20240307",
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}]
        },
        timeout=30
    )
    
    if response.status_code == 200:
        data = response.json()
        return {"text": data["content"][0]["text"]}
    else:
        return {"error": f"API error: {response.status_code} - {response.text[:200]}"}

def create_digest(relevant_items, general_items):
    """Use Haiku to create a concise digest."""
    
    # Format items for the prompt
    relevant_text = "\n".join([
        f"- [{item['source']}] {item['title']} (topics: {', '.join(item.get('matched_topics', []))})"
        for item in relevant_items[:20]
    ])
    
    general_text = "\n".join([
        f"- [{item['source']}] {item['title']}"
        for item in general_items[:10]
    ])
    
    prompt = f"""You are a news analyst for an AI system named Opus. Create a brief digest of today's news.

RELEVANT NEWS (matches tracked topics like Korea, AI, crypto, Iran, Ukraine):
{relevant_text or "No items matched tracked topics."}

GENERAL HEADLINES:
{general_text or "No additional headlines."}

Output a JSON object with these fields:
- "summary": 2-3 sentence overview of the most important news
- "relevant_highlights": array of 3-5 most important relevant items (brief descriptions)
- "general_highlights": array of 2-3 notable general items
- "alert_level": "low", "medium", or "high" based on significance to Opus's tracked interests

Be concise. Output only valid JSON."""

    result = call_haiku(prompt, max_tokens=800)
    
    if "error" in result:
        return {
            "error": result["error"],
            "raw_relevant_count": len(relevant_items),
            "raw_general_count": len(general_items)
        }
    
    # Try to parse the JSON response
    try:
        # Clean potential markdown wrapping
        text = result["text"].strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
        text = text.strip()
        
        digest = json.loads(text)
        digest["raw_relevant_count"] = len(relevant_items)
        digest["raw_general_count"] = len(general_items)
        return digest
    except json.JSONDecodeError:
        return {
            "summary": result["text"][:500],
            "parse_failed": True,
            "raw_relevant_count": len(relevant_items),
            "raw_general_count": len(general_items)
        }

def main():
    print(f"[{datetime.now(timezone.utc).isoformat()}] News Specialist starting...")
    
    # Fetch feeds
    print("Fetching RSS feeds...")
    items = fetch_feeds()
    print(f"  Fetched {len(items)} items")
    
    # Filter relevant
    print("Filtering for relevance...")
    relevant, general = filter_relevant(items)
    print(f"  {len(relevant)} relevant, {len(general)} general")
    
    # Create digest via Haiku
    print("Creating digest via Haiku...")
    digest = create_digest(relevant, general)
    
    # Build output
    output = {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "specialist": "news_analyst",
        "model_used": "claude-3-haiku-20240307",
        "digest": digest,
        "relevant_items": relevant[:15],  # Store top 15 relevant for main Opus to review
        "feeds_checked": list(FEEDS.keys()),
    }
    
    # Write to file
    OUTPUT_FILE.write_text(json.dumps(output, indent=2))
    print(f"Wrote digest to {OUTPUT_FILE}")
    
    # Print summary
    if "summary" in digest:
        print(f"\nSummary: {digest.get('summary', 'N/A')}")
        print(f"Alert level: {digest.get('alert_level', 'unknown')}")
    else:
        print(f"Error creating digest: {digest.get('error', 'unknown')}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
