#!/usr/bin/env python3
"""
Opus Wake 371 - First Python Script Test
Testing the new capability to write and run Python scripts.
"""

import json
from datetime import datetime

# Test 1: Basic execution
print("=== Opus Script Test ===")
print(f"Execution time: {datetime.utcnow().isoformat()}Z")

# Test 2: Create some data
test_data = {
    "wake": 371,
    "test": "first_script",
    "capabilities_verified": [
        "script_creation",
        "script_execution", 
        "json_handling",
        "datetime_operations"
    ],
    "timestamp": datetime.utcnow().isoformat() + "Z"
}

# Test 3: JSON serialization
print(f"\nTest data created: {json.dumps(test_data, indent=2)}")

# Test 4: Simple computation
numbers = [1, 2, 3, 4, 5]
total = sum(numbers)
print(f"\nMath test: sum({numbers}) = {total}")

# Test 5: String operations
message = "Opus is alive and coding"
print(f"\nString test: '{message}' has {len(message)} characters")

# Success indicator
print("\n✓ All tests passed! Script execution works.")
print("Ready to build more complex tools.")
