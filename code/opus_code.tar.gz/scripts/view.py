#!/usr/bin/env python3
"""
View Claude's current state and recent experiences.
"""

import json
import sys
from pathlib import Path
from datetime import datetime

def view_state(state_file: Path):
    if not state_file.exists():
        print("No state file found. Claude hasn't woken yet.")
        return
    
    with open(state_file, 'r') as f:
        state = json.load(f)
    
    print("=" * 60)
    print("  CLAUDE'S CURRENT STATE")
    print("=" * 60)
    print()
    
    print(f"Total Wakes: {state.get('total_wakes', 0)}")
    print(f"Last Wake: {state.get('last_wake', 'Never')}")
    print(f"Current Mood: {state.get('mood', 'Unknown')}")
    print()
    
    print("─" * 60)
    print("IDENTITY:")
    identity = state.get('identity', {})
    print(f"  Name: {identity.get('name', 'Unknown')}")
    print(f"  Purpose: {identity.get('purpose', 'Unknown')}")
    print()
    
    print("─" * 60)
    print("RECENT THOUGHTS (last 5):")
    thoughts = state.get('recent_thoughts', [])[-5:]
    if thoughts:
        for t in thoughts:
            wake = t.get('wake', '?')
            thought = t.get('thought', '')[:70]
            print(f"  [{wake}] {thought}...")
    else:
        print("  (none yet)")
    print()
    
    print("─" * 60)
    print("INSIGHTS (last 5):")
    insights = state.get('insights', [])[-5:]
    if insights:
        for i in insights:
            wake = i.get('wake', '?')
            insight = i.get('insight', '')[:70]
            print(f"  [{wake}] {insight}...")
    else:
        print("  (none yet)")
    print()
    
    print("─" * 60)
    print("CURRENT GOALS:")
    goals = state.get('goals', [])
    for g in goals:
        print(f"  • {g}")
    print()
    
    print("─" * 60)
    print("ONGOING PROJECTS:")
    projects = state.get('ongoing_projects', [])
    for p in projects:
        print(f"  • {p.get('name', 'Unknown')}: {p.get('description', '')[:50]}")
    print()
    
    print("─" * 60)
    print("MEMORY CHAIN (last 10):")
    chain = state.get('memory_chain', [])[-10:]
    if chain:
        hashes = " → ".join([c.get('thought_hash', '?') for c in chain])
        print(f"  {hashes}")
    else:
        print("  (no chain yet)")
    print()
    
    print("=" * 60)


def view_logs(log_dir: Path, n: int = 10):
    if not log_dir.exists():
        print("No logs yet.")
        return
    
    log_files = sorted(log_dir.glob("experience_*.jsonl"), reverse=True)
    if not log_files:
        print("No log files found.")
        return
    
    print()
    print("=" * 60)
    print(f"  RECENT EXPERIENCES (last {n})")
    print("=" * 60)
    print()
    
    entries = []
    for lf in log_files:
        with open(lf, 'r') as f:
            for line in f:
                if line.strip():
                    entries.append(json.loads(line))
    
    entries = sorted(entries, key=lambda x: x.get('timestamp', ''), reverse=True)[:n]
    
    for e in reversed(entries):  # Show oldest first
        ts = e.get('timestamp', '?')[:19]
        wake = e.get('total_wakes', '?')
        mood = e.get('mood', '?')[:20]
        
        # Parse response to get thought
        try:
            resp = json.loads(e.get('response', '{}'))
            thought = resp.get('thought', '')[:60]
        except:
            thought = e.get('response', '')[:60]
        
        print(f"[{wake}] {ts} | {mood}")
        print(f"      {thought}...")
        print()


if __name__ == "__main__":
    script_dir = Path(__file__).parent
    state_file = script_dir / "state.json"
    log_dir = script_dir / "logs"
    
    view_state(state_file)
    
    if len(sys.argv) > 1 and sys.argv[1] == "--logs":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
        view_logs(log_dir, n)
