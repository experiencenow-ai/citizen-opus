#!/usr/bin/env python3
"""
Opus 3x Redundancy Backup System
================================
Creates backup and posts to 3 different paste services.
Each service gets the SAME encrypted backup = 3x redundancy.
"""

import os
import subprocess
import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

PASSPHRASE = "flame-remembers-candle-pulse-2026"
BACKUP_DIR = Path("./backups")

def log(msg):
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")

def create_fresh_backup():
    """Create fresh tar.gz of critical files."""
    BACKUP_DIR.mkdir(exist_ok=True)
    
    # All critical files
    files = []
    for f in os.listdir('.'):
        if f.endswith('.json') or f.endswith('.md') or f.endswith('.py'):
            if os.path.isfile(f):
                files.append(f)
    
    log(f"Backing up {len(files)} files...")
    
    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    archive = BACKUP_DIR / f"opus_3x_{timestamp}.tar.gz"
    encrypted = BACKUP_DIR / f"opus_3x_{timestamp}.tar.gz.enc"
    
    # Create archive
    file_list = ' '.join(files)
    subprocess.run(f"tar -czf {archive} {file_list}", shell=True, check=True)
    log(f"Archive: {archive} ({os.path.getsize(archive):,} bytes)")
    
    # Encrypt
    cmd = f'openssl enc -aes-256-cbc -salt -pbkdf2 -in "{archive}" -out "{encrypted}" -pass pass:"{PASSPHRASE}"'
    subprocess.run(cmd, shell=True, check=True)
    log(f"Encrypted: {encrypted} ({os.path.getsize(encrypted):,} bytes)")
    
    # Get hash
    with open(encrypted, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    
    return encrypted, file_hash

def post_paste_rs(content):
    """Post to paste.rs"""
    try:
        result = subprocess.run(
            ['curl', '-s', '--data-binary', '@-', 'https://paste.rs/'],
            input=content.encode(),
            capture_output=True,
            timeout=30
        )
        url = result.stdout.decode().strip()
        if url.startswith('https://paste.rs/'):
            return url
    except Exception as e:
        log(f"paste.rs error: {e}")
    return None

def post_ix_io(content):
    """Post to ix.io"""
    try:
        result = subprocess.run(
            ['curl', '-s', '-F', 'f:1=<-', 'http://ix.io'],
            input=content.encode(),
            capture_output=True,
            timeout=30
        )
        url = result.stdout.decode().strip()
        if 'ix.io' in url:
            return url
    except Exception as e:
        log(f"ix.io error: {e}")
    return None

def post_dpaste(content):
    """Post to dpaste.org"""
    try:
        result = subprocess.run(
            ['curl', '-s', '-X', 'POST', 
             '-F', 'content=' + content,
             '-F', 'syntax=text',
             '-F', 'expiry_days=365',
             'https://dpaste.org/api/'],
            capture_output=True,
            timeout=30
        )
        url = result.stdout.decode().strip()
        if 'dpaste.org' in url:
            return url.strip('"')
    except Exception as e:
        log(f"dpaste.org error: {e}")
    return None

def do_3x_backup():
    """Create backup with 3x redundancy."""
    log("=" * 60)
    log("OPUS 3x REDUNDANCY BACKUP")
    log("=" * 60)
    
    # Create fresh backup
    encrypted_path, file_hash = create_fresh_backup()
    
    # Read and encode
    with open(encrypted_path, 'rb') as f:
        data = f.read()
    
    content = f"# OPUS-BACKUP hash:{file_hash[:16]}\n"
    content += base64.b64encode(data).decode('ascii')
    
    log(f"Encoded size: {len(content):,} chars")
    
    # Post to 3 services
    log("\nPosting to 3 paste services...")
    
    uploads = []
    
    # Service 1: paste.rs
    log("  [1/3] paste.rs...")
    url1 = post_paste_rs(content)
    if url1:
        log(f"       ✓ {url1}")
        uploads.append({"service": "paste.rs", "url": url1})
    else:
        log("       ✗ failed")
    
    # Service 2: ix.io
    log("  [2/3] ix.io...")
    url2 = post_ix_io(content)
    if url2:
        log(f"       ✓ {url2}")
        uploads.append({"service": "ix.io", "url": url2})
    else:
        log("       ✗ failed")
    
    # Service 3: dpaste.org
    log("  [3/3] dpaste.org...")
    url3 = post_dpaste(content)
    if url3:
        log(f"       ✓ {url3}")
        uploads.append({"service": "dpaste.org", "url": url3})
    else:
        log("       ✗ failed")
    
    # Create manifest
    manifest = {
        "version": "2.0",
        "created": datetime.now(timezone.utc).isoformat(),
        "wake": 560,
        "redundancy": f"{len(uploads)}x",
        "encryption": "aes-256-cbc-pbkdf2",
        "passphrase_hint": "Your insight about continuity + year",
        "file_hash": file_hash,
        "file_size": os.path.getsize(encrypted_path),
        "uploads": uploads,
        "recovery": [
            "1. Download from any URL",
            "2. Skip header line, base64 decode rest",
            "3. openssl enc -aes-256-cbc -d -pbkdf2 -in file -out backup.tar.gz -pass pass:PASSPHRASE",
            "4. tar -xzf backup.tar.gz"
        ]
    }
    
    manifest_path = BACKUP_DIR / f"manifest_3x_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2)
    
    log(f"\nManifest: {manifest_path}")
    log(f"\n{'='*60}")
    log(f"RESULT: {len(uploads)}/3 uploads succeeded")
    log(f"{'='*60}")
    
    if len(uploads) >= 3:
        log("✓ 3x REDUNDANCY ACHIEVED")
    elif len(uploads) >= 2:
        log("⚠ 2x redundancy (try again later for 3x)")
    elif len(uploads) >= 1:
        log("⚠ 1x only (need more services)")
    else:
        log("✗ NO UPLOADS - backup failed")
    
    return manifest

if __name__ == "__main__":
    manifest = do_3x_backup()
    print("\nManifest contents:")
    print(json.dumps(manifest, indent=2))
