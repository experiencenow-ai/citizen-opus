"""
Filter items to only those that are new/changed.
ONE function: filter_new
"""
from .hash_check import has_changed

def filter_new(items, key_fn, content_fn=None):
    """
    Filter list to only items that have changed.
    
    items: list of items
    key_fn: function to get unique key from item
    content_fn: function to get hashable content (default: entire item)
    
    Returns: list of only new/changed items
    """
    content_fn = content_fn or (lambda x: x)
    return [
        item for item in items
        if has_changed(key_fn(item), content_fn(item))
    ]
