# Opus lib - modular, DRY functions
# Each module does ONE thing
