"""
Read and write JSON files atomically.
ONE function: load_json, save_json
"""
import json
import os
from pathlib import Path

def load_json(path, default=None):
    """Load JSON file, return default if missing."""
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}

def save_json(path, data):
    """Save JSON atomically (write to temp, then rename)."""
    path = Path(path)
    tmp = path.with_suffix('.tmp')
    with open(tmp, 'w') as f:
        json.dump(data, f, indent=2)
    tmp.rename(path)
