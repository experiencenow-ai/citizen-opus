"""
Check if something has changed by comparing hashes.
ONE function: has_changed
"""
import hashlib
from .json_io import load_json, save_json

HASH_FILE = "/root/claude/opus/state/hashes.json"

def content_hash(content):
    """SHA256 of stringified content."""
    if isinstance(content, (dict, list)):
        content = str(sorted(content.items()) if isinstance(content, dict) else content)
    return hashlib.sha256(str(content).encode()).hexdigest()[:16]

def has_changed(key, content, update=True):
    """
    Check if content has changed since last check.
    Returns True if new or changed.
    If update=True, stores the new hash.
    """
    hashes = load_json(HASH_FILE)
    new_hash = content_hash(content)
    old_hash = hashes.get(key)
    
    changed = old_hash != new_hash
    
    if update and changed:
        hashes[key] = new_hash
        save_json(HASH_FILE, hashes)
    
    return changed
