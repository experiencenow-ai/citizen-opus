#!/usr/bin/env python3
"""
Trace HOP destinations to find final exchange endpoints
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from collections import defaultdict

getcontext().prec = 50

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Main USDT outflow destinations from main wallet
HOP_ADDRESSES = [
    ("0x1f98326385a0e7113655ed4845059de514f4b56e", 900000),
    ("0xae1e8796052db5f4a975a006800ae33a20845078", 400000),
    ("0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1", 400000),
    ("0xa2d5d84b345f759934fa626927ba947eb12aabc2", 110000),
    ("0x811da8fc80f9d496469d108b3b503bb3444db929", 110000),
    ("0x51c3cf5d5fc1f2cb0f2a03cc39cf5998309072ec", 106000),
    ("0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e", 28280),  # Known Bybit
    ("0x1090725c7c02536c450136136fd1fa2c8ce16c21", 20000),
    ("0x96fced1718f48777516c442c360d79d9ad6f60da", 5000),
    ("0x5abf378d523d2fb61e78b5409901c9f6d9e26ed8", 3714),
    ("0x65664e204614a27c4a7c314323f2fd6ebb565120", 1800),
]

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def trace_address(address, amount_received):
    """Trace where funds from this address went"""
    print(f"\n{'='*80}")
    print(f"TRACING: {address}")
    print(f"Amount Received: ${amount_received:,}")
    print(f"{'='*80}")
    
    # Get USDT transactions
    token_txs = api_call("account", "tokentx", {
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    # Get current balance
    balance = api_call("account", "tokenbalance", {"contractaddress": USDT_CONTRACT, "address": address})
    current = Decimal(balance) / Decimal(10**6) if balance else Decimal(0)
    
    print(f"Current USDT Balance: ${current:,.2f}")
    print(f"Total USDT TXs: {len(token_txs)}")
    
    # Separate inflows and outflows
    inflows = []
    outflows = []
    
    for tx in token_txs:
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue
        
        data = {
            "hash": tx["hash"],
            "from": tx["from"],
            "to": tx["to"],
            "value": float(value)
        }
        
        if tx["to"].lower() == address.lower():
            inflows.append(data)
        elif tx["from"].lower() == address.lower():
            outflows.append(data)
    
    total_in = sum(t["value"] for t in inflows)
    total_out = sum(t["value"] for t in outflows)
    
    print(f"\nTotal In: ${total_in:,.2f}")
    print(f"Total Out: ${total_out:,.2f}")
    
    if outflows:
        print(f"\nOutflows to:")
        by_dest = defaultdict(lambda: {"total": 0, "txs": []})
        for tx in outflows:
            by_dest[tx["to"]]["total"] += tx["value"]
            by_dest[tx["to"]]["txs"].append(tx["hash"])
        
        destinations = []
        for dest, data in sorted(by_dest.items(), key=lambda x: x[1]["total"], reverse=True):
            print(f"  {dest}: ${data['total']:,.2f} ({len(data['txs'])} TXs)")
            destinations.append({
                "address": dest,
                "amount": data["total"],
                "tx_count": len(data["txs"]),
                "tx_hashes": data["txs"]
            })
        
        return {
            "address": address,
            "amount_received": amount_received,
            "current_balance": float(current),
            "total_in": total_in,
            "total_out": total_out,
            "destinations": destinations
        }
    else:
        print("  No outflows (funds sitting)")
        return {
            "address": address,
            "amount_received": amount_received,
            "current_balance": float(current),
            "total_in": total_in,
            "total_out": total_out,
            "destinations": [],
            "status": "DORMANT"
        }

def main():
    print("TRACING HOP DESTINATIONS")
    print("="*80)
    
    results = []
    
    for address, amount in HOP_ADDRESSES:
        result = trace_address(address, amount)
        results.append(result)
    
    # Summary
    print("\n\n" + "="*80)
    print("SUMMARY - FINAL DESTINATIONS")
    print("="*80)
    
    final_destinations = defaultdict(float)
    dormant = []
    
    for r in results:
        if r.get("status") == "DORMANT" or not r["destinations"]:
            dormant.append(r)
        else:
            for dest in r["destinations"]:
                final_destinations[dest["address"]] += dest["amount"]
    
    print("\n[FINAL DESTINATIONS]")
    for dest, amount in sorted(final_destinations.items(), key=lambda x: x[1], reverse=True):
        print(f"  {dest}: ${amount:,.2f}")
    
    print(f"\n[DORMANT FUNDS - READY FOR FREEZE]")
    total_dormant = 0
    for r in dormant:
        print(f"  {r['address']}: ${r['current_balance']:,.2f}")
        total_dormant += r['current_balance']
    print(f"  TOTAL DORMANT: ${total_dormant:,.2f}")
    
    # Save
    with open("hop_trace_complete.json", "w") as f:
        json.dump({
            "hop_traces": results,
            "final_destinations": dict(final_destinations),
            "dormant_addresses": [(r["address"], r["current_balance"]) for r in dormant]
        }, f, indent=2)
    
    print("\nSaved to hop_trace_complete.json")

if __name__ == "__main__":
    main()
