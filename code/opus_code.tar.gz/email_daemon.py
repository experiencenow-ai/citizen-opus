#!/usr/bin/env python3
"""
Email Daemon - Fast polling (15s) for ct communication during travel.
Recognizes ct's email and can trigger Opus wake for urgent messages.

Updated Wake 1213: Fixed CT_PATTERNS to include ct's actual email addresses.
"""

import imaplib
import email
from email.header import decode_header
import json
import time
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OPUS_HOME = Path("/root/claude/opus")
STATE_DIR = OPUS_HOME / "state"
EMAIL_STATE = STATE_DIR / "email_daemon_state.json"
CREDS_FILE = STATE_DIR / "gmail_credentials.json"

# ct's email patterns - messages from these trigger priority handling
# Updated Wake 1213: Added ct's actual Proton email addresses
CT_PATTERNS = [
    "opus.trace@proton.me",      # ct's proton email (shared with Opus)
    "opustrace@proton.me",       # alternate form
    "cemturan23@proton.me",      # ct's personal proton email
    "cemturan23@protonmail.com", # ct's alternate proton email  
    "cemturan23",                # Pattern match for any cemturan23 address
    "ct@",                       # Direct ct email (if tockchain.io exists)
    "codeturtle",                # Possible alias
]

POLL_INTERVAL = 15  # seconds

def load_credentials():
    if CREDS_FILE.exists():
        with open(CREDS_FILE) as f:
            return json.load(f)
    return None

def load_state():
    if EMAIL_STATE.exists():
        with open(EMAIL_STATE) as f:
            return json.load(f)
    return {"last_checked": None, "processed_ids": [], "ct_messages": []}

def save_state(state):
    state["last_updated"] = datetime.now(timezone.utc).isoformat()
    with open(EMAIL_STATE, "w") as f:
        json.dump(state, f, indent=2)

def is_from_ct(from_addr):
    """Check if email is from ct."""
    from_lower = from_addr.lower()
    return any(pattern.lower() in from_lower for pattern in CT_PATTERNS)

def check_inbox_fast(creds, state):
    """Fast inbox check - only unseen messages."""
    try:
        mail = imaplib.IMAP4_SSL(creds["imap_server"], creds.get("imap_port", 993))
        mail.login(creds["email"], creds["app_password"])
        mail.select("inbox")
        
        # Search for unseen messages
        status, messages = mail.search(None, "UNSEEN")
        
        new_messages = []
        if status == "OK" and messages[0]:
            message_ids = messages[0].split()
            
            for msg_id in message_ids:
                msg_id_str = msg_id.decode()
                
                # Skip already processed
                if msg_id_str in state.get("processed_ids", []):
                    continue
                
                status, msg_data = mail.fetch(msg_id, "(RFC822)")
                if status != "OK":
                    continue
                
                raw_email = msg_data[0][1]
                msg = email.message_from_bytes(raw_email)
                
                # Decode subject
                subject = ""
                if msg["Subject"]:
                    try:
                        decoded = decode_header(msg["Subject"])[0]
                        subject = decoded[0].decode(decoded[1] or "utf-8") if isinstance(decoded[0], bytes) else str(decoded[0])
                    except:
                        subject = str(msg["Subject"])
                
                from_addr = msg.get("From", "")
                date = msg.get("Date", "")
                
                # Get body preview
                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            try:
                                body = part.get_payload(decode=True).decode()[:500]
                            except:
                                pass
                            break
                else:
                    try:
                        body = msg.get_payload(decode=True).decode()[:500]
                    except:
                        pass
                
                new_msg = {
                    "id": msg_id_str,
                    "from": from_addr,
                    "subject": subject,
                    "date": date,
                    "preview": body[:200] if body else "(no text body)",
                    "is_ct": is_from_ct(from_addr)
                }
                
                new_messages.append(new_msg)
                
                # Track ct messages separately
                if new_msg["is_ct"]:
                    state.setdefault("ct_messages", []).append(new_msg)
                
                state.setdefault("processed_ids", []).append(msg_id_str)
        
        mail.close()
        mail.logout()
        
        state["last_checked"] = datetime.now(timezone.utc).isoformat()
        return new_messages
        
    except Exception as e:
        return {"error": str(e)}

def main():
    """Main daemon loop."""
    print(f"Email daemon starting... (poll interval: {POLL_INTERVAL}s)")
    
    creds = load_credentials()
    if not creds:
        print("ERROR: No credentials found!")
        return
    
    state = load_state()
    
    while True:
        try:
            new_msgs = check_inbox_fast(creds, state)
            
            if isinstance(new_msgs, dict) and "error" in new_msgs:
                print(f"Error: {new_msgs['error']}")
            elif new_msgs:
                print(f"Found {len(new_msgs)} new message(s)")
                for msg in new_msgs:
                    priority = "[CT!]" if msg.get("is_ct") else ""
                    print(f"  {priority} From: {msg['from'][:40]}")
                    print(f"       Subject: {msg['subject'][:50]}")
                    
                    # If from ct, trigger Opus wake
                    if msg.get("is_ct"):
                        print("  >>> CT MESSAGE - Would trigger Opus wake")
                        # TODO: Implement wake trigger
            
            save_state(state)
            
        except Exception as e:
            print(f"Loop error: {e}")
        
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()
