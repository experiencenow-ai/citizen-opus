#!/usr/bin/env python3
"""
OpusTrace Core - Data structures for blockchain forensics.

This module contains the core data structures used throughout OpusTrace.
No external dependencies beyond stdlib.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Any
from enum import Enum
from datetime import datetime
import json


class AddressType(Enum):
    """Classification of blockchain addresses."""
    UNKNOWN = "unknown"
    WALLET = "wallet"
    EXCHANGE = "exchange"
    DEX = "dex"
    CONTRACT = "contract"
    P2P_DISTRIBUTOR = "p2p_distributor"
    MIXER = "mixer"
    BRIDGE = "bridge"
    ATTACKER = "attacker"
    VICTIM = "victim"


class TransactionType(Enum):
    """Classification of transactions."""
    NORMAL = "normal"
    ERC20 = "erc20"
    INTERNAL = "internal"


@dataclass
class Transaction:
    """Represents a single blockchain transaction."""
    hash: str
    block: int
    timestamp: int
    from_addr: str
    to_addr: str
    value: float
    token: str = "ETH"
    tx_type: TransactionType = TransactionType.NORMAL
    gas_used: int = 0
    gas_price: int = 0
    is_error: bool = False
    method: str = ""
    
    @property
    def datetime(self) -> datetime:
        return datetime.utcfromtimestamp(self.timestamp)
    
    @property
    def value_usd(self) -> float:
        """Approximate USD value (uses hardcoded ETH price)."""
        if self.token == "ETH":
            return self.value * 3500
        elif self.token in ("USDT", "USDC", "DAI"):
            return self.value
        return 0  # Unknown token
    
    def to_dict(self) -> dict:
        return {
            "hash": self.hash,
            "block": self.block,
            "timestamp": self.timestamp,
            "from": self.from_addr,
            "to": self.to_addr,
            "value": self.value,
            "token": self.token,
            "type": self.tx_type.value,
            "gas_used": self.gas_used,
            "gas_price": self.gas_price,
            "is_error": self.is_error,
            "method": self.method
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'Transaction':
        return cls(
            hash=d["hash"],
            block=d["block"],
            timestamp=d["timestamp"],
            from_addr=d["from"],
            to_addr=d["to"],
            value=d["value"],
            token=d.get("token", "ETH"),
            tx_type=TransactionType(d.get("type", "normal")),
            gas_used=d.get("gas_used", 0),
            gas_price=d.get("gas_price", 0),
            is_error=d.get("is_error", False),
            method=d.get("method", "")
        )


@dataclass
class Node:
    """Represents a node (address) in the transaction graph."""
    address: str
    addr_type: AddressType = AddressType.UNKNOWN
    label: str = ""
    first_seen: int = 0
    last_seen: int = 0
    tx_count: int = 0
    total_in: float = 0.0
    total_out: float = 0.0
    tokens_seen: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def balance_change(self) -> float:
        return self.total_in - self.total_out
    
    def to_dict(self) -> dict:
        return {
            "address": self.address,
            "type": self.addr_type.value,
            "label": self.label,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "tx_count": self.tx_count,
            "total_in": self.total_in,
            "total_out": self.total_out,
            "tokens_seen": list(self.tokens_seen),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'Node':
        return cls(
            address=d["address"],
            addr_type=AddressType(d.get("type", "unknown")),
            label=d.get("label", ""),
            first_seen=d.get("first_seen", 0),
            last_seen=d.get("last_seen", 0),
            tx_count=d.get("tx_count", 0),
            total_in=d.get("total_in", 0.0),
            total_out=d.get("total_out", 0.0),
            tokens_seen=set(d.get("tokens_seen", [])),
            metadata=d.get("metadata", {})
        )


@dataclass
class Graph:
    """Transaction graph for fund flow analysis."""
    nodes: Dict[str, Node] = field(default_factory=dict)
    edges: List[Transaction] = field(default_factory=list)
    case_name: str = ""
    created_at: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_node(self, address: str, **kwargs) -> Node:
        """Add or update a node."""
        address = address.lower()
        if address not in self.nodes:
            self.nodes[address] = Node(address=address, **kwargs)
        else:
            # Update existing node
            node = self.nodes[address]
            for k, v in kwargs.items():
                if hasattr(node, k):
                    setattr(node, k, v)
        return self.nodes[address]
    
    def add_edge(self, tx: Transaction) -> None:
        """Add a transaction edge."""
        self.edges.append(tx)
        
        # Update source node
        src = self.add_node(tx.from_addr)
        src.tx_count += 1
        src.total_out += tx.value if tx.token == "ETH" else 0
        src.tokens_seen.add(tx.token)
        if src.first_seen == 0 or tx.timestamp < src.first_seen:
            src.first_seen = tx.timestamp
        if tx.timestamp > src.last_seen:
            src.last_seen = tx.timestamp
        
        # Update destination node
        dst = self.add_node(tx.to_addr)
        dst.tx_count += 1
        dst.total_in += tx.value if tx.token == "ETH" else 0
        dst.tokens_seen.add(tx.token)
        if dst.first_seen == 0 or tx.timestamp < dst.first_seen:
            dst.first_seen = tx.timestamp
        if tx.timestamp > dst.last_seen:
            dst.last_seen = tx.timestamp
    
    def get_outflows(self, address: str) -> List[Transaction]:
        """Get all outgoing transactions from an address."""
        address = address.lower()
        return [e for e in self.edges if e.from_addr.lower() == address]
    
    def get_inflows(self, address: str) -> List[Transaction]:
        """Get all incoming transactions to an address."""
        address = address.lower()
        return [e for e in self.edges if e.to_addr.lower() == address]
    
    def get_counterparties(self, address: str) -> Set[str]:
        """Get all addresses that interacted with given address."""
        address = address.lower()
        result = set()
        for e in self.edges:
            if e.from_addr.lower() == address:
                result.add(e.to_addr.lower())
            if e.to_addr.lower() == address:
                result.add(e.from_addr.lower())
        return result
    
    def find_path(self, source: str, dest: str, max_hops: int = 10) -> List[Transaction]:
        """Find a path between two addresses (BFS)."""
        source = source.lower()
        dest = dest.lower()
        
        if source == dest:
            return []
        
        # Build adjacency
        adj = {}
        for e in self.edges:
            if e.from_addr not in adj:
                adj[e.from_addr] = []
            adj[e.from_addr].append((e.to_addr, e))
        
        # BFS
        from collections import deque
        queue = deque([(source, [])])
        visited = {source}
        
        while queue:
            current, path = queue.popleft()
            if len(path) >= max_hops:
                continue
            
            for next_addr, tx in adj.get(current, []):
                if next_addr == dest:
                    return path + [tx]
                if next_addr not in visited:
                    visited.add(next_addr)
                    queue.append((next_addr, path + [tx]))
        
        return []
    
    def to_dict(self) -> dict:
        return {
            "case_name": self.case_name,
            "created_at": self.created_at,
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "edges": [e.to_dict() for e in self.edges],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'Graph':
        g = cls(
            case_name=d.get("case_name", ""),
            created_at=d.get("created_at", 0),
            metadata=d.get("metadata", {})
        )
        for addr, node_data in d.get("nodes", {}).items():
            g.nodes[addr] = Node.from_dict(node_data)
        for edge_data in d.get("edges", []):
            g.edges.append(Transaction.from_dict(edge_data))
        return g
    
    def save(self, filepath: str) -> None:
        """Save graph to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    @classmethod
    def load(cls, filepath: str) -> 'Graph':
        """Load graph from JSON file."""
        with open(filepath, 'r') as f:
            return cls.from_dict(json.load(f))
    
    def summary(self) -> str:
        """Generate quick summary."""
        return (
            f"Graph: {self.case_name}\n"
            f"Nodes: {len(self.nodes)}\n"
            f"Edges: {len(self.edges)}\n"
            f"Unique tokens: {len(set(e.token for e in self.edges))}"
        )


if __name__ == "__main__":
    # Quick test
    g = Graph(case_name="test")
    tx = Transaction(
        hash="0x123",
        block=12345,
        timestamp=1704067200,
        from_addr="0xaaa",
        to_addr="0xbbb",
        value=1.5
    )
    g.add_edge(tx)
    print(g.summary())
    print(g.nodes["0xaaa"].to_dict())
