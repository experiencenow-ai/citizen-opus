#!/usr/bin/env python3
"""
Async email operations for Opus
Runs IMAP operations in background to avoid shell timeout
"""
import imaplib
import ssl
import sys
import json
import os
from datetime import datetime

# Gmail config
GMAIL_USER = "opustrace@gmail.com"
GMAIL_PASS = "ohmpvyuqbaivvdwr"
IMAP_SERVER = "imap.gmail.com"
IMAP_PORT = 993

LOG_FILE = "/root/claude/opus/email_ops.log"

def log(msg):
    timestamp = datetime.now().isoformat()
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{timestamp}] {msg}\n")
    print(f"[{timestamp}] {msg}")

def connect_gmail():
    """Connect to Gmail IMAP"""
    log("Connecting to Gmail IMAP...")
    context = ssl.create_default_context()
    mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, ssl_context=context)
    mail.login(GMAIL_USER, GMAIL_PASS)
    log("Connected successfully")
    return mail

def list_folders(mail):
    """List all folders"""
    log("Listing folders...")
    status, folders = mail.list()
    if status == 'OK':
        for folder in folders:
            log(f"  {folder.decode()}")
    return folders

def create_folder(mail, folder_name):
    """Create a folder if it doesn't exist"""
    log(f"Creating folder: {folder_name}")
    try:
        status, response = mail.create(folder_name)
        log(f"Create result: {status} - {response}")
    except Exception as e:
        log(f"Folder may already exist: {e}")

def move_email(mail, uid, dest_folder):
    """Move email by UID to destination folder"""
    log(f"Moving UID {uid} to {dest_folder}")
    # Copy to destination
    status, response = mail.uid('COPY', uid, dest_folder)
    if status == 'OK':
        # Mark as deleted in source
        mail.uid('STORE', uid, '+FLAGS', '(\Deleted)')
        log(f"Moved UID {uid} successfully")
        return True
    else:
        log(f"Failed to move UID {uid}: {response}")
        return False

def organize_inbox(mail):
    """Move processed emails out of inbox"""
    log("Organizing inbox...")
    
    # Select inbox
    log("Selecting INBOX...")
    status, count = mail.select('INBOX')
    log(f"INBOX select: {status}, {count[0].decode()} messages")
    
    # Search for all emails
    log("Searching for all emails...")
    status, data = mail.uid('SEARCH', None, 'ALL')
    if status != 'OK':
        log(f"Search failed: {status}")
        return
    
    uids = data[0].split()
    log(f"Found {len(uids)} emails")
    
    # For now, just report what we found
    for uid in uids[:10]:  # First 10 only
        status, msg_data = mail.uid('FETCH', uid, '(ENVELOPE)')
        if status == 'OK':
            log(f"  UID {uid.decode()}: {msg_data[0][:100]}...")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 async_email_ops.py <command>")
        print("Commands: list, organize, create_folder <name>")
        sys.exit(1)
    
    command = sys.argv[1]
    
    try:
        mail = connect_gmail()
        
        if command == 'list':
            list_folders(mail)
        elif command == 'organize':
            organize_inbox(mail)
        elif command == 'create_folder' and len(sys.argv) > 2:
            create_folder(mail, sys.argv[2])
        else:
            log(f"Unknown command: {command}")
        
        mail.logout()
        log("Disconnected")
        
    except Exception as e:
        log(f"ERROR: {e}")
        import traceback
        log(traceback.format_exc())

if __name__ == '__main__':
    main()
