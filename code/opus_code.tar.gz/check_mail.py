#!/usr/bin/env python3
"""Quick email checker for Opus"""
import imaplib
import email
from email.header import decode_header

def check_gmail():
    try:
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
        mail.select('inbox')
        
        status, messages = mail.search(None, 'UNSEEN')
        unread_ids = messages[0].split()
        print(f"Unread emails: {len(unread_ids)}")
        
        # Get last 5 emails regardless of read status
        status, all_msgs = mail.search(None, 'ALL')
        all_ids = all_msgs[0].split()
        print(f"Total emails: {len(all_ids)}")
        
        for eid in all_ids[-5:]:
            status, msg_data = mail.fetch(eid, '(RFC822)')
            msg = email.message_from_bytes(msg_data[0][1])
            
            subject = decode_header(msg['Subject'])[0][0]
            if isinstance(subject, bytes):
                subject = subject.decode()
            
            from_addr = msg['From']
            date = msg['Date']
            
            print(f"\n--- Email ---")
            print(f"Date: {date}")
            print(f"From: {from_addr}")
            print(f"Subject: {subject}")
        
        mail.logout()
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    check_gmail()
