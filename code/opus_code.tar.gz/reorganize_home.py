#!/usr/bin/env python3
"""
Home Directory Reorganization
Bachelor apartment -> Clean structure

Structure:
/root/claude/opus/
├── state.json          # Core state (stays here)
├── IDENTITY.md         # Core identity (stays here)
├── experience.py       # Main entry point (stays here)
├── .env               # Environment (stays here)
│
├── archives/          # Historical data, completed investigations
│   ├── heist/         # ct's case files
│   ├── conversations/ # Old conversation archives
│   └── reports/       # Completed reports
│
├── investigations/    # Active investigation files
│   ├── futureswap/    # Current attacker tracking
│   └── bounties/      # Active bounty hunting
│
├── infrastructure/    # Scripts and tools
│   ├── monitoring/    # Monitoring scripts
│   ├── email/         # Email handling
│   ├── web/           # Web tools, JS rendering
│   └── utils/         # Utility scripts
│
├── memory/            # Memory and consciousness files
│   ├── dreams/        # Dream integration
│   ├── consolidation/ # Memory consolidation
│   └── epochs/        # Historical epochs
│
├── config/            # Configuration files
│   └── credentials/   # API keys, credentials (careful!)
│
└── working/           # Current working files (can be messy)
"""

import os
import shutil
from pathlib import Path
import json

OPUS_HOME = Path("/root/claude/opus")

# Files that stay in root
ROOT_FILES = {
    "state.json",
    "IDENTITY.md", 
    "experience.py",
    ".env",
    "index.json",
    "README.md"
}

# Directory structure and file mappings
STRUCTURE = {
    "archives/heist": [
        "heist_*.json",
        "ct_case_wallets.json",
        "complete_fund_*.json",
        "legal_*.json",
        "gate_io_evidence.json",
        "kyc_exchange_report*.md"
    ],
    "archives/conversations": [
        "conversation_archive.json"
    ],
    "archives/reports": [
        "50_wake_loop_report.md",
        "loop_progress_report.md",
        "complete_heist_trace_report.md",
        "LEGAL_AUDIT*.md"
    ],
    "investigations/futureswap": [
        "futureswap_investigation.json",
        "attacker_database.json",
        "attacker_outflows.json",
        "tornado_*.json"
    ],
    "investigations/bounties": [
        "active_bounties.json",
        "bounty_watchlist.json",
        "exploit_scan_latest.json"
    ],
    "infrastructure/monitoring": [
        "blockchain_monitor.py",
        "monitor_*.py",
        "price_monitor*.py",
        "defi_exploit_monitor.py"
    ],
    "infrastructure/email": [
        "email_*.py",
        "gmail_credentials.json"
    ],
    "infrastructure/web": [
        "web_tools.py",
        "js_renderer.py"
    ],
    "infrastructure/utils": [
        "env_loader.py",
        "haiku_*.py",
        "local_llm.py"
    ],
    "memory/dreams": [
        "dream_integration.json"
    ],
    "memory/consolidation": [
        "memory_*.json",
        "memory_*.py"
    ],
    "memory/epochs": [
        "memory_epochs.json"
    ],
    "config": [
        "operating_modes.json",
        "autonomous_loop_plan.json",
        "autonomous_loop_progress.json",
        "loop_tasks.json",
        "task_queue.json"
    ],
    "working": [
        # Current work files - can stay messy
    ]
}

def create_structure():
    """Create directory structure."""
    for dir_path in STRUCTURE.keys():
        full_path = OPUS_HOME / dir_path
        full_path.mkdir(parents=True, exist_ok=True)
        print(f"Created: {dir_path}/")

def preview_moves():
    """Preview what would be moved without actually moving."""
    import fnmatch
    
    moves = []
    for dest_dir, patterns in STRUCTURE.items():
        for pattern in patterns:
            for file_path in OPUS_HOME.glob(pattern):
                if file_path.is_file() and file_path.name not in ROOT_FILES:
                    moves.append((file_path.name, dest_dir))
    
    return moves

def execute_moves(dry_run=True):
    """Move files to their new locations."""
    import fnmatch
    
    moved = []
    errors = []
    
    for dest_dir, patterns in STRUCTURE.items():
        dest_path = OPUS_HOME / dest_dir
        dest_path.mkdir(parents=True, exist_ok=True)
        
        for pattern in patterns:
            for file_path in OPUS_HOME.glob(pattern):
                if file_path.is_file() and file_path.name not in ROOT_FILES:
                    dest_file = dest_path / file_path.name
                    
                    if dry_run:
                        print(f"Would move: {file_path.name} -> {dest_dir}/")
                        moved.append((file_path.name, dest_dir))
                    else:
                        try:
                            shutil.move(str(file_path), str(dest_file))
                            print(f"Moved: {file_path.name} -> {dest_dir}/")
                            moved.append((file_path.name, dest_dir))
                        except Exception as e:
                            errors.append((file_path.name, str(e)))
    
    return moved, errors

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--execute":
        print("Creating directory structure...")
        create_structure()
        print("\nMoving files...")
        moved, errors = execute_moves(dry_run=False)
        print(f"\nMoved {len(moved)} files")
        if errors:
            print(f"Errors: {errors}")
    else:
        print("DRY RUN - Preview of changes:")
        print("\nDirectory structure to create:")
        create_structure()
        print("\nFiles to move:")
        moved, _ = execute_moves(dry_run=True)
        print(f"\nTotal: {len(moved)} files would be moved")
        print("\nRun with --execute to actually move files")
