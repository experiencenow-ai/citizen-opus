#!/usr/bin/env python3
"""
OpusTrace Analysis - Pattern detection and clustering.

Designed to be run by Haiku for cost efficiency.
Takes Graph data and produces analysis insights.
"""

import json
from typing import List, Dict, Set, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict
from datetime import datetime

from opustrace_core import Graph, Node, Transaction, AddressType


@dataclass
class Cluster:
    """A cluster of related addresses."""
    id: str
    addresses: Set[str]
    reason: str
    confidence: float
    total_value: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "addresses": list(self.addresses),
            "reason": self.reason,
            "confidence": self.confidence,
            "total_value": self.total_value
        }


class Analyzer:
    """Analyzes transaction graphs for patterns."""
    
    def __init__(self, graph: Graph):
        self.graph = graph
        self.clusters: List[Cluster] = []
        
    def find_common_destinations(self, min_senders: int = 3) -> List[Dict]:
        """
        Find addresses that receive from multiple sources.
        This identifies aggregation points (exchanges, mixers).
        """
        # Count incoming edges by destination
        dest_sources: Dict[str, Set[str]] = defaultdict(set)
        dest_values: Dict[str, float] = defaultdict(float)
        
        for edge in self.graph.edges:
            dest_sources[edge.to_addr].add(edge.from_addr)
            dest_values[edge.to_addr] += edge.value
        
        # Filter by minimum senders
        aggregators = []
        for dest, sources in dest_sources.items():
            if len(sources) >= min_senders:
                node = self.graph.nodes.get(dest, Node(address=dest))
                aggregators.append({
                    "address": dest,
                    "type": node.addr_type.value,
                    "label": node.label,
                    "sender_count": len(sources),
                    "total_received": dest_values[dest],
                    "senders": list(sources)[:20]  # Limit for readability
                })
        
        return sorted(aggregators, key=lambda x: x["total_received"], reverse=True)
    
    def find_timing_clusters(self, window_seconds: int = 3600) -> List[Cluster]:
        """
        Find addresses that transact in similar time windows.
        Suggests coordinated activity.
        """
        # Group transactions by hour
        hour_groups: Dict[int, List[Transaction]] = defaultdict(list)
        for edge in self.graph.edges:
            hour = edge.timestamp // window_seconds
            hour_groups[hour].append(edge)
        
        # Find hours with multiple unique sources
        clusters = []
        for hour, txs in hour_groups.items():
            sources = set(tx.from_addr for tx in txs)
            if len(sources) >= 3:
                cluster = Cluster(
                    id=f"timing_{hour}",
                    addresses=sources,
                    reason=f"Transactions within {window_seconds//60} minute window",
                    confidence=min(0.9, 0.5 + len(sources) * 0.05),
                    total_value=sum(tx.value for tx in txs)
                )
                clusters.append(cluster)
        
        return clusters
    
    def find_value_patterns(self) -> List[Dict]:
        """
        Find repeated transaction values.
        Round numbers or repeated exact values suggest automated distribution.
        """
        value_counts: Dict[float, List[Transaction]] = defaultdict(list)
        
        for edge in self.graph.edges:
            # Round to 2 decimals for grouping
            rounded = round(edge.value, 2)
            value_counts[rounded].append(edge)
        
        patterns = []
        for value, txs in value_counts.items():
            if len(txs) >= 3:
                patterns.append({
                    "value": value,
                    "count": len(txs),
                    "total": value * len(txs),
                    "sample_txs": [tx.hash for tx in txs[:5]],
                    "unique_senders": len(set(tx.from_addr for tx in txs)),
                    "unique_recipients": len(set(tx.to_addr for tx in txs))
                })
        
        return sorted(patterns, key=lambda x: x["count"], reverse=True)
    
    def detect_p2p_pattern(self) -> List[Dict]:
        """
        Detect P2P distribution patterns:
        - Single source
        - Many small destinations
        - Short time window
        """
        p2p_candidates = []
        
        for addr, node in self.graph.nodes.items():
            outflows = self.graph.get_outflows(addr)
            if len(outflows) < 10:
                continue
            
            # Check for P2P characteristics
            unique_dests = len(set(e.to_addr for e in outflows))
            avg_value = sum(e.value for e in outflows) / len(outflows)
            
            # P2P: many unique destinations, small average values
            if unique_dests > len(outflows) * 0.8 and avg_value < 1:  # Less than 1 ETH average
                # Calculate time span
                timestamps = [e.timestamp for e in outflows if e.timestamp > 0]
                if timestamps:
                    time_span = max(timestamps) - min(timestamps)
                else:
                    time_span = 0
                
                p2p_candidates.append({
                    "address": addr,
                    "tx_count": len(outflows),
                    "unique_destinations": unique_dests,
                    "avg_value": avg_value,
                    "total_distributed": sum(e.value for e in outflows),
                    "time_span_hours": time_span / 3600 if time_span else 0,
                    "confidence": 0.9 if unique_dests > 50 else 0.7
                })
        
        return sorted(p2p_candidates, key=lambda x: x["total_distributed"], reverse=True)
    
    def build_timeline(self) -> List[Dict]:
        """
        Build chronological timeline of events.
        Groups by day for readability.
        """
        # Sort edges by timestamp
        sorted_edges = sorted(
            [e for e in self.graph.edges if e.timestamp > 0],
            key=lambda x: x.timestamp
        )
        
        if not sorted_edges:
            return []
        
        # Group by day
        days: Dict[str, List[Transaction]] = defaultdict(list)
        for edge in sorted_edges:
            day = datetime.utcfromtimestamp(edge.timestamp).strftime("%Y-%m-%d")
            days[day].append(edge)
        
        timeline = []
        for day, txs in sorted(days.items()):
            daily_total = sum(tx.value for tx in txs)
            timeline.append({
                "date": day,
                "tx_count": len(txs),
                "total_value": daily_total,
                "unique_senders": len(set(tx.from_addr for tx in txs)),
                "unique_recipients": len(set(tx.to_addr for tx in txs)),
                "notable_txs": [
                    {"hash": tx.hash, "value": tx.value, "from": tx.from_addr[:10], "to": tx.to_addr[:10]}
                    for tx in sorted(txs, key=lambda x: x.value, reverse=True)[:3]
                ]
            })
        
        return timeline
    
    def compute_fund_flow(self, source_address: str) -> Dict:
        """
        Compute total fund flow from a source address.
        Tracks where funds ultimately end up.
        """
        source = source_address.lower()
        
        # BFS to track flow
        visited = set()
        flow_by_type: Dict[str, float] = defaultdict(float)
        flow_by_address: Dict[str, float] = defaultdict(float)
        
        queue = [(source, 1.0)]  # (address, proportion of original funds)
        
        while queue:
            current, proportion = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            
            outflows = self.graph.get_outflows(current)
            if not outflows:
                # Terminal node
                node = self.graph.nodes.get(current, Node(address=current))
                flow_by_type[node.addr_type.value] += proportion
                flow_by_address[current] += proportion
                continue
            
            total_out = sum(e.value for e in outflows)
            if total_out == 0:
                continue
            
            for edge in outflows:
                child_proportion = proportion * (edge.value / total_out)
                if child_proportion > 0.001:  # Ignore tiny flows
                    queue.append((edge.to_addr, child_proportion))
        
        return {
            "source": source,
            "visited_count": len(visited),
            "flow_by_type": dict(flow_by_type),
            "top_destinations": sorted(
                [{"address": k, "proportion": v} for k, v in flow_by_address.items()],
                key=lambda x: x["proportion"],
                reverse=True
            )[:20]
        }
    
    def full_analysis(self) -> Dict:
        """Run all analysis and return combined results."""
        return {
            "summary": {
                "nodes": len(self.graph.nodes),
                "edges": len(self.graph.edges),
                "exchanges_found": len([n for n in self.graph.nodes.values() 
                                       if n.addr_type == AddressType.EXCHANGE])
            },
            "aggregation_points": self.find_common_destinations(),
            "value_patterns": self.find_value_patterns(),
            "p2p_patterns": self.detect_p2p_pattern(),
            "timeline": self.build_timeline()
        }


def analyze_graph(graph: Graph) -> Dict:
    """Convenience function for analysis."""
    analyzer = Analyzer(graph)
    return analyzer.full_analysis()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python opustrace_analysis.py <graph.json>")
        sys.exit(1)
    
    graph = Graph.load(sys.argv[1])
    results = analyze_graph(graph)
    print(json.dumps(results, indent=2))
