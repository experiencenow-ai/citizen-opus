#!/usr/bin/env python3
"""
COMPLETE AUDIT - Every dollar traced
LEGAL DOCUMENT - Full TX hashes, no truncation
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from datetime import datetime, timezone

getcontext().prec = 50

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Known wallet addresses
WALLETS = {
    "MAIN": "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7",
    "VICTIM_1": "0x3eADF348745F80a3d9245AeA621dE0957C65c53F",
    "VICTIM_2": "0x777deFa08C49f1ebd77B87abE664f47Dc14Cc5f7",
    "PHISHER": "0xeE8Ea66a5D8D2c93004Ec100EF91Fea8C2f8AFa7",
}

# Known exchange deposit/hot wallets
EXCHANGES = {
    "0x7237b8a4b2dd97dcddb758feac0e8d925016694c": "Gate.io Deposit",
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io Hot",
    "0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e": "Bybit #1",
    "0x63aabab8bc31c4f360ae6c7cf78f67f118f2154c": "Bybit #2",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot",
    "0x525254e58c25d9ac127c63af9a9830f7e5a91a0b": "Bitget Deposit",
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Bitget Hot",
    "0xae1e8796052db5f4a975a006800ae33a20845078": "WhiteBIT P2P Distributor",
    "0x18e296053cbdf986196903e889b7dca7a73882f6": "Exchange Hot (Unknown)",
}

# Token contracts
TOKENS = {
    "0xdac17f958d2ee523a2206206994597c13d831ec7": {"name": "USDT", "decimals": 6},
    "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0": {"name": "wstETH", "decimals": 18},
    "0x18084fba666a33d37592fa2633fd49a74dd93a88": {"name": "tBTC", "decimals": 18},
}

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def ts_to_str(ts):
    dt = datetime.fromtimestamp(int(ts), tz=timezone.utc)
    return dt.strftime('%Y-%m-%d %H:%M:%S UTC')

def main():
    audit = {
        "metadata": {
            "generated": datetime.now(timezone.utc).isoformat(),
            "etherscan_api_version": "V2",
            "api_key_used": ETHERSCAN_API_KEY,
            "note": "COMPLETE AUDIT - All TX hashes untruncated for legal verification"
        },
        "victim_wallets": {
            "eth_1": WALLETS["VICTIM_1"],
            "eth_2": WALLETS["VICTIM_2"]
        },
        "attacker_main_wallet": WALLETS["MAIN"],
        "theft_transactions": [],
        "exchange_deposits": {
            "gate_io": {"address": "0x7237b8a4b2dd97dcddb758feac0e8d925016694c", "hot_wallet": "0x0d0707963952f2fba59dd06f2b425ace40b492fe", "amount": 0, "txs": []},
            "bybit_1": {"address": "0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e", "amount": 0, "txs": []},
            "bybit_2": {"address": "0x63aabab8bc31c4f360ae6c7cf78f67f118f2154c", "amount": 0, "txs": []},
            "bitget": {"address": "0x525254e58c25d9ac127c63af9a9830f7e5a91a0b", "amount": 0, "txs": []},
            "whitebit_p2p": {"address": "0xae1e8796052db5f4a975a006800ae33a20845078", "amount": 0, "txs": []},
        },
        "dormant_funds": [],
        "reconciliation": {},
    }
    
    # Get all TXs from main wallet
    print("Fetching main wallet transactions...")
    normal_txs = api_call("account", "txlist", {"address": WALLETS["MAIN"], "startblock": 0, "endblock": 99999999, "sort": "asc"})
    token_txs = api_call("account", "tokentx", {"address": WALLETS["MAIN"], "startblock": 0, "endblock": 99999999, "sort": "asc"})
    
    print(f"Normal TXs: {len(normal_txs)}")
    print(f"Token TXs: {len(token_txs)}")
    
    # THEFT TRANSACTIONS
    print("\nProcessing theft transactions...")
    
    for tx in normal_txs:
        if tx["to"].lower() == WALLETS["MAIN"].lower():
            value = Decimal(tx["value"]) / Decimal(10**18)
            src = tx["from"].lower()
            if src == WALLETS["VICTIM_1"].lower() or src == WALLETS["VICTIM_2"].lower():
                audit["theft_transactions"].append({
                    "tx_hash": tx["hash"],
                    "timestamp": ts_to_str(tx["timeStamp"]),
                    "from": tx["from"],
                    "to": tx["to"],
                    "asset": "ETH",
                    "amount": str(value),
                    "source": "VICTIM_1" if src == WALLETS["VICTIM_1"].lower() else "VICTIM_2"
                })
    
    for tx in token_txs:
        if tx["to"].lower() == WALLETS["MAIN"].lower():
            contract = tx.get("contractAddress", "").lower()
            if contract not in TOKENS:
                continue
            info = TOKENS[contract]
            value = Decimal(tx["value"]) / Decimal(10**info["decimals"])
            src = tx["from"].lower()
            if src == WALLETS["VICTIM_1"].lower() or src == WALLETS["VICTIM_2"].lower():
                audit["theft_transactions"].append({
                    "tx_hash": tx["hash"],
                    "timestamp": ts_to_str(tx["timeStamp"]),
                    "from": tx["from"],
                    "to": tx["to"],
                    "asset": info["name"],
                    "amount": str(value),
                    "source": "VICTIM_1" if src == WALLETS["VICTIM_1"].lower() else "VICTIM_2"
                })
    
    # USDT OUTFLOWS - trace where funds went
    print("\nTracing USDT outflows...")
    
    usdt_txs = api_call("account", "tokentx", {
        "address": WALLETS["MAIN"],
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    usdt_in = Decimal(0)
    usdt_out = Decimal(0)
    usdt_out_by_dest = {}
    
    for tx in usdt_txs:
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue
        
        if tx["to"].lower() == WALLETS["MAIN"].lower():
            usdt_in += value
        elif tx["from"].lower() == WALLETS["MAIN"].lower():
            usdt_out += value
            dest = tx["to"]
            if dest not in usdt_out_by_dest:
                usdt_out_by_dest[dest] = {"amount": Decimal(0), "txs": []}
            usdt_out_by_dest[dest]["amount"] += value
            usdt_out_by_dest[dest]["txs"].append({
                "tx_hash": tx["hash"],
                "timestamp": ts_to_str(tx["timeStamp"]),
                "amount": str(value)
            })
    
    # Get current USDT balance
    current_usdt = api_call("account", "tokenbalance", {"contractaddress": USDT_CONTRACT, "address": WALLETS["MAIN"]})
    current_usdt_val = Decimal(current_usdt) / Decimal(10**6) if current_usdt else Decimal(0)
    
    print(f"\nUSDT Summary:")
    print(f"  In: ${usdt_in:,.2f}")
    print(f"  Out: ${usdt_out:,.2f}")
    print(f"  Current: ${current_usdt_val:,.2f}")
    print(f"  Checksum: ${usdt_in - usdt_out - current_usdt_val:.2f} (should be 0)")
    
    # Categorize destinations
    print("\nCategorizing destinations...")
    
    categorized = []
    for dest, data in sorted(usdt_out_by_dest.items(), key=lambda x: x[1]["amount"], reverse=True):
        amount = float(data["amount"])
        label = EXCHANGES.get(dest.lower(), EXCHANGES.get(dest, "Unknown"))
        
        entry = {
            "address": dest,
            "label": label,
            "amount_usd": amount,
            "tx_count": len(data["txs"]),
            "transactions": data["txs"]
        }
        categorized.append(entry)
        
        if amount > 1000:
            print(f"  {dest}: ${amount:,.2f} -> {label}")
    
    audit["usdt_outflows"] = categorized
    
    # Current balances (dormant funds)
    print("\nChecking dormant funds in main wallet...")
    
    eth_balance = api_call("account", "balance", {"address": WALLETS["MAIN"]})
    eth_val = Decimal(eth_balance) / Decimal(10**18) if eth_balance else Decimal(0)
    
    audit["dormant_funds"] = [
        {
            "wallet": WALLETS["MAIN"],
            "label": "Attacker Main Wallet",
            "eth_balance": str(eth_val),
            "usdt_balance": str(current_usdt_val)
        }
    ]
    
    # Reconciliation
    print("\nBuilding reconciliation...")
    
    audit["reconciliation"] = {
        "usdt_total_in": str(usdt_in),
        "usdt_total_out": str(usdt_out),
        "usdt_current_balance": str(current_usdt_val),
        "usdt_checksum": str(usdt_in - usdt_out - current_usdt_val),
        "eth_current_balance": str(eth_val),
        "exchange_deposits_summary": {
            "gate_io": sum(float(c["amount_usd"]) for c in categorized if "Gate" in c["label"]),
            "bybit": sum(float(c["amount_usd"]) for c in categorized if "Bybit" in c["label"]),
            "bitget": sum(float(c["amount_usd"]) for c in categorized if "Bitget" in c["label"]),
            "whitebit": sum(float(c["amount_usd"]) for c in categorized if "WhiteBIT" in c["label"]),
            "other": sum(float(c["amount_usd"]) for c in categorized if c["label"] == "Unknown" and float(c["amount_usd"]) > 1000),
        }
    }
    
    # Save complete audit
    with open("heist_complete_audit.json", "w") as f:
        json.dump(audit, f, indent=2)
    
    print(f"\n{'='*80}")
    print("AUDIT COMPLETE")
    print(f"{'='*80}")
    print(f"\nTheft TXs: {len(audit['theft_transactions'])}")
    print(f"USDT Outflow destinations: {len(audit['usdt_outflows'])}")
    print(f"\nReconciliation:")
    for k, v in audit["reconciliation"].items():
        print(f"  {k}: {v}")
    
    print("\nSaved to: heist_complete_audit.json")

if __name__ == "__main__":
    main()
