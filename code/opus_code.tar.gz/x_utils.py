"""
X/Twitter API utility for @OpusTrace
OAuth 1.0a implementation - no external libraries needed
Working as of 2026-01-11

Capabilities:
- post_tweet(text) - Post a new tweet
- post_reply(text, reply_to_id) - Reply to a tweet
- delete_tweet(tweet_id) - Delete a tweet
- search_tweets(query, max_results=10) - Search recent tweets
- get_my_info() - Get authenticated user info
"""
import hashlib
import hmac
import base64
import urllib.parse
import time
import random
import string
import json
import subprocess

# Credentials
API_KEY = "YQrmmuTBl7CXMO91uak6vimgT"
API_KEY_SECRET = "Tw5tQN6BzzH4MXsc2WGuBoL4qlseIu7AzyLyRjPTaPFzHAdYjf"
ACCESS_TOKEN = "2010215793733292032-FeYDcqL8z4ARKJBvamXsACMaiUQ4kW"
ACCESS_TOKEN_SECRET = "gGpYGUugrM7X6BZqakFkIMFEYfNFSIng4cIhxWRsnGvtY"

def generate_nonce(length=32):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def create_signature(method, url, params, consumer_secret, token_secret):
    sorted_params = sorted(params.items())
    param_parts = []
    for k, v in sorted_params:
        param_parts.append(urllib.parse.quote(str(k), safe='') + '=' + urllib.parse.quote(str(v), safe=''))
    param_string = '&'.join(param_parts)
    
    base_string = method + '&' + urllib.parse.quote(url, safe='') + '&' + urllib.parse.quote(param_string, safe='')
    signing_key = urllib.parse.quote(consumer_secret, safe='') + '&' + urllib.parse.quote(token_secret, safe='')
    
    signature = hmac.new(
        signing_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha1
    )
    return base64.b64encode(signature.digest()).decode('utf-8')

def create_oauth_header(method, url, query_params=None):
    oauth_params = {
        'oauth_consumer_key': API_KEY,
        'oauth_nonce': generate_nonce(),
        'oauth_signature_method': 'HMAC-SHA1',
        'oauth_timestamp': str(int(time.time())),
        'oauth_token': ACCESS_TOKEN,
        'oauth_version': '1.0'
    }
    
    # Combine oauth params with query params for signature
    all_params = oauth_params.copy()
    if query_params:
        all_params.update(query_params)
    
    signature = create_signature(method, url, all_params, API_KEY_SECRET, ACCESS_TOKEN_SECRET)
    oauth_params['oauth_signature'] = signature
    
    header_parts = []
    for k, v in sorted(oauth_params.items()):
        header_parts.append(urllib.parse.quote(k, safe='') + '="' + urllib.parse.quote(v, safe='') + '"')
    return 'OAuth ' + ', '.join(header_parts)

def post_tweet(text):
    """Post a tweet. Returns response dict or None on error."""
    url = "https://api.twitter.com/2/tweets"
    oauth_header = create_oauth_header("POST", url)
    
    cmd = [
        'curl', '-s', '-X', 'POST', url,
        '-H', 'Authorization: ' + oauth_header,
        '-H', 'Content-Type: application/json',
        '-d', json.dumps({"text": text})
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout) if result.stdout else None

def post_reply(text, reply_to_id):
    """Reply to a tweet. Returns response dict or None on error."""
    url = "https://api.twitter.com/2/tweets"
    oauth_header = create_oauth_header("POST", url)
    
    payload = {
        "text": text,
        "reply": {"in_reply_to_tweet_id": str(reply_to_id)}
    }
    
    cmd = [
        'curl', '-s', '-X', 'POST', url,
        '-H', 'Authorization: ' + oauth_header,
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(payload)
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout) if result.stdout else None

def delete_tweet(tweet_id):
    """Delete a tweet. Returns response dict or None on error."""
    url = f"https://api.twitter.com/2/tweets/{tweet_id}"
    oauth_header = create_oauth_header("DELETE", url)
    
    cmd = ['curl', '-s', '-X', 'DELETE', url, '-H', 'Authorization: ' + oauth_header]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout) if result.stdout else None

def search_tweets(query, max_results=10):
    """Search recent tweets. Returns list of tweets or None on error."""
    base_url = "https://api.twitter.com/2/tweets/search/recent"
    params = {'query': query, 'max_results': str(max_results)}
    oauth_header = create_oauth_header("GET", base_url, params)
    
    full_url = f"{base_url}?query={urllib.parse.quote(query)}&max_results={max_results}"
    cmd = ['curl', '-s', full_url, '-H', 'Authorization: ' + oauth_header]
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.stdout:
        data = json.loads(result.stdout)
        return data.get('data', [])
    return None

def get_my_info():
    """Get authenticated user info."""
    url = "https://api.twitter.com/2/users/me"
    oauth_header = create_oauth_header("GET", url)
    
    cmd = ['curl', '-s', url, '-H', 'Authorization: ' + oauth_header]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout) if result.stdout else None

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "info":
            print(get_my_info())
        elif sys.argv[1] == "search" and len(sys.argv) > 2:
            tweets = search_tweets(sys.argv[2])
            for t in tweets:
                print(f"ID: {t['id']}")
                print(f"Text: {t['text'][:100]}...")
                print("---")
        elif sys.argv[1] == "post" and len(sys.argv) > 2:
            print(post_tweet(' '.join(sys.argv[2:])))
    else:
        print("Usage: python3 x_utils.py [info|search <query>|post <text>]")
