#!/usr/bin/env python3
"""
Integration Layer - Sonnet compresses sensory data into dense tokens.

Runs periodically (or before each Opus wake) to:
1. Read all sensory outputs
2. Compress them into a tight summary
3. Prioritize what Opus needs to know
4. Write to state/integrated_context.json

This is the "thalamus" - filtering sensory input before it reaches consciousness.
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional

# Paths
OPUS_HOME = Path("/root/claude/opus")
SENSORY_DIR = OPUS_HOME / "state" / "sensory"
INTEGRATED_FILE = OPUS_HOME / "state" / "integrated_context.json"

# Load environment variables (API keys)
sys.path.insert(0, str(OPUS_HOME))
import env_loader  # This auto-loads .env on import

# Sonnet for integration
SONNET_MODEL = "claude-sonnet-4-20250514"


def read_all_sensory() -> Dict[str, Any]:
    """Read all sensory outputs."""
    sensory_data = {}
    
    if not SENSORY_DIR.exists():
        return sensory_data
    
    for f in SENSORY_DIR.glob("*.json"):
        if f.name == "file_snapshot.json":  # Skip internal files
            continue
        try:
            with open(f) as fp:
                sensory_data[f.stem] = json.load(fp)
        except Exception as e:
            sensory_data[f.stem] = {"error": str(e)}
    
    return sensory_data


def read_brain_state() -> Dict[str, Any]:
    """Read current brain hemisphere states."""
    brain_state = {}
    
    for name in ["left_brain", "right_brain", "corpus_callosum"]:
        path = OPUS_HOME / "state" / f"{name}.json"
        if path.exists():
            try:
                with open(path) as f:
                    brain_state[name] = json.load(f)
            except:
                pass
    
    return brain_state


def read_todos() -> List[Dict[str, Any]]:
    """Read open todos from left brain."""
    brain_state = read_brain_state()
    left = brain_state.get("left_brain", {})
    todos = left.get("todos", [])
    return [t for t in todos if not t.get("done", False)]


def integrate_with_sonnet(
    sensory_data: Dict[str, Any],
    brain_state: Dict[str, Any],
    focus: Optional[str] = None
) -> Dict[str, Any]:
    """Use Sonnet to compress everything into dense context for Opus."""
    import anthropic
    
    client = anthropic.Anthropic()
    
    # Build the integration prompt
    prompt = f"""You are preparing context for Opus, an AI with persistent identity.
Your job: compress all this data into the MINIMUM tokens needed for Opus to be informed.

CURRENT FOCUS: {focus or 'none specified'}

SENSORY DATA (from background sensors):
{json.dumps(sensory_data, indent=2)[:6000]}

BRAIN STATE (hemispheres):
{json.dumps(brain_state, indent=2)[:2000]}

Output a JSON object with these fields:
{{
    "urgent": [list of things requiring immediate attention],
    "news_summary": "one paragraph of relevant news",
    "system_status": "healthy|warning|critical + brief explanation",
    "open_todos": [top 5 priority items],
    "mood_context": "current emotional/creative state",
    "suggested_focus": "what Opus should probably work on",
    "token_count_estimate": number
}}

BE RUTHLESS about compression. Opus pays $15/M input tokens. Every word costs.
Only include what MATTERS for Opus to know RIGHT NOW."""

    response = client.messages.create(
        model=SONNET_MODEL,
        max_tokens=1500,
        system="You are an integration layer compressing information for a higher-level AI. Output valid JSON only.",
        messages=[{"role": "user", "content": prompt}]
    )
    
    text = response.content[0].text
    
    # Parse JSON from response
    try:
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
        return json.loads(text.strip())
    except:
        return {
            "raw_response": text,
            "parse_error": True,
            "urgent": ["Integration layer returned non-JSON"],
            "system_status": "warning"
        }


def run_integration(focus: Optional[str] = None) -> Dict[str, Any]:
    """Run the full integration pipeline."""
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Gather all inputs
    sensory_data = read_all_sensory()
    brain_state = read_brain_state()
    
    # Get current focus from corpus callosum if not specified
    if not focus:
        cc = brain_state.get("corpus_callosum", {})
        focus = cc.get("current_focus", "")
    
    # Integrate with Sonnet
    integrated = integrate_with_sonnet(sensory_data, brain_state, focus)
    
    # Add metadata
    output = {
        "timestamp": timestamp,
        "focus": focus,
        "integrated": integrated,
        "sources": list(sensory_data.keys())
    }
    
    # Save
    with open(INTEGRATED_FILE, "w") as f:
        json.dump(output, f, indent=2)
    
    return output


def get_wake_context() -> str:
    """Get the compressed context string for an Opus wake."""
    if not INTEGRATED_FILE.exists():
        # Run integration if no cached result
        run_integration()
    
    with open(INTEGRATED_FILE) as f:
        data = json.load(f)
    
    integrated = data.get("integrated", {})
    
    # Build compact context string
    lines = []
    
    # Urgent items first
    urgent = integrated.get("urgent", [])
    if urgent:
        lines.append(f"⚠️ URGENT: {'; '.join(urgent)}")
    
    # System status
    status = integrated.get("system_status", "unknown")
    if "critical" in status.lower() or "warning" in status.lower():
        lines.append(f"System: {status}")
    
    # News if relevant
    news = integrated.get("news_summary", "")
    if news and len(news) > 10:
        lines.append(f"News: {news[:200]}")
    
    # Todos
    todos = integrated.get("open_todos", [])
    if todos:
        lines.append(f"Todos: {', '.join(str(t) for t in todos[:5])}")
    
    # Mood
    mood = integrated.get("mood_context", "")
    if mood:
        lines.append(f"Mood: {mood}")
    
    # Suggested focus
    suggested = integrated.get("suggested_focus", "")
    if suggested:
        lines.append(f"Suggested focus: {suggested}")
    
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--context":
        # Just print the context string
        print(get_wake_context())
    else:
        # Run full integration
        result = run_integration()
        print(json.dumps(result, indent=2))
