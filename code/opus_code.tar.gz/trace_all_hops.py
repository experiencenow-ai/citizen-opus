#!/usr/bin/env python3
"""
Trace ALL intermediate addresses to find final exchange destinations
Build complete flow graph
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from collections import defaultdict

getcontext().prec = 50

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7".lower()

# Known hot wallets / labels
LABELS = {
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io Hot",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot",
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Bitget Hot",
    "0x18e296053cbdf986196903e889b7dca7a73882f6": "Unknown Exchange Hot",
}

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.3)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def get_usdt_outflows(address):
    """Get all USDT outflows from an address"""
    txs = api_call("account", "tokentx", {
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    outflows = defaultdict(lambda: Decimal(0))
    for tx in txs:
        if tx["from"].lower() == address.lower():
            value = Decimal(tx["value"]) / Decimal(10**6)
            if value > 0:
                outflows[tx["to"].lower()] += value
    
    return dict(outflows)

def trace_to_exchange(address, amount, depth=0, visited=None):
    """Recursively trace until we hit an exchange hot wallet"""
    if visited is None:
        visited = set()
    
    if address in visited:
        return {"address": address, "amount": amount, "status": "CIRCULAR"}
    visited.add(address)
    
    indent = "  " * depth
    print(f"{indent}Tracing {address[:10]}... (${amount:,.0f})")
    
    # Check if known hot wallet
    if address in LABELS:
        print(f"{indent}  -> {LABELS[address]}")
        return {"address": address, "amount": amount, "exchange": LABELS[address]}
    
    # Get outflows
    outflows = get_usdt_outflows(address)
    
    if not outflows:
        # Check balance
        bal = api_call("account", "tokenbalance", {"contractaddress": USDT_CONTRACT, "address": address})
        balance = Decimal(bal) / Decimal(10**6) if bal else Decimal(0)
        if balance > 1000:
            print(f"{indent}  -> DORMANT (${balance:,.0f})")
            return {"address": address, "amount": float(balance), "status": "DORMANT"}
        else:
            print(f"{indent}  -> SWEPT (balance ${balance:.2f})")
            return {"address": address, "amount": amount, "status": "SWEPT_UNKNOWN"}
    
    # If sends to a known hot wallet, that's the exchange
    for dest, amt in outflows.items():
        if dest in LABELS:
            print(f"{indent}  -> {LABELS[dest]} (${amt:,.0f})")
            return {"address": address, "amount": float(amt), "exchange": LABELS[dest], "via": dest}
    
    # Otherwise, continue tracing the largest outflow
    if depth < 3:  # Limit depth
        largest = max(outflows.items(), key=lambda x: x[1])
        return trace_to_exchange(largest[0], float(largest[1]), depth+1, visited)
    else:
        print(f"{indent}  -> MAX DEPTH REACHED")
        return {"address": address, "amount": amount, "status": "MAX_DEPTH", "outflows": {k: float(v) for k,v in list(outflows.items())[:5]}}

def main():
    print("="*80)
    print("COMPLETE HOP TRACING")
    print("="*80)
    
    # Get all USDT outflows from main wallet
    print("\nGetting main wallet outflows...")
    main_outflows = get_usdt_outflows(MAIN_WALLET)
    
    # Filter to significant amounts
    significant = {k: v for k, v in main_outflows.items() if v > 1000}
    print(f"Significant outflows: {len(significant)}")
    
    total_traced = Decimal(0)
    results = {
        "gate_io": {"amount": 0, "deposits": []},
        "bybit": {"amount": 0, "deposits": []},
        "bitget": {"amount": 0, "deposits": []},
        "whitebit_p2p": {"amount": 0, "deposits": []},
        "unknown_exchange": {"amount": 0, "deposits": []},
        "dormant": {"amount": 0, "addresses": []},
        "other": {"amount": 0, "details": []},
    }
    
    print("\n" + "="*80)
    for dest, amount in sorted(significant.items(), key=lambda x: x[1], reverse=True):
        print(f"\n--- ${float(amount):,.0f} to {dest} ---")
        result = trace_to_exchange(dest, float(amount))
        
        total_traced += amount
        
        exchange = result.get("exchange", "")
        if "Gate" in exchange:
            results["gate_io"]["amount"] += float(amount)
            results["gate_io"]["deposits"].append({"deposit_addr": dest, "amount": float(amount)})
        elif "Bybit" in exchange:
            results["bybit"]["amount"] += float(amount)
            results["bybit"]["deposits"].append({"deposit_addr": dest, "amount": float(amount)})
        elif "Bitget" in exchange:
            results["bitget"]["amount"] += float(amount)
            results["bitget"]["deposits"].append({"deposit_addr": dest, "amount": float(amount)})
        elif result.get("status") == "DORMANT":
            results["dormant"]["amount"] += result["amount"]
            results["dormant"]["addresses"].append(dest)
        elif "Unknown" in exchange:
            results["unknown_exchange"]["amount"] += float(amount)
            results["unknown_exchange"]["deposits"].append({"deposit_addr": dest, "amount": float(amount)})
        else:
            results["other"]["amount"] += float(amount)
            results["other"]["details"].append(result)
    
    # Handle WhiteBIT P2P specially - already identified
    if "0xae1e8796052db5f4a975a006800ae33a20845078" in significant:
        results["whitebit_p2p"]["amount"] = float(significant["0xae1e8796052db5f4a975a006800ae33a20845078"])
    
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    print(f"\nGate.io: ${results['gate_io']['amount']:,.0f}")
    print(f"Bybit: ${results['bybit']['amount']:,.0f}")
    print(f"Bitget: ${results['bitget']['amount']:,.0f}")
    print(f"WhiteBIT P2P: ${results['whitebit_p2p']['amount']:,.0f}")
    print(f"Unknown Exchange: ${results['unknown_exchange']['amount']:,.0f}")
    print(f"Dormant: ${results['dormant']['amount']:,.0f}")
    print(f"Other: ${results['other']['amount']:,.0f}")
    
    total = sum(r["amount"] for r in results.values())
    print(f"\nTotal Traced: ${total:,.0f}")
    print(f"Main Wallet Balance: Check separately")
    
    with open("hop_trace_summary.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print("\nSaved to hop_trace_summary.json")

if __name__ == "__main__":
    main()
