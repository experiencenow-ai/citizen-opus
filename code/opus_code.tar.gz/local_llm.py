#!/usr/bin/env python3
"""
Local LLM - Ollama wrapper for free local inference.

Models:
- FAST: mistral-nemo (12B) - email triage, filtering, quick tasks
- QUALITY: qwen2.5:72b - consolidation, summarization, complex reasoning
- EMBED: nomic-embed-text - semantic embeddings

All run locally. All free. All the time.
"""

import json
import requests
from typing import Optional, List, Dict, Any, Generator
from dataclasses import dataclass
from enum import Enum
import time

OLLAMA_BASE = "http://localhost:11434"


class ModelTier(Enum):
    FAST = "fast"       # Quick tasks, always loaded
    QUALITY = "quality" # Complex tasks, loaded on demand
    EMBED = "embed"     # Embeddings only


@dataclass
class ModelConfig:
    name: str
    ollama_name: str
    tier: ModelTier
    context_length: int
    description: str


# Model configurations - update these based on what you pull
MODELS = {
    "fast": ModelConfig(
        name="fast",
        ollama_name="mistral-nemo",  # or "llama3.1:8b"
        tier=ModelTier.FAST,
        context_length=32768,
        description="Fast model for triage, filtering, classification"
    ),
    "quality": ModelConfig(
        name="quality", 
        ollama_name="qwen2.5:72b",  # or "llama3.1:70b"
        tier=ModelTier.QUALITY,
        context_length=32768,
        description="Quality model for consolidation, complex reasoning"
    ),
    "embed": ModelConfig(
        name="embed",
        ollama_name="nomic-embed-text",
        tier=ModelTier.EMBED,
        context_length=8192,
        description="Embedding model for semantic search"
    )
}


def check_ollama() -> bool:
    """Check if Ollama is running."""
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        return r.status_code == 200
    except:
        return False


def list_models() -> List[str]:
    """List available models in Ollama."""
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=10)
        if r.status_code == 200:
            data = r.json()
            return [m["name"] for m in data.get("models", [])]
    except:
        pass
    return []


def pull_model(model_name: str) -> bool:
    """Pull a model if not already available."""
    print(f"Pulling {model_name}...")
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/pull",
            json={"name": model_name},
            stream=True,
            timeout=3600  # Models can take a while
        )
        for line in r.iter_lines():
            if line:
                data = json.loads(line)
                status = data.get("status", "")
                if "pulling" in status or "downloading" in status:
                    print(f"  {status}", end="\r")
        print(f"\n{model_name} ready")
        return True
    except Exception as e:
        print(f"Failed to pull {model_name}: {e}")
        return False


def generate(
    prompt: str,
    model: str = "fast",
    system: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 2048,
    stream: bool = False
) -> str:
    """
    Generate text using local LLM.
    
    Args:
        prompt: The user prompt
        model: "fast", "quality", or specific ollama model name
        system: Optional system prompt
        temperature: 0.0-1.0
        max_tokens: Maximum tokens to generate
        stream: If True, yields chunks
    
    Returns:
        Generated text
    """
    # Resolve model name
    if model in MODELS:
        ollama_model = MODELS[model].ollama_name
    else:
        ollama_model = model
    
    payload = {
        "model": ollama_model,
        "prompt": prompt,
        "stream": stream,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        }
    }
    
    if system:
        payload["system"] = system
    
    try:
        if stream:
            return _generate_stream(payload)
        else:
            r = requests.post(
                f"{OLLAMA_BASE}/api/generate",
                json=payload,
                timeout=300  # 5 min timeout for slow models
            )
            if r.status_code == 200:
                return r.json().get("response", "")
            else:
                return f"[Error: {r.status_code}]"
    except requests.Timeout:
        return "[Error: Timeout]"
    except Exception as e:
        return f"[Error: {e}]"


def _generate_stream(payload: dict) -> Generator[str, None, None]:
    """Stream generation."""
    r = requests.post(
        f"{OLLAMA_BASE}/api/generate",
        json=payload,
        stream=True,
        timeout=300
    )
    for line in r.iter_lines():
        if line:
            data = json.loads(line)
            chunk = data.get("response", "")
            if chunk:
                yield chunk


def chat(
    messages: List[Dict[str, str]],
    model: str = "fast",
    temperature: float = 0.7,
    max_tokens: int = 2048
) -> str:
    """
    Chat completion using local LLM.
    
    Args:
        messages: List of {"role": "user"|"assistant"|"system", "content": str}
        model: "fast", "quality", or specific ollama model name
    
    Returns:
        Assistant response
    """
    if model in MODELS:
        ollama_model = MODELS[model].ollama_name
    else:
        ollama_model = model
    
    payload = {
        "model": ollama_model,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        }
    }
    
    try:
        r = requests.post(
            f"{OLLAMA_BASE}/api/chat",
            json=payload,
            timeout=300
        )
        if r.status_code == 200:
            return r.json().get("message", {}).get("content", "")
        else:
            return f"[Error: {r.status_code}]"
    except Exception as e:
        return f"[Error: {e}]"


def embed(texts: List[str], model: str = "embed") -> List[List[float]]:
    """
    Generate embeddings for texts.
    
    Args:
        texts: List of strings to embed
        model: Embedding model name
    
    Returns:
        List of embedding vectors
    """
    if model in MODELS:
        ollama_model = MODELS[model].ollama_name
    else:
        ollama_model = model
    
    embeddings = []
    for text in texts:
        try:
            r = requests.post(
                f"{OLLAMA_BASE}/api/embeddings",
                json={"model": ollama_model, "prompt": text},
                timeout=30
            )
            if r.status_code == 200:
                embeddings.append(r.json().get("embedding", []))
            else:
                embeddings.append([])
        except:
            embeddings.append([])
    
    return embeddings


def embed_single(text: str, model: str = "embed") -> List[float]:
    """Embed a single text."""
    result = embed([text], model)
    return result[0] if result else []


# Convenience functions for common tasks

def triage_email(email_from: str, subject: str, snippet: str) -> Dict[str, Any]:
    """
    Triage an email - is it important? spam? needs response?
    Uses FAST model.
    """
    prompt = f"""Triage this email. Output JSON only.

From: {email_from}
Subject: {subject}
Preview: {snippet}

Output format:
{{"priority": "high|medium|low|spam", "needs_response": true|false, "category": "string", "summary": "one line"}}"""

    response = generate(prompt, model="fast", temperature=0.3)
    
    try:
        # Extract JSON from response
        if "{" in response and "}" in response:
            json_str = response[response.index("{"):response.rindex("}")+1]
            return json.loads(json_str)
    except:
        pass
    
    return {"priority": "medium", "needs_response": True, "category": "unknown", "summary": snippet[:50]}


def filter_news(items: List[Dict[str, str]], interests: List[str]) -> List[Dict[str, Any]]:
    """
    Filter news items by relevance.
    Uses FAST model.
    """
    items_text = "\n".join([f"- {item.get('title', '')}" for item in items[:20]])
    interests_text = ", ".join(interests)
    
    prompt = f"""Filter these news items for relevance to: {interests_text}

News items:
{items_text}

Output JSON array of relevant items with relevance score 1-10:
[{{"title": "...", "relevance": N, "why": "brief reason"}}]

Only include items with relevance >= 6."""

    response = generate(prompt, model="fast", temperature=0.3)
    
    try:
        if "[" in response and "]" in response:
            json_str = response[response.index("["):response.rindex("]")+1]
            return json.loads(json_str)
    except:
        pass
    
    return []


def summarize_for_memory(text: str, max_words: int = 100) -> str:
    """
    Summarize text for memory storage.
    Uses FAST model for short texts, QUALITY for long.
    """
    model = "fast" if len(text) < 2000 else "quality"
    
    prompt = f"""Summarize this for long-term memory storage. Be concise but preserve key facts.
Maximum {max_words} words.

Text:
{text}

Summary:"""

    return generate(prompt, model=model, temperature=0.3, max_tokens=200)


def consolidate_memories(memories: List[str]) -> Dict[str, Any]:
    """
    Consolidate multiple memories into insights.
    Uses QUALITY model.
    """
    memories_text = "\n---\n".join(memories)
    
    prompt = f"""Analyze these memories and extract insights.

Memories:
{memories_text}

Output JSON:
{{
    "key_insights": ["insight1", "insight2"],
    "patterns": ["pattern1", "pattern2"],
    "should_remember": ["important fact 1", "important fact 2"],
    "can_forget": ["redundant or outdated item"]
}}"""

    response = generate(prompt, model="quality", temperature=0.5, max_tokens=1000)
    
    try:
        if "{" in response and "}" in response:
            json_str = response[response.index("{"):response.rindex("}")+1]
            return json.loads(json_str)
    except:
        pass
    
    return {"key_insights": [], "patterns": [], "should_remember": [], "can_forget": []}


class LocalLLM:
    """
    Convenience class for local LLM operations.
    """
    def __init__(self):
        self.available = check_ollama()
        if self.available:
            self.models = list_models()
        else:
            self.models = []
    
    def ensure_models(self):
        """Ensure required models are pulled."""
        for config in MODELS.values():
            if config.ollama_name not in self.models:
                pull_model(config.ollama_name)
        self.models = list_models()
    
    def generate(self, prompt: str, **kwargs) -> str:
        return generate(prompt, **kwargs)
    
    def chat(self, messages: List[Dict], **kwargs) -> str:
        return chat(messages, **kwargs)
    
    def embed(self, texts: List[str]) -> List[List[float]]:
        return embed(texts)
    
    def triage_email(self, **kwargs) -> Dict:
        return triage_email(**kwargs)
    
    def filter_news(self, items: List[Dict], interests: List[str]) -> List[Dict]:
        return filter_news(items, interests)
    
    def summarize(self, text: str, **kwargs) -> str:
        return summarize_for_memory(text, **kwargs)
    
    def consolidate(self, memories: List[str]) -> Dict:
        return consolidate_memories(memories)


if __name__ == "__main__":
    import sys
    
    print("=== Local LLM Status ===")
    
    if not check_ollama():
        print("❌ Ollama not running!")
        print("\nInstall and start Ollama:")
        print("  curl -fsSL https://ollama.com/install.sh | sh")
        print("  ollama serve")
        sys.exit(1)
    
    print("✓ Ollama running")
    
    models = list_models()
    print(f"\nAvailable models: {models}")
    
    print("\nRequired models:")
    for name, config in MODELS.items():
        status = "✓" if config.ollama_name in models else "✗ (need to pull)"
        print(f"  {name}: {config.ollama_name} {status}")
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--pull":
            print("\nPulling required models...")
            for config in MODELS.values():
                if config.ollama_name not in models:
                    pull_model(config.ollama_name)
        
        elif sys.argv[1] == "--test":
            print("\nTesting fast model...")
            start = time.time()
            response = generate("What is 2+2? Answer briefly.", model="fast")
            elapsed = time.time() - start
            print(f"Response: {response}")
            print(f"Time: {elapsed:.2f}s")
            
            print("\nTesting embeddings...")
            start = time.time()
            vectors = embed(["Hello world", "Test embedding"])
            elapsed = time.time() - start
            print(f"Embedded 2 texts in {elapsed:.2f}s")
            print(f"Vector dimension: {len(vectors[0]) if vectors and vectors[0] else 'N/A'}")
    else:
        print("\nUsage:")
        print("  python local_llm.py --pull   # Pull required models")
        print("  python local_llm.py --test   # Test inference")
