#!/usr/bin/env python3
"""
Complete heist reconciliation - every TX, every satoshi accounted for.
Uses Etherscan V2 API with correct key: 7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from collections import defaultdict

getcontext().prec = 50

# CORRECT API KEY
ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"

# Known attacker wallets
MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"
HOP1 = "0x525254e59F6ED01FfC1B5fef3f68aAAa08Ce7e4F"
HOP2 = "0xf99BEDe1da17484ee48Bd9F1DE82E7353a79D3c7"

# Victim wallets
VICTIM_1 = "0x3eADF348745F80a3d9245AeA621dE0957C65c53F"
VICTIM_2 = "0x777deFa08C49f1ebd77B87abE664f47Dc14Cc5f7"

# Valuable tokens (filter out garbage)
VALUABLE_TOKENS = {
    "0xdac17f958d2ee523a2206206994597c13d831ec7": "USDT",  # USDT
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": "USDC",  # USDC
    "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0": "wstETH", # wstETH
    "0x18084fba666a33d37592fa2633fd49a74dd93a88": "tBTC",  # tBTC
    "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599": "WBTC",  # WBTC
    "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": "WETH",  # WETH
    "0x6b175474e89094c44da98b954eedeac495271d0f": "DAI",   # DAI
}

def etherscan_v2_request(module, action, params):
    """Make Etherscan V2 API request"""
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1  # Ethereum mainnet
    
    time.sleep(0.25)  # Rate limit
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    
    if data.get("status") != "1":
        if "No transactions found" in data.get("message", ""):
            return []
        print(f"  API Error: {data}")
        return None
    return data.get("result", [])

def get_normal_txs(address):
    """Get normal ETH transactions"""
    return etherscan_v2_request("account", "txlist", {
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })

def get_internal_txs(address):
    """Get internal transactions"""
    return etherscan_v2_request("account", "txlistinternal", {
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })

def get_token_txs(address):
    """Get ERC20 token transfers"""
    return etherscan_v2_request("account", "tokentx", {
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })

def get_eth_balance(address):
    """Get current ETH balance"""
    result = etherscan_v2_request("account", "balance", {"address": address})
    if result:
        return Decimal(result) / Decimal(10**18)
    return Decimal(0)

def wei_to_eth(wei):
    return Decimal(wei) / Decimal(10**18)

def format_ts(ts):
    from datetime import datetime
    return datetime.utcfromtimestamp(int(ts)).strftime('%Y-%m-%d %H:%M:%S UTC')

def analyze_wallet(address, label):
    """Full analysis of a wallet"""
    print(f"\n{'='*80}")
    print(f"ANALYZING: {address}")
    print(f"LABEL: {label}")
    print(f"{'='*80}")
    
    # Get all transaction types
    normal_txs = get_normal_txs(address) or []
    internal_txs = get_internal_txs(address) or []
    token_txs = get_token_txs(address) or []
    current_balance = get_eth_balance(address)
    
    print(f"\nTransaction counts:")
    print(f"  Normal TXs: {len(normal_txs)}")
    print(f"  Internal TXs: {len(internal_txs)}")
    print(f"  Token TXs: {len(token_txs)}")
    print(f"  Current ETH balance: {current_balance}")
    
    # Process normal transactions
    inflows = []
    outflows = []
    
    for tx in normal_txs:
        value_eth = wei_to_eth(tx.get("value", "0"))
        if value_eth == 0:
            continue
            
        tx_data = {
            "hash": tx["hash"],
            "timestamp": format_ts(tx["timeStamp"]),
            "timestamp_unix": int(tx["timeStamp"]),
            "from": tx["from"],
            "to": tx["to"],
            "value_eth": float(value_eth),
            "type": "ETH"
        }
        
        if tx["to"].lower() == address.lower():
            inflows.append(tx_data)
        elif tx["from"].lower() == address.lower():
            outflows.append(tx_data)
    
    # Process internal transactions (from swaps, etc)
    for tx in internal_txs:
        value_eth = wei_to_eth(tx.get("value", "0"))
        if value_eth == 0:
            continue
            
        tx_data = {
            "hash": tx["hash"],
            "timestamp": format_ts(tx["timeStamp"]),
            "timestamp_unix": int(tx["timeStamp"]),
            "from": tx["from"],
            "to": tx["to"],
            "value_eth": float(value_eth),
            "type": "ETH_INTERNAL"
        }
        
        if tx["to"].lower() == address.lower():
            inflows.append(tx_data)
        elif tx["from"].lower() == address.lower():
            outflows.append(tx_data)
    
    # Process token transactions - FILTER GARBAGE
    token_inflows = []
    token_outflows = []
    
    for tx in token_txs:
        contract = tx.get("contractAddress", "").lower()
        if contract not in VALUABLE_TOKENS:
            continue  # Skip garbage tokens
        
        decimals = int(tx.get("tokenDecimal", 18))
        value = Decimal(tx.get("value", "0")) / Decimal(10**decimals)
        
        if value == 0:
            continue
            
        tx_data = {
            "hash": tx["hash"],
            "timestamp": format_ts(tx["timeStamp"]),
            "timestamp_unix": int(tx["timeStamp"]),
            "from": tx["from"],
            "to": tx["to"],
            "value": float(value),
            "token": VALUABLE_TOKENS[contract],
            "contract": contract
        }
        
        if tx["to"].lower() == address.lower():
            token_inflows.append(tx_data)
        elif tx["from"].lower() == address.lower():
            token_outflows.append(tx_data)
    
    return {
        "address": address,
        "label": label,
        "current_eth_balance": float(current_balance),
        "eth_inflows": inflows,
        "eth_outflows": outflows,
        "token_inflows": token_inflows,
        "token_outflows": token_outflows,
        "summary": {
            "total_eth_in": sum(t["value_eth"] for t in inflows),
            "total_eth_out": sum(t["value_eth"] for t in outflows),
            "token_in_by_type": {},
            "token_out_by_type": {}
        }
    }

def main():
    print("HEIST RECONCILIATION - FULL TRACE")
    print(f"API KEY: {ETHERSCAN_API_KEY}")
    print("="*80)
    
    results = {}
    
    # Analyze main wallet first
    results["main_wallet"] = analyze_wallet(MAIN_WALLET, "MAIN ATTACKER WALLET")
    
    # Analyze HOP1 and HOP2
    results["hop1"] = analyze_wallet(HOP1, "HOP1 (USDT Staging)")
    results["hop2"] = analyze_wallet(HOP2, "HOP2 (USDT Staging)")
    
    # Save raw results
    with open("heist_full_reconciliation.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "="*80)
    print("RECONCILIATION SAVED TO: heist_full_reconciliation.json")
    print("="*80)
    
    # Print summary
    print("\n\nMAIN WALLET SUMMARY:")
    main = results["main_wallet"]
    print(f"  ETH In:  {main['summary']['total_eth_in']:.6f}")
    print(f"  ETH Out: {main['summary']['total_eth_out']:.6f}")
    print(f"  Current: {main['current_eth_balance']:.6f}")
    
    print("\n  TOKEN INFLOWS:")
    for t in main["token_inflows"]:
        print(f"    {t['timestamp']}: {t['value']:.4f} {t['token']} from {t['from'][:10]}...")
    
    print("\n  TOKEN OUTFLOWS:")
    for t in main["token_outflows"]:
        print(f"    {t['timestamp']}: {t['value']:.4f} {t['token']} to {t['to'][:10]}...")

if __name__ == "__main__":
    main()
