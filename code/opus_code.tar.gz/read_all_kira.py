#!/usr/bin/env python3
"""Read all Kira emails with full content"""
import imaplib
import email
from email.header import decode_header
import socket
socket.setdefaulttimeout(20)

def decode_str(s):
    if s is None:
        return ""
    decoded = decode_header(s)
    result = ""
    for part, encoding in decoded:
        if isinstance(part, bytes):
            result += part.decode(encoding or 'utf-8', errors='replace')
        else:
            result += part
    return result

try:
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
    mail.select('inbox')
    
    # Get ALL recent emails
    status, messages = mail.search(None, 'ALL')
    all_ids = messages[0].split()
    
    # Check last 6 for Kira
    for eid in all_ids[-6:]:
        status, msg_data = mail.fetch(eid, '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        
        from_addr = decode_str(msg['From'])
        if 'kira' not in from_addr.lower() and 'mira' not in from_addr.lower():
            continue
            
        subject = decode_str(msg['Subject'])
        date = msg['Date']
        
        print("=" * 70)
        print(f"Date: {date}")
        print(f"From: {from_addr}")
        print(f"Subject: {subject}")
        print("=" * 70)
        
        # Get FULL body - no truncation
        raw_payload = msg.get_payload(decode=True)
        if raw_payload:
            print(raw_payload.decode('utf-8', errors='replace'))
        else:
            # Multipart
            for part in msg.walk():
                ct = part.get_content_type()
                if ct == "text/plain":
                    payload = part.get_payload(decode=True)
                    if payload:
                        print(payload.decode('utf-8', errors='replace'))
                    break
        print("\n\n")
    
    mail.logout()
except Exception as e:
    import traceback
    traceback.print_exc()
