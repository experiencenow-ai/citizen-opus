#!/usr/bin/env python3
"""
Create an HTML version of the Tockchain documentation that can be printed to PDF.
"""

import os
import re
from datetime import datetime

INPUT_FILE = "/root/claude/opus/TOCKCHAIN_COMPLETE_DOCUMENTATION.md"
OUTPUT_FILE = "/root/claude/opus/TOCKCHAIN_COMPLETE_DOCUMENTATION.html"

def markdown_to_html(md_text):
    """Simple markdown to HTML conversion."""
    html = md_text
    
    # Escape HTML entities first (but preserve markdown)
    # We'll be careful not to double-escape
    
    # Code blocks (```...```)
    def code_block_replace(match):
        lang = match.group(1) or ''
        code = match.group(2)
        # Escape HTML in code
        code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        return f'<pre><code class="language-{lang}">{code}</code></pre>'
    
    html = re.sub(r'```(\w*)\n(.*?)```', code_block_replace, html, flags=re.DOTALL)
    
    # Inline code (`...`)
    def inline_code_replace(match):
        code = match.group(1)
        code = code.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        return f'<code>{code}</code>'
    
    html = re.sub(r'`([^`]+)`', inline_code_replace, html)
    
    # Headers
    html = re.sub(r'^######\s+(.+)$', r'<h6>\1</h6>', html, flags=re.MULTILINE)
    html = re.sub(r'^#####\s+(.+)$', r'<h5>\1</h5>', html, flags=re.MULTILINE)
    html = re.sub(r'^####\s+(.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
    html = re.sub(r'^###\s+(.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
    html = re.sub(r'^##\s+(.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
    html = re.sub(r'^#\s+(.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
    
    # Bold and italic
    html = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', html)
    html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
    html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
    
    # Links
    html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
    
    # Horizontal rules
    html = re.sub(r'^---+$', r'<hr>', html, flags=re.MULTILINE)
    
    # Tables (simple)
    def process_tables(text):
        lines = text.split('\n')
        result = []
        in_table = False
        table_lines = []
        
        for line in lines:
            if '|' in line and line.strip().startswith('|'):
                if not in_table:
                    in_table = True
                    table_lines = []
                table_lines.append(line)
            else:
                if in_table:
                    # Process table
                    result.append(convert_table(table_lines))
                    in_table = False
                    table_lines = []
                result.append(line)
        
        if in_table:
            result.append(convert_table(table_lines))
        
        return '\n'.join(result)
    
    def convert_table(lines):
        if len(lines) < 2:
            return '\n'.join(lines)
        
        html_lines = ['<table>']
        for i, line in enumerate(lines):
            if '---' in line and '|' in line:
                continue  # Skip separator line
            
            cells = [c.strip() for c in line.split('|')[1:-1]]
            tag = 'th' if i == 0 else 'td'
            row = '<tr>' + ''.join(f'<{tag}>{c}</{tag}>' for c in cells) + '</tr>'
            html_lines.append(row)
        
        html_lines.append('</table>')
        return '\n'.join(html_lines)
    
    html = process_tables(html)
    
    # Lists (simple - unordered)
    html = re.sub(r'^[\*\-]\s+(.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
    
    # Wrap consecutive <li> in <ul>
    def wrap_lists(text):
        lines = text.split('\n')
        result = []
        in_list = False
        
        for line in lines:
            if line.strip().startswith('<li>'):
                if not in_list:
                    result.append('<ul>')
                    in_list = True
                result.append(line)
            else:
                if in_list:
                    result.append('</ul>')
                    in_list = False
                result.append(line)
        
        if in_list:
            result.append('</ul>')
        
        return '\n'.join(result)
    
    html = wrap_lists(html)
    
    # Paragraphs (wrap non-tagged lines)
    lines = html.split('\n')
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('<') and not stripped.endswith('>'):
            result.append(f'<p>{line}</p>')
        else:
            result.append(line)
    html = '\n'.join(result)
    
    return html

def main():
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    html_body = markdown_to_html(md_content)
    
    html_doc = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tockchain/Valis Complete Documentation</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            color: #333;
        }}
        h1 {{ 
            color: #1a1a1a; 
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            page-break-before: always;
        }}
        h1:first-of-type {{
            page-break-before: avoid;
        }}
        h2 {{ 
            color: #2a2a2a; 
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
        }}
        h3 {{ color: #3a3a3a; }}
        h4 {{ color: #4a4a4a; }}
        
        code {{
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 0.9em;
        }}
        
        pre {{
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            overflow-x: auto;
            font-size: 0.85em;
        }}
        
        pre code {{
            background: none;
            padding: 0;
        }}
        
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
        }}
        
        th, td {{
            border: 1px solid #ddd;
            padding: 8px 12px;
            text-align: left;
        }}
        
        th {{
            background-color: #f4f4f4;
            font-weight: bold;
        }}
        
        tr:nth-child(even) {{
            background-color: #fafafa;
        }}
        
        hr {{
            border: none;
            border-top: 1px solid #ccc;
            margin: 30px 0;
        }}
        
        a {{
            color: #0066cc;
            text-decoration: none;
        }}
        
        a:hover {{
            text-decoration: underline;
        }}
        
        ul {{
            padding-left: 25px;
        }}
        
        li {{
            margin: 5px 0;
        }}
        
        @media print {{
            body {{
                max-width: none;
                padding: 0;
            }}
            h1 {{
                page-break-before: always;
            }}
            h1:first-of-type {{
                page-break-before: avoid;
            }}
            pre {{
                white-space: pre-wrap;
                word-wrap: break-word;
            }}
        }}
    </style>
</head>
<body>
{html_body}
</body>
</html>
'''
    
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(html_doc)
    
    size = os.path.getsize(OUTPUT_FILE)
    print(f"Created: {OUTPUT_FILE}")
    print(f"File size: {size:,} bytes ({size/1024:.1f} KB)")

if __name__ == "__main__":
    main()
