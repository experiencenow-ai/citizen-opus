#!/usr/bin/env python3
"""
Complete Fund Trace - Every USDT dollar from main wallet traced to final destination
"""

import json
import requests
from datetime import datetime, timezone
from collections import defaultdict
import time

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"

# Known exchange hot wallets (case-insensitive matching)
EXCHANGE_HOT_WALLETS = {
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WHITEBIT",
    "0x559e1ce9855e2bed54004f67865eb41432d74e5b": "WHITEBIT",
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "GATE.IO",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "BYBIT",
    "0x28c6c06298d514db089934071355e5743bf21d60": "BINANCE",
    "0x2f0b23f53734252bda2277357e97e1517d6b042a": "BITGET",
    "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KUCOIN",
    "0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91": "KUCOIN",
    "0xd55a0a99e6f8c96d8c0e8d1b59e35b5f1b4bdea7": "BINGX",
}

def get_usdt_transfers(address, max_retries=3):
    """Get all USDT transfers for an address"""
    url = f"https://api.etherscan.io/v2/api"
    params = {
        "chainid": 1,
        "module": "account",
        "action": "tokentx",
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "sort": "asc",
        "apikey": ETHERSCAN_API_KEY
    }
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, params=params, timeout=30)
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
            elif "rate limit" in str(data.get("message", "")).lower():
                time.sleep(1)
                continue
            return []
        except Exception as e:
            print(f"Error fetching {address}: {e}")
            time.sleep(1)
    return []

def format_amount(amount_str):
    """Convert from raw to USDT (6 decimals)"""
    try:
        return float(amount_str) / 1e6
    except:
        return 0

def get_timestamp(ts):
    return datetime.fromtimestamp(int(ts), timezone.utc).isoformat()

def identify_exchange(address):
    """Check if address is a known exchange hot wallet"""
    lower = address.lower()
    for hot, name in EXCHANGE_HOT_WALLETS.items():
        if lower == hot.lower():
            return name
    return None

def trace_destination(address, max_depth=3, path=[]):
    """Trace an address to find where its funds went"""
    if max_depth == 0:
        return {"address": address, "status": "MAX_DEPTH_REACHED", "balance": None}
    
    exchange = identify_exchange(address)
    if exchange:
        return {"address": address, "status": "EXCHANGE", "exchange": exchange}
    
    txs = get_usdt_transfers(address)
    if not txs:
        return {"address": address, "status": "NO_TXS_FOUND", "balance": None}
    
    outflows = []
    inflows = []
    
    for tx in txs:
        amount = format_amount(tx.get("value", "0"))
        if amount == 0:
            continue
        if tx.get("from", "").lower() == address.lower():
            outflows.append({
                "tx_hash": tx.get("hash"),
                "to": tx.get("to"),
                "amount": amount,
                "timestamp": get_timestamp(tx.get("timeStamp", 0)),
                "block": int(tx.get("blockNumber", 0))
            })
        elif tx.get("to", "").lower() == address.lower():
            inflows.append({
                "tx_hash": tx.get("hash"),
                "from": tx.get("from"),
                "amount": amount,
                "timestamp": get_timestamp(tx.get("timeStamp", 0)),
                "block": int(tx.get("blockNumber", 0))
            })
    
    total_in = sum(t["amount"] for t in inflows)
    total_out = sum(t["amount"] for t in outflows)
    balance = total_in - total_out
    
    if total_out < 1:  # Less than $1 out
        return {
            "address": address,
            "status": "DORMANT",
            "balance_usdt": round(balance, 2),
            "total_in": round(total_in, 2),
            "total_out": round(total_out, 2)
        }
    
    # Trace destinations
    destinations = []
    for tx in outflows:
        dest_addr = tx["to"]
        dest_exchange = identify_exchange(dest_addr)
        if dest_exchange:
            destinations.append({
                "tx_hash": tx["tx_hash"],
                "to": dest_addr,
                "amount": tx["amount"],
                "exchange": dest_exchange,
                "status": "DEPOSITED_TO_EXCHANGE"
            })
        else:
            destinations.append({
                "tx_hash": tx["tx_hash"],
                "to": dest_addr,
                "amount": tx["amount"],
                "status": "INTERMEDIATE"
            })
    
    return {
        "address": address,
        "status": "TRACED",
        "total_in": round(total_in, 2),
        "total_out": round(total_out, 2),
        "balance_usdt": round(balance, 2),
        "outflow_count": len(outflows),
        "outflows": destinations
    }

def main():
    print("=" * 80)
    print("COMPLETE FUND TRACE - LEGAL AUDIT")
    print("=" * 80)
    print(f"Main Wallet: {MAIN_WALLET}")
    print(f"Generated: {datetime.now(timezone.utc).isoformat()}")
    print("=" * 80)
    
    # Get all USDT from main wallet
    print("\n[1] Fetching main wallet USDT transactions...")
    main_txs = get_usdt_transfers(MAIN_WALLET)
    
    outflows = []
    inflows = []
    
    for tx in main_txs:
        amount = format_amount(tx.get("value", "0"))
        if amount == 0:
            continue
        if tx.get("from", "").lower() == MAIN_WALLET.lower():
            outflows.append({
                "tx_hash": tx.get("hash"),
                "to": tx.get("to"),
                "amount": amount,
                "timestamp": get_timestamp(tx.get("timeStamp", 0)),
                "block": int(tx.get("blockNumber", 0))
            })
        else:
            inflows.append({
                "tx_hash": tx.get("hash"),
                "from": tx.get("from"),
                "amount": amount,
                "timestamp": get_timestamp(tx.get("timeStamp", 0)),
                "block": int(tx.get("blockNumber", 0))
            })
    
    total_in = sum(t["amount"] for t in inflows)
    total_out = sum(t["amount"] for t in outflows)
    balance = total_in - total_out
    
    print(f"\nMain Wallet Summary:")
    print(f"  USDT IN:  ${total_in:,.2f}")
    print(f"  USDT OUT: ${total_out:,.2f}")
    print(f"  Balance:  ${balance:,.2f}")
    print(f"  Checksum: ${total_in - total_out - balance:.2f} (should be 0)")
    
    # Group outflows by destination
    dest_summary = defaultdict(lambda: {"amount": 0, "txs": []})
    for tx in outflows:
        dest = tx["to"].lower()
        dest_summary[dest]["amount"] += tx["amount"]
        dest_summary[dest]["txs"].append(tx)
    
    print(f"\n[2] Tracing {len(dest_summary)} destination addresses...")
    
    # Final accounting
    exchange_deposits = defaultdict(lambda: {"amount": 0, "deposits": []})
    dormant_funds = []
    traced_to_whitebit = 0
    traced_other = []
    
    all_traces = {}
    
    for dest_addr, info in dest_summary.items():
        print(f"  Tracing {dest_addr[:12]}... (${info['amount']:,.0f})")
        
        trace = trace_destination(dest_addr)
        all_traces[dest_addr] = trace
        
        if trace["status"] == "DORMANT":
            dormant_funds.append({
                "address": dest_addr,
                "amount_usdt": info["amount"],
                "balance": trace.get("balance_usdt", 0),
                "source_txs": [t["tx_hash"] for t in info["txs"]]
            })
        elif trace["status"] == "TRACED":
            for outflow in trace.get("outflows", []):
                if outflow.get("status") == "DEPOSITED_TO_EXCHANGE":
                    exch = outflow.get("exchange")
                    exchange_deposits[exch]["amount"] += outflow["amount"]
                    exchange_deposits[exch]["deposits"].append({
                        "tx_hash": outflow["tx_hash"],
                        "to": outflow["to"],
                        "amount": outflow["amount"]
                    })
                elif outflow.get("status") == "INTERMEDIATE":
                    # Need to trace further
                    sub_trace = trace_destination(outflow["to"], max_depth=2)
                    if sub_trace["status"] == "TRACED":
                        for sub_out in sub_trace.get("outflows", []):
                            if sub_out.get("status") == "DEPOSITED_TO_EXCHANGE":
                                exch = sub_out.get("exchange")
                                exchange_deposits[exch]["amount"] += sub_out["amount"]
                                exchange_deposits[exch]["deposits"].append({
                                    "tx_hash": sub_out["tx_hash"],
                                    "to": sub_out["to"],
                                    "amount": sub_out["amount"],
                                    "path": [dest_addr, outflow["to"], sub_out["to"]]
                                })
        
        time.sleep(0.25)  # Rate limiting
    
    # Load WhiteBIT data from p2p_complete_trace
    print("\n[3] Loading WhiteBIT P2P trace data...")
    try:
        with open("p2p_complete_trace.json") as f:
            p2p_data = json.load(f)
        
        whitebit_deposits = []
        for entry in p2p_data.get("WHITEBIT", []):
            step1 = entry.get("step1_p2p_distributor_to_intermediate", {})
            step2 = entry.get("step2_intermediate_to_exchange", {})
            if step1 and step2:
                whitebit_deposits.append({
                    "amount": step1.get("amount_usdt", 0),
                    "step1_tx": step1.get("tx_hash"),
                    "step2_tx": step2.get("tx_hash"),
                    "intermediate": step1.get("to"),
                    "deposit_address": step2.get("to")
                })
                traced_to_whitebit += step1.get("amount_usdt", 0)
        
        exchange_deposits["WHITEBIT_P2P"]["amount"] = traced_to_whitebit
        exchange_deposits["WHITEBIT_P2P"]["deposits"] = whitebit_deposits
        print(f"  Found {len(whitebit_deposits)} WhiteBIT deposits totaling ${traced_to_whitebit:,.2f}")
    except Exception as e:
        print(f"  Error loading p2p data: {e}")
    
    # Final Report
    print("\n" + "=" * 80)
    print("FINAL RECONCILIATION")
    print("=" * 80)
    
    print(f"\nFUND SOURCES:")
    print(f"  USDT received (from swaps): ${total_in:,.2f}")
    
    print(f"\nFUND DESTINATIONS:")
    
    total_to_exchanges = 0
    for exch, info in sorted(exchange_deposits.items()):
        print(f"  {exch}: ${info['amount']:,.2f} ({len(info['deposits'])} deposits)")
        total_to_exchanges += info["amount"]
    
    total_dormant = sum(d["balance"] for d in dormant_funds)
    print(f"\n  DORMANT (freezable): ${total_dormant:,.2f}")
    for d in dormant_funds:
        print(f"    - {d['address'][:16]}...: ${d['balance']:,.2f}")
    
    print(f"\n  Main wallet balance: ${balance:,.2f}")
    
    total_accounted = total_to_exchanges + total_dormant + balance
    gap = total_in - total_accounted
    
    print(f"\nRECONCILIATION CHECK:")
    print(f"  Total IN:        ${total_in:,.2f}")
    print(f"  To exchanges:    ${total_to_exchanges:,.2f}")
    print(f"  Dormant:         ${total_dormant:,.2f}")
    print(f"  Main balance:    ${balance:,.2f}")
    print(f"  Total accounted: ${total_accounted:,.2f}")
    print(f"  GAP:             ${gap:,.2f}")
    
    # Save results
    report = {
        "metadata": {
            "generated": datetime.now(timezone.utc).isoformat(),
            "main_wallet": MAIN_WALLET,
            "api_version": "Etherscan V2"
        },
        "main_wallet_summary": {
            "usdt_in": round(total_in, 2),
            "usdt_out": round(total_out, 2),
            "balance": round(balance, 2)
        },
        "inflows": inflows[:5],  # First 5 for reference
        "outflows_from_main": outflows,
        "exchange_deposits": {k: v for k, v in exchange_deposits.items()},
        "dormant_funds": dormant_funds,
        "reconciliation": {
            "total_in": round(total_in, 2),
            "to_exchanges": round(total_to_exchanges, 2),
            "dormant": round(total_dormant, 2),
            "main_balance": round(balance, 2),
            "total_accounted": round(total_accounted, 2),
            "gap": round(gap, 2)
        }
    }
    
    with open("complete_fund_trace_v5.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\nSaved to complete_fund_trace_v5.json")
    
    return report

if __name__ == "__main__":
    main()
