#!/usr/bin/env python3
"""
Network Expander v2 - Optimized for speed.

Key optimizations:
1. Limit TX fetch to most recent 100 per address
2. Focus on high-value transactions only (>$100)
3. Early exit when hitting known exchange hot wallets
4. Cache results to avoid re-fetching
"""

import os
import sys
import json
import time
import requests
from collections import deque
from typing import Dict, Set, List, Tuple, Optional
from datetime import datetime

# Load .env
def load_env():
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    if line.startswith('export '):
                        line = line[7:]
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()

load_env()

API_KEY = os.environ.get("ETHERSCAN_API_KEY", "")
MIN_VALUE_USD = 100  # Only track >$100 flows
ETH_PRICE = 3500

# Known exchange addresses (hot wallets and deposit addresses)
KNOWN_EXCHANGES = {
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io",
    "0x7237b8a4b2dd97dcddb758feac0e8d925016694c": "Gate.io (Hop)",
    # WhiteBIT
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    "0x5a52e96bacdabb82fd05763e25335261b270efcb": "WhiteBIT",
    # Bybit  
    "0x17fbbd5bf41693e6bd534a1bc7ca412401d7ce6e": "Bybit",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    "0x63aabab8bc31c4f360ae6c7cf78f67f118f2154c": "Bybit",
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance",
    "0xc889740f66d7a2ea538cd44eb5456f490c75d0b3": "Binance (User)",
    # KuCoin
    "0x83c41363cbee0081dab75cb841fa24f3db46627e": "KuCoin",
    "0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91": "KuCoin",
    # Bitget
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Bitget",
    "0x97b9d2102a9a65a54d1a36c12b0e58d6a1ed6b45": "Bitget",
    # Huobi/HTX
    "0x46340b20830761efd32832a74d7169b29feb9758": "Huobi",
    "0x5c985e89dde482efe97ea9f1950ad149eb73829b": "Huobi",
    # OKX
    "0x5041ed759dd4afc3a72b8192c143f72f4724081a": "OKX",
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    # Crypto.com
    "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com",
    # Coinbase
    "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase",
    "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase",
    # Kraken
    "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": "Kraken",
}

# Also known contracts to skip
KNOWN_CONTRACTS = {
    "0xdac17f958d2ee523a2206206994597c13d831ec7": "USDT Contract",
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": "USDC Contract",
    "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": "WETH Contract",
}

def api_call(params: dict) -> list:
    """Single API call with retry."""
    params["apikey"] = API_KEY
    params["chainid"] = 1
    
    for attempt in range(3):
        try:
            time.sleep(0.25)  # Rate limit
            resp = requests.get("https://api.etherscan.io/v2/api", params=params, timeout=15)
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
            return []
        except Exception as e:
            if attempt < 2:
                time.sleep(1)
            else:
                return []
    return []

def get_significant_transactions(address: str) -> Tuple[List[dict], List[dict]]:
    """
    Get significant (>$100) transactions for an address.
    Returns (inflows, outflows)
    """
    address = address.lower()
    
    # Get normal TX (ETH)
    normal = api_call({
        "module": "account",
        "action": "txlist",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": 1,
        "offset": 500,  # Last 500 TX
        "sort": "desc"
    })
    
    # Get ERC20 TX (tokens)
    erc20 = api_call({
        "module": "account",
        "action": "tokentx",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": 1,
        "offset": 500,
        "sort": "desc"
    })
    
    inflows = []
    outflows = []
    
    # Process ETH transactions
    for tx in normal:
        if tx.get("isError") == "1":
            continue
        value_eth = int(tx.get("value", 0)) / 1e18
        value_usd = value_eth * ETH_PRICE
        if value_usd < MIN_VALUE_USD:
            continue
        
        entry = {
            "hash": tx.get("hash"),
            "from": tx.get("from", "").lower(),
            "to": tx.get("to", "").lower(),
            "value_usd": value_usd,
            "token": "ETH",
            "timestamp": int(tx.get("timeStamp", 0))
        }
        
        if entry["from"] == address:
            outflows.append(entry)
        elif entry["to"] == address:
            inflows.append(entry)
    
    # Process token transactions (USDT, USDC only)
    for tx in erc20:
        symbol = tx.get("tokenSymbol", "")
        if symbol not in ("USDT", "USDC"):
            continue
        
        decimals = int(tx.get("tokenDecimal", 18))
        value = int(tx.get("value", 0)) / (10 ** decimals)
        if value < MIN_VALUE_USD:
            continue
        
        entry = {
            "hash": tx.get("hash"),
            "from": tx.get("from", "").lower(),
            "to": tx.get("to", "").lower(),
            "value_usd": value,
            "token": symbol,
            "timestamp": int(tx.get("timeStamp", 0))
        }
        
        if entry["from"] == address:
            outflows.append(entry)
        elif entry["to"] == address:
            inflows.append(entry)
    
    return inflows, outflows

def check_exchange(address: str) -> Tuple[bool, Optional[str]]:
    """Check if address is a known exchange or deposit address."""
    address = address.lower()
    if address in KNOWN_EXCHANGES:
        return True, KNOWN_EXCHANGES[address]
    return False, None

def expand_network(seeds: List[str], max_depth: int = 2) -> dict:
    """
    BFS expansion from seed addresses.
    
    For each address:
    1. Check if it's a known exchange (if so, record as KYC touchpoint)
    2. Get significant in/out transactions
    3. Record connected addresses for next depth
    """
    visited = {}  # address -> depth
    queue = deque()
    kyc_touchpoints = []
    address_data = {}
    
    # Initialize
    for seed in seeds:
        seed = seed.lower()
        queue.append((seed, 0, "SEED"))
        visited[seed] = 0
    
    total_api_calls = 0
    
    while queue:
        address, depth, source = queue.popleft()
        
        # Check if known exchange
        is_exchange, exchange_name = check_exchange(address)
        if is_exchange:
            kyc_touchpoints.append({
                "address": address,
                "exchange": exchange_name,
                "depth": depth,
                "source": source
            })
            # Don't expand from exchange addresses (too many connections)
            continue
        
        # Skip known contracts
        if address in KNOWN_CONTRACTS:
            continue
        
        print(f"[D{depth}] {address[:12]}...", file=sys.stderr)
        
        inflows, outflows = get_significant_transactions(address)
        total_api_calls += 2
        
        # Store data
        address_data[address] = {
            "depth": depth,
            "source": source,
            "inflows_count": len(inflows),
            "outflows_count": len(outflows),
            "total_in_usd": sum(t["value_usd"] for t in inflows),
            "total_out_usd": sum(t["value_usd"] for t in outflows),
            "sample_inflows": inflows[:5],
            "sample_outflows": outflows[:5]
        }
        
        # Check if any flow goes to exchange
        for tx in outflows:
            dest = tx["to"]
            is_ex, ex_name = check_exchange(dest)
            if is_ex:
                kyc_touchpoints.append({
                    "address": address,
                    "exchange": ex_name,
                    "depth": depth,
                    "via_tx": tx["hash"],
                    "value_usd": tx["value_usd"],
                    "direction": "deposit"
                })
        
        for tx in inflows:
            src = tx["from"]
            is_ex, ex_name = check_exchange(src)
            if is_ex:
                kyc_touchpoints.append({
                    "address": address,
                    "exchange": ex_name,
                    "depth": depth,
                    "via_tx": tx["hash"],
                    "value_usd": tx["value_usd"],
                    "direction": "withdrawal"
                })
        
        # Add connected addresses to queue if not at max depth
        if depth < max_depth:
            # Add sources (backwards)
            for tx in inflows:
                src = tx["from"]
                if src not in visited and src not in KNOWN_CONTRACTS:
                    visited[src] = depth + 1
                    queue.append((src, depth + 1, f"inflow from {address[:8]}"))
            
            # Add destinations (forwards)
            for tx in outflows:
                dest = tx["to"]
                if dest not in visited and dest not in KNOWN_CONTRACTS:
                    visited[dest] = depth + 1
                    queue.append((dest, depth + 1, f"outflow from {address[:8]}"))
    
    # Deduplicate KYC touchpoints
    seen = set()
    unique_kyc = []
    for tp in kyc_touchpoints:
        key = (tp["address"], tp["exchange"])
        if key not in seen:
            seen.add(key)
            unique_kyc.append(tp)
    
    # Sort by value
    unique_kyc.sort(key=lambda x: x.get("value_usd", 0), reverse=True)
    
    return {
        "seeds": seeds,
        "max_depth": max_depth,
        "total_addresses": len(visited),
        "api_calls": total_api_calls,
        "kyc_touchpoints": unique_kyc,
        "exchanges_found": list(set(tp["exchange"] for tp in unique_kyc)),
        "address_data": address_data
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 network_expander_v2.py <address> [address2...] [--depth N] [--output FILE]")
        sys.exit(1)
    
    addresses = []
    depth = 2
    output = None
    
    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == "--depth" or arg == "-d":
            depth = int(sys.argv[i+1])
            i += 2
        elif arg == "--output" or arg == "-o":
            output = sys.argv[i+1]
            i += 2
        elif arg.startswith("0x"):
            addresses.append(arg)
            i += 1
        else:
            i += 1
    
    result = expand_network(addresses, max_depth=depth)
    
    if output:
        with open(output, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\nWritten to {output}")
    else:
        # Print summary
        print("\n" + "="*60)
        print(f"NETWORK EXPANSION RESULTS")
        print("="*60)
        print(f"Seeds: {len(addresses)}")
        print(f"Max depth: {depth}")
        print(f"Total addresses discovered: {result['total_addresses']}")
        print(f"API calls made: {result['api_calls']}")
        print(f"\nKYC TOUCHPOINTS ({len(result['kyc_touchpoints'])}):")
        print("-"*60)
        for tp in result['kyc_touchpoints'][:20]:
            val = tp.get('value_usd', 0)
            print(f"  [{tp['exchange']}] {tp['address'][:16]}... ${val:,.0f} (depth {tp['depth']})")
        print("-"*60)
        print(f"Exchanges found: {', '.join(result['exchanges_found'])}")
