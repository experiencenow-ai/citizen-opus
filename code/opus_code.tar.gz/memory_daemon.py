#!/usr/bin/env python3
"""
Memory Daemon - Continuous memory management for Opus.

Runs 24/7 handling:
- Real-time indexing of new memories
- Periodic consolidation (extracting insights from recent memories)
- Pruning of redundant/outdated memories
- File watching for new documents

All using local LLM - completely free.
"""

import json
import os
import sys
import time
import signal
import hashlib
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import threading

# Paths
OPUS_HOME = Path("/root/claude/opus")
STATE_DIR = OPUS_HOME / "state"
CONFIG_DIR = OPUS_HOME / "config"
LOG_DIR = OPUS_HOME / "logs"

# Ensure directories
for d in [STATE_DIR, CONFIG_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(OPUS_HOME))

from memory_index import MemoryIndex, get_memory_index
from local_llm import LocalLLM, consolidate_memories, summarize_for_memory

# Daemon state
DAEMON_STATE_FILE = STATE_DIR / "memory_daemon.json"
PID_FILE = CONFIG_DIR / "memory_daemon.pid"

# Flags
running = True


def log(msg: str):
    """Log with timestamp."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")
    with open(LOG_DIR / "memory_daemon.log", "a") as f:
        f.write(f"[{ts}] {msg}\n")


@dataclass
class DaemonState:
    """Persistent state for the daemon."""
    last_index_time: Optional[str] = None
    last_consolidation_time: Optional[str] = None
    last_state_hash: Optional[str] = None
    indexed_files: Dict[str, str] = None  # path -> hash
    consolidation_wake: int = 0  # Last wake we consolidated up to
    total_indexed: int = 0
    total_consolidated: int = 0
    
    def __post_init__(self):
        if self.indexed_files is None:
            self.indexed_files = {}
    
    def save(self):
        with open(DAEMON_STATE_FILE, "w") as f:
            json.dump(asdict(self), f, indent=2)
    
    @classmethod
    def load(cls) -> "DaemonState":
        if DAEMON_STATE_FILE.exists():
            try:
                with open(DAEMON_STATE_FILE) as f:
                    data = json.load(f)
                    return cls(**data)
            except:
                pass
        return cls()


def get_file_hash(path: Path) -> str:
    """Get hash of file contents."""
    try:
        with open(path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()
    except:
        return ""


def check_state_changed(state: DaemonState) -> bool:
    """Check if state.json has changed."""
    state_path = OPUS_HOME / "state.json"
    if not state_path.exists():
        return False
    
    current_hash = get_file_hash(state_path)
    if current_hash != state.last_state_hash:
        state.last_state_hash = current_hash
        return True
    return False


def index_new_memories(index: MemoryIndex, state: DaemonState) -> int:
    """Index any new memories from state.json."""
    state_path = OPUS_HOME / "state.json"
    if not state_path.exists():
        return 0
    
    with open(state_path) as f:
        opus_state = json.load(f)
    
    indexed = 0
    
    # Index recent thoughts (only new ones)
    for thought in opus_state.get("recent_thoughts", []):
        wake = thought.get("wake", 0)
        content = thought.get("thought", "")
        if content and len(content) > 10:
            # add() skips if exists
            result = index.add(content, "thoughts", wake=wake, skip_if_exists=True)
            if result:
                indexed += 1
    
    # Index insights
    for insight in opus_state.get("insights", []):
        wake = insight.get("wake", 0)
        content = insight.get("insight", "")
        if content and len(content) > 10:
            index.add(content, "insights", wake=wake, skip_if_exists=True)
            indexed += 1
    
    state.last_index_time = datetime.now(timezone.utc).isoformat()
    state.total_indexed += indexed
    
    return indexed


def index_new_files(index: MemoryIndex, state: DaemonState) -> int:
    """Index any new or changed files."""
    watch_dirs = [
        OPUS_HOME / "docs",
        OPUS_HOME / "investigations",
    ]
    
    watch_extensions = {".md", ".json", ".txt", ".py"}
    
    indexed = 0
    
    for watch_dir in watch_dirs:
        if not watch_dir.exists():
            continue
        
        for file_path in watch_dir.rglob("*"):
            if not file_path.is_file():
                continue
            if file_path.suffix not in watch_extensions:
                continue
            if file_path.stat().st_size > 100000:  # Skip files > 100KB
                continue
            
            path_str = str(file_path)
            current_hash = get_file_hash(file_path)
            
            # Check if new or changed
            if path_str in state.indexed_files:
                if state.indexed_files[path_str] == current_hash:
                    continue  # No change
            
            # Index the file
            try:
                result = index.index_file(file_path, summarize=True)
                if result:
                    state.indexed_files[path_str] = current_hash
                    indexed += 1
                    log(f"Indexed file: {file_path.name}")
            except Exception as e:
                log(f"Failed to index {file_path.name}: {e}")
    
    return indexed


def should_consolidate(state: DaemonState) -> bool:
    """Check if it's time for memory consolidation."""
    # Consolidate every 50 wakes or 24 hours, whichever comes first
    
    # Check wake count
    state_path = OPUS_HOME / "state.json"
    if state_path.exists():
        with open(state_path) as f:
            opus_state = json.load(f)
            current_wake = opus_state.get("total_wakes", 0)
            if current_wake - state.consolidation_wake >= 50:
                return True
    
    # Check time
    if state.last_consolidation_time:
        last_time = datetime.fromisoformat(state.last_consolidation_time)
        if datetime.now(timezone.utc) - last_time > timedelta(hours=24):
            return True
    else:
        return True  # Never consolidated
    
    return False


def run_consolidation(index: MemoryIndex, state: DaemonState) -> Dict[str, Any]:
    """
    Run memory consolidation.
    
    1. Get recent memories since last consolidation
    2. Use local LLM to extract insights
    3. Add new insights to index
    4. Optionally prune redundant memories
    """
    log("Starting memory consolidation...")
    
    # Get memories since last consolidation
    recent = index.get_recent("thoughts", n=100, min_wake=state.consolidation_wake)
    
    if not recent:
        log("No new memories to consolidate")
        return {"status": "no_memories"}
    
    # Group memories into chunks for consolidation
    chunk_size = 20
    chunks = [recent[i:i+chunk_size] for i in range(0, len(recent), chunk_size)]
    
    all_insights = []
    
    for chunk in chunks:
        # Extract content
        memory_texts = [m["content"] for m in chunk if m.get("content")]
        
        if not memory_texts:
            continue
        
        # Consolidate using local LLM
        try:
            result = consolidate_memories(memory_texts)
            
            # Add new insights to index
            for insight in result.get("key_insights", []):
                if insight and len(insight) > 20:
                    index.add(insight, "insights", metadata={"source": "consolidation"})
                    all_insights.append(insight)
            
            # Add patterns as insights too
            for pattern in result.get("patterns", []):
                if pattern and len(pattern) > 20:
                    index.add(f"Pattern: {pattern}", "insights", metadata={"source": "consolidation"})
                    all_insights.append(pattern)
                    
        except Exception as e:
            log(f"Consolidation chunk failed: {e}")
    
    # Update state
    state_path = OPUS_HOME / "state.json"
    if state_path.exists():
        with open(state_path) as f:
            opus_state = json.load(f)
            state.consolidation_wake = opus_state.get("total_wakes", 0)
    
    state.last_consolidation_time = datetime.now(timezone.utc).isoformat()
    state.total_consolidated += len(all_insights)
    state.save()
    
    log(f"Consolidation complete: {len(all_insights)} new insights")
    
    return {
        "status": "success",
        "insights_created": len(all_insights),
        "memories_processed": len(recent),
        "insights": all_insights[:5]  # Return first 5 for logging
    }


def index_dreams(index: MemoryIndex, state: DaemonState) -> int:
    """Index any new dream records."""
    dream_dir = OPUS_HOME / "dreams"
    if not dream_dir.exists():
        return 0
    
    indexed = 0
    
    # Check for recent.json
    recent_file = dream_dir / "recent.json"
    if recent_file.exists():
        try:
            with open(recent_file) as f:
                dreams = json.load(f)
            
            for dream in dreams:
                narrative = dream.get("narrative", "")
                if narrative and len(narrative) > 20:
                    dream_id = f"dream_{dream.get('timestamp', '')}"
                    content = f"Dream ({dream.get('archetype_used', 'unknown')}): {narrative}"
                    
                    index.add(
                        content,
                        "dreams",
                        metadata={
                            "archetype": dream.get("archetype_used", ""),
                            "tone": dream.get("emotional_tone", ""),
                            "meaning": dream.get("possible_meaning", "")
                        },
                        skip_if_exists=True
                    )
                    indexed += 1
        except Exception as e:
            log(f"Failed to index dreams: {e}")
    
    return indexed


def daemon_loop():
    """Main daemon loop."""
    global running
    
    log("Memory daemon starting...")
    
    # Initialize
    state = DaemonState.load()
    
    # Check for local LLM
    llm = LocalLLM()
    if not llm.available:
        log("WARNING: Ollama not running. Consolidation will not work.")
        log("Start Ollama with: ollama serve")
    else:
        log(f"Local LLM available. Models: {llm.models}")
    
    # Initialize memory index
    try:
        index = get_memory_index()
        log(f"Memory index loaded. Total items: {index.count()}")
    except Exception as e:
        log(f"Failed to initialize memory index: {e}")
        return
    
    # Initial indexing
    if check_state_changed(state):
        indexed = index_new_memories(index, state)
        log(f"Initial indexing: {indexed} memories")
        state.save()
    
    last_file_check = datetime.now()
    last_consolidation_check = datetime.now()
    
    while running:
        try:
            now = datetime.now()
            
            # Check for state.json changes (every 10 seconds)
            if check_state_changed(state):
                indexed = index_new_memories(index, state)
                if indexed > 0:
                    log(f"Indexed {indexed} new memories")
                state.save()
            
            # Check for file changes (every 5 minutes)
            if (now - last_file_check).total_seconds() > 300:
                indexed = index_new_files(index, state)
                if indexed > 0:
                    log(f"Indexed {indexed} new files")
                
                # Also index dreams
                dream_count = index_dreams(index, state)
                if dream_count > 0:
                    log(f"Indexed {dream_count} dreams")
                
                last_file_check = now
                state.save()
            
            # Check for consolidation (every hour)
            if (now - last_consolidation_check).total_seconds() > 3600:
                if should_consolidate(state):
                    if llm.available:
                        result = run_consolidation(index, state)
                        if result.get("insights_created", 0) > 0:
                            log(f"Created {result['insights_created']} insights")
                    else:
                        log("Skipping consolidation - Ollama not available")
                last_consolidation_check = now
            
            # Sleep
            time.sleep(10)
            
        except Exception as e:
            log(f"Daemon loop error: {e}")
            time.sleep(30)
    
    log("Memory daemon stopped")


def signal_handler(signum, frame):
    """Handle shutdown signals."""
    global running
    log(f"Received signal {signum}, shutting down...")
    running = False


def write_pid():
    """Write PID file."""
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def remove_pid():
    """Remove PID file."""
    if PID_FILE.exists():
        PID_FILE.unlink()


def is_already_running() -> bool:
    """Check if daemon is already running."""
    if not PID_FILE.exists():
        return False
    
    try:
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return True
    except (ValueError, ProcessLookupError, PermissionError):
        remove_pid()
        return False


def force_consolidation():
    """Run consolidation immediately (for manual trigger)."""
    state = DaemonState.load()
    index = get_memory_index()
    
    # Reset consolidation wake to force full consolidation
    state.consolidation_wake = max(0, state.consolidation_wake - 100)
    
    result = run_consolidation(index, state)
    return result


def search_memories(query: str, n: int = 10, min_similarity: float = 0.3):
    """
    Search memories from command line or Python.
    
    Returns list of dicts with: wake, type, similarity, content
    """
    index = get_memory_index()
    results = index.search(query, n_results=n)
    
    # Filter by minimum similarity and format output
    formatted = []
    for r in results:
        sim = r.get('similarity', 0)
        if sim >= min_similarity:
            formatted.append({
                'wake': r['metadata'].get('wake', -1),
                'type': r['metadata'].get('memory_type', 'unknown'),
                'similarity': sim,
                'content': r['content']
            })
    return formatted


def recall(query: str, n: int = 5) -> str:
    """
    Quick recall for Opus - returns concatenated relevant memories.
    
    Usage in Opus's code:
        from memory_daemon import recall
        context = recall("ct teaching debugging")
    """
    results = search_memories(query, n=n, min_similarity=0.4)
    if not results:
        return f"No memories found for: {query}"
    
    output = []
    for r in results:
        wake_str = f"Wake {r['wake']}" if r['wake'] != -1 else "Historical"
        output.append(f"[{wake_str} - {r['similarity']:.0%}]\n{r['content']}")
    
    return "\n\n---\n\n".join(output)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "status":
            if is_already_running():
                with open(PID_FILE) as f:
                    pid = f.read().strip()
                print(f"Memory daemon running (PID {pid})")
            else:
                print("Memory daemon not running")
            
            state = DaemonState.load()
            print(f"Last index: {state.last_index_time}")
            print(f"Last consolidation: {state.last_consolidation_time}")
            print(f"Total indexed: {state.total_indexed}")
            print(f"Total consolidated: {state.total_consolidated}")
            
            index = get_memory_index()
            print(f"Index size: {index.count()} items")
        
        elif cmd == "stop":
            if is_already_running():
                with open(PID_FILE) as f:
                    pid = int(f.read().strip())
                os.kill(pid, signal.SIGTERM)
                print(f"Sent SIGTERM to {pid}")
            else:
                print("Daemon not running")
        
        elif cmd == "start":
            if is_already_running():
                print("Daemon already running")
                sys.exit(1)
            
            # Daemonize
            if os.fork() > 0:
                sys.exit(0)
            os.setsid()
            if os.fork() > 0:
                sys.exit(0)
            
            sys.stdout = open(LOG_DIR / "memory_daemon.log", "a")
            sys.stderr = sys.stdout
            
            signal.signal(signal.SIGTERM, signal_handler)
            signal.signal(signal.SIGINT, signal_handler)
            
            write_pid()
            try:
                daemon_loop()
            finally:
                remove_pid()
        
        elif cmd == "consolidate":
            print("Running consolidation...")
            result = force_consolidation()
            print(json.dumps(result, indent=2))
        
        elif cmd == "search" and len(sys.argv) > 2:
            query = " ".join(sys.argv[2:])
            # Check for flags
            n_results = 10  # Default to more results
            output_json = False
            args = sys.argv[2:]
            
            if "--json" in args:
                output_json = True
                args.remove("--json")
            if "-n" in args:
                idx = args.index("-n")
                n_results = int(args[idx + 1])
                args = args[:idx] + args[idx+2:]
            
            query = " ".join(args)
            results = search_memories(query, n=n_results)
            
            if output_json:
                # Output as JSON for programmatic use
                import json
                output = []
                for mem in results:
                    output.append({
                        "wake": mem.get('wake', -1),
                        "type": mem.get('type', 'unknown'),
                        "similarity": round(mem.get('similarity', 0), 3),
                        "content": mem.get('content', '')  # Full content
                    })
                print(json.dumps(output, indent=2))
            else:
                print(f"Searching: {query} ({len(results)} results)\n")
                for i, mem in enumerate(results):
                    wake = mem.get('wake', '?')
                    sim = mem.get('similarity', 0)
                    mtype = mem.get('type', '?')
                    content = mem.get('content', '')
                    
                    print(f"─── {i+1}. Wake {wake} | {mtype} | {sim:.0%} match ───")
                    # Show full content up to 1500 chars
                    if len(content) > 1500:
                        print(f"{content[:1500]}...")
                    else:
                        print(content)
                    print()
        
        elif cmd == "index":
            print("Indexing state.json...")
            index = get_memory_index()
            state = DaemonState.load()
            count = index_new_memories(index, state)
            print(f"Indexed {count} memories")
            state.save()
        
        else:
            print(f"Unknown command: {cmd}")
            print("\nUsage:")
            print("  python memory_daemon.py start        # Start daemon")
            print("  python memory_daemon.py stop         # Stop daemon")
            print("  python memory_daemon.py status       # Show status")
            print("  python memory_daemon.py consolidate  # Run consolidation now")
            print("  python memory_daemon.py search <q>   # Search memories")
            print("  python memory_daemon.py index        # Index state.json")
    
    else:
        # Run in foreground
        if is_already_running():
            print("Daemon already running in background")
            sys.exit(1)
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        write_pid()
        try:
            daemon_loop()
        finally:
            remove_pid()
