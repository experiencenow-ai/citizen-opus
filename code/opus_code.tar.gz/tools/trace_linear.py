#!/usr/bin/env python3
"""Quick linear trace - follows single-output chains"""
import json
import urllib.request
import sys

def get_outgoing_txs(addr):
    addr = addr.lower()
    url = f"https://eth.blockscout.com/api/v2/addresses/{addr}/transactions?filter=from"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode()).get('items', [])
    except Exception as e:
        print(f"Error: {e}")
        return []

def trace_linear(start_addr, max_hops=10, min_eth=1.0):
    """Follow the money through single-output chains"""
    current = start_addr
    path = [current]
    total_eth = 0
    
    for hop in range(max_hops):
        txs = get_outgoing_txs(current)
        if not txs:
            print(f"  Hop {hop}: {current[:16]}... -> NO OUTGOING TXS")
            break
            
        # Find significant outgoing txs (>min_eth)
        significant = [t for t in txs if int(t['value'])/1e18 >= min_eth]
        
        if not significant:
            print(f"  Hop {hop}: {current[:16]}... -> no significant txs (>{min_eth} ETH)")
            break
            
        # Take the largest one
        largest = max(significant, key=lambda t: int(t['value']))
        eth = int(largest['value'])/1e18
        next_addr = largest['to']['hash']
        
        print(f"  Hop {hop}: {current[:16]}... -> {next_addr[:16]}... ({eth:.2f} ETH)")
        
        if hop == 0:
            total_eth = eth
            
        path.append(next_addr)
        current = next_addr
        
    return path, total_eth

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 trace_linear.py <address> [max_hops] [min_eth]")
        sys.exit(1)
        
    addr = sys.argv[1]
    max_hops = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    min_eth = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
    
    print(f"Tracing from {addr}")
    print(f"Max hops: {max_hops}, Min ETH: {min_eth}")
    print()
    
    path, eth = trace_linear(addr, max_hops, min_eth)
    
    print(f"\nPath length: {len(path)} addresses")
    print(f"Initial ETH: {eth:.2f}")
    print(f"Final address: {path[-1]}")
