#!/usr/bin/env python3
"""
Etherscan Address Monitor

Monitors specified addresses for activity and alerts when transactions occur.
Can be run as a cron job or daemon.
"""

import json
import os
import sys
import time
from datetime import datetime

# Configuration
ADDRESSES_FILE = "/root/claude/opus/state/monitored_addresses.json"
ALERTS_FILE = "/root/claude/opus/state/address_alerts.json"

def load_addresses():
    """Load addresses to monitor."""
    if os.path.exists(ADDRESSES_FILE):
        with open(ADDRESSES_FILE) as f:
            return json.load(f)
    return {"addresses": []}

def save_alert(alert):
    """Save an alert to the alerts file."""
    alerts = []
    if os.path.exists(ALERTS_FILE):
        with open(ALERTS_FILE) as f:
            alerts = json.load(f).get("alerts", [])
    
    alerts.append(alert)
    
    with open(ALERTS_FILE, 'w') as f:
        json.dump({"alerts": alerts, "last_updated": datetime.utcnow().isoformat()}, f, indent=2)

def check_address(address, label, last_tx_count):
    """Check an address for new transactions.
    
    Returns (new_tx_count, has_activity)
    """
    # This would normally use Etherscan API
    # For now, return placeholder
    print(f"Would check {label}: {address}")
    print(f"  Last known tx count: {last_tx_count}")
    return last_tx_count, False

def main():
    print(f"[{datetime.utcnow().isoformat()}] Address monitor starting...")
    
    config = load_addresses()
    addresses = config.get("addresses", [])
    
    if not addresses:
        print("No addresses configured for monitoring.")
        print(f"Add addresses to {ADDRESSES_FILE}")
        return
    
    for addr_config in addresses:
        address = addr_config.get("address")
        label = addr_config.get("label", "Unknown")
        last_tx = addr_config.get("last_tx_count", 0)
        
        new_tx, has_activity = check_address(address, label, last_tx)
        
        if has_activity:
            alert = {
                "timestamp": datetime.utcnow().isoformat(),
                "address": address,
                "label": label,
                "message": f"New activity detected on {label}",
                "old_tx_count": last_tx,
                "new_tx_count": new_tx
            }
            save_alert(alert)
            print(f"ALERT: {alert['message']}")

if __name__ == "__main__":
    main()
