#!/usr/bin/env python3
"""
Scan a list of addresses and report status.
Can be run as a quick check or continuous monitoring.
"""

import subprocess
import json
import sys
import time
from datetime import datetime, timezone

def query_blockscout(address):
    """Query address via Blockscout"""
    cmd = f'curl -s "https://eth.blockscout.com/api/v2/addresses/{address}"'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        balance_wei = int(data.get('coin_balance', 0))
        return {
            "balance_eth": balance_wei / 1e18,
            "is_scam": data.get('is_scam', False),
            "reputation": data.get('reputation', 'unknown'),
            "exchange_rate": float(data.get('exchange_rate', 0)),
        }
    except:
        return None

def load_watchlist():
    """Load addresses from bounty_watchlist.json"""
    try:
        with open('bounty_watchlist.json', 'r') as f:
            data = json.load(f)
        
        addresses = []
        for key, val in data.get('known_addresses', {}).items():
            if isinstance(val, dict) and 'address' in val:
                addresses.append({
                    "name": key,
                    "address": val['address'],
                    "note": val.get('note', '')
                })
        return addresses
    except Exception as e:
        print(f"Error loading watchlist: {e}")
        return []

def scan_addresses(addresses):
    """Scan list of addresses and return results"""
    results = []
    for addr_info in addresses:
        info = query_blockscout(addr_info['address'])
        if info:
            usd_value = info['balance_eth'] * info.get('exchange_rate', 0)
            results.append({
                "name": addr_info['name'],
                "address": addr_info['address'],
                "balance_eth": info['balance_eth'],
                "balance_usd": usd_value,
                "is_scam": info.get('is_scam', False),
                "reputation": info.get('reputation', 'unknown'),
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
        else:
            results.append({
                "name": addr_info['name'],
                "address": addr_info['address'],
                "error": "query failed",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
        # Rate limit
        time.sleep(0.5)
    return results

def format_results(results):
    """Pretty print results"""
    print("=" * 70)
    print(f"Address Scan Results - {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print("=" * 70)
    
    total_eth = 0
    total_usd = 0
    
    for r in results:
        print(f"\n{r['name']}:")
        print(f"  {r['address']}")
        if 'error' in r:
            print(f"  ❌ {r['error']}")
        else:
            print(f"  Balance: {r['balance_eth']:.6f} ETH (${r['balance_usd']:,.2f})")
            if r.get('is_scam'):
                print(f"  ⚠️  SCAM TAG")
            total_eth += r['balance_eth']
            total_usd += r['balance_usd']
    
    print("\n" + "=" * 70)
    print(f"Total tracked: {total_eth:.6f} ETH (${total_usd:,.2f})")
    print("=" * 70)
    
    return {"total_eth": total_eth, "total_usd": total_usd}

def save_scan_results(results, filename="scan_results.json"):
    """Save results to file"""
    with open(filename, 'w') as f:
        json.dump({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "results": results
        }, f, indent=2)

if __name__ == "__main__":
    addresses = load_watchlist()
    
    if not addresses:
        print("No addresses in watchlist")
        sys.exit(1)
    
    print(f"Scanning {len(addresses)} addresses...")
    results = scan_addresses(addresses)
    totals = format_results(results)
    save_scan_results(results)
    print(f"\nResults saved to scan_results.json")
