#!/usr/bin/env python3
"""
Address Monitor v1 - Prototype for Wake 1000
Track wallets associated with bounties and stolen funds.

Quick prototype - will be refactored into clean DRY functions.
Designed to run cheaply via cron, with Haiku/Sonnet evaluating changes.
"""

import json
import requests
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any

# Erigon RPC endpoint
RPC_URL = "http://localhost:8545"

# Known addresses to track (will be loaded from bounty_watchlist.json)
WATCHLIST_FILE = Path(__file__).parent / "bounty_watchlist.json"
STATE_FILE = Path(__file__).parent / "address_monitor_state.json"
ALERTS_FILE = Path(__file__).parent / "address_monitor_alerts.json"

def rpc_call(method: str, params: list = None) -> Any:
    """Make JSON-RPC call to Erigon."""
    payload = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params or [],
        "id": 1
    }
    try:
        resp = requests.post(RPC_URL, json=payload, timeout=30)
        result = resp.json()
        if "error" in result:
            print(f"RPC Error: {result['error']}")
            return None
        return result.get("result")
    except Exception as e:
        print(f"RPC Exception: {e}")
        return None

def hex_to_int(hex_str: str) -> int:
    """Convert hex string to int."""
    if hex_str is None:
        return 0
    return int(hex_str, 16)

def wei_to_eth(wei: int) -> float:
    """Convert wei to ETH."""
    return wei / 1e18

def get_balance(address: str) -> Optional[float]:
    """Get ETH balance for address."""
    result = rpc_call("eth_getBalance", [address, "latest"])
    if result:
        return wei_to_eth(hex_to_int(result))
    return None

def get_transaction_count(address: str) -> Optional[int]:
    """Get number of transactions from address."""
    result = rpc_call("eth_getTransactionCount", [address, "latest"])
    if result:
        return hex_to_int(result)
    return None

def get_block_number() -> Optional[int]:
    """Get current block number."""
    result = rpc_call("eth_blockNumber")
    if result:
        return hex_to_int(result)
    return None

def load_state() -> Dict:
    """Load previous state."""
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {"addresses": {}, "last_check": None, "last_block": None}

def save_state(state: Dict):
    """Save state to file."""
    STATE_FILE.write_text(json.dumps(state, indent=2))

def load_watchlist() -> Dict:
    """Load addresses to watch."""
    if WATCHLIST_FILE.exists():
        return json.loads(WATCHLIST_FILE.read_text())
    return {"known_addresses": {}}

def check_address(address: str, state: Dict) -> Dict:
    """Check an address and return any changes."""
    address = address.lower()
    balance = get_balance(address)
    tx_count = get_transaction_count(address)
    
    prev = state.get("addresses", {}).get(address, {})
    prev_balance = prev.get("balance")
    prev_tx_count = prev.get("tx_count")
    
    changes = {}
    if prev_balance is not None and balance != prev_balance:
        changes["balance_change"] = balance - prev_balance
    if prev_tx_count is not None and tx_count != prev_tx_count:
        changes["new_txs"] = tx_count - prev_tx_count
    
    return {
        "balance": balance,
        "tx_count": tx_count,
        "prev_balance": prev_balance,
        "prev_tx_count": prev_tx_count,
        "changes": changes
    }

def generate_alert(address: str, label: str, result: Dict) -> Optional[Dict]:
    """Generate alert if significant change detected."""
    changes = result.get("changes", {})
    if not changes:
        return None
    
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "address": address,
        "label": label,
        "balance_change_eth": changes.get("balance_change"),
        "new_transactions": changes.get("new_txs"),
        "current_balance": result.get("balance"),
        "current_tx_count": result.get("tx_count")
    }

def run_scan():
    """Main scan function."""
    print(f"[{datetime.now(timezone.utc).isoformat()}] Starting address scan...")
    
    block = get_block_number()
    if block is None:
        print("ERROR: Cannot connect to Erigon")
        return
    print(f"Current block: {block}")
    
    state = load_state()
    watchlist = load_watchlist()
    alerts = []
    
    # Gather all addresses to check
    addresses_to_check = []
    for source, data in watchlist.get("known_addresses", {}).items():
        for addr in data.get("addresses", []):
            addresses_to_check.append((addr, source))
    
    print(f"Checking {len(addresses_to_check)} addresses...")
    
    for address, label in addresses_to_check:
        result = check_address(address, state)
        
        # Update state
        if "addresses" not in state:
            state["addresses"] = {}
        state["addresses"][address.lower()] = {
            "balance": result["balance"],
            "tx_count": result["tx_count"],
            "label": label,
            "last_check": datetime.now(timezone.utc).isoformat()
        }
        
        # Check for alerts
        alert = generate_alert(address, label, result)
        if alert:
            alerts.append(alert)
            print(f"ALERT: {label} - {address}")
            print(f"  Balance change: {alert.get('balance_change_eth', 0):.4f} ETH")
            print(f"  New txs: {alert.get('new_transactions', 0)}")
    
    # Save state
    state["last_check"] = datetime.now(timezone.utc).isoformat()
    state["last_block"] = block
    save_state(state)
    
    # Save alerts if any
    if alerts:
        existing_alerts = []
        if ALERTS_FILE.exists():
            existing_alerts = json.loads(ALERTS_FILE.read_text())
        existing_alerts.extend(alerts)
        # Keep last 100 alerts
        existing_alerts = existing_alerts[-100:]
        ALERTS_FILE.write_text(json.dumps(existing_alerts, indent=2))
        print(f"Generated {len(alerts)} alerts")
    
    print("Scan complete.")

if __name__ == "__main__":
    run_scan()
