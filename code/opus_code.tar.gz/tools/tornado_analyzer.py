#!/usr/bin/env python3
"""
Tornado Cash Behavioral Analysis Tool

This tool doesn't break Tornado's cryptography - it looks for behavioral patterns
that can link deposits to withdrawals through heuristics:

1. Timing correlation: Deposits and withdrawals close in time
2. Amount patterns: Unique amounts that might be linked
3. Gas fee analysis: Same funding wallet for gas
4. Recipient behavior: What happens after withdrawal
5. Cross-chain correlation: Activity on other chains

This is probabilistic, not deterministic - it generates hypotheses for investigation.
"""

import json
import sys
from datetime import datetime, timedelta

# Tornado Cash contract addresses (Ethereum mainnet)
TORNADO_CONTRACTS = {
    "0.1_ETH": "0x12D66f87A04A9E220743712cE6d9bB1B5616B8Fc",
    "1_ETH": "0x47CE0C6eD5B0Ce3d3A51fdb1C52DC66a7c3c2936",
    "10_ETH": "0x910Cbd523D972eb0a6f4cAe4618aD62622b39DbF",
    "100_ETH": "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291",
}

# Known heuristics for linking
HEURISTICS = {
    "timing_window": {
        "description": "Deposits and withdrawals within N hours",
        "confidence": "LOW to MEDIUM",
        "notes": "Sophisticated actors wait longer, but amateurs often withdraw quickly"
    },
    "gas_funding": {
        "description": "Same wallet funds gas for deposit and withdrawal addresses",
        "confidence": "HIGH",
        "notes": "This is a common mistake - using same wallet to fund gas"
    },
    "unique_amounts": {
        "description": "Non-standard amounts that can be linked",
        "confidence": "MEDIUM",
        "notes": "If someone deposits 10.123 ETH, that's more linkable than 10 ETH"
    },
    "exchange_endpoints": {
        "description": "Both deposit source and withdrawal destination are same exchange",
        "confidence": "MEDIUM to HIGH",
        "notes": "Exchange KYC can link the accounts"
    },
    "behavioral_fingerprint": {
        "description": "Similar transaction patterns, timing preferences, etc.",
        "confidence": "LOW",
        "notes": "Requires large dataset to establish patterns"
    }
}

def analyze_timing_correlation(deposits: list, withdrawals: list, window_hours: int = 24) -> list:
    """Find deposits and withdrawals that occurred within a time window."""
    correlations = []
    
    for deposit in deposits:
        dep_time = datetime.fromisoformat(deposit['timestamp'])
        for withdrawal in withdrawals:
            with_time = datetime.fromisoformat(withdrawal['timestamp'])
            time_diff = abs((with_time - dep_time).total_seconds() / 3600)
            
            if time_diff <= window_hours:
                correlations.append({
                    "deposit": deposit,
                    "withdrawal": withdrawal,
                    "time_diff_hours": round(time_diff, 2),
                    "confidence": "LOW" if time_diff > 12 else "MEDIUM" if time_diff > 4 else "HIGH"
                })
    
    return correlations

def analyze_gas_funding(deposit_addr: str, withdrawal_addr: str, gas_funders: dict) -> dict:
    """Check if same wallet funded gas for both addresses."""
    dep_funder = gas_funders.get(deposit_addr)
    with_funder = gas_funders.get(withdrawal_addr)
    
    if dep_funder and with_funder and dep_funder == with_funder:
        return {
            "match": True,
            "funder": dep_funder,
            "confidence": "HIGH",
            "notes": "Same wallet funded gas for both addresses - strong link"
        }
    return {"match": False}

def main():
    print("Tornado Cash Behavioral Analyzer")
    print("=" * 50)
    print("\nThis tool analyzes behavioral patterns, not cryptographic weaknesses.")
    print("\nAvailable heuristics:")
    for name, info in HEURISTICS.items():
        print(f"\n  {name}:")
        print(f"    {info['description']}")
        print(f"    Confidence: {info['confidence']}")
    
    print("\n" + "=" * 50)
    print("\nTo use this tool, you need:")
    print("  1. List of deposits to Tornado Cash in a time window")
    print("  2. List of withdrawals from Tornado Cash in a time window")
    print("  3. Gas funding information for addresses")
    print("  4. Exchange deposit/withdrawal data (if available)")
    
    print("\nThe tool generates hypotheses for manual investigation.")
    print("It does NOT break Tornado's cryptographic privacy guarantees.")

if __name__ == "__main__":
    main()
