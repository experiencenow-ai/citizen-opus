#!/usr/bin/env python3
"""
Trace the Balancer exploit attacker's funds.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

# Attacker addresses from the exploit
EXPLOIT_TX = "0xd45c4c92568409e070004188bd4e0922d2888fc6f405d943a104a35d951d96a2"
ATTACKER_FROM = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
ATTACKER_TO = "0x000000000000bb1b11e5ac8099e92e366b64c133"

# Get the transaction receipt to see all transfers
print(f"=== Analyzing Balancer Exploit Transaction ===")
print(f"TX: {EXPLOIT_TX}")

receipt_req = {
    "jsonrpc": "2.0",
    "method": "eth_getTransactionReceipt",
    "params": [EXPLOIT_TX],
    "id": 1
}
receipt = run_curl(receipt_req)['result']
print(f"Gas used: {int(receipt['gasUsed'], 16):,}")
print(f"Logs count: {len(receipt['logs'])}")

# ERC20 Transfer event topic
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

# Find all ERC20 transfers in this transaction
transfers = [log for log in receipt['logs'] if log['topics'][0] == TRANSFER_TOPIC]
print(f"\nERC20 transfers: {len(transfers)}")

# Look for large transfers to the attacker address
print(f"\n=== Transfers to attacker addresses ===")
for transfer in transfers:
    if len(transfer['topics']) >= 3:
        to_addr = "0x" + transfer['topics'][2][-40:]
        if to_addr.lower() in [ATTACKER_FROM.lower(), ATTACKER_TO.lower()]:
            from_addr = "0x" + transfer['topics'][1][-40:]
            amount = int(transfer['data'], 16)
            token = transfer['address']
            print(f"Token: {token}")
            print(f"  From: {from_addr}")
            print(f"  To: {to_addr}")
            print(f"  Amount: {amount / 1e18:.4f}")
            print()

# Now check the current balance and recent transactions of the attacker addresses
print(f"\n=== Current balance of {ATTACKER_FROM} ===")
bal_req = {
    "jsonrpc": "2.0",
    "method": "eth_getBalance",
    "params": [ATTACKER_FROM, "latest"],
    "id": 1
}
bal = run_curl(bal_req)
if 'result' in bal:
    print(f"ETH: {int(bal['result'], 16) / 1e18:.4f}")

print(f"\n=== Current balance of {ATTACKER_TO} ===")
bal_req['params'] = [ATTACKER_TO, "latest"]
bal = run_curl(bal_req)
if 'result' in bal:
    print(f"ETH: {int(bal['result'], 16) / 1e18:.4f}")

# Check transaction count to see if these are contracts or EOAs
print(f"\n=== Checking if addresses are contracts ===")
for addr in [ATTACKER_FROM, ATTACKER_TO]:
    code_req = {
        "jsonrpc": "2.0",
        "method": "eth_getCode",
        "params": [addr, "latest"],
        "id": 1
    }
    code = run_curl(code_req)
    if 'result' in code:
        code_len = len(code['result']) - 2  # Remove 0x prefix
        if code_len > 0:
            print(f"{addr}: CONTRACT ({code_len // 2} bytes)")
        else:
            print(f"{addr}: EOA")
