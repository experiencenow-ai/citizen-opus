#!/usr/bin/env python3
"""
Batch Address Scanner for Bounty Tracking
Queries multiple addresses via Erigon RPC and reports changes.
Uses urllib (no external dependencies).
"""

import json
import sys
import os
from datetime import datetime
import urllib.request
import urllib.error

ERIGON_RPC = "http://localhost:8545"
SCAN_RESULTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scan_results.json")
WATCHLIST_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bounty_watchlist.json")

def wei_to_eth(wei_hex):
    """Convert hex wei string to ETH float"""
    wei = int(wei_hex, 16)
    return wei / 1e18

def get_eth_price():
    """Get current ETH price in USD"""
    try:
        req = urllib.request.Request(
            "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd",
            headers={"User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return data["ethereum"]["usd"]
    except Exception as e:
        print(f"Price fetch failed: {e}")
        return 2500  # fallback estimate

def rpc_call(method, params):
    """Make an Erigon RPC call"""
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }).encode()
    
    req = urllib.request.Request(
        ERIGON_RPC,
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())

def batch_get_balances(addresses):
    """Get balances for multiple addresses"""
    results = {}
    
    for addr in addresses:
        try:
            data = rpc_call("eth_getBalance", [addr.lower(), "latest"])
            
            if "result" in data:
                results[addr.lower()] = {
                    "balance_wei": data["result"],
                    "balance_eth": wei_to_eth(data["result"]),
                    "checked_at": datetime.utcnow().isoformat()
                }
            else:
                results[addr.lower()] = {"error": str(data.get("error", "unknown"))}
        except Exception as e:
            results[addr.lower()] = {"error": str(e)}
    
    return results

def load_previous_scan():
    """Load previous scan results for comparison"""
    try:
        with open(SCAN_RESULTS_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def save_scan_results(results):
    """Save scan results"""
    with open(SCAN_RESULTS_FILE, 'w') as f:
        json.dump(results, f, indent=2)

def detect_changes(current, previous):
    """Detect significant balance changes"""
    changes = []
    
    for addr, data in current.items():
        if "error" in data:
            continue
            
        prev_data = previous.get("addresses", {}).get(addr)
        if not prev_data or "error" in prev_data:
            continue
            
        prev_eth = prev_data.get("balance_eth", 0)
        curr_eth = data.get("balance_eth", 0)
        
        diff = curr_eth - prev_eth
        if abs(diff) > 0.001:  # More than 0.001 ETH change
            changes.append({
                "address": addr,
                "previous": prev_eth,
                "current": curr_eth,
                "change": diff,
                "direction": "IN" if diff > 0 else "OUT"
            })
    
    return changes

def main():
    # Load watchlist
    try:
        with open(WATCHLIST_FILE, 'r') as f:
            watchlist = json.load(f)
    except Exception as e:
        print(f"Error loading watchlist: {e}")
        return
    
    # Extract addresses to scan
    addresses = []
    address_info = {}
    
    known = watchlist.get("known_addresses", {})
    for name, info in known.items():
        if "address" in info:
            addr = info["address"].lower()
            addresses.append(addr)
            address_info[addr] = name
    
    # Also check ct's bounty address
    bounty_addr = "0x88f1d72668204093e6Bdd75Baa86105c6DB7B063".lower()
    if bounty_addr not in addresses:
        addresses.append(bounty_addr)
        address_info[bounty_addr] = "ct_bounty_collection"
    
    if not addresses:
        print("No addresses to scan")
        return
    
    print(f"Scanning {len(addresses)} addresses...")
    
    # Get current ETH price
    eth_price = get_eth_price()
    print(f"ETH price: ${eth_price:,.2f}")
    
    # Batch scan
    current_balances = batch_get_balances(addresses)
    
    # Load previous for comparison
    previous = load_previous_scan()
    
    # Detect changes
    changes = detect_changes(current_balances, previous)
    
    # Print results
    print("\n=== SCAN RESULTS ===")
    for addr, data in current_balances.items():
        name = address_info.get(addr, "unknown")
        if "error" in data:
            print(f"[ERROR] {name}: {data['error']}")
        else:
            eth = data["balance_eth"]
            usd = eth * eth_price
            print(f"[{name}] {eth:.6f} ETH (${usd:,.2f})")
    
    if changes:
        print("\n=== CHANGES DETECTED ===")
        for c in changes:
            name = address_info.get(c["address"], c["address"][:10])
            direction = "▲" if c["direction"] == "IN" else "▼"
            usd_change = c["change"] * eth_price
            print(f"{direction} {name}: {c['change']:+.6f} ETH (${usd_change:+,.2f})")
    else:
        print("\nNo significant changes since last scan")
    
    # Save results
    results = {
        "scan_time": datetime.utcnow().isoformat(),
        "eth_price_usd": eth_price,
        "addresses": current_balances,
        "changes": changes
    }
    save_scan_results(results)
    print(f"\nResults saved to scan_results.json")

if __name__ == "__main__":
    main()
