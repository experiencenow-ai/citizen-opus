#!/usr/bin/env python3
"""Trace transactions TO the vault"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"
WETH = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"

def rpc_call(method, params):
    cmd = f'''curl -s -m 30 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return json.loads(result.stdout).get("result")

# Check WETH balance of the vault
WETH_BALANCE_CALL = "0x70a08231" + MWETH_VAULT[2:].zfill(64)
balance = rpc_call("eth_call", [{"to": WETH, "data": WETH_BALANCE_CALL}, "latest"])
if balance:
    print(f"Vault's WETH balance: {int(balance, 16) / 1e18:.6f} WETH")

# Check if vault is a proxy by looking at storage slot 0
slot0 = rpc_call("eth_getStorageAt", [MWETH_VAULT, "0x0", "latest"])
print(f"Storage slot 0: {slot0}")

# Check implementation slot for proxy pattern
# EIP-1967 implementation slot
impl_slot = "0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc"
impl = rpc_call("eth_getStorageAt", [MWETH_VAULT, impl_slot, "latest"])
print(f"EIP-1967 impl slot: {impl}")

# Get transaction count of the vault
nonce = rpc_call("eth_getTransactionCount", [MWETH_VAULT, "latest"])
print(f"Vault tx count: {int(nonce, 16)}")

# Wait - the vault is a contract, its nonce would be for CREATE operations
# Let me check if there are WETH transfers TO the vault
print("\nChecking WETH transfers to vault...")
TRANSFER_SIG = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
# topic2 is 'to' address
logs = rpc_call("eth_getLogs", [{
    "address": WETH,
    "topics": [TRANSFER_SIG, None, "0x" + MWETH_VAULT[2:].zfill(64).lower()],
    "fromBlock": hex(23718991),
    "toBlock": "latest"
}])
if logs:
    print(f"Found {len(logs)} WETH transfers to vault")
    total = 0
    for log in logs:
        value = int(log["data"], 16) / 1e18
        total += value
        block = int(log["blockNumber"], 16)
        print(f"  Block {block}: {value:.4f} WETH")
    print(f"Total: {total:.4f} WETH")
else:
    print("No WETH transfers to vault found")

# Check WETH transfers FROM the vault
print("\nChecking WETH transfers FROM vault...")
logs2 = rpc_call("eth_getLogs", [{
    "address": WETH,
    "topics": [TRANSFER_SIG, "0x" + MWETH_VAULT[2:].zfill(64).lower()],
    "fromBlock": hex(23718991),
    "toBlock": "latest"
}])
if logs2:
    print(f"Found {len(logs2)} WETH transfers from vault")
    total = 0
    for log in logs2:
        value = int(log["data"], 16) / 1e18
        total += value
        block = int(log["blockNumber"], 16)
        to_addr = "0x" + log["topics"][2][-40:]
        print(f"  Block {block}: {value:.4f} WETH to {to_addr[:16]}...")
    print(f"Total: {total:.4f} WETH")
else:
    print("No WETH transfers from vault found")
