#!/usr/bin/env python3
"""
Quick Trace Safe - Address analysis with Erigon-safe parameters
Opus Wake 1048

SAFE VERSION: Uses smaller block ranges to avoid crashing Erigon.

trace_filter is expensive - large block ranges can OOM or crash the node.
This version:
1. Limits to 2000 blocks max per query
2. Paginates larger ranges
3. Has shorter timeouts
4. Falls back gracefully on errors

Usage: python3 quick_trace_safe.py <address> [--blocks N]
"""

import json
import urllib.request
import sys
from collections import defaultdict
from pathlib import Path

RPC_URL = "http://localhost:8545"
MAX_BLOCKS_PER_QUERY = 2000  # Safe limit for trace_filter
TIMEOUT_SECONDS = 30  # Shorter timeout

def rpc_call(method, params=None):
    """RPC call with safe timeout."""
    payload = json.dumps({'jsonrpc': '2.0', 'method': method, 'params': params or [], 'id': 1}).encode()
    req = urllib.request.Request(RPC_URL, data=payload, headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            result = json.loads(resp.read().decode())
            if 'error' in result:
                print(f"RPC Error: {result['error']}")
                return None
            return result.get('result')
    except Exception as e:
        print(f"RPC call failed: {e}")
        return None

def hex_to_int(h):
    return int(h, 16) if h else 0

def wei_to_eth(w):
    return w / 1e18

def safe_trace_filter(address, direction='to', from_block=0, to_block=None):
    """
    Safe trace_filter that paginates to avoid crashing Erigon.
    
    direction: 'to' for incoming, 'from' for outgoing
    """
    all_traces = []
    
    if to_block is None:
        to_block = hex_to_int(rpc_call('eth_blockNumber'))
    
    # Paginate through block range
    current = from_block
    while current < to_block:
        chunk_end = min(current + MAX_BLOCKS_PER_QUERY, to_block)
        
        if direction == 'to':
            params = [{'toAddress': [address], 'fromBlock': hex(current), 'toBlock': hex(chunk_end)}]
        else:
            params = [{'fromAddress': [address], 'fromBlock': hex(current), 'toBlock': hex(chunk_end)}]
        
        print(f"  Scanning blocks {current} to {chunk_end}...")
        traces = rpc_call('trace_filter', params)
        
        if traces:
            all_traces.extend(traces)
            print(f"    Found {len(traces)} traces")
        
        current = chunk_end + 1
    
    return all_traces

def quick_trace_safe(address: str, num_blocks: int = 5000) -> dict:
    """
    Quick trace of an address with safe parameters.
    Default reduced to 5000 blocks (from 10000).
    """
    address = address.lower()
    
    current_block = hex_to_int(rpc_call('eth_blockNumber'))
    if current_block is None:
        print("ERROR: Could not get block number. Is Erigon running?")
        return None
        
    from_blk = max(0, current_block - num_blocks)
    
    print(f"Tracing {address[:15]}... (blocks {from_blk} to {current_block})")
    print(f"  Using safe pagination ({MAX_BLOCKS_PER_QUERY} blocks per query)")
    
    # Get traces with pagination
    incoming = safe_trace_filter(address, 'to', from_blk, current_block)
    outgoing = safe_trace_filter(address, 'from', from_blk, current_block)
    
    print(f"Total Incoming: {len(incoming)} traces")
    print(f"Total Outgoing: {len(outgoing)} traces")
    
    # Analyze flows
    senders = defaultdict(lambda: {'count': 0, 'total_eth': 0})
    receivers = defaultdict(lambda: {'count': 0, 'total_eth': 0})
    
    for trace in incoming:
        action = trace.get('action', {})
        from_addr = action.get('from', '').lower()
        value = wei_to_eth(hex_to_int(action.get('value', '0x0')))
        senders[from_addr]['count'] += 1
        senders[from_addr]['total_eth'] += value
    
    for trace in outgoing:
        action = trace.get('action', {})
        to_addr = (action.get('to') or '').lower()
        value = wei_to_eth(hex_to_int(action.get('value', '0x0')))
        receivers[to_addr]['count'] += 1
        receivers[to_addr]['total_eth'] += value
    
    # Sort by value
    top_senders = sorted(senders.items(), key=lambda x: -x[1]['total_eth'])[:20]
    top_receivers = sorted(receivers.items(), key=lambda x: -x[1]['total_eth'])[:20]
    
    result = {
        'address': address,
        'block_range': {'from': from_blk, 'to': current_block},
        'incoming_traces': len(incoming),
        'outgoing_traces': len(outgoing),
        'total_received_eth': sum(s['total_eth'] for s in senders.values()),
        'total_sent_eth': sum(r['total_eth'] for r in receivers.values()),
        'top_senders': [(addr, data) for addr, data in top_senders if data['total_eth'] > 0],
        'top_receivers': [(addr, data) for addr, data in top_receivers if data['total_eth'] > 0]
    }
    
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 quick_trace_safe.py <address> [--blocks N]")
        sys.exit(1)
    
    address = sys.argv[1]
    blocks = 5000  # Reduced default
    
    if '--blocks' in sys.argv:
        idx = sys.argv.index('--blocks')
        if idx + 1 < len(sys.argv):
            blocks = min(int(sys.argv[idx + 1]), 10000)  # Cap at 10K
    
    result = quick_trace_safe(address, blocks)
    
    if result:
        print("\n=== Summary ===")
        print(f"Received: {result['total_received_eth']:.4f} ETH")
        print(f"Sent: {result['total_sent_eth']:.4f} ETH")
        
        if result['top_senders']:
            print("\nTop Senders:")
            for addr, data in result['top_senders'][:10]:
                print(f"  {addr[:20]}...: {data['total_eth']:.4f} ETH ({data['count']} txs)")
        
        if result['top_receivers']:
            print("\nTop Receivers:")
            for addr, data in result['top_receivers'][:10]:
                print(f"  {addr[:20]}...: {data['total_eth']:.4f} ETH ({data['count']} txs)")
