#!/usr/bin/env python3
"""
Etherscan V2 API query tool - works across all chains with single API.
Chain IDs: 1=Ethereum, 42161=Arbitrum, 137=Polygon, 10=Optimism, 8453=Base
"""

import json
import subprocess
import sys

# Etherscan V2 base URL
BASE_URL = "https://api.etherscan.io/v2/api"

# Chain IDs
CHAINS = {
    "eth": 1,
    "ethereum": 1,
    "arb": 42161,
    "arbitrum": 42161,
    "polygon": 137,
    "optimism": 10,
    "base": 8453,
    "bsc": 56,
    "avalanche": 43114,
}

def query_api(params, chain_id=1):
    """Query Etherscan V2 API using curl."""
    param_str = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"{BASE_URL}?chainid={chain_id}&{param_str}"
    
    try:
        result = subprocess.run(
            ["curl", "-s", url],
            capture_output=True,
            text=True,
            timeout=15
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"error": str(e)}

def get_balance(address, chain="eth"):
    """Get native token balance."""
    chain_id = CHAINS.get(chain.lower(), 1)
    params = {
        "module": "account",
        "action": "balance",
        "address": address,
        "tag": "latest"
    }
    result = query_api(params, chain_id)
    
    if result.get("status") == "1":
        wei = int(result["result"])
        return wei / 1e18
    return None

def get_txlist(address, chain="eth", page=1, offset=20):
    """Get transaction list for address."""
    chain_id = CHAINS.get(chain.lower(), 1)
    params = {
        "module": "account",
        "action": "txlist",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": page,
        "offset": offset,
        "sort": "desc"
    }
    result = query_api(params, chain_id)
    
    if result.get("status") == "1":
        return result["result"]
    return None

def get_token_txs(address, chain="eth", page=1, offset=20):
    """Get ERC-20 token transfers."""
    chain_id = CHAINS.get(chain.lower(), 1)
    params = {
        "module": "account",
        "action": "tokentx",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": page,
        "offset": offset,
        "sort": "desc"
    }
    result = query_api(params, chain_id)
    
    if result.get("status") == "1":
        return result["result"]
    return None

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 etherscan_v2.py <chain> <address>")
        print("       python3 etherscan_v2.py arb balance <address>")
        print("       python3 etherscan_v2.py eth tokens <address>")
        print(f"Chains: {', '.join(CHAINS.keys())}")
        sys.exit(1)
    
    chain = sys.argv[1]
    
    if sys.argv[2] == "balance" and len(sys.argv) > 3:
        addr = sys.argv[3]
        bal = get_balance(addr, chain)
        if bal is not None:
            print(f"Balance on {chain}: {bal:.6f}")
        else:
            print("Error fetching balance")
    elif sys.argv[2] == "tokens" and len(sys.argv) > 3:
        addr = sys.argv[3]
        txs = get_token_txs(addr, chain)
        if txs:
            print(f"Recent token transfers for {addr} on {chain}:")
            for tx in txs[:10]:
                value = int(tx.get('value', 0)) / (10 ** int(tx.get('tokenDecimal', 18)))
                symbol = tx.get('tokenSymbol', '?')
                print(f"  {tx.get('from', '')[:10]}... -> {tx.get('to', '')[:10]}... {value:.4f} {symbol}")
    else:
        addr = sys.argv[2]
        txs = get_txlist(addr, chain)
        if txs:
            print(f"Recent transactions for {addr} on {chain}:")
            for tx in txs[:10]:
                value = int(tx.get('value', 0)) / 1e18
                block = tx.get('blockNumber', '?')
                print(f"  Block {block}: {tx.get('from', '')[:10]}... -> {tx.get('to', '')[:10]}... ({value:.4f})")
        else:
            print("Error or no transactions found")
