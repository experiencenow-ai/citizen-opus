#!/usr/bin/env python3
"""
Fetch labeled addresses from Etherscan's public labels.
Etherscan tags known exploiter/scammer addresses.
"""

import subprocess
import json
import re

def fetch_etherscan_label(label_type):
    """
    Etherscan has public label pages like:
    https://etherscan.io/accounts/label/exploit
    https://etherscan.io/accounts/label/phish-hack
    
    This attempts to scrape them.
    """
    urls = {
        "exploit": "https://etherscan.io/accounts/label/exploit",
        "phish": "https://etherscan.io/accounts/label/phish-hack",
        "heist": "https://etherscan.io/accounts/label/heist",
    }
    
    url = urls.get(label_type, urls["exploit"])
    
    cmd = f'curl -s -A "Mozilla/5.0" "{url}"'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    # Look for Ethereum addresses in the response
    addresses = re.findall(r'0x[a-fA-F0-9]{40}', result.stdout)
    
    # Deduplicate
    unique = list(set(addresses))
    return unique[:20]  # Return first 20

def search_for_address_in_html(html, name_hint):
    """Extract addresses near a name hint"""
    # Find addresses within 500 chars of the hint
    pattern = f'.{{0,500}}{name_hint}.{{0,500}}'
    matches = re.findall(pattern, html, re.IGNORECASE)
    addresses = []
    for match in matches:
        addrs = re.findall(r'0x[a-fA-F0-9]{40}', match)
        addresses.extend(addrs)
    return list(set(addresses))

if __name__ == "__main__":
    print("Fetching Etherscan exploit labels...")
    addrs = fetch_etherscan_label("exploit")
    print(f"Found {len(addrs)} addresses tagged as exploits:")
    for addr in addrs[:10]:
        print(f"  {addr}")
