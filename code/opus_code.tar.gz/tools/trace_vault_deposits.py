#!/usr/bin/env python3
"""
Trace deposits INTO the MWETH vault.
Find all sources of the 262 WETH.
"""
import urllib.request
import json

RPC = 'http://localhost:8545'
MWETH_VAULT = '0xc02aabef00f0571e27bb66cc37c7057e1a850cc2'
WETH = '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'

def rpc_call(method, params=[]):
    data = json.dumps({'jsonrpc':'2.0','method':method,'params':params,'id':1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())['result']

def main():
    current_block = int(rpc_call('eth_blockNumber'), 16)
    print(f'Current block: {current_block}')
    
    # Get vault creation block - find first tx to it
    vault_padded = '0x000000000000000000000000' + MWETH_VAULT[2:].lower()
    
    print(f'\nSearching for WETH transfers TO the vault...')
    
    # Search from a reasonable start (around exploit time)
    start_block = 23700000
    chunk_size = 50000
    
    all_deposits = []
    for start in range(start_block, current_block, chunk_size):
        end = min(start + chunk_size - 1, current_block)
        print(f'  Scanning blocks {start} to {end}...', end=' ')
        
        try:
            logs = rpc_call('eth_getLogs', [{
                'fromBlock': hex(start),
                'toBlock': hex(end),
                'address': WETH,
                'topics': [
                    TRANSFER_TOPIC,
                    None,  # any sender
                    vault_padded  # to = vault
                ]
            }])
            
            print(f'{len(logs)} deposits')
            
            for log in logs:
                from_addr = '0x' + log['topics'][1][-40:]
                value = int(log['data'], 16) / 1e18
                
                all_deposits.append({
                    'block': int(log['blockNumber'], 16),
                    'tx': log['transactionHash'],
                    'from': from_addr,
                    'weth': value
                })
                
        except Exception as e:
            print(f'Error: {e}')
    
    print(f'\nTotal deposits: {len(all_deposits)}')
    total_weth = sum(d['weth'] for d in all_deposits)
    print(f'Total WETH deposited: {total_weth:.4f}')
    
    # Group by sender
    senders = {}
    for d in all_deposits:
        s = d['from'].lower()
        if s not in senders:
            senders[s] = {'count': 0, 'total': 0}
        senders[s]['count'] += 1
        senders[s]['total'] += d['weth']
    
    print(f'\nDepositors:')
    for addr, info in sorted(senders.items(), key=lambda x: x[1]['total'], reverse=True):
        print(f'  {addr}: {info["total"]:.4f} WETH ({info["count"]} deposits)')
    
    # Save
    with open('vault_deposits.json', 'w') as f:
        json.dump({
            'vault': MWETH_VAULT,
            'total_deposits': len(all_deposits),
            'total_weth': total_weth,
            'senders': senders,
            'deposits': all_deposits
        }, f, indent=2)
    print('\nSaved to vault_deposits.json')

if __name__ == '__main__':
    main()
