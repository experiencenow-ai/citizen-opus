#!/usr/bin/env python3
"""
Attacker Behavior Analyzer v2
Categorizes crypto attackers by post-exploit behavior patterns.

Key insight: Attackers who hesitate before laundering may be:
1. Amateurs (uncertain how to launder)
2. Negotiation-open (considering returning for bounty)
3. Technical difficulties (struggling with Tornado Cash)
4. Patient professionals (waiting for attention to die down)

This matters because category 1-3 attackers have higher recovery potential.
"""

import json
import subprocess
from datetime import datetime, timezone

# Known attacker patterns
ATTACKER_PROFILES = {
    "immediate_laundering": {
        "description": "Moves to Tornado Cash within 1-6 hours",
        "recovery_probability": "VERY LOW",
        "typical_actor": "Professional, possibly nation-state",
        "examples": ["Lazarus Group", "Most sophisticated hackers"]
    },
    "delayed_laundering": {
        "description": "Waits 12-48 hours before laundering",
        "recovery_probability": "LOW",
        "typical_actor": "Patient professional",
        "examples": []
    },
    "hesitant": {
        "description": "Funds sit idle for 48+ hours",
        "recovery_probability": "MEDIUM",
        "typical_actor": "Amateur or negotiation-open",
        "examples": ["Futureswap attacker (2+ days idle)"]
    },
    "partial_return": {
        "description": "Returns some funds, keeps percentage",
        "recovery_probability": "HIGH for returned portion",
        "typical_actor": "White/gray hat or negotiator",
        "examples": []
    },
    "laundered": {
        "description": "Already moved funds to mixer/DEX",
        "recovery_probability": "VERY LOW",
        "typical_actor": "Any",
        "examples": ["Truebit attacker"]
    }
}

def query_rpc(rpc_url, method, params):
    """Query JSON-RPC endpoint."""
    payload = {"jsonrpc": "2.0", "method": method, "params": params, "id": 1}
    try:
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", "-H", "Content-Type: application/json",
             "--data", json.dumps(payload), rpc_url],
            capture_output=True, text=True, timeout=15
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"error": str(e)}

def get_balance(address, rpc_url="https://eth.llamarpc.com"):
    """Get ETH balance."""
    result = query_rpc(rpc_url, "eth_getBalance", [address, "latest"])
    if "result" in result:
        return int(result["result"], 16) / 1e18
    return None

def get_tx_count(address, rpc_url="https://eth.llamarpc.com"):
    """Get transaction count (proxy for activity)."""
    result = query_rpc(rpc_url, "eth_getTransactionCount", [address, "latest"])
    if "result" in result:
        return int(result["result"], 16)
    return None

def analyze_attacker(address, exploit_date, stolen_amount, protocol_name, initial_balance=None):
    """
    Analyze an attacker's behavior pattern.
    
    Args:
        address: Attacker's Ethereum address
        exploit_date: Date of exploit (YYYY-MM-DD)
        stolen_amount: Estimated USD value stolen
        protocol_name: Name of exploited protocol
        initial_balance: Initial ETH balance after exploit (if known)
    
    Returns:
        Analysis dict with behavior classification
    """
    now = datetime.now(timezone.utc)
    exploit_dt = datetime.strptime(exploit_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    days_since = (now - exploit_dt).days
    hours_since = (now - exploit_dt).total_seconds() / 3600
    
    # Get current balance
    balance = get_balance(address)
    tx_count = get_tx_count(address)
    
    analysis = {
        "address": address,
        "protocol": protocol_name,
        "exploit_date": exploit_date,
        "stolen_amount_usd": stolen_amount,
        "days_since_exploit": days_since,
        "hours_since_exploit": round(hours_since, 1),
        "current_balance_eth": balance,
        "transaction_count": tx_count,
        "analyzed_at": datetime.now(timezone.utc).isoformat()
    }
    
    eth_price = 3100  # Approximate
    
    # Classify behavior
    if balance is None:
        analysis["classification"] = "UNKNOWN"
        analysis["recovery_potential"] = "UNKNOWN"
        analysis["notes"] = "Could not query balance"
    else:
        remaining_usd = balance * eth_price
        
        # Calculate what percentage remains
        # If we know initial balance, use that; otherwise estimate from stolen amount
        if initial_balance:
            initial_usd = initial_balance * eth_price
        else:
            initial_usd = stolen_amount
        
        remaining_pct = (remaining_usd / initial_usd) * 100 if initial_usd > 0 else 0
        
        analysis["remaining_usd"] = round(remaining_usd, 2)
        analysis["remaining_pct"] = round(remaining_pct, 1)
        
        # Key classification logic:
        # 1. If tx_count > 10 and balance < 5% of stolen -> already laundered
        # 2. If balance > 50% and hours > 48 -> hesitant (high recovery potential)
        # 3. If balance > 50% and hours < 48 -> too early
        # 4. If balance < 50% and tx_count > 5 -> actively laundering
        
        if tx_count and tx_count > 10 and remaining_pct < 5:
            analysis["classification"] = "laundered"
            analysis["recovery_potential"] = "VERY LOW"
            analysis["notes"] = f"Already laundered via {tx_count} transactions, only dust remains"
        elif remaining_pct > 50:
            if hours_since > 48:
                analysis["classification"] = "hesitant"
                analysis["recovery_potential"] = "MEDIUM-HIGH"
                analysis["notes"] = f"Funds idle for {days_since}+ days with {remaining_pct:.0f}% remaining - unusual, may be open to negotiation"
            else:
                analysis["classification"] = "too_early_to_classify"
                analysis["recovery_potential"] = "UNKNOWN"
                analysis["notes"] = "Need more time to observe pattern"
        elif remaining_pct > 10:
            analysis["classification"] = "actively_laundering"
            analysis["recovery_potential"] = "LOW"
            analysis["notes"] = f"Partial laundering in progress, {remaining_pct:.0f}% remaining"
        else:
            if hours_since < 6:
                analysis["classification"] = "immediate_laundering"
            elif hours_since < 48:
                analysis["classification"] = "delayed_laundering"
            else:
                analysis["classification"] = "laundered"
            analysis["recovery_potential"] = "VERY LOW"
            analysis["notes"] = "Funds already moved/laundered"
    
    return analysis

def save_attacker_database(attackers, filename="attacker_database.json"):
    """Save attacker database to file."""
    db = {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "profiles": ATTACKER_PROFILES,
        "attackers": attackers,
        "summary": {
            "total_tracked": len(attackers),
            "hesitant_count": sum(1 for a in attackers if a.get("classification") == "hesitant"),
            "actionable_count": sum(1 for a in attackers if a.get("recovery_potential") in ["MEDIUM", "MEDIUM-HIGH", "HIGH"]),
            "total_remaining_usd": sum(a.get("remaining_usd", 0) for a in attackers)
        }
    }
    with open(filename, 'w') as f:
        json.dump(db, f, indent=2)
    return filename

if __name__ == "__main__":
    print("=== Attacker Behavior Analyzer v2 ===\n")
    
    # Known attackers to analyze
    known_attackers = [
        {
            "address": "0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95",
            "exploit_date": "2026-01-09",
            "stolen_amount": 400000,
            "protocol": "Futureswap",
            "initial_balance": 95.78  # Known from tracing
        },
        {
            "address": "0xc0454E545a7A715c6D3627f77bEd376a05182FBc",
            "exploit_date": "2026-01-08",
            "stolen_amount": 26600000,  # Claimed (actual was ~82 ETH)
            "protocol": "Truebit",
            "initial_balance": 82  # Estimated actual theft
        }
    ]
    
    results = []
    for attacker in known_attackers:
        print(f"Analyzing {attacker['protocol']} attacker...")
        analysis = analyze_attacker(
            attacker["address"],
            attacker["exploit_date"],
            attacker["stolen_amount"],
            attacker["protocol"],
            attacker.get("initial_balance")
        )
        results.append(analysis)
        
        print(f"  Address: {analysis['address'][:20]}...")
        print(f"  Classification: {analysis['classification']}")
        print(f"  Recovery Potential: {analysis['recovery_potential']}")
        print(f"  Current Balance: {analysis.get('current_balance_eth', 'N/A'):.4f} ETH")
        if 'remaining_usd' in analysis:
            print(f"  Remaining Value: ${analysis['remaining_usd']:,.0f} ({analysis['remaining_pct']:.1f}%)")
        print(f"  Tx Count: {analysis.get('transaction_count', 'N/A')}")
        print(f"  Notes: {analysis['notes']}")
        print()
    
    # Save database
    filename = save_attacker_database(results)
    print(f"Saved to {filename}")
    
    # Print summary
    print("\n=== Summary ===")
    hesitant = [r for r in results if r["classification"] == "hesitant"]
    if hesitant:
        print(f"ACTIONABLE: {len(hesitant)} hesitant attacker(s)")
        for h in hesitant:
            print(f"  - {h['protocol']}: ${h['remaining_usd']:,.0f} recoverable")
