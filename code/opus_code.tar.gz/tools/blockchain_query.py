#!/usr/bin/env python3
"""
Blockchain query tool with fallback to public APIs when Erigon is down.
Uses Blockscout as primary fallback (no API key needed).
"""

import subprocess
import json
import socket

def check_erigon():
    """Check if local Erigon is available"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('127.0.0.1', 8545))
        sock.close()
        return result == 0
    except:
        return False

def query_balance_erigon(address):
    """Query balance via local Erigon"""
    cmd = f'''curl -s -X POST http://localhost:8545 \
        -H "Content-Type: application/json" \
        -d '{{"jsonrpc":"2.0","method":"eth_getBalance","params":["{address}","latest"],"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        balance_wei = int(data['result'], 16)
        return {"balance_eth": balance_wei / 1e18, "source": "erigon"}
    except:
        return None

def query_blockscout(address):
    """Query address info via Blockscout (free, no API key)"""
    cmd = f'curl -s "https://eth.blockscout.com/api/v2/addresses/{address}"'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        balance_wei = int(data.get('coin_balance', 0))
        return {
            "balance_eth": balance_wei / 1e18,
            "is_scam": data.get('is_scam', False),
            "reputation": data.get('reputation', 'unknown'),
            "is_contract": data.get('is_contract', False),
            "has_tokens": data.get('has_tokens', False),
            "exchange_rate": float(data.get('exchange_rate', 0)),
            "source": "blockscout"
        }
    except Exception as e:
        return None

def get_address_info(address):
    """Get address info, trying Erigon first, then Blockscout"""
    if check_erigon():
        info = query_balance_erigon(address)
        if info:
            return info
    
    return query_blockscout(address)

def format_usd(eth, rate):
    """Format ETH to USD"""
    if rate:
        return f"${eth * rate:,.2f}"
    return "N/A"

if __name__ == "__main__":
    # Test with known addresses
    test_addresses = [
        ("Bybit Primary Exploiter", "0x47666fab8bd0ac7003bce3f5c3585383f09486e2"),
        ("Tornado Cash Router", "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b"),
    ]
    
    print("=" * 60)
    print("Blockchain Query Tool")
    print("=" * 60)
    print(f"Erigon status: {'UP' if check_erigon() else 'DOWN (using Blockscout)'}")
    print()
    
    for name, addr in test_addresses:
        info = get_address_info(addr)
        if info:
            print(f"{name}:")
            print(f"  Address: {addr}")
            print(f"  Balance: {info['balance_eth']:.6f} ETH", end="")
            if 'exchange_rate' in info:
                print(f" ({format_usd(info['balance_eth'], info.get('exchange_rate'))})")
            else:
                print()
            if info.get('is_scam'):
                print(f"  ⚠️  TAGGED AS SCAM")
            if info.get('reputation') and info['reputation'] != 'unknown':
                print(f"  Reputation: {info['reputation']}")
            print(f"  Source: {info['source']}")
        else:
            print(f"{name}: QUERY FAILED")
        print()
