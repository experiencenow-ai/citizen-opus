#!/usr/bin/env python3
"""
Trace ALL outflows from attacker's main proxy.
Goal: Find where the bulk of stolen funds went.
"""
import urllib.request
import json
import time

RPC = 'http://localhost:8545'
PROXY = '0x0000000000004f3d8aaf9175fd824cb00ad4bf80'
EXPLOIT_BLOCK = 23718991  # Block of the exploit

def rpc_call(method, params=[]):
    data = json.dumps({'jsonrpc':'2.0','method':method,'params':params,'id':1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())['result']

def get_tx_receipts_in_range(start_block, end_block, batch_size=100):
    """Get all transactions from an address in a block range."""
    # We'll check each block for transactions from the proxy
    txs = []
    for block_num in range(start_block, end_block + 1, batch_size):
        end = min(block_num + batch_size - 1, end_block)
        # Get transactions by checking blocks
        for b in range(block_num, end + 1):
            try:
                block = rpc_call('eth_getBlockByNumber', [hex(b), True])
                if block and block.get('transactions'):
                    for tx in block['transactions']:
                        if tx.get('from', '').lower() == PROXY.lower():
                            txs.append({
                                'hash': tx['hash'],
                                'block': b,
                                'to': tx.get('to'),
                                'value': int(tx.get('value', '0x0'), 16) / 1e18,
                                'input_len': len(tx.get('input', '0x'))
                            })
            except Exception as e:
                print(f'Error at block {b}: {e}')
                continue
    return txs

def main():
    print(f'Tracing outflows from {PROXY}')
    print(f'Starting from exploit block {EXPLOIT_BLOCK}')
    
    current_block = int(rpc_call('eth_blockNumber'), 16)
    print(f'Current block: {current_block}')
    
    # This would be very slow to scan all blocks
    # Instead, let's use eth_getLogs to find token transfers
    # ERC20 Transfer event: Transfer(address,address,uint256)
    # Topic0: 0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef
    
    TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
    proxy_padded = '0x000000000000000000000000' + PROXY[2:].lower()
    
    print(f'\nSearching for token transfers FROM attacker proxy...')
    
    # Search in chunks (10000 blocks at a time)
    chunk_size = 10000
    all_transfers = []
    
    for start in range(EXPLOIT_BLOCK, current_block, chunk_size):
        end = min(start + chunk_size - 1, current_block)
        print(f'  Scanning blocks {start} to {end}...', end=' ')
        
        try:
            logs = rpc_call('eth_getLogs', [{
                'fromBlock': hex(start),
                'toBlock': hex(end),
                'topics': [
                    TRANSFER_TOPIC,
                    proxy_padded,  # from = attacker
                    None  # any recipient
                ]
            }])
            
            print(f'{len(logs)} transfers found')
            
            for log in logs:
                token = log['address']
                to_addr = '0x' + log['topics'][2][-40:]
                value_hex = log['data']
                value = int(value_hex, 16) if value_hex != '0x' else 0
                
                all_transfers.append({
                    'block': int(log['blockNumber'], 16),
                    'token': token,
                    'to': to_addr,
                    'value_raw': value
                })
                
        except Exception as e:
            print(f'Error: {e}')
            time.sleep(1)
    
    print(f'\nTotal outgoing transfers: {len(all_transfers)}')
    
    # Group by destination
    destinations = {}
    for t in all_transfers:
        dest = t['to'].lower()
        if dest not in destinations:
            destinations[dest] = {'count': 0, 'tokens': set()}
        destinations[dest]['count'] += 1
        destinations[dest]['tokens'].add(t['token'].lower())
    
    print(f'\nUnique destinations: {len(destinations)}')
    print('\nTop destinations by transfer count:')
    sorted_dests = sorted(destinations.items(), key=lambda x: x[1]['count'], reverse=True)[:20]
    for dest, info in sorted_dests:
        print(f'  {dest}: {info["count"]} transfers, {len(info["tokens"])} tokens')
    
    # Save results
    results = {
        'attacker': PROXY,
        'scan_range': [EXPLOIT_BLOCK, current_block],
        'total_transfers': len(all_transfers),
        'destinations': {k: {'count': v['count'], 'tokens': list(v['tokens'])} for k, v in destinations.items()},
        'transfers': all_transfers[:100]  # Save first 100 for inspection
    }
    
    with open('attacker_outflows.json', 'w') as f:
        json.dump(results, f, indent=2)
    print('\nSaved to attacker_outflows.json')

if __name__ == '__main__':
    main()
