#!/usr/bin/env python3
"""Trace outflows from the secondary attacker contract"""
import urllib.request
import json

RPC = "http://localhost:8546"

def eth_call(method, params):
    data = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read()).get("result")

BB1B = "0x000000000000bb1b11e5ac8099e92e366b64c133"

# Get all transactions from this address
print(f"Tracing outflows from {BB1B}")
print(f"Total outgoing txs: 38")

# We need to find these transactions. Let's check around the exploit block
# and also check recent blocks
EXPLOIT_BLOCK = 23718991
CURRENT_BLOCK = int(eth_call("eth_blockNumber", []), 16)
print(f"Current block: {CURRENT_BLOCK}")

# Check if there are internal transactions by looking at ETH balance changes
# First, let's look at a few blocks after the exploit
print("\n=== Checking blocks after exploit ===")
outflows = []

# Sample some blocks after the exploit
for block_num in range(EXPLOIT_BLOCK, min(EXPLOIT_BLOCK + 100, CURRENT_BLOCK)):
    block = eth_call("eth_getBlockByNumber", [hex(block_num), True])
    if not block:
        continue
    
    for tx in block.get('transactions', []):
        tx_from = tx.get('from', '').lower()
        if tx_from == BB1B.lower():
            outflows.append({
                'block': block_num,
                'hash': tx['hash'],
                'to': tx.get('to', ''),
                'value': int(tx['value'], 16) / 1e18
            })

print(f"Found {len(outflows)} outgoing txs in first 100 blocks after exploit")
for o in outflows[:10]:
    print(f"  Block {o['block']}: {o['hash'][:20]}... -> {o['to'][:20]}... ({o['value']:.4f} ETH)")
