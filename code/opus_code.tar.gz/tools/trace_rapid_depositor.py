#!/usr/bin/env python3
"""
Trace the funding source of the suspicious rapid Tornado depositor.
If they were funded by the Balancer attacker, we have a link.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

RAPID_DEPOSITOR = "0x0bb298be4c2656391d961bbe3248ddfc6e77746d"
ATTACKER_PROXY = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
EXPLOIT_BLOCK = 23718991

print(f"=== Tracing funding of {RAPID_DEPOSITOR} ===")

# Find the first transaction involving this address (funding transaction)
# We need to find ETH transfers to this address

# Check for internal transactions - look for value transfers
# First, let's find when this address became active

# Get the nonce to understand activity level
nonce_req = {"jsonrpc": "2.0", "method": "eth_getTransactionCount", "params": [RAPID_DEPOSITOR, "latest"], "id": 1}
nonce = int(run_curl(nonce_req)['result'], 16)
print(f"Total transactions sent: {nonce}")

# Look for ETH transfers TO this address using trace methods or logs
# Since Erigon supports trace_filter, let's try that

# Actually, let's look for the first block where this address appears
# by checking balance at different points

# Check balance right before and after exploit
print(f"\nChecking balance history...")

# At exploit block
bal_at_exploit = {"jsonrpc": "2.0", "method": "eth_getBalance", "params": [RAPID_DEPOSITOR, hex(EXPLOIT_BLOCK)], "id": 1}
bal = run_curl(bal_at_exploit)
if 'result' in bal:
    print(f"Balance at exploit (block {EXPLOIT_BLOCK}): {int(bal['result'], 16) / 1e18:.4f} ETH")

# 1000 blocks after
bal_after = {"jsonrpc": "2.0", "method": "eth_getBalance", "params": [RAPID_DEPOSITOR, hex(EXPLOIT_BLOCK + 1000)], "id": 1}
bal = run_curl(bal_after)
if 'result' in bal:
    print(f"Balance at block {EXPLOIT_BLOCK + 1000}: {int(bal['result'], 16) / 1e18:.4f} ETH")

# 5000 blocks after
bal_after = {"jsonrpc": "2.0", "method": "eth_getBalance", "params": [RAPID_DEPOSITOR, hex(EXPLOIT_BLOCK + 5000)], "id": 1}
bal = run_curl(bal_after)
if 'result' in bal:
    print(f"Balance at block {EXPLOIT_BLOCK + 5000}: {int(bal['result'], 16) / 1e18:.4f} ETH")

# Now - if balance was 0 at exploit and non-zero shortly after, this is suspicious

# Try trace_filter to find incoming ETH
print(f"\nTrying to find incoming ETH transfers...")
trace_req = {
    "jsonrpc": "2.0",
    "method": "trace_filter",
    "params": [{
        "toAddress": [RAPID_DEPOSITOR],
        "fromBlock": hex(EXPLOIT_BLOCK - 1000),
        "toBlock": hex(EXPLOIT_BLOCK + 10000),
        "count": 10
    }],
    "id": 1
}
result = run_curl(trace_req)
if 'result' in result and result['result']:
    print(f"Found {len(result['result'])} traces")
    for trace in result['result'][:5]:
        if trace.get('action', {}).get('value'):
            value = int(trace['action']['value'], 16)
            if value > 0:
                print(f"\nIncoming ETH:")
                print(f"  From: {trace['action'].get('from', 'N/A')}")
                print(f"  Value: {value / 1e18:.4f} ETH")
                print(f"  Block: {trace.get('blockNumber', 'N/A')}")
                print(f"  TX: {trace.get('transactionHash', 'N/A')}")
elif 'error' in result:
    print(f"Error: {result['error']}")
else:
    print("No traces found")
