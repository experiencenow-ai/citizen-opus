#!/usr/bin/env python3
"""
Follow the chain of attacker addresses.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

# Chain of addresses found so far
ADDRESSES = [
    "0x0000000000004f3d8aaf9175fd824cb00ad4bf80",  # Original sender
    "0x000000000000bb1b11e5ac8099e92e366b64c133",  # Exploit contract
    "0x000000000000e59fc57340cd50d1b12221601b87",  # Received stolen tokens
]

TORNADO_100 = "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"
EXPLOIT_BLOCK = 23718991

for addr in ADDRESSES:
    print(f"\n=== {addr} ===")
    
    # Check balance
    bal_req = {"jsonrpc": "2.0", "method": "eth_getBalance", "params": [addr, "latest"], "id": 1}
    bal = run_curl(bal_req)
    print(f"ETH balance: {int(bal['result'], 16) / 1e18:.4f}")
    
    # Check if contract
    code_req = {"jsonrpc": "2.0", "method": "eth_getCode", "params": [addr, "latest"], "id": 1}
    code = run_curl(code_req)
    code_len = len(code['result']) - 2
    print(f"Type: {'CONTRACT' if code_len > 0 else 'EOA'}")
    
    # Check transaction count
    nonce_req = {"jsonrpc": "2.0", "method": "eth_getTransactionCount", "params": [addr, "latest"], "id": 1}
    nonce = run_curl(nonce_req)
    print(f"Transaction count: {int(nonce['result'], 16)}")

# Now let's find if any of these addresses deposited to Tornado Cash
print(f"\n=== Checking Tornado Cash deposits from attacker addresses ===")

# Get all transactions from the third address (the one that received tokens)
# Look for transactions to Tornado Cash
addr = ADDRESSES[2]
nonce_req = {"jsonrpc": "2.0", "method": "eth_getTransactionCount", "params": [addr, "latest"], "id": 1}
nonce = int(run_curl(nonce_req)['result'], 16)
print(f"\n{addr} has {nonce} transactions")

if nonce > 0 and nonce < 100:
    # Get transaction hashes by scanning
    print("Scanning for transactions from this address...")
    
    # Check if this address sent to Tornado
    # We need to find the block range where this address was active
    # Let's check recent internal transactions
