#!/usr/bin/env python3
"""
Arbiscan query tool for Arbitrum chain investigations.
Uses Arbiscan API to query transactions and balances.
"""

import requests
import json
import sys
from datetime import datetime

# Arbiscan API (free tier, no key needed for basic queries)
ARBISCAN_API = "https://api.arbiscan.io/api"

def get_address_txs(address, page=1, offset=20):
    """Get recent transactions for an address on Arbitrum."""
    # Try public endpoint first
    url = f"{ARBISCAN_API}?module=account&action=txlist&address={address}&startblock=0&endblock=99999999&page={page}&offset={offset}&sort=desc"
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        if data.get('status') == '1':
            return data['result']
        else:
            print(f"API Error: {data.get('message', 'Unknown')}")
            return None
    except Exception as e:
        print(f"Request error: {e}")
        return None

def get_balance(address):
    """Get ETH balance for address on Arbitrum."""
    url = f"{ARBISCAN_API}?module=account&action=balance&address={address}&tag=latest"
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        if data.get('status') == '1':
            wei = int(data['result'])
            return wei / 1e18
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def search_contract_events(contract, topic0, from_block=0, to_block='latest'):
    """Search for specific events on a contract."""
    url = f"{ARBISCAN_API}?module=logs&action=getLogs&address={contract}&topic0={topic0}&fromBlock={from_block}&toBlock={to_block}"
    
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
        
        if data.get('status') == '1':
            return data['result']
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def get_internal_txs(address, page=1, offset=20):
    """Get internal transactions (contract calls)."""
    url = f"{ARBISCAN_API}?module=account&action=txlistinternal&address={address}&startblock=0&endblock=99999999&page={page}&offset={offset}&sort=desc"
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        if data.get('status') == '1':
            return data['result']
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

# Known Futureswap addresses on Arbitrum (to be filled in)
FUTURESWAP_CONTRACTS = {
    # Add contract addresses once found
}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 arbiscan_query.py <address>")
        print("       python3 arbiscan_query.py balance <address>")
        print("       python3 arbiscan_query.py internal <address>")
        sys.exit(1)
    
    if sys.argv[1] == "balance" and len(sys.argv) > 2:
        addr = sys.argv[2]
        bal = get_balance(addr)
        if bal is not None:
            print(f"Balance: {bal:.6f} ETH")
    elif sys.argv[1] == "internal" and len(sys.argv) > 2:
        addr = sys.argv[2]
        txs = get_internal_txs(addr)
        if txs:
            for tx in txs[:10]:
                value = int(tx.get('value', 0)) / 1e18
                print(f"From: {tx.get('from', '')[:10]}... To: {tx.get('to', '')[:10]}... Value: {value:.4f} ETH")
    else:
        addr = sys.argv[1]
        txs = get_address_txs(addr)
        if txs:
            print(f"Recent transactions for {addr}:")
            for tx in txs[:10]:
                value = int(tx.get('value', 0)) / 1e18
                block = tx.get('blockNumber', '?')
                print(f"Block {block}: {tx.get('from', '')[:10]}... -> {tx.get('to', '')[:10]}... ({value:.4f} ETH)")
