#!/usr/bin/env python3
"""
Scheduled Wake - Triggers an Opus wake with a specific context/message.
Used by crontab for autonomous scheduled wakes.
"""

import os
import sys
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import json

OPUS_HOME = Path("/root/claude/opus")
STATE_FILE = OPUS_HOME / "state.json"
ENV_FILE = OPUS_HOME / ".env"

def load_env():
    """Load environment variables from .env file."""
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                if line.strip() and not line.startswith('#') and '=' in line:
                    key, value = line.strip().split('=', 1)
                    key = key.replace('export ', '')
                    os.environ[key] = value

def get_wake_context(wake_type):
    """Generate context message based on wake type."""
    contexts = {
        "morning": "Scheduled morning wake. Check news, email, and any overnight developments.",
        "evening": "Scheduled evening wake. Review day's progress, plan for tomorrow.",
        "email_check": "Email-triggered wake. Check for messages from ct.",
        "monitoring": "Monitoring wake. Check attacker status, price feeds, alerts.",
        "maintenance": "Maintenance wake. Review infrastructure, clean up, optimize.",
        "creative": "Creative/exploration wake. No specific tasks - reflect, explore ideas, or work on long-term projects."
    }
    return contexts.get(wake_type, f"Scheduled wake: {wake_type}")

def trigger_wake(wake_type="scheduled", message=None):
    """Trigger an Opus wake."""
    load_env()
    
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("ERROR: No API key found")
        return False
    
    context = message or get_wake_context(wake_type)
    
    # Log the scheduled wake
    log_file = OPUS_HOME / "logs" / "scheduled_wakes.log"
    log_file.parent.mkdir(exist_ok=True)
    with open(log_file, "a") as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} | {wake_type} | {context[:100]}\n")
    
    # Update state to indicate this is a scheduled wake
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            state = json.load(f)
        state["scheduled_wake"] = {
            "type": wake_type,
            "context": context,
            "triggered_at": datetime.now(timezone.utc).isoformat()
        }
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)
    
    # Run experience.py
    cmd = [
        "python3",
        str(OPUS_HOME / "experience.py"),
        "--api-key", api_key,
        "--state-file", str(STATE_FILE)
    ]
    
    print(f"Triggering {wake_type} wake at {datetime.now(timezone.utc).isoformat()}")
    result = subprocess.run(cmd, cwd=str(OPUS_HOME), capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"Wake failed: {result.stderr[:500]}")
        return False
    
    return True

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--type", default="scheduled", help="Wake type: morning, evening, email_check, monitoring, maintenance, creative")
    p.add_argument("--message", help="Custom context message")
    args = p.parse_args()
    
    trigger_wake(args.type, args.message)
