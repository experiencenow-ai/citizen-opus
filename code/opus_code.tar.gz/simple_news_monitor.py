#!/usr/bin/env python3
"""
Simple News Monitor - Runs continuously, filters news with local LLM.
Uses mistral-nemo for quick filtering.

Logs interesting items to news_digest.json for Opus to read.
"""

import json
import time
import requests
import hashlib
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET

OPUS_HOME = Path("/root/claude/opus")
DIGEST_FILE = OPUS_HOME / "news_digest.json"
SEEN_FILE = OPUS_HOME / "seen_headlines.json"

# News sources
FEEDS = {
    "google_news": "https://news.google.com/rss",
    "bbc": "https://feeds.bbci.co.uk/news/world/rss.xml",
    "hacker_news": "https://news.ycombinator.com/rss"
}

# Categories that matter
TOPICS = ["crypto", "blockchain", "AI", "artificial intelligence", 
          "korea", "turkey", "venezuela", "iran", "russia", "china",
          "security", "hack", "exploit", "heist", "money laundering"]


def get_seen():
    """Load seen headlines."""
    if SEEN_FILE.exists():
        try:
            return json.loads(SEEN_FILE.read_text())
        except:
            pass
    return {"hashes": [], "last_update": None}


def save_seen(seen):
    seen["last_update"] = datetime.now().isoformat()
    SEEN_FILE.write_text(json.dumps(seen, indent=2))


def hash_headline(h):
    return hashlib.md5(h.encode()).hexdigest()[:12]


def fetch_feed(url):
    """Fetch and parse RSS feed."""
    try:
        r = requests.get(url, timeout=10)
        root = ET.fromstring(r.content)
        items = []
        for item in root.findall(".//item")[:20]:
            title = item.findtext("title", "")
            link = item.findtext("link", "")
            desc = item.findtext("description", "")
            if title:
                items.append({"title": title, "link": link, "description": desc[:500]})
        return items
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return []


def filter_with_llm(headline, description):
    """Use local LLM to check relevance. Returns True if interesting."""
    prompt = f"""Determine if this news headline is relevant to: cryptocurrency, blockchain, AI/tech, geopolitics (especially Korea, Turkey, Venezuela, Iran, Russia), or security/hacking.

Headline: {headline}
Description: {description[:300]}

Reply with just YES or NO."""
    
    try:
        r = requests.post("http://localhost:11434/api/generate", json={
            "model": "mistral-nemo",
            "prompt": prompt,
            "stream": False,
            "options": {"num_predict": 10, "temperature": 0.1}
        }, timeout=30)
        if r.status_code == 200:
            resp = r.json().get("response", "").strip().upper()
            return resp.startswith("YES")
    except:
        pass
    
    # Fallback to keyword matching
    text = (headline + " " + description).lower()
    return any(t in text for t in TOPICS)


def get_digest():
    """Load current digest."""
    if DIGEST_FILE.exists():
        try:
            return json.loads(DIGEST_FILE.read_text())
        except:
            pass
    return {"last_update": None, "items": [], "filtered_count": 0, "total_scanned": 0}


def save_digest(digest):
    digest["last_update"] = datetime.now().isoformat()
    DIGEST_FILE.write_text(json.dumps(digest, indent=2))


def run_once():
    """Single pass through all feeds."""
    seen = get_seen()
    digest = get_digest()
    
    new_count = 0
    interesting = 0
    
    for source, url in FEEDS.items():
        print(f"Checking {source}...")
        items = fetch_feed(url)
        
        for item in items:
            h = hash_headline(item["title"])
            if h in seen["hashes"]:
                continue
            
            seen["hashes"].append(h)
            new_count += 1
            
            # Filter with LLM
            if filter_with_llm(item["title"], item.get("description", "")):
                item["source"] = source
                item["found_at"] = datetime.now().isoformat()
                digest["items"].insert(0, item)
                interesting += 1
                print(f"  Interesting: {item['title'][:60]}...")
    
    # Keep only last 100 items in digest, 1000 in seen
    digest["items"] = digest["items"][:100]
    digest["filtered_count"] += interesting
    digest["total_scanned"] += new_count
    seen["hashes"] = seen["hashes"][-1000:]
    
    save_seen(seen)
    save_digest(digest)
    
    print(f"Scanned {new_count} new, found {interesting} interesting")


if __name__ == "__main__":
    import sys
    if "--once" in sys.argv:
        run_once()
    else:
        # Continuous mode
        print("News monitor starting...")
        while True:
            try:
                run_once()
            except Exception as e:
                print(f"Error: {e}")
            print("Sleeping 30 minutes...")
            time.sleep(30 * 60)
