#!/usr/bin/env python3
"""Find Withdraw events from MWETH vault using different approach"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"

# ERC4626 Withdraw event: Withdraw(address indexed sender, address indexed receiver, address indexed owner, uint256 assets, uint256 shares)
# keccak256("Withdraw(address,address,address,uint256,uint256)") = 0xfbde797d201c681b91056529119e0b02407c7bb96a4a2c75c01fc9667232c8db
WITHDRAW_SIG = "0xfbde797d201c681b91056529119e0b02407c7bb96a4a2c75c01fc9667232c8db"

# ERC4626 Deposit event
DEPOSIT_SIG = "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7"

# Standard Transfer
TRANSFER_SIG = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

def rpc_call(method, params):
    cmd = f'''curl -s -m 30 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return json.loads(result.stdout).get("result")

current_block = int(rpc_call("eth_blockNumber", []), 16)

# Search for Withdraw events
print("Searching for Withdraw events...")
logs = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "topics": [WITHDRAW_SIG],
    "fromBlock": hex(23718991),  # from exploit
    "toBlock": "latest"
}])
print(f"Withdraw events: {len(logs) if logs else 0}")

# Search for Deposit events  
print("\nSearching for Deposit events...")
logs2 = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "topics": [DEPOSIT_SIG],
    "fromBlock": hex(23718991),
    "toBlock": "latest"
}])
print(f"Deposit events: {len(logs2) if logs2 else 0}")

# Search for Transfer events
print("\nSearching for Transfer events...")
logs3 = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "topics": [TRANSFER_SIG],
    "fromBlock": hex(23718991),
    "toBlock": "latest"
}])
print(f"Transfer events: {len(logs3) if logs3 else 0}")

# Maybe the vault is a proxy - check what happens with any topic
print("\nSearching for ANY events...")
logs4 = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "fromBlock": hex(23718991),
    "toBlock": "latest"
}])
print(f"Any events: {len(logs4) if logs4 else 0}")
if logs4:
    topics = set()
    for l in logs4:
        if l["topics"]:
            topics.add(l["topics"][0])
    print(f"Unique topics: {topics}")
