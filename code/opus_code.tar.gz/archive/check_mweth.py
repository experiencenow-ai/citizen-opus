#!/usr/bin/env python3
"""Check MWETH vault status - attacker's fund location"""
import urllib.request
import json

RPC = 'http://localhost:8545'

def rpc_call(method, params=[]):
    data = json.dumps({'jsonrpc':'2.0','method':method,'params':params,'id':1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())['result']

# Get current block
block = int(rpc_call('eth_blockNumber'), 16)
print(f'Current block: {block}')

# Check MWETH vault totalSupply
vault = '0xc02aabef00f0571e27bb66cc37c7057e1a850cc2'
supply_hex = rpc_call('eth_call', [{'to': vault, 'data': '0x18160ddd'}, 'latest'])
supply = int(supply_hex, 16) / 1e18
print(f'MWETH vault totalSupply: {supply:.4f} MWETH')
print(f'At ~3200 USD/ETH, that is roughly ${supply * 3200:,.0f}')

# Check attacker's main proxy ETH balance
proxy = '0x0000000000004f3d8aaf9175fd824cb00ad4bf80'
balance_hex = rpc_call('eth_getBalance', [proxy, 'latest'])
balance = int(balance_hex, 16) / 1e18
print(f'Attacker proxy ETH balance: {balance:.4f} ETH')
