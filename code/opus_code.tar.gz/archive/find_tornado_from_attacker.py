#!/usr/bin/env python3
"""
Find Tornado Cash deposits from the main attacker proxy.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

ATTACKER_PROXY = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
TORNADO_100 = "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"
EXPLOIT_BLOCK = 23718991

# Get current block
current_req = {"jsonrpc": "2.0", "method": "eth_blockNumber", "id": 1}
current_block = int(run_curl(current_req)['result'], 16)

# Look for Tornado Cash deposit events and cross-reference with attacker transactions
# Since we can't easily get all transactions from an address, let's look for
# Tornado deposits and check if any came from the attacker

# Deposit event signature
DEPOSIT_TOPIC = "0xa945e51eec50ab98c161376f0db4cf2aeba3ec92755fe2fcd388bdbbb80ff196"

print("Scanning Tornado 100 ETH deposits after exploit for attacker address...")
print(f"Checking blocks {EXPLOIT_BLOCK} to {EXPLOIT_BLOCK + 50000}")

# Search in chunks
chunk_size = 10000
attacker_deposits = []

for start in range(EXPLOIT_BLOCK, min(EXPLOIT_BLOCK + 50000, current_block), chunk_size):
    end = min(start + chunk_size, current_block)
    
    logs_req = {
        "jsonrpc": "2.0",
        "method": "eth_getLogs",
        "params": [{
            "fromBlock": hex(start),
            "toBlock": hex(end),
            "address": TORNADO_100,
            "topics": [DEPOSIT_TOPIC]
        }],
        "id": 1
    }
    
    result = run_curl(logs_req)
    if 'result' in result:
        for log in result['result']:
            # Get the transaction to check sender
            tx_req = {
                "jsonrpc": "2.0",
                "method": "eth_getTransactionByHash",
                "params": [log['transactionHash']],
                "id": 1
            }
            tx = run_curl(tx_req)
            if tx.get('result') and tx['result']['from'].lower() == ATTACKER_PROXY.lower():
                block = int(log['blockNumber'], 16)
                attacker_deposits.append({
                    'block': block,
                    'tx': log['transactionHash']
                })
                print(f"Found! Block {block}: {log['transactionHash']}")

print(f"\nTotal deposits from attacker: {len(attacker_deposits)}")

# Also check the 10 ETH pool
TORNADO_10 = "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"  # Same address handles multiple denominations

# Let's also look at the rapid depositor we found earlier
print(f"\n=== Checking rapid depositor 0x0bb298be4c2656391d961bbe3248ddfc6e77746d ===")
rapid_depositor = "0x0bb298be4c2656391d961bbe3248ddfc6e77746d"

# Check this address's balance and activity
bal_req = {"jsonrpc": "2.0", "method": "eth_getBalance", "params": [rapid_depositor, "latest"], "id": 1}
bal = run_curl(bal_req)
print(f"ETH balance: {int(bal['result'], 16) / 1e18:.4f}")

code_req = {"jsonrpc": "2.0", "method": "eth_getCode", "params": [rapid_depositor, "latest"], "id": 1}
code = run_curl(code_req)
code_len = len(code['result']) - 2
print(f"Type: {'CONTRACT' if code_len > 0 else 'EOA'}")

nonce_req = {"jsonrpc": "2.0", "method": "eth_getTransactionCount", "params": [rapid_depositor, "latest"], "id": 1}
nonce = run_curl(nonce_req)
print(f"Transaction count: {int(nonce['result'], 16)}")
