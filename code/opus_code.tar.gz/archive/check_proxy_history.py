#!/usr/bin/env python3
"""Check the main proxy's transaction count and recent activity"""
import urllib.request
import json

RPC = "http://localhost:8546"

def eth_call(method, params):
    data = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read()).get("result")

MAIN_PROXY = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"

# Get nonce (transaction count)
nonce = eth_call("eth_getTransactionCount", [MAIN_PROXY, "latest"])
print(f"Main proxy {MAIN_PROXY}")
print(f"Total transactions sent: {int(nonce, 16)}")

# Get current balance
balance = eth_call("eth_getBalance", [MAIN_PROXY, "latest"])
print(f"Current ETH balance: {int(balance, 16) / 1e18:.4f} ETH")

# Check the secondary addresses
for addr in [
    "0x000000000000bb1b11e5ac8099e92e366b64c133",
    "0x000000000000e59fc57340cd50d1b12221601b87",
]:
    nonce = eth_call("eth_getTransactionCount", [addr, "latest"])
    balance = eth_call("eth_getBalance", [addr, "latest"])
    code = eth_call("eth_getCode", [addr, "latest"])
    print(f"\n{addr}")
    print(f"  Transactions: {int(nonce, 16)}")
    print(f"  ETH balance: {int(balance, 16) / 1e18:.4f} ETH")
    print(f"  Code size: {(len(code) - 2) // 2 if code else 0} bytes")
