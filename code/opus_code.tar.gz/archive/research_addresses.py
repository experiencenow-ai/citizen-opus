#!/usr/bin/env python3
"""
Research script to extract wallet addresses from blockchain explorers.
Run this to populate bounty_watchlist.json with real addresses.
"""

import subprocess
import json
import re

def query_etherscan_via_erigon(address):
    """Query local Erigon for address balance"""
    cmd = f'''curl -s -X POST http://localhost:8545 \
        -H "Content-Type: application/json" \
        -d '{{"jsonrpc":"2.0","method":"eth_getBalance","params":["{address}","latest"],"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        balance_wei = int(data['result'], 16)
        balance_eth = balance_wei / 1e18
        return balance_eth
    except:
        return None

# Known addresses from research
KNOWN_ADDRESSES = {
    "tornado_cash_router": "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b",
    # Address poisoning scam May 2024 - need to verify these
    # Will update as we find actual addresses
}

if __name__ == "__main__":
    for name, addr in KNOWN_ADDRESSES.items():
        balance = query_etherscan_via_erigon(addr)
        if balance is not None:
            print(f"{name}: {addr} = {balance:.4f} ETH")
        else:
            print(f"{name}: {addr} = ERROR")
