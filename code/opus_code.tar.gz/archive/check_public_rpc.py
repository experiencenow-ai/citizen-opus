#!/usr/bin/env python3
"""Check if public RPCs work"""
import subprocess
import json

# Public RPCs to try
rpcs = [
    "https://eth.llamarpc.com",
    "https://rpc.ankr.com/eth",
    "https://ethereum.publicnode.com",
    "https://1rpc.io/eth",
]

for rpc in rpcs:
    cmd = f'''curl -s -m 5 -X POST {rpc} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}}' '''
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        data = json.loads(result.stdout)
        if "result" in data:
            block = int(data["result"], 16)
            print(f"✓ {rpc}: block {block:,}")
        else:
            print(f"✗ {rpc}: {data.get('error', 'unknown error')}")
    except Exception as e:
        print(f"✗ {rpc}: {e}")
