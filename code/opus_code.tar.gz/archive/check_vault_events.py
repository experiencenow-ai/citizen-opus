#!/usr/bin/env python3
"""Check all events from MWETH vault"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"

def rpc_call(method, params):
    cmd = f'''curl -s -m 30 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return json.loads(result.stdout).get("result")

# Check if it's a contract
code = rpc_call("eth_getCode", [MWETH_VAULT, "latest"])
if code and code != "0x":
    print(f"Contract size: {(len(code)-2)//2} bytes")
else:
    print("Not a contract!")
    exit()

# Get ALL logs from this address (no topic filter)
current_block = int(rpc_call("eth_blockNumber", []), 16)
start_block = current_block - 50000  # last ~7 days

logs = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "fromBlock": hex(start_block),
    "toBlock": "latest"
}])

if logs:
    print(f"Found {len(logs)} events in last 50k blocks:")
    event_types = {}
    for log in logs:
        topic0 = log["topics"][0] if log["topics"] else "no_topic"
        event_types[topic0] = event_types.get(topic0, 0) + 1
    for topic, count in event_types.items():
        print(f"  {topic[:18]}...: {count}")
else:
    print("No events found")
    
# Try checking from earlier - around the exploit
print("\nChecking from exploit time (block 23718991)...")
logs2 = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "fromBlock": hex(23718991),
    "toBlock": hex(23718991 + 10000)
}])
if logs2:
    print(f"Found {len(logs2)} events near exploit")
else:
    print("No events near exploit")
