#!/usr/bin/env python3
"""
Check Futureswap contracts on Arbitrum for exploit investigation.
The protocol lost ~$400K (52% of Arbitrum TVL) on Jan 10-11, 2026.
"""

import subprocess
import json

# Known Futureswap contract addresses (from docs/DefiLlama)
# FST token on Arbitrum
FST_TOKEN_ARB = "0x488cc08935458403a0458e45E20c0159c8AB2c92"

# Arbitrum RPC endpoints
ARB_RPCS = [
    "https://arb1.arbitrum.io/rpc",
    "https://arbitrum.llamarpc.com",
    "https://rpc.ankr.com/arbitrum"
]

def query_rpc(rpc_url, method, params):
    """Query JSON-RPC endpoint."""
    payload = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }
    try:
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", "-H", "Content-Type: application/json",
             "--data", json.dumps(payload), rpc_url],
            capture_output=True, text=True, timeout=15
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"error": str(e)}

def get_balance(address, rpc_url):
    """Get ETH balance on Arbitrum."""
    result = query_rpc(rpc_url, "eth_getBalance", [address, "latest"])
    if "result" in result:
        return int(result["result"], 16) / 1e18
    return None

def get_block_number(rpc_url):
    """Get current block number."""
    result = query_rpc(rpc_url, "eth_blockNumber", [])
    if "result" in result:
        return int(result["result"], 16)
    return None

if __name__ == "__main__":
    print("=== Futureswap Arbitrum Investigation ===\n")
    
    # Try to connect to Arbitrum
    for rpc in ARB_RPCS:
        block = get_block_number(rpc)
        if block:
            print(f"Connected to Arbitrum via {rpc}")
            print(f"Current block: {block:,}")
            break
    else:
        print("Failed to connect to any Arbitrum RPC")
        exit(1)
    
    print(f"\nFST Token Contract: {FST_TOKEN_ARB}")
    
    # Check if we can get the balance of the token contract
    bal = get_balance(FST_TOKEN_ARB, rpc)
    if bal is not None:
        print(f"FST Contract ETH balance: {bal:.6f} ETH")
    
    print("\n=== Next Steps ===")
    print("1. Need to find main Futureswap trading contracts on Arbitrum")
    print("2. Look for large ETH outflows in last 24-48 hours")
    print("3. Check for abnormal transactions around the time of the exploit")
    print("\nNote: Without an Etherscan API key, we're limited to direct RPC queries")
