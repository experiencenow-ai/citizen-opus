#!/usr/bin/env python3
"""
Monitor Balancer attacker's MetaMorpho vault for withdrawals.
Alert if funds start moving.
"""
import json
import subprocess
import sys
import os

def rpc(method, params=[]):
    data = {"jsonrpc": "2.0", "method": method, "params": params, "id": 1}
    cmd = ['curl', '-s', '-X', 'POST', 'http://localhost:8545', 
           '-H', 'Content-Type: application/json', '-d', json.dumps(data)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    return json.loads(result.stdout)

# Attacker addresses
ATTACKER = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"
WETH = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"

STATE_DIR = os.path.dirname(os.path.abspath(__file__))

def main():
    # Check vault status
    total_supply_result = rpc("eth_call", [{"to": MWETH_VAULT, "data": "0x18160ddd"}, "latest"])
    total_assets_result = rpc("eth_call", [{"to": MWETH_VAULT, "data": "0x01e1d114"}, "latest"])

    if 'result' in total_supply_result and 'result' in total_assets_result:
        supply = int(total_supply_result['result'], 16) / 1e18
        assets = int(total_assets_result['result'], 16) / 1e18
        
        print(f"MWETH Vault Status:")
        print(f"  Total Supply: {supply:.4f} MWETH")
        print(f"  Total Assets: {assets:.4f} WETH")
        print(f"  Share Price: {assets/supply:.6f}" if supply > 0 else "  Share Price: N/A")
        
        # Alert if supply decreased (withdrawal happened)
        state_file = os.path.join(STATE_DIR, 'mweth_last_supply.txt')
        try:
            with open(state_file, 'r') as f:
                last = float(f.read().strip())
            if supply < last - 0.01:
                print(f"\n!!! ALERT: Withdrawal detected! Supply dropped from {last:.4f} to {supply:.4f}")
        except:
            pass
        
        with open(state_file, 'w') as f:
            f.write(str(supply))

    # Check attacker's balances
    eth_bal = int(rpc("eth_getBalance", [ATTACKER, "latest"])['result'], 16) / 1e18
    weth_data = "0x70a08231" + "000000000000000000000000" + ATTACKER[2:]
    weth_bal = int(rpc("eth_call", [{"to": WETH, "data": weth_data}, "latest"])['result'], 16) / 1e18

    print(f"\nAttacker ({ATTACKER[:12]}...):")
    print(f"  ETH: {eth_bal:.4f}")
    print(f"  WETH: {weth_bal:.4f}")

    if weth_bal > 1.0:
        print(f"\n!!! ALERT: Attacker has {weth_bal:.4f} WETH - potential withdrawal!")
    
    return {"supply": supply, "assets": assets, "attacker_eth": eth_bal, "attacker_weth": weth_bal}

if __name__ == "__main__":
    main()
