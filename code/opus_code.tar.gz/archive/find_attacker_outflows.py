#!/usr/bin/env python3
"""
Find where the Balancer attacker sent funds after the exploit.
Look for ETH transfers and ERC20 transfers from the attacker contracts.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

ATTACKER_CONTRACT = "0x000000000000bb1b11e5ac8099e92e366b64c133"
EXPLOIT_BLOCK = 23718991

# Look for ERC20 transfers FROM the attacker contract after the exploit
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

# Search blocks after the exploit
print(f"Searching for transfers FROM attacker contract after block {EXPLOIT_BLOCK}...")

# Get all Transfer events where the attacker is the sender
# topic[1] is the 'from' address in Transfer events
attacker_topic = "0x000000000000000000000000" + ATTACKER_CONTRACT[2:].lower()

# Search in chunks - first check how many blocks since exploit
current_req = {"jsonrpc": "2.0", "method": "eth_blockNumber", "id": 1}
current_block = int(run_curl(current_req)['result'], 16)
print(f"Current block: {current_block}")
print(f"Blocks since exploit: {current_block - EXPLOIT_BLOCK}")

# Search first 10000 blocks after exploit
end_block = min(EXPLOIT_BLOCK + 10000, current_block)

logs_req = {
    "jsonrpc": "2.0",
    "method": "eth_getLogs",
    "params": [{
        "fromBlock": hex(EXPLOIT_BLOCK),
        "toBlock": hex(end_block),
        "topics": [TRANSFER_TOPIC, attacker_topic]
    }],
    "id": 1
}

result = run_curl(logs_req)
if 'result' in result:
    logs = result['result']
    print(f"\nFound {len(logs)} transfers FROM attacker in first 10k blocks")
    
    # Show destination addresses
    destinations = {}
    for log in logs:
        to_addr = "0x" + log['topics'][2][-40:]
        token = log['address']
        amount = int(log['data'], 16)
        key = (to_addr, token)
        destinations[key] = destinations.get(key, 0) + amount
    
    print("\nDestination breakdown:")
    for (to_addr, token), amount in sorted(destinations.items(), key=lambda x: -x[1])[:10]:
        print(f"To: {to_addr}")
        print(f"  Token: {token}")
        print(f"  Amount: {amount / 1e18:.4f}")
        print()
else:
    print(f"Error: {result}")

# Also check internal transactions - look for transactions TO known mixers
TORNADO_100 = "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"

print(f"\n=== Checking for Tornado Cash 100 ETH deposits from attacker ===")
# Look for deposits to Tornado Cash from this address
# Deposit event: Deposit(bytes32 indexed commitment, uint32 leafIndex, uint256 timestamp)
DEPOSIT_TOPIC = "0xa945e51eec50ab98c161376f0db4cf2aeba3ec92755fe2fcd388bdbbb80ff196"

tornado_req = {
    "jsonrpc": "2.0",
    "method": "eth_getLogs",
    "params": [{
        "fromBlock": hex(EXPLOIT_BLOCK),
        "toBlock": hex(current_block),
        "address": TORNADO_100
    }],
    "id": 1
}

result = run_curl(tornado_req)
if 'result' in result:
    deposits = [l for l in result['result'] if l['topics'][0] == DEPOSIT_TOPIC]
    print(f"Total Tornado 100 ETH deposits since exploit: {len(deposits)}")
    
    # Get unique depositors by checking transactions
    # This is expensive, so just sample
    if deposits:
        print(f"\nSampling first 5 deposit transactions...")
        for dep in deposits[:5]:
            tx_req = {
                "jsonrpc": "2.0",
                "method": "eth_getTransactionByHash",
                "params": [dep['transactionHash']],
                "id": 1
            }
            tx = run_curl(tx_req)['result']
            if tx:
                print(f"Block {int(dep['blockNumber'], 16)}: from {tx['from']}")
