#!/usr/bin/env python3
"""Verify the MWETH vault details"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"
ATTACKER = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"

def rpc_call(method, params):
    cmd = f'''curl -s -m 10 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return json.loads(result.stdout).get("result")

# Check name()
name = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x06fdde03"}, "latest"])
if name:
    # Decode string
    try:
        hex_str = name[2:]  # remove 0x
        if len(hex_str) > 128:
            # offset is first 32 bytes, length is next 32
            length = int(hex_str[64:128], 16)
            name_hex = hex_str[128:128+length*2]
            name_str = bytes.fromhex(name_hex).decode('utf-8', errors='ignore')
            print(f"Name: {name_str}")
    except:
        print(f"Name (raw): {name[:66]}...")

# Check symbol()
symbol = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x95d89b41"}, "latest"])
if symbol:
    try:
        hex_str = symbol[2:]
        if len(hex_str) > 128:
            length = int(hex_str[64:128], 16)
            sym_hex = hex_str[128:128+length*2]
            sym_str = bytes.fromhex(sym_hex).decode('utf-8', errors='ignore')
            print(f"Symbol: {sym_str}")
    except:
        print(f"Symbol (raw): {symbol[:66]}...")

# Check totalSupply()
supply = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x18160ddd"}, "latest"])
if supply:
    print(f"Total supply: {int(supply, 16) / 1e18:.6f}")

# Check owner()
owner = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x8da5cb5b"}, "latest"])
if owner and owner != "0x":
    print(f"Owner: 0x{owner[-40:]}")

# Check attacker's balance of this token
balance_call = "0x70a08231" + ATTACKER[2:].zfill(64)
balance = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": balance_call}, "latest"])
if balance:
    print(f"Attacker's MWETH balance: {int(balance, 16) / 1e18:.6f}")
