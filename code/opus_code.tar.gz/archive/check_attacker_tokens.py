#!/usr/bin/env python3
"""Check current token balances of attacker addresses"""
import urllib.request
import json

RPC = "http://localhost:8546"

def eth_call(method, params):
    data = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read()).get("result")

# ERC20 balanceOf(address) = 0x70a08231
def get_token_balance(token, holder):
    data = "0x70a08231" + holder[2:].zfill(64)
    result = eth_call("eth_call", [{"to": token, "data": data}, "latest"])
    if result and result != "0x":
        return int(result, 16)
    return 0

# Key tokens
TOKENS = {
    "WETH": "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    "osETH": "0xf1c9acdc66974dfb6decb12aa385b9cd01190e38",
    "wstETH": "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0",
    "rETH": "0xae78736cd615f374d3085123a210448e74fc6393",
    "cbETH": "0xbe9895146f7af43049ca1c1ae358b0541ea49704",
    "USDC": "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
    "USDT": "0xdac17f958d2ee523a2206206994597c13d831ec7",
}

# Attacker addresses
ADDRS = [
    "0x0000000000004f3d8aaf9175fd824cb00ad4bf80",  # Main proxy
    "0x000000000000bb1b11e5ac8099e92e366b64c133",  # Secondary
    "0x000000000000e59fc57340cd50d1b12221601b87",  # Third
    "0x2ead8b9f2fea0f84b6fd5f30fbbc4d293f6b5198",  # MWETH vault we found
]

for addr in ADDRS:
    eth_bal = eth_call("eth_getBalance", [addr, "latest"])
    eth_val = int(eth_bal, 16) / 1e18 if eth_bal else 0
    print(f"\n{addr}")
    print(f"  ETH: {eth_val:.4f}")
    
    for name, token in TOKENS.items():
        bal = get_token_balance(token, addr)
        if bal > 0:
            # USDC/USDT are 6 decimals
            decimals = 6 if name in ['USDC', 'USDT'] else 18
            val = bal / (10 ** decimals)
            if val > 0.001:
                print(f"  {name}: {val:.4f}")
