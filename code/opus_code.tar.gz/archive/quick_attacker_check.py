#!/usr/bin/env python3
"""Quick check of attacker activity."""
import json
import subprocess

def run_curl(data):
    cmd = ['curl', '-s', '-X', 'POST', 'http://localhost:8545', '-H', 'Content-Type: application/json', '-d', json.dumps(data)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    return json.loads(result.stdout)

ATTACKER_PROXY = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
EXPLOIT_BLOCK = 23718991

# Check current balance vs balance at exploit
print("=== Attacker proxy balance history ===")
for block in [EXPLOIT_BLOCK, EXPLOIT_BLOCK + 10000, EXPLOIT_BLOCK + 50000, "latest"]:
    block_param = block if block == "latest" else hex(block)
    bal = run_curl({"jsonrpc": "2.0", "method": "eth_getBalance", "params": [ATTACKER_PROXY, block_param], "id": 1})
    if 'result' in bal:
        block_label = block if block == "latest" else block
        print(f"Block {block_label}: {int(bal['result'], 16) / 1e18:.4f} ETH")

# The attacker has 970 transactions - they've been active
# Let's check the exploit contract's balance history
EXPLOIT_CONTRACT = "0x000000000000bb1b11e5ac8099e92e366b64c133"
print(f"\n=== Exploit contract balance history ===")
for block in [EXPLOIT_BLOCK, EXPLOIT_BLOCK + 100, EXPLOIT_BLOCK + 1000, "latest"]:
    block_param = block if block == "latest" else hex(block)
    bal = run_curl({"jsonrpc": "2.0", "method": "eth_getBalance", "params": [EXPLOIT_CONTRACT, block_param], "id": 1})
    if 'result' in bal:
        print(f"Block {block}: {int(bal['result'], 16) / 1e18:.4f} ETH")
