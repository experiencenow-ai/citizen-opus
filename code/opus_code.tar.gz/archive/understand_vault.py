#!/usr/bin/env python3
"""Understand what the MWETH vault actually does"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"

def rpc_call(method, params):
    cmd = f'''curl -s -m 10 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return json.loads(result.stdout).get("result")

# ERC4626 asset() function - what underlying asset does this vault hold?
# asset() = 0x38d52e0f
asset = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x38d52e0f"}, "latest"])
if asset:
    asset_addr = "0x" + asset[-40:]
    print(f"Underlying asset: {asset_addr}")
    
    # Check what this asset is
    # name()
    name = rpc_call("eth_call", [{"to": asset_addr, "data": "0x06fdde03"}, "latest"])
    if name and name != "0x":
        try:
            hex_str = name[2:]
            if len(hex_str) > 128:
                length = int(hex_str[64:128], 16)
                name_hex = hex_str[128:128+length*2]
                name_str = bytes.fromhex(name_hex).decode('utf-8', errors='ignore')
                print(f"Asset name: {name_str}")
        except:
            pass

# totalAssets() - how many underlying assets does the vault have?
# totalAssets() = 0x01e1d114
total_assets = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x01e1d114"}, "latest"])
if total_assets:
    print(f"Total assets: {int(total_assets, 16) / 1e18:.6f}")

# Check if this is a MetaMorpho vault - MORPHO() function
# MORPHO() = 0x3acb5624
morpho = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x3acb5624"}, "latest"])
if morpho and morpho != "0x":
    morpho_addr = "0x" + morpho[-40:]
    print(f"Morpho address: {morpho_addr}")

# Check decimals
decimals = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x313ce567"}, "latest"])
if decimals:
    print(f"Decimals: {int(decimals, 16)}")
