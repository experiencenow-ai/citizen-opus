#!/usr/bin/env python3
"""Investigate the Truebit exploit - January 8, 2026"""
import urllib.request
import json

RPC = "http://localhost:8546"

def eth_call(method, params):
    data = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": 1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read()).get("result")

# Affected contract mentioned by Truebit
AFFECTED_CONTRACT = "0x764C64b2A09b09Acb100B80d8c505Aa6a0302EF2"

print("=== Truebit Exploit Investigation ===")
print(f"Affected contract: {AFFECTED_CONTRACT}")

# Check the contract
code = eth_call("eth_getCode", [AFFECTED_CONTRACT, "latest"])
balance = eth_call("eth_getBalance", [AFFECTED_CONTRACT, "latest"])
nonce = eth_call("eth_getTransactionCount", [AFFECTED_CONTRACT, "latest"])

print(f"Current ETH balance: {int(balance, 16) / 1e18:.4f} ETH")
print(f"Transaction count: {int(nonce, 16)}")
print(f"Code size: {(len(code) - 2) // 2 if code else 0} bytes")

# Get current block to understand timeframe
current_block = int(eth_call("eth_blockNumber", []), 16)
print(f"\nCurrent block: {current_block}")

# January 8, 2026 would be around block... let's estimate
# Block 23875706 is now (Jan 10-11)
# ~7200 blocks/day, so Jan 8 would be ~14400 blocks earlier
jan_8_block_estimate = current_block - 14400
print(f"Estimated Jan 8 block: ~{jan_8_block_estimate}")

# Try to find recent transactions to/from this contract
# Check the last few blocks for any activity
print("\nChecking recent blocks for contract activity...")
for block_num in range(current_block - 100, current_block):
    block = eth_call("eth_getBlockByNumber", [hex(block_num), True])
    if not block:
        continue
    for tx in block.get('transactions', []):
        if tx.get('to', '').lower() == AFFECTED_CONTRACT.lower():
            print(f"Block {block_num}: TX to contract: {tx['hash']}")
        if tx.get('from', '').lower() == AFFECTED_CONTRACT.lower():
            print(f"Block {block_num}: TX from contract: {tx['hash']}")
