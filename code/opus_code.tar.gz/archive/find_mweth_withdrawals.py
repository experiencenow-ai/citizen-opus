#!/usr/bin/env python3
"""Find when MWETH vault was drained"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"

# Transfer event signature
TRANSFER_SIG = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

def rpc_call(method, params):
    cmd = f'''curl -s -m 30 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    data = json.loads(result.stdout)
    return data.get("result")

# Get logs from the vault - look at recent blocks
# Last known supply was ~262 WETH around block 23875706
# Check from that block to now
current_block = int(rpc_call("eth_blockNumber", []), 16)
start_block = 23875706  # last known good

print(f"Checking MWETH vault transfers from block {start_block:,} to {current_block:,}")
print(f"Block range: {current_block - start_block:,} blocks")

# Get all transfer events from the vault
logs = rpc_call("eth_getLogs", [{
    "address": MWETH_VAULT,
    "topics": [TRANSFER_SIG],
    "fromBlock": hex(start_block),
    "toBlock": "latest"
}])

if logs:
    print(f"\nFound {len(logs)} transfer events:")
    for log in logs:
        block = int(log["blockNumber"], 16)
        from_addr = "0x" + log["topics"][1][-40:] if len(log["topics"]) > 1 else "?"
        to_addr = "0x" + log["topics"][2][-40:] if len(log["topics"]) > 2 else "?"
        value = int(log["data"], 16) / 1e18 if log["data"] != "0x" else 0
        tx = log["transactionHash"][:18]
        print(f"  Block {block}: {value:.4f} MWETH from {from_addr[:12]}... to {to_addr[:12]}... ({tx}...)")
else:
    print("No transfers found")
