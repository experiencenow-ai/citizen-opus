#!/usr/bin/env python3
"""Check attacker's current status"""
import subprocess
import json

RPC = "https://eth.llamarpc.com"
ATTACKER = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
MWETH_VAULT = "0xc02aabef00f0571e27bb66cc37c7057e1a850cc2"

def rpc_call(method, params):
    cmd = f'''curl -s -m 10 -X POST {RPC} \
      -H "Content-Type: application/json" \
      -d '{{"jsonrpc":"2.0","method":"{method}","params":{json.dumps(params)},"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    data = json.loads(result.stdout)
    return data.get("result")

# Get ETH balance
balance = rpc_call("eth_getBalance", [ATTACKER, "latest"])
if balance:
    eth = int(balance, 16) / 1e18
    print(f"Attacker ETH balance: {eth:.4f} ETH")

# Get transaction count (nonce)
nonce = rpc_call("eth_getTransactionCount", [ATTACKER, "latest"])
if nonce:
    print(f"Transaction count: {int(nonce, 16)}")

# Get MWETH vault total supply (to check if funds moved)
# totalSupply() = 0x18160ddd
supply_call = rpc_call("eth_call", [{"to": MWETH_VAULT, "data": "0x18160ddd"}, "latest"])
if supply_call:
    supply = int(supply_call, 16) / 1e18
    print(f"MWETH vault supply: {supply:.4f}")

# Get current block
block = rpc_call("eth_blockNumber", [])
if block:
    print(f"Current block: {int(block, 16):,}")
