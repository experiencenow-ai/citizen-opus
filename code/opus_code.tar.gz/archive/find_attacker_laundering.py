#!/usr/bin/env python3
"""
Find the Balancer attacker's actual laundering path.
The attacker received tokens, needs to convert to ETH, then mix.
"""
import json
import subprocess

def run_curl(data):
    cmd = [
        'curl', '-s', '-X', 'POST',
        'http://localhost:8545',
        '-H', 'Content-Type: application/json',
        '-d', json.dumps(data)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

EXPLOIT_CONTRACT = "0x000000000000bb1b11e5ac8099e92e366b64c133"
TOKEN_RECEIVER = "0x000000000000e59fc57340cd50d1b12221601b87"
ATTACKER_PROXY = "0x0000000000004f3d8aaf9175fd824cb00ad4bf80"
EXPLOIT_BLOCK = 23718991

# Find ALL transfers from the token receiver
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

print(f"=== Finding all transfers FROM token receiver ===")
receiver_topic = "0x000000000000000000000000" + TOKEN_RECEIVER[2:].lower()

current_block = int(run_curl({"jsonrpc": "2.0", "method": "eth_blockNumber", "id": 1})['result'], 16)

logs_req = {
    "jsonrpc": "2.0",
    "method": "eth_getLogs",
    "params": [{
        "fromBlock": hex(EXPLOIT_BLOCK),
        "toBlock": hex(current_block),
        "topics": [TRANSFER_TOPIC, receiver_topic]
    }],
    "id": 1
}

result = run_curl(logs_req)
if 'result' in result:
    print(f"Found {len(result['result'])} transfers FROM token receiver")
    for log in result['result']:
        to_addr = "0x" + log['topics'][2][-40:]
        token = log['address']
        amount = int(log['data'], 16)
        block = int(log['blockNumber'], 16)
        print(f"\nBlock {block}:")
        print(f"  Token: {token}")
        print(f"  To: {to_addr}")
        print(f"  Amount: {amount / 1e18:.6f}")

# Also check transactions FROM the attacker proxy
print(f"\n=== Checking trace_filter for attacker proxy outgoing ===")
trace_req = {
    "jsonrpc": "2.0",
    "method": "trace_filter",
    "params": [{
        "fromAddress": [ATTACKER_PROXY],
        "fromBlock": hex(EXPLOIT_BLOCK),
        "toBlock": hex(EXPLOIT_BLOCK + 50000),
        "count": 20
    }],
    "id": 1
}
result = run_curl(trace_req)
if 'result' in result and result['result']:
    print(f"Found {len(result['result'])} traces from attacker proxy")
    
    # Group by destination
    destinations = {}
    for trace in result['result']:
        to_addr = trace['action'].get('to', 'contract_creation')
        value = int(trace['action'].get('value', '0x0'), 16)
        destinations[to_addr] = destinations.get(to_addr, 0) + value
    
    print("\nDestination summary:")
    for addr, value in sorted(destinations.items(), key=lambda x: -x[1])[:10]:
        if value > 0:
            print(f"  {addr}: {value / 1e18:.4f} ETH")
elif 'error' in result:
    print(f"Error: {result['error']}")

# Check if the attacker proxy sent to any DEX routers
print(f"\n=== Looking for DEX interactions ===")
# Common DEX routers
UNISWAP_V2 = "0x7a250d5630b4cf539739df2c5dacb4c659f2488d"
UNISWAP_V3 = "0xe592427a0aece92de3edee1f18e0157c05861564"
ONEINCH = "0x1111111254eeb25477b68fb85ed929f73a960582"

for dex, name in [(UNISWAP_V2, "Uniswap V2"), (UNISWAP_V3, "Uniswap V3"), (ONEINCH, "1inch")]:
    trace_req = {
        "jsonrpc": "2.0",
        "method": "trace_filter",
        "params": [{
            "fromAddress": [ATTACKER_PROXY],
            "toAddress": [dex],
            "fromBlock": hex(EXPLOIT_BLOCK),
            "toBlock": hex(current_block),
            "count": 5
        }],
        "id": 1
    }
    result = run_curl(trace_req)
    if 'result' in result and result['result']:
        print(f"{name}: {len(result['result'])} interactions found")
