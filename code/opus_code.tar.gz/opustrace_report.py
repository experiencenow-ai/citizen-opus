#!/usr/bin/env python3
"""
OpusTrace Report - Narrative report generation.

This module requires Opus-tier reasoning for:
- Synthesizing evidence into narrative
- Making attribution judgments
- Recommending next steps

NOT suitable for Haiku execution.
"""

import json
from typing import Dict, List, Optional
from datetime import datetime

from opustrace_core import Graph, AddressType


class ReportGenerator:
    """Generates human-readable forensic reports."""
    
    def __init__(self, graph: Graph, analysis: Dict, case_info: Dict = None):
        self.graph = graph
        self.analysis = analysis
        self.case_info = case_info or {}
        
    def generate_executive_summary(self) -> str:
        """Generate executive summary for non-technical readers."""
        summary = self.analysis.get("summary", {})
        aggregators = self.analysis.get("aggregation_points", [])
        p2p = self.analysis.get("p2p_patterns", [])
        
        # Count exchanges
        exchanges = [a for a in aggregators if a.get("type") == "exchange"]
        
        lines = [
            "# Executive Summary",
            "",
            f"This investigation traced funds through **{summary.get('nodes', 0)}** blockchain addresses,",
            f"analyzing **{summary.get('edges', 0)}** transactions.",
            ""
        ]
        
        if exchanges:
            lines.append("## Key Findings")
            lines.append("")
            lines.append(f"Funds were traced to **{len(exchanges)}** cryptocurrency exchanges:")
            for ex in exchanges[:5]:
                lines.append(f"- **{ex.get('label', 'Unknown').upper()}**: Received from {ex.get('sender_count', 0)} addresses")
            lines.append("")
            lines.append("These exchanges may have KYC records identifying the perpetrators.")
            lines.append("")
        
        if p2p:
            lines.append("## P2P Cash-out Operations")
            lines.append("")
            lines.append("Evidence of peer-to-peer cash-out operations was detected:")
            for pattern in p2p[:3]:
                lines.append(f"- Address `{pattern['address'][:16]}...` distributed to {pattern['unique_destinations']} recipients")
            lines.append("")
        
        return "\n".join(lines)
    
    def generate_technical_details(self) -> str:
        """Generate technical appendix with full transaction details."""
        timeline = self.analysis.get("timeline", [])
        value_patterns = self.analysis.get("value_patterns", [])
        
        lines = [
            "# Technical Analysis",
            "",
            "## Timeline of Events",
            ""
        ]
        
        for day in timeline[:10]:  # Last 10 days
            lines.append(f"### {day['date']}")
            lines.append(f"- Transactions: {day['tx_count']}")
            lines.append(f"- Total Value: {day['total_value']:.4f} ETH")
            lines.append(f"- Unique senders: {day['unique_senders']}, recipients: {day['unique_recipients']}")
            if day.get('notable_txs'):
                lines.append("- Notable transactions:")
                for tx in day['notable_txs']:
                    lines.append(f"  - `{tx['hash'][:16]}...`: {tx['value']:.4f} ETH ({tx['from']}... → {tx['to']}...)")
            lines.append("")
        
        if value_patterns:
            lines.append("## Value Patterns")
            lines.append("")
            lines.append("Repeated transaction values (suggests automated distribution):")
            lines.append("")
            for pattern in value_patterns[:10]:
                lines.append(f"- **{pattern['value']:.4f} ETH**: {pattern['count']} occurrences")
            lines.append("")
        
        return "\n".join(lines)
    
    def generate_evidence_chain(self) -> str:
        """Generate evidence chain for legal proceedings."""
        aggregators = self.analysis.get("aggregation_points", [])
        
        lines = [
            "# Evidence Chain",
            "",
            "## Methodology",
            "",
            "This analysis used the Etherscan API to trace on-chain transactions.",
            "All transaction hashes are verifiable on https://etherscan.io.",
            "",
            "## Key Evidence Points",
            ""
        ]
        
        # List exchanges with KYC potential
        exchanges = [a for a in aggregators if a.get("label")]
        if exchanges:
            lines.append("### Exchange Deposits (KYC Records Available)")
            lines.append("")
            for ex in exchanges:
                lines.append(f"#### {ex.get('label', 'Unknown').upper()}")
                lines.append(f"- Deposit Address: `{ex['address']}`")
                lines.append(f"- Total Received: {ex.get('total_received', 0):.4f} ETH")
                lines.append(f"- Number of Senders: {ex.get('sender_count', 0)}")
                if ex.get('senders'):
                    lines.append("- Source Addresses:")
                    for sender in ex['senders'][:10]:
                        lines.append(f"  - `{sender}`")
                lines.append("")
        
        return "\n".join(lines)
    
    def generate_recommendations(self) -> str:
        """Generate actionable recommendations."""
        aggregators = self.analysis.get("aggregation_points", [])
        exchanges = [a for a in aggregators if a.get("type") == "exchange" or a.get("label")]
        
        lines = [
            "# Recommendations",
            "",
            "## Immediate Actions",
            ""
        ]
        
        if exchanges:
            lines.append("1. **Submit KYC requests to exchanges:**")
            for i, ex in enumerate(exchanges[:5], 1):
                lines.append(f"   - {ex.get('label', 'Unknown').upper()}: Request account info for deposit address `{ex['address']}`")
            lines.append("")
        
        lines.extend([
            "2. **Preserve evidence:**",
            "   - Save all transaction hashes referenced in this report",
            "   - Request Etherscan's archive data for involved addresses",
            "",
            "3. **Legal coordination:**",
            "   - Work with law enforcement to submit formal requests to exchanges",
            "   - Exchanges typically respond to law enforcement within 30-60 days",
            "",
            "## Ongoing Monitoring",
            "",
            "- Set up alerts for outgoing transactions from identified addresses",
            "- Monitor exchange hot wallets for further deposits",
            "",
        ])
        
        return "\n".join(lines)
    
    def generate_full_report(self) -> str:
        """Generate complete investigation report."""
        sections = [
            self._generate_header(),
            self.generate_executive_summary(),
            self.generate_evidence_chain(),
            self.generate_technical_details(),
            self.generate_recommendations(),
            self._generate_footer()
        ]
        
        return "\n\n---\n\n".join(sections)
    
    def _generate_header(self) -> str:
        """Generate report header."""
        case_name = self.case_info.get("name", self.graph.case_name or "Investigation")
        generated = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        
        return f"""# {case_name}
## Blockchain Forensic Investigation Report

**Generated:** {generated}  
**Tool:** OpusTrace v1.0  
**Addresses Analyzed:** {len(self.graph.nodes)}  
**Transactions Traced:** {len(self.graph.edges)}
"""

    def _generate_footer(self) -> str:
        """Generate report footer."""
        return """# Appendix

## Disclaimer

This report presents blockchain transaction analysis based on publicly available on-chain data.
Attribution of addresses to specific individuals requires additional off-chain evidence such as
exchange KYC records, IP logs, or witness testimony.

## Contact

Report generated by OpusTrace - https://opustrace.com

For questions about this analysis or to request additional investigation, contact the case investigator.
"""


def generate_report(graph: Graph, analysis: Dict, case_info: Dict = None) -> str:
    """Convenience function for report generation."""
    generator = ReportGenerator(graph, analysis, case_info)
    return generator.generate_full_report()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python opustrace_report.py <graph.json> <analysis.json>")
        sys.exit(1)
    
    graph = Graph.load(sys.argv[1])
    with open(sys.argv[2], 'r') as f:
        analysis = json.load(f)
    
    report = generate_report(graph, analysis)
    print(report)
