#!/usr/bin/env python3
"""
OpusTrace Workers - Parallel address tracing.

Uses ThreadPoolExecutor for concurrent API calls.
Designed to be run by Haiku for cost efficiency.
"""

import os
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Set, Optional, Tuple
from dataclasses import dataclass

from opustrace_core import Graph, Node, Transaction, TransactionType, AddressType
from opustrace_api import EtherscanAPI, parse_etherscan_tx, classify_address, identify_exchange


@dataclass
class TraceConfig:
    """Configuration for tracing operations."""
    max_depth: int = 3  # How many hops to trace
    max_workers: int = 5  # Parallel threads (match rate limit)
    min_value_eth: float = 0.001  # Ignore dust
    min_value_usd: float = 10  # Ignore small amounts
    trace_erc20: bool = True
    trace_internal: bool = False  # Usually not needed
    save_progress: bool = True
    progress_file: str = "trace_progress.json"


class Tracer:
    """Multi-threaded address tracer."""
    
    def __init__(self, config: TraceConfig = None, api_key: str = None):
        self.config = config or TraceConfig()
        self.api = EtherscanAPI(api_key=api_key)
        self.graph = Graph()
        self.traced: Set[str] = set()
        self.to_trace: List[Tuple[str, int]] = []  # (address, depth)
        
    def trace_address(self, address: str) -> Dict:
        """
        Trace a single address. Returns summary dict.
        This is the unit of work that can be parallelized.
        """
        address = address.lower()
        
        # Get transactions
        normal_txs = self.api.get_normal_transactions(address)
        erc20_txs = self.api.get_erc20_transactions(address) if self.config.trace_erc20 else []
        
        # Parse and filter
        outflows = []
        inflows = []
        
        for tx in normal_txs:
            parsed = parse_etherscan_tx(tx, address)
            if parsed["value"] < self.config.min_value_eth:
                continue  # Skip dust
            if parsed["direction"] == "OUT":
                outflows.append(parsed)
            elif parsed["direction"] == "IN":
                inflows.append(parsed)
        
        # Handle ERC-20 stablecoins
        for tx in erc20_txs:
            parsed = parse_etherscan_tx(tx, address)
            if parsed["token"] in ("USDT", "USDC", "DAI"):
                if parsed["value"] < self.config.min_value_usd:
                    continue
                if parsed["direction"] == "OUT":
                    outflows.append(parsed)
                elif parsed["direction"] == "IN":
                    inflows.append(parsed)
        
        # Identify destinations
        destinations = {}
        for tx in outflows:
            dest = tx["to"]
            if dest not in destinations:
                destinations[dest] = {
                    "address": dest,
                    "total_eth": 0,
                    "total_usd": 0,
                    "tx_count": 0,
                    "txids": [],
                    "exchange": identify_exchange(dest)
                }
            destinations[dest]["tx_count"] += 1
            destinations[dest]["txids"].append(tx["hash"])
            if tx["token"] == "ETH":
                destinations[dest]["total_eth"] += tx["value"]
                destinations[dest]["total_usd"] += tx["value"] * 3500
            elif tx["token"] in ("USDT", "USDC", "DAI"):
                destinations[dest]["total_usd"] += tx["value"]
        
        return {
            "address": address,
            "outflow_count": len(outflows),
            "inflow_count": len(inflows),
            "total_out_eth": sum(t["value"] for t in outflows if t["token"] == "ETH"),
            "total_in_eth": sum(t["value"] for t in inflows if t["token"] == "ETH"),
            "destinations": list(destinations.values()),
            "traced_at": int(time.time())
        }
    
    def trace_multi(self, addresses: List[str], depth: int = 0) -> List[Dict]:
        """
        Trace multiple addresses in parallel.
        Returns list of trace results.
        """
        results = []
        
        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            future_to_addr = {
                executor.submit(self.trace_address, addr): addr 
                for addr in addresses
                if addr.lower() not in self.traced
            }
            
            for future in as_completed(future_to_addr):
                addr = future_to_addr[future]
                try:
                    result = future.result()
                    results.append(result)
                    self.traced.add(addr.lower())
                    
                    # Add destinations to trace queue
                    if depth < self.config.max_depth:
                        for dest in result["destinations"]:
                            if dest["address"].lower() not in self.traced:
                                if not dest["exchange"]:  # Don't trace into exchanges
                                    self.to_trace.append((dest["address"], depth + 1))
                    
                    print(f"[{len(self.traced)}] Traced {addr[:10]}... -> {len(result['destinations'])} destinations")
                    
                except Exception as e:
                    print(f"Error tracing {addr}: {e}")
                    results.append({
                        "address": addr,
                        "error": str(e),
                        "traced_at": int(time.time())
                    })
        
        return results
    
    def trace_full(self, starting_addresses: List[str]) -> Graph:
        """
        Full recursive trace from starting addresses.
        Returns populated Graph.
        """
        self.graph = Graph(case_name="trace", created_at=int(time.time()))
        
        # Initialize queue
        for addr in starting_addresses:
            self.to_trace.append((addr, 0))
        
        all_results = []
        
        while self.to_trace:
            # Get batch of addresses at same depth
            current_batch = []
            current_depth = self.to_trace[0][1]
            
            while self.to_trace and self.to_trace[0][1] == current_depth:
                addr, depth = self.to_trace.pop(0)
                if addr.lower() not in self.traced:
                    current_batch.append(addr)
            
            if not current_batch:
                continue
                
            print(f"\n=== Depth {current_depth}: Tracing {len(current_batch)} addresses ===")
            results = self.trace_multi(current_batch, current_depth)
            all_results.extend(results)
            
            # Save progress
            if self.config.save_progress:
                with open(self.config.progress_file, 'w') as f:
                    json.dump({
                        "traced": list(self.traced),
                        "pending": len(self.to_trace),
                        "results": all_results
                    }, f, indent=2)
        
        # Build graph from results
        for result in all_results:
            if "error" in result:
                continue
            
            src_addr = result["address"]
            self.graph.add_node(src_addr)
            
            for dest in result.get("destinations", []):
                dest_addr = dest["address"]
                
                # Set node type if exchange
                if dest["exchange"]:
                    self.graph.add_node(dest_addr, 
                                       addr_type=AddressType.EXCHANGE,
                                       label=dest["exchange"])
                else:
                    self.graph.add_node(dest_addr)
                
                # Add edges (simplified - one edge per destination)
                for txid in dest["txids"]:
                    tx = Transaction(
                        hash=txid,
                        block=0,  # Would need another API call
                        timestamp=0,
                        from_addr=src_addr,
                        to_addr=dest_addr,
                        value=dest["total_eth"] / len(dest["txids"])
                    )
                    self.graph.add_edge(tx)
        
        return self.graph


def trace_from_addresses(addresses: List[str], config: TraceConfig = None, 
                        api_key: str = None) -> Graph:
    """
    Convenience function for tracing from multiple starting addresses.
    """
    tracer = Tracer(config=config, api_key=api_key)
    return tracer.trace_full(addresses)


def trace_single_address(address: str, api_key: str = None) -> Dict:
    """
    Trace a single address (no recursion).
    Returns raw trace data.
    """
    tracer = Tracer(api_key=api_key)
    return tracer.trace_address(address)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python opustrace_workers.py <address> [depth]")
        sys.exit(1)
    
    addr = sys.argv[1]
    depth = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    
    config = TraceConfig(max_depth=depth)
    tracer = Tracer(config=config)
    result = tracer.trace_address(addr)
    
    print(json.dumps(result, indent=2))
