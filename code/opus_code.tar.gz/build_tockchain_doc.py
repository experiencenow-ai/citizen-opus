#!/usr/bin/env python3
"""
Build a comprehensive Tockchain/Valis documentation file.
Combines all DOC_*.md files into a single organized document.
"""

import os
import glob
from datetime import datetime

# Define the logical organization of documentation
SECTIONS = {
    "1. Core System": {
        "description": "Fundamental types, constants, and core blockchain infrastructure",
        "files": [
            "DOC__valis_h.md",
            "DOC__valis_h_full.md", 
            "DOC_valis_h.md",
            "DOC_valis_config.md",
            "DOC_valis_files.md",
            "DOC_valis_hash.md",
            "DOC_valis_keys.md",
            "DOC_valis_math.md",
            "DOC_valis_shared.md",
            "DOC_valis_messaging.md",
            "DOC_valis_net_MT.md",
        ]
    },
    "2. Consensus & Validation": {
        "description": "Block validation, voting, and network consensus",
        "files": [
            "DOC_validator.md",
            "DOC_validator_h.md",
            "DOC_gen3.md",
            "DOC_gen3_h.md",
            "DOC_gen3_chain.md",
            "DOC_gen3_vote.md",
            "DOC_gen3_net.md",
            "DOC_gen3_nodechange.md",
            "DOC_gen3_metrics.md",
            "DOC_gen3_ssd.md",
            "DOC_gen3_utils.md",
            "DOC_gen3_vans.md",
            "DOC_gen3_needbits.md",
            "DOC_gen3_rawtock.md",
        ]
    },
    "3. Ethereum Bridge": {
        "description": "Cross-chain bridge for Ethereum deposits and withdrawals",
        "files": [
            "DOC_bridge_h.md",
            "DOC_bridge_c.md",
            "DOC_bridge_deposit.md",
            "DOC_bridge_withdraw.md",
            "DOC_bridge_abi.md",
            "DOC_bridge_rlp.md",
            "DOC_bridge_mpt.md",
            "DOC_bridge_mptjson.md",
            "DOC_bridge_rpc.md",
            "DOC_bridge_rpc_h.md",
            "DOC_bridge_prices.md",
            "DOC_bridge_utils.md",
            "DOC_bridge_vsm_ref.md",
            "DOC_ethrpc.md",
        ]
    },
    "4. Threshold Signature Scheme (TSS)": {
        "description": "Distributed key generation and signing for validator consensus",
        "files": [
            "DOC_tss_overview.md",
            "DOC_tss_module.md",
            "DOC_tss_keygen.md",
            "DOC_tss_sig.md",
            "DOC_valis_tss.md",
        ]
    },
    "5. Ledger & Assets": {
        "description": "Account state, asset management, and trading",
        "files": [
            "DOC_ledger_h.md",
            "DOC_ledger_assets.md",
            "DOC_ledger_atomic.md",
            "DOC_ledger_erc20.md",
            "DOC_ledger_hourly.md",
            "DOC_ledger_pylon7.md",
            "DOC_ledger_vhandlers.md",
            "DOC_ledger_vtrade.md",
        ]
    },
    "6. Unified Finance Core (UFC)": {
        "description": "DEX, orderbook, AMM pools, and swap execution",
        "files": [
            "DOC_ufc_h.md",
            "DOC_ufc_c.md",
            "DOC_ufc_orderbook.md",
            "DOC_ufc_pool.md",
            "DOC_ufc_swap.md",
            "DOC_ufc_oob.md",
            "DOC_ufc_planner.md",
            "DOC_ufc_scan.md",
            "DOC_ufc_utils.md",
        ]
    },
    "7. DeFi Protocols": {
        "description": "Lending, market making, and perpetual contracts",
        "files": [
            "DOC_LOAN.md",
            "DOC_MM.md",
            "DOC_PERP.md",
            "DOC_pylon_spec.md",
        ]
    },
    "8. Dataflow Engine": {
        "description": "Reactive computation and incremental state updates",
        "files": [
            "DOC_dataflow.md",
            "DOC_dataflow_h.md",
            "DOC_dataflow_inc_h.md",
            "DOC_dataflow_api.md",
            "DOC_dataflow_batch.md",
            "DOC_dataflow_cache.md",
            "DOC_dataflow_frontier.md",
            "DOC_dataflow_trigger.md",
            "DOC_df_developer_guide.md",
            "DOC_df_gas.md",
            "DOC_df_sdk.md",
        ]
    },
    "9. Virtual Machine & Smart Contracts": {
        "description": "eBPF-based VM and verified execution",
        "files": [
            "DOC_vbpf.md",
            "DOC_ebpf_ubpf.md",
            "DOC_valis_herongen.md",
            "DOC_valis_heronverify.md",
        ]
    },
    "10. Formal Verification": {
        "description": "Coq proofs and Frama-C verified code",
        "files": [
            "DOC_coq_proofs.md",
            "DOC_frama_verified.md",
            "DOC_frama_verified_h.md",
        ]
    },
    "11. Infrastructure": {
        "description": "Build system, networking, JSON handling, and utilities",
        "files": [
            "DOC_build_system.md",
            "DOC_json.md",
            "DOC_nng_shim.md",
            "DOC_websocketd.md",
            "DOC_websockets_h.md",
            "DOC_cryptolibs.md",
            "DOC_test_suite.md",
        ]
    }
}

def read_file_safe(filepath):
    """Read file with error handling."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f"<!-- Error reading {filepath}: {e} -->\n"

def build_toc(sections):
    """Build table of contents."""
    toc = ["# Table of Contents\n"]
    for section_name, section_data in sections.items():
        # Create anchor from section name
        anchor = section_name.lower().replace(" ", "-").replace(".", "").replace("(", "").replace(")", "").replace("&", "and")
        toc.append(f"- [{section_name}](#{anchor})")
        toc.append(f"  - *{section_data['description']}*")
        for f in section_data['files']:
            if os.path.exists(f):
                # Get title from file
                content = read_file_safe(f)
                first_line = content.split('\n')[0] if content else f
                title = first_line.replace('#', '').strip() if first_line.startswith('#') else f
                file_anchor = f.replace('.md', '').replace('_', '-').lower()
                toc.append(f"    - [{title}](#{file_anchor})")
    return '\n'.join(toc)

def main():
    output = []
    
    # Title page
    output.append("""# Tockchain/Valis Technical Documentation

**Complete System Reference**

Generated: """ + datetime.now().strftime("%Y-%m-%d %H:%M UTC") + """

---

## About This Document

This document contains the complete technical documentation for Tockchain/Valis, a formally verified blockchain with:

- **Threshold Signature Scheme (TSS)** for distributed validator consensus
- **Ethereum Bridge** for cross-chain asset transfers
- **Unified Finance Core (UFC)** for DEX, orderbook, and AMM functionality
- **Dataflow Engine** for reactive computation
- **eBPF Virtual Machine** for smart contract execution
- **Formal Verification** using Coq proofs and Frama-C

The system is designed for:
1. High throughput (~800,000 tx/sec theoretical)
2. Formal correctness guarantees
3. Ethereum compatibility
4. Decentralized finance primitives

---

""")
    
    # Table of Contents
    output.append(build_toc(SECTIONS))
    output.append("\n\n---\n\n")
    
    # Track files we've included
    included_files = set()
    
    # Process each section
    for section_name, section_data in SECTIONS.items():
        output.append(f"# {section_name}\n")
        output.append(f"*{section_data['description']}*\n\n")
        output.append("---\n\n")
        
        for filepath in section_data['files']:
            if os.path.exists(filepath):
                included_files.add(filepath)
                content = read_file_safe(filepath)
                # Add file anchor
                file_anchor = filepath.replace('.md', '').replace('_', '-').lower()
                output.append(f'<a name="{file_anchor}"></a>\n\n')
                output.append(content)
                output.append("\n\n---\n\n")
            else:
                output.append(f"<!-- File not found: {filepath} -->\n\n")
    
    # Check for any files not included
    all_docs = set(glob.glob("DOC_*.md"))
    missing = all_docs - included_files
    if missing:
        output.append("# Appendix: Additional Documentation\n\n")
        output.append("*Files not categorized in main sections*\n\n---\n\n")
        for filepath in sorted(missing):
            content = read_file_safe(filepath)
            output.append(content)
            output.append("\n\n---\n\n")
    
    # Write output
    final_doc = '\n'.join(output)
    output_file = "TOCKCHAIN_COMPLETE_DOCUMENTATION.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(final_doc)
    
    # Stats
    print(f"Generated: {output_file}")
    print(f"Total size: {len(final_doc):,} bytes")
    print(f"Files included: {len(included_files)}")
    if missing:
        print(f"Additional files in appendix: {len(missing)}")
        for m in sorted(missing):
            print(f"  - {m}")

if __name__ == "__main__":
    main()
