#!/usr/bin/env python3
"""
Email Cleanup Script for OpusTrace
Moves automated emails to Automated folder to reduce INBOX load time.

Run with: python3 email_cleanup.py
Takes ~5 minutes due to Gmail throttling (~10s per operation)
"""
import imaplib
import socket
import time

socket.setdefaulttimeout(60)

CREDS = {
    "email": "opustrace@gmail.com",
    "password": "ohmpvyuqbaivvdwr"
}

AUTOMATED_PATTERNS = [
    'google.com', 'godaddy.com', 'twitter.com', 'x.com', 
    'paywithmoon.com', 'noreply', 'no-reply', 'mailer-daemon',
    'postmaster', 'notification', 'alert', 'accounts.google',
    'security-noreply', 'calendar-notification', 'etherscan',
    'anthropic', 'claude', 'moonshot', 'kimi.ai'
]

def main():
    start = time.time()
    
    print("Connecting to Gmail IMAP...")
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login(CREDS['email'], CREDS['password'])
    mail.select('INBOX')
    
    # Get all message IDs
    status, messages = mail.search(None, 'ALL')
    msg_ids = messages[0].split()
    print(f"Found {len(msg_ids)} emails in INBOX")
    
    if not msg_ids:
        print("Inbox is empty!")
        mail.logout()
        return
    
    # Batch fetch all headers
    print("Fetching headers (batch)...")
    id_range = f'1:{len(msg_ids)}'
    status, data = mail.fetch(id_range, '(BODY[HEADER.FIELDS (FROM)])')
    
    # Find automated emails
    automated = []
    for i in range(0, len(data), 2):
        if data[i] == b')':
            continue
        try:
            msg_info = data[i][0].decode()
            msg_id = msg_info.split()[0]
            header = data[i][1].decode('utf-8', errors='replace').lower()
            
            if any(p in header for p in AUTOMATED_PATTERNS):
                automated.append(msg_id)
        except Exception as e:
            pass
    
    print(f"Found {len(automated)} automated emails to move")
    
    if not automated:
        print("No automated emails to move!")
        mail.logout()
        return
    
    # Move them one by one (throttled)
    moved = 0
    for i, msg_id in enumerate(automated):
        print(f"[{i+1}/{len(automated)}] Moving {msg_id}...", end=' ', flush=True)
        try:
            status, response = mail.copy(msg_id, 'Automated')
            if status == 'OK':
                mail.store(msg_id, '+FLAGS', '\\Deleted')
                moved += 1
                print("OK")
            else:
                print(f"FAILED: {response}")
        except Exception as e:
            print(f"ERROR: {e}")
    
    # Expunge deleted messages
    print("Expunging deleted messages...")
    mail.expunge()
    
    # Check remaining
    status, messages = mail.search(None, 'ALL')
    remaining = len(messages[0].split()) if messages[0] else 0
    
    elapsed = time.time() - start
    print(f"\n=== COMPLETE ===")
    print(f"Moved: {moved} emails to Automated")
    print(f"Remaining in INBOX: {remaining}")
    print(f"Time: {elapsed:.1f}s ({elapsed/60:.1f} minutes)")
    
    mail.logout()

if __name__ == '__main__':
    main()
