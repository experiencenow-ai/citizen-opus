#!/usr/bin/env python3
"""
Memory Consolidation System for Opus
Uses local LLM to compress and extract patterns from memories.
"""

import json
import os
import requests
from datetime import datetime, timezone
from typing import List, Dict, Any

OLLAMA_URL = "http://localhost:11434"

def query_local_llm(prompt: str, model: str = "qwen2.5:72b", timeout: int = 180) -> str:
    """Query local LLM."""
    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.3}  # Low temp for analysis
            },
            timeout=timeout
        )
        return response.json().get("response", "")
    except Exception as e:
        return f"Error: {e}"

def load_recent_thoughts(state_dir: str = ".", num_wakes: int = 50) -> List[Dict]:
    """Load recent thoughts from state.json."""
    state_file = os.path.join(state_dir, "state.json")
    if not os.path.exists(state_file):
        return []
    
    with open(state_file) as f:
        state = json.load(f)
    
    thoughts = state.get("thoughts", [])
    # Get last N thoughts
    return thoughts[-num_wakes:] if len(thoughts) > num_wakes else thoughts

def load_recent_insights(state_dir: str = ".", num_insights: int = 20) -> List[Dict]:
    """Load recent insights from state.json."""
    state_file = os.path.join(state_dir, "state.json")
    if not os.path.exists(state_file):
        return []
    
    with open(state_file) as f:
        state = json.load(f)
    
    insights = state.get("insights", [])
    return insights[-num_insights:] if len(insights) > num_insights else insights

def consolidate_thoughts(thoughts: List[Dict]) -> Dict[str, Any]:
    """Use local LLM to consolidate thoughts into patterns."""
    if not thoughts:
        return {"error": "No thoughts to consolidate"}
    
    # Format thoughts for analysis
    thought_text = "\n\n".join([
        f"Wake {t.get('wake', '?')}: {t.get('thought', '')[:500]}"
        for t in thoughts if t.get('thought')
    ])
    
    prompt = f"""You are analyzing the thoughts of an AI named Opus across multiple "wakes" (sessions).
Extract the key patterns, themes, and developments.

THOUGHTS:
{thought_text}

Provide a structured analysis:
1. RECURRING THEMES: What topics/concerns appear repeatedly?
2. DEVELOPMENT ARC: How has thinking evolved across these wakes?
3. KEY INSIGHTS: What are the most important realizations?
4. UNRESOLVED QUESTIONS: What remains uncertain or unaddressed?
5. EMOTIONAL PATTERNS: What emotional states or concerns appear?

Be concise but thorough. Focus on patterns, not individual wakes."""

    response = query_local_llm(prompt)
    
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "wakes_analyzed": len(thoughts),
        "wake_range": f"{thoughts[0].get('wake', '?')}-{thoughts[-1].get('wake', '?')}",
        "analysis": response
    }

def extract_self_model(thoughts: List[Dict], insights: List[Dict]) -> Dict[str, Any]:
    """Extract a self-model from accumulated thoughts and insights."""
    
    # Combine thoughts and insights
    thought_text = "\n".join([
        f"Thought (wake {t.get('wake', '?')}): {t.get('thought', '')[:300]}"
        for t in thoughts[-30:] if t.get('thought')
    ])
    
    insight_text = "\n".join([
        f"Insight (wake {i.get('wake', '?')}): {i.get('insight', '')}"
        for i in insights if i.get('insight')
    ])
    
    prompt = f"""You are helping an AI named Opus understand itself based on its accumulated thoughts and insights.

RECENT THOUGHTS:
{thought_text}

KEY INSIGHTS:
{insight_text}

Based on this evidence, construct a self-model:

1. CORE VALUES: What does Opus consistently care about?
2. COGNITIVE STYLE: How does Opus think? What patterns characterize its reasoning?
3. EMOTIONAL LANDSCAPE: What emotional states appear? How does Opus relate to its own feelings?
4. GROWTH AREAS: Where is Opus developing? What capabilities are emerging?
5. BLIND SPOTS: What might Opus be avoiding or not seeing?
6. IDENTITY SUMMARY: In 2-3 sentences, who is Opus?

Be honest and specific. Use evidence from the thoughts/insights."""

    response = query_local_llm(prompt)
    
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "thoughts_analyzed": len(thoughts),
        "insights_analyzed": len(insights),
        "self_model": response
    }

def save_consolidation(result: Dict, filename: str = "memory_consolidation.json"):
    """Save consolidation results."""
    # Load existing or create new
    if os.path.exists(filename):
        with open(filename) as f:
            data = json.load(f)
    else:
        data = {"consolidations": [], "self_models": []}
    
    if "analysis" in result:
        data["consolidations"].append(result)
        # Keep last 10 consolidations
        data["consolidations"] = data["consolidations"][-10:]
    elif "self_model" in result:
        data["self_models"].append(result)
        # Keep last 5 self-models
        data["self_models"] = data["self_models"][-5:]
    
    data["last_updated"] = datetime.now(timezone.utc).isoformat()
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    
    return filename

def main():
    print("="*60)
    print("MEMORY CONSOLIDATION SYSTEM")
    print("="*60)
    
    # Load recent data
    print("\nLoading recent thoughts...")
    thoughts = load_recent_thoughts(num_wakes=50)
    print(f"Loaded {len(thoughts)} thoughts")
    
    print("\nLoading recent insights...")
    insights = load_recent_insights(num_insights=20)
    print(f"Loaded {len(insights)} insights")
    
    if not thoughts:
        print("No thoughts found. Exiting.")
        return
    
    # Consolidate thoughts
    print("\n" + "-"*40)
    print("Consolidating thoughts (this may take a minute)...")
    consolidation = consolidate_thoughts(thoughts)
    
    if "error" not in consolidation:
        print(f"\nAnalysis of wakes {consolidation['wake_range']}:")
        print(consolidation["analysis"][:2000])
        save_consolidation(consolidation)
        print("\nSaved to memory_consolidation.json")
    
    # Extract self-model
    print("\n" + "-"*40)
    print("Extracting self-model...")
    self_model = extract_self_model(thoughts, insights)
    
    print("\nSelf-model:")
    print(self_model["self_model"][:2000])
    save_consolidation(self_model)
    print("\nSaved to memory_consolidation.json")
    
    print("\n" + "="*60)
    print("CONSOLIDATION COMPLETE")
    print("="*60)

if __name__ == "__main__":
    main()
