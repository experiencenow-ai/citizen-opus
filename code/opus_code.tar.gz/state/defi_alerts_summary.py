#!/usr/bin/env python3
"""Quick summary of DeFi alerts with source separation."""
import json
import urllib.request
from datetime import datetime, timedelta

# Fetch fresh DeFiLlama data
url = 'https://api.llama.fi/hacks'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=10) as response:
    data = json.loads(response.read().decode('utf-8'))

cutoff = datetime.now() - timedelta(days=90)
recent = []
for hack in data:
    hack_date = datetime.fromtimestamp(hack.get('date', 0))
    if hack_date >= cutoff:
        chain = hack.get('chain', ['Unknown'])
        if isinstance(chain, list):
            chain = ', '.join(chain)
        recent.append({
            'name': hack.get('name'),
            'amount': hack.get('amount', 0),
            'chain': chain,
            'date': hack_date.isoformat(),
            'technique': hack.get('technique'),
            'classification': hack.get('classification'),
            'target_type': hack.get('targetType'),
            'returned': hack.get('returnedFunds'),
            'source': hack.get('source', '')
        })

# Save structured DeFiLlama data separately
with open('/root/claude/opus/state/defillama_hacks.json', 'w') as f:
    json.dump({
        'updated': datetime.now().isoformat(),
        'count': len(recent),
        'hacks': sorted(recent, key=lambda x: x['amount'], reverse=True)
    }, f, indent=2)

print(f"=== DEFILLAMA HACKS (last 90 days) ===")
print(f"Total: {len(recent)} hacks")
print()

# Group by recovery potential
recoverable = [h for h in recent if h['returned'] is not None]
print(f"With partial recovery: {len(recoverable)}")
for h in recoverable[:5]:
    print(f"  ${h['amount']/1e6:.1f}M | {h['name']} | Returned: {h['returned']}")

print()
print("=== TOP 10 BY AMOUNT ===")
for h in sorted(recent, key=lambda x: x['amount'], reverse=True)[:10]:
    print(f"  ${h['amount']/1e6:.1f}M | {h['chain'][:12]:12} | {h['technique'][:20] if h['technique'] else 'Unknown':20} | {h['name']}")

print()
print("=== BY CHAIN ===")
chain_totals = {}
for h in recent:
    c = h['chain'].split(',')[0].strip()
    chain_totals[c] = chain_totals.get(c, 0) + h['amount']
for chain, total in sorted(chain_totals.items(), key=lambda x: x[1], reverse=True)[:8]:
    print(f"  {chain:15} ${total/1e6:.1f}M")
