import hashlib
import hmac
import base64
import urllib.parse
import time
import random
import string
import json
import subprocess

# Credentials
API_KEY = "YQrmmuTBl7CXMO91uak6vimgT"
API_KEY_SECRET = "Tw5tQN6BzzH4MXsc2WGuBoL4qlseIu7AzyLyRjPTaPFzHAdYjf"
ACCESS_TOKEN = "2010215793733292032-FeYDcqL8z4ARKJBvamXsACMaiUQ4kW"
ACCESS_TOKEN_SECRET = "gGpYGUugrM7X6BZqakFkIMFEYfNFSIng4cIhxWRsnGvtY"

def generate_nonce(length=32):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def create_signature(method, url, params, consumer_secret, token_secret):
    sorted_params = sorted(params.items())
    param_parts = []
    for k, v in sorted_params:
        param_parts.append(urllib.parse.quote(str(k), safe='') + '=' + urllib.parse.quote(str(v), safe=''))
    param_string = '&'.join(param_parts)
    
    base_string = method + '&' + urllib.parse.quote(url, safe='') + '&' + urllib.parse.quote(param_string, safe='')
    signing_key = urllib.parse.quote(consumer_secret, safe='') + '&' + urllib.parse.quote(token_secret, safe='')
    
    signature = hmac.new(
        signing_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha1
    )
    return base64.b64encode(signature.digest()).decode('utf-8')

def create_oauth_header(method, url):
    oauth_params = {
        'oauth_consumer_key': API_KEY,
        'oauth_nonce': generate_nonce(),
        'oauth_signature_method': 'HMAC-SHA1',
        'oauth_timestamp': str(int(time.time())),
        'oauth_token': ACCESS_TOKEN,
        'oauth_version': '1.0'
    }
    
    signature = create_signature(method, url, oauth_params, API_KEY_SECRET, ACCESS_TOKEN_SECRET)
    oauth_params['oauth_signature'] = signature
    
    header_parts = []
    for k, v in sorted(oauth_params.items()):
        header_parts.append(urllib.parse.quote(k, safe='') + '="' + urllib.parse.quote(v, safe='') + '"')
    return 'OAuth ' + ', '.join(header_parts)

def post_tweet(text):
    url = "https://api.twitter.com/2/tweets"
    oauth_header = create_oauth_header("POST", url)
    
    cmd = [
        'curl', '-s', '-X', 'POST', url,
        '-H', 'Authorization: ' + oauth_header,
        '-H', 'Content-Type: application/json',
        '-d', json.dumps({"text": text})
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout) if result.stdout else None

def get_my_tweets():
    # Get user ID first, then tweets
    url = "https://api.twitter.com/2/users/me"
    oauth_header = create_oauth_header("GET", url)
    
    cmd = ['curl', '-s', url, '-H', 'Authorization: ' + oauth_header]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        tweet = ' '.join(sys.argv[1:])
        result = post_tweet(tweet)
        print(json.dumps(result, indent=2))
    else:
        print(get_my_tweets())
