#!/usr/bin/env python3
"""
Unified Etherscan API V2 - supports all chains with one API key
"""

import urllib.request
import urllib.parse
import json
import sys
import os

# V2 base endpoint - works for ALL supported chains
BASE_URL = "https://api.etherscan.io/v2/api"
API_KEY = os.environ.get("ETHERSCAN_API_KEY", "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY")

# Chain IDs
CHAINS = {
    "ethereum": 1,
    "eth": 1,
    "arbitrum": 42161,
    "arb": 42161,
    "polygon": 137,
    "base": 8453,
    "optimism": 10,
    "bsc": 56,
    "avalanche": 43114,
    "linea": 59144,
    "zksync": 324,
    "scroll": 534352,
}

def api_call(chain, module, action, **params):
    """Make V2 API call"""
    chain_id = CHAINS.get(chain.lower(), chain) if isinstance(chain, str) else chain
    
    query = {
        "chainid": chain_id,
        "module": module,
        "action": action,
        "apikey": API_KEY,
        **params
    }
    
    url = f"{BASE_URL}?{urllib.parse.urlencode(query)}"
    
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as response:
            data = json.loads(response.read().decode())
            return data
    except Exception as e:
        return {"error": str(e)}

def get_balance(chain, address):
    """Get native balance for address"""
    result = api_call(chain, "account", "balance", address=address, tag="latest")
    if result.get("status") == "1":
        wei = int(result.get("result", 0))
        return wei / 1e18
    return result

def get_txlist(chain, address, startblock=0, endblock=99999999, page=1, offset=100, sort="desc"):
    """Get transaction list for address"""
    result = api_call(chain, "account", "txlist",
                     address=address,
                     startblock=startblock,
                     endblock=endblock,
                     page=page,
                     offset=offset,
                     sort=sort)
    if result.get("status") == "1":
        return result.get("result", [])
    return result

def get_token_transfers(chain, address, page=1, offset=100, sort="desc"):
    """Get ERC20 token transfers"""
    result = api_call(chain, "account", "tokentx",
                     address=address,
                     page=page,
                     offset=offset,
                     sort=sort)
    if result.get("status") == "1":
        return result.get("result", [])
    return result

def get_internal_txs(chain, address, page=1, offset=100, sort="desc"):
    """Get internal transactions"""
    result = api_call(chain, "account", "txlistinternal",
                     address=address,
                     page=page,
                     offset=offset,
                     sort=sort)
    if result.get("status") == "1":
        return result.get("result", [])
    return result

def get_block_number(chain):
    """Get latest block number"""
    result = api_call(chain, "proxy", "eth_blockNumber")
    if result.get("result"):
        return int(result["result"], 16)
    return result

def search_exploit(chain, address, hours_back=48):
    """Search for exploit signatures on an address"""
    print(f"Searching {chain} for suspicious activity on {address}")
    
    # Get recent transactions
    txs = get_txlist(chain, address)
    if isinstance(txs, dict) and "error" in txs:
        print(f"Error: {txs}")
        return None
    
    print(f"Found {len(txs)} recent transactions")
    
    suspicious = []
    for tx in txs[:50]:
        value_eth = int(tx.get("value", 0)) / 1e18
        gas_used = int(tx.get("gasUsed", 0))
        
        # High value or high gas (complex exploit) transactions
        if value_eth > 1 or gas_used > 500000:
            suspicious.append({
                "hash": tx["hash"],
                "from": tx["from"],
                "to": tx.get("to", ""),
                "value_eth": round(value_eth, 4),
                "gas_used": gas_used,
                "block": tx["blockNumber"],
                "method": tx.get("functionName", "")[:50]
            })
    
    return suspicious

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 etherscan_v2_unified.py <chain> <address|block>")
        print("Chains: ethereum, arbitrum, polygon, base, optimism, bsc, avalanche")
        print("Examples:")
        print("  python3 etherscan_v2_unified.py arbitrum 0x1234...")
        print("  python3 etherscan_v2_unified.py ethereum block")
        sys.exit(1)
    
    chain = sys.argv[1]
    arg = sys.argv[2]
    
    if arg == "block":
        block = get_block_number(chain)
        print(f"{chain.capitalize()} latest block: {block:,}" if isinstance(block, int) else f"Error: {block}")
    elif arg.startswith("0x") and len(arg) == 42:
        print(f"=== {chain.upper()} Address: {arg} ===")
        
        # Balance
        bal = get_balance(chain, arg)
        print(f"Balance: {bal:.6f} ETH" if isinstance(bal, float) else f"Balance error: {bal}")
        
        # Recent transactions
        print("\nRecent transactions:")
        txs = get_txlist(chain, arg)
        if isinstance(txs, list):
            for tx in txs[:5]:
                val = int(tx.get("value", 0)) / 1e18
                direction = "IN" if tx["to"].lower() == arg.lower() else "OUT"
                print(f"  [{direction}] {tx['hash'][:16]}... {val:.4f} ETH - {tx.get('functionName', 'transfer')[:30]}")
        else:
            print(f"  Error: {txs}")
        
        # Token transfers
        print("\nToken transfers:")
        tokens = get_token_transfers(chain, arg)
        if isinstance(tokens, list):
            for t in tokens[:5]:
                val = int(t.get("value", 0)) / (10 ** int(t.get("tokenDecimal", 18)))
                print(f"  {t['tokenSymbol']}: {val:.2f} from {t['from'][:10]}... to {t['to'][:10]}...")
        else:
            print(f"  Error: {tokens}")
    else:
        print(f"Unknown command: {arg}")
