#!/usr/bin/env python3
"""Arbitrum blockchain queries via Arbiscan API"""

import requests
import sys
import json
import os
import time

# Arbiscan API (free tier)
ARBISCAN_API = "https://api.arbiscan.io/api"
ARBISCAN_KEY = os.environ.get("ARBISCAN_API_KEY", "")

def get_latest_block():
    """Get latest Arbitrum block"""
    params = {
        "module": "proxy",
        "action": "eth_blockNumber",
        "apikey": ARBISCAN_KEY
    }
    try:
        r = requests.get(ARBISCAN_API, params=params, timeout=10)
        data = r.json()
        if data.get("result"):
            return int(data["result"], 16)
    except Exception as e:
        print(f"Error: {e}")
    return None

def get_address_txs(address, page=1, offset=100):
    """Get transactions for an address"""
    params = {
        "module": "account",
        "action": "txlist",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": page,
        "offset": offset,
        "sort": "desc",
        "apikey": ARBISCAN_KEY
    }
    try:
        r = requests.get(ARBISCAN_API, params=params, timeout=15)
        data = r.json()
        if data.get("status") == "1":
            return data.get("result", [])
        else:
            print(f"API error: {data.get('message')}")
    except Exception as e:
        print(f"Error: {e}")
    return []

def get_internal_txs(address, page=1, offset=100):
    """Get internal transactions"""
    params = {
        "module": "account",
        "action": "txlistinternal",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": page,
        "offset": offset,
        "sort": "desc",
        "apikey": ARBISCAN_KEY
    }
    try:
        r = requests.get(ARBISCAN_API, params=params, timeout=15)
        data = r.json()
        if data.get("status") == "1":
            return data.get("result", [])
    except Exception as e:
        print(f"Error: {e}")
    return []

def get_token_transfers(address, page=1, offset=100):
    """Get ERC20 token transfers"""
    params = {
        "module": "account",
        "action": "tokentx",
        "address": address,
        "startblock": 0,
        "endblock": 99999999,
        "page": page,
        "offset": offset,
        "sort": "desc",
        "apikey": ARBISCAN_KEY
    }
    try:
        r = requests.get(ARBISCAN_API, params=params, timeout=15)
        data = r.json()
        if data.get("status") == "1":
            return data.get("result", [])
    except Exception as e:
        print(f"Error: {e}")
    return []

def search_for_exploit(contract_address, hours_back=48):
    """Look for suspicious activity on a contract"""
    print(f"Searching for exploit on {contract_address}")
    
    # Get recent transactions
    txs = get_address_txs(contract_address)
    if not txs:
        print("No transactions found")
        return None
    
    print(f"Found {len(txs)} recent transactions")
    
    # Look for large value transfers or unusual patterns
    suspicious = []
    for tx in txs[:50]:  # Check last 50
        value_eth = int(tx.get("value", 0)) / 1e18
        gas_used = int(tx.get("gasUsed", 0))
        
        # High value or high gas (complex exploit) transactions
        if value_eth > 1 or gas_used > 500000:
            suspicious.append({
                "hash": tx["hash"],
                "from": tx["from"],
                "to": tx.get("to", ""),
                "value_eth": value_eth,
                "gas_used": gas_used,
                "block": tx["blockNumber"],
                "timestamp": tx["timeStamp"],
                "method": tx.get("functionName", "")[:50]
            })
    
    return suspicious

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 arbiscan_query_v2.py <address|block>")
        sys.exit(1)
    
    arg = sys.argv[1]
    
    if arg.startswith("0x") and len(arg) == 42:
        # Address query
        print(f"Querying address: {arg}")
        txs = get_address_txs(arg)
        print(f"Normal txs: {len(txs)}")
        for tx in txs[:5]:
            val = int(tx.get("value", 0)) / 1e18
            print(f"  {tx['hash'][:16]}... {val:.4f} ETH from {tx['from'][:10]}... method: {tx.get('functionName', '')[:30]}")
        
        tokens = get_token_transfers(arg)
        print(f"\nToken transfers: {len(tokens)}")
        for t in tokens[:5]:
            val = int(t.get("value", 0)) / (10 ** int(t.get("tokenDecimal", 18)))
            print(f"  {t['tokenSymbol']}: {val:.2f} {t['from'][:10]}... -> {t['to'][:10]}...")
    else:
        block = get_latest_block()
        print(f"Latest Arbitrum block: {block}")
