#!/usr/bin/env python3
"""
Monitor Futureswap attacker address for any movement
Alert if funds move toward Tornado Cash or other mixers
"""
import subprocess
import json
import sys

ATTACKER = "0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95"
TORNADO_ROUTER = "0xd90e2f925DA726b50C4Ed8D0Fb90Ad053324F31b"
TORNADO_100 = "0xA160cdAB225685dA1d56aa342Ad8841c3b53f291"

def get_balance(address, rpc_url):
    """Get ETH balance from RPC"""
    cmd = f'''curl -s -X POST {rpc_url} \
        -H "Content-Type: application/json" \
        -d '{{"jsonrpc":"2.0","method":"eth_getBalance","params":["{address}","latest"],"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        return int(data['result'], 16) / 1e18
    except:
        return None

def get_tx_count(address, rpc_url):
    """Get transaction count from RPC"""
    cmd = f'''curl -s -X POST {rpc_url} \
        -H "Content-Type: application/json" \
        -d '{{"jsonrpc":"2.0","method":"eth_getTransactionCount","params":["{address}","latest"],"id":1}}' '''
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        return int(data['result'], 16)
    except:
        return None

def main():
    eth_rpc = "https://eth.llamarpc.com"
    arb_rpc = "https://arb1.arbitrum.io/rpc"
    
    eth_balance = get_balance(ATTACKER, eth_rpc)
    arb_balance = get_balance(ATTACKER, arb_rpc)
    eth_tx = get_tx_count(ATTACKER, eth_rpc)
    arb_tx = get_tx_count(ATTACKER, arb_rpc)
    
    print(f"Futureswap Attacker: {ATTACKER}")
    print(f"  Ethereum: {eth_balance:.4f} ETH, {eth_tx} txs")
    print(f"  Arbitrum: {arb_balance:.4f} ETH, {arb_tx} txs")
    
    # Alert thresholds
    # If ETH balance drops significantly, funds are moving
    EXPECTED_ETH = 95.78
    if eth_balance and eth_balance < EXPECTED_ETH - 1:
        print(f"  ⚠️ ALERT: ETH balance dropped from {EXPECTED_ETH} to {eth_balance:.4f}!")
        print(f"  ⚠️ Funds may be moving to mixer!")
        return 1
    
    if eth_tx and eth_tx > 1:  # Currently only 1 tx
        print(f"  ⚠️ ALERT: New outgoing transaction detected!")
        return 1
    
    print(f"  ✓ Funds still idle (expected: ~{EXPECTED_ETH} ETH)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
