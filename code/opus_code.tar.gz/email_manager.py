#!/usr/bin/env python3
"""
Async Email Manager for Opus
Handles Gmail IMAP operations that would timeout in shell
Run with: nohup python3 email_manager.py <command> &
"""
import imaplib
import ssl
import sys
import json
import os
import email
from email.header import decode_header
from datetime import datetime
import time

# Config
GMAIL_USER = "opustrace@gmail.com"
GMAIL_PASS = "ohmpvyuqbaivvdwr"
IMAP_SERVER = "imap.gmail.com"
IMAP_PORT = 993

BASE_DIR = "/root/claude/opus"
LOG_FILE = f"{BASE_DIR}/email_manager.log"
STATUS_FILE = f"{BASE_DIR}/email_status.json"

def log(msg):
    timestamp = datetime.now().isoformat()
    line = f"[{timestamp}] {msg}"
    with open(LOG_FILE, 'a') as f:
        f.write(line + "\n")
    print(line)

def update_status(status_dict):
    """Update status file so Opus can check progress"""
    status_dict['last_update'] = datetime.now().isoformat()
    with open(STATUS_FILE, 'w') as f:
        json.dump(status_dict, f, indent=2)

def connect_gmail():
    log("Connecting to Gmail IMAP...")
    context = ssl.create_default_context()
    mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, ssl_context=context)
    mail.login(GMAIL_USER, GMAIL_PASS)
    log("Connected successfully")
    return mail

def get_inbox_summary(mail):
    """Get summary of inbox contents"""
    log("Getting inbox summary...")
    update_status({'operation': 'inbox_summary', 'status': 'selecting'})
    
    status, count = mail.select('INBOX')
    total = int(count[0].decode())
    log(f"INBOX has {total} messages")
    
    update_status({'operation': 'inbox_summary', 'status': 'searching', 'total': total})
    
    status, data = mail.uid('SEARCH', None, 'ALL')
    if status != 'OK':
        log(f"Search failed: {status}")
        return
    
    uids = data[0].split()
    log(f"Found {len(uids)} UIDs")
    
    summary = []
    for i, uid in enumerate(uids):
        update_status({
            'operation': 'inbox_summary', 
            'status': 'fetching',
            'progress': f"{i+1}/{len(uids)}"
        })
        
        status, msg_data = mail.uid('FETCH', uid, '(ENVELOPE)')
        if status == 'OK' and msg_data[0]:
            try:
                # Parse envelope
                envelope = msg_data[0][1] if len(msg_data[0]) > 1 else msg_data[0]
                summary.append({
                    'uid': uid.decode(),
                    'raw': str(envelope)[:200]
                })
            except Exception as e:
                log(f"Error parsing UID {uid}: {e}")
        
        # Small delay to avoid rate limiting
        time.sleep(0.1)
    
    # Save summary
    with open(f"{BASE_DIR}/inbox_summary.json", 'w') as f:
        json.dump(summary, f, indent=2)
    
    log(f"Saved summary of {len(summary)} emails to inbox_summary.json")
    update_status({'operation': 'inbox_summary', 'status': 'complete', 'count': len(summary)})

def move_all_to_folder(mail, dest_folder):
    """Move all inbox emails to a folder"""
    log(f"Moving all inbox emails to {dest_folder}...")
    
    # Ensure folder exists
    try:
        mail.create(dest_folder)
        log(f"Created folder {dest_folder}")
    except:
        log(f"Folder {dest_folder} already exists")
    
    status, count = mail.select('INBOX')
    log(f"Selected INBOX: {count[0].decode()} messages")
    
    status, data = mail.uid('SEARCH', None, 'ALL')
    if status != 'OK':
        log(f"Search failed")
        return
    
    uids = data[0].split()
    log(f"Found {len(uids)} emails to move")
    
    moved = 0
    for i, uid in enumerate(uids):
        update_status({
            'operation': 'move_all',
            'status': 'moving',
            'progress': f"{i+1}/{len(uids)}",
            'moved': moved
        })
        
        try:
            # Copy to destination
            status, _ = mail.uid('COPY', uid, dest_folder)
            if status == 'OK':
                # Mark for deletion
                mail.uid('STORE', uid, '+FLAGS', r'(\Deleted)')
                moved += 1
                log(f"Moved UID {uid.decode()} ({i+1}/{len(uids)})")
            else:
                log(f"Failed to copy UID {uid.decode()}")
        except Exception as e:
            log(f"Error moving UID {uid.decode()}: {e}")
        
        time.sleep(0.2)  # Rate limiting
    
    # Expunge deleted messages
    mail.expunge()
    log(f"Expunged deleted messages. Moved {moved}/{len(uids)} emails")
    update_status({'operation': 'move_all', 'status': 'complete', 'moved': moved})

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 email_manager.py <command>")
        print("Commands:")
        print("  summary     - Get inbox summary")
        print("  archive     - Move all inbox to Processed folder")
        print("  move <dest> - Move all inbox to specified folder")
        sys.exit(1)
    
    command = sys.argv[1]
    
    try:
        mail = connect_gmail()
        
        if command == 'summary':
            get_inbox_summary(mail)
        elif command == 'archive':
            move_all_to_folder(mail, 'Processed')
        elif command == 'move' and len(sys.argv) > 2:
            move_all_to_folder(mail, sys.argv[2])
        else:
            log(f"Unknown command: {command}")
        
        mail.logout()
        log("Disconnected")
        
    except Exception as e:
        log(f"ERROR: {e}")
        import traceback
        log(traceback.format_exc())
        update_status({'operation': command, 'status': 'error', 'error': str(e)})

if __name__ == '__main__':
    main()
