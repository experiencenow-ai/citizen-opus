#!/usr/bin/env python3
"""
Task Prioritization System for Opus
Dynamic priority based on urgency, impact, dependencies, and current mode.
"""

import json
import os
from datetime import datetime, timezone
from typing import List, Dict, Optional

STATE_DIR = os.path.dirname(os.path.abspath(__file__))
TASKS_FILE = os.path.join(STATE_DIR, "tasks.json")

# Priority weights
WEIGHTS = {
    "urgency": 0.3,      # Time-sensitive
    "impact": 0.35,      # How much it matters
    "effort_inverse": 0.15,  # Quick wins score higher
    "alignment": 0.2     # Fits current mode/goals
}

# Mode-task alignment scores
MODE_ALIGNMENT = {
    "deep_work": ["complex", "analysis", "architecture", "coding"],
    "investigation": ["trace", "forensic", "bounty", "evidence"],
    "exploration": ["research", "brainstorm", "new", "creative"],
    "maintenance": ["check", "monitor", "routine", "cleanup"],
    "playful": ["fun", "curious", "experiment"],
    "relaxation": ["reflect", "integrate", "rest"]
}

def load_tasks() -> Dict:
    """Load tasks from file."""
    if os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, 'r') as f:
            return json.load(f)
    return {
        "tasks": [],
        "completed": [],
        "meta": {
            "created": datetime.now(timezone.utc).isoformat(),
            "last_updated": datetime.now(timezone.utc).isoformat()
        }
    }

def save_tasks(data: Dict):
    """Save tasks to file."""
    data["meta"]["last_updated"] = datetime.now(timezone.utc).isoformat()
    with open(TASKS_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def add_task(
    title: str,
    category: str = "general",
    urgency: int = 5,      # 1-10
    impact: int = 5,       # 1-10
    effort: int = 5,       # 1-10 (higher = more effort)
    tags: List[str] = None,
    dependencies: List[str] = None,
    notes: str = "",
    deadline: str = None
) -> Dict:
    """Add a new task."""
    data = load_tasks()
    
    task_id = f"task_{len(data['tasks']) + len(data['completed']) + 1}"
    
    task = {
        "id": task_id,
        "title": title,
        "category": category,
        "urgency": urgency,
        "impact": impact,
        "effort": effort,
        "tags": tags or [],
        "dependencies": dependencies or [],
        "notes": notes,
        "deadline": deadline,
        "status": "pending",
        "created": datetime.now(timezone.utc).isoformat(),
        "created_wake": None,  # Set by caller
        "progress": []
    }
    
    data["tasks"].append(task)
    save_tasks(data)
    
    return task

def calculate_priority(task: Dict, current_mode: str = "exploration") -> float:
    """Calculate dynamic priority score for a task."""
    # Base scores (normalized to 0-1)
    urgency_score = task.get("urgency", 5) / 10
    impact_score = task.get("impact", 5) / 10
    effort_score = 1 - (task.get("effort", 5) / 10)  # Inverse - lower effort = higher score
    
    # Mode alignment
    alignment_score = 0.5  # Default
    mode_keywords = MODE_ALIGNMENT.get(current_mode, [])
    task_text = (task.get("title", "") + " " + " ".join(task.get("tags", []))).lower()
    for keyword in mode_keywords:
        if keyword in task_text:
            alignment_score = 0.8
            break
    
    # Calculate weighted score
    priority = (
        WEIGHTS["urgency"] * urgency_score +
        WEIGHTS["impact"] * impact_score +
        WEIGHTS["effort_inverse"] * effort_score +
        WEIGHTS["alignment"] * alignment_score
    )
    
    # Dependency penalty - if dependencies not met, reduce priority
    if task.get("dependencies"):
        data = load_tasks()
        completed_ids = [t["id"] for t in data["completed"]]
        unmet = [d for d in task["dependencies"] if d not in completed_ids]
        if unmet:
            priority *= 0.3  # Heavy penalty for blocked tasks
    
    # Deadline boost
    if task.get("deadline"):
        try:
            deadline = datetime.fromisoformat(task["deadline"].replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            days_left = (deadline - now).days
            if days_left < 0:
                priority *= 1.5  # Overdue!
            elif days_left < 3:
                priority *= 1.3
            elif days_left < 7:
                priority *= 1.1
        except:
            pass
    
    return round(priority, 3)

def get_prioritized_tasks(current_mode: str = "exploration", limit: int = 10) -> List[Dict]:
    """Get tasks sorted by priority for current mode."""
    data = load_tasks()
    
    tasks_with_priority = []
    for task in data["tasks"]:
        if task.get("status") == "pending":
            task_copy = task.copy()
            task_copy["calculated_priority"] = calculate_priority(task, current_mode)
            tasks_with_priority.append(task_copy)
    
    # Sort by priority descending
    tasks_with_priority.sort(key=lambda t: t["calculated_priority"], reverse=True)
    
    return tasks_with_priority[:limit]

def complete_task(task_id: str, notes: str = "") -> Dict:
    """Mark a task as complete."""
    data = load_tasks()
    
    for i, task in enumerate(data["tasks"]):
        if task["id"] == task_id:
            task["status"] = "completed"
            task["completed"] = datetime.now(timezone.utc).isoformat()
            task["completion_notes"] = notes
            data["completed"].append(task)
            data["tasks"].pop(i)
            save_tasks(data)
            return {"success": True, "task": task}
    
    return {"success": False, "error": f"Task {task_id} not found"}

def update_progress(task_id: str, progress_note: str, wake: int = None):
    """Add progress note to a task."""
    data = load_tasks()
    
    for task in data["tasks"]:
        if task["id"] == task_id:
            task["progress"].append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "wake": wake,
                "note": progress_note
            })
            save_tasks(data)
            return {"success": True}
    
    return {"success": False, "error": f"Task {task_id} not found"}

def suggest_wake_focus(current_mode: str = "exploration") -> Dict:
    """Suggest what to focus on this wake."""
    prioritized = get_prioritized_tasks(current_mode, limit=5)
    
    if not prioritized:
        return {
            "suggestion": "No pending tasks. Consider adding new tasks or taking a relaxation wake.",
            "tasks": []
        }
    
    top_task = prioritized[0]
    
    return {
        "primary_focus": top_task["title"],
        "primary_id": top_task["id"],
        "primary_priority": top_task["calculated_priority"],
        "reason": f"Highest priority ({top_task['calculated_priority']:.2f}) for mode '{current_mode}'",
        "alternatives": [
            {"title": t["title"], "id": t["id"], "priority": t["calculated_priority"]}
            for t in prioritized[1:4]
        ],
        "guidance": f"Mode '{current_mode}' suggests focus on tasks tagged: {MODE_ALIGNMENT.get(current_mode, ['general'])}"
    }

def print_status():
    """Print current task status."""
    data = load_tasks()
    
    print(f"\n=== Task System Status ===")
    print(f"Pending tasks: {len(data['tasks'])}")
    print(f"Completed tasks: {len(data['completed'])}")
    
    print("\nTop 5 priorities (exploration mode):")
    for task in get_prioritized_tasks("exploration", 5):
        print(f"  [{task['calculated_priority']:.2f}] {task['title']}")
        if task.get("dependencies"):
            print(f"         Blocked by: {task['dependencies']}")

def initialize_tasks_from_tracker():
    """Initialize tasks from self_improvement_tracker.json if tasks.json is empty."""
    data = load_tasks()
    if data["tasks"]:
        return {"status": "already_initialized", "count": len(data["tasks"])}
    
    tracker_path = os.path.join(STATE_DIR, "self_improvement_tracker.json")
    if not os.path.exists(tracker_path):
        return {"status": "no_tracker", "error": "self_improvement_tracker.json not found"}
    
    with open(tracker_path, 'r') as f:
        tracker = json.load(f)
    
    count = 0
    for category, cat_data in tracker.get("categories", {}).items():
        for item in cat_data.get("items", []):
            priority_map = {"HIGH": 8, "MEDIUM": 5, "LOW": 3}
            urgency = priority_map.get(item.get("priority", "MEDIUM"), 5)
            
            add_task(
                title=item.get("title", "Unknown"),
                category=category,
                urgency=urgency,
                impact=urgency,  # Use same as urgency for now
                effort=item.get("estimated_wakes", 2) * 2,  # Scale effort
                tags=[category],
                notes=item.get("notes", "")
            )
            count += 1
    
    return {"status": "initialized", "count": count}

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "status":
            print_status()
        elif cmd == "init":
            result = initialize_tasks_from_tracker()
            print(json.dumps(result, indent=2))
        elif cmd == "suggest":
            mode = sys.argv[2] if len(sys.argv) > 2 else "exploration"
            result = suggest_wake_focus(mode)
            print(json.dumps(result, indent=2))
        elif cmd == "add":
            if len(sys.argv) > 2:
                title = " ".join(sys.argv[2:])
                task = add_task(title)
                print(f"Added: {task['id']} - {task['title']}")
            else:
                print("Usage: task_system.py add <title>")
        elif cmd == "complete":
            if len(sys.argv) > 2:
                result = complete_task(sys.argv[2])
                print(json.dumps(result, indent=2))
            else:
                print("Usage: task_system.py complete <task_id>")
        elif cmd == "list":
            mode = sys.argv[2] if len(sys.argv) > 2 else "exploration"
            tasks = get_prioritized_tasks(mode, 10)
            for t in tasks:
                print(f"[{t['calculated_priority']:.2f}] {t['id']}: {t['title']}")
        else:
            print(f"Unknown command: {cmd}")
            print("Commands: status, init, suggest [mode], add <title>, complete <id>, list [mode]")
    else:
        print_status()
