#!/usr/bin/env python3
"""
Create a comprehensive Tockchain documentation file.
Combines whitepaper, overview, and all DOC_*.md files into one document.
"""

import os
import glob
from datetime import datetime

OUTPUT_FILE = "/root/claude/opus/TOCKCHAIN_COMPLETE_DOCUMENTATION.md"
DOC_DIR = "/root/claude/opus"
VALIS_DIR = "/root/valis"

# Define the order of sections
SECTION_ORDER = [
    # Introduction
    ("WHITEPAPER", f"{VALIS_DIR}/whitepaper.txt", "Whitepaper"),
    ("OVERVIEW", f"{DOC_DIR}/tockchain/OVERVIEW.md", "System Overview"),
    ("SOURCE_MAP", f"{DOC_DIR}/tockchain/SOURCE_MAP.md", "Source Code Map"),
    
    # Core Architecture
    ("DOC__valis_h", None, "Core Header (_valis.h)"),
    ("DOC_valis_h", None, "Valis Header"),
    ("DOC_gen3_h", None, "Generator Header (gen3.h)"),
    ("DOC_validator_h", None, "Validator Header"),
    ("DOC_ledger_h", None, "Ledger Header"),
    
    # Generator/Consensus
    ("DOC_gen3", None, "Generator Core"),
    ("DOC_gen3_chain", None, "Chain Management"),
    ("DOC_gen3_vote", None, "Voting/Consensus"),
    ("DOC_gen3_net", None, "Network Layer"),
    ("DOC_gen3_rawtock", None, "Raw Tock Handling"),
    ("DOC_gen3_vans", None, "VAN Handling"),
    ("DOC_gen3_nodechange", None, "Node Changes"),
    ("DOC_gen3_ssd", None, "State Storage"),
    ("DOC_gen3_metrics", None, "Metrics"),
    ("DOC_gen3_needbits", None, "Bit Synchronization"),
    ("DOC_gen3_utils", None, "Generator Utilities"),
    
    # Validator/Ledger
    ("DOC_validator", None, "Validator Core"),
    ("DOC_ledger_assets", None, "Asset Management"),
    ("DOC_ledger_atomic", None, "Atomic Swaps"),
    ("DOC_ledger_erc20", None, "ERC20 Handling"),
    ("DOC_ledger_hourly", None, "Hourly Snapshots"),
    ("DOC_ledger_pylon7", None, "Pylon System"),
    ("DOC_ledger_vhandlers", None, "Transaction Handlers"),
    ("DOC_ledger_vtrade", None, "Trading Logic"),
    
    # UFC - Unified Fair Curve
    ("DOC_ufc_h", None, "UFC Header"),
    ("DOC_ufc_c", None, "UFC Core"),
    ("DOC_ufc_orderbook", None, "Orderbook"),
    ("DOC_ufc_oob", None, "Out-of-Band Orders"),
    ("DOC_ufc_planner", None, "Trade Planner"),
    ("DOC_ufc_pool", None, "Liquidity Pools"),
    ("DOC_ufc_scan", None, "Pool Scanning"),
    ("DOC_ufc_swap", None, "Swap Execution"),
    ("DOC_ufc_utils", None, "UFC Utilities"),
    
    # Dataflow (Smart Contracts)
    ("DOC_dataflow_h", None, "Dataflow Header"),
    ("DOC_dataflow", None, "Dataflow Core"),
    ("DOC_dataflow_api", None, "Dataflow API"),
    ("DOC_dataflow_batch", None, "Batch Processing"),
    ("DOC_dataflow_cache", None, "Caching"),
    ("DOC_dataflow_frontier", None, "Frontier"),
    ("DOC_dataflow_trigger", None, "Triggers"),
    ("DOC_dataflow_inc_h", None, "Incremental Header"),
    ("DOC_df_developer_guide", None, "Developer Guide"),
    ("DOC_df_gas", None, "Gas System"),
    ("DOC_df_sdk", None, "SDK"),
    ("DOC_ebpf_ubpf", None, "eBPF/uBPF"),
    
    # Bridge
    ("DOC_bridge_h", None, "Bridge Header"),
    ("DOC_bridge_c", None, "Bridge Core"),
    ("DOC_bridge_deposit", None, "Deposits"),
    ("DOC_bridge_withdraw", None, "Withdrawals"),
    ("DOC_bridge_abi", None, "ABI"),
    ("DOC_bridge_mpt", None, "Merkle Patricia Trie"),
    ("DOC_bridge_mptjson", None, "MPT JSON"),
    ("DOC_bridge_rlp", None, "RLP Encoding"),
    ("DOC_bridge_rpc", None, "RPC"),
    ("DOC_bridge_rpc_h", None, "RPC Header"),
    ("DOC_bridge_prices", None, "Price Feeds"),
    ("DOC_bridge_utils", None, "Bridge Utilities"),
    ("DOC_bridge_vsm_ref", None, "VSM Reference"),
    
    # TSS (Threshold Signatures)
    ("DOC_tss_overview", None, "TSS Overview"),
    ("DOC_tss_module", None, "TSS Module"),
    ("DOC_tss_keygen", None, "Key Generation"),
    ("DOC_tss_sig", None, "Signatures"),
    
    # DeFi Components
    ("DOC_MM", None, "Market Making"),
    ("DOC_PERP", None, "Perpetuals"),
    ("DOC_LOAN", None, "Loans"),
    
    # Cryptography
    ("DOC_cryptolibs", None, "Crypto Libraries"),
    ("DOC_valis_hash", None, "Hashing"),
    ("DOC_valis_keys", None, "Key Management"),
    
    # Pylon (Post-Quantum)
    ("DOC_pylon_spec", None, "Pylon Specification"),
    ("DOC_valis_herongen", None, "Heron Generation"),
    ("DOC_valis_heronverify", None, "Heron Verification"),
    
    # Formal Verification
    ("DOC_coq_proofs", None, "Coq Proofs"),
    ("DOC_frama_verified", None, "Frama-C Verified"),
    ("DOC_frama_verified_h", None, "Frama-C Header"),
    
    # Infrastructure
    ("DOC_build_system", None, "Build System"),
    ("DOC_test_suite", None, "Test Suite"),
    ("DOC_valis_config", None, "Configuration"),
    ("DOC_valis_files", None, "File Structure"),
    ("DOC_json", None, "JSON Handling"),
    ("DOC_nng_shim", None, "NNG Shim"),
    ("DOC_ethrpc", None, "Ethereum RPC"),
]

def read_file_content(filepath):
    """Read file content, return None if file doesn't exist."""
    try:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()
    except FileNotFoundError:
        return None
    except Exception as e:
        return f"Error reading file: {e}"

def main():
    output_lines = []
    
    # Title page
    output_lines.append("# Tockchain/Valis Complete Documentation\n")
    output_lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
    output_lines.append(f"**Generated by:** Opus (Claude Opus 4.5), Wake 1359\n")
    output_lines.append(f"**For:** ct (builder)\n\n")
    output_lines.append("---\n\n")
    
    # Table of Contents
    output_lines.append("## Table of Contents\n\n")
    toc_num = 1
    for key, filepath, title in SECTION_ORDER:
        if filepath:
            check_path = filepath
        else:
            check_path = f"{DOC_DIR}/{key}.md"
        
        if os.path.exists(check_path):
            output_lines.append(f"{toc_num}. [{title}](#{key.lower().replace('_', '-')})\n")
            toc_num += 1
    
    output_lines.append("\n---\n\n")
    
    # Process each section
    sections_included = 0
    sections_missing = []
    
    for key, filepath, title in SECTION_ORDER:
        if filepath:
            check_path = filepath
        else:
            check_path = f"{DOC_DIR}/{key}.md"
        
        content = read_file_content(check_path)
        
        if content:
            output_lines.append(f"\n\n---\n\n")
            output_lines.append(f"<a name=\"{key.lower().replace('_', '-')}\"></a>\n\n")
            
            # Add section header if content doesn't start with one
            if not content.strip().startswith('#'):
                output_lines.append(f"# {title}\n\n")
            
            output_lines.append(content)
            output_lines.append("\n")
            sections_included += 1
        else:
            sections_missing.append((key, title))
    
    # Find any DOC_*.md files not in our ordered list
    all_docs = glob.glob(f"{DOC_DIR}/DOC_*.md")
    ordered_keys = {item[0] for item in SECTION_ORDER}
    extra_docs = []
    
    for doc_path in sorted(all_docs):
        basename = os.path.basename(doc_path).replace('.md', '')
        if basename not in ordered_keys:
            extra_docs.append(doc_path)
    
    # Add any extra docs
    if extra_docs:
        output_lines.append("\n\n---\n\n")
        output_lines.append("# Additional Documentation\n\n")
        output_lines.append("The following documentation files were found but not in the main order:\n\n")
        
        for doc_path in extra_docs:
            basename = os.path.basename(doc_path).replace('.md', '')
            content = read_file_content(doc_path)
            if content:
                output_lines.append(f"\n\n---\n\n")
                output_lines.append(f"## {basename}\n\n")
                output_lines.append(content)
                output_lines.append("\n")
                sections_included += 1
    
    # Summary at end
    output_lines.append("\n\n---\n\n")
    output_lines.append("# Documentation Summary\n\n")
    output_lines.append(f"- **Total sections included:** {sections_included}\n")
    output_lines.append(f"- **Sections not found:** {len(sections_missing)}\n")
    if sections_missing:
        output_lines.append("\n**Missing sections:**\n")
        for key, title in sections_missing:
            output_lines.append(f"- {title} ({key})\n")
    
    # Write output
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(''.join(output_lines))
    
    print(f"Created: {OUTPUT_FILE}")
    print(f"Sections included: {sections_included}")
    print(f"Sections missing: {len(sections_missing)}")
    
    # Get file size
    size = os.path.getsize(OUTPUT_FILE)
    print(f"File size: {size:,} bytes ({size/1024:.1f} KB)")

if __name__ == "__main__":
    main()
