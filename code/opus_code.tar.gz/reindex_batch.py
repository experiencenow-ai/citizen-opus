#!/usr/bin/env python3
"""
Batch reindex - uses batch embedding for ~8x speedup.
"""
import json
import re
import sys
import hashlib
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

OPUS_HOME = Path("/root/claude/opus")
sys.path.insert(0, str(OPUS_HOME))

from local_llm import embed
import chromadb
from chromadb.config import Settings

CHROMA_DIR = OPUS_HOME / "memory_db"

def parse_response_json(response: str) -> dict:
    """Extract JSON from a response that might be in a codeblock."""
    if not response:
        return {}
    try:
        return json.loads(response)
    except:
        pass
    patterns = [
        r'```json\s*(.*?)\s*```',
        r'```\s*(\{.*?\})\s*```',
    ]
    for pattern in patterns:
        match = re.search(pattern, response, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except:
                continue
    return {}


def hash_content(content: str) -> str:
    return hashlib.md5(content.encode()).hexdigest()[:12]


def collect_all_memories() -> tuple:
    """Collect all thoughts and insights from logs."""
    thoughts = []
    insights = []
    
    log_dirs = [OPUS_HOME / "logs", OPUS_HOME / "firstlogs"]
    
    for log_dir in log_dirs:
        if not log_dir.exists():
            continue
        
        for log_file in sorted(log_dir.glob("experience_*.jsonl")):
            with open(log_file) as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        entry = json.loads(line)
                        wake = entry.get("total_wakes") or entry.get("wake") or entry.get("instance")
                        timestamp = entry.get("timestamp")
                        
                        parsed = parse_response_json(entry.get("response", ""))
                        
                        thought = parsed.get("thought")
                        if thought and len(thought) > 20:
                            thoughts.append({
                                "content": thought[:3000],
                                "wake": wake,
                                "timestamp": timestamp
                            })
                        
                        insight = parsed.get("insight")
                        if insight:
                            if isinstance(insight, list):
                                for ins in insight:
                                    if ins and len(str(ins)) > 10:
                                        insights.append({
                                            "content": str(ins)[:2000],
                                            "wake": wake,
                                            "timestamp": timestamp
                                        })
                            elif len(str(insight)) > 10:
                                insights.append({
                                    "content": str(insight)[:2000],
                                    "wake": wake,
                                    "timestamp": timestamp
                                })
                    except:
                        pass
    
    return thoughts, insights


def batch_index(collection, items: List[Dict], memory_type: str, batch_size: int = 50):
    """Add items in batches for efficiency."""
    
    # Get existing IDs to avoid duplicates
    existing = set()
    try:
        result = collection.get(include=[])
        existing = set(result["ids"])
    except:
        pass
    
    total_added = 0
    
    for i in range(0, len(items), batch_size):
        batch = items[i:i+batch_size]
        
        # Filter out existing
        new_items = []
        for item in batch:
            item_id = f"{memory_type}_{item.get('wake', 'none')}_{hash_content(item['content'])}"
            if item_id not in existing:
                item["id"] = item_id
                new_items.append(item)
                existing.add(item_id)  # Mark as added
        
        if not new_items:
            continue
        
        # Get embeddings in batch
        texts = [item["content"] for item in new_items]
        embeddings = embed(texts)
        
        if not embeddings or len(embeddings) != len(new_items):
            print(f"  Warning: Embedding failed for batch {i}-{i+batch_size}")
            continue
        
        # Prepare for ChromaDB
        ids = [item["id"] for item in new_items]
        documents = [item["content"] for item in new_items]
        metadatas = [{
            "memory_type": memory_type,
            "wake": item.get("wake"),
            "timestamp": item.get("timestamp"),
        } for item in new_items]
        
        try:
            collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=documents,
                metadatas=metadatas
            )
            total_added += len(new_items)
        except Exception as e:
            print(f"  Error adding batch: {e}")
        
        if (i + batch_size) % 200 == 0:
            print(f"  Progress: {i + batch_size}/{len(items)}, added: {total_added}")
    
    return total_added


def main():
    print("=" * 60)
    print("BATCH REINDEX - THOUGHTS AND INSIGHTS")
    print("=" * 60)
    
    # Collect all memories
    print("\nCollecting memories from logs...")
    thoughts, insights = collect_all_memories()
    print(f"Found {len(thoughts)} thoughts, {len(insights)} insights")
    
    # Initialize ChromaDB
    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR),
        settings=Settings(anonymized_telemetry=False)
    )
    
    thoughts_coll = client.get_or_create_collection("thoughts", metadata={"hnsw:space": "cosine"})
    insights_coll = client.get_or_create_collection("insights", metadata={"hnsw:space": "cosine"})
    all_coll = client.get_or_create_collection("all_memories", metadata={"hnsw:space": "cosine"})
    
    print(f"\nCurrent counts: thoughts={thoughts_coll.count()}, insights={insights_coll.count()}")
    
    # Index thoughts
    print("\nIndexing thoughts...")
    added = batch_index(thoughts_coll, thoughts, "thoughts")
    print(f"Added {added} thoughts")
    
    # Also add to all_memories
    print("Adding to all_memories...")
    batch_index(all_coll, thoughts, "thoughts")
    
    # Index insights
    print("\nIndexing insights...")
    added = batch_index(insights_coll, insights, "insights")
    print(f"Added {added} insights")
    
    # Also add to all_memories
    print("Adding to all_memories...")
    batch_index(all_coll, insights, "insights")
    
    print("\n" + "=" * 60)
    print("COMPLETE")
    print("=" * 60)
    print(f"Final counts: thoughts={thoughts_coll.count()}, insights={insights_coll.count()}")


if __name__ == "__main__":
    main()
