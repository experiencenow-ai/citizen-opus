#!/usr/bin/env python3
"""
Trace where ALL USDT went from main wallet
"""

import requests
import json
import time
from decimal import Decimal, getcontext
from collections import defaultdict

getcontext().prec = 50

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
MAIN_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.25)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def get_token_balance(address, contract):
    result = api_call("account", "tokenbalance", {"contractaddress": contract, "address": address})
    if result:
        return Decimal(result) / Decimal(10**6)  # USDT has 6 decimals
    return Decimal(0)

def main():
    # Get ALL token TXs
    token_txs = api_call("account", "tokentx", {
        "address": MAIN_WALLET,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    print(f"Total USDT TXs: {len(token_txs)}")
    
    # Current balance
    current = get_token_balance(MAIN_WALLET, USDT_CONTRACT)
    print(f"\nCurrent USDT balance: {current:,.2f}")
    
    # Categorize
    inflows = []
    outflows = []
    
    for tx in token_txs:
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue  # Skip dust/poisoning
        
        data = {
            "hash": tx["hash"],
            "from": tx["from"],
            "to": tx["to"],
            "value": float(value),
            "timestamp": tx["timeStamp"]
        }
        
        if tx["to"].lower() == MAIN_WALLET.lower():
            inflows.append(data)
        elif tx["from"].lower() == MAIN_WALLET.lower():
            outflows.append(data)
    
    total_in = sum(t["value"] for t in inflows)
    total_out = sum(t["value"] for t in outflows)
    
    print(f"\nTotal USDT In: {total_in:,.2f}")
    print(f"Total USDT Out: {total_out:,.2f}")
    print(f"Calculated Balance: {total_in - total_out:,.2f}")
    print(f"Difference vs Current: {total_in - total_out - float(current):,.2f}")
    
    # Group outflows by destination
    print("\n" + "="*100)
    print("USDT OUTFLOWS BY DESTINATION")
    print("="*100)
    
    by_dest = defaultdict(lambda: {"total": 0, "txs": []})
    for tx in outflows:
        dest = tx["to"]
        by_dest[dest]["total"] += tx["value"]
        by_dest[dest]["txs"].append(tx["hash"])
    
    # Sort by amount
    sorted_dests = sorted(by_dest.items(), key=lambda x: x[1]["total"], reverse=True)
    
    grand_total = 0
    dest_list = []
    
    for dest, data in sorted_dests:
        grand_total += data["total"]
        dest_list.append({
            "address": dest,
            "amount": data["total"],
            "tx_count": len(data["txs"]),
            "tx_hashes": data["txs"]
        })
        print(f"\n{dest}")
        print(f"  Amount: ${data['total']:,.2f}")
        print(f"  TX Count: {len(data['txs'])}")
        for h in data["txs"][:3]:
            print(f"    {h}")
        if len(data["txs"]) > 3:
            print(f"    ... +{len(data['txs'])-3} more")
    
    print(f"\n\n{'='*100}")
    print(f"GRAND TOTAL OUT: ${grand_total:,.2f}")
    print(f"CURRENT BALANCE: ${float(current):,.2f}")
    print(f"ACCOUNTED: ${grand_total + float(current):,.2f}")
    print(f"{'='*100}")
    
    # Save
    output = {
        "main_wallet": MAIN_WALLET,
        "usdt_inflows_total": total_in,
        "usdt_outflows_total": total_out,
        "current_balance": float(current),
        "destinations": dest_list
    }
    
    with open("usdt_destinations_complete.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print("\nSaved to usdt_destinations_complete.json")

if __name__ == "__main__":
    main()
