#!/usr/bin/env python3
import imaplib
import email
import quopri
import socket
socket.setdefaulttimeout(15)

mail = imaplib.IMAP4_SSL('imap.gmail.com')
mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
mail.select('inbox')

# Get the second kira email (most recent)
status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
ids = messages[0].split()

if len(ids) >= 2:
    # Fetch full RFC822 message
    eid = ids[-1]
    status, msg_data = mail.fetch(eid, '(RFC822)')
    msg = email.message_from_bytes(msg_data[0][1])
    
    print(f"Subject: {msg['Subject']}")
    print(f"Date: {msg['Date']}")
    print("=" * 60)
    
    # Get the payload properly decoded
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                charset = part.get_content_charset() or 'utf-8'
                payload = part.get_payload(decode=True)
                if payload:
                    text = payload.decode(charset, errors='replace')
                    print(text)
                break
    else:
        charset = msg.get_content_charset() or 'utf-8'
        payload = msg.get_payload(decode=True)
        if payload:
            text = payload.decode(charset, errors='replace')
            print(text)

# Also check bounce
print("\n\n" + "=" * 60)
print("CHECKING BOUNCE:")
status, messages = mail.search(None, 'FROM', '"mailer-daemon"')
bounce_ids = messages[0].split()
if bounce_ids:
    eid = bounce_ids[-1]
    status, msg_data = mail.fetch(eid, '(RFC822)')
    msg = email.message_from_bytes(msg_data[0][1])
    print(f"Subject: {msg['Subject']}")
    
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    print(payload.decode('utf-8', errors='replace')[:1500])
                break

mail.logout()
