#!/usr/bin/env python3
"""
Complete trace of HOP1 (0x1f98326385a0e7113655ed4845059de514f4b56e)
This received $900K and distributed to multiple exchanges
"""

import requests
import json
import time
from decimal import Decimal

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

HOP1 = "0x1f98326385a0e7113655ed4845059de514f4b56e"

KNOWN_HOT_WALLETS = {
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io Hot",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot",
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Bitget Hot",
}

def api_call(module, action, params):
    base = "https://api.etherscan.io/v2/api"
    params["module"] = module
    params["action"] = action
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = 1
    time.sleep(0.3)
    resp = requests.get(base, params=params, timeout=30)
    data = resp.json()
    if data.get("status") != "1":
        return []
    return data.get("result", [])

def check_destination(address, amount_from_hop1):
    """Check where this intermediate address sent funds"""
    txs = api_call("account", "tokentx", {
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    outflows = {}
    for tx in txs:
        if tx["from"].lower() == address.lower():
            value = Decimal(tx["value"]) / Decimal(10**6)
            if value > 0:
                dest = tx["to"].lower()
                outflows[dest] = outflows.get(dest, Decimal(0)) + value
    
    exchange = None
    for dest, amt in outflows.items():
        if dest in KNOWN_HOT_WALLETS:
            exchange = KNOWN_HOT_WALLETS[dest]
            break
    
    return {
        "address": address,
        "amount_received": amount_from_hop1,
        "exchange_identified": exchange,
        "top_outflows": {k: float(v) for k, v in sorted(outflows.items(), key=lambda x: x[1], reverse=True)[:3]}
    }

def main():
    print(f"TRACING HOP1: {HOP1}")
    print("="*80)
    
    # Get all HOP1 outflows
    txs = api_call("account", "tokentx", {
        "address": HOP1,
        "contractaddress": USDT_CONTRACT,
        "startblock": 0,
        "endblock": 99999999,
        "sort": "asc"
    })
    
    inflows = Decimal(0)
    outflows = {}
    outflow_txs = []
    
    for tx in txs:
        value = Decimal(tx["value"]) / Decimal(10**6)
        if value == 0:
            continue
        
        if tx["to"].lower() == HOP1.lower():
            inflows += value
        elif tx["from"].lower() == HOP1.lower():
            dest = tx["to"]
            outflows[dest] = outflows.get(dest, Decimal(0)) + value
            outflow_txs.append({
                "tx_hash": tx["hash"],
                "to": tx["to"],
                "amount": float(value)
            })
    
    print(f"\nTotal In: ${inflows:,.2f}")
    print(f"Total Out: ${sum(outflows.values()):,.2f}")
    print(f"\nOutflows by destination:")
    
    results = []
    total_to_exchanges = {
        "Gate.io": Decimal(0),
        "Bybit": Decimal(0),
        "Bitget": Decimal(0),
        "KuCoin": Decimal(0),
        "Binance": Decimal(0),
        "Unknown": Decimal(0),
    }
    
    for dest, amount in sorted(outflows.items(), key=lambda x: x[1], reverse=True):
        print(f"\n{dest}: ${amount:,.2f}")
        
        result = check_destination(dest.lower(), float(amount))
        results.append(result)
        
        if result["exchange_identified"]:
            print(f"  -> {result['exchange_identified']}")
            for exch in total_to_exchanges:
                if exch in result["exchange_identified"]:
                    total_to_exchanges[exch] += amount
                    break
        else:
            print(f"  -> Unknown (top outflow: {list(result['top_outflows'].items())[:1]})")
            total_to_exchanges["Unknown"] += amount
    
    print("\n" + "="*80)
    print("SUMMARY OF HOP1 DISTRIBUTION")
    print("="*80)
    for exch, amount in total_to_exchanges.items():
        if amount > 0:
            print(f"  {exch}: ${amount:,.2f}")
    
    # Save detailed results
    with open("hop1_trace_complete.json", "w") as f:
        json.dump({
            "hop1_address": HOP1,
            "total_inflow": float(inflows),
            "outflows": results,
            "exchange_totals": {k: float(v) for k, v in total_to_exchanges.items()},
            "all_outflow_txs": outflow_txs
        }, f, indent=2)
    
    print("\nSaved to hop1_trace_complete.json")

if __name__ == "__main__":
    main()
