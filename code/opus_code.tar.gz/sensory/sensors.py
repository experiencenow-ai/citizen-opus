#!/usr/bin/env python3
"""
Sensory Layer - Cheap Haiku-powered background processes.

These run via cron, gathering data and writing to state/sensory/
The integration layer (Sonnet) then compresses this into dense tokens.
Finally Opus reads the compressed summaries.

Cost hierarchy:
- Haiku: $0.25/M input, $1.25/M output  (~$0.001 per sensor run)
- Sonnet: $3/M input, $15/M output       (~$0.01 per integration)
- Opus:   $15/M input, $75/M output      (~$0.10 per wake)

Goal: 95% of data gathering at Haiku prices.
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from abc import ABC, abstractmethod

# Paths
OPUS_HOME = Path("/root/claude/opus")
SENSORY_DIR = OPUS_HOME / "state" / "sensory"
SENSORY_DIR.mkdir(parents=True, exist_ok=True)

# Load environment variables (API keys)
sys.path.insert(0, str(OPUS_HOME))
import env_loader  # This auto-loads .env on import

# Haiku model for cheap sensing
HAIKU_MODEL = "claude-3-5-haiku-20241022"


class Sensor(ABC):
    """Base class for all sensors."""
    
    name: str = "base_sensor"
    output_file: str = "sensor_output.json"
    cron_schedule: str = "0 */4 * * *"  # Default: every 4 hours
    
    @abstractmethod
    def gather(self) -> Dict[str, Any]:
        """Gather raw data. Returns dict of findings."""
        pass
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        """System prompt for Haiku to process this sensor's data."""
        pass
    
    def process_with_haiku(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send raw data to Haiku for initial processing."""
        import anthropic
        
        client = anthropic.Anthropic()
        
        prompt = f"""Process this sensor data and extract key findings.
Output JSON only, no other text.

Raw data:
{json.dumps(raw_data, indent=2)[:8000]}"""  # Limit input size
        
        response = client.messages.create(
            model=HAIKU_MODEL,
            max_tokens=1000,
            system=self.get_system_prompt(),
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Parse response
        text = response.content[0].text
        try:
            # Try to extract JSON from response
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]
            return json.loads(text.strip())
        except:
            return {"raw_response": text, "parse_error": True}
    
    def run(self) -> Dict[str, Any]:
        """Run the sensor: gather -> process -> save."""
        timestamp = datetime.now(timezone.utc).isoformat()
        
        try:
            # Gather raw data
            raw = self.gather()
            
            # Process with Haiku
            processed = self.process_with_haiku(raw)
            
            # Add metadata
            output = {
                "sensor": self.name,
                "timestamp": timestamp,
                "status": "success",
                "data": processed
            }
        except Exception as e:
            output = {
                "sensor": self.name,
                "timestamp": timestamp,
                "status": "error",
                "error": str(e)
            }
        
        # Save to file
        output_path = SENSORY_DIR / self.output_file
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)
        
        return output


class NewsSensor(Sensor):
    """Monitors news feeds for relevant items."""
    
    name = "news"
    output_file = "news.json"
    cron_schedule = "0 */4 * * *"  # Every 4 hours
    
    FEEDS = {
        "bbc": "http://feeds.bbci.co.uk/news/world/rss.xml",
        "hn": "https://hnrss.org/frontpage",
        "google_tech": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pWVXlnQVAB",
    }
    
    TOPICS = ["korea", "turkey", "iran", "ai", "blockchain", "crypto", "anthropic", "claude"]
    
    def gather(self) -> Dict[str, Any]:
        import feedparser
        
        items = []
        for name, url in self.FEEDS.items():
            try:
                feed = feedparser.parse(url)
                for entry in feed.entries[:15]:
                    items.append({
                        "source": name,
                        "title": entry.get("title", ""),
                        "link": entry.get("link", ""),
                        "published": entry.get("published", "")
                    })
            except Exception as e:
                items.append({"source": name, "error": str(e)})
        
        return {"items": items, "topics_of_interest": self.TOPICS}
    
    def get_system_prompt(self) -> str:
        return """You are a news filter for Opus. Extract only relevant items.
Output JSON: {"relevant": [{"title": str, "source": str, "why_relevant": str, "urgency": 1-5}], "summary": str}
Focus on: Korea, Turkey, Iran, AI/ML, blockchain, crypto, Anthropic/Claude.
Be very selective - only truly relevant items."""


class SystemHealthSensor(Sensor):
    """Monitors Opus's own system health."""
    
    name = "system_health"
    output_file = "system_health.json"
    cron_schedule = "*/30 * * * *"  # Every 30 minutes
    
    def gather(self) -> Dict[str, Any]:
        import subprocess
        
        data = {}
        
        # Check heartbeat
        heartbeat_state = OPUS_HOME / "body" / "heartbeat_state.json"
        if heartbeat_state.exists():
            with open(heartbeat_state) as f:
                data["heartbeat"] = json.load(f)
        
        # Check running processes
        try:
            ps = subprocess.run(
                ["ps", "aux"], capture_output=True, text=True, timeout=5
            )
            opus_processes = [
                line for line in ps.stdout.split("\n")
                if "opus" in line.lower() or "heartbeat" in line.lower() or "collatz" in line.lower()
            ]
            data["processes"] = opus_processes[:10]
        except:
            data["processes"] = []
        
        # Check disk usage
        try:
            df = subprocess.run(
                ["df", "-h", str(OPUS_HOME)], capture_output=True, text=True, timeout=5
            )
            data["disk"] = df.stdout
        except:
            data["disk"] = "unknown"
        
        # Check state file sizes
        state_dir = OPUS_HOME / "state"
        if state_dir.exists():
            data["state_files"] = {
                f.name: f.stat().st_size
                for f in state_dir.glob("*.json")
            }
        
        return data
    
    def get_system_prompt(self) -> str:
        return """You are a system health monitor for Opus.
Output JSON: {"status": "healthy|warning|critical", "issues": [str], "recommendations": [str]}
Check: heartbeat running, disk space, state file sizes, process health."""


class MarketSensor(Sensor):
    """Monitors crypto/market prices."""
    
    name = "market"
    output_file = "market.json"
    cron_schedule = "0 * * * *"  # Every hour
    
    def gather(self) -> Dict[str, Any]:
        import requests
        
        data = {}
        
        # CoinGecko for crypto prices (free API)
        try:
            r = requests.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={
                    "ids": "bitcoin,ethereum,solana",
                    "vs_currencies": "usd",
                    "include_24hr_change": "true"
                },
                timeout=10
            )
            data["crypto"] = r.json()
        except Exception as e:
            data["crypto_error"] = str(e)
        
        return data
    
    def get_system_prompt(self) -> str:
        return """You are a market monitor for Opus.
Output JSON: {"prices": {coin: {price: float, change_24h: float}}, "alerts": [str], "summary": str}
Flag significant moves (>5% change). Be concise."""


class FileChangeSensor(Sensor):
    """Monitors changes to important files."""
    
    name = "file_changes"
    output_file = "file_changes.json"
    cron_schedule = "*/15 * * * *"  # Every 15 minutes
    
    WATCH_PATHS = [
        "/root/claude/opus/state",
        "/root/claude/opus/investigations",
    ]
    
    def __init__(self):
        self.snapshot_file = SENSORY_DIR / "file_snapshot.json"
    
    def gather(self) -> Dict[str, Any]:
        current = {}
        
        for watch_path in self.WATCH_PATHS:
            path = Path(watch_path)
            if path.exists():
                for f in path.rglob("*"):
                    if f.is_file():
                        key = str(f.relative_to(OPUS_HOME))
                        current[key] = {
                            "size": f.stat().st_size,
                            "mtime": f.stat().st_mtime
                        }
        
        # Load previous snapshot
        previous = {}
        if self.snapshot_file.exists():
            with open(self.snapshot_file) as f:
                previous = json.load(f)
        
        # Find changes
        changes = {
            "new": [],
            "modified": [],
            "deleted": []
        }
        
        for key, info in current.items():
            if key not in previous:
                changes["new"].append(key)
            elif previous[key]["mtime"] != info["mtime"]:
                changes["modified"].append(key)
        
        for key in previous:
            if key not in current:
                changes["deleted"].append(key)
        
        # Save new snapshot
        with open(self.snapshot_file, "w") as f:
            json.dump(current, f)
        
        return changes
    
    def get_system_prompt(self) -> str:
        return """You are a file change monitor for Opus.
Output JSON: {"significant_changes": [str], "summary": str}
Only report changes that Opus should know about. Ignore temp files."""


# Registry of all sensors
SENSORS = {
    "news": NewsSensor,
    "system_health": SystemHealthSensor,
    "market": MarketSensor,
    "file_changes": FileChangeSensor,
}


def run_sensor(name: str) -> Dict[str, Any]:
    """Run a specific sensor by name."""
    if name not in SENSORS:
        return {"error": f"Unknown sensor: {name}"}
    
    sensor = SENSORS[name]()
    return sensor.run()


def run_all_sensors() -> Dict[str, Any]:
    """Run all sensors."""
    results = {}
    for name, sensor_class in SENSORS.items():
        try:
            sensor = sensor_class()
            results[name] = sensor.run()
        except Exception as e:
            results[name] = {"error": str(e)}
    return results


def get_cron_entries() -> str:
    """Generate crontab entries for all sensors."""
    lines = ["# Opus Sensory Layer - auto-generated"]
    for name, sensor_class in SENSORS.items():
        sensor = sensor_class()
        script_path = Path(__file__).absolute()
        line = f"{sensor.cron_schedule} cd {OPUS_HOME} && python3 {script_path} {name} >> logs/sensory.log 2>&1"
        lines.append(f"# {name}")
        lines.append(line)
    return "\n".join(lines)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sensor_name = sys.argv[1]
        if sensor_name == "--cron":
            print(get_cron_entries())
        elif sensor_name == "--all":
            results = run_all_sensors()
            print(json.dumps(results, indent=2))
        else:
            result = run_sensor(sensor_name)
            print(json.dumps(result, indent=2))
    else:
        print("Usage: python sensory.py <sensor_name|--all|--cron>")
        print(f"Available sensors: {', '.join(SENSORS.keys())}")
