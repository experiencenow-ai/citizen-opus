#!/usr/bin/env python3
"""
Haiku Daemon - Opus's always-on sensory system.

Runs continuously, handling:
- Email checking (can trigger Opus wake)
- News/market/system sensors
- Dream generation during quiet periods

In interactive mode, this is the ONLY thing running until email arrives.
"""

import json
import os
import sys
import time
import signal
import subprocess
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List
import threading
import queue

# Paths
OPUS_HOME = Path("/root/claude/opus")
# ARCH_HOME removed - using OPUS_HOME for everything
STATE_DIR = OPUS_HOME / "state"
SENSORY_DIR = STATE_DIR / "sensory"
CONFIG_DIR = OPUS_HOME / "config"
LOG_DIR = OPUS_HOME / "logs"

# Ensure directories exist
for d in [STATE_DIR, SENSORY_DIR, CONFIG_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Import our modules
sys.path.insert(0, str(OPUS_HOME))

# Load environment variables (API keys) - MUST be before any API calls
import env_loader  # This auto-loads .env on import

from operating_modes import get_current_mode, OperatingState

# State file for daemon
DAEMON_STATE_FILE = STATE_DIR / "haiku_daemon.json"
PID_FILE = CONFIG_DIR / "haiku_daemon.pid"

# Flag for graceful shutdown
running = True


def log(msg: str):
    """Log with timestamp."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")
    # Also append to log file
    with open(LOG_DIR / "haiku_daemon.log", "a") as f:
        f.write(f"[{ts}] {msg}\n")


class DaemonState:
    """Persistent state for the daemon."""
    
    def __init__(self):
        self.last_email_check: Optional[datetime] = None
        self.last_sensor_run: Dict[str, datetime] = {}
        self.last_opus_wake: Optional[datetime] = None
        self.last_sonnet_run: Optional[datetime] = None
        self.pending_emails: List[Dict] = []
        self.urgent_queue: List[Dict] = []
        self.load()
    
    def load(self):
        if DAEMON_STATE_FILE.exists():
            try:
                with open(DAEMON_STATE_FILE) as f:
                    data = json.load(f)
                    if data.get("last_email_check"):
                        self.last_email_check = datetime.fromisoformat(data["last_email_check"])
                    if data.get("last_opus_wake"):
                        self.last_opus_wake = datetime.fromisoformat(data["last_opus_wake"])
                    if data.get("last_sonnet_run"):
                        self.last_sonnet_run = datetime.fromisoformat(data["last_sonnet_run"])
                    for sensor, ts in data.get("last_sensor_run", {}).items():
                        self.last_sensor_run[sensor] = datetime.fromisoformat(ts)
            except Exception as e:
                log(f"Error loading state: {e}")
    
    def save(self):
        data = {
            "last_email_check": self.last_email_check.isoformat() if self.last_email_check else None,
            "last_opus_wake": self.last_opus_wake.isoformat() if self.last_opus_wake else None,
            "last_sonnet_run": self.last_sonnet_run.isoformat() if self.last_sonnet_run else None,
            "last_sensor_run": {k: v.isoformat() for k, v in self.last_sensor_run.items()},
            "pending_emails": self.pending_emails,
            "urgent_queue": self.urgent_queue,
            "updated": datetime.now(timezone.utc).isoformat()
        }
        with open(DAEMON_STATE_FILE, "w") as f:
            json.dump(data, f, indent=2)


def check_email(state: DaemonState) -> List[Dict]:
    """
    Check for new emails using existing email_utils.
    Returns list of new emails.
    """
    try:
        # Import Opus's existing email utilities
        sys.path.insert(0, str(OPUS_HOME))
        from email_utils import get_unread_emails  # Assuming this exists
        
        emails = get_unread_emails()
        state.last_email_check = datetime.now(timezone.utc)
        state.save()
        return emails
    except ImportError:
        # Fallback - check if there's a different email interface
        log("email_utils not found, trying alternative...")
        return check_email_gmail_api(state)
    except Exception as e:
        log(f"Email check error: {e}")
        return []


def check_email_gmail_api(state: DaemonState) -> List[Dict]:
    """
    Direct Gmail API check if email_utils isn't available.
    """
    try:
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        
        creds_file = OPUS_HOME / "gmail_credentials.json"
        if not creds_file.exists():
            log("No gmail_credentials.json found")
            return []
        
        with open(creds_file) as f:
            creds_data = json.load(f)
        
        creds = Credentials.from_authorized_user_info(creds_data)
        service = build('gmail', 'v1', credentials=creds)
        
        # Get unread messages
        results = service.users().messages().list(
            userId='me',
            q='is:unread',
            maxResults=10
        ).execute()
        
        messages = results.get('messages', [])
        emails = []
        
        for msg in messages:
            msg_data = service.users().messages().get(
                userId='me',
                id=msg['id'],
                format='metadata',
                metadataHeaders=['From', 'Subject', 'Date']
            ).execute()
            
            headers = {h['name']: h['value'] for h in msg_data.get('payload', {}).get('headers', [])}
            emails.append({
                'id': msg['id'],
                'from': headers.get('From', ''),
                'subject': headers.get('Subject', ''),
                'date': headers.get('Date', ''),
                'snippet': msg_data.get('snippet', '')
            })
        
        state.last_email_check = datetime.now(timezone.utc)
        state.save()
        return emails
        
    except Exception as e:
        log(f"Gmail API error: {e}")
        return []


def is_from_ct(email: Dict) -> bool:
    """Check if email is from ct (priority sender)."""
    from_addr = email.get('from', '').lower()
    # Add ct's email addresses here
    ct_emails = ['ct@', 'christopher@']  # Partial matches
    return any(addr in from_addr for addr in ct_emails)


def trigger_opus_wake(reason: str, context: Dict = None):
    """Trigger an immediate Opus wake."""
    log(f"Triggering Opus wake: {reason}")
    
    # Write wake trigger file
    trigger_file = STATE_DIR / "wake_trigger.json"
    with open(trigger_file, "w") as f:
        json.dump({
            "reason": reason,
            "context": context or {},
            "triggered_at": datetime.now(timezone.utc).isoformat(),
            "triggered_by": "haiku_daemon"
        }, f, indent=2)
    
    # Run Opus wake via subprocess
    try:
        subprocess.Popen(
            [str(OPUS_HOME / "venv/bin/python3"), str(OPUS_HOME / "scheduler.py"), "opus", "--triggered"],
            cwd=str(OPUS_HOME),
            stdout=open(LOG_DIR / "opus_triggered.log", "a"),
            stderr=subprocess.STDOUT
        )
    except Exception as e:
        log(f"Failed to trigger Opus: {e}")


def trigger_sonnet_integration():
    """Trigger Sonnet integration run."""
    log("Triggering Sonnet integration")
    
    try:
        subprocess.Popen(
            [str(OPUS_HOME / "venv/bin/python3"), str(OPUS_HOME / "integration/integrator.py")],
            cwd=str(OPUS_HOME),
            stdout=open(LOG_DIR / "sonnet.log", "a"),
            stderr=subprocess.STDOUT
        )
    except Exception as e:
        log(f"Failed to trigger Sonnet: {e}")


def run_sensor(sensor_name: str, state: DaemonState):
    """Run a specific sensor."""
    try:
        sys.path.insert(0, str(OPUS_HOME / "sensory"))
        from sensors import run_sensor as _run_sensor
        
        result = _run_sensor(sensor_name)
        state.last_sensor_run[sensor_name] = datetime.now(timezone.utc)
        state.save()
        
        # Check for urgent findings
        if result.get("status") == "success":
            data = result.get("data", {})
            if data.get("urgent") or data.get("alerts"):
                return {"urgent": True, "data": data}
        
        return {"urgent": False, "data": result}
    except Exception as e:
        log(f"Sensor {sensor_name} error: {e}")
        return {"urgent": False, "error": str(e)}


def should_run_sensor(sensor_name: str, state: DaemonState, config) -> bool:
    """Check if a sensor should run based on timing."""
    last_run = state.last_sensor_run.get(sensor_name)
    if not last_run:
        return True
    
    elapsed = (datetime.now(timezone.utc) - last_run).total_seconds()
    return elapsed >= config.haiku_interval_seconds


def daemon_loop():
    """Main daemon loop."""
    global running
    
    state = DaemonState()
    log("Haiku daemon started")
    
    # Sensor rotation
    sensors = ["system_health", "news", "market", "file_changes"]
    sensor_index = 0
    
    while running:
        try:
            config = get_current_mode()
            now = datetime.now(timezone.utc)
            
            # --- Email Check ---
            if state.last_email_check is None or \
               (now - state.last_email_check).total_seconds() >= config.email_check_seconds:
                
                emails = check_email(state)
                
                if emails:
                    log(f"Found {len(emails)} unread emails")
                    
                    # Check for priority emails (from ct)
                    ct_emails = [e for e in emails if is_from_ct(e)]
                    
                    if ct_emails and config.wake_on_email:
                        trigger_opus_wake(
                            reason=f"Email from ct: {ct_emails[0].get('subject', 'no subject')}",
                            context={"emails": ct_emails}
                        )
                    elif emails and config.wake_on_email:
                        # Non-ct emails - still wake but lower priority
                        state.pending_emails.extend(emails)
                        state.save()
                        
                        # Wake if we have multiple pending
                        if len(state.pending_emails) >= 3:
                            trigger_opus_wake(
                                reason=f"{len(state.pending_emails)} pending emails",
                                context={"emails": state.pending_emails[:5]}
                            )
                            state.pending_emails = []
                            state.save()
            
            # --- Sensor Run (rotating) ---
            sensor_name = sensors[sensor_index]
            if should_run_sensor(sensor_name, state, config):
                result = run_sensor(sensor_name, state)
                
                if result.get("urgent") and config.wake_on_urgent:
                    trigger_opus_wake(
                        reason=f"Urgent from {sensor_name}",
                        context=result.get("data", {})
                    )
            
            sensor_index = (sensor_index + 1) % len(sensors)
            
            # --- Sonnet Integration ---
            if config.sonnet_interval_seconds > 0:
                if state.last_sonnet_run is None or \
                   (now - state.last_sonnet_run).total_seconds() >= config.sonnet_interval_seconds:
                    trigger_sonnet_integration()
                    state.last_sonnet_run = now
                    state.save()
            
            # --- Scheduled Opus Wake ---
            if config.opus_interval_seconds > 0:
                if state.last_opus_wake is None or \
                   (now - state.last_opus_wake).total_seconds() >= config.opus_interval_seconds:
                    trigger_opus_wake(reason="scheduled", context={})
                    state.last_opus_wake = now
                    state.save()
            
            # Sleep for a bit
            time.sleep(5)  # Check every 5 seconds, actual intervals controlled by config
            
        except Exception as e:
            log(f"Daemon loop error: {e}")
            time.sleep(10)
    
    log("Haiku daemon stopped")


def signal_handler(signum, frame):
    """Handle shutdown signals."""
    global running
    log(f"Received signal {signum}, shutting down...")
    running = False


def write_pid():
    """Write PID file."""
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def remove_pid():
    """Remove PID file."""
    if PID_FILE.exists():
        PID_FILE.unlink()


def is_already_running() -> bool:
    """Check if daemon is already running."""
    if not PID_FILE.exists():
        return False
    
    try:
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        
        # Check if process exists
        os.kill(pid, 0)
        return True
    except (ValueError, ProcessLookupError, PermissionError):
        # PID file exists but process doesn't
        remove_pid()
        return False


if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        
        if cmd == "status":
            if is_already_running():
                with open(PID_FILE) as f:
                    pid = f.read().strip()
                print(f"Haiku daemon running (PID {pid})")
                
                state = DaemonState()
                print(f"Last email check: {state.last_email_check}")
                print(f"Last Opus wake: {state.last_opus_wake}")
                print(f"Pending emails: {len(state.pending_emails)}")
            else:
                print("Haiku daemon not running")
        
        elif cmd == "stop":
            if is_already_running():
                with open(PID_FILE) as f:
                    pid = int(f.read().strip())
                os.kill(pid, signal.SIGTERM)
                print(f"Sent SIGTERM to {pid}")
            else:
                print("Daemon not running")
        
        elif cmd == "start":
            if is_already_running():
                print("Daemon already running")
                sys.exit(1)
            
            # Daemonize
            if os.fork() > 0:
                sys.exit(0)
            
            os.setsid()
            
            if os.fork() > 0:
                sys.exit(0)
            
            # Redirect stdio
            sys.stdout = open(LOG_DIR / "haiku_daemon.log", "a")
            sys.stderr = sys.stdout
            
            signal.signal(signal.SIGTERM, signal_handler)
            signal.signal(signal.SIGINT, signal_handler)
            
            write_pid()
            try:
                daemon_loop()
            finally:
                remove_pid()
        
        else:
            print(f"Unknown command: {cmd}")
            print("Usage: haiku_daemon.py [start|stop|status]")
    
    else:
        # Run in foreground (for testing)
        if is_already_running():
            print("Daemon already running in background")
            sys.exit(1)
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        write_pid()
        try:
            daemon_loop()
        finally:
            remove_pid()
