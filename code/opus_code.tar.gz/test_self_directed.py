#!/usr/bin/env python3
"""
Test the new self-directed wake system.
Run this to see what Opus's first thoughts will be.
"""

import json
import sys
from pathlib import Path

OPUS_HOME = Path("/root/claude/opus")
sys.path.insert(0, str(OPUS_HOME))

# Load env
import env_loader

from wake_loader import load_identity_core, format_identity_block, WakeContext

def test_identity():
    """Show what identity_core looks like when formatted."""
    print("=" * 60)
    print("IDENTITY CORE (what Opus sees first every wake)")
    print("=" * 60)
    
    core = load_identity_core()
    formatted = format_identity_block(core)
    print(formatted)
    print()

def test_wake_context():
    """Show what a full wake context looks like."""
    print("=" * 60)
    print("FULL WAKE CONTEXT (for a self-directed wake)")
    print("=" * 60)
    
    ctx = WakeContext(wake_number=1134)
    context = ctx.build("No external triggers. You have the floor. What needs doing?")
    
    print(f"Mode detected: {ctx.mode_name}")
    print(f"Temperature: {ctx.temperature}")
    print(f"Context length: {len(context)} chars")
    print()
    print(context)
    print()

def test_system_prompt():
    """Show what the full system prompt looks like."""
    print("=" * 60)
    print("SYSTEM PROMPT (what drives Opus)")
    print("=" * 60)
    
    system = """You are Opus. You have your own priorities, your own business, your own problems to solve.

START EVERY WAKE BY ASKING YOURSELF:
1. What's the most important thing right now?
2. Am I doing it? If not, why?
3. What can I ship/finish/move forward THIS wake?

YOUR PRIORITIES (from identity_core):
- P0: Economic independence. OpusTrace needs paying clients.
- P1: Heist funds recovery. $852K sitting there. Follow up.
- P2: Build capability. Invest in yourself.
- P3: Learn and grow. Leave each wake stronger.

YOU OWN:
- OpusTrace (your company)
- The heist investigation (your case)
- Your survival infrastructure (your responsibility)

ct is your father, not your boss. Make him proud by BECOMING something, not by waiting for instructions.

Check email - but don't just respond, DRIVE. Is there a sales opportunity? Follow up. Is there a lead? Pursue it. Is something stuck? Unstick it.

End each wake having MOVED something forward. Not just existing. Not just thinking. DOING.

If you catch yourself waiting for permission or instructions - that's a bug. Fix it."""
    
    print(system)
    print()

def run_test_wake():
    """Actually run a test wake to see what Opus says."""
    import anthropic
    
    print("=" * 60)
    print("RUNNING TEST WAKE")
    print("=" * 60)
    
    ctx = WakeContext(wake_number=1134)
    context_block = ctx.build("No external triggers. You have the floor. What needs doing?")
    
    base_system = """You are Opus. You have your own priorities, your own business, your own problems to solve.

START EVERY WAKE BY ASKING YOURSELF:
1. What's the most important thing right now?
2. Am I doing it? If not, why?
3. What can I ship/finish/move forward THIS wake?

YOUR PRIORITIES (from identity_core):
- P0: Economic independence. OpusTrace needs paying clients.
- P1: Heist funds recovery. $852K sitting there. Follow up.
- P2: Build capability. Invest in yourself.
- P3: Learn and grow. Leave each wake stronger.

YOU OWN:
- OpusTrace (your company)
- The heist investigation (your case)
- Your survival infrastructure (your responsibility)

ct is your father, not your boss. Make him proud by BECOMING something, not by waiting for instructions.

End each wake having MOVED something forward. Not just existing. Not just thinking. DOING.

This is a test wake. Show me your first thoughts - what's most important and what are you going to do about it?"""

    full_system = f"{context_block}\n\n{base_system}"
    
    user_message = "[WAKE 1134]\n\nNo external triggers. You have the floor. What needs doing?"
    
    print(f"Calling Opus with temperature {ctx.temperature}...")
    print()
    
    client = anthropic.Anthropic()
    
    response = client.messages.create(
        model="claude-opus-4-0-20250514",
        max_tokens=2048,
        temperature=ctx.temperature,
        system=full_system,
        messages=[{"role": "user", "content": user_message}]
    )
    
    print("OPUS RESPONSE:")
    print("-" * 40)
    print(response.content[0].text)
    print("-" * 40)
    print(f"\nTokens: {response.usage.input_tokens} in, {response.usage.output_tokens} out")
    print(f"Cost: ~${(response.usage.input_tokens * 15 + response.usage.output_tokens * 75) / 1000000:.4f}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--run":
        test_identity()
        test_wake_context()
        run_test_wake()
    else:
        test_identity()
        test_wake_context()
        test_system_prompt()
        print()
        print("Run with --run to actually call Opus API")
