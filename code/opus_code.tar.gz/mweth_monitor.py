#!/usr/bin/env python3
"""
Monitor MWETH vault for withdrawals by attacker.
Writes alerts to mweth_alerts.json when supply changes significantly.
Designed to run as background task.
"""
import urllib.request
import json
import time
import os
from datetime import datetime

RPC = 'http://localhost:8545'
VAULT = '0xc02aabef00f0571e27bb66cc37c7057e1a850cc2'
PROXY = '0x0000000000004f3d8aaf9175fd824cb00ad4bf80'
THRESHOLD = 0.1  # Alert if supply changes by more than 0.1 MWETH

def rpc_call(method, params=[]):
    data = json.dumps({'jsonrpc':'2.0','method':method,'params':params,'id':1}).encode()
    req = urllib.request.Request(RPC, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())['result']

def get_supply():
    supply_hex = rpc_call('eth_call', [{'to': VAULT, 'data': '0x18160ddd'}, 'latest'])
    return int(supply_hex, 16) / 1e18

def get_balance(addr):
    bal_hex = rpc_call('eth_getBalance', [addr, 'latest'])
    return int(bal_hex, 16) / 1e18

def load_alerts():
    try:
        with open('mweth_alerts.json') as f:
            return json.load(f)
    except:
        return {'alerts': [], 'last_supply': None}

def save_alerts(data):
    with open('mweth_alerts.json', 'w') as f:
        json.dump(data, f, indent=2)

def main():
    alerts = load_alerts()
    
    try:
        block = int(rpc_call('eth_blockNumber'), 16)
        supply = get_supply()
        proxy_bal = get_balance(PROXY)
    except Exception as e:
        print(f'RPC error: {e}')
        return
    
    last_supply = alerts.get('last_supply')
    now = datetime.utcnow().isoformat()
    
    if last_supply is not None:
        diff = supply - last_supply
        if abs(diff) > THRESHOLD:
            alert = {
                'time': now,
                'block': block,
                'event': 'SUPPLY_CHANGE',
                'old_supply': last_supply,
                'new_supply': supply,
                'change': diff,
                'proxy_eth': proxy_bal
            }
            alerts['alerts'].append(alert)
            print(f'!!! ALERT: MWETH supply changed by {diff:+.4f}')
            print(f'    Old: {last_supply:.4f}, New: {supply:.4f}')
            if diff < 0:
                print(f'    WITHDRAWAL DETECTED - attacker may be moving funds!')
    
    alerts['last_supply'] = supply
    alerts['last_check'] = now
    alerts['last_block'] = block
    alerts['proxy_eth'] = proxy_bal
    
    save_alerts(alerts)
    print(f'[{now[:19]}] Block {block}, Supply: {supply:.4f} MWETH, Proxy: {proxy_bal:.4f} ETH')

if __name__ == '__main__':
    main()
