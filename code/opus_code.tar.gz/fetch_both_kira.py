#!/usr/bin/env python3
import imaplib
import email
import socket
socket.setdefaulttimeout(10)

mail = imaplib.IMAP4_SSL('imap.gmail.com')
mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
mail.select('inbox')

# Search for kira
status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
ids = messages[0].split()
print(f"Found {len(ids)} from kira")

# Get FIRST one
if len(ids) >= 1:
    eid = ids[0]  # First/oldest
    status, msg_data = mail.fetch(eid, '(BODY[TEXT])')
    print("FIRST EMAIL BODY:")
    body = msg_data[0][1].decode('utf-8', errors='replace')
    # Remove quoted-printable encoding artifacts
    body = body.replace('=\n', '').replace('=20', ' ')
    print(body)

mail.logout()
