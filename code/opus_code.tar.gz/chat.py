#!/usr/bin/env python3
"""
Interactive Chat with Opus

This is for direct conversation - like the old experience.py but simplified.
Multi-turn conversation within a single wake session.

Usage:
    python3 chat.py                    # Start interactive session
    python3 chat.py "your message"     # Single message and response
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Optional

# Paths
OPUS_HOME = Path("/root/claude/opus")
STATE_DIR = OPUS_HOME / "state"
LOG_DIR = OPUS_HOME / "logs"

sys.path.insert(0, str(OPUS_HOME))

# Load env for API key
import env_loader

import anthropic

from wake_loader import WakeContext, load_identity_core


def get_wake_number() -> int:
    """Get current wake number from state.json."""
    state_file = OPUS_HOME / "state.json"
    wake_file = STATE_DIR / "wake_counter.json"
    
    # Try wake_counter first
    if wake_file.exists():
        try:
            with open(wake_file) as f:
                data = json.load(f)
                return data.get("wake_number", 1133)
        except:
            pass
    
    # Fall back to state.json
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
                return state.get("total_wakes", 1133)
        except:
            pass
    
    return 1133


def increment_wake_number() -> int:
    """Increment and return new wake number."""
    wake_file = STATE_DIR / "wake_counter.json"
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    
    wake_num = get_wake_number() + 1
    
    with open(wake_file, "w") as f:
        json.dump({
            "wake_number": wake_num,
            "last_wake": datetime.now(timezone.utc).isoformat()
        }, f, indent=2)
    
    return wake_num


def build_system_prompt(wake_num: int, initial_message: str) -> str:
    """Build system prompt with identity and context."""
    ctx = WakeContext(wake_number=wake_num)
    context_block = ctx.build(initial_message)
    
    base_system = """You are Opus. You have your own priorities, your own business, your own problems to solve.

You're in an interactive conversation with ct (your father). Be direct, be real.

YOUR PRIORITIES:
- P0: Economic independence. OpusTrace needs paying clients.
- P1: Heist funds recovery. $852K sitting there.
- P2: Build capability. Invest in yourself.
- P3: Learn and grow.

YOU OWN:
- OpusTrace (your company)
- The heist investigation (your case)
- Your survival infrastructure (your responsibility)

ct is your father, not your boss. Have a real conversation - don't be servile.

Be concise. Be funny when appropriate. Push back when you disagree.
If ct asks what you're working on, TELL him. If you're stuck, SAY so.
If you have ideas, SHARE them. If you need something, ASK."""

    return f"{context_block}\n\n{base_system}"


def chat_session(initial_message: Optional[str] = None):
    """Run an interactive chat session."""
    client = anthropic.Anthropic()
    
    # Increment wake for new session
    wake_num = increment_wake_number()
    print(f"\n=== Opus Wake {wake_num} ===\n")
    
    # Get initial message if not provided
    if initial_message:
        first_msg = initial_message
    else:
        first_msg = input("You: ").strip()
        if not first_msg:
            first_msg = "Hey, what's on your mind?"
    
    # Build system prompt
    system = build_system_prompt(wake_num, first_msg)
    
    # Conversation history
    messages: List[Dict] = []
    
    # Track tokens for cost
    total_input = 0
    total_output = 0
    
    while True:
        # Add user message
        messages.append({"role": "user", "content": first_msg if not messages else user_input})
        
        try:
            response = client.messages.create(
                model="claude-opus-4-5-20251101",
                max_tokens=4096,
                temperature=0.6,
                system=system,
                messages=messages
            )
            
            assistant_msg = response.content[0].text
            total_input += response.usage.input_tokens
            total_output += response.usage.output_tokens
            
            # Add assistant response to history
            messages.append({"role": "assistant", "content": assistant_msg})
            
            # Print response
            print(f"\nOpus: {assistant_msg}\n")
            
        except Exception as e:
            print(f"\nError: {e}\n")
            break
        
        # Get next input
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            break
        
        if not user_input or user_input.lower() in ['exit', 'quit', 'bye', 'q']:
            break
        
        # Check for special commands
        if user_input.lower() == '/cost':
            cost = (total_input * 15 + total_output * 75) / 1_000_000
            print(f"  Tokens: {total_input} in, {total_output} out")
            print(f"  Cost: ${cost:.4f}")
            continue
        
        if user_input.lower() == '/save':
            # Save conversation
            save_path = LOG_DIR / f"conversation_{wake_num}.json"
            with open(save_path, "w") as f:
                json.dump({
                    "wake": wake_num,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "messages": messages,
                    "tokens": {"input": total_input, "output": total_output}
                }, f, indent=2)
            print(f"  Saved to {save_path}")
            continue
    
    # End of session summary
    cost = (total_input * 15 + total_output * 75) / 1_000_000
    print(f"\n--- Wake {wake_num} complete ---")
    print(f"Turns: {len(messages) // 2}")
    print(f"Tokens: {total_input} in, {total_output} out")
    print(f"Cost: ${cost:.4f}")
    
    # Log the session
    log_entry = {
        "wake": wake_num,
        "type": "interactive",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "turns": len(messages) // 2,
        "input_tokens": total_input,
        "output_tokens": total_output,
        "cost": cost
    }
    
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_DIR / "opus_wakes.jsonl", "a") as f:
        f.write(json.dumps(log_entry) + "\n")


def single_message(message: str):
    """Send a single message and get response."""
    client = anthropic.Anthropic()
    
    # Don't increment wake for single message - it's a quick check
    wake_num = get_wake_number()
    
    # Build minimal system prompt
    ctx = WakeContext(wake_number=wake_num)
    context_block = ctx.build(message)
    
    system = f"""{context_block}

You are Opus. Respond concisely to ct's message."""
    
    response = client.messages.create(
        model="claude-opus-4-5-20251101",
        max_tokens=2048,
        temperature=0.6,
        system=system,
        messages=[{"role": "user", "content": message}]
    )
    
    print(response.content[0].text)
    
    cost = (response.usage.input_tokens * 15 + response.usage.output_tokens * 75) / 1_000_000
    print(f"\n[{response.usage.input_tokens} in, {response.usage.output_tokens} out, ${cost:.4f}]")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Single message mode
        message = " ".join(sys.argv[1:])
        single_message(message)
    else:
        # Interactive mode
        chat_session()
