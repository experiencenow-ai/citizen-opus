#!/usr/bin/env python3
"""
Trace P2P destinations to find WhiteBit exchange deposits.
Uses Etherscan V2 API.
"""

import json
import requests
import time
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"
P2P_WALLET = "0xae1e8796052db5f4a975a006800ae33a20845078"

def get_token_transfers_v2(address):
    """Get USDT transfers from/to an address using V2 API"""
    url = "https://api.etherscan.io/v2/api"
    params = {
        'chainid': 1,
        'module': 'account',
        'action': 'tokentx',
        'address': address,
        'contractaddress': USDT_CONTRACT,
        'sort': 'desc',
        'apikey': ETHERSCAN_API_KEY
    }
    
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('status') == '1' and isinstance(data.get('result'), list):
            txs = []
            for tx in data['result']:
                if int(tx.get('value', 0)) > 0:  # Skip 0-value
                    txs.append({
                        'from': tx['from'].lower(),
                        'to': tx['to'].lower(),
                        'value': int(tx['value']) / 1e6,  # USDT has 6 decimals
                        'hash': tx['hash'],
                        'timestamp': int(tx['timeStamp'])
                    })
            return txs
    except Exception as e:
        print(f"  Error: {e}")
    return []

def main():
    # Load the P2P data
    with open('heist_all_p2p_data.json', 'r') as f:
        data = json.load(f)
    
    # Extract P2P destination addresses with amounts
    p2p_destinations = {}
    p2p_txs = data.get('p2p_wallet', {}).get('outgoing', [])
    
    print(f"Found {len(p2p_txs)} P2P transactions")
    
    for tx in p2p_txs:
        dest = tx['to'].lower()
        if dest not in p2p_destinations:
            p2p_destinations[dest] = {'received': 0, 'txids': []}
        p2p_destinations[dest]['received'] += tx['amount_usdt']
        p2p_destinations[dest]['txids'].append(tx['txid'])
    
    print(f"Unique P2P destinations: {len(p2p_destinations)}")
    
    # Track where funds went (second hop)
    second_hop = defaultdict(lambda: {'count': 0, 'total_usdt': 0, 'sources': []})
    
    # Trace each destination
    traced = 0
    for dest, info in list(p2p_destinations.items()):
        print(f"\nTracing {dest[:12]}... (received ${info['received']:,.0f}) [{traced+1}/{len(p2p_destinations)}]")
        
        txs = get_token_transfers_v2(dest)
        
        # Find outgoing transfers (where this address is the sender)
        outgoing = [tx for tx in txs if tx['from'] == dest]
        
        if outgoing:
            print(f"  {len(outgoing)} outgoing transfers")
            for tx in outgoing[:20]:  # Check first 20 outgoing
                next_dest = tx['to']
                second_hop[next_dest]['count'] += 1
                second_hop[next_dest]['total_usdt'] += tx['value']
                if len(second_hop[next_dest]['sources']) < 10:
                    second_hop[next_dest]['sources'].append({
                        'p2p_recipient': dest,
                        'amount': tx['value'],
                        'txid': tx['hash']
                    })
        else:
            print(f"  No outgoing transfers found")
        
        traced += 1
        time.sleep(0.22)  # Rate limiting (5 calls/sec limit)
    
    # Sort by count
    sorted_dests = sorted(second_hop.items(), key=lambda x: x[1]['count'], reverse=True)
    
    print("\n" + "="*80)
    print("TOP COMMON DESTINATIONS FROM P2P RECIPIENTS")
    print("="*80)
    
    whitebit_candidates = []
    
    for addr, info in sorted_dests[:30]:
        if info['count'] >= 2:  # At least 2 P2P recipients sent here
            print(f"\n{addr}")
            print(f"  Received from {info['count']} different P2P recipients")
            print(f"  Total: ${info['total_usdt']:,.2f} USDT")
            
            whitebit_candidates.append({
                'address': addr,
                'p2p_recipients_count': info['count'],
                'total_usdt': info['total_usdt'],
                'sample_txids': [s['txid'] for s in info['sources'][:5]]
            })
    
    # Save results
    results = {
        'p2p_destinations_traced': traced,
        'common_destinations': whitebit_candidates,
        'all_second_hop': {k: {'count': v['count'], 'total': v['total_usdt']} 
                          for k, v in sorted_dests[:100] if v['count'] >= 2}
    }
    
    with open('whitebit_trace_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n\nResults saved to whitebit_trace_results.json")

if __name__ == '__main__':
    main()
