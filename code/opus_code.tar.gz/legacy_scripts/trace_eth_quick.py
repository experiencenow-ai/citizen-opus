#!/usr/bin/env python3
"""
Quick trace of top P2P destinations on Ethereum
"""

import json
import time
import requests
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
ETH_API = "https://api.etherscan.io/v2/api"

# Known exchange addresses
KNOWN_EXCHANGES = {
    # WhiteBIT (common deposit addresses)
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance 14",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 15", 
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 16",
    "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance 8",
    # OKX
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    "0x98ec059dc3adfbdd63429454aeb0c990fba4a128": "OKX Hot",
    # Bybit
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    # KuCoin
    "0x2b5634c42055806a59e9107ed44d43c426e58258": "KuCoin",
    # HTX
    "0xab5c66752a9e8167967685f1450532fb96d5d24f": "HTX",
}

def get_eth_token_txs(address):
    """Get token transactions from Ethereum"""
    try:
        params = {
            "chainid": 1,
            "module": "account",
            "action": "tokentx",
            "address": address,
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(ETH_API, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        pass
    return []

# Get P2P wallet transactions
p2p_wallet = "0xae1e8796052db5f4a975a006800ae33a20845078"
p2p_txs = get_eth_token_txs(p2p_wallet)
print(f"P2P wallet transactions: {len(p2p_txs)}")

# Get outgoing
outgoing = [tx for tx in p2p_txs if tx.get("from", "").lower() == p2p_wallet.lower()]
print(f"Outgoing: {len(outgoing)}")

# Get destinations
destinations = defaultdict(lambda: {"amount": 0, "txids": []})
for tx in outgoing:
    to_addr = tx.get("to", "").lower()
    value = float(tx.get("value", 0)) / 1e6
    if value > 0:
        destinations[to_addr]["amount"] += value
        destinations[to_addr]["txids"].append(tx.get("hash"))

# Sort and take top 30
sorted_dests = sorted(destinations.items(), key=lambda x: x[1]["amount"], reverse=True)[:30]

print(f"\nTracing top 30 destinations (of {len(destinations)} total)")
print("=" * 70)

final_dests = defaultdict(lambda: {"amount": 0, "sources": [], "txids": []})

for i, (addr, info) in enumerate(sorted_dests):
    amt = info["amount"]
    
    # Check if direct exchange
    if addr in [k.lower() for k in KNOWN_EXCHANGES]:
        for k, v in KNOWN_EXCHANGES.items():
            if k.lower() == addr:
                print(f"[{i+1:2d}] ${amt:>10,.0f} -> {v} (direct)")
                final_dests[v]["amount"] += amt
                final_dests[v]["sources"].append(addr)
                break
        continue
    
    time.sleep(0.2)
    addr_txs = get_eth_token_txs(addr)
    addr_out = [tx for tx in addr_txs if tx.get("from", "").lower() == addr]
    
    if not addr_out:
        print(f"[{i+1:2d}] ${amt:>10,.0f} -> Still in wallet ({addr[:12]}...)")
        final_dests["Still in wallet"]["amount"] += amt
        final_dests["Still in wallet"]["sources"].append(addr)
        continue
    
    # Find where it went
    out_dests = defaultdict(float)
    for tx in addr_out:
        to = tx.get("to", "").lower()
        val = float(tx.get("value", 0)) / 1e6
        out_dests[to] += val
    
    # Check for known exchanges
    found = False
    for to_addr, to_amt in sorted(out_dests.items(), key=lambda x: x[1], reverse=True)[:3]:
        for k, v in KNOWN_EXCHANGES.items():
            if k.lower() == to_addr:
                print(f"[{i+1:2d}] ${amt:>10,.0f} -> {v} (via {addr[:8]}...)")
                final_dests[v]["amount"] += to_amt
                final_dests[v]["sources"].append(addr)
                found = True
                break
        if found:
            break
    
    if not found:
        primary = max(out_dests.items(), key=lambda x: x[1])
        print(f"[{i+1:2d}] ${amt:>10,.0f} -> {primary[0][:16]}... ${primary[1]:,.0f}")
        final_dests[f"Unknown:{primary[0][:16]}"]["amount"] += primary[1]
        final_dests[f"Unknown:{primary[0][:16]}"]["sources"].append(addr)

print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)

for dest, info in sorted(final_dests.items(), key=lambda x: x[1]["amount"], reverse=True)[:15]:
    print(f"{dest:30s} ${info['amount']:>12,.2f} from {len(info['sources']):3d} wallets")

# Save
with open("heist_eth_trace.json", "w") as f:
    json.dump({k: {"amount": v["amount"], "sources": len(v["sources"])} for k, v in final_dests.items()}, f, indent=2)

print("\nSaved to heist_eth_trace.json")
