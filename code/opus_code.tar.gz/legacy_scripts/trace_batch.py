#!/usr/bin/env python3
"""
Batch trace P2P destinations - process in chunks with progress saving
"""

import json
import time
import requests
from collections import defaultdict
import os

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
ETH_API = "https://api.etherscan.io/v2/api"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

KNOWN_EXCHANGES = {
    # WhiteBIT
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance",
    "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance",
    "0x5a52e96bacdabb82fd05763e25335261b270efcb": "Binance",
    # OKX
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    "0x98ec059dc3adfbdd63429454aeb0c990fba4a128": "OKX",
    # Bybit
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    # KuCoin
    "0x2b5634c42055806a59e9107ed44d43c426e58258": "KuCoin",
    # HTX
    "0xab5c66752a9e8167967685f1450532fb96d5d24f": "HTX",
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    # MEXC
    "0x3cc936b795a188f0e246cbb2d74c5bd190aecf18": "MEXC",
}

def get_usdt_txs(address):
    try:
        params = {
            "chainid": 1, "module": "account", "action": "tokentx",
            "address": address, "contractaddress": USDT_CONTRACT,
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(ETH_API, params=params, timeout=8)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except:
        pass
    return []

# Load destinations
with open("heist_p2p_eth_destinations.json", "r") as f:
    data = json.load(f)

destinations = list(data["destinations"].items())
print(f"Total destinations to trace: {len(destinations)}")

# Load progress if exists
progress_file = "trace_progress.json"
if os.path.exists(progress_file):
    with open(progress_file, "r") as f:
        progress = json.load(f)
    start_idx = progress.get("processed", 0)
    results = progress.get("results", {})
    print(f"Resuming from index {start_idx}")
else:
    start_idx = 0
    results = {}

# Process in batches
batch_size = 30  # Process 30 at a time
end_idx = min(start_idx + batch_size, len(destinations))

print(f"Processing indices {start_idx} to {end_idx-1}...")
print("=" * 60)

for i in range(start_idx, end_idx):
    addr, amt = destinations[i]
    addr_lower = addr.lower()
    
    # Check if direct exchange
    exchange = None
    for k, v in KNOWN_EXCHANGES.items():
        if k.lower() == addr_lower:
            exchange = v
            break
    
    if exchange:
        print(f"[{i:3d}] ${amt:>8,.0f} -> {exchange} (direct)")
        results[addr] = {"type": "exchange", "exchange": exchange, "amount": amt}
        continue
    
    # Rate limit
    time.sleep(0.22)
    
    # Get outgoing
    txs = get_usdt_txs(addr)
    outgoing = [tx for tx in txs if tx.get("from", "").lower() == addr_lower]
    
    if not outgoing:
        print(f"[{i:3d}] ${amt:>8,.0f} -> Still in wallet")
        results[addr] = {"type": "still_in_wallet", "amount": amt}
        continue
    
    # Group by destination
    out_dests = defaultdict(float)
    for tx in outgoing:
        to = tx.get("to", "").lower()
        val = float(tx.get("value", 0)) / 1e6
        out_dests[to] += val
    
    # Check for exchanges
    found = None
    for to_addr, to_amt in sorted(out_dests.items(), key=lambda x: x[1], reverse=True):
        for k, v in KNOWN_EXCHANGES.items():
            if k.lower() == to_addr:
                found = v
                print(f"[{i:3d}] ${amt:>8,.0f} -> {v} (${to_amt:,.0f})")
                results[addr] = {"type": "exchange", "exchange": v, "amount": to_amt, "via": addr}
                break
        if found:
            break
    
    if not found:
        primary = max(out_dests.items(), key=lambda x: x[1])
        print(f"[{i:3d}] ${amt:>8,.0f} -> Unknown ({primary[0][:12]}...)")
        results[addr] = {"type": "unknown", "destination": primary[0], "amount": primary[1]}

# Save progress
progress = {"processed": end_idx, "results": results}
with open(progress_file, "w") as f:
    json.dump(progress, f, indent=2)

print(f"\nProgress saved. Processed {end_idx}/{len(destinations)}")

# Summary so far
exchange_totals = defaultdict(float)
still_in = 0
unknown = 0

for addr, info in results.items():
    if info["type"] == "exchange":
        exchange_totals[info["exchange"]] += info["amount"]
    elif info["type"] == "still_in_wallet":
        still_in += info["amount"]
    else:
        unknown += info["amount"]

print("\n" + "=" * 60)
print("CURRENT SUMMARY")
print("=" * 60)
for ex, amt in sorted(exchange_totals.items(), key=lambda x: x[1], reverse=True):
    print(f"{ex:20s} ${amt:>12,.2f}")
print(f"{'Still in wallet':20s} ${still_in:>12,.2f}")
print(f"{'Unknown':20s} ${unknown:>12,.2f}")
