#!/usr/bin/env python3
"""
Trace all P2P destinations to find common endpoints (exchanges, mixers, etc.)
"""

import json
import time
import requests
from collections import defaultdict
from datetime import datetime

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
TRON_API = "https://apilist.tronscanapi.com/api"
BSC_API = "https://api.bscscan.com/api"

# Known exchange addresses
KNOWN_EXCHANGES = {
    # Tron
    "TQoLh9evwUmZKxpD1uhFttsZk3EBs8BksV": "WhiteBIT",
    "TNaRAoLUyYEV2uF7GUrzSjRQTU8v5ZJ5VR": "WhiteBIT",
    "TKVSaJQDWeKFPg8QTFdxkSKxWEzgfGz91L": "WhiteBIT",
    "TXDADvvG3eFd2cQfPcLGUF4ZxTBQFvYPzi": "WhiteBIT",
    "TLfKJ67pcMkq4V3N1kkJBz2Z5TLpLz7bZK": "WhiteBIT Hot Wallet",
    "TVGhN7ThUW2bHMBQYSLK1rNGmZBfGuxBQB": "WhiteBIT",
    "TYDzsYUEpvnYmQk4zGP9sWWcTEd2MiAtW6": "Binance",
    "TYASr5UV6HEcXatwdFQfmLVUqQQQMUxHLS": "Binance Hot",
    "TAUN6FwrnwwmaEqYcckffC7wYmbaS6cBiX": "Binance",
    "TQrY8tryqsYVCYS3MFbtffiPp2ccyn4STm": "OKX",
    "TS7Kc1Y6Xpvvp5LgVLCt1eEbXbE8oYkPsV": "HTX (Huobi)",
    "TNDzfERDpxLDS2w1q6yaFC7pzqaSQ3Bg3r": "KuCoin",
    "TDqSquXBgUCLYvYC4XZgrprLK589dkhSCf": "Gate.io",
    "TCYpR4xqMT3wKFLB3KTVqjDdBjLFZjkMYS": "Bybit",
    # BSC
    "0x8894e0a0c962cb723c1976a4421c95949be2d4e3": "Binance Hot",
    "0xe2fc31f816a9b94326492132018c3aecc4a93ae1": "WhiteBIT",
    "0x3c783c21a0383057d128bae431894a5c19f9cf06": "WhiteBIT",
}

def get_tron_transactions(address, limit=50):
    """Get outgoing USDT transactions from a Tron address"""
    url = f"{TRON_API}/token_trc20/transfers"
    params = {
        "relatedAddress": address,
        "limit": limit,
        "start": 0,
        "direction": 0,  # 0 = from
        "db_version": 1
    }
    try:
        resp = requests.get(url, params=params, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("token_transfers", [])
    except Exception as e:
        print(f"  Error fetching Tron txs for {address}: {e}")
    return []

def get_bsc_transactions(address):
    """Get outgoing USDT transactions from a BSC address"""
    usdt_contract = "0x55d398326f99059fF775485246999027B3197955"
    url = f"{BSC_API}"
    params = {
        "module": "account",
        "action": "tokentx",
        "address": address,
        "contractaddress": usdt_contract,
        "sort": "desc",
        "apikey": ETHERSCAN_API_KEY  # BSCScan uses same key format
    }
    try:
        resp = requests.get(url, params=params, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        print(f"  Error fetching BSC txs for {address}: {e}")
    return []

def trace_address(address, chain="tron", depth=1):
    """Trace an address to find where funds went"""
    destinations = []
    
    if chain == "tron":
        txs = get_tron_transactions(address)
        for tx in txs:
            if tx.get("from_address", "").lower() == address.lower():
                to_addr = tx.get("to_address", "")
                amount = float(tx.get("quant", 0)) / 1e6  # USDT has 6 decimals on Tron
                if amount > 0:
                    destinations.append({
                        "to": to_addr,
                        "amount": amount,
                        "txid": tx.get("transaction_id", ""),
                        "timestamp": tx.get("block_ts", 0)
                    })
    elif chain == "bsc":
        txs = get_bsc_transactions(address)
        for tx in txs:
            if tx.get("from", "").lower() == address.lower():
                to_addr = tx.get("to", "")
                amount = float(tx.get("value", 0)) / 1e18
                if amount > 0:
                    destinations.append({
                        "to": to_addr,
                        "amount": amount,
                        "txid": tx.get("hash", ""),
                        "timestamp": int(tx.get("timeStamp", 0))
                    })
    
    return destinations

def identify_exchange(address):
    """Check if address is a known exchange"""
    addr_lower = address.lower() if address.startswith("0x") else address
    
    for known_addr, name in KNOWN_EXCHANGES.items():
        if known_addr.lower() == addr_lower or known_addr == address:
            return name
    return None

def main():
    # Load P2P data
    with open("heist_all_p2p_data.json", "r") as f:
        data = json.load(f)
    
    # Get all unique P2P destination addresses
    p2p_destinations = set()
    p2p_amounts = defaultdict(float)
    
    # From P2P wallet
    for tx in data.get("p2p_wallet", {}).get("outgoing", []):
        if tx.get("direction") == "OUT" and tx.get("amount_usdt", 0) > 0:
            to_addr = tx.get("to", "")
            if to_addr:
                p2p_destinations.add(to_addr)
                p2p_amounts[to_addr] += tx.get("amount_usdt", 0)
    
    # From attacker direct
    for tx in data.get("attacker_direct", {}).get("outgoing", []):
        if tx.get("direction") == "OUT" and tx.get("amount_usdt", 0) > 0:
            to_addr = tx.get("to", "")
            if to_addr:
                p2p_destinations.add(to_addr)
                p2p_amounts[to_addr] += tx.get("amount_usdt", 0)
    
    print(f"Found {len(p2p_destinations)} unique P2P destination addresses")
    print(f"Total amount distributed: ${sum(p2p_amounts.values()):,.2f}")
    print()
    
    # Track common final destinations
    final_destinations = defaultdict(lambda: {"count": 0, "total_amount": 0, "source_wallets": set(), "txids": []})
    traced_wallets = {}
    
    # Sort by amount received (highest first)
    sorted_destinations = sorted(p2p_destinations, key=lambda x: p2p_amounts[x], reverse=True)
    
    print("Tracing P2P destinations to find common endpoints...")
    print("=" * 80)
    
    for i, addr in enumerate(sorted_destinations):
        amount = p2p_amounts[addr]
        print(f"\n[{i+1}/{len(sorted_destinations)}] {addr[:16]}... (received ${amount:,.2f})")
        
        # Determine chain - these are BSC addresses (0x prefix)
        chain = "bsc" if addr.startswith("0x") else "tron"
        
        # Check if already a known exchange
        exchange = identify_exchange(addr)
        if exchange:
            print(f"  -> KNOWN EXCHANGE: {exchange}")
            final_destinations[f"{exchange} (direct)"]["count"] += 1
            final_destinations[f"{exchange} (direct)"]["total_amount"] += amount
            final_destinations[f"{exchange} (direct)"]["source_wallets"].add(addr)
            continue
        
        # Trace where this wallet sent funds
        time.sleep(0.3)  # Rate limiting
        outgoing = trace_address(addr, chain)
        
        if not outgoing:
            print(f"  -> No outgoing transactions found (funds may still be there)")
            final_destinations["Still in P2P wallet"]["count"] += 1
            final_destinations["Still in P2P wallet"]["total_amount"] += amount
            final_destinations["Still in P2P wallet"]["source_wallets"].add(addr)
            continue
        
        traced_wallets[addr] = outgoing
        
        # Check each outgoing destination
        found_exchange = False
        for out_tx in outgoing[:5]:  # Check first 5 outgoing
            to_addr = out_tx["to"]
            exchange = identify_exchange(to_addr)
            if exchange:
                print(f"  -> Sent to {exchange}: ${out_tx['amount']:,.2f}")
                final_destinations[exchange]["count"] += 1
                final_destinations[exchange]["total_amount"] += out_tx["amount"]
                final_destinations[exchange]["source_wallets"].add(addr)
                final_destinations[exchange]["txids"].append(out_tx["txid"])
                found_exchange = True
            else:
                # Track unknown destinations for pattern analysis
                final_destinations[f"Unknown: {to_addr[:16]}..."]["count"] += 1
                final_destinations[f"Unknown: {to_addr[:16]}..."]["total_amount"] += out_tx["amount"]
                final_destinations[f"Unknown: {to_addr[:16]}..."]["source_wallets"].add(addr)
        
        if not found_exchange:
            print(f"  -> Sent to {len(outgoing)} unknown addresses")
    
    # Summary
    print("\n" + "=" * 80)
    print("FINAL DESTINATION SUMMARY")
    print("=" * 80)
    
    # Sort by total amount
    sorted_finals = sorted(final_destinations.items(), key=lambda x: x[1]["total_amount"], reverse=True)
    
    for dest, info in sorted_finals[:20]:  # Top 20
        print(f"\n{dest}")
        print(f"  Transactions: {info['count']}")
        print(f"  Total Amount: ${info['total_amount']:,.2f}")
        print(f"  Source Wallets: {len(info['source_wallets'])}")
        if info.get("txids"):
            print(f"  Sample TXIDs: {info['txids'][:3]}")
    
    # Save results
    results = {
        "summary": {
            "total_destinations": len(p2p_destinations),
            "total_distributed": sum(p2p_amounts.values()),
            "traced_at": datetime.utcnow().isoformat()
        },
        "final_destinations": {
            k: {
                "count": v["count"],
                "total_amount": v["total_amount"],
                "source_wallets": list(v["source_wallets"]),
                "txids": v.get("txids", [])
            }
            for k, v in sorted_finals
        },
        "traced_wallets": traced_wallets,
        "p2p_amounts": dict(p2p_amounts)
    }
    
    with open("heist_p2p_trace_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to heist_p2p_trace_results.json")

if __name__ == "__main__":
    main()
