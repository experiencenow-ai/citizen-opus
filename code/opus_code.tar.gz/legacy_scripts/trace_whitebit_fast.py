#!/usr/bin/env python3
"""
Fast trace - batch API calls and focus on high-value destinations first.
"""

import json
import requests
import time
from collections import defaultdict
import concurrent.futures

BSCSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

def get_outgoing_usdt(address, max_txs=20):
    """Get outgoing USDT transactions from an address."""
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={BSCSCAN_API_KEY}"
    
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
        
        if data.get('status') == '1' and data.get('result'):
            txs = data['result'][:max_txs]
            outgoing = []
            for tx in txs:
                if tx['from'].lower() == address.lower() and int(tx['value']) > 0:
                    outgoing.append({
                        'to': tx['to'].lower(),
                        'amount': int(tx['value']) / 1e18,
                        'txid': tx['hash']
                    })
            return address, outgoing
    except Exception as e:
        pass
    return address, []

def main():
    # Load P2P data
    with open('heist_all_p2p_data.json', 'r') as f:
        data = json.load(f)
    
    # Get P2P wallet destinations
    p2p_outgoing = data['p2p_wallet']['outgoing']
    
    # Build destination list with amounts
    p2p_destinations = {}
    for tx in p2p_outgoing:
        if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
            dest = tx['to'].lower()
            if dest not in p2p_destinations:
                p2p_destinations[dest] = 0
            p2p_destinations[dest] += tx['amount_usdt']
    
    # Sort by amount received (high value first)
    sorted_dests = sorted(p2p_destinations.items(), key=lambda x: x[1], reverse=True)
    
    print(f"Tracing {len(sorted_dests)} P2P destinations...")
    
    # Track endpoints
    endpoints = defaultdict(lambda: {'count': 0, 'total': 0, 'sources': set(), 'txids': []})
    
    # Process in batches with rate limiting
    for i, (dest, amt) in enumerate(sorted_dests):
        addr, outgoing = get_outgoing_usdt(dest)
        
        for tx in outgoing:
            ep = tx['to']
            endpoints[ep]['count'] += 1
            endpoints[ep]['total'] += tx['amount']
            endpoints[ep]['sources'].add(dest)
            if len(endpoints[ep]['txids']) < 5:
                endpoints[ep]['txids'].append(tx['txid'])
        
        if (i+1) % 10 == 0:
            print(f"  {i+1}/{len(sorted_dests)} traced...")
        
        time.sleep(0.21)  # Rate limit
    
    # Convert sets to lists for JSON
    for ep in endpoints:
        endpoints[ep]['sources'] = list(endpoints[ep]['sources'])
    
    # Sort by source count
    sorted_eps = sorted(endpoints.items(), key=lambda x: len(x[1]['sources']), reverse=True)
    
    print("\n" + "="*70)
    print("TOP ENDPOINTS (by number of unique P2P sources)")
    print("="*70)
    
    whitebit_addrs = []
    for addr, info in sorted_eps[:20]:
        src_count = len(info['sources'])
        if src_count >= 2:
            whitebit_addrs.append({
                'address': addr,
                'source_count': src_count,
                'total_usdt': info['total'],
                'sample_txids': info['txids'][:3]
            })
        print(f"\n{addr}")
        print(f"  From {src_count} different P2P buyers -> ${info['total']:,.2f}")
        print(f"  TX: {info['txids'][0][:20]}..." if info['txids'] else "")
    
    # Save results
    results = {
        'whitebit_candidates': whitebit_addrs,
        'all_endpoints': {addr: {
            'source_count': len(info['sources']),
            'total_usdt': info['total'],
            'sample_txids': info['txids'][:3]
        } for addr, info in sorted_eps[:50]}
    }
    
    with open('whitebit_trace_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n\nSaved to whitebit_trace_results.json")
    print(f"Found {len(whitebit_addrs)} addresses receiving from 2+ sources")

if __name__ == "__main__":
    main()
