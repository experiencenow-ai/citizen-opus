#!/usr/bin/env python3
"""
Trace P2P recipients to WhiteBit using Etherscan API v2
Identify unique deposit addresses (which correspond to unique WhiteBit accounts)
"""
import json
import requests
import time

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"
CHAIN_ID = 1  # Ethereum mainnet

# Known WhiteBit hot wallet
WHITEBIT_HOT = "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3".lower()

# USDT contract on Ethereum
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

def get_token_transfers(address, direction="from"):
    """Get USDT transfers from/to an address using v2 API"""
    params = {
        "chainid": CHAIN_ID,
        "module": "account",
        "action": "tokentx",
        "address": address,
        "contractaddress": USDT_CONTRACT,
        "sort": "asc",
        "apikey": API_KEY
    }
    
    try:
        resp = requests.get(BASE_URL, params=params, timeout=30)
        data = resp.json()
        if data.get("status") == "1":
            return data.get("result", [])
        else:
            print(f"  API returned: {data.get('message', 'unknown error')}")
            return []
    except Exception as e:
        print(f"  Error: {e}")
        return []

def load_p2p_data():
    """Load the P2P transaction data"""
    with open("/root/claude/opus/heist_all_p2p_data.json", "r") as f:
        return json.load(f)

def main():
    p2p_data = load_p2p_data()
    p2p_txs = p2p_data.get("p2p_wallet", {}).get("outgoing", [])
    
    print(f"Analyzing {len(p2p_txs)} P2P transactions to find WhiteBit deposit addresses")
    print("=" * 70)
    
    # Track unique WhiteBit deposit addresses
    deposit_addresses = {}  # deposit_addr -> list of (p2p_recipient, amount, txid)
    no_whitebit = []
    errors = []
    
    # Process each P2P recipient
    for i, tx in enumerate(p2p_txs):
        p2p_recipient = tx["to"].lower()
        amount = tx["amount_usdt"]
        
        print(f"\n[{i+1}/{len(p2p_txs)}] {p2p_recipient[:10]}... (${amount})")
        
        # Get their outgoing transfers
        transfers = get_token_transfers(p2p_recipient)
        time.sleep(0.25)  # Rate limit
        
        # Find transfers that eventually go to WhiteBit hot wallet
        found_whitebit = False
        for transfer in transfers:
            if transfer["from"].lower() == p2p_recipient:
                dest = transfer["to"].lower()
                value = int(transfer["value"]) / 1e6  # USDT has 6 decimals
                
                # Check if dest is WhiteBit hot wallet directly
                if dest == WHITEBIT_HOT:
                    # This is direct to hot wallet - unusual
                    print(f"  -> Direct to WhiteBit hot wallet: ${value}")
                    if dest not in deposit_addresses:
                        deposit_addresses[dest] = []
                    deposit_addresses[dest].append({
                        "p2p_recipient": p2p_recipient,
                        "amount": amount,
                        "transfer_amount": value,
                        "txid": transfer["hash"],
                        "is_direct": True
                    })
                    found_whitebit = True
                else:
                    # Check if this dest address ever sent to WhiteBit
                    # This would be a deposit address -> hot wallet pattern
                    dest_transfers = get_token_transfers(dest)
                    time.sleep(0.25)
                    
                    for dt in dest_transfers:
                        if dt["to"].lower() == WHITEBIT_HOT:
                            print(f"  -> Deposit addr {dest[:10]}... -> WhiteBit (${value})")
                            if dest not in deposit_addresses:
                                deposit_addresses[dest] = []
                            deposit_addresses[dest].append({
                                "p2p_recipient": p2p_recipient,
                                "amount": amount,
                                "transfer_amount": value,
                                "txid": transfer["hash"],
                                "deposit_address": dest,
                                "is_direct": False
                            })
                            found_whitebit = True
                            break
        
        if not found_whitebit:
            print(f"  -> No WhiteBit connection found")
            no_whitebit.append({"address": p2p_recipient, "amount": amount})
        
        # Save progress every 20 addresses
        if (i + 1) % 20 == 0:
            save_progress(deposit_addresses, no_whitebit)
    
    # Final save
    save_progress(deposit_addresses, no_whitebit, final=True)

def save_progress(deposit_addresses, no_whitebit, final=False):
    """Save current progress"""
    result = {
        "unique_deposit_addresses": len(deposit_addresses),
        "total_recipients_to_whitebit": sum(len(v) for v in deposit_addresses.values()),
        "no_whitebit_count": len(no_whitebit),
        "deposit_address_details": {
            addr: {
                "count": len(recipients),
                "total_amount": sum(r["amount"] for r in recipients),
                "recipients": recipients
            }
            for addr, recipients in deposit_addresses.items()
        },
        "no_whitebit": no_whitebit
    }
    
    filename = "/root/claude/opus/whitebit_deposit_addresses.json"
    with open(filename, "w") as f:
        json.dump(result, f, indent=2)
    
    if final:
        print("\n" + "=" * 70)
        print("FINAL RESULTS")
        print("=" * 70)
        print(f"Unique WhiteBit deposit addresses: {len(deposit_addresses)}")
        print(f"Total P2P recipients going to WhiteBit: {sum(len(v) for v in deposit_addresses.values())}")
        print(f"P2P recipients NOT going to WhiteBit: {len(no_whitebit)}")
        
        print("\nDeposit address breakdown:")
        for addr, recipients in sorted(deposit_addresses.items(), key=lambda x: -len(x[1])):
            total = sum(r["amount"] for r in recipients)
            print(f"  {addr[:16]}... : {len(recipients)} deposits, ${total:,.2f}")

if __name__ == "__main__":
    main()
