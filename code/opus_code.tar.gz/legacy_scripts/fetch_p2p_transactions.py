#!/usr/bin/env python3
"""
Fetch all P2P transactions from the distribution wallet
Uses Etherscan API to get complete transaction list with TXIDs
"""

import requests
import json
import time
from datetime import datetime, timedelta, timezone

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"

# P2P Distribution Wallet
P2P_WALLET = "0xae1e8796052db5f4a975a006800ae33a20845078"

# USDT Contract
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

def get_token_transfers(address, contract=None, start_block=0, end_block=99999999):
    """Get ERC20 token transfers for an address"""
    params = {
        'module': 'account',
        'action': 'tokentx',
        'address': address,
        'startblock': start_block,
        'endblock': end_block,
        'sort': 'desc',
        'apikey': API_KEY,
        'chainid': 1
    }
    if contract:
        params['contractaddress'] = contract
    
    try:
        resp = requests.get(BASE_URL, params=params, timeout=60)
        data = resp.json()
        if data.get('status') == '1':
            return data.get('result', [])
        elif data.get('message') == 'No transactions found':
            return []
        else:
            print(f"API Error: {data.get('message')}")
            return []
    except Exception as e:
        print(f"Request error: {e}")
        return []

def format_timestamp(unix_ts):
    """Convert unix timestamp to UTC and Antalya time (UTC+3)"""
    utc_dt = datetime.fromtimestamp(int(unix_ts), tz=timezone.utc)
    antalya_dt = utc_dt + timedelta(hours=3)
    return utc_dt.strftime('%Y-%m-%d %H:%M:%S'), antalya_dt.strftime('%Y-%m-%d %H:%M:%S')

def main():
    print(f"Fetching USDT transfers from P2P wallet: {P2P_WALLET}")
    print("=" * 80)
    
    # Get all USDT transfers
    transfers = get_token_transfers(P2P_WALLET, USDT_CONTRACT)
    print(f"Total transfers found: {len(transfers)}")
    
    # Filter for outgoing transfers with value > 0
    outgoing = []
    for tx in transfers:
        if tx['from'].lower() == P2P_WALLET.lower() and int(tx['value']) > 0:
            value_usdt = int(tx['value']) / 1e6  # USDT has 6 decimals
            utc_time, antalya_time = format_timestamp(tx['timeStamp'])
            outgoing.append({
                'txid': tx['hash'],
                'utc_time': utc_time,
                'antalya_time': antalya_time,
                'amount_usdt': round(value_usdt, 2),
                'to': tx['to'],
                'block': int(tx['blockNumber'])
            })
    
    # Sort by timestamp descending
    outgoing.sort(key=lambda x: x['utc_time'], reverse=True)
    
    print(f"Outgoing transfers (value > 0): {len(outgoing)}")
    
    # Calculate totals
    total_usdt = sum(tx['amount_usdt'] for tx in outgoing)
    print(f"Total USDT transferred out: ${total_usdt:,.2f}")
    
    # Save to JSON
    result = {
        "wallet": P2P_WALLET,
        "report_generated": datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),
        "total_outgoing_count": len(outgoing),
        "total_usdt_out": round(total_usdt, 2),
        "transactions": outgoing
    }
    
    with open('p2p_wallet_all_transactions.json', 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"\nSaved to p2p_wallet_all_transactions.json")
    
    # Print sample
    print("\n" + "=" * 80)
    print("SAMPLE (First 10 most recent):")
    print("=" * 80)
    for tx in outgoing[:10]:
        print(f"TX: {tx['txid']}")
        print(f"   Time: {tx['antalya_time']} (Antalya)")
        print(f"   Amount: ${tx['amount_usdt']:,.2f}")
        print(f"   To: {tx['to']}")
        print()

if __name__ == "__main__":
    main()
