#!/usr/bin/env python3
"""
Trace P2P destinations to find WhiteBit exchange deposits.
Focus: Extract all P2P destinations, trace their outflows, identify common WhiteBit addresses.
"""

import json
import requests
import time
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

def get_token_transfers(address, direction='from'):
    """Get USDT transfers from/to an address"""
    url = "https://api.etherscan.io/v2/api"
    params = {
        'module': 'account',
        'action': 'tokentx',
        'address': address,
        'contractaddress': USDT_CONTRACT,
        'sort': 'desc',
        'apikey': ETHERSCAN_API_KEY
    }
    
    try:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()
        if data.get('status') == '1' and data.get('result'):
            txs = []
            for tx in data['result']:
                if int(tx.get('value', 0)) > 0:  # Skip 0-value
                    txs.append({
                        'from': tx['from'].lower(),
                        'to': tx['to'].lower(),
                        'value': int(tx['value']) / 1e6,  # USDT has 6 decimals
                        'hash': tx['hash'],
                        'timestamp': int(tx['timeStamp'])
                    })
            return txs
    except Exception as e:
        print(f"Error fetching {address}: {e}")
    return []

# Known exchange addresses (we'll build this list)
KNOWN_EXCHANGES = {
    '0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23': 'WhiteBit Hot Wallet',
    '0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3': 'WhiteBit',
}

def main():
    # Load the P2P data
    with open('heist_all_p2p_data.json', 'r') as f:
        data = json.load(f)
    
    # Extract all P2P destination addresses
    p2p_destinations = set()
    p2p_txs = data.get('p2p_wallet', {}).get('outgoing', [])
    
    print(f"Found {len(p2p_txs)} P2P transactions")
    
    for tx in p2p_txs:
        dest = tx['to'].lower()
        p2p_destinations.add(dest)
    
    print(f"Unique P2P destinations: {len(p2p_destinations)}")
    
    # Now trace each destination's outflows to find where they sent funds
    # Track which addresses appear as destinations
    second_hop_destinations = defaultdict(lambda: {'count': 0, 'total_usdt': 0, 'sources': []})
    
    traced_count = 0
    for dest in list(p2p_destinations)[:50]:  # Start with first 50 to avoid rate limits
        print(f"\nTracing {dest[:10]}... ({traced_count+1}/{min(50, len(p2p_destinations))})")
        
        txs = get_token_transfers(dest)
        
        # Find outgoing transfers (where this address is the sender)
        outgoing = [tx for tx in txs if tx['from'] == dest]
        
        if outgoing:
            print(f"  Found {len(outgoing)} outgoing transfers")
            for tx in outgoing[:10]:  # First 10 outgoing per address
                next_dest = tx['to']
                second_hop_destinations[next_dest]['count'] += 1
                second_hop_destinations[next_dest]['total_usdt'] += tx['value']
                second_hop_destinations[next_dest]['sources'].append({
                    'from': dest,
                    'amount': tx['value'],
                    'txid': tx['hash']
                })
        
        traced_count += 1
        time.sleep(0.25)  # Rate limiting
    
    # Sort by count (most common destinations)
    sorted_dests = sorted(second_hop_destinations.items(), key=lambda x: x[1]['count'], reverse=True)
    
    print("\n" + "="*80)
    print("TOP COMMON DESTINATIONS (likely exchanges)")
    print("="*80)
    
    whitebit_addresses = []
    
    for addr, info in sorted_dests[:20]:
        label = KNOWN_EXCHANGES.get(addr, 'Unknown')
        print(f"\n{addr}")
        print(f"  Count: {info['count']} transfers from P2P recipients")
        print(f"  Total: ${info['total_usdt']:,.2f} USDT")
        print(f"  Label: {label}")
        
        if info['count'] >= 3:  # If 3+ P2P recipients sent here, likely an exchange
            whitebit_addresses.append({
                'address': addr,
                'count': info['count'],
                'total_usdt': info['total_usdt'],
                'label': label,
                'sample_sources': info['sources'][:5]
            })
    
    # Save results
    results = {
        'traced_p2p_destinations': traced_count,
        'total_p2p_destinations': len(p2p_destinations),
        'common_destinations': whitebit_addresses,
        'all_second_hop': {k: {'count': v['count'], 'total': v['total_usdt']} 
                          for k, v in sorted_dests[:50]}
    }
    
    with open('whitebit_trace_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n\nResults saved to whitebit_trace_results.json")

if __name__ == '__main__':
    main()
