#!/usr/bin/env python3
"""
Check if P2P destinations ARE WhiteBit deposit addresses directly.
These addresses have no outgoing USDT - likely they ARE the exchange deposits.
"""

import json
import requests
import time

BSCSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

def get_all_tx(address):
    """Get all transactions (normal + internal) for an address."""
    # Normal transactions
    url = f"https://api.bscscan.com/api?module=account&action=txlist&address={address}&startblock=0&endblock=99999999&sort=desc&apikey={BSCSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1':
            return data['result'][:50]
    except:
        pass
    return []

def get_all_token_tx(address):
    """Get ALL token transactions (not just USDT)."""
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&sort=desc&apikey={BSCSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1':
            return data['result'][:50]
    except:
        pass
    return []

# Sample addresses that received ~$4k from P2P wallet
test_addresses = [
    "0x0e1faa94b3b66b70967a4e4448600fea3895108e",
    "0xe17b08ad90ca38c87959d81d5bf106d8b8bf80a9",
    "0xc88c90a9b0576fe4f27a0796997ba89fd78b3771",
    "0x84e643b51c823ba7fad5ce0bb4d5c02521427f39",
    "0x14850ad917d87d578383004c3e639ac5aec0d85f"
]

print("Checking if P2P destinations are WhiteBit deposit addresses...")
print("="*70)

for addr in test_addresses:
    print(f"\n{addr}")
    
    # Get normal transactions
    txs = get_all_tx(addr)
    print(f"  Normal TXs: {len(txs)}")
    
    # Count incoming vs outgoing
    incoming = sum(1 for tx in txs if tx.get('to', '').lower() == addr.lower())
    outgoing = sum(1 for tx in txs if tx.get('from', '').lower() == addr.lower())
    print(f"  Incoming: {incoming}, Outgoing: {outgoing}")
    
    # Get token transactions  
    token_txs = get_all_token_tx(addr)
    print(f"  Token TXs: {len(token_txs)}")
    
    # Analyze token transactions
    token_in = []
    token_out = []
    for tx in token_txs:
        if tx.get('to', '').lower() == addr.lower():
            token_in.append(tx)
        else:
            token_out.append(tx)
    
    print(f"  Token IN: {len(token_in)}, Token OUT: {len(token_out)}")
    
    # If there ARE outgoing token txs, show where they went
    if token_out:
        print(f"  Token OUT destinations:")
        seen = set()
        for tx in token_out[:5]:
            dest = tx['to'].lower()
            if dest not in seen:
                seen.add(dest)
                amt = int(tx['value']) / (10 ** int(tx.get('tokenDecimal', 18)))
                print(f"    -> {dest} (${amt:,.0f} {tx.get('tokenSymbol', 'UNK')})")
                print(f"       TX: {tx['hash']}")
    
    # Check if address looks like exchange deposit (only receives, never sends)
    if outgoing == 0 and len(token_out) == 0:
        print(f"  *** LIKELY EXCHANGE DEPOSIT ADDRESS (no outgoing) ***")
    
    time.sleep(0.3)

print("\n" + "="*70)
print("CONCLUSION")
print("="*70)
print("""
If all these addresses have:
- Multiple incoming transactions
- ZERO outgoing transactions
Then they ARE WhiteBit deposit addresses directly!

The P2P buyers are depositing directly to their WhiteBit accounts.
WhiteBit should have KYC for all these deposit addresses.
""")
