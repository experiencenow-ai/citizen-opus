#!/usr/bin/env python3
"""
Trace P2P destinations on Ethereum mainnet to find common endpoints
"""

import json
import time
import requests
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
ETH_API = "https://api.etherscan.io/v2/api"
USDT_ETH = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Known exchange addresses on Ethereum
KNOWN_EXCHANGES = {
    # WhiteBIT
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    "0x2e31af2f66e8e8ed4d6e7b7b6e1b5f8e3c4d5a6b": "WhiteBIT",
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance 14",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance 15",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance 16",
    "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance 17",
    "0x9696f59e4d72e237be84ffd425dcad154bf96976": "Binance 18",
    "0x4976a4a02f38326660d17bf34b431dc6e2eb2327": "Binance 19",
    "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance 8",
    "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": "Binance 1",
    # OKX
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    "0x98ec059dc3adfbdd63429454aeb0c990fba4a128": "OKX Hot",
    # Bybit
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    "0x1db92e2eebc8e0c075a02bea49a2935bcd2dfcf4": "Bybit Hot",
    # KuCoin
    "0x2b5634c42055806a59e9107ed44d43c426e58258": "KuCoin",
    "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin",
    # HTX (Huobi)
    "0x5c985e89dde482efe97ea9f1950ad149eb73829b": "HTX",
    "0xab5c66752a9e8167967685f1450532fb96d5d24f": "HTX 1",
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io",
    # Kraken
    "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken",
    # Coinbase
    "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase",
    # MEXC
    "0x3cc936b795a188f0e246cbb2d74c5bd190aecf18": "MEXC",
}

def get_eth_token_txs(address):
    """Get token transactions from Ethereum"""
    try:
        params = {
            "chainid": 1,
            "module": "account",
            "action": "tokentx",
            "address": address,
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(ETH_API, params=params, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        print(f"  API Error: {e}")
    return []

def identify_exchange(address):
    """Check if address is a known exchange"""
    addr_lower = address.lower()
    for known_addr, name in KNOWN_EXCHANGES.items():
        if known_addr.lower() == addr_lower:
            return name
    return None

# Get P2P wallet transactions
print("Fetching P2P wallet (0xae1e...) transactions from Ethereum...")
p2p_wallet = "0xae1e8796052db5f4a975a006800ae33a20845078"
p2p_txs = get_eth_token_txs(p2p_wallet)

print(f"Found {len(p2p_txs)} token transactions")

# Get outgoing transactions
outgoing = [tx for tx in p2p_txs if tx.get("from", "").lower() == p2p_wallet.lower()]
print(f"Outgoing: {len(outgoing)} transactions")

# Get unique destinations
destinations = defaultdict(lambda: {"amount": 0, "txids": []})
for tx in outgoing:
    to_addr = tx.get("to", "").lower()
    value = float(tx.get("value", 0)) / 1e6  # USDT has 6 decimals
    if value > 0:
        destinations[to_addr]["amount"] += value
        destinations[to_addr]["txids"].append(tx.get("hash"))

print(f"\nUnique destinations: {len(destinations)}")
print(f"Total distributed: ${sum(d['amount'] for d in destinations.values()):,.2f}")

# Sort by amount
sorted_dests = sorted(destinations.items(), key=lambda x: x[1]["amount"], reverse=True)

print("\n" + "=" * 80)
print("TRACING P2P DESTINATIONS TO FIND COMMON ENDPOINTS")
print("=" * 80)

# Track final destinations
final_destinations = defaultdict(lambda: {"amount": 0, "sources": [], "txids": []})
traced_count = 0

for i, (addr, info) in enumerate(sorted_dests):
    amt = info["amount"]
    print(f"\n[{i+1}/{len(sorted_dests)}] {addr}")
    print(f"  Received: ${amt:,.2f}")
    
    # Check if direct to exchange
    exchange = identify_exchange(addr)
    if exchange:
        print(f"  -> DIRECT TO: {exchange}")
        final_destinations[exchange]["amount"] += amt
        final_destinations[exchange]["sources"].append(addr)
        continue
    
    # Rate limit
    time.sleep(0.25)
    
    # Trace where this address sent funds
    addr_txs = get_eth_token_txs(addr)
    addr_outgoing = [tx for tx in addr_txs if tx.get("from", "").lower() == addr]
    
    if not addr_outgoing:
        print(f"  -> Still in wallet (no outgoing)")
        final_destinations["Still in P2P wallet"]["amount"] += amt
        final_destinations["Still in P2P wallet"]["sources"].append(addr)
        continue
    
    traced_count += 1
    
    # Group outgoing by destination
    out_dests = defaultdict(float)
    out_txids = defaultdict(list)
    for tx in addr_outgoing:
        to = tx.get("to", "").lower()
        val = float(tx.get("value", 0)) / 1e6
        if val > 0:
            out_dests[to] += val
            out_txids[to].append(tx.get("hash"))
    
    # Check each destination
    found_exchange = False
    for to_addr, to_amt in sorted(out_dests.items(), key=lambda x: x[1], reverse=True)[:5]:
        exchange = identify_exchange(to_addr)
        if exchange:
            print(f"  -> {exchange}: ${to_amt:,.2f}")
            final_destinations[exchange]["amount"] += to_amt
            final_destinations[exchange]["sources"].append(addr)
            final_destinations[exchange]["txids"].extend(out_txids[to_addr][:2])
            found_exchange = True
        else:
            # Track as unknown destination
            final_destinations[f"Unknown:{to_addr[:16]}"]["amount"] += to_amt
            final_destinations[f"Unknown:{to_addr[:16]}"]["sources"].append(addr)
    
    if not found_exchange:
        primary = max(out_dests.items(), key=lambda x: x[1])
        print(f"  -> Unknown: {primary[0][:20]}... ${primary[1]:,.0f}")

# Summary
print("\n" + "=" * 80)
print("FINAL DESTINATION SUMMARY")
print("=" * 80)

# Group and sort
exchange_totals = {}
unknown_totals = {}
for dest, info in final_destinations.items():
    if dest.startswith("Unknown:"):
        unknown_totals[dest] = info
    else:
        exchange_totals[dest] = info

print("\n### KNOWN EXCHANGES ###")
for dest, info in sorted(exchange_totals.items(), key=lambda x: x[1]["amount"], reverse=True):
    print(f"\n{dest}")
    print(f"  Total: ${info['amount']:,.2f}")
    print(f"  From {len(info['sources'])} P2P wallets")
    if info.get("txids"):
        print(f"  Sample TXIDs:")
        for txid in info["txids"][:3]:
            print(f"    https://etherscan.io/tx/{txid}")

print(f"\n### UNKNOWN DESTINATIONS (top 10 by amount) ###")
sorted_unknown = sorted(unknown_totals.items(), key=lambda x: x[1]["amount"], reverse=True)[:10]
for dest, info in sorted_unknown:
    addr = dest.replace("Unknown:", "")
    print(f"\n{addr}...")
    print(f"  Total: ${info['amount']:,.2f} from {len(info['sources'])} P2P wallets")

# Save results
results = {
    "p2p_wallet": p2p_wallet,
    "chain": "ethereum",
    "total_distributed": sum(d["amount"] for d in destinations.values()),
    "unique_destinations": len(destinations),
    "traced_wallets": traced_count,
    "exchange_flows": {k: {"amount": v["amount"], "sources": len(v["sources"]), "txids": v.get("txids", [])[:5]} for k, v in exchange_totals.items()},
    "top_unknown": {k.replace("Unknown:", ""): {"amount": v["amount"], "sources": len(v["sources"])} for k, v in sorted_unknown}
}

with open("heist_eth_trace.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"\n\nResults saved to heist_eth_trace.json")
