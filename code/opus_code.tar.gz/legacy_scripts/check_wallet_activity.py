#!/usr/bin/env python3
"""
Check all activity for specific P2P wallets - not just USDT
"""

import json
import requests
import time

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BSCSCAN_API = "https://api.bscscan.com/api"

def get_all_token_txs(address):
    """Get ALL token transactions (not just USDT)"""
    try:
        params = {
            "module": "account",
            "action": "tokentx",
            "address": address,
            "sort": "desc",
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(BSCSCAN_API, params=params, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        print(f"  Error: {e}")
    return []

def get_normal_txs(address):
    """Get normal BNB transactions"""
    try:
        params = {
            "module": "account",
            "action": "txlist",
            "address": address,
            "sort": "desc",
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(BSCSCAN_API, params=params, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        print(f"  Error: {e}")
    return []

# Check specific wallets that ct said went to WhiteBIT
# These are the $4k recipients
test_wallets = [
    "0xe17b08ad90ca38c87959d81d5bf106d8b8bf80a9",
    "0x84e643b51c823ba7fad5ce0bb4d5c02521427f39",
    "0x14850ad917d87d578383004c3e639ac5aec0d85f",
    "0x7d6de6ad6e3689a29d2be77006278469c702dc1f",
    "0xc88c90a9b0576fe4f27a0796997ba89fd78b3771"
]

print("Checking full activity for P2P destination wallets...")
print("=" * 80)

for addr in test_wallets:
    print(f"\n{addr}")
    print("-" * 60)
    
    # Get all token txs
    time.sleep(0.3)
    token_txs = get_all_token_txs(addr)
    
    if token_txs:
        print(f"  Token transactions: {len(token_txs)}")
        for tx in token_txs[:5]:
            direction = "OUT" if tx.get("from", "").lower() == addr.lower() else "IN"
            to_from = tx.get("to" if direction == "OUT" else "from", "")
            symbol = tx.get("tokenSymbol", "?")
            decimals = int(tx.get("tokenDecimal", 18))
            value = float(tx.get("value", 0)) / (10 ** decimals)
            print(f"    {direction}: {value:,.2f} {symbol} -> {to_from[:16]}...")
    else:
        print("  No token transactions found")
    
    # Get normal txs
    time.sleep(0.3)
    normal_txs = get_normal_txs(addr)
    
    if normal_txs:
        print(f"  Normal transactions: {len(normal_txs)}")
        for tx in normal_txs[:3]:
            direction = "OUT" if tx.get("from", "").lower() == addr.lower() else "IN"
            to_from = tx.get("to" if direction == "OUT" else "from", "")
            value = float(tx.get("value", 0)) / 1e18
            print(f"    {direction}: {value:.4f} BNB -> {to_from[:16]}...")
    else:
        print("  No normal transactions found")

print("\n" + "=" * 80)
print("Note: If these wallets truly sent to WhiteBIT, the funds may have moved")
print("via a different chain (Tron?) or the addresses ct checked may be different.")
