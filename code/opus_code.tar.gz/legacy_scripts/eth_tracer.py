#!/usr/bin/env python3
"""
ETH Blockchain Tracer - Helper functions for tracing funds
Uses Etherscan API v2
"""

import requests
import json
import time
from datetime import datetime

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"

# Known addresses
KNOWN_ADDRESSES = {
    # Exchanges
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot Wallet",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance Hot Wallet 8",
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit Hot Wallet",
    "0x1db92e2eebc8e0c075a02bea49a2935bcd2dfcf4": "Coinbase",
    "0x503828976d22510aad0201ac7ec88293211d23da": "Coinbase",
    "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": "Coinbase",
    "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": "Coinbase",
    # Mixers
    "0xd90e2f925da726b50c4ed8d0fb90ad053324f31b": "Tornado Cash Router",
    "0x722122df12d4e14e13ac3b6895a86e84145b6967": "Tornado Cash 0.1 ETH",
    "0xdd4c48c0b24039969fc16d1cdf626eab821d3384": "Tornado Cash 1 ETH",
    "0xd4b88df4d29f5cedd6857912842cff3b20c8cfa3": "Tornado Cash 10 ETH",
    "0x910cbd523d972eb0a6f4cae4618ad62622b39dbf": "Tornado Cash 100 ETH",
    # Bridges
    "0x1231deb6f5749ef6ce6943a275a1d3e7486f4eae": "LiFi Bridge",
    "0x3a23f943181408eac424116af7b7790c94cb97a5": "Socket Bridge",
    # DEXs
    "0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45": "Uniswap V3 Router 2",
    "0xe592427a0aece92de3edee1f18e0157c05861564": "Uniswap V3 Router",
    "0x7a250d5630b4cf539739df2c5dacb4c659f2488d": "Uniswap V2 Router",
    # Case-specific
    "0xee8ef8cba3b33fc14cf448f8c064a08a3f92afa7": "ATTACKER MAIN WALLET",
    "0xee8ea66a5d8d2c93004ec100ef91fea8c2f8afa7": "PHISHING TRAP (ct mistake)",
    "0x27438f3caf9df8b9b05abcaab5422e1731cb1aa1": "INTERMEDIARY WALLET",
}

# Known tokens
KNOWN_TOKENS = {
    "0xdac17f958d2ee523a2206206994597c13d831ec7": {"symbol": "USDT", "decimals": 6},
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": {"symbol": "USDC", "decimals": 6},
    "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": {"symbol": "WETH", "decimals": 18},
    "0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0": {"symbol": "wstETH", "decimals": 18},
    "0x18084fba666a33d37592fa2633fd49a74dd93a88": {"symbol": "tBTC", "decimals": 18},
    "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599": {"symbol": "WBTC", "decimals": 8},
}

def etherscan_request(module, action, **params):
    """Make Etherscan API request"""
    params['module'] = module
    params['action'] = action
    params['apikey'] = API_KEY
    params['chainid'] = 1  # Ethereum mainnet
    
    try:
        resp = requests.get(BASE_URL, params=params, timeout=30)
        data = resp.json()
        if data.get('status') == '1' or data.get('message') == 'OK':
            return data.get('result', [])
        elif data.get('message') == 'No transactions found':
            return []
        else:
            print(f"API Error: {data.get('message', 'Unknown error')}")
            return None
    except Exception as e:
        print(f"Request error: {e}")
        return None

def get_eth_balance(address):
    """Get ETH balance"""
    result = etherscan_request('account', 'balance', address=address, tag='latest')
    if result:
        return int(result) / 1e18
    return 0

def get_token_balance(address, token_contract):
    """Get ERC20 token balance"""
    result = etherscan_request('account', 'tokenbalance', 
                               contractaddress=token_contract, 
                               address=address, 
                               tag='latest')
    if result:
        decimals = KNOWN_TOKENS.get(token_contract.lower(), {}).get('decimals', 18)
        return int(result) / (10 ** decimals)
    return 0

def get_normal_transactions(address, start_block=0, end_block=99999999):
    """Get all normal ETH transactions for an address"""
    return etherscan_request('account', 'txlist', 
                            address=address,
                            startblock=start_block,
                            endblock=end_block,
                            sort='asc')

def get_internal_transactions(address, start_block=0, end_block=99999999):
    """Get internal transactions"""
    return etherscan_request('account', 'txlistinternal',
                            address=address,
                            startblock=start_block,
                            endblock=end_block,
                            sort='asc')

def get_token_transfers(address, start_block=0, end_block=99999999):
    """Get all ERC20 token transfers for an address"""
    return etherscan_request('account', 'tokentx',
                            address=address,
                            startblock=start_block,
                            endblock=end_block,
                            sort='asc')

def get_tx_receipt(txhash):
    """Get transaction receipt"""
    return etherscan_request('proxy', 'eth_getTransactionReceipt', txhash=txhash)

def label_address(address):
    """Return label if known, otherwise shortened address"""
    addr_lower = address.lower()
    if addr_lower in KNOWN_ADDRESSES:
        return KNOWN_ADDRESSES[addr_lower]
    return address

def is_exchange_address(address):
    """Check if address is a known exchange"""
    addr_lower = address.lower()
    label = KNOWN_ADDRESSES.get(addr_lower, '')
    return any(x in label.lower() for x in ['binance', 'bybit', 'coinbase', 'kraken', 'okx', 'huobi', 'kucoin'])

def is_mixer_address(address):
    """Check if address is a known mixer"""
    addr_lower = address.lower()
    label = KNOWN_ADDRESSES.get(addr_lower, '')
    return 'tornado' in label.lower()

def is_real_token(contract_address):
    """Check if token is a real known token (not fake/scam)"""
    return contract_address.lower() in KNOWN_TOKENS

def format_timestamp(ts):
    """Convert Unix timestamp to readable format (Antalya time = UTC+3)"""
    dt = datetime.utcfromtimestamp(int(ts))
    # Add 3 hours for Antalya
    from datetime import timedelta
    dt_antalya = dt + timedelta(hours=3)
    return dt_antalya.strftime('%Y-%m-%d %H:%M:%S') + ' (Antalya)'

def format_value(value, decimals=18):
    """Format token value with proper decimals"""
    return int(value) / (10 ** decimals)

def trace_wallet(address, verbose=True):
    """Complete trace of a wallet - all transactions"""
    address = address.lower()
    
    if verbose:
        print(f"\n{'='*60}")
        print(f"TRACING: {address}")
        print(f"Label: {label_address(address)}")
        print(f"{'='*60}\n")
    
    results = {
        'address': address,
        'label': label_address(address),
        'eth_balance': get_eth_balance(address),
        'token_balances': {},
        'normal_txs': [],
        'token_transfers': [],
        'internal_txs': [],
        'inflows': [],
        'outflows': [],
        'exchange_interactions': [],
        'mixer_interactions': []
    }
    
    # Get token balances
    for contract, info in KNOWN_TOKENS.items():
        balance = get_token_balance(address, contract)
        if balance > 0:
            results['token_balances'][info['symbol']] = balance
    
    time.sleep(0.3)  # Rate limiting
    
    # Get normal transactions
    normal_txs = get_normal_transactions(address)
    if normal_txs:
        for tx in normal_txs:
            tx_data = {
                'hash': tx['hash'],
                'timestamp': format_timestamp(tx['timeStamp']),
                'from': tx['from'],
                'to': tx['to'],
                'value_eth': format_value(tx['value'], 18),
                'from_label': label_address(tx['from']),
                'to_label': label_address(tx['to']),
                'is_error': tx.get('isError', '0') == '1'
            }
            results['normal_txs'].append(tx_data)
            
            # Categorize
            if tx['from'].lower() == address:
                results['outflows'].append(tx_data)
                if is_exchange_address(tx['to']):
                    results['exchange_interactions'].append(tx_data)
                if is_mixer_address(tx['to']):
                    results['mixer_interactions'].append(tx_data)
            else:
                results['inflows'].append(tx_data)
    
    time.sleep(0.3)
    
    # Get token transfers
    token_txs = get_token_transfers(address)
    if token_txs:
        for tx in token_txs:
            # Skip fake tokens
            if not is_real_token(tx['contractAddress']):
                continue
                
            token_info = KNOWN_TOKENS.get(tx['contractAddress'].lower(), {'symbol': tx.get('tokenSymbol', 'UNKNOWN'), 'decimals': 18})
            tx_data = {
                'hash': tx['hash'],
                'timestamp': format_timestamp(tx['timeStamp']),
                'from': tx['from'],
                'to': tx['to'],
                'token': token_info['symbol'],
                'value': format_value(tx['value'], token_info['decimals']),
                'from_label': label_address(tx['from']),
                'to_label': label_address(tx['to'])
            }
            results['token_transfers'].append(tx_data)
            
            # Categorize
            if tx['from'].lower() == address:
                results['outflows'].append(tx_data)
                if is_exchange_address(tx['to']):
                    results['exchange_interactions'].append(tx_data)
            else:
                results['inflows'].append(tx_data)
    
    if verbose:
        print(f"ETH Balance: {results['eth_balance']:.4f} ETH")
        print(f"Token Balances: {results['token_balances']}")
        print(f"Normal TXs: {len(results['normal_txs'])}")
        print(f"Token Transfers: {len(results['token_transfers'])}")
        print(f"Inflows: {len(results['inflows'])}")
        print(f"Outflows: {len(results['outflows'])}")
        print(f"Exchange Interactions: {len(results['exchange_interactions'])}")
        print(f"Mixer Interactions: {len(results['mixer_interactions'])}")
    
    return results

def check_bybit_deposit(address):
    """Check if any outgoing tx goes to Bybit deposit addresses"""
    # Bybit deposit addresses forward to hot wallet quickly
    BYBIT_HOT_WALLET = "0xf89d7b9c864f589bbf53a82105107622b35eaa40"
    
    txs = get_normal_transactions(address)
    if not txs:
        return []
    
    bybit_deposits = []
    for tx in txs:
        if tx['from'].lower() == address.lower():
            # Check if recipient forwards to Bybit hot wallet
            time.sleep(0.3)
            recipient_txs = get_normal_transactions(tx['to'])
            if recipient_txs:
                for rtx in recipient_txs:
                    if rtx['to'].lower() == BYBIT_HOT_WALLET.lower():
                        bybit_deposits.append({
                            'original_tx': tx['hash'],
                            'recipient': tx['to'],
                            'amount_eth': format_value(tx['value'], 18),
                            'timestamp': format_timestamp(tx['timeStamp']),
                            'bybit_sweep_tx': rtx['hash']
                        })
                        break
    
    return bybit_deposits

if __name__ == "__main__":
    # Test with main attacker wallet
    print("Testing ETH Tracer...")
    
    # Quick balance check
    main_wallet = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"
    eth_bal = get_eth_balance(main_wallet)
    print(f"Main wallet ETH balance: {eth_bal:.4f}")
    
    usdt_bal = get_token_balance(main_wallet, "0xdac17f958d2ee523a2206206994597c13d831ec7")
    print(f"Main wallet USDT balance: {usdt_bal:.2f}")
