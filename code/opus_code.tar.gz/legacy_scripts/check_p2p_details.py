#!/usr/bin/env python3
"""
Check P2P wallet details more carefully
"""

import json
import requests
from collections import defaultdict
from datetime import datetime

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
ETH_API = "https://api.etherscan.io/v2/api"

p2p_wallet = "0xae1e8796052db5f4a975a006800ae33a20845078"

# Get transactions
params = {
    "chainid": 1,
    "module": "account",
    "action": "tokentx",
    "address": p2p_wallet,
    "apikey": ETHERSCAN_API_KEY
}
resp = requests.get(ETH_API, params=params, timeout=30)
data = resp.json()
txs = data.get("result", [])

print(f"Total token transactions: {len(txs)}")

# Separate incoming and outgoing
incoming = [tx for tx in txs if tx.get("to", "").lower() == p2p_wallet.lower()]
outgoing = [tx for tx in txs if tx.get("from", "").lower() == p2p_wallet.lower()]

print(f"Incoming: {len(incoming)}")
print(f"Outgoing: {len(outgoing)}")

# Check USDT only
usdt_contract = "0xdac17f958d2ee523a2206206994597c13d831ec7"
usdt_in = [tx for tx in incoming if tx.get("contractAddress", "").lower() == usdt_contract.lower()]
usdt_out = [tx for tx in outgoing if tx.get("contractAddress", "").lower() == usdt_contract.lower()]

print(f"\nUSDT transactions only:")
print(f"  Incoming: {len(usdt_in)}")
print(f"  Outgoing: {len(usdt_out)}")

# Calculate totals
total_in = sum(float(tx.get("value", 0)) / 1e6 for tx in usdt_in)
total_out = sum(float(tx.get("value", 0)) / 1e6 for tx in usdt_out)

print(f"\nUSDT totals:")
print(f"  Total received: ${total_in:,.2f}")
print(f"  Total sent: ${total_out:,.2f}")
print(f"  Balance: ${total_in - total_out:,.2f}")

# Time range
if usdt_in:
    timestamps = [int(tx.get("timeStamp", 0)) for tx in usdt_in + usdt_out]
    min_ts = min(timestamps)
    max_ts = max(timestamps)
    print(f"\nTime range:")
    print(f"  First: {datetime.utcfromtimestamp(min_ts)}")
    print(f"  Last: {datetime.utcfromtimestamp(max_ts)}")

# Check incoming sources
print("\n" + "=" * 60)
print("INCOMING USDT SOURCES (grouped)")
print("=" * 60)

in_sources = defaultdict(float)
for tx in usdt_in:
    from_addr = tx.get("from", "").lower()
    value = float(tx.get("value", 0)) / 1e6
    in_sources[from_addr] += value

for addr, amt in sorted(in_sources.items(), key=lambda x: x[1], reverse=True)[:10]:
    print(f"  {addr[:20]}... ${amt:,.2f}")

# Check outgoing destinations (time-filtered to heist period)
print("\n" + "=" * 60)
print("OUTGOING USDT DESTINATIONS (Dec 29 - Jan 11 only)")
print("=" * 60)

# Heist was Dec 28, 2025. Filter to Dec 29 onwards
heist_start = datetime(2025, 12, 29).timestamp()

heist_period_out = [tx for tx in usdt_out if int(tx.get("timeStamp", 0)) >= heist_start]
print(f"Transactions in heist period: {len(heist_period_out)}")

out_dests = defaultdict(float)
for tx in heist_period_out:
    to_addr = tx.get("to", "").lower()
    value = float(tx.get("value", 0)) / 1e6
    out_dests[to_addr] += value

print(f"Unique destinations: {len(out_dests)}")
print(f"Total distributed: ${sum(out_dests.values()):,.2f}")

print("\nTop 20 destinations by amount:")
for i, (addr, amt) in enumerate(sorted(out_dests.items(), key=lambda x: x[1], reverse=True)[:20]):
    print(f"  [{i+1:2d}] {addr} ${amt:,.2f}")

# Save the heist-period destinations
with open("heist_p2p_eth_destinations.json", "w") as f:
    json.dump({
        "p2p_wallet": p2p_wallet,
        "heist_period_start": "2025-12-29",
        "total_distributed": sum(out_dests.values()),
        "destinations": {k: v for k, v in sorted(out_dests.items(), key=lambda x: x[1], reverse=True)}
    }, f, indent=2)

print("\nSaved heist-period destinations to heist_p2p_eth_destinations.json")
