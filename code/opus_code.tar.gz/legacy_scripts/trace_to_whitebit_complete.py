#!/usr/bin/env python3
"""
Trace ALL P2P wallet destinations to find WhiteBit deposit addresses.
Focus: Find common endpoints and identify WhiteBit addresses.
"""

import json
import requests
import time
from collections import defaultdict

BSCSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

# Known exchange addresses (to identify endpoints)
KNOWN_EXCHANGES = {
    "0x8894e0a0c962cb723c1976a4421c95949be2d4e3": "Binance Hot Wallet 6",
    "0xe2fc31f816a9b94326492132018c3aecc4a93ae1": "Binance Hot Wallet 14",
    "0xdccf3b77da55107280bd850ea519df3705d1a75a": "WhiteBit Hot Wallet",
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBit",
    "0x0d4943a0c7e9679ed24c5d7b6f0c2c6a3a4e5a4e": "WhiteBit",
    "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": "Gate.io",
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": "MEXC",
    "0x4982085c9e2f89f2ecb8131eca71afad896e89cb": "Bybit",
}

def get_outgoing_usdt(address, max_txs=100):
    """Get outgoing USDT transactions from an address."""
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={BSCSCAN_API_KEY}"
    
    try:
        resp = requests.get(url, timeout=30)
        data = resp.json()
        
        if data.get('status') == '1' and data.get('result'):
            txs = data['result'][:max_txs]
            outgoing = []
            for tx in txs:
                if tx['from'].lower() == address.lower() and int(tx['value']) > 0:
                    outgoing.append({
                        'to': tx['to'].lower(),
                        'amount': int(tx['value']) / 1e18,
                        'txid': tx['hash'],
                        'time': tx['timeStamp']
                    })
            return outgoing
    except Exception as e:
        print(f"Error fetching {address}: {e}")
    return []

def label_address(addr):
    """Return label if known exchange, else None."""
    return KNOWN_EXCHANGES.get(addr.lower())

def main():
    # Load P2P data
    with open('heist_all_p2p_data.json', 'r') as f:
        data = json.load(f)
    
    # Get all P2P wallet outgoing destinations
    p2p_outgoing = data['p2p_wallet']['outgoing']
    
    # Extract unique destinations with amounts from P2P wallet
    p2p_destinations = {}
    for tx in p2p_outgoing:
        if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
            dest = tx['to'].lower()
            if dest not in p2p_destinations:
                p2p_destinations[dest] = {'total_received': 0, 'txids': []}
            p2p_destinations[dest]['total_received'] += tx['amount_usdt']
            p2p_destinations[dest]['txids'].append(tx['txid'])
    
    print(f"Found {len(p2p_destinations)} unique P2P destinations to trace")
    print(f"Total distributed: ${sum(d['total_received'] for d in p2p_destinations.values()):,.2f}")
    
    # Track where each destination sends funds
    common_endpoints = defaultdict(lambda: {
        'count': 0, 
        'total_usdt': 0, 
        'from_addresses': [], 
        'sample_txids': [],
        'label': None
    })
    
    traced_count = 0
    results_by_dest = {}
    
    for dest, info in p2p_destinations.items():
        traced_count += 1
        print(f"\r[{traced_count}/{len(p2p_destinations)}] Tracing {dest[:10]}... received ${info['total_received']:,.2f}", end='', flush=True)
        
        outgoing = get_outgoing_usdt(dest, max_txs=50)
        results_by_dest[dest] = {
            'received_from_p2p': info['total_received'],
            'outgoing_txs': outgoing
        }
        
        for tx in outgoing:
            endpoint = tx['to']
            common_endpoints[endpoint]['count'] += 1
            common_endpoints[endpoint]['total_usdt'] += tx['amount']
            if dest not in common_endpoints[endpoint]['from_addresses']:
                common_endpoints[endpoint]['from_addresses'].append(dest)
            if len(common_endpoints[endpoint]['sample_txids']) < 10:
                common_endpoints[endpoint]['sample_txids'].append(tx['txid'])
            
            # Check if known exchange
            label = label_address(endpoint)
            if label:
                common_endpoints[endpoint]['label'] = label
        
        # Rate limiting - 5 calls per second max
        time.sleep(0.22)
    
    print("\n\n" + "="*80)
    print("COMMON ENDPOINTS (addresses receiving from multiple P2P destinations)")
    print("="*80)
    
    # Sort by count (most common destinations)
    sorted_endpoints = sorted(common_endpoints.items(), key=lambda x: x[1]['count'], reverse=True)
    
    # Print top endpoints
    whitebit_candidates = []
    for addr, info in sorted_endpoints[:30]:
        label = info['label'] or "UNKNOWN"
        print(f"\n{addr}")
        print(f"  Label: {label}")
        print(f"  Received from {info['count']} P2P destinations")
        print(f"  Total: ${info['total_usdt']:,.2f}")
        print(f"  Sample TXID: {info['sample_txids'][0] if info['sample_txids'] else 'N/A'}")
        
        # If multiple sources and significant amount, likely WhiteBit
        if info['count'] >= 3:
            whitebit_candidates.append({
                'address': addr,
                'label': label,
                'source_count': info['count'],
                'total_usdt': info['total_usdt'],
                'from_addresses': info['from_addresses'],
                'sample_txids': info['sample_txids']
            })
    
    # Save results
    results = {
        'whitebit_candidates': whitebit_candidates,
        'all_endpoints': {addr: {
            'count': info['count'],
            'total_usdt': info['total_usdt'],
            'label': info['label'],
            'from_count': len(info['from_addresses']),
            'sample_txids': info['sample_txids'][:3]
        } for addr, info in sorted_endpoints},
        'traced_destinations': len(p2p_destinations),
        'total_p2p_amount': sum(d['total_received'] for d in p2p_destinations.values())
    }
    
    with open('whitebit_trace_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n\nResults saved to whitebit_trace_results.json")
    print(f"\nFound {len(whitebit_candidates)} addresses receiving from 3+ P2P destinations")
    
    # Summary
    print("\n" + "="*80)
    print("WHITEBIT DEPOSIT ADDRESS CANDIDATES")
    print("="*80)
    for c in whitebit_candidates:
        print(f"\n{c['address']}")
        print(f"  Sources: {c['source_count']} different P2P buyers")
        print(f"  Total: ${c['total_usdt']:,.2f}")

if __name__ == "__main__":
    main()
