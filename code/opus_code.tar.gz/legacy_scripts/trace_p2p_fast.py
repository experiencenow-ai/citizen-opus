#!/usr/bin/env python3
"""
Fast P2P destination tracing - batch approach with BSCScan API
"""

import json
import time
import requests
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BSCSCAN_API = "https://api.bscscan.com/api"
USDT_BSC = "0x55d398326f99059fF775485246999027B3197955"

# Known exchange deposit addresses on BSC
KNOWN_EXCHANGES = {
    # WhiteBIT
    "0xe2fc31f816a9b94326492132018c3aecc4a93ae1": "WhiteBIT",
    "0x3c783c21a0383057d128bae431894a5c19f9cf06": "WhiteBIT",
    "0x39a7c6c1a1e5f8f8f5e7e3a4c6b9f5d3c2b1a0d9": "WhiteBIT",
    # Binance
    "0x8894e0a0c962cb723c1976a4421c95949be2d4e3": "Binance Hot",
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance Hot 14",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance Hot 15",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance Hot 16",
    "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance Hot 17",
    # OKX
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    "0x98ec059dc3adfbdd63429454aeb0c990fba4a128": "OKX Hot",
    # Bybit
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    # KuCoin
    "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin",
    # HTX
    "0x5c985e89dde482efe97ea9f1950ad149eb73829b": "HTX",
}

def get_bsc_token_txs(address, max_retries=3):
    """Get token transactions for an address"""
    for attempt in range(max_retries):
        try:
            params = {
                "module": "account",
                "action": "tokentx",
                "address": address,
                "contractaddress": USDT_BSC,
                "sort": "desc",
                "apikey": ETHERSCAN_API_KEY
            }
            resp = requests.get(BSCSCAN_API, params=params, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "1":
                    return data.get("result", [])
                elif "rate limit" in data.get("message", "").lower():
                    time.sleep(1)
                    continue
            return []
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(0.5)
            continue
    return []

def main():
    # Load P2P data
    with open("heist_all_p2p_data.json", "r") as f:
        data = json.load(f)
    
    # Get all P2P destinations with amounts
    p2p_destinations = {}
    
    for tx in data.get("p2p_wallet", {}).get("outgoing", []):
        if tx.get("direction") == "OUT" and tx.get("amount_usdt", 0) > 0:
            to_addr = tx.get("to", "").lower()
            if to_addr:
                if to_addr not in p2p_destinations:
                    p2p_destinations[to_addr] = {"received": 0, "txs": []}
                p2p_destinations[to_addr]["received"] += tx.get("amount_usdt", 0)
                p2p_destinations[to_addr]["txs"].append(tx.get("txid"))
    
    print(f"Found {len(p2p_destinations)} unique P2P destinations")
    
    # Track final destinations
    exchange_flows = defaultdict(lambda: {"amount": 0, "p2p_wallets": [], "txids": []})
    unknown_flows = defaultdict(lambda: {"amount": 0, "p2p_wallets": []})
    still_in_wallet = {"amount": 0, "wallets": []}
    
    # Sort by amount (highest first) and process
    sorted_addrs = sorted(p2p_destinations.keys(), key=lambda x: p2p_destinations[x]["received"], reverse=True)
    
    print("\nTracing destinations (checking outgoing transactions)...")
    print("-" * 70)
    
    for i, addr in enumerate(sorted_addrs):
        info = p2p_destinations[addr]
        amt = info["received"]
        
        # Rate limit
        if i > 0 and i % 5 == 0:
            time.sleep(1)
        
        # Get outgoing transactions
        txs = get_bsc_token_txs(addr)
        
        # Filter to outgoing only
        outgoing = [tx for tx in txs if tx.get("from", "").lower() == addr]
        
        if not outgoing:
            still_in_wallet["amount"] += amt
            still_in_wallet["wallets"].append(addr)
            print(f"[{i+1:3d}] {addr[:12]}... ${amt:>10,.0f} -> Still in wallet")
            continue
        
        # Check where funds went
        found_exchange = False
        for tx in outgoing[:10]:  # Check first 10 outgoing
            to_addr = tx.get("to", "").lower()
            tx_amt = float(tx.get("value", 0)) / 1e18
            
            # Check if it's a known exchange
            for known_addr, exchange_name in KNOWN_EXCHANGES.items():
                if to_addr == known_addr.lower():
                    exchange_flows[exchange_name]["amount"] += tx_amt
                    exchange_flows[exchange_name]["p2p_wallets"].append(addr)
                    exchange_flows[exchange_name]["txids"].append(tx.get("hash"))
                    print(f"[{i+1:3d}] {addr[:12]}... ${amt:>10,.0f} -> {exchange_name} (${tx_amt:,.0f})")
                    found_exchange = True
                    break
            
            if not found_exchange:
                # Track unknown destination for pattern analysis
                unknown_flows[to_addr]["amount"] += tx_amt
                unknown_flows[to_addr]["p2p_wallets"].append(addr)
        
        if not found_exchange:
            # Get the primary destination (highest amount)
            primary_dest = max(outgoing, key=lambda x: float(x.get("value", 0)))
            to_addr = primary_dest.get("to", "")[:12]
            print(f"[{i+1:3d}] {addr[:12]}... ${amt:>10,.0f} -> Unknown ({to_addr}...)")
    
    # Summary
    print("\n" + "=" * 70)
    print("EXCHANGE FLOW SUMMARY")
    print("=" * 70)
    
    total_to_exchanges = 0
    for exchange, info in sorted(exchange_flows.items(), key=lambda x: x[1]["amount"], reverse=True):
        print(f"\n{exchange}:")
        print(f"  Total Amount: ${info['amount']:,.2f}")
        print(f"  From {len(set(info['p2p_wallets']))} P2P wallets")
        total_to_exchanges += info["amount"]
        if info["txids"]:
            print(f"  Sample TXIDs:")
            for txid in info["txids"][:3]:
                print(f"    https://bscscan.com/tx/{txid}")
    
    print(f"\n{'=' * 70}")
    print(f"Total traced to known exchanges: ${total_to_exchanges:,.2f}")
    print(f"Still in P2P wallets: ${still_in_wallet['amount']:,.2f} ({len(still_in_wallet['wallets'])} wallets)")
    print(f"To unknown addresses: ${sum(x['amount'] for x in unknown_flows.values()):,.2f}")
    
    # Find common unknown destinations
    print(f"\n{'=' * 70}")
    print("TOP UNKNOWN DESTINATIONS (may be unlabeled exchanges)")
    print("=" * 70)
    
    sorted_unknown = sorted(unknown_flows.items(), key=lambda x: x[1]["amount"], reverse=True)[:15]
    for addr, info in sorted_unknown:
        print(f"\n{addr}")
        print(f"  Received: ${info['amount']:,.2f} from {len(set(info['p2p_wallets']))} P2P wallets")
    
    # Save results
    results = {
        "exchange_flows": {k: {"amount": v["amount"], "wallet_count": len(set(v["p2p_wallets"])), "txids": v["txids"][:10]} for k, v in exchange_flows.items()},
        "still_in_wallet": {"amount": still_in_wallet["amount"], "count": len(still_in_wallet["wallets"])},
        "top_unknown": {k: {"amount": v["amount"], "sources": len(set(v["p2p_wallets"]))} for k, v in sorted_unknown}
    }
    
    with open("heist_exchange_trace.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to heist_exchange_trace.json")

if __name__ == "__main__":
    main()
