#!/usr/bin/env python3
"""
Trace all P2P wallet destinations to find common endpoints (WhiteBit addresses).
"""

import json
import requests
import time
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

def get_outgoing_usdt(address, max_txs=50):
    """Get outgoing USDT transactions from an address."""
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={ETHERSCAN_API_KEY}"
    
    try:
        resp = requests.get(url, timeout=30)
        data = resp.json()
        
        if data.get('status') == '1' and data.get('result'):
            txs = data['result'][:max_txs]
            outgoing = []
            for tx in txs:
                if tx['from'].lower() == address.lower() and int(tx['value']) > 0:
                    outgoing.append({
                        'to': tx['to'].lower(),
                        'amount': int(tx['value']) / 1e18,
                        'txid': tx['hash'],
                        'time': tx['timeStamp']
                    })
            return outgoing
    except Exception as e:
        print(f"Error fetching {address}: {e}")
    return []

def main():
    # Load P2P data
    with open('heist_all_p2p_data.json', 'r') as f:
        data = json.load(f)
    
    # Get all P2P wallet outgoing destinations
    p2p_outgoing = data['p2p_wallet']['outgoing']
    
    # Extract unique destinations from P2P wallet
    p2p_destinations = set()
    for tx in p2p_outgoing:
        if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
            p2p_destinations.add(tx['to'].lower())
    
    print(f"Found {len(p2p_destinations)} unique P2P destinations to trace")
    
    # Track where each destination sends funds
    common_endpoints = defaultdict(lambda: {'count': 0, 'total_usdt': 0, 'from_addresses': [], 'txids': []})
    traced_count = 0
    
    for dest in p2p_destinations:
        traced_count += 1
        print(f"\n[{traced_count}/{len(p2p_destinations)}] Tracing {dest[:10]}...")
        
        outgoing = get_outgoing_usdt(dest, max_txs=20)
        
        for tx in outgoing:
            endpoint = tx['to']
            common_endpoints[endpoint]['count'] += 1
            common_endpoints[endpoint]['total_usdt'] += tx['amount']
            if dest not in common_endpoints[endpoint]['from_addresses']:
                common_endpoints[endpoint]['from_addresses'].append(dest)
            common_endpoints[endpoint]['txids'].append(tx['txid'])
        
        # Rate limiting - 5 calls per second max
        time.sleep(0.25)
    
    # Sort by count (most common destinations)
    sorted_endpoints = sorted(common_endpoints.items(), key=lambda x: x[1]['count'], reverse=True)
    
    print("\n" + "="*80)
    print("COMMON ENDPOINTS (addresses receiving from multiple P2P destinations)")
    print("="*80)
    
    results = []
    for endpoint, info in sorted_endpoints[:30]:  # Top 30
        if info['count'] >= 2:  # At least 2 different sources
            print(f"\n{endpoint}")
            print(f"  Received from {info['count']} P2P destinations")
            print(f"  Total USDT: ${info['total_usdt']:,.2f}")
            print(f"  Sources: {len(info['from_addresses'])} unique addresses")
            results.append({
                'address': endpoint,
                'receive_count': info['count'],
                'total_usdt': info['total_usdt'],
                'source_count': len(info['from_addresses']),
                'sources': info['from_addresses'][:10],  # First 10
                'sample_txids': info['txids'][:5]  # First 5 txids
            })
    
    # Save results
    output = {
        'analysis_type': 'P2P destination tracing',
        'p2p_destinations_traced': len(p2p_destinations),
        'common_endpoints': results
    }
    
    with open('whitebit_trace_results.json', 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n\nResults saved to whitebit_trace_results.json")
    print(f"Found {len(results)} addresses receiving from multiple P2P destinations")

if __name__ == '__main__':
    main()
