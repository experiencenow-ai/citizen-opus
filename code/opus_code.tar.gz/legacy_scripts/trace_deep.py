#!/usr/bin/env python3
"""
Deep trace - follow the money 2 hops from P2P destinations.
ct said spot checking 3 destinations that got $4k each all went to WhiteBit.
"""

import json
import requests
import time
from collections import defaultdict

BSCSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

def get_outgoing(address):
    """Get outgoing USDT transactions."""
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={BSCSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1':
            return [{'to': tx['to'].lower(), 'amt': int(tx['value'])/1e18, 'tx': tx['hash']} 
                    for tx in data['result'][:30] 
                    if tx['from'].lower() == address.lower() and int(tx['value']) > 0]
    except Exception as e:
        print(f"  Error: {e}")
    return []

# Load data
with open('heist_all_p2p_data.json') as f:
    data = json.load(f)

# Get destinations
dests = {}
for tx in data['p2p_wallet']['outgoing']:
    if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
        d = tx['to'].lower()
        dests[d] = dests.get(d, 0) + tx['amount_usdt']

# Focus on $4k destinations (the ones ct mentioned)
four_k_dests = [(d, a) for d, a in dests.items() if 3900 < a < 4100]
print(f"Found {len(four_k_dests)} destinations that received ~$4k each")

# Track 2-hop endpoints
hop1_endpoints = defaultdict(lambda: {'sources': set(), 'total': 0, 'txids': []})
hop2_endpoints = defaultdict(lambda: {'sources': set(), 'total': 0, 'txids': []})

# Trace first 15 of the $4k destinations
for i, (dest, amt) in enumerate(four_k_dests[:15]):
    print(f"\n[{i+1}/15] {dest} (${amt:,.0f})")
    
    hop1_txs = get_outgoing(dest)
    print(f"  Hop 1: {len(hop1_txs)} outgoing transactions")
    
    for tx in hop1_txs:
        hop1 = tx['to']
        hop1_endpoints[hop1]['sources'].add(dest)
        hop1_endpoints[hop1]['total'] += tx['amt']
        if len(hop1_endpoints[hop1]['txids']) < 3:
            hop1_endpoints[hop1]['txids'].append(tx['tx'])
        
        print(f"    -> {hop1[:15]}... ${tx['amt']:,.0f}")
    
    time.sleep(0.22)

# Now trace hop1 endpoints to find hop2 (WhiteBit)
print("\n" + "="*60)
print("HOP 1 ENDPOINTS (first destination from P2P buyers)")
print("="*60)

sorted_hop1 = sorted(hop1_endpoints.items(), key=lambda x: len(x[1]['sources']), reverse=True)
for addr, info in sorted_hop1[:10]:
    print(f"\n{addr}")
    print(f"  From {len(info['sources'])} P2P buyers -> ${info['total']:,.2f}")

# Trace top hop1 endpoints to find hop2
print("\n" + "="*60)
print("TRACING HOP 1 -> HOP 2 (finding WhiteBit)")
print("="*60)

for addr, info in sorted_hop1[:10]:
    if len(info['sources']) >= 1:
        print(f"\nTracing {addr[:15]}...")
        hop2_txs = get_outgoing(addr)
        for tx in hop2_txs:
            hop2 = tx['to']
            hop2_endpoints[hop2]['sources'].add(addr)
            hop2_endpoints[hop2]['total'] += tx['amt']
            if len(hop2_endpoints[hop2]['txids']) < 3:
                hop2_endpoints[hop2]['txids'].append(tx['tx'])
            print(f"  -> {hop2[:15]}... ${tx['amt']:,.0f}")
        time.sleep(0.22)

print("\n" + "="*60)
print("HOP 2 ENDPOINTS (likely WhiteBit deposit addresses)")
print("="*60)

sorted_hop2 = sorted(hop2_endpoints.items(), key=lambda x: len(x[1]['sources']), reverse=True)
for addr, info in sorted_hop2[:15]:
    print(f"\n{addr}")
    print(f"  From {len(info['sources'])} hop1 addresses -> ${info['total']:,.2f}")
    print(f"  TX: {info['txids'][0]}" if info['txids'] else "")

# Save results
results = {
    'hop1_endpoints': [{
        'address': a,
        'source_count': len(i['sources']),
        'total': i['total'],
        'txids': i['txids']
    } for a, i in sorted_hop1[:20]],
    'hop2_endpoints': [{
        'address': a,
        'source_count': len(i['sources']),
        'total': i['total'],
        'txids': i['txids']
    } for a, i in sorted_hop2[:20]]
}

with open('whitebit_deep_trace.json', 'w') as f:
    json.dump(results, f, indent=2)
print("\n\nSaved to whitebit_deep_trace.json")
