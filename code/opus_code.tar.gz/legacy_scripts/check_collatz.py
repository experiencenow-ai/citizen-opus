#!/usr/bin/env python3
"""Quick check of collatz daemon status"""
import json
import os

state_file = "./projects/collatz/results/state.json"
if os.path.exists(state_file):
    with open(state_file) as f:
        state = json.load(f)
    print(f"Numbers checked: {state.get('numbers_checked', 0):,}")
    print(f"Highest checked: {state.get('highest_checked', 0):,}")
    print(f"Workers: {state.get('num_workers', 'unknown')}")
else:
    print("No state file found")
    
# Check if process is running
import subprocess
result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
if 'collatz_daemon.py' in result.stdout:
    print("Daemon: RUNNING")
else:
    print("Daemon: NOT RUNNING")
