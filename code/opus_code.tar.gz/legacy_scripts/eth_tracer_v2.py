#!/usr/bin/env python3
"""
Ethereum USDT Tracer using Etherscan API v2
Unified API for all chains
"""
import requests
import time
import json
from datetime import datetime

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"

# Common contracts
USDT_ETH = "0xdac17f958d2ee523a2206206994597c13d831ec7"
USDC_ETH = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"

# Known exchange addresses
KNOWN_EXCHANGES = {
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance",
    "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance",
    "0x4e68ccd3e89f51c3074ca5072bbac773960dfa36": "Uniswap V3",
    "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640": "Uniswap V3 USDC/ETH",
}

class EthTracerV2:
    def __init__(self, chain_id=1):
        self.chain_id = chain_id
        self.rate_limit_delay = 0.2  # 5 calls/sec for free tier
    
    def _call_api(self, module, action, **params):
        """Make API call with rate limiting"""
        all_params = {
            "chainid": self.chain_id,
            "module": module,
            "action": action,
            "apikey": API_KEY,
            **params
        }
        
        try:
            resp = requests.get(BASE_URL, params=all_params, timeout=30)
            data = resp.json()
            time.sleep(self.rate_limit_delay)
            return data
        except Exception as e:
            print(f"API error: {e}")
            return None
    
    def get_token_transfers(self, address, contract=USDT_ETH, start_block=0):
        """Get all token transfers for an address"""
        result = self._call_api(
            "account", "tokentx",
            address=address,
            contractaddress=contract,
            startblock=start_block,
            sort="asc"
        )
        
        if result and result.get("status") == "1":
            return result.get("result", [])
        return []
    
    def get_eth_balance(self, address):
        """Get ETH balance"""
        result = self._call_api(
            "account", "balance",
            address=address,
            tag="latest"
        )
        
        if result and result.get("status") == "1":
            return int(result.get("result", 0)) / 1e18
        return 0
    
    def get_token_balance(self, address, contract=USDT_ETH):
        """Get token balance"""
        result = self._call_api(
            "account", "tokenbalance",
            address=address,
            contractaddress=contract,
            tag="latest"
        )
        
        if result and result.get("status") == "1":
            return int(result.get("result", 0)) / 1e6  # USDT has 6 decimals
        return 0
    
    def trace_outflows(self, address, contract=USDT_ETH, min_value=100):
        """Trace all outgoing transfers from an address"""
        transfers = self.get_token_transfers(address, contract)
        
        outflows = []
        for t in transfers:
            if t["from"].lower() == address.lower():
                value = int(t["value"]) / 1e6
                if value >= min_value:
                    dest = t["to"].lower()
                    label = KNOWN_EXCHANGES.get(dest, "Unknown")
                    
                    outflows.append({
                        "to": dest,
                        "label": label,
                        "amount": value,
                        "txid": t["hash"],
                        "timestamp": datetime.utcfromtimestamp(int(t["timeStamp"])).isoformat(),
                        "block": t["blockNumber"]
                    })
        
        return outflows
    
    def identify_exchange(self, address):
        """Check if address is a known exchange"""
        return KNOWN_EXCHANGES.get(address.lower(), None)


def main():
    """Example usage"""
    tracer = EthTracerV2(chain_id=1)
    
    # Example: trace P2P wallet
    p2p_wallet = "0xae1e8796052db5f4a975a006800ae33a20845078"
    
    print(f"Tracing {p2p_wallet}")
    print("=" * 60)
    
    # Get balance
    usdt_balance = tracer.get_token_balance(p2p_wallet)
    print(f"Current USDT balance: ${usdt_balance:,.2f}")
    
    # Get outflows
    outflows = tracer.trace_outflows(p2p_wallet, min_value=500)
    print(f"\nOutflows (>$500): {len(outflows)}")
    
    for o in outflows[:10]:
        print(f"  ${o['amount']:,.2f} -> {o['to'][:16]}... ({o['label']})")


if __name__ == "__main__":
    main()
