#!/usr/bin/env python3
"""
Trace P2P destinations on ETHEREUM (not BSC) to find WhiteBit.
"""

import json
import requests
import time
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"  # USDT on Ethereum

def get_outgoing_usdt(address):
    """Get outgoing USDT transactions on Ethereum."""
    url = f"https://api.etherscan.io/v2/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={ETHERSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1' and data.get('result'):
            return [{'to': tx['to'].lower(), 'amt': int(tx['value'])/1e6, 'tx': tx['hash']} 
                    for tx in data['result'][:30] 
                    if tx['from'].lower() == address.lower() and int(tx['value']) > 0]
    except Exception as e:
        print(f"  Error: {e}")
    return []

def get_all_token_tx(address):
    """Get ALL token transactions for an address on Ethereum."""
    url = f"https://api.etherscan.io/v2/api?module=account&action=tokentx&address={address}&sort=desc&apikey={ETHERSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1':
            return data['result'][:50]
    except:
        pass
    return []

# Load P2P data
with open('heist_all_p2p_data.json') as f:
    data = json.load(f)

# Get destinations with amounts
dests = {}
for tx in data['p2p_wallet']['outgoing']:
    if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
        d = tx['to'].lower()
        dests[d] = dests.get(d, 0) + tx['amount_usdt']

# Sort by amount
sorted_dests = sorted(dests.items(), key=lambda x: x[1], reverse=True)

print(f"Tracing {len(sorted_dests)} P2P destinations on ETHEREUM...")
print("="*70)

# Track endpoints
endpoints = defaultdict(lambda: {'sources': set(), 'total': 0, 'txids': []})

# Trace top 30 destinations
for i, (dest, amt) in enumerate(sorted_dests[:30]):
    print(f"\n[{i+1}/30] {dest[:15]}... received ${amt:,.0f}")
    
    # Get outgoing USDT
    outgoing = get_outgoing_usdt(dest)
    print(f"  Outgoing USDT: {len(outgoing)} transactions")
    
    for tx in outgoing:
        ep = tx['to']
        endpoints[ep]['sources'].add(dest)
        endpoints[ep]['total'] += tx['amt']
        if len(endpoints[ep]['txids']) < 3:
            endpoints[ep]['txids'].append(tx['tx'])
        print(f"    -> {ep[:15]}... ${tx['amt']:,.0f}")
    
    # If no outgoing, check if it's an exchange deposit
    if not outgoing:
        all_txs = get_all_token_tx(dest)
        in_count = sum(1 for tx in all_txs if tx.get('to', '').lower() == dest.lower())
        out_count = sum(1 for tx in all_txs if tx.get('from', '').lower() == dest.lower())
        print(f"  All tokens: {in_count} in, {out_count} out")
        if out_count == 0:
            print(f"  *** LIKELY EXCHANGE DEPOSIT (no outgoing) ***")
    
    time.sleep(0.22)

# Sort endpoints by source count
sorted_eps = sorted(endpoints.items(), key=lambda x: len(x[1]['sources']), reverse=True)

print("\n" + "="*70)
print("COMMON ENDPOINTS (WhiteBit candidates)")
print("="*70)

whitebit_addrs = []
for addr, info in sorted_eps[:20]:
    src_count = len(info['sources'])
    if src_count >= 2:
        whitebit_addrs.append({
            'address': addr,
            'source_count': src_count,
            'total_usdt': info['total'],
            'txids': info['txids']
        })
    print(f"\n{addr}")
    print(f"  From {src_count} P2P buyers -> ${info['total']:,.2f}")
    if info['txids']:
        print(f"  TX: {info['txids'][0]}")

# Save results
with open('whitebit_eth_trace.json', 'w') as f:
    json.dump({
        'whitebit_candidates': whitebit_addrs,
        'all_endpoints': [{
            'address': a,
            'source_count': len(i['sources']),
            'total': i['total'],
            'txids': i['txids']
        } for a, i in sorted_eps[:30]]
    }, f, indent=2)

print(f"\n\nSaved to whitebit_eth_trace.json")
