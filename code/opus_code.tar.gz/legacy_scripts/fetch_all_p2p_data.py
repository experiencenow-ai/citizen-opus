#!/usr/bin/env python3
"""
Fetch all P2P-related transactions for the heist investigation
Includes: P2P wallet, Attacker direct distributions, Hop wallets
"""

import requests
import json
import time
from datetime import datetime, timedelta, timezone

API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BASE_URL = "https://api.etherscan.io/v2/api"

# Key wallets
P2P_WALLET = "0xae1e8796052db5f4a975a006800ae33a20845078"
ATTACKER_WALLET = "0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7"
HOP1_WALLET = "0x1F98E7D1e0d0B65e2b5Db4a9e4d8f3C2A1B0C9D8"  # placeholder - will find real one

# USDT Contract
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

def get_token_transfers(address, contract=None):
    """Get ERC20 token transfers for an address"""
    params = {
        'module': 'account',
        'action': 'tokentx',
        'address': address,
        'startblock': 0,
        'endblock': 99999999,
        'sort': 'desc',
        'apikey': API_KEY,
        'chainid': 1
    }
    if contract:
        params['contractaddress'] = contract
    
    try:
        resp = requests.get(BASE_URL, params=params, timeout=60)
        data = resp.json()
        if data.get('status') == '1':
            return data.get('result', [])
        else:
            print(f"API Error for {address[:10]}...: {data.get('message')}")
            return []
    except Exception as e:
        print(f"Request error: {e}")
        return []

def format_timestamp(unix_ts):
    """Convert unix timestamp to UTC and Antalya time (UTC+3)"""
    utc_dt = datetime.fromtimestamp(int(unix_ts), tz=timezone.utc)
    antalya_dt = utc_dt + timedelta(hours=3)
    return utc_dt.strftime('%Y-%m-%d %H:%M:%S'), antalya_dt.strftime('%Y-%m-%d %H:%M:%S')

def process_transfers(transfers, wallet_address, direction='out'):
    """Process transfers and filter by direction"""
    results = []
    for tx in transfers:
        if int(tx['value']) == 0:
            continue  # Skip 0-value (address poisoning)
            
        is_outgoing = tx['from'].lower() == wallet_address.lower()
        is_incoming = tx['to'].lower() == wallet_address.lower()
        
        if direction == 'out' and not is_outgoing:
            continue
        if direction == 'in' and not is_incoming:
            continue
        if direction == 'both':
            pass  # Include all
            
        value_usdt = int(tx['value']) / 1e6
        utc_time, antalya_time = format_timestamp(tx['timeStamp'])
        
        results.append({
            'txid': tx['hash'],
            'utc_time': utc_time,
            'antalya_time': antalya_time,
            'amount_usdt': round(value_usdt, 2),
            'from': tx['from'],
            'to': tx['to'],
            'direction': 'OUT' if is_outgoing else 'IN',
            'block': int(tx['blockNumber'])
        })
    
    return sorted(results, key=lambda x: x['utc_time'], reverse=True)

def main():
    all_data = {}
    
    # 1. P2P Distribution Wallet
    print("=" * 80)
    print("1. P2P DISTRIBUTION WALLET")
    print(f"   {P2P_WALLET}")
    print("=" * 80)
    
    p2p_transfers = get_token_transfers(P2P_WALLET, USDT_CONTRACT)
    p2p_out = process_transfers(p2p_transfers, P2P_WALLET, 'out')
    p2p_in = process_transfers(p2p_transfers, P2P_WALLET, 'in')
    
    print(f"   Outgoing: {len(p2p_out)} transfers, ${sum(t['amount_usdt'] for t in p2p_out):,.2f}")
    print(f"   Incoming: {len(p2p_in)} transfers, ${sum(t['amount_usdt'] for t in p2p_in):,.2f}")
    
    all_data['p2p_wallet'] = {
        'address': P2P_WALLET,
        'outgoing': p2p_out,
        'outgoing_total': round(sum(t['amount_usdt'] for t in p2p_out), 2),
        'incoming': p2p_in,
        'incoming_total': round(sum(t['amount_usdt'] for t in p2p_in), 2)
    }
    
    time.sleep(0.5)  # Rate limit
    
    # 2. Attacker Main Wallet
    print("\n" + "=" * 80)
    print("2. ATTACKER MAIN WALLET")
    print(f"   {ATTACKER_WALLET}")
    print("=" * 80)
    
    attacker_transfers = get_token_transfers(ATTACKER_WALLET, USDT_CONTRACT)
    attacker_out = process_transfers(attacker_transfers, ATTACKER_WALLET, 'out')
    attacker_in = process_transfers(attacker_transfers, ATTACKER_WALLET, 'in')
    
    print(f"   Outgoing: {len(attacker_out)} transfers, ${sum(t['amount_usdt'] for t in attacker_out):,.2f}")
    print(f"   Incoming: {len(attacker_in)} transfers, ${sum(t['amount_usdt'] for t in attacker_in):,.2f}")
    
    all_data['attacker_wallet'] = {
        'address': ATTACKER_WALLET,
        'outgoing': attacker_out,
        'outgoing_total': round(sum(t['amount_usdt'] for t in attacker_out), 2),
        'incoming': attacker_in,
        'incoming_total': round(sum(t['amount_usdt'] for t in attacker_in), 2)
    }
    
    # Save all data
    with open('heist_all_p2p_data.json', 'w') as f:
        json.dump(all_data, f, indent=2)
    
    print(f"\nSaved complete data to heist_all_p2p_data.json")
    
    # Print summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"P2P Wallet Outgoing:     ${all_data['p2p_wallet']['outgoing_total']:>12,.2f} ({len(p2p_out)} txs)")
    print(f"Attacker Wallet Outgoing: ${all_data['attacker_wallet']['outgoing_total']:>12,.2f} ({len(attacker_out)} txs)")

if __name__ == "__main__":
    main()
