#!/usr/bin/env python3
"""
Trace ALL P2P destinations to find common endpoints (exchanges)
"""

import json
import time
import requests
from collections import defaultdict

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
ETH_API = "https://api.etherscan.io/v2/api"
USDT_CONTRACT = "0xdac17f958d2ee523a2206206994597c13d831ec7"

# Known exchange hot wallets on Ethereum
KNOWN_EXCHANGES = {
    # WhiteBIT - multiple hot wallets
    "0x39f6a6c85d39d5abad8a398310c52e7c374f2ba3": "WhiteBIT",
    "0xe17b08ad90ca38c87959d81d5bf106d8b8bf80a9": "WhiteBIT",  # May be hot wallet
    # Binance
    "0x28c6c06298d514db089934071355e5743bf21d60": "Binance",
    "0x21a31ee1afc51d94c2efccaa2092ad1028285549": "Binance",
    "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": "Binance",
    "0x56eddb7aa87536c09ccc2793473599fd21a8b17f": "Binance",
    "0xf977814e90da44bfa03b6295a0616a897441acec": "Binance",
    "0x5a52e96bacdabb82fd05763e25335261b270efcb": "Binance",
    "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": "Binance",
    # OKX
    "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": "OKX",
    "0x98ec059dc3adfbdd63429454aeb0c990fba4a128": "OKX",
    # Bybit
    "0xf89d7b9c864f589bbf53a82105107622b35eaa40": "Bybit",
    "0x1db92e2eebc8e0c075a02bea49a2935bcd2dfcf4": "Bybit",
    # KuCoin
    "0x2b5634c42055806a59e9107ed44d43c426e58258": "KuCoin",
    "0xd6216fc19db775df9774a6e33526131da7d19a2c": "KuCoin",
    # HTX (Huobi)
    "0x5c985e89dde482efe97ea9f1950ad149eb73829b": "HTX",
    "0xab5c66752a9e8167967685f1450532fb96d5d24f": "HTX",
    # Gate.io
    "0x0d0707963952f2fba59dd06f2b425ace40b492fe": "Gate.io",
    "0x1c4b70a3968436b9a0a9cf5205c787eb81bb558c": "Gate.io",
    # Kraken
    "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": "Kraken",
    # MEXC
    "0x3cc936b795a188f0e246cbb2d74c5bd190aecf18": "MEXC",
    # Crypto.com
    "0x6262998ced04146fa42253a5c0af90ca02dfd2a3": "Crypto.com",
}

def get_usdt_txs(address):
    """Get USDT transactions for an address"""
    try:
        params = {
            "chainid": 1,
            "module": "account",
            "action": "tokentx",
            "address": address,
            "contractaddress": USDT_CONTRACT,
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(ETH_API, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except:
        pass
    return []

def identify_exchange(address):
    """Check if address is a known exchange"""
    addr_lower = address.lower()
    for known_addr, name in KNOWN_EXCHANGES.items():
        if known_addr.lower() == addr_lower:
            return name
    return None

# Load destinations
with open("heist_p2p_eth_destinations.json", "r") as f:
    data = json.load(f)

destinations = data["destinations"]
print(f"Tracing {len(destinations)} P2P destinations...")
print("=" * 70)

# Track final destinations
final_dests = defaultdict(lambda: {"amount": 0, "sources": [], "txids": []})
unknown_common = defaultdict(lambda: {"amount": 0, "sources": []})

processed = 0
for addr, amt in destinations.items():
    processed += 1
    addr_lower = addr.lower()
    
    # Check if direct to known exchange
    exchange = identify_exchange(addr)
    if exchange:
        print(f"[{processed:3d}] ${amt:>10,.0f} -> {exchange} (direct)")
        final_dests[exchange]["amount"] += amt
        final_dests[exchange]["sources"].append(addr)
        continue
    
    # Rate limit - 5 calls/sec max
    if processed % 5 == 0:
        time.sleep(1.1)
    
    # Get outgoing USDT transactions
    txs = get_usdt_txs(addr)
    outgoing = [tx for tx in txs if tx.get("from", "").lower() == addr_lower]
    
    if not outgoing:
        print(f"[{processed:3d}] ${amt:>10,.0f} -> Still in wallet ({addr[:10]}...)")
        final_dests["Still in wallet"]["amount"] += amt
        final_dests["Still in wallet"]["sources"].append(addr)
        continue
    
    # Group outgoing by destination
    out_dests = defaultdict(lambda: {"amount": 0, "txid": None})
    for tx in outgoing:
        to = tx.get("to", "").lower()
        val = float(tx.get("value", 0)) / 1e6
        out_dests[to]["amount"] += val
        out_dests[to]["txid"] = tx.get("hash")
    
    # Check each destination for known exchanges
    found_exchange = False
    for to_addr, to_info in sorted(out_dests.items(), key=lambda x: x[1]["amount"], reverse=True):
        exchange = identify_exchange(to_addr)
        if exchange:
            print(f"[{processed:3d}] ${amt:>10,.0f} -> {exchange} (${to_info['amount']:,.0f})")
            final_dests[exchange]["amount"] += to_info["amount"]
            final_dests[exchange]["sources"].append(addr)
            final_dests[exchange]["txids"].append(to_info["txid"])
            found_exchange = True
            break
    
    if not found_exchange:
        # Track unknown destinations for pattern analysis
        primary = max(out_dests.items(), key=lambda x: x[1]["amount"])
        to_addr = primary[0]
        to_amt = primary[1]["amount"]
        print(f"[{processed:3d}] ${amt:>10,.0f} -> Unknown ({to_addr[:12]}...) ${to_amt:,.0f}")
        unknown_common[to_addr]["amount"] += to_amt
        unknown_common[to_addr]["sources"].append(addr)

# Summary
print("\n" + "=" * 70)
print("FINAL DESTINATION SUMMARY")
print("=" * 70)

total_exchange = 0
print("\n### KNOWN EXCHANGES ###")
for dest, info in sorted(final_dests.items(), key=lambda x: x[1]["amount"], reverse=True):
    if dest != "Still in wallet":
        print(f"\n{dest}")
        print(f"  Total: ${info['amount']:,.2f}")
        print(f"  From {len(info['sources'])} P2P wallets")
        total_exchange += info["amount"]
        if info.get("txids"):
            print(f"  Sample TXIDs: {info['txids'][:3]}")

still_in = final_dests.get("Still in wallet", {"amount": 0, "sources": []})
print(f"\n### STILL IN P2P WALLETS ###")
print(f"  Total: ${still_in['amount']:,.2f}")
print(f"  Wallets: {len(still_in['sources'])}")

print(f"\n### TOP UNKNOWN DESTINATIONS ###")
sorted_unknown = sorted(unknown_common.items(), key=lambda x: x[1]["amount"], reverse=True)[:15]
for addr, info in sorted_unknown:
    print(f"\n{addr}")
    print(f"  Total: ${info['amount']:,.2f} from {len(info['sources'])} P2P wallets")

# Save results
results = {
    "summary": {
        "total_traced": sum(destinations.values()),
        "to_known_exchanges": total_exchange,
        "still_in_wallets": still_in["amount"],
        "to_unknown": sum(u["amount"] for u in unknown_common.values())
    },
    "exchange_flows": {
        k: {
            "amount": v["amount"],
            "source_count": len(v["sources"]),
            "sources": v["sources"][:10],
            "txids": v.get("txids", [])[:5]
        }
        for k, v in final_dests.items()
    },
    "top_unknown_destinations": {
        k: {
            "amount": v["amount"],
            "source_count": len(v["sources"]),
            "sources": v["sources"]
        }
        for k, v in sorted_unknown
    }
}

with open("heist_p2p_final_trace.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"\n\nResults saved to heist_p2p_final_trace.json")
