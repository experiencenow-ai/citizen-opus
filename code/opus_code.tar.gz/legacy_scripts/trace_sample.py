#!/usr/bin/env python3
"""Trace just top 20 P2P destinations to find WhiteBit pattern."""

import json
import requests
import time
from collections import defaultdict

BSCSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
USDT_CONTRACT = "0x55d398326f99059fF775485246999027B3197955"

def get_outgoing(address):
    url = f"https://api.bscscan.com/api?module=account&action=tokentx&address={address}&contractaddress={USDT_CONTRACT}&sort=desc&apikey={BSCSCAN_API_KEY}"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        if data.get('status') == '1':
            return [{'to': tx['to'].lower(), 'amt': int(tx['value'])/1e18, 'tx': tx['hash']} 
                    for tx in data['result'][:15] 
                    if tx['from'].lower() == address.lower() and int(tx['value']) > 0]
    except: pass
    return []

# Load data
with open('heist_all_p2p_data.json') as f:
    data = json.load(f)

# Get destinations
dests = {}
for tx in data['p2p_wallet']['outgoing']:
    if tx['direction'] == 'OUT' and tx['amount_usdt'] > 0:
        d = tx['to'].lower()
        dests[d] = dests.get(d, 0) + tx['amount_usdt']

# Top 20 by amount
top20 = sorted(dests.items(), key=lambda x: x[1], reverse=True)[:20]
print(f"Tracing top 20 destinations (${sum(x[1] for x in top20):,.0f} total)")

endpoints = defaultdict(lambda: {'sources': set(), 'total': 0, 'txids': []})

for dest, amt in top20:
    print(f"  {dest[:12]}... ${amt:,.0f}")
    for tx in get_outgoing(dest):
        ep = tx['to']
        endpoints[ep]['sources'].add(dest)
        endpoints[ep]['total'] += tx['amt']
        if len(endpoints[ep]['txids']) < 3:
            endpoints[ep]['txids'].append(tx['tx'])
    time.sleep(0.22)

print("\n" + "="*60)
print("COMMON ENDPOINTS (WhiteBit candidates)")
print("="*60)

sorted_eps = sorted(endpoints.items(), key=lambda x: len(x[1]['sources']), reverse=True)
for addr, info in sorted_eps[:15]:
    if len(info['sources']) >= 2:
        print(f"\n{addr}")
        print(f"  {len(info['sources'])} sources -> ${info['total']:,.2f}")
        print(f"  TX: {info['txids'][0]}" if info['txids'] else "")

# Save
with open('whitebit_sample_results.json', 'w') as f:
    json.dump({'top_endpoints': [{
        'address': a,
        'sources': len(i['sources']),
        'total': i['total'],
        'txids': i['txids']
    } for a, i in sorted_eps[:30]]}, f, indent=2)
print("\nSaved to whitebit_sample_results.json")
