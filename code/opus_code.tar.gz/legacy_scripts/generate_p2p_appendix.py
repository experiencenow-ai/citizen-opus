#!/usr/bin/env python3
"""
Generate comprehensive P2P transaction appendix in Markdown format
"""

import json
from datetime import datetime, timezone

# Load the data
with open('heist_all_p2p_data.json', 'r') as f:
    data = json.load(f)

# Also load the p2p wallet transactions
with open('p2p_wallet_all_transactions.json', 'r') as f:
    p2p_data = json.load(f)

def short_addr(addr):
    """Shorten address for display"""
    return f"{addr[:10]}...{addr[-8:]}"

def etherscan_link(txid):
    """Create Etherscan link"""
    return f"[{txid[:18]}...](https://etherscan.io/tx/{txid})"

# Generate the appendix
md = []

md.append("# APPENDIX: P2P & Small Transaction Evidence")
md.append("")
md.append(f"**Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
md.append(f"**Case:** ct Home Invasion - Antalya Crypto Heist")
md.append(f"**Data Source:** Etherscan API with verified TXIDs")
md.append("")
md.append("---")
md.append("")

# Executive Summary
md.append("## Executive Summary")
md.append("")
md.append("| Category | Amount | TX Count |")
md.append("|----------|--------|----------|")
md.append(f"| P2P Wallet Cashouts | ${data['p2p_wallet']['outgoing_total']:,.2f} | {len(data['p2p_wallet']['outgoing'])} |")
md.append(f"| Attacker Direct Distributions | ${data['attacker_wallet']['outgoing_total']:,.2f} | {len(data['attacker_wallet']['outgoing'])} |")
total = data['p2p_wallet']['outgoing_total'] + data['attacker_wallet']['outgoing_total']
md.append(f"| **TOTAL TRACED** | **${total:,.2f}** | **{len(data['p2p_wallet']['outgoing']) + len(data['attacker_wallet']['outgoing'])}** |")
md.append("")

# Critical Finding
md.append("## ⚠️ CRITICAL: Wallet Still Active")
md.append("")
md.append("The P2P distribution wallet `0xae1e8796052db5f4a975a006800ae33a20845078` made transactions on **January 10, 2026** - indicating:")
md.append("- The mastermind or an accomplice is **still actively cashing out stolen funds**")
md.append("- The operator is **not in custody** or has **external assistance**")
md.append("- Transaction timing (14:43-15:42 Antalya time) may indicate operator's timezone/schedule")
md.append("")

# Section 1: P2P Wallet
md.append("---")
md.append("")
md.append("## 1. P2P Distribution Wallet Transactions")
md.append("")
md.append(f"**Wallet:** `{data['p2p_wallet']['address']}`")
md.append("")
md.append(f"**Total Outgoing:** ${data['p2p_wallet']['outgoing_total']:,.2f} in {len(data['p2p_wallet']['outgoing'])} transactions")
md.append("")
md.append("**Pattern:** Small amounts ($500-$4,000) to unique addresses = P2P/OTC cashout")
md.append("")
md.append("### Complete Transaction List")
md.append("")
md.append("| # | TX Hash | Antalya Time | Amount (USDT) | Destination |")
md.append("|---|---------|--------------|---------------|-------------|")

for i, tx in enumerate(data['p2p_wallet']['outgoing'], 1):
    md.append(f"| {i} | `{tx['txid']}` | {tx['antalya_time']} | ${tx['amount_usdt']:,.2f} | `{tx['to']}` |")

md.append("")

# Section 2: Attacker Wallet Direct Distributions
md.append("---")
md.append("")
md.append("## 2. Attacker Wallet Direct Distributions")
md.append("")
md.append(f"**Wallet:** `{data['attacker_wallet']['address']}`")
md.append("")
md.append(f"**Total Outgoing:** ${data['attacker_wallet']['outgoing_total']:,.2f} in {len(data['attacker_wallet']['outgoing'])} transactions")
md.append("")
md.append("### Complete Transaction List")
md.append("")
md.append("| # | TX Hash | Antalya Time | Amount (USDT) | Destination |")
md.append("|---|---------|--------------|---------------|-------------|")

for i, tx in enumerate(data['attacker_wallet']['outgoing'], 1):
    md.append(f"| {i} | `{tx['txid']}` | {tx['antalya_time']} | ${tx['amount_usdt']:,.2f} | `{tx['to']}` |")

md.append("")

# Section 3: P2P Wallet Funding Sources (filter out 0-value)
md.append("---")
md.append("")
md.append("## 3. P2P Wallet Funding Sources")
md.append("")

# Filter out 0-value transactions
real_incoming = [tx for tx in data['p2p_wallet']['incoming'] if tx['amount_usdt'] > 0]
real_incoming_total = sum(tx['amount_usdt'] for tx in real_incoming)

md.append(f"**Total Incoming:** ${real_incoming_total:,.2f} ({len(real_incoming)} real transactions)")
md.append("")
md.append("All incoming transactions (showing funding chain):")
md.append("")
md.append("| # | TX Hash | Antalya Time | Amount (USDT) | Source |")
md.append("|---|---------|--------------|---------------|--------|")

for i, tx in enumerate(real_incoming, 1):
    md.append(f"| {i} | `{tx['txid']}` | {tx['antalya_time']} | ${tx['amount_usdt']:,.2f} | `{tx['from']}` |")

md.append("")

# Section 4: Timing Analysis
md.append("---")
md.append("")
md.append("## 4. Transaction Timing Analysis")
md.append("")
md.append("### Most Recent P2P Cashouts (January 10, 2026)")
md.append("")
md.append("| TX Hash | Antalya Time | Amount |")
md.append("|---------|--------------|--------|")

recent = [tx for tx in data['p2p_wallet']['outgoing'] if tx['antalya_time'].startswith('2026-01-10')]
for tx in recent:
    md.append(f"| `{tx['txid']}` | {tx['antalya_time']} | ${tx['amount_usdt']:,.2f} |")

md.append("")
md.append("**Pattern:** All transactions occurred between 14:43-15:42 Antalya time (UTC+3)")
md.append("")

# Section 5: Key Destination Addresses
md.append("---")
md.append("")
md.append("## 5. Unique Destination Addresses")
md.append("")

# Get unique destinations from P2P wallet
destinations = {}
for tx in data['p2p_wallet']['outgoing']:
    dest = tx['to']
    if dest not in destinations:
        destinations[dest] = {'count': 0, 'total': 0}
    destinations[dest]['count'] += 1
    destinations[dest]['total'] += tx['amount_usdt']

md.append(f"**Total Unique Destinations:** {len(destinations)}")
md.append("")
md.append("Top destinations by total received:")
md.append("")
md.append("| Address | TX Count | Total Received |")
md.append("|---------|----------|----------------|")

sorted_dests = sorted(destinations.items(), key=lambda x: x[1]['total'], reverse=True)
for addr, info in sorted_dests[:20]:
    md.append(f"| `{addr}` | {info['count']} | ${info['total']:,.2f} |")

md.append("")

# Write the file
with open('heist_p2p_complete_appendix.md', 'w') as f:
    f.write('\n'.join(md))

print(f"Generated heist_p2p_complete_appendix.md")
print(f"Total lines: {len(md)}")
print(f"P2P transactions: {len(data['p2p_wallet']['outgoing'])}")
print(f"Attacker transactions: {len(data['attacker_wallet']['outgoing'])}")
print(f"Unique P2P destinations: {len(destinations)}")
print(f"Real incoming to P2P: {len(real_incoming)} (filtered from {len(data['p2p_wallet']['incoming'])})")
