#!/usr/bin/env python3
"""
Trace just the top 20 P2P destinations to find patterns
"""

import json
import time
import requests

ETHERSCAN_API_KEY = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"
BSCSCAN_API = "https://api.bscscan.com/api"
USDT_BSC = "0x55d398326f99059fF775485246999027B3197955"

def get_bsc_token_txs(address):
    """Get token transactions for an address"""
    try:
        params = {
            "module": "account",
            "action": "tokentx",
            "address": address,
            "contractaddress": USDT_BSC,
            "sort": "desc",
            "apikey": ETHERSCAN_API_KEY
        }
        resp = requests.get(BSCSCAN_API, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result", [])
    except Exception as e:
        print(f"  Error: {e}")
    return []

# Load P2P data
with open("heist_all_p2p_data.json", "r") as f:
    data = json.load(f)

# Get P2P destinations with amounts
p2p_destinations = {}
for tx in data.get("p2p_wallet", {}).get("outgoing", []):
    if tx.get("direction") == "OUT" and tx.get("amount_usdt", 0) > 0:
        to_addr = tx.get("to", "").lower()
        if to_addr:
            if to_addr not in p2p_destinations:
                p2p_destinations[to_addr] = 0
            p2p_destinations[to_addr] += tx.get("amount_usdt", 0)

# Sort by amount and get top 20
sorted_addrs = sorted(p2p_destinations.items(), key=lambda x: x[1], reverse=True)[:20]

print(f"Tracing top 20 P2P destinations (of {len(p2p_destinations)} total)")
print("=" * 80)

all_destinations = {}

for i, (addr, amt) in enumerate(sorted_addrs):
    print(f"\n[{i+1}] {addr}")
    print(f"    Received from P2P: ${amt:,.2f}")
    
    time.sleep(0.25)  # Rate limit
    txs = get_bsc_token_txs(addr)
    
    # Filter to outgoing
    outgoing = [tx for tx in txs if tx.get("from", "").lower() == addr]
    
    if not outgoing:
        print(f"    -> No outgoing (funds still there)")
        continue
    
    print(f"    -> {len(outgoing)} outgoing transactions")
    
    # Group by destination
    dest_amounts = {}
    for tx in outgoing:
        to = tx.get("to", "").lower()
        val = float(tx.get("value", 0)) / 1e18
        if to not in dest_amounts:
            dest_amounts[to] = 0
        dest_amounts[to] += val
    
    # Show top destinations
    sorted_dests = sorted(dest_amounts.items(), key=lambda x: x[1], reverse=True)[:3]
    for dest, dest_amt in sorted_dests:
        print(f"    -> {dest[:20]}... ${dest_amt:,.0f}")
        if dest not in all_destinations:
            all_destinations[dest] = {"amount": 0, "sources": 0}
        all_destinations[dest]["amount"] += dest_amt
        all_destinations[dest]["sources"] += 1

print("\n" + "=" * 80)
print("COMMON DESTINATIONS (received from multiple P2P wallets)")
print("=" * 80)

# Find addresses that received from multiple sources
common = [(k, v) for k, v in all_destinations.items() if v["sources"] >= 2]
common.sort(key=lambda x: x[1]["amount"], reverse=True)

for addr, info in common[:10]:
    print(f"\n{addr}")
    print(f"  Total: ${info['amount']:,.2f} from {info['sources']} P2P wallets")

# Save
with open("heist_top20_trace.json", "w") as f:
    json.dump({
        "traced": {addr: amt for addr, amt in sorted_addrs},
        "common_destinations": {k: v for k, v in common}
    }, f, indent=2)

print("\nSaved to heist_top20_trace.json")
