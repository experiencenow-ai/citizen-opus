#!/usr/bin/env python3
"""
News Scanner Specialist - Opus's eyes on the world.
LOCAL LLM VERSION - uses Ollama instead of Claude API.

Run via cron every 4 hours or on-demand.
Output: state/parallel/news_digest.json
"""

import sys
import json
import requests
from pathlib import Path
from datetime import datetime, timezone

# Add lib to path
sys.path.insert(0, str(Path(__file__).parent.parent / "lib"))

from rss import fetch_multiple
from state import read_state, write_state, timestamp

# RSS feeds to scan
FEEDS = {
    "google_world": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pWVXlnQVAB",
    "google_tech": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pWVXlnQVAB",
    "bbc": "http://feeds.bbci.co.uk/news/world/rss.xml",
    "hacker_news": "https://hnrss.org/frontpage",
}

OLLAMA_URL = "http://localhost:11434"

def query_local(prompt: str, system: str = None, model: str = "mistral-nemo:latest") -> str:
    """Query local LLM via Ollama."""
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.3}
    }
    if system:
        payload["system"] = system
    
    try:
        response = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=120)
        if response.status_code == 200:
            return response.json().get("response", "")
        return f"Error: HTTP {response.status_code}"
    except Exception as e:
        return f"Error: {e}"

def build_analysis_prompt(items: list) -> str:
    """Build the analysis prompt."""
    headlines = "\n".join([
        f"- [{item['source']}] {item['title'][:100]}"
        for item in items[:30]
    ])
    
    return f"""Analyze these headlines. Focus on: Korea, Turkey, AI, crypto, geopolitics.

Return ONLY this JSON (no markdown, no explanation):
{{"digest":"2-3 sentence summary","relevant":[{{"title":"headline","category":"geo|ai|crypto|other","score":1-5}}]}}

Headlines:
{headlines}"""

SYSTEM_PROMPT = """You are a news analyst. Return ONLY valid JSON with no extra text."""

def main():
    print(f"[{timestamp()}] News scanner (local) starting...")
    
    # Fetch feeds
    items = fetch_multiple(FEEDS, max_per_feed=10)
    print(f"  Fetched {len(items)} headlines")
    
    if not items:
        print("  No headlines fetched, aborting")
        return 1
    
    # Analyze with local LLM
    prompt = build_analysis_prompt(items)
    result_text = query_local(prompt, system=SYSTEM_PROMPT)
    
    # Try to parse JSON from response
    try:
        # Find JSON in response
        start = result_text.find('{')
        end = result_text.rfind('}') + 1
        if start >= 0 and end > start:
            result = json.loads(result_text[start:end])
        else:
            result = {"error": "No JSON found", "raw": result_text[:500]}
    except json.JSONDecodeError as e:
        result = {"error": f"JSON parse error: {e}", "raw": result_text[:500]}
    
    if "error" in result:
        print(f"  Analysis error: {result['error']}")
    else:
        relevant = result.get("relevant", [])
        digest = result.get("digest", "No digest")
        print(f"  Success: {len(relevant)} relevant items")
        print(f"  Digest: {digest[:100]}...")
    
    # Add metadata
    result["timestamp"] = timestamp()
    result["source"] = "local_llm"
    result["raw_count"] = len(items)
    
    # Save state
    write_state("news_digest.json", result)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
