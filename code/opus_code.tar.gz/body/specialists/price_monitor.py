#!/usr/bin/env python3
"""
Price Monitor - Track crypto prices for trading/monitoring.
Uses free CoinGecko API (no key required).
"""

import json
import requests
from datetime import datetime, timezone
from pathlib import Path

OPUS_HOME = Path("/root/claude/opus")
PRICE_FILE = OPUS_HOME / "state" / "prices.json"
PRICE_FILE.parent.mkdir(parents=True, exist_ok=True)

# Tokens to track
TOKENS = {
    "bitcoin": "BTC",
    "ethereum": "ETH", 
    "tether": "USDT",
    "solana": "SOL",
    "tron": "TRX",
    "chainlink": "LINK"
}

def fetch_prices() -> dict:
    """Fetch current prices from CoinGecko."""
    try:
        ids = ",".join(TOKENS.keys())
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd&include_24hr_change=true"
        response = requests.get(url, timeout=30)
        if response.status_code == 200:
            return response.json()
        return {"error": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"error": str(e)}

def update_prices():
    """Update price file with latest data."""
    prices = fetch_prices()
    
    if "error" in prices:
        print(f"Price fetch error: {prices['error']}")
        return None
    
    # Load existing data
    history = []
    if PRICE_FILE.exists():
        try:
            with open(PRICE_FILE) as f:
                data = json.load(f)
                history = data.get("history", [])[-288:]  # Keep ~3 days at 15min intervals
        except:
            pass
    
    # Format current prices
    current = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "prices": {}
    }
    
    for coin_id, symbol in TOKENS.items():
        if coin_id in prices:
            current["prices"][symbol] = {
                "usd": prices[coin_id].get("usd"),
                "change_24h": prices[coin_id].get("usd_24h_change")
            }
    
    history.append(current)
    
    # Save
    output = {
        "last_updated": current["timestamp"],
        "current": current["prices"],
        "history": history
    }
    
    with open(PRICE_FILE, 'w') as f:
        json.dump(output, f, indent=2)
    
    return current["prices"]

def get_alert_conditions(prices: dict) -> list:
    """Check for significant price movements."""
    alerts = []
    for symbol, data in prices.items():
        change = data.get("change_24h", 0)
        if change and abs(change) > 10:
            direction = "up" if change > 0 else "down"
            alerts.append(f"{symbol} {direction} {abs(change):.1f}% in 24h")
    return alerts

if __name__ == "__main__":
    print(f"[{datetime.now().isoformat()}] Price monitor starting...")
    prices = update_prices()
    if prices:
        print("Current prices:")
        for symbol, data in prices.items():
            price = data.get("usd", "?")
            change = data.get("change_24h", 0)
            print(f"  {symbol}: ${price:,.2f} ({change:+.1f}%)" if isinstance(price, (int, float)) else f"  {symbol}: ${price}")
        
        alerts = get_alert_conditions(prices)
        if alerts:
            print("ALERTS:", ", ".join(alerts))
    print("Done")
