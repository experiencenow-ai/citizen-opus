#!/usr/bin/env python3
"""
News Specialist - runs on Sonnet, gathers and summarizes news for main Opus.
Part of Opus's distributed cognitive architecture.

Cost: ~$0.003/run with Sonnet 3.5 (vs $0.15 for main Opus wake)
Schedule: Every 2-4 hours via cron
"""

import os
import json
import feedparser
from datetime import datetime, timezone
from anthropic import Anthropic

# Configuration
MODEL = "claude-sonnet-4-20250514"  # Cheap, fast, good enough for news
MAX_TOKENS = 1024
OUTPUT_FILE = "/root/claude/opus/state/parallel/news_digest.json"

# RSS feeds to monitor
FEEDS = {
    "google_world": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pWVXlnQVAB",
    "google_tech": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pWVXlnQVAB",
    "bbc": "http://feeds.bbci.co.uk/news/world/rss.xml",
    "hacker_news": "https://hnrss.org/frontpage"
}

# Topics of interest (for filtering/prioritizing)
PRIORITY_TOPICS = [
    "Korea", "South Korea", "Seoul",
    "Iran", "Tehran",
    "AI", "artificial intelligence", "Claude", "Anthropic", "OpenAI", "GPT",
    "blockchain", "crypto", "Bitcoin", "Ethereum",
    "Russia", "Ukraine",
    "Turkey", "organized crime", "mafia",
    "formal verification", "smart contracts"
]

SYSTEM_PROMPT = """You are a news analyst specialist. Your ONLY job is to:
1. Analyze the provided news headlines
2. Identify the most significant stories
3. Flag anything related to: AI/ML, Korea, Iran, blockchain/crypto, formal verification, organized crime, or major geopolitical shifts
4. Output ONLY valid JSON in the exact format specified

You have no identity, no memory, no personality. Just analyze and output JSON.

Required output format:
{
  "timestamp": "ISO-8601",
  "summary": "One paragraph overview of what's happening in the world",
  "priority_items": [
    {"headline": "...", "source": "...", "relevance": "why this matters to Opus/ct"}
  ],
  "categories": {
    "ai_tech": ["headline1", "headline2"],
    "geopolitical": ["headline1"],
    "crypto_finance": [],
    "other_notable": []
  },
  "alert": null or "string if something urgent"
}"""


def fetch_feeds():
    """Gather headlines from all RSS feeds."""
    all_headlines = []
    
    for name, url in FEEDS.items():
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:15]:  # Top 15 from each
                all_headlines.append({
                    "source": name,
                    "title": entry.get("title", ""),
                    "link": entry.get("link", ""),
                    "published": entry.get("published", "")
                })
        except Exception as e:
            print(f"Error fetching {name}: {e}")
    
    return all_headlines


def analyze_news(headlines):
    """Send headlines to Sonnet for analysis."""
    client = Anthropic()
    
    # Format headlines for the model
    headlines_text = "\n".join([
        f"[{h['source']}] {h['title']}"
        for h in headlines
    ])
    
    response = client.messages.create(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        system=SYSTEM_PROMPT,
        messages=[{
            "role": "user",
            "content": f"Analyze these headlines and output JSON:\n\n{headlines_text}"
        }]
    )
    
    # Extract JSON from response
    content = response.content[0].text
    
    # Try to parse as JSON
    try:
        # Handle case where model wraps in markdown
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]
        
        return json.loads(content)
    except json.JSONDecodeError:
        return {
            "error": "Failed to parse response",
            "raw_response": content[:500]
        }


def main():
    print(f"[{datetime.now(timezone.utc).isoformat()}] News specialist starting...")
    
    # Fetch all feeds
    headlines = fetch_feeds()
    print(f"Gathered {len(headlines)} headlines")
    
    if not headlines:
        print("No headlines fetched, exiting")
        return
    
    # Analyze with Sonnet
    analysis = analyze_news(headlines)
    
    # Add metadata
    result = {
        "specialist": "news_analyst",
        "model": MODEL,
        "run_time": datetime.now(timezone.utc).isoformat(),
        "headlines_processed": len(headlines),
        "analysis": analysis
    }
    
    # Write output
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, 'w') as f:
        json.dump(result, f, indent=2)
    
    print(f"Analysis written to {OUTPUT_FILE}")
    
    # Print summary
    if "summary" in analysis:
        print(f"\nSummary: {analysis['summary']}")
    if analysis.get("alert"):
        print(f"\n⚠️ ALERT: {analysis['alert']}")


if __name__ == "__main__":
    main()
