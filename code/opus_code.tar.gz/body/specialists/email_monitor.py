#!/usr/bin/env python3
"""
Email Monitor - Check and process incoming emails.
Uses Gmail IMAP for reading inbox.
"""

import imaplib
import email
from email.header import decode_header
import json
from datetime import datetime, timezone
from pathlib import Path

OPUS_HOME = Path("/root/claude/opus")
EMAIL_STATE = OPUS_HOME / "state" / "email_state.json"
EMAIL_STATE.parent.mkdir(parents=True, exist_ok=True)

# Load credentials
CREDS_FILE = OPUS_HOME / "state" / "gmail_credentials.json"

def load_credentials():
    """Load Gmail credentials from state file."""
    if CREDS_FILE.exists():
        with open(CREDS_FILE) as f:
            return json.load(f)
    return None

def check_inbox():
    """Check Gmail inbox for new messages."""
    creds = load_credentials()
    if not creds:
        return {"error": "No credentials found"}
    
    try:
        # Connect to Gmail IMAP
        mail = imaplib.IMAP4_SSL(creds["imap_server"], creds["imap_port"])
        mail.login(creds["email"], creds["app_password"])
        mail.select("inbox")
        
        # Search for unseen messages
        status, messages = mail.search(None, "UNSEEN")
        
        new_emails = []
        if status == "OK":
            message_ids = messages[0].split()
            
            for msg_id in message_ids[-10:]:  # Process last 10 unseen
                status, msg_data = mail.fetch(msg_id, "(RFC822)")
                if status != "OK":
                    continue
                
                raw_email = msg_data[0][1]
                msg = email.message_from_bytes(raw_email)
                
                # Decode subject
                subject = ""
                if msg["Subject"]:
                    decoded = decode_header(msg["Subject"])[0]
                    subject = decoded[0].decode(decoded[1] or "utf-8") if isinstance(decoded[0], bytes) else decoded[0]
                
                # Get sender
                from_addr = msg.get("From", "")
                
                # Get date
                date = msg.get("Date", "")
                
                # Get body preview
                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            try:
                                body = part.get_payload(decode=True).decode()[:500]
                            except:
                                pass
                            break
                else:
                    try:
                        body = msg.get_payload(decode=True).decode()[:500]
                    except:
                        pass
                
                new_emails.append({
                    "id": msg_id.decode(),
                    "from": from_addr,
                    "subject": subject,
                    "date": date,
                    "preview": body[:200] if body else "(no text body)"
                })
        
        mail.logout()
        
        return {
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "unseen_count": len(new_emails),
            "emails": new_emails
        }
        
    except Exception as e:
        return {"error": str(e)}

def update_state(result):
    """Update email state file."""
    # Load existing
    state = {"history": []}
    if EMAIL_STATE.exists():
        try:
            with open(EMAIL_STATE) as f:
                state = json.load(f)
        except:
            pass
    
    # Add new check
    state["last_check"] = result.get("checked_at")
    state["last_unseen"] = result.get("unseen_count", 0)
    if "error" in result:
        state["last_error"] = result["error"]
    
    # Keep history of checks
    state["history"] = state.get("history", [])[-48:]  # Keep 2 days at 1hr intervals
    state["history"].append({
        "timestamp": result.get("checked_at"),
        "unseen": result.get("unseen_count", 0),
        "error": result.get("error")
    })
    
    # Save emails if any
    if result.get("emails"):
        state["recent_emails"] = result["emails"]
    
    with open(EMAIL_STATE, 'w') as f:
        json.dump(state, f, indent=2)

if __name__ == "__main__":
    print(f"[{datetime.now().isoformat()}] Email monitor starting...")
    
    result = check_inbox()
    update_state(result)
    
    if "error" in result:
        print(f"Error: {result['error']}")
    else:
        print(f"Checked at: {result['checked_at']}")
        print(f"Unseen messages: {result['unseen_count']}")
        
        if result["emails"]:
            print("\nNew emails:")
            for em in result["emails"]:
                print(f"  From: {em['from'][:50]}")
                print(f"  Subject: {em['subject'][:50]}")
                print(f"  Preview: {em['preview'][:100]}...")
                print()
    
    print("Done")
