#!/usr/bin/env python3
"""
Address Monitor v2 - Clean DRY implementation
Wake 1000 milestone - realtime tracking of stolen funds

Architecture:
- This script: Data gathering (runs via cron, cheap)
- Haiku/Sonnet: Initial evaluation of changes
- Opus: Strategic decisions on significant movements

Functions are composable and reusable for future blockchain tools.
"""

import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable
from dataclasses import dataclass, asdict
from enum import Enum

# ============================================================================
# Configuration
# ============================================================================

class Config:
    """Central configuration."""
    RPC_URL = "http://localhost:8545"
    SCRIPT_DIR = Path(__file__).parent
    WATCHLIST_FILE = SCRIPT_DIR / "bounty_watchlist.json"
    STATE_FILE = SCRIPT_DIR / "address_monitor_state.json"
    ALERTS_FILE = SCRIPT_DIR / "address_monitor_alerts.json"
    SUMMARY_FILE = SCRIPT_DIR / "address_monitor_summary.json"
    MAX_ALERTS = 100
    
    # Alert thresholds
    MIN_BALANCE_CHANGE_ETH = 0.01  # Ignore dust
    MIN_TX_FOR_ALERT = 1

# ============================================================================
# Data Types
# ============================================================================

@dataclass
class AddressState:
    """State of a tracked address."""
    address: str
    label: str
    balance: float
    tx_count: int
    last_check: str
    
    def to_dict(self) -> Dict:
        return asdict(self)

@dataclass  
class Alert:
    """Movement alert."""
    timestamp: str
    address: str
    label: str
    balance_change_eth: Optional[float]
    new_transactions: Optional[int]
    current_balance: float
    current_tx_count: int
    severity: str  # "low", "medium", "high"
    
    def to_dict(self) -> Dict:
        return asdict(self)

class Severity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

# ============================================================================
# RPC Layer - Ethereum JSON-RPC interface
# ============================================================================

def rpc_call(method: str, params: list = None, url: str = None) -> Any:
    """
    Make JSON-RPC call to Ethereum node.
    
    Args:
        method: RPC method name
        params: Method parameters
        url: RPC endpoint (defaults to Config.RPC_URL)
    
    Returns:
        Result from RPC call, or None on error
    """
    url = url or Config.RPC_URL
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": method,
        "params": params or [],
        "id": 1
    }).encode()
    
    try:
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            if "error" in result:
                return None
            return result.get("result")
    except Exception:
        return None

def batch_rpc_call(calls: List[Dict], url: str = None) -> List[Any]:
    """
    Make batch JSON-RPC call for efficiency.
    
    Args:
        calls: List of {"method": str, "params": list}
        url: RPC endpoint
    
    Returns:
        List of results in same order as calls
    """
    url = url or Config.RPC_URL
    payload = json.dumps([
        {"jsonrpc": "2.0", "method": c["method"], "params": c.get("params", []), "id": i}
        for i, c in enumerate(calls)
    ]).encode()
    
    try:
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            results = json.loads(resp.read().decode())
            # Sort by id and extract results
            results.sort(key=lambda x: x.get("id", 0))
            return [r.get("result") for r in results]
    except Exception:
        return [None] * len(calls)

# ============================================================================
# Conversion Utilities
# ============================================================================

def hex_to_int(hex_str: Optional[str]) -> int:
    """Convert hex string to int, handling None."""
    return int(hex_str, 16) if hex_str else 0

def wei_to_eth(wei: int) -> float:
    """Convert wei to ETH."""
    return wei / 1e18

def eth_to_usd(eth: float, eth_price: float = 3085.0) -> float:
    """Convert ETH to USD at given price."""
    return eth * eth_price

# ============================================================================
# Blockchain Queries
# ============================================================================

def get_balance(address: str) -> Optional[float]:
    """Get ETH balance for address in ETH."""
    result = rpc_call("eth_getBalance", [address, "latest"])
    return wei_to_eth(hex_to_int(result)) if result else None

def get_tx_count(address: str) -> Optional[int]:
    """Get transaction count for address."""
    result = rpc_call("eth_getTransactionCount", [address, "latest"])
    return hex_to_int(result) if result else None

def get_block_number() -> Optional[int]:
    """Get current block number."""
    result = rpc_call("eth_blockNumber")
    return hex_to_int(result) if result else None

def get_multiple_balances(addresses: List[str]) -> Dict[str, float]:
    """
    Get balances for multiple addresses efficiently using batch RPC.
    
    Returns:
        Dict mapping address -> balance in ETH
    """
    calls = [{"method": "eth_getBalance", "params": [addr, "latest"]} 
             for addr in addresses]
    results = batch_rpc_call(calls)
    return {
        addr.lower(): wei_to_eth(hex_to_int(r)) if r else 0
        for addr, r in zip(addresses, results)
    }

def get_multiple_tx_counts(addresses: List[str]) -> Dict[str, int]:
    """
    Get tx counts for multiple addresses efficiently.
    """
    calls = [{"method": "eth_getTransactionCount", "params": [addr, "latest"]}
             for addr in addresses]
    results = batch_rpc_call(calls)
    return {
        addr.lower(): hex_to_int(r) if r else 0
        for addr, r in zip(addresses, results)
    }

# ============================================================================
# State Management
# ============================================================================

def load_json(path: Path, default: Any = None) -> Any:
    """Load JSON file with default."""
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except Exception:
        return default

def save_json(path: Path, data: Any, indent: int = 2):
    """Save data as JSON."""
    path.write_text(json.dumps(data, indent=indent))

def load_state() -> Dict:
    """Load monitoring state."""
    return load_json(Config.STATE_FILE, {"addresses": {}, "last_check": None, "last_block": None})

def save_state(state: Dict):
    """Save monitoring state."""
    save_json(Config.STATE_FILE, state)

def load_watchlist() -> Dict:
    """Load watchlist configuration."""
    return load_json(Config.WATCHLIST_FILE, {"known_addresses": {}})

def append_alerts(new_alerts: List[Alert]):
    """Append alerts to alerts file, keeping max Config.MAX_ALERTS."""
    existing = load_json(Config.ALERTS_FILE, [])
    existing.extend([a.to_dict() for a in new_alerts])
    save_json(Config.ALERTS_FILE, existing[-Config.MAX_ALERTS:])

# ============================================================================
# Alert Logic
# ============================================================================

def calculate_severity(balance_change: float, new_txs: int) -> Severity:
    """
    Calculate alert severity based on movement size.
    """
    if abs(balance_change) > 100 or new_txs > 10:
        return Severity.HIGH
    elif abs(balance_change) > 10 or new_txs > 5:
        return Severity.MEDIUM
    return Severity.LOW

def check_for_changes(
    address: str,
    label: str,
    current: Dict[str, Any],
    previous: Optional[Dict[str, Any]]
) -> Optional[Alert]:
    """
    Check for significant changes between current and previous state.
    
    Returns Alert if significant change detected, None otherwise.
    """
    if not previous:
        return None  # First observation, no change
    
    balance_change = current["balance"] - previous.get("balance", 0)
    new_txs = current["tx_count"] - previous.get("tx_count", 0)
    
    # Filter noise
    if abs(balance_change) < Config.MIN_BALANCE_CHANGE_ETH and new_txs < Config.MIN_TX_FOR_ALERT:
        return None
    
    severity = calculate_severity(balance_change, new_txs)
    
    return Alert(
        timestamp=datetime.now(timezone.utc).isoformat(),
        address=address,
        label=label,
        balance_change_eth=balance_change if balance_change != 0 else None,
        new_transactions=new_txs if new_txs > 0 else None,
        current_balance=current["balance"],
        current_tx_count=current["tx_count"],
        severity=severity.value
    )

# ============================================================================
# Main Scanner
# ============================================================================

def scan_addresses() -> Dict[str, Any]:
    """
    Main scan function. Checks all watched addresses and generates alerts.
    
    Returns:
        Summary dict with scan results
    """
    now = datetime.now(timezone.utc).isoformat()
    
    # Check connectivity
    block = get_block_number()
    if block is None:
        return {"status": "error", "message": "Cannot connect to Erigon", "timestamp": now}
    
    state = load_state()
    watchlist = load_watchlist()
    
    # Gather addresses
    addresses_by_label = {}
    for source, data in watchlist.get("known_addresses", {}).items():
        for addr in data.get("addresses", []):
            addresses_by_label[addr.lower()] = source
    
    addresses = list(addresses_by_label.keys())
    if not addresses:
        return {"status": "ok", "message": "No addresses to monitor", "timestamp": now}
    
    # Batch fetch current state
    balances = get_multiple_balances(addresses)
    tx_counts = get_multiple_tx_counts(addresses)
    
    # Check for changes and update state
    alerts = []
    new_state = {"addresses": {}, "last_check": now, "last_block": block}
    
    total_eth = 0
    for addr in addresses:
        label = addresses_by_label[addr]
        current = {
            "balance": balances.get(addr, 0),
            "tx_count": tx_counts.get(addr, 0),
            "label": label,
            "last_check": now
        }
        total_eth += current["balance"]
        
        previous = state.get("addresses", {}).get(addr)
        alert = check_for_changes(addr, label, current, previous)
        if alert:
            alerts.append(alert)
        
        new_state["addresses"][addr] = current
    
    # Save state
    save_state(new_state)
    
    # Save alerts
    if alerts:
        append_alerts(alerts)
    
    # Generate summary
    summary = {
        "status": "ok",
        "timestamp": now,
        "block": block,
        "addresses_checked": len(addresses),
        "total_eth_tracked": round(total_eth, 4),
        "total_usd_tracked": round(eth_to_usd(total_eth), 2),
        "alerts_generated": len(alerts),
        "high_severity_alerts": len([a for a in alerts if a.severity == "high"]),
        "top_balances": sorted(
            [(addr, bal) for addr, bal in balances.items() if bal > 0.1],
            key=lambda x: x[1],
            reverse=True
        )[:5]
    }
    
    save_json(Config.SUMMARY_FILE, summary)
    return summary

def print_summary(summary: Dict):
    """Print human-readable summary."""
    print(f"\n{'='*60}")
    print(f"Address Monitor Scan - {summary.get('timestamp', 'unknown')}")
    print(f"{'='*60}")
    print(f"Status: {summary.get('status', 'unknown')}")
    print(f"Block: {summary.get('block', 'N/A')}")
    print(f"Addresses checked: {summary.get('addresses_checked', 0)}")
    print(f"Total ETH tracked: {summary.get('total_eth_tracked', 0):.4f}")
    print(f"Total USD tracked: ${summary.get('total_usd_tracked', 0):,.2f}")
    print(f"Alerts: {summary.get('alerts_generated', 0)} ({summary.get('high_severity_alerts', 0)} high)")
    
    top = summary.get('top_balances', [])
    if top:
        print(f"\nTop balances:")
        for addr, bal in top:
            print(f"  {addr[:10]}...{addr[-6:]}: {bal:.4f} ETH (${eth_to_usd(bal):,.2f})")
    print(f"{'='*60}\n")

# ============================================================================
# Entry Point
# ============================================================================

if __name__ == "__main__":
    summary = scan_addresses()
    print_summary(summary)
