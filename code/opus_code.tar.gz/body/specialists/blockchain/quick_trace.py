#!/usr/bin/env python3
"""
Quick Trace - Fast address analysis using Erigon trace_filter
Opus Wake 1006

Usage: python3 quick_trace.py <address> [--blocks N]
"""

import json
import urllib.request
import sys
from collections import defaultdict
from pathlib import Path

RPC_URL = "http://localhost:8545"
OUTPUT_DIR = Path(__file__).parent / "traces"
OUTPUT_DIR.mkdir(exist_ok=True)

def rpc_call(method, params=None):
    payload = json.dumps({'jsonrpc': '2.0', 'method': method, 'params': params or [], 'id': 1}).encode()
    req = urllib.request.Request(RPC_URL, data=payload, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read().decode())
        if 'error' in result:
            print(f"RPC Error: {result['error']}")
            return None
        return result.get('result')

def hex_to_int(h):
    return int(h, 16) if h else 0

def wei_to_eth(w):
    return w / 1e18

def quick_trace(address: str, num_blocks: int = 10000) -> dict:
    """Quick trace of an address."""
    address = address.lower()
    
    current_block = hex_to_int(rpc_call('eth_blockNumber'))
    from_blk = max(0, current_block - num_blocks)
    
    print(f"Tracing {address[:15]}... (blocks {from_blk} to {current_block})")
    
    # Get traces
    incoming = rpc_call('trace_filter', [{
        'toAddress': [address],
        'fromBlock': hex(from_blk),
        'toBlock': hex(current_block)
    }]) or []
    
    outgoing = rpc_call('trace_filter', [{
        'fromAddress': [address],
        'fromBlock': hex(from_blk),
        'toBlock': hex(current_block)
    }]) or []
    
    print(f"  Incoming: {len(incoming)} traces")
    print(f"  Outgoing: {len(outgoing)} traces")
    
    # Analyze flows
    senders = defaultdict(lambda: {'count': 0, 'total_eth': 0})
    receivers = defaultdict(lambda: {'count': 0, 'total_eth': 0})
    
    for trace in incoming:
        action = trace.get('action', {})
        from_addr = action.get('from', '').lower()
        value = wei_to_eth(hex_to_int(action.get('value', '0x0')))
        senders[from_addr]['count'] += 1
        senders[from_addr]['total_eth'] += value
    
    for trace in outgoing:
        action = trace.get('action', {})
        to_addr = (action.get('to') or '').lower()
        value = wei_to_eth(hex_to_int(action.get('value', '0x0')))
        receivers[to_addr]['count'] += 1
        receivers[to_addr]['total_eth'] += value
    
    # Sort by value
    top_senders = sorted(senders.items(), key=lambda x: -x[1]['total_eth'])[:20]
    top_receivers = sorted(receivers.items(), key=lambda x: -x[1]['total_eth'])[:20]
    
    result = {
        'address': address,
        'block_range': {'from': from_blk, 'to': current_block},
        'incoming_traces': len(incoming),
        'outgoing_traces': len(outgoing),
        'total_received_eth': sum(s['total_eth'] for s in senders.values()),
        'total_sent_eth': sum(r['total_eth'] for r in receivers.values()),
        'unique_senders': len(senders),
        'unique_receivers': len(receivers),
        'top_senders': [
            {'address': a, 'count': d['count'], 'total_eth': round(d['total_eth'], 4)}
            for a, d in top_senders if d['total_eth'] > 0
        ],
        'top_receivers': [
            {'address': a, 'count': d['count'], 'total_eth': round(d['total_eth'], 4)}
            for a, d in top_receivers if d['total_eth'] > 0
        ]
    }
    
    return result

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 quick_trace.py <address> [--blocks N]")
        sys.exit(1)
    
    address = sys.argv[1].lower()
    if not address.startswith('0x'):
        address = '0x' + address
    
    blocks = 10000
    if '--blocks' in sys.argv:
        idx = sys.argv.index('--blocks')
        if idx + 1 < len(sys.argv):
            blocks = int(sys.argv[idx + 1])
    
    result = quick_trace(address, blocks)
    
    # Print summary
    print(f"\n{'='*60}")
    print(f"Address: {result['address']}")
    print(f"Block range: {result['block_range']['from']} - {result['block_range']['to']}")
    print(f"Total received: {result['total_received_eth']:.4f} ETH from {result['unique_senders']} addresses")
    print(f"Total sent: {result['total_sent_eth']:.4f} ETH to {result['unique_receivers']} addresses")
    
    if result['top_senders']:
        print(f"\nTop Senders:")
        for s in result['top_senders'][:5]:
            print(f"  {s['address'][:18]}... : {s['total_eth']:.4f} ETH ({s['count']} tx)")
    
    if result['top_receivers']:
        print(f"\nTop Receivers:")
        for r in result['top_receivers'][:5]:
            print(f"  {r['address'][:18]}... : {r['total_eth']:.4f} ETH ({r['count']} tx)")
    
    # Save to file
    output_file = OUTPUT_DIR / f"quick_{address[:10]}.json"
    output_file.write_text(json.dumps(result, indent=2))
    print(f"\nSaved to: {output_file}")

if __name__ == "__main__":
    main()
