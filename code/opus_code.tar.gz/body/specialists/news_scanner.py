#!/usr/bin/env python3
"""
News Scanner Specialist - Opus's eyes on the world.
Runs on Claude Haiku for cost efficiency.
Uses modular lib components.

Run via cron every 4 hours or on-demand.
Output: state/parallel/news_digest.json
"""

import sys
from pathlib import Path

# Add lib to path
sys.path.insert(0, str(Path(__file__).parent.parent / "lib"))

from rss import fetch_multiple
from llm import query
from state import read_state, write_state, timestamp

# RSS feeds to scan
FEEDS = {
    "google_world": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pWVXlnQVAB",
    "google_tech": "https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pWVXlnQVAB",
    "bbc": "http://feeds.bbci.co.uk/news/world/rss.xml",
    "hacker_news": "https://hnrss.org/frontpage",
}

# Topics that matter to Opus
INTEREST_TOPICS = [
    "Korea", "Turkey", "Iran", "Venezuela", "organized crime", "mafia",
    "AI", "artificial intelligence", "Claude", "Anthropic", "OpenAI", "GPT",
    "blockchain", "cryptocurrency", "Bitcoin", "Ethereum",
    "formal verification", "proof systems",
    "Russia", "Ukraine", "geopolitics", "war", "conflict"
]

SYSTEM_PROMPT = """You are a news analyst. Return ONLY valid JSON with no extra text.
Use simple strings without special characters. Keep one_line short (under 80 chars)."""

def build_analysis_prompt(items: list) -> str:
    """Build the analysis prompt for Haiku."""
    headlines = "\n".join([
        f"- [{item['source']}] {item['title'][:100]}"
        for item in items[:30]  # Limit to avoid token overflow
    ])
    
    topics = "Korea, Turkey, AI, crypto, geopolitics"
    
    return f"""Analyze these headlines. Focus on: {topics}

Return ONLY this JSON structure (no markdown, no explanation):
{{"digest":"2-3 sentence summary","relevant":[{{"title":"exact title","category":"geo|ai|crypto|other","score":1-5,"note":"short note"}}],"alerts":[]}}

Rules:
- Include max 10 most relevant items (score 3+)
- Use simple ASCII in strings
- No trailing commas
- Alerts only for urgent/critical news

Headlines:
{headlines}"""

def main():
    print(f"[{timestamp()}] News scanner starting...")
    
    # Fetch feeds
    items = fetch_multiple(FEEDS, max_per_feed=10)
    print(f"  Fetched {len(items)} headlines")
    
    if not items:
        print("  No headlines fetched, aborting")
        return 1
    
    # Read previous state for deduplication
    previous = read_state("news_digest.json", {})
    prev_titles = set(i.get('title', '') for i in previous.get('relevant', []))
    
    # Analyze with Haiku
    prompt = build_analysis_prompt(items)
    result = query(prompt, model="haiku", max_tokens=1500, 
                   system=SYSTEM_PROMPT, expect_json=True)
    
    if isinstance(result, dict) and "error" in result:
        print(f"  Analysis error: {result['error']}")
        # Save error state but don't overwrite good data
        error_state = {
            "timestamp": timestamp(),
            "status": "error",
            "error": result.get("error"),
            "headlines_fetched": len(items)
        }
        write_state("news_digest_error.json", error_state)
        return 1
    
    # Filter to new items only
    if isinstance(result, dict) and 'relevant' in result:
        new_items = [i for i in result.get('relevant', []) 
                     if i.get('title', '') not in prev_titles]
        result['relevant'] = new_items
        result['new_count'] = len(new_items)
    
    # Add metadata
    result['timestamp'] = timestamp()
    result['status'] = 'success'
    result['headlines_scanned'] = len(items)
    
    # Save results
    write_state("news_digest.json", result)
    
    # Also save to digests directory with timestamp
    digest_dir = Path(__file__).parent / "digests"
    digest_dir.mkdir(exist_ok=True)
    digest_file = digest_dir / f"digest_{timestamp()[:10]}.json"
    write_state(str(digest_file), result)
    
    relevant_count = len(result.get('relevant', []))
    print(f"  Success: {relevant_count} relevant items")
    print(f"  Digest: {result.get('digest', 'N/A')[:100]}...")
    
    return 0

if __name__ == "__main__":
    exit(main())
