#!/usr/bin/env python3
"""
Simple RSS parser using only stdlib.
No feedparser dependency.
"""

import urllib.request
import xml.etree.ElementTree as ET
from typing import List, Dict
import ssl
import html

def fetch_rss(url: str, timeout: int = 10) -> List[Dict]:
    """
    Fetch and parse an RSS feed. Returns list of items.
    Each item: {title, link, published, summary, source_url}
    """
    items = []
    try:
        # Handle SSL
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(url, headers={'User-Agent': 'OpusBot/1.0'})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            data = resp.read().decode('utf-8', errors='ignore')
        
        root = ET.fromstring(data)
        
        # Handle both RSS 2.0 and Atom feeds
        # RSS 2.0: channel/item
        for item in root.findall('.//item'):
            items.append({
                'title': html.unescape(item.findtext('title', '')),
                'link': item.findtext('link', ''),
                'published': item.findtext('pubDate', ''),
                'summary': html.unescape(item.findtext('description', '')[:500] if item.findtext('description') else ''),
                'source_url': url
            })
        
        # Atom: entry
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        for entry in root.findall('.//atom:entry', ns) + root.findall('.//entry'):
            link_elem = entry.find('atom:link[@href]', ns) or entry.find('link[@href]') or entry.find('link')
            link = link_elem.get('href', '') if link_elem is not None else (link_elem.text if link_elem else '')
            items.append({
                'title': html.unescape(entry.findtext('atom:title', '', ns) or entry.findtext('title', '')),
                'link': link,
                'published': entry.findtext('atom:published', '', ns) or entry.findtext('published', '') or entry.findtext('updated', ''),
                'summary': html.unescape((entry.findtext('atom:summary', '', ns) or entry.findtext('summary', ''))[:500]),
                'source_url': url
            })
            
    except Exception as e:
        print(f"RSS fetch error ({url}): {e}")
    
    return items

def fetch_multiple(feeds: Dict[str, str], max_per_feed: int = 10) -> List[Dict]:
    """
    Fetch multiple feeds. feeds = {name: url}
    Returns combined list with 'source' field added.
    """
    all_items = []
    for name, url in feeds.items():
        items = fetch_rss(url)[:max_per_feed]
        for item in items:
            item['source'] = name
        all_items.extend(items)
    return all_items


if __name__ == "__main__":
    # Test
    test_feeds = {
        "bbc": "http://feeds.bbci.co.uk/news/world/rss.xml",
    }
    items = fetch_multiple(test_feeds, max_per_feed=3)
    for item in items:
        print(f"[{item['source']}] {item['title'][:60]}...")
