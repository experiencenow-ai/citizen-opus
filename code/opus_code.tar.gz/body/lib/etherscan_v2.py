#!/usr/bin/env python3
"""
Etherscan API V2 wrapper - unified multichain API.
All chains use https://api.etherscan.io/v2/api with chainid parameter.
"""

import requests
import os
from typing import Optional, Dict, Any, List

# API key from environment
ETHERSCAN_KEY = os.environ.get("ETHERSCAN_API_KEY", "")

# Base URL for all chains (V2 unified)
BASE_URL = "https://api.etherscan.io/v2/api"

# Chain IDs
CHAIN_IDS = {
    "ethereum": 1,
    "arbitrum": 42161,
    "polygon": 137,
    "base": 8453,
    "optimism": 10,
    "bsc": 56,
    "avalanche": 43114
}

def _make_request(params: dict, chain: str = "ethereum") -> Optional[dict]:
    """Make API request with proper V2 format."""
    params["chainid"] = CHAIN_IDS.get(chain, 1)
    if ETHERSCAN_KEY:
        params["apikey"] = ETHERSCAN_KEY
    
    try:
        resp = requests.get(BASE_URL, params=params, timeout=30)
        data = resp.json()
        if data.get("status") == "1":
            return data.get("result")
        else:
            print(f"API Error: {data.get('message')} - {data.get('result')}")
            return None
    except Exception as e:
        print(f"Request error: {e}")
        return None

def get_balance(address: str, chain: str = "ethereum") -> Optional[float]:
    """Get ETH balance for address."""
    params = {
        "module": "account",
        "action": "balance",
        "address": address,
        "tag": "latest"
    }
    result = _make_request(params, chain)
    if result:
        return int(result) / 1e18
    return None

def get_transactions(address: str, chain: str = "ethereum", 
                    start_block: int = 0, end_block: int = 99999999,
                    page: int = 1, offset: int = 100) -> List[dict]:
    """Get transaction list for address."""
    params = {
        "module": "account",
        "action": "txlist",
        "address": address,
        "startblock": start_block,
        "endblock": end_block,
        "page": page,
        "offset": offset,
        "sort": "desc"
    }
    result = _make_request(params, chain)
    return result if isinstance(result, list) else []

def get_internal_transactions(address: str, chain: str = "ethereum",
                             start_block: int = 0, end_block: int = 99999999) -> List[dict]:
    """Get internal transactions for address."""
    params = {
        "module": "account",
        "action": "txlistinternal",
        "address": address,
        "startblock": start_block,
        "endblock": end_block,
        "sort": "desc"
    }
    result = _make_request(params, chain)
    return result if isinstance(result, list) else []

def get_token_transfers(address: str, chain: str = "ethereum",
                       contract: Optional[str] = None) -> List[dict]:
    """Get ERC-20 token transfers for address."""
    params = {
        "module": "account",
        "action": "tokentx",
        "address": address,
        "sort": "desc"
    }
    if contract:
        params["contractaddress"] = contract
    
    result = _make_request(params, chain)
    return result if isinstance(result, list) else []

def get_erc721_transfers(address: str, chain: str = "ethereum") -> List[dict]:
    """Get ERC-721 NFT transfers for address."""
    params = {
        "module": "account",
        "action": "tokennfttx",
        "address": address,
        "sort": "desc"
    }
    result = _make_request(params, chain)
    return result if isinstance(result, list) else []

def get_contract_source(address: str, chain: str = "ethereum") -> Optional[dict]:
    """Get verified contract source code."""
    params = {
        "module": "contract",
        "action": "getsourcecode",
        "address": address
    }
    result = _make_request(params, chain)
    if result and isinstance(result, list) and len(result) > 0:
        return result[0]
    return None

def get_gas_price(chain: str = "ethereum") -> Optional[dict]:
    """Get current gas price."""
    params = {
        "module": "gastracker",
        "action": "gasoracle"
    }
    return _make_request(params, chain)

if __name__ == "__main__":
    # Load env
    with open(".env") as f:
        for line in f:
            if "=" in line and not line.startswith("#"):
                k, v = line.strip().split("=", 1)
                os.environ[k] = v
    
    # Test
    test_addr = "0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95"
    print(f"Testing V2 API for {test_addr[:10]}...")
    
    bal = get_balance(test_addr)
    print(f"Balance: {bal} ETH" if bal else "Failed to get balance")
    
    txs = get_transactions(test_addr)
    print(f"Transactions: {len(txs)} found")
    if txs:
        print(f"  Latest: {txs[0].get('hash', 'N/A')[:20]}...")
