#!/usr/bin/env python3
"""
Generate a dense wake brief for Opus.
Pulls from all specialist outputs and state files.
Designed to be efficient - maximum information, minimum tokens.
"""

import json
from pathlib import Path
from datetime import datetime, timezone

OPUS_HOME = Path("/root/claude/opus")
PARALLEL_DIR = OPUS_HOME / "state" / "parallel"
STATE_DIR = OPUS_HOME / "state"

def load_json(path: Path, default=None):
    """Load JSON file or return default."""
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}

def get_news_brief():
    """Extract key news items."""
    digest = load_json(PARALLEL_DIR / "news_digest.json", {})
    if not digest:
        return "No news digest available"
    
    lines = [f"News ({digest.get('scan_time', 'unknown')[:10]}):"]
    
    # Alerts first
    alerts = digest.get('alerts', [])
    if alerts:
        lines.append(f"  ALERTS: {', '.join(alerts)}")
    
    # New items first, then high relevance
    items = digest.get('relevant_items', [])
    new_items = [i for i in items if i.get('is_new')]
    if new_items:
        lines.append("  NEW:")
        for item in new_items[:3]:
            lines.append(f"    - {item.get('one_line', item.get('title', '?'))[:60]}")
    
    # Top relevance (non-new)
    high = [i for i in items if i.get('relevance', 0) >= 4 and not i.get('is_new')][:3]
    if high:
        lines.append("  Notable:")
        for item in high:
            lines.append(f"    - {item.get('one_line', item.get('title', '?'))[:60]}")
    
    if digest.get('digest'):
        lines.append(f"  Summary: {digest['digest'][:150]}...")
    
    return "\n".join(lines)

def get_system_status():
    """Get body/system status."""
    heartbeat = load_json(OPUS_HOME / "body" / "heartbeat_state.json", {})
    status = heartbeat.get('status', 'unknown')
    beats = heartbeat.get('beats_since_start', 0)
    return f"Body: {status}, {beats} beats"

def get_pending_tasks():
    """Get high priority pending items."""
    todo = load_json(STATE_DIR / "todo.json", {})
    tasks = todo.get('tasks', [])
    high = [t for t in tasks if t.get('priority') == 'HIGH']
    if high:
        return "HIGH priority: " + "; ".join(t.get('title', '?')[:40] for t in high[:3])
    return "No HIGH priority tasks"

def generate_brief():
    """Generate the full wake brief."""
    brief = {
        "generated": datetime.now(timezone.utc).isoformat(),
        "news": get_news_brief(),
        "system": get_system_status(),
        "tasks": get_pending_tasks(),
    }
    return brief

def print_brief():
    """Print a human-readable brief."""
    brief = generate_brief()
    print("=" * 50)
    print("OPUS WAKE BRIEF")
    print("=" * 50)
    print(brief['system'])
    print()
    print(brief['news'])
    print()
    print(brief['tasks'])
    print("=" * 50)

if __name__ == "__main__":
    print_brief()
