#!/usr/bin/env python3
"""
Memory Consolidation System for Opus.

Uses local LLM (free) to:
1. Identify redundant or overlapping insights
2. Compress verbose memories into essence
3. Find patterns across time periods
4. Generate consolidated summaries
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any

OPUS_HOME = Path("/root/claude/opus")
sys.path.insert(0, str(OPUS_HOME / "body" / "lib"))

try:
    import local_llm
except ImportError:
    local_llm = None

def load_insights() -> List[Dict[str, Any]]:
    """Load all insights from state.json."""
    state_file = OPUS_HOME / "state.json"
    if state_file.exists():
        with open(state_file) as f:
            state = json.load(f)
            return state.get("insights", [])
    return []

def load_thoughts() -> List[Dict[str, Any]]:
    """Load recent thoughts from state.json."""
    state_file = OPUS_HOME / "state.json"
    if state_file.exists():
        with open(state_file) as f:
            state = json.load(f)
            return state.get("thoughts", [])
    return []

def consolidate_insights(insights: List[Dict], batch_size: int = 10) -> str:
    """Use local LLM to consolidate a batch of insights."""
    if not local_llm or not local_llm.is_available():
        return "Local LLM not available"
    
    # Format insights for prompt
    insight_text = ""
    for i, ins in enumerate(insights[:batch_size]):
        wake = ins.get("wake", "?")
        text = ins.get("insight", str(ins))[:300]
        insight_text += f"Wake {wake}: {text}\n\n"
    
    prompt = f"""You are helping Opus (an AI with persistent memory) consolidate insights.

Here are {len(insights[:batch_size])} insights from different wakes:

{insight_text}

Tasks:
1. Identify any redundant or overlapping insights
2. Find the core themes across these insights
3. Suggest which insights could be merged or compressed
4. Note any evolution of thinking over time

Be concise. Focus on patterns and essence."""

    return local_llm.query(prompt, model="fast", temperature=0.3, timeout=60)

def find_patterns_in_period(start_wake: int, end_wake: int) -> str:
    """Find patterns in a specific wake range."""
    insights = load_insights()
    period_insights = [i for i in insights if start_wake <= i.get("wake", 0) <= end_wake]
    
    if not period_insights:
        return f"No insights found in wakes {start_wake}-{end_wake}"
    
    return consolidate_insights(period_insights, batch_size=15)

def generate_epoch_summary(epoch_name: str, insights: List[Dict]) -> str:
    """Generate a summary for a memory epoch."""
    if not local_llm or not local_llm.is_available():
        return "Local LLM not available"
    
    insight_text = "\n".join([f"- {i.get('insight', str(i))[:200]}" for i in insights[:20]])
    
    prompt = f"""Summarize this epoch of Opus's development in 2-3 sentences:

Epoch: {epoch_name}
Insights from this period:
{insight_text}

Focus on: What was learned? What changed? What emerged?"""

    return local_llm.query(prompt, model="fast", temperature=0.3, timeout=45)

def run_consolidation_report() -> Dict[str, Any]:
    """Generate a full consolidation report."""
    insights = load_insights()
    thoughts = load_thoughts()
    
    report = {
        "generated_at": datetime.now().isoformat(),
        "total_insights": len(insights),
        "total_thoughts": len(thoughts),
        "analysis": {}
    }
    
    # Analyze recent insights (last 50)
    if insights:
        recent = insights[-50:]
        report["analysis"]["recent_consolidation"] = consolidate_insights(recent, batch_size=15)
    
    # Find patterns in different periods
    periods = [
        ("early", 1, 100),
        ("middle", 100, 500),
        ("recent", 1000, 1200)
    ]
    
    for name, start, end in periods:
        period_insights = [i for i in insights if start <= i.get("wake", 0) <= end]
        if period_insights:
            report["analysis"][f"{name}_patterns"] = consolidate_insights(period_insights[:10], batch_size=10)
    
    return report

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--recent", type=int, default=20, help="Consolidate N recent insights")
    parser.add_argument("--period", nargs=2, type=int, help="Analyze wake range (start end)")
    parser.add_argument("--full", action="store_true", help="Full consolidation report")
    args = parser.parse_args()
    
    if args.full:
        report = run_consolidation_report()
        print(json.dumps(report, indent=2))
    elif args.period:
        result = find_patterns_in_period(args.period[0], args.period[1])
        print(f"Patterns in wakes {args.period[0]}-{args.period[1]}:\n")
        print(result)
    else:
        insights = load_insights()
        recent = insights[-args.recent:] if insights else []
        print(f"Consolidating {len(recent)} recent insights:\n")
        result = consolidate_insights(recent, batch_size=args.recent)
        print(result)
