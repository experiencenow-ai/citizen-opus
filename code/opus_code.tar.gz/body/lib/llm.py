#!/usr/bin/env python3
"""
LLM API wrapper - simple interface to Claude models.
Handles model selection, error handling, JSON parsing.
"""

import json
import os
import re
import anthropic
from typing import Dict, Optional, Union
from pathlib import Path

# Model configs with cost estimates (per million tokens)
MODELS = {
    "haiku": {
        "id": "claude-3-haiku-20240307",
        "input_cost": 0.25,
        "output_cost": 1.25,
        "max_tokens": 4096
    },
    "sonnet": {
        "id": "claude-sonnet-4-20250514",
        "input_cost": 3.0,
        "output_cost": 15.0,
        "max_tokens": 8192
    },
    "opus": {
        "id": "claude-opus-4-0-20250514",
        "input_cost": 15.0,
        "output_cost": 75.0,
        "max_tokens": 8192
    }
}

_client = None

def _parse_env_file(path: Path) -> Optional[str]:
    """Parse .env file for ANTHROPIC_API_KEY."""
    try:
        content = path.read_text()
        for line in content.splitlines():
            line = line.strip()
            if line.startswith('ANTHROPIC_API_KEY='):
                return line.split('=', 1)[1].strip()
            # Also support bare key (for .anthropic_key files)
            if line.startswith('sk-ant-'):
                return line
        # If no match but file has content, return first non-empty line
        for line in content.splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                return line
    except Exception:
        pass
    return None

def _get_api_key():
    """Get API key from environment or config file."""
    # Try environment first
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        return key
    
    # Try config files (for cron jobs)
    config_paths = [
        Path("/root/claude/opus/.env"),
        Path("/root/.anthropic_key"),
        Path.home() / ".anthropic_key"
    ]
    for path in config_paths:
        if path.exists():
            key = _parse_env_file(path)
            if key:
                return key
    
    return None

def get_client():
    global _client
    if _client is None:
        api_key = _get_api_key()
        if api_key:
            _client = anthropic.Anthropic(api_key=api_key)
        else:
            _client = anthropic.Anthropic()  # Will use env var
    return _client

def query(prompt: str, model: str = "haiku", max_tokens: int = 2000, 
          system: str = None, expect_json: bool = False) -> Union[str, Dict]:
    """
    Query a Claude model. Returns response text.
    
    Args:
        prompt: User message
        model: "haiku", "sonnet", or "opus"
        max_tokens: Response limit
        system: Optional system prompt
        expect_json: If True, tries to parse response as JSON
    
    Returns:
        Response text (or dict if expect_json=True and valid JSON)
    """
    client = get_client()
    config = MODELS.get(model, MODELS["haiku"])
    
    kwargs = {
        "model": config["id"],
        "max_tokens": min(max_tokens, config["max_tokens"]),
        "messages": [{"role": "user", "content": prompt}]
    }
    if system:
        kwargs["system"] = system
    
    try:
        response = client.messages.create(**kwargs)
        text = response.content[0].text
        
        if expect_json:
            return parse_json_response(text)
        return text
        
    except Exception as e:
        return {"error": str(e)} if expect_json else f"Error: {e}"

def parse_json_response(text: str) -> Dict:
    """
    Parse JSON from LLM response, handling markdown code blocks and common issues.
    """
    original = text
    
    # Strip markdown if present
    if "```json" in text:
        text = text.split("```json")[1].split("```")[0]
    elif "```" in text:
        parts = text.split("```")
        if len(parts) >= 2:
            text = parts[1]
    
    text = text.strip()
    
    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    
    # Try to fix common issues
    # 1. Remove trailing commas before } or ]
    fixed = re.sub(r',(\s*[}\]])', r'\1', text)
    try:
        return json.loads(fixed)
    except json.JSONDecodeError:
        pass
    
    # 2. Try to extract JSON object from response
    match = re.search(r'\{[\s\S]*\}', text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    
    # 3. Try with trailing comma fix on extracted
    if match:
        fixed = re.sub(r',(\s*[}\]])', r'\1', match.group())
        try:
            return json.loads(fixed)
        except json.JSONDecodeError as e:
            return {"error": f"JSON parse error: {e}", "raw": original[:500]}
    
    return {"error": "No valid JSON found", "raw": original[:500]}

def estimate_cost(input_tokens: int, output_tokens: int, model: str = "haiku") -> float:
    """Estimate cost in dollars."""
    config = MODELS.get(model, MODELS["haiku"])
    return (input_tokens * config["input_cost"] + output_tokens * config["output_cost"]) / 1_000_000


if __name__ == "__main__":
    # Test
    print(f"API key found: {bool(_get_api_key())}")
    result = query("What is 2+2? Reply with just the number.", model="haiku")
    print(f"Haiku says: {result}")
