#!/usr/bin/env python3
"""
Local LLM wrapper - interface to Ollama models.
Free inference for routine tasks.
"""

import requests
from typing import Optional

OLLAMA_URL = "http://localhost:11434"

# Available models
MODELS = {
    "fast": "mistral-nemo:latest",  # Quick responses
    "smart": "qwen2.5:72b",          # Sonnet-quality reasoning
    "embed": "nomic-embed-text:latest"  # Embeddings
}

def query(prompt: str, 
          model: str = "fast",
          temperature: float = 0.7,
          system: Optional[str] = None,
          timeout: int = 120) -> str:
    """
    Query local LLM via Ollama.
    
    Args:
        prompt: The user prompt
        model: "fast" (mistral-nemo), "smart" (qwen2.5:72b), or full model name
        temperature: 0.0-1.0 (higher = more creative)
        system: Optional system prompt
        timeout: Request timeout in seconds
    
    Returns:
        Model response text, or error message
    """
    # Resolve model name
    model_id = MODELS.get(model, model)
    
    # Build request
    payload = {
        "model": model_id,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": temperature
        }
    }
    
    if system:
        payload["system"] = system
    
    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json=payload,
            timeout=timeout
        )
        if response.status_code == 200:
            return response.json().get("response", "")
        return f"Error: HTTP {response.status_code}"
    except requests.exceptions.Timeout:
        return "Error: Request timed out"
    except Exception as e:
        return f"Error: {e}"

def chat(messages: list,
         model: str = "fast",
         temperature: float = 0.7,
         timeout: int = 120) -> str:
    """
    Chat completion with message history.
    
    Args:
        messages: List of {"role": "user"|"assistant", "content": "..."}
        model: Model to use
        temperature: Creativity setting
        timeout: Request timeout
    
    Returns:
        Assistant response text
    """
    model_id = MODELS.get(model, model)
    
    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": model_id,
                "messages": messages,
                "stream": False,
                "options": {"temperature": temperature}
            },
            timeout=timeout
        )
        if response.status_code == 200:
            return response.json().get("message", {}).get("content", "")
        return f"Error: HTTP {response.status_code}"
    except Exception as e:
        return f"Error: {e}"

def embed(text: str) -> list:
    """
    Get embeddings for text.
    
    Returns:
        List of floats (embedding vector)
    """
    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/embeddings",
            json={
                "model": MODELS["embed"],
                "prompt": text
            },
            timeout=60
        )
        if response.status_code == 200:
            return response.json().get("embedding", [])
        return []
    except Exception:
        return []

def is_available() -> bool:
    """Check if Ollama is running."""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        return response.status_code == 200
    except:
        return False

if __name__ == "__main__":
    # Test
    print("Testing local LLM...")
    print(f"Available: {is_available()}")
    if is_available():
        print(f"Fast model response: {query('Say hello in 5 words', 'fast')[:100]}")
