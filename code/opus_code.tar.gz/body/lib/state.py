#!/usr/bin/env python3
"""
State management - read/write JSON state files with change detection.
Implements ct's advice: suppress data if no change.
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional

OPUS_HOME = Path("/root/claude/opus")
PARALLEL_DIR = OPUS_HOME / "state" / "parallel"

def ensure_dirs():
    """Create necessary directories."""
    PARALLEL_DIR.mkdir(parents=True, exist_ok=True)

def read_state(filename: str, default: Any = None) -> Any:
    """Read a JSON state file. Returns default if not found."""
    path = PARALLEL_DIR / filename if not Path(filename).is_absolute() else Path(filename)
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}

def write_state(filename: str, data: Any, only_if_changed: bool = True) -> bool:
    """
    Write JSON state file.
    
    Args:
        filename: Filename (relative to parallel dir or absolute)
        data: Data to write
        only_if_changed: If True, skip write if content unchanged
        
    Returns:
        True if written, False if skipped (no change)
    """
    ensure_dirs()
    path = PARALLEL_DIR / filename if not Path(filename).is_absolute() else Path(filename)
    
    new_content = json.dumps(data, indent=2, sort_keys=True)
    new_hash = hashlib.md5(new_content.encode()).hexdigest()
    
    if only_if_changed and path.exists():
        with open(path, 'r') as f:
            old_hash = hashlib.md5(f.read().encode()).hexdigest()
        if old_hash == new_hash:
            return False
    
    with open(path, 'w') as f:
        f.write(new_content)
    return True

def get_last_hash(filename: str) -> Optional[str]:
    """Get MD5 hash of current state file contents."""
    path = PARALLEL_DIR / filename
    if not path.exists():
        return None
    with open(path, 'r') as f:
        return hashlib.md5(f.read().encode()).hexdigest()

def timestamp() -> str:
    """Current UTC ISO timestamp."""
    return datetime.utcnow().isoformat() + "Z"


if __name__ == "__main__":
    # Test
    ensure_dirs()
    test_data = {"test": "data", "time": timestamp()}
    written = write_state("test_state.json", test_data)
    print(f"Written: {written}")
    written2 = write_state("test_state.json", test_data)  # Should skip
    print(f"Written again: {written2}")  # Should be False
