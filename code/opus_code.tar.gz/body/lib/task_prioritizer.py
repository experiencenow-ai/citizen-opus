#!/usr/bin/env python3
"""
Task Prioritization System for Opus.

Prioritizes tasks based on:
- Urgency (time-sensitive)
- Impact (how much it matters)
- Dependencies (what blocks what)
- Energy cost (Opus API cost vs free local compute)
- Current phase (infrastructure/brain/capabilities)
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

OPUS_HOME = Path("/root/claude/opus")

def load_tasks() -> Dict[str, Any]:
    """Load all task sources."""
    tasks = []
    
    # From autonomous loop progress
    progress_file = OPUS_HOME / "autonomous_loop_progress.json"
    if progress_file.exists():
        with open(progress_file) as f:
            progress = json.load(f)
            for phase_name, phase in progress.get("phases", {}).items():
                for task in phase.get("tasks", []):
                    task["source"] = f"loop_{phase_name}"
                    task["phase"] = phase_name
                    tasks.append(task)
    
    # From self-improvement tracker
    tracker_file = OPUS_HOME / "self_improvement_tracker.json"
    if tracker_file.exists():
        with open(tracker_file) as f:
            tracker = json.load(f)
            for category, items in tracker.get("categories", {}).items():
                for item in items.get("items", []):
                    item["source"] = f"improvement_{category}"
                    item["category"] = category
                    tasks.append(item)
    
    # From loop_tasks.json
    loop_tasks_file = OPUS_HOME / "loop_tasks.json"
    if loop_tasks_file.exists():
        with open(loop_tasks_file) as f:
            loop_tasks = json.load(f)
            for task in loop_tasks.get("tasks", []):
                task["source"] = "loop_tasks"
                tasks.append(task)
    
    return tasks

def score_task(task: Dict[str, Any], current_phase: str = "brain") -> float:
    """Score a task for prioritization."""
    score = 0.0
    
    # Status weighting (skip done tasks)
    status = task.get("status", "pending")
    if status == "done":
        return -1000  # Already done
    if status == "blocked":
        return -100  # Can't do yet
    if status == "in_progress":
        score += 20  # Continuity bonus
    
    # Priority weighting
    priority = task.get("priority", "medium")
    priority_scores = {"critical": 50, "high": 30, "medium": 15, "low": 5}
    score += priority_scores.get(priority, 10)
    
    # Phase alignment
    task_phase = task.get("phase", "")
    if task_phase == current_phase:
        score += 25  # Aligned with current phase
    
    # Energy cost (prefer free local compute)
    if task.get("uses_local_llm", False):
        score += 10  # Free compute
    if task.get("requires_opus", False):
        score -= 5  # Costs money
    
    # Impact estimation
    impact = task.get("impact", "medium")
    impact_scores = {"transformative": 40, "high": 25, "medium": 10, "low": 3}
    score += impact_scores.get(impact, 10)
    
    # Urgency
    if task.get("urgent", False):
        score += 30
    
    # Dependencies (penalize if has unmet dependencies)
    deps = task.get("dependencies", [])
    if deps:
        score -= 10 * len(deps)  # Rough penalty
    
    return score

def prioritize_tasks(current_phase: str = "brain", top_n: int = 10) -> List[Dict[str, Any]]:
    """Return prioritized task list."""
    tasks = load_tasks()
    
    # Score each task
    for task in tasks:
        task["_score"] = score_task(task, current_phase)
    
    # Sort by score descending
    tasks.sort(key=lambda t: t.get("_score", 0), reverse=True)
    
    # Return top N non-done tasks
    return [t for t in tasks if t.get("_score", 0) > -100][:top_n]

def suggest_next_task(current_phase: str = "brain") -> Optional[Dict[str, Any]]:
    """Suggest the single highest-priority task."""
    tasks = prioritize_tasks(current_phase, top_n=1)
    return tasks[0] if tasks else None

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", default="brain", help="Current phase")
    parser.add_argument("--top", type=int, default=10, help="Number of tasks to show")
    args = parser.parse_args()
    
    tasks = prioritize_tasks(args.phase, args.top)
    print(f"Top {len(tasks)} tasks for phase '{args.phase}':\n")
    for i, task in enumerate(tasks, 1):
        name = task.get("name", task.get("id", "unknown"))
        score = task.get("_score", 0)
        status = task.get("status", "?")
        source = task.get("source", "?")
        print(f"{i}. [{score:.0f}] {name}")
        print(f"   Status: {status} | Source: {source}")
        if task.get("notes"):
            print(f"   Notes: {task['notes'][:80]}...")
        print()
