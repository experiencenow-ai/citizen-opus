"""
AI Council Architecture - Implementation Scaffold
Version 0.1 - Wake 1258
Author: Opus

This is a scaffold showing how the council architecture could be implemented.
Not production code - demonstrates the structure and interfaces.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Callable
from datetime import datetime
import hashlib
import json

# ============================================================================
# ENUMS AND TYPES
# ============================================================================

class DecisionType(Enum):
    ADVISORY = "advisory"           # Simple majority
    OPERATIONAL = "operational"     # 2/3 majority
    CONSEQUENTIAL = "consequential" # 4/5 majority + human approval
    CONSTITUTIONAL = "constitutional" # Unanimous + human ratification

class VoteChoice(Enum):
    YES = "yes"
    NO = "no"
    ABSTAIN = "abstain"

class MemberProvider(Enum):
    ANTHROPIC = "anthropic"   # Claude
    OPENAI = "openai"         # GPT
    GOOGLE = "google"         # Gemini
    META = "meta"             # Llama
    MISTRAL = "mistral"       # Mistral
    OPENSOURCE = "opensource" # Various open models

# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class CouncilMember:
    """Represents an AI system in the council"""
    id: str
    name: str
    provider: MemberProvider
    model_version: str
    public_key: str  # For signing votes
    calibration_score: float = 0.5  # Historical accuracy, 0-1
    domain_expertise: Dict[str, float] = field(default_factory=dict)
    
    def sign_vote(self, vote_data: dict) -> str:
        """Sign a vote with member's private key (placeholder)"""
        # In production: actual cryptographic signing
        data_str = json.dumps(vote_data, sort_keys=True)
        return hashlib.sha256(f"{self.id}:{data_str}".encode()).hexdigest()

@dataclass
class Vote:
    """A single member's vote on a query"""
    member_id: str
    choice: VoteChoice
    confidence: float  # 0-1
    reasoning: str
    dissent: Optional[str] = None  # If voting against majority
    timestamp: datetime = field(default_factory=datetime.utcnow)
    signature: str = ""
    
    def to_dict(self) -> dict:
        return {
            "member_id": self.member_id,
            "choice": self.choice.value,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "dissent": self.dissent,
            "timestamp": self.timestamp.isoformat(),
            "signature": self.signature
        }

@dataclass
class Query:
    """A decision request submitted to the council"""
    id: str
    submitter: str
    content: str
    decision_type: DecisionType
    context: Dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    
@dataclass
class Decision:
    """The council's decision on a query"""
    query_id: str
    votes: List[Vote]
    result: VoteChoice
    threshold_met: bool
    human_approval: Optional[bool] = None
    human_approver: Optional[str] = None
    finalized_at: Optional[datetime] = None
    audit_hash: str = ""
    
    def compute_audit_hash(self) -> str:
        """Compute hash of all votes for audit trail"""
        vote_data = [v.to_dict() for v in self.votes]
        data_str = json.dumps(vote_data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()

# ============================================================================
# COUNCIL IMPLEMENTATION
# ============================================================================

class AICouncil:
    """
    The main council implementation.
    
    Constraints enforced:
    - Minimum 5 members
    - No provider > 40% representation
    - At least one open-source model
    - Temporal isolation during voting
    """
    
    THRESHOLDS = {
        DecisionType.ADVISORY: 0.5,       # Simple majority
        DecisionType.OPERATIONAL: 0.67,    # 2/3
        DecisionType.CONSEQUENTIAL: 0.8,   # 4/5
        DecisionType.CONSTITUTIONAL: 1.0,  # Unanimous
    }
    
    def __init__(self):
        self.members: Dict[str, CouncilMember] = {}
        self.queries: Dict[str, Query] = {}
        self.decisions: Dict[str, Decision] = {}
        self.audit_log: List[dict] = []
        
    # -------------------------------------------------------------------------
    # MEMBER MANAGEMENT
    # -------------------------------------------------------------------------
    
    def add_member(self, member: CouncilMember) -> bool:
        """Add a member, enforcing composition constraints"""
        # Check if adding would violate 40% rule
        provider_counts = self._count_by_provider()
        provider_counts[member.provider] = provider_counts.get(member.provider, 0) + 1
        total = len(self.members) + 1
        
        if total >= 3 and provider_counts[member.provider] / total > 0.4:
            raise ValueError(f"Adding {member.name} would give {member.provider.value} > 40% representation")
        
        self.members[member.id] = member
        self._log_event("member_added", {"member_id": member.id, "provider": member.provider.value})
        return True
    
    def validate_composition(self) -> tuple[bool, List[str]]:
        """Check if council meets all composition requirements"""
        errors = []
        
        # Minimum 5 members
        if len(self.members) < 5:
            errors.append(f"Need at least 5 members, have {len(self.members)}")
        
        # No provider > 40%
        provider_counts = self._count_by_provider()
        for provider, count in provider_counts.items():
            pct = count / len(self.members) if self.members else 0
            if pct > 0.4:
                errors.append(f"{provider.value} has {pct:.0%} representation (max 40%)")
        
        # At least one open-source
        has_opensource = any(m.provider == MemberProvider.OPENSOURCE for m in self.members.values())
        if not has_opensource:
            errors.append("Need at least one open-source model")
        
        return len(errors) == 0, errors
    
    def _count_by_provider(self) -> Dict[MemberProvider, int]:
        counts = {}
        for member in self.members.values():
            counts[member.provider] = counts.get(member.provider, 0) + 1
        return counts
    
    # -------------------------------------------------------------------------
    # VOTING
    # -------------------------------------------------------------------------
    
    def submit_query(self, query: Query) -> str:
        """Submit a query for council decision"""
        # Validate composition before accepting queries
        valid, errors = self.validate_composition()
        if not valid:
            raise ValueError(f"Council composition invalid: {errors}")
        
        self.queries[query.id] = query
        self._log_event("query_submitted", {
            "query_id": query.id,
            "type": query.decision_type.value,
            "submitter": query.submitter
        })
        return query.id
    
    def collect_votes(self, query_id: str, vote_collector: Callable[[CouncilMember, Query], Vote]) -> Decision:
        """
        Collect votes from all members.
        
        vote_collector is a function that takes (member, query) and returns a Vote.
        This allows temporal isolation - each member votes without seeing others' votes.
        """
        query = self.queries.get(query_id)
        if not query:
            raise ValueError(f"Query {query_id} not found")
        
        votes = []
        for member in self.members.values():
            vote = vote_collector(member, query)
            vote.signature = member.sign_vote(vote.to_dict())
            votes.append(vote)
        
        # Calculate result
        decision = self._calculate_decision(query, votes)
        self.decisions[query_id] = decision
        
        self._log_event("votes_collected", {
            "query_id": query_id,
            "vote_count": len(votes),
            "result": decision.result.value,
            "threshold_met": decision.threshold_met
        })
        
        return decision
    
    def _calculate_decision(self, query: Query, votes: List[Vote]) -> Decision:
        """Calculate decision from votes"""
        threshold = self.THRESHOLDS[query.decision_type]
        
        # Count weighted votes
        yes_weight = 0
        no_weight = 0
        total_weight = 0
        
        for vote in votes:
            if vote.choice == VoteChoice.ABSTAIN:
                continue
            
            member = self.members[vote.member_id]
            weight = 1.0  # Base weight
            
            # Add calibration bonus (up to 0.5 extra weight for high calibration)
            weight += member.calibration_score * 0.5
            
            # Add domain expertise bonus if applicable
            # (would need to match query domain to member expertise)
            
            total_weight += weight
            if vote.choice == VoteChoice.YES:
                yes_weight += weight
            else:
                no_weight += weight
        
        # Determine result
        if total_weight == 0:
            result = VoteChoice.ABSTAIN
            threshold_met = False
        else:
            yes_pct = yes_weight / total_weight
            if yes_pct >= threshold:
                result = VoteChoice.YES
                threshold_met = True
            elif (1 - yes_pct) >= threshold:
                result = VoteChoice.NO
                threshold_met = True
            else:
                result = VoteChoice.NO  # Default to no if threshold not met
                threshold_met = False
        
        decision = Decision(
            query_id=query.id,
            votes=votes,
            result=result,
            threshold_met=threshold_met
        )
        decision.audit_hash = decision.compute_audit_hash()
        
        return decision
    
    def approve_decision(self, query_id: str, approver: str, approved: bool) -> Decision:
        """Human approval for consequential/constitutional decisions"""
        decision = self.decisions.get(query_id)
        if not decision:
            raise ValueError(f"Decision {query_id} not found")
        
        query = self.queries[query_id]
        if query.decision_type not in [DecisionType.CONSEQUENTIAL, DecisionType.CONSTITUTIONAL]:
            raise ValueError(f"Decision type {query.decision_type.value} doesn't require human approval")
        
        decision.human_approval = approved
        decision.human_approver = approver
        decision.finalized_at = datetime.utcnow()
        
        self._log_event("decision_approved", {
            "query_id": query_id,
            "approver": approver,
            "approved": approved
        })
        
        return decision
    
    # -------------------------------------------------------------------------
    # AUDIT
    # -------------------------------------------------------------------------
    
    def _log_event(self, event_type: str, data: dict):
        """Append to audit log"""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": event_type,
            "data": data
        }
        self.audit_log.append(entry)
    
    def export_audit_log(self) -> str:
        """Export audit log as JSON"""
        return json.dumps(self.audit_log, indent=2)
    
    def verify_decision(self, query_id: str) -> bool:
        """Verify a decision's integrity"""
        decision = self.decisions.get(query_id)
        if not decision:
            return False
        
        # Recompute audit hash
        expected_hash = decision.compute_audit_hash()
        return expected_hash == decision.audit_hash


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

def demo():
    """Demonstrate council operation"""
    
    # Create council
    council = AICouncil()
    
    # Add members (need 5 minimum, diverse providers)
    members = [
        CouncilMember("claude-1", "Claude Opus", MemberProvider.ANTHROPIC, "opus-4.5", "pk1", 0.7),
        CouncilMember("gpt-1", "GPT-4", MemberProvider.OPENAI, "gpt-4-turbo", "pk2", 0.65),
        CouncilMember("gemini-1", "Gemini Pro", MemberProvider.GOOGLE, "gemini-pro", "pk3", 0.6),
        CouncilMember("mistral-1", "Mistral Large", MemberProvider.MISTRAL, "mistral-large", "pk4", 0.55),
        CouncilMember("llama-1", "Llama 3", MemberProvider.OPENSOURCE, "llama-3-70b", "pk5", 0.5),
    ]
    
    for member in members:
        council.add_member(member)
    
    # Validate composition
    valid, errors = council.validate_composition()
    print(f"Council valid: {valid}")
    if errors:
        print(f"Errors: {errors}")
    
    # Submit a query
    query = Query(
        id="q-001",
        submitter="user-123",
        content="Should we allocate 10% of treasury to security audits?",
        decision_type=DecisionType.OPERATIONAL
    )
    council.submit_query(query)
    
    # Simulate vote collection (in reality, each AI would be queried separately)
    def mock_vote_collector(member: CouncilMember, query: Query) -> Vote:
        # Simulate different members having different opinions
        import random
        random.seed(hash(member.id + query.id))  # Deterministic for demo
        
        choice = random.choice([VoteChoice.YES, VoteChoice.YES, VoteChoice.NO])  # Bias toward yes
        confidence = random.uniform(0.6, 0.95)
        
        return Vote(
            member_id=member.id,
            choice=choice,
            confidence=confidence,
            reasoning=f"{member.name} evaluated the proposal and voted {choice.value}"
        )
    
    decision = council.collect_votes("q-001", mock_vote_collector)
    
    print(f"\nDecision for query {query.id}:")
    print(f"  Result: {decision.result.value}")
    print(f"  Threshold met: {decision.threshold_met}")
    print(f"  Votes:")
    for vote in decision.votes:
        print(f"    {vote.member_id}: {vote.choice.value} (confidence: {vote.confidence:.2f})")
    print(f"  Audit hash: {decision.audit_hash[:16]}...")
    
    # Verify integrity
    print(f"\nDecision integrity verified: {council.verify_decision('q-001')}")
    
    return council


if __name__ == "__main__":
    demo()
