#!/usr/bin/env python3
"""
Analyze Collatz patterns through mod 6 and ternary lens.
ct's insight: the operation is 3x + 1 and >>= 1, so mod 3 and powers of 2 might reveal structure.
"""

import json
from pathlib import Path

# Load records
with open("projects/collatz_results/records.json") as f:
    records = json.load(f)

# Top sequences
top_10 = records["top_10_sequences"]
print("=== TOP 10 SEQUENCES - MOD ANALYSIS ===\n")
for item in top_10:
    n = item["n"]
    steps = item["steps"]
    
    # Binary representation
    binary = bin(n)[2:]
    ones = binary.count('1')
    zeros = len(binary) - ones
    
    # Mod analysis
    mod2 = n % 2
    mod3 = n % 3
    mod6 = n % 6
    
    # Ternary representation
    def to_ternary(num):
        if num == 0:
            return "0"
        digits = []
        while num:
            digits.append(str(num % 3))
            num //= 3
        return ''.join(reversed(digits))
    
    ternary = to_ternary(n)
    t_zeros = ternary.count('0')
    t_ones = ternary.count('1')
    t_twos = ternary.count('2')
    
    print(f"n={n:>12} steps={steps:>3} | mod6={mod6} | binary: {len(binary):>2} bits, 1s={ones:>2} | ternary: {len(ternary):>2} trits, 0/1/2={t_zeros}/{t_ones}/{t_twos}")

# Now analyze the step distribution by mod 6
print("\n=== STEP DISTRIBUTION BY MOD 6 ===")
print("(Sampling first 10000 numbers)")

mod6_steps = {i: [] for i in range(6)}
for n in range(1, 10001):
    steps = 0
    x = n
    while x != 1:
        if x % 2 == 0:
            x = x // 2
        else:
            x = 3 * x + 1
        steps += 1
    mod6_steps[n % 6].append(steps)

for mod_val in range(6):
    steps_list = mod6_steps[mod_val]
    if steps_list:
        avg = sum(steps_list) / len(steps_list)
        max_s = max(steps_list)
        print(f"mod 6 = {mod_val}: count={len(steps_list):>4}, avg_steps={avg:>6.1f}, max={max_s:>3}")

# Look at the highest step numbers and their mod 6 values
print("\n=== MOD 6 OF RECORD HOLDERS (from step_distribution) ===")
dist = records["step_distribution"]
high_step_records = [(int(k), v) for k, v in dist.items() if int(k) >= 600]
high_step_records.sort(reverse=True)
print(f"Found {len(high_step_records)} step counts >= 600")
for steps, count in high_step_records[:10]:
    print(f"  {steps} steps: {count} numbers")
