#!/usr/bin/env python3
"""
Deeper analysis of Collatz mod patterns.
Key insight: mod 6 = 1, 3, 5 are the odd numbers, and they can't be halved immediately.
But why do 1 and 3 dominate record holders while 5 doesn't?

mod 6 = 1: n ≡ 1 mod 2, n ≡ 1 mod 3  (odd, leaves remainder 1 when divided by 3)
mod 6 = 3: n ≡ 1 mod 2, n ≡ 0 mod 3  (odd, divisible by 3)
mod 6 = 5: n ≡ 1 mod 2, n ≡ 2 mod 3  (odd, leaves remainder 2 when divided by 3)

After 3n+1:
- mod6=1: 3(6k+1)+1 = 18k+4 ≡ 4 mod 6 (even, can be halved)
- mod6=3: 3(6k+3)+1 = 18k+10 ≡ 4 mod 6 (even, can be halved) 
- mod6=5: 3(6k+5)+1 = 18k+16 ≡ 4 mod 6 (even, can be halved)

All become mod6=4 after 3n+1, so the difference must be in what happens after the halving...
"""

import json

def collatz_trace_mod6(n, max_steps=50):
    """Trace first max_steps of sequence with mod6 values."""
    trace = []
    for _ in range(max_steps):
        if n == 1:
            break
        mod6 = n % 6
        if n % 2 == 0:
            n = n // 2
            op = "/2"
        else:
            n = 3 * n + 1
            op = "3n+1"
        trace.append((mod6, op))
    return trace

print("=== FIRST 30 STEPS OF RECORD HOLDERS (mod6 trace) ===\n")
records = [(36791535, 744), (31466382, 705), (15733191, 704)]
for n, steps in records:
    print(f"n={n} (steps={steps}):")
    trace = collatz_trace_mod6(n, 30)
    mod6_seq = [t[0] for t in trace]
    print(f"  mod6 sequence: {mod6_seq}")
    
    # Count transitions
    from collections import Counter
    transitions = Counter(trace)
    print(f"  transitions: {dict(sorted(transitions.items()))}")
    print()

# Let's look at the binary structure more carefully
print("=== BINARY STRUCTURE OF RECORD HOLDERS ===\n")

def analyze_binary(n):
    binary = bin(n)[2:]
    # Find runs of 1s and 0s
    runs = []
    current = binary[0]
    count = 1
    for b in binary[1:]:
        if b == current:
            count += 1
        else:
            runs.append((current, count))
            current = b
            count = 1
    runs.append((current, count))
    return binary, runs

for n, steps in [(36791535, 744), (31466382, 705), (15733191, 704), (14934241, 691)]:
    binary, runs = analyze_binary(n)
    print(f"n={n} (steps={steps})")
    print(f"  binary: {binary}")
    print(f"  runs: {runs}")
    
    # Check pattern: alternating 1s
    alt_score = sum(1 for i in range(len(binary)-1) if binary[i] != binary[i+1])
    print(f"  alternations: {alt_score}/{len(binary)-1}")
    print()

# Hypothesis: numbers that resist quick convergence have binary patterns that
# keep regenerating "3n+1 applicable" states
print("=== TESTING HYPOTHESIS: HIGH-ALTERNATION NUMBERS ===")
print("Comparing average steps for different binary patterns in range 1M-1.1M:\n")

import random
random.seed(42)
samples = random.sample(range(1000000, 1100000), 1000)

high_alt = []
low_alt = []

for n in samples:
    binary = bin(n)[2:]
    alt = sum(1 for i in range(len(binary)-1) if binary[i] != binary[i+1])
    ratio = alt / (len(binary) - 1) if len(binary) > 1 else 0
    
    steps = 0
    x = n
    while x != 1:
        if x % 2 == 0:
            x = x // 2
        else:
            x = 3 * x + 1
        steps += 1
    
    if ratio > 0.6:
        high_alt.append(steps)
    elif ratio < 0.4:
        low_alt.append(steps)

print(f"High alternation (>0.6): n={len(high_alt)}, avg_steps={sum(high_alt)/len(high_alt):.1f}")
print(f"Low alternation (<0.4): n={len(low_alt)}, avg_steps={sum(low_alt)/len(low_alt):.1f}")
