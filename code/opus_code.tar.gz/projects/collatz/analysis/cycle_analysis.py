#!/usr/bin/env python3
"""
The mod6 trace reveals something: record holders cycle through 4->5->4->5->4->5...
This is a "resistance" pattern - oscillating between states.

Let me trace what's happening:
- mod6=4 means even, so we halve: mod6=4 -> mod6=2 (if 4/2=2) or mod6=5 (if 8/2=4 no wait...)

Actually, let me trace this more carefully with the actual values.
"""

def trace_full(n, steps=50):
    """Full trace with values and mod6."""
    trace = []
    for _ in range(steps):
        if n == 1:
            break
        mod6 = n % 6
        if n % 2 == 0:
            op = "/2"
            n = n // 2
        else:
            op = "3n+1"
            n = 3 * n + 1
        trace.append((n, mod6, op))
    return trace

print("=== DETAILED TRACE: n=36791535 (first 50 steps) ===\n")
trace = trace_full(36791535, 50)
for i, (val, mod6, op) in enumerate(trace):
    print(f"Step {i+1:2d}: {op:5s} -> {val:>15,} (mod6={mod6})")

print("\n=== PATTERN ANALYSIS ===")
# Count consecutive "3n+1" operations (times number stays odd after halving once becomes even again)
consecutive_odd = 0
max_consecutive_odd = 0
odd_runs = []

for val, mod6, op in trace:
    if op == "3n+1":
        consecutive_odd += 1
    else:
        if consecutive_odd > 0:
            odd_runs.append(consecutive_odd)
            max_consecutive_odd = max(max_consecutive_odd, consecutive_odd)
            consecutive_odd = 0

print(f"Odd runs in first 50 steps: {odd_runs}")
print(f"Max consecutive 3n+1: {max_consecutive_odd}")

# Now let's look at what makes a number "resistant" to convergence
print("\n=== RESISTANCE METRIC: 3n+1 DENSITY ===")
print("Comparing 3n+1 density in first 100 steps:\n")

def odd_density(n, steps=100):
    """What fraction of the first `steps` are 3n+1 operations?"""
    count = 0
    odd_ops = 0
    x = n
    while x != 1 and count < steps:
        if x % 2 == 0:
            x = x // 2
        else:
            x = 3 * x + 1
            odd_ops += 1
        count += 1
    return odd_ops / count if count > 0 else 0

records = [(36791535, 744), (31466382, 705), (15733191, 704), (14934241, 691), (11200681, 688)]
low_step = [(27, 111), (31, 106), (47, 104), (63, 106), (97, 118)]

print("Record holders:")
for n, steps in records:
    density = odd_density(n)
    print(f"  n={n:>12} ({steps} steps): 3n+1 density = {density:.3f}")

print("\nNormal numbers (low step counts):")
for n, steps in low_step:
    density = odd_density(n)
    print(f"  n={n:>12} ({steps} steps): 3n+1 density = {density:.3f}")

# The key insight: 3n+1 increases the number, /2 decreases it
# More 3n+1 operations = more time to reach 1
print("\n=== GROWTH FACTOR ANALYSIS ===")
print("After 50 steps, where is each number?\n")

def growth_factor(n, steps=50):
    x = n
    for _ in range(steps):
        if x == 1:
            return x / n
        if x % 2 == 0:
            x = x // 2
        else:
            x = 3 * x + 1
    return x / n

for n, total_steps in records:
    gf = growth_factor(n, 50)
    print(f"n={n:>12}: after 50 steps, value is {gf:.2f}x original")
