#!/usr/bin/env python3
"""
Collatz Daemon - runs continuously, yields to other processes, designed for 8-16 core system.
Checks one batch, saves, sleeps briefly to allow other tasks.
"""

import json
import time
import os
from datetime import datetime
from pathlib import Path
import multiprocessing as mp

RESULTS_DIR = Path("/root/claude/opus/projects/collatz_results")
STATE_FILE = RESULTS_DIR / "state.json"
RECORDS_FILE = RESULTS_DIR / "records.json"
DAEMON_LOG = RESULTS_DIR / "daemon.log"

BATCH_SIZE = 100000  # Numbers per batch
SLEEP_BETWEEN_BATCHES = 0.5  # Brief yield to other processes
NUM_WORKERS = max(1, mp.cpu_count() - 2)  # Leave 2 cores free

def collatz_stats(n):
    """Return (steps, peak) for number n."""
    steps = 0
    peak = n
    current = n
    while current != 1:
        if current % 2 == 0:
            current = current // 2
        else:
            current = 3 * current + 1
        peak = max(peak, current)
        steps += 1
    return n, steps, peak

def process_batch(args):
    """Process a batch of numbers."""
    start_n, end_n = args
    results = []
    for n in range(start_n, end_n):
        results.append(collatz_stats(n))
    return results

def load_state():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"current_n": 1, "numbers_checked": 0, "start_time": datetime.now().isoformat()}

def load_records():
    if RECORDS_FILE.exists():
        with open(RECORDS_FILE) as f:
            return json.load(f)
    return {
        "longest_sequence": {"n": 1, "steps": 0},
        "highest_peak": {"n": 1, "peak": 1},
        "top_10_sequences": []
    }

def save_state(state):
    state["last_update"] = datetime.now().isoformat()
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def save_records(records):
    with open(RECORDS_FILE, "w") as f:
        json.dump(records, f, indent=2)

def log(msg):
    with open(DAEMON_LOG, "a") as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

def main():
    state = load_state()
    records = load_records()
    
    log(f"Daemon started at n={state['current_n']} with {NUM_WORKERS} workers")
    
    while True:
        start_n = state["current_n"]
        end_n = start_n + BATCH_SIZE
        
        # Split batch across workers
        chunk_size = BATCH_SIZE // NUM_WORKERS
        chunks = [(start_n + i*chunk_size, start_n + (i+1)*chunk_size) for i in range(NUM_WORKERS)]
        
        with mp.Pool(NUM_WORKERS) as pool:
            all_results = pool.map(process_batch, chunks)
        
        # Flatten and process results
        for batch in all_results:
            for n, steps, peak in batch:
                # Update records
                if steps > records["longest_sequence"]["steps"]:
                    records["longest_sequence"] = {"n": n, "steps": steps}
                    log(f"New record: n={n}, steps={steps}")
                
                if peak > records["highest_peak"]["peak"]:
                    records["highest_peak"] = {"n": n, "peak": peak}
                
                # Update top 10
                top10 = records["top_10_sequences"]
                if len(top10) < 10 or steps > top10[-1]["steps"]:
                    top10.append({"n": n, "steps": steps})
                    top10.sort(key=lambda x: -x["steps"])
                    records["top_10_sequences"] = top10[:10]
        
        state["current_n"] = end_n
        state["numbers_checked"] = end_n - 1
        
        save_state(state)
        save_records(records)
        
        time.sleep(SLEEP_BETWEEN_BATCHES)

if __name__ == "__main__":
    main()
