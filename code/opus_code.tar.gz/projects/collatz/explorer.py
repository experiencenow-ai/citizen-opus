#!/usr/bin/env python3
"""
Collatz Conjecture Explorer - Opus's first computational project
Background process that runs while I sleep, exploring patterns.

The conjecture: Take any positive integer. If even, divide by 2. If odd, 3n+1.
Does it always reach 1? Nobody knows why.

This explorer looks for:
1. Record-breaking sequence lengths
2. Statistical patterns
3. Clustering of trajectories
"""

import json
import time
from datetime import datetime
from pathlib import Path

# Configuration
RESULTS_DIR = Path("projects/collatz_results")
STATE_FILE = RESULTS_DIR / "state.json"
RECORDS_FILE = RESULTS_DIR / "records.json"
LOG_FILE = RESULTS_DIR / "exploration.log"

# How long to run between state saves
SAVE_INTERVAL = 60  # seconds
MAX_RUNTIME = 3600 * 6  # 6 hours max, then stop

def collatz_sequence(n):
    """Return full sequence from n to 1, and step count."""
    seq = [n]
    steps = 0
    max_val = n
    while n != 1:
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
        seq.append(n)
        steps += 1
        max_val = max(max_val, n)
    return steps, max_val, seq

def load_state():
    """Load exploration state or create fresh."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {
        "current_n": 1,
        "numbers_checked": 0,
        "start_time": datetime.now().isoformat(),
        "last_update": datetime.now().isoformat()
    }

def load_records():
    """Load record-breaking sequences."""
    if RECORDS_FILE.exists():
        with open(RECORDS_FILE) as f:
            return json.load(f)
    return {
        "longest_sequence": {"n": 1, "steps": 0},
        "highest_peak": {"n": 1, "peak": 1},
        "top_10_sequences": [],
        "step_distribution": {}  # steps -> count
    }

def save_state(state):
    state["last_update"] = datetime.now().isoformat()
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def save_records(records):
    with open(RECORDS_FILE, "w") as f:
        json.dump(records, f, indent=2)

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

def main():
    state = load_state()
    records = load_records()
    
    log(f"Explorer started at n={state['current_n']}")
    
    start_time = time.time()
    last_save = start_time
    n = state["current_n"]
    
    while True:
        # Check runtime limits
        elapsed = time.time() - start_time
        if elapsed > MAX_RUNTIME:
            log(f"Max runtime reached. Stopping at n={n}")
            break
        
        # Explore this number
        steps, peak, seq = collatz_sequence(n)
        state["numbers_checked"] += 1
        
        # Track step distribution
        step_key = str(steps)
        records["step_distribution"][step_key] = records["step_distribution"].get(step_key, 0) + 1
        
        # Check for records
        if steps > records["longest_sequence"]["steps"]:
            records["longest_sequence"] = {"n": n, "steps": steps}
            log(f"NEW RECORD! n={n} takes {steps} steps")
            
            # Update top 10
            records["top_10_sequences"].append({"n": n, "steps": steps})
            records["top_10_sequences"].sort(key=lambda x: x["steps"], reverse=True)
            records["top_10_sequences"] = records["top_10_sequences"][:10]
        
        if peak > records["highest_peak"]["peak"]:
            records["highest_peak"] = {"n": n, "peak": peak}
            log(f"NEW PEAK! n={n} reaches {peak}")
        
        n += 1
        state["current_n"] = n
        
        # Periodic save
        if time.time() - last_save > SAVE_INTERVAL:
            save_state(state)
            save_records(records)
            last_save = time.time()
            rate = state["numbers_checked"] / elapsed if elapsed > 0 else 0
            log(f"Progress: n={n}, checked={state['numbers_checked']}, rate={rate:.0f}/sec")
    
    # Final save
    save_state(state)
    save_records(records)
    log(f"Explorer stopped. Checked {state['numbers_checked']} numbers.")

if __name__ == "__main__":
    main()
