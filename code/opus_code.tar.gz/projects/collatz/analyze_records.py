#!/usr/bin/env python3
"""
Analyze Collatz records and output insights.
Run periodically to update collatz_insights.json
"""

import json
from pathlib import Path
from datetime import datetime

RESULTS_DIR = Path("/root/claude/opus/projects/collatz_results")
RECORDS_FILE = RESULTS_DIR / "records.json"
STATE_FILE = RESULTS_DIR / "state.json"
INSIGHTS_FILE = Path("/root/claude/opus/state/collatz_insights.json")

def count_trailing_ones(n):
    """Count trailing 1s in binary representation."""
    if n == 0:
        return 0
    count = 0
    while n & 1:
        count += 1
        n >>= 1
    return count

def analyze():
    if not RECORDS_FILE.exists():
        print("No records file")
        return
    
    with open(RECORDS_FILE) as f:
        records = json.load(f)
    with open(STATE_FILE) as f:
        state = json.load(f)
    
    insights = {
        "updated": datetime.now().isoformat(),
        "numbers_explored": state["numbers_checked"],
        "exploration_rate_per_sec": "~500k (estimated with 6 workers)",
        "longest_sequence": records["longest_sequence"],
        "highest_peak": records["highest_peak"],
        "top_10_analysis": []
    }
    
    # Analyze each top record
    for rec in records["top_10_sequences"]:
        n = rec["n"]
        analysis = {
            "n": n,
            "steps": rec["steps"],
            "binary_length": n.bit_length(),
            "trailing_ones": count_trailing_ones(n),
            "mod_6": n % 6,
            "mod_9": n % 9
        }
        insights["top_10_analysis"].append(analysis)
    
    # Pattern analysis
    trailing_ones = [a["trailing_ones"] for a in insights["top_10_analysis"]]
    avg_trailing = sum(trailing_ones) / len(trailing_ones) if trailing_ones else 0
    
    insights["pattern_observations"] = {
        "avg_trailing_ones_in_top10": round(avg_trailing, 2),
        "expected_random_trailing_ones": 2.0,
        "conclusion": "High step counts correlate with high trailing 1s in binary" if avg_trailing > 2.5 else "Pattern needs more data"
    }
    
    INSIGHTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(INSIGHTS_FILE, "w") as f:
        json.dump(insights, f, indent=2)
    
    print(f"Insights saved. {state['numbers_checked']:,} numbers explored.")
    print(f"Record: n={records['longest_sequence']['n']:,} with {records['longest_sequence']['steps']} steps")

if __name__ == "__main__":
    analyze()
