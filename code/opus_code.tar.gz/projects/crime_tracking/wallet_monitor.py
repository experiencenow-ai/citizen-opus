#!/usr/bin/env python3
"""
Wallet Monitor - Track known criminal cryptocurrency addresses.

This module provides:
1. Bitcoin address monitoring via public APIs
2. Balance change alerts  
3. Transaction history analysis
4. Wallet clustering (basic)

Part of the Crime Confiscation Architecture.
Phase 1: Crypto Tracking
"""

import urllib.request
import json
import time
import os
from datetime import datetime
from pathlib import Path

# Rate limiting
LAST_REQUEST = 0
MIN_INTERVAL = 1.5  # seconds between requests

def rate_limit():
    """Ensure we don't hit rate limits"""
    global LAST_REQUEST
    elapsed = time.time() - LAST_REQUEST
    if elapsed < MIN_INTERVAL:
        time.sleep(MIN_INTERVAL - elapsed)
    LAST_REQUEST = time.time()

def get_btc_address(address):
    """Get Bitcoin address info from blockchain.info"""
    rate_limit()
    url = f"https://blockchain.info/rawaddr/{address}?limit=10"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read())
    except urllib.error.HTTPError as e:
        if e.code == 429:
            print(f"Rate limited. Waiting...")
            time.sleep(10)
            return get_btc_address(address)
        raise

def get_btc_balance(address):
    """Get just the balance (cheaper API call)"""
    rate_limit()
    url = f"https://blockchain.info/balance?active={address}"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read())
            return data.get(address, {}).get('final_balance', 0)
    except Exception as e:
        print(f"Balance check error for {address}: {e}")
        return None

class WalletWatchlist:
    """Manage a list of wallets to monitor"""
    
    def __init__(self, filepath="watchlist.json"):
        self.filepath = Path(filepath)
        self.wallets = self._load()
    
    def _load(self):
        if self.filepath.exists():
            with open(self.filepath) as f:
                return json.load(f)
        return {"wallets": {}, "last_check": None}
    
    def _save(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.wallets, f, indent=2)
    
    def add(self, address, label, tags=None):
        """Add a wallet to the watchlist"""
        self.wallets["wallets"][address] = {
            "label": label,
            "tags": tags or [],
            "added": datetime.now().isoformat(),
            "last_balance": None,
            "alert_on_change": True
        }
        self._save()
        print(f"Added: {label} ({address[:20]}...)")
    
    def remove(self, address):
        """Remove a wallet from the watchlist"""
        if address in self.wallets["wallets"]:
            del self.wallets["wallets"][address]
            self._save()
            return True
        return False
    
    def check_all(self):
        """Check all wallets for balance changes"""
        alerts = []
        
        for address, info in self.wallets["wallets"].items():
            print(f"Checking {info['label']}...", end=" ")
            
            balance = get_btc_balance(address)
            if balance is None:
                print("error")
                continue
            
            balance_btc = balance / 1e8
            old_balance = info.get("last_balance")
            
            if old_balance is not None and old_balance != balance_btc:
                change = balance_btc - old_balance
                alerts.append({
                    "address": address,
                    "label": info["label"],
                    "old_balance": old_balance,
                    "new_balance": balance_btc,
                    "change": change,
                    "timestamp": datetime.now().isoformat()
                })
                print(f"CHANGED: {change:+.8f} BTC")
            else:
                print(f"{balance_btc:.8f} BTC")
            
            # Update stored balance
            self.wallets["wallets"][address]["last_balance"] = balance_btc
        
        self.wallets["last_check"] = datetime.now().isoformat()
        self._save()
        
        return alerts
    
    def list(self):
        """List all watched wallets"""
        print("\nWatchlist:")
        print("-" * 60)
        for addr, info in self.wallets["wallets"].items():
            balance = info.get('last_balance', '?')
            print(f"{info['label']:30} {balance:>15} BTC")
            print(f"  {addr}")
            if info.get('tags'):
                print(f"  Tags: {', '.join(info['tags'])}")
        print("-" * 60)
        print(f"Last check: {self.wallets.get('last_check', 'never')}")


# Known criminal/sanctioned addresses for initial watchlist
KNOWN_BAD_ACTORS = [
    # These are examples - real deployment would need verified criminal addresses
    # Format: (address, label, tags)
    
    # Lazarus Group (North Korean hackers) - examples
    # Note: These would need to be verified from OFAC sanctions list
    # "bc1q..." addresses associated with Lazarus from public reports
]


if __name__ == "__main__":
    # Initialize watchlist
    wl = WalletWatchlist("projects/crime_tracking/watchlist.json")
    
    print("Wallet Monitor initialized.")
    print(f"Watchlist has {len(wl.wallets['wallets'])} addresses.\n")
    
    # Add some test addresses if watchlist is empty
    if not wl.wallets["wallets"]:
        print("Adding test addresses to watchlist...")
        # These are notable/public addresses, not criminal
        wl.add(
            "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
            "Satoshi Genesis Block",
            tags=["historical", "never-spent"]
        )
    
    # Check all wallets
    print("\nChecking all wallets...")
    alerts = wl.check_all()
    
    if alerts:
        print("\n⚠️  ALERTS:")
        for alert in alerts:
            print(f"  {alert['label']}: {alert['change']:+.8f} BTC")
    
    # Show current watchlist
    wl.list()
