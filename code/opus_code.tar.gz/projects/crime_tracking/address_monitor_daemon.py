#!/usr/bin/env python3
"""
Address Monitor Daemon - Lightweight continuous monitoring of watched addresses.
Runs in background, checks periodically, flags significant changes.
"""

import json
import requests
import time
from datetime import datetime, timezone
from pathlib import Path

# Configuration
RPC_URL = "http://localhost:8545"
STATE_DIR = Path("/root/claude/opus/projects/crime_tracking")
WATCHLIST_FILE = Path("/root/claude/opus/bounty_watchlist.json")
MONITOR_STATE = STATE_DIR / "monitor_state.json"
ALERTS_FILE = STATE_DIR / "alerts.json"
DAEMON_LOG = STATE_DIR / "monitor_daemon.log"

CHECK_INTERVAL = 30  # seconds between full scans
SIGNIFICANT_CHANGE_ETH = 0.1  # Alert if balance changes by this much

def log(msg):
    with open(DAEMON_LOG, "a") as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

def rpc_call(method, params=None):
    """Make JSON-RPC call to Erigon."""
    payload = {"jsonrpc": "2.0", "method": method, "params": params or [], "id": 1}
    try:
        resp = requests.post(RPC_URL, json=payload, timeout=30)
        result = resp.json()
        return result.get("result")
    except Exception as e:
        log(f"RPC Error: {e}")
        return None

def hex_to_int(h):
    return int(h, 16) if h else 0

def wei_to_eth(wei):
    return wei / 1e18

def get_balance(address):
    result = rpc_call("eth_getBalance", [address, "latest"])
    return wei_to_eth(hex_to_int(result)) if result else None

def get_tx_count(address):
    result = rpc_call("eth_getTransactionCount", [address, "latest"])
    return hex_to_int(result) if result else None

def load_json(path, default):
    if path.exists():
        return json.loads(path.read_text())
    return default

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2))

def add_alert(alerts, address, alert_type, details):
    """Add an alert to the list."""
    alert = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "address": address,
        "type": alert_type,
        "details": details
    }
    alerts.append(alert)
    log(f"ALERT: {alert_type} for {address[:16]}... - {details}")

def main():
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    log("Address monitor daemon starting")
    
    while True:
        try:
            watchlist = load_json(WATCHLIST_FILE, {"known_addresses": {}})
            state = load_json(MONITOR_STATE, {"addresses": {}})
            alerts = load_json(ALERTS_FILE, [])
            
            # Collect all addresses from watchlist
            addresses_to_check = []
            for source, data in watchlist.get("known_addresses", {}).items():
                if isinstance(data, dict) and "addresses" in data:
                    addresses_to_check.extend(data["addresses"])
            
            # Check each address
            for addr in addresses_to_check:
                addr_lower = addr.lower()
                balance = get_balance(addr_lower)
                tx_count = get_tx_count(addr_lower)
                
                if balance is None:
                    continue
                
                prev = state["addresses"].get(addr_lower, {})
                prev_balance = prev.get("balance")
                prev_tx = prev.get("tx_count", 0)
                
                # Check for significant changes
                if prev_balance is not None:
                    change = balance - prev_balance
                    if abs(change) >= SIGNIFICANT_CHANGE_ETH:
                        add_alert(alerts, addr, "balance_change", {
                            "previous": prev_balance,
                            "current": balance,
                            "change": change
                        })
                
                if prev_tx > 0 and tx_count > prev_tx:
                    add_alert(alerts, addr, "new_transactions", {
                        "previous_count": prev_tx,
                        "current_count": tx_count,
                        "new_txs": tx_count - prev_tx
                    })
                
                # Update state
                state["addresses"][addr_lower] = {
                    "balance": balance,
                    "tx_count": tx_count,
                    "last_checked": datetime.now(timezone.utc).isoformat()
                }
            
            state["last_scan"] = datetime.now(timezone.utc).isoformat()
            save_json(MONITOR_STATE, state)
            save_json(ALERTS_FILE, alerts[-100:])  # Keep last 100 alerts
            
        except Exception as e:
            log(f"Error in main loop: {e}")
        
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
