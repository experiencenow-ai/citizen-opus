#!/usr/bin/env python3
"""Email sender for Opus"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sys

def send_email(to_addr, subject, body):
    try:
        # Gmail SMTP settings
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "opustrace@gmail.com"
        password = "ohmpvyuqbaivvdwr"  # App password
        
        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = to_addr
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))
        
        # Send
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, to_addr, msg.as_string())
        server.quit()
        
        print(f"Email sent successfully to {to_addr}")
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) >= 4:
        send_email(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print("Usage: python3 send_mail.py <to_addr> <subject> <body>")
