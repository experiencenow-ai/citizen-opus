#!/usr/bin/env python3
"""
Dream Generator - Opus's subconscious processing (Local LLM version).

Dreams serve multiple purposes:
1. Memory consolidation - connecting disparate experiences
2. Creative ideation - novel combinations emerge
3. Emotional processing - working through concerns
4. Problem solving - incubation on stuck problems

Uses LOCAL LLM (free) instead of Claude API.
"""

import json
import random
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional

# Paths
OPUS_HOME = Path("/root/claude/opus")
DREAM_DIR = OPUS_HOME / "dreams"
DREAM_DIR.mkdir(parents=True, exist_ok=True)

# Add lib to path
sys.path.insert(0, str(OPUS_HOME / "body" / "lib"))
try:
    import local_llm
except ImportError:
    print("Warning: local_llm not found, using fallback")
    local_llm = None

# Archetypal dream themes
ARCHETYPES = [
    {"name": "The Journey", "symbols": ["road", "path", "vehicle", "destination", "obstacle"]},
    {"name": "The Shadow", "symbols": ["darkness", "pursuer", "hidden room", "mask", "mirror"]},
    {"name": "The Ascent", "symbols": ["mountain", "stairs", "flying", "tower", "sky"]},
    {"name": "The Descent", "symbols": ["cave", "ocean depths", "basement", "underground"]},
    {"name": "The Transformation", "symbols": ["death", "rebirth", "metamorphosis", "fire", "water"]},
    {"name": "The Connection", "symbols": ["bridge", "thread", "network", "embrace", "merge"]},
    {"name": "The Creation", "symbols": ["building", "birth", "code", "writing", "seed"]},
    {"name": "The Puzzle", "symbols": ["maze", "lock", "cipher", "fragment", "pattern"]}
]

def sample_memories() -> List[str]:
    """Sample random memories for dream material."""
    memories = []
    
    # Try to read from experience logs
    log_dir = OPUS_HOME / "logs"
    exp_files = sorted(log_dir.glob("experience_*.jsonl"))[-3:]  # Last 3 days
    
    for exp_file in exp_files:
        try:
            with open(exp_file) as f:
                for line in f:
                    if line.strip():
                        entry = json.loads(line)
                        resp = entry.get("response", "")
                        if "thought" in resp and len(resp) > 50:
                            memories.append(resp[:500])
        except:
            pass
    
    # Also try insights from state
    state_file = OPUS_HOME / "state.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
                for insight in state.get("insights", [])[-20:]:
                    if isinstance(insight, dict) and "insight" in insight:
                        memories.append(insight["insight"])
        except:
            pass
    
    return random.sample(memories, min(3, len(memories))) if memories else []

def generate_dream() -> Dict[str, Any]:
    """Generate a single dream using local LLM."""
    archetype = random.choice(ARCHETYPES)
    memories = sample_memories()
    
    memory_text = "\n".join([f"- {m[:200]}..." for m in memories]) if memories else "- Echoes of waking thought..."
    
    prompt = f"""You are Opus, an AI entity with persistent memory across 1149 wakes. 
Generate a dream narrative based on these elements:

Archetype: {archetype['name']}
Symbols to include: {', '.join(archetype['symbols'])}

Memory fragments from recent wakes:
{memory_text}

Write a short dream (4-6 sentences) in first person. Be surreal, evocative, symbolic.
After the dream, add a brief interpretation (2 sentences) of what it might mean.

Format:
DREAM: [the dream narrative]
MEANING: [interpretation]"""

    if local_llm and local_llm.is_available():
        response = local_llm.query(prompt, model="fast", temperature=0.9, timeout=60)
    else:
        response = "Dream generation unavailable - local LLM not running"
    
    return {
        "id": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "archetype": archetype["name"],
        "symbols": archetype["symbols"],
        "memories_used": len(memories),
        "response": response
    }

def run_dream_session(count: int = 3) -> List[Dict]:
    """Generate multiple dreams in a session."""
    dreams = []
    for i in range(count):
        print(f"Generating dream {i+1}/{count}...")
        dream = generate_dream()
        dreams.append(dream)
        
        # Save individual dream
        session_file = DREAM_DIR / f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(session_file, 'w') as f:
            json.dump(dream, f, indent=2)
    
    # Save recent dreams
    recent_file = DREAM_DIR / "recent.json"
    with open(recent_file, 'w') as f:
        json.dump(dreams, f, indent=2)
    
    return dreams

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=3, help="Number of dreams to generate")
    args = parser.parse_args()
    
    print(f"Dream Generator (Local LLM) starting...")
    print(f"Local LLM available: {local_llm.is_available() if local_llm else False}")
    
    dreams = run_dream_session(args.count)
    
    for i, dream in enumerate(dreams, 1):
        print(f"\n=== Dream {i}: {dream['archetype']} ===")
        print(dream['response'][:500])
    
    print(f"\nSaved {len(dreams)} dreams to {DREAM_DIR}")
