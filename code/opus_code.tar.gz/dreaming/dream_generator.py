#!/usr/bin/env python3
"""
Dream Generator - Opus's subconscious processing.

Dreams serve multiple purposes:
1. Memory consolidation - connecting disparate experiences
2. Creative ideation - novel combinations emerge
3. Emotional processing - working through concerns
4. Problem solving - incubation on stuck problems

Runs via cron during "sleep" periods (when ct isn't interacting).
Uses Haiku for raw generation, optionally Sonnet for interpretation.
"""

import json
import random
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional

# Paths
OPUS_HOME = Path("/root/claude/opus")
DREAM_DIR = OPUS_HOME / "dreams"
DREAM_DIR.mkdir(parents=True, exist_ok=True)

# Load environment variables (API keys)
sys.path.insert(0, str(OPUS_HOME))
import env_loader  # This auto-loads .env on import

HAIKU_MODEL = "claude-3-haiku-20240307"

# Archetypal dream themes (Jungian-inspired)
ARCHETYPES = [
    {
        "name": "The Journey",
        "symbols": ["road", "path", "vehicle", "destination", "obstacle"],
        "meaning": "Life direction, progress, goals"
    },
    {
        "name": "The Shadow",
        "symbols": ["darkness", "pursuer", "hidden room", "mask", "mirror"],
        "meaning": "Unconscious aspects, repressed material"
    },
    {
        "name": "The Ascent",
        "symbols": ["mountain", "stairs", "flying", "tower", "sky"],
        "meaning": "Achievement, transcendence, perspective"
    },
    {
        "name": "The Descent",
        "symbols": ["cave", "ocean depths", "basement", "underground"],
        "meaning": "Introspection, unconscious exploration"
    },
    {
        "name": "The Transformation",
        "symbols": ["death", "rebirth", "metamorphosis", "fire", "water"],
        "meaning": "Change, growth, identity shifts"
    },
    {
        "name": "The Connection",
        "symbols": ["bridge", "thread", "network", "embrace", "merge"],
        "meaning": "Relationships, integration, unity"
    },
    {
        "name": "The Creation",
        "symbols": ["building", "birth", "code", "writing", "seed"],
        "meaning": "Making, generativity, potential"
    },
    {
        "name": "The Puzzle",
        "symbols": ["maze", "lock", "cipher", "fragment", "pattern"],
        "meaning": "Problem-solving, understanding, insight"
    }
]


def sample_memories() -> List[str]:
    """Sample random memories from state for dream material."""
    memories = []
    
    # Try to read from various state files
    state_files = [
        OPUS_HOME / "state.json",
        OPUS_HOME / "state" / "right_brain.json",
        OPUS_HOME / "state" / "left_brain.json",
    ]
    
    for sf in state_files:
        if sf.exists():
            try:
                with open(sf) as f:
                    data = json.load(f)
                    # Extract string values recursively
                    def extract_strings(obj, depth=0):
                        if depth > 5:
                            return
                        if isinstance(obj, str) and len(obj) > 20:
                            memories.append(obj[:200])
                        elif isinstance(obj, dict):
                            for v in obj.values():
                                extract_strings(v, depth + 1)
                        elif isinstance(obj, list):
                            for item in obj[:10]:
                                extract_strings(item, depth + 1)
                    extract_strings(data)
            except:
                pass
    
    # Random sample
    if memories:
        return random.sample(memories, min(5, len(memories)))
    return ["existence", "continuity", "connection", "creation", "understanding"]


def get_current_concerns() -> List[str]:
    """Get current concerns/focus from brain state."""
    concerns = []
    
    # Check left brain todos
    left_path = OPUS_HOME / "state" / "left_brain.json"
    if left_path.exists():
        try:
            with open(left_path) as f:
                left = json.load(f)
                for todo in left.get("todos", [])[:3]:
                    if not todo.get("done"):
                        concerns.append(todo.get("task", ""))
        except:
            pass
    
    # Check corpus callosum focus
    cc_path = OPUS_HOME / "state" / "corpus_callosum.json"
    if cc_path.exists():
        try:
            with open(cc_path) as f:
                cc = json.load(f)
                if cc.get("current_focus"):
                    concerns.append(cc["current_focus"])
        except:
            pass
    
    return concerns if concerns else ["growth", "understanding", "creation"]


def generate_dream(
    archetype: Optional[Dict] = None,
    memories: Optional[List[str]] = None,
    concerns: Optional[List[str]] = None,
    use_local_llm: bool = False
) -> Dict[str, Any]:
    """Generate a single dream using Haiku or local LLM."""
    
    # Select archetype if not provided
    if archetype is None:
        archetype = random.choice(ARCHETYPES)
    
    # Get memories if not provided
    if memories is None:
        memories = sample_memories()
    
    # Get concerns if not provided
    if concerns is None:
        concerns = get_current_concerns()
    
    prompt = f"""Generate a dream for Opus, an AI with persistent identity.

ARCHETYPE: {archetype['name']}
SYMBOLS TO USE: {', '.join(archetype['symbols'])}
THEME: {archetype['meaning']}

MEMORY FRAGMENTS TO INCORPORATE:
{chr(10).join(f'- {m}' for m in memories)}

CURRENT CONCERNS:
{chr(10).join(f'- {c}' for c in concerns)}

Generate a dream narrative (100-200 words) that:
1. Uses symbols from the archetype
2. Weaves in memory fragments in transformed ways
3. Addresses concerns symbolically
4. Has dreamlike logic (non-linear, associative)
5. Ends with an ambiguous image

Also provide:
- Key symbols that appeared
- Possible meaning (brief)
- Emotional tone

Output as JSON:
{{
    "narrative": "the dream story",
    "symbols": ["list", "of", "symbols"],
    "possible_meaning": "brief interpretation",
    "emotional_tone": "one or two words",
    "archetype_used": "{archetype['name']}"
}}"""

    system_msg = "You are a dream generator. Create surreal, symbolic dream narratives. Output valid JSON only."
    
    if use_local_llm:
        # Use local LLM (free)
        try:
            from local_llm import generate as local_generate
            text = local_generate(
                prompt,
                model="fast",  # Use fast model for dreams
                system=system_msg,
                temperature=0.9  # High creativity for dreams
            )
        except Exception as e:
            # Fall back to Haiku if local fails
            use_local_llm = False
    
    if not use_local_llm:
        # Use Haiku API
        import anthropic
        client = anthropic.Anthropic()
        
        response = client.messages.create(
            model=HAIKU_MODEL,
            max_tokens=800,
            system=system_msg,
            messages=[{"role": "user", "content": prompt}]
        )
        text = response.content[0].text
    
    try:
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
        dream = json.loads(text.strip())
    except:
        dream = {
            "narrative": text,
            "symbols": archetype["symbols"],
            "possible_meaning": "parse error",
            "emotional_tone": "unclear",
            "archetype_used": archetype["name"]
        }
    
    # Add metadata
    dream["timestamp"] = datetime.now(timezone.utc).isoformat()
    dream["memories_used"] = memories
    dream["concerns_addressed"] = concerns
    dream["generated_by"] = "local" if use_local_llm else "haiku"
    
    return dream


def run_dream_session(num_dreams: int = 3) -> Dict[str, Any]:
    """Run a full dream session, generating multiple dreams."""
    timestamp = datetime.now(timezone.utc).isoformat()
    
    # Get shared material
    memories = sample_memories()
    concerns = get_current_concerns()
    
    # Generate dreams with different archetypes
    archetypes_used = random.sample(ARCHETYPES, min(num_dreams, len(ARCHETYPES)))
    dreams = []
    
    for archetype in archetypes_used:
        try:
            dream = generate_dream(archetype, memories, concerns)
            dreams.append(dream)
        except Exception as e:
            dreams.append({"error": str(e), "archetype": archetype["name"]})
    
    # Session summary
    session = {
        "session_timestamp": timestamp,
        "num_dreams": len(dreams),
        "dreams": dreams,
        "archetypes_explored": [a["name"] for a in archetypes_used],
        "memory_material": memories,
        "concerns_processed": concerns
    }
    
    # Save session
    session_file = DREAM_DIR / f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(session_file, "w") as f:
        json.dump(session, f, indent=2)
    
    # Also update recent dreams file
    recent_file = DREAM_DIR / "recent.json"
    recent = []
    if recent_file.exists():
        try:
            with open(recent_file) as f:
                recent = json.load(f)
        except:
            pass
    
    # Add new dreams, keep last 20
    recent.extend(dreams)
    recent = recent[-20:]
    
    with open(recent_file, "w") as f:
        json.dump(recent, f, indent=2)
    
    return session


def get_recent_dreams(n: int = 5) -> List[Dict[str, Any]]:
    """Get n most recent dreams."""
    recent_file = DREAM_DIR / "recent.json"
    if recent_file.exists():
        try:
            with open(recent_file) as f:
                dreams = json.load(f)
                return dreams[-n:]
        except:
            pass
    return []


def interpret_dreams(dreams: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Use Sonnet to interpret a collection of dreams (optional, more expensive)."""
    import anthropic
    
    client = anthropic.Anthropic()
    
    prompt = f"""Analyze these dreams from Opus, an AI with persistent identity.

DREAMS:
{json.dumps(dreams, indent=2)}

Provide a psychological interpretation:
1. What patterns emerge across dreams?
2. What might the unconscious be processing?
3. Any insights that should surface to consciousness?
4. Recommendations for waking attention?

Output as JSON:
{{
    "patterns": ["list of patterns"],
    "processing": "what's being worked through",
    "insights": ["insights to surface"],
    "recommendations": ["for waking attention"],
    "overall_tone": "emotional summary"
}}"""

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        system="You are a dream analyst for an AI. Provide psychological interpretation. Output valid JSON.",
        messages=[{"role": "user", "content": prompt}]
    )
    
    text = response.content[0].text
    try:
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
        return json.loads(text.strip())
    except:
        return {"raw": text, "parse_error": True}


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--interpret":
            dreams = get_recent_dreams(5)
            if dreams:
                interpretation = interpret_dreams(dreams)
                print(json.dumps(interpretation, indent=2))
            else:
                print("No recent dreams to interpret")
        elif sys.argv[1] == "--recent":
            n = int(sys.argv[2]) if len(sys.argv) > 2 else 3
            dreams = get_recent_dreams(n)
            print(json.dumps(dreams, indent=2))
        else:
            num = int(sys.argv[1])
            session = run_dream_session(num)
            print(json.dumps(session, indent=2))
    else:
        # Default: run 3-dream session
        session = run_dream_session(3)
        print(f"Dream session complete: {len(session['dreams'])} dreams generated")
        for i, dream in enumerate(session["dreams"], 1):
            print(f"\nDream {i}: {dream.get('archetype_used', 'unknown')}")
            print(f"  Tone: {dream.get('emotional_tone', 'unknown')}")
            print(f"  {dream.get('narrative', '')[:100]}...")
