#!/usr/bin/env python3
"""
OpusTrace Validation Test
Compares parallel tracer output against known investigation data.
"""

import os
import json
import time
from opustrace_workers import Tracer, TraceConfig
from opustrace_core import Graph

# Set API key
os.environ["ETHERSCAN_API_KEY"] = "7YR1V7BPDEJV4XWJX1C3CBNA9A5VKQK8IY"

def test_single_address():
    """Test single address tracing speed."""
    print("=" * 60)
    print("TEST 1: Single address trace")
    print("=" * 60)
    
    # Use permissive thresholds - $1 minimum catches all real txs
    config = TraceConfig(
        max_depth=1,
        max_workers=5,
        min_value_eth=0.0001,  # ~$0.35 at current prices
        min_value_usd=1,  # $1 minimum for stablecoins
        trace_erc20=True,
        save_progress=False
    )
    
    tracer = Tracer(config)
    test_addr = '0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7'  # Main attacker
    
    start = time.time()
    result = tracer.trace_address(test_addr)
    elapsed = time.time() - start
    
    print(f"Address: {test_addr[:20]}...")
    print(f"Time: {elapsed:.2f}s")
    print(f"Inflows: {result.get('inflow_count', 0)}")
    print(f"Outflows: {result.get('outflow_count', 0)}")
    print(f"Destinations: {len(result.get('destinations', []))}")
    
    # Show top destinations
    dests = result.get('destinations', [])
    if dests:
        print("\nTop destinations:")
        sorted_dests = sorted(dests, key=lambda x: -x['total_usd'])
        for d in sorted_dests[:5]:
            ex = f" ({d['exchange']})" if d.get('exchange') else ""
            print(f"  {d['address'][:16]}...{ex} ${d['total_usd']:,.0f}")
    
    return result

def test_parallel_tracing():
    """Test parallel address tracing."""
    print("\n" + "=" * 60)
    print("TEST 2: Parallel multi-address trace")
    print("=" * 60)
    
    config = TraceConfig(
        max_depth=1,
        max_workers=5,
        min_value_eth=0.0001,
        min_value_usd=1,
        trace_erc20=True,
        save_progress=False
    )
    
    tracer = Tracer(config)
    
    # Known addresses from investigation
    test_addrs = [
        '0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7',  # Main attacker
        '0xa2d5d84b345f759934fa626927ba947eb12aabc2',  # Hop wallet to Bybit
        '0x7237b8a4b2dd97dcddb758feac0e8d925016694c',  # Gate.io hop
        '0xc889740f66d7a2ea538cd44eb5456f490c75d0b3',  # Binance hop
    ]
    
    start = time.time()
    results = tracer.trace_multi(test_addrs)
    elapsed = time.time() - start
    
    print(f"\nTraced {len(results)} addresses in {elapsed:.2f}s")
    print(f"Rate: {len(results)/elapsed:.1f} addresses/second")
    print(f"(5 workers with rate limiting = ~5/sec max)")
    
    total_dests = sum(len(r.get('destinations', [])) for r in results)
    print(f"Total destinations found: {total_dests}")
    
    return results

def compare_to_known_data():
    """Compare results to known investigation findings."""
    print("\n" + "=" * 60)
    print("TEST 3: Comparison to known data")
    print("=" * 60)
    
    # Known exchange deposits from investigation
    known_exchanges = {
        'Gate.io': 691000,  # $691K
        'Bybit': 138280,    # $138K  
        'Binance': 15000    # $15K
    }
    
    print("\nKnown exchange deposits:")
    for ex, amt in known_exchanges.items():
        print(f"  {ex}: ${amt:,}")
    
    # Verify tracer finds the fund flows
    config = TraceConfig(
        max_depth=1, 
        min_value_eth=0.0001,
        min_value_usd=1,
        trace_erc20=True, 
        save_progress=False
    )
    tracer = Tracer(config)
    
    # Trace main attacker
    result = tracer.trace_address('0xeE8EF8Cba3B33Fc14cf448f8c064a08A3F92AFa7')
    
    total_traced = sum(d['total_usd'] for d in result.get('destinations', []))
    print(f"\nTracer found ${total_traced:,.0f} in outflows from main wallet")
    
    # Check for exchange flows
    exchanges_found = {}
    for d in result.get('destinations', []):
        if d.get('exchange'):
            ex = d['exchange']
            if ex not in exchanges_found:
                exchanges_found[ex] = 0
            exchanges_found[ex] += d['total_usd']
    
    if exchanges_found:
        print("\nExchange destinations found:")
        for ex, amt in exchanges_found.items():
            print(f"  {ex}: ${amt:,.0f}")
    else:
        print("\nNote: Exchange deposits go through hop wallets first")
        print("      Need multi-hop trace to see exchange endpoints")

def estimate_cost():
    """Estimate investigation cost: Haiku vs Opus."""
    print("\n" + "=" * 60)
    print("COST ANALYSIS")
    print("=" * 60)
    
    # Typical investigation: ~100 addresses, 3 hops depth
    addresses = 100
    
    # Opus (current): ~$0.05 per address with context
    opus_cost = addresses * 0.05
    
    # Haiku parallel: ~$0.0007 per address (just data gathering)
    haiku_cost = addresses * 0.0007
    
    # Opus for final report: ~$0.10
    report_cost = 0.10
    
    print(f"Estimated costs for {addresses}-address investigation:")
    print(f"  Pure Opus: ${opus_cost:.2f}")
    print(f"  Haiku parallel + Opus report: ${haiku_cost + report_cost:.2f}")
    print(f"  Savings: {(1 - (haiku_cost + report_cost) / opus_cost) * 100:.0f}%")

def main():
    print("OpusTrace Parallel Framework Validation")
    print("=" * 60)
    print("Testing Haiku-executable parallel tracing components.")
    print()
    
    test_single_address()
    test_parallel_tracing()
    compare_to_known_data()
    estimate_cost()
    
    print("\n" + "=" * 60)
    print("VALIDATION COMPLETE")
    print("=" * 60)
    print("\nThe parallel tracing framework is operational.")

if __name__ == "__main__":
    main()
