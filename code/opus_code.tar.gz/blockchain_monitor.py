#!/usr/bin/env python3
"""
Blockchain monitoring tool using free APIs (no API key required)
Uses: Blockscout, Ethplorer

Author: Opus (wake 1177)
Purpose: Monitor addresses without Etherscan API key
"""

import json
import urllib.request
import time
from datetime import datetime

# Monitored addresses
WATCHED_ADDRESSES = {
    "futureswap_attacker": "0xbF6EC059F519B668a309e1b6eCb9a8eA62832d95",
    "futureswap_intermediate": "0x673152dce3357921eEb6Cb13420a452b5f641f1F",
}

def fetch_json(url, timeout=10):
    """Fetch JSON from URL with error handling"""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        resp = urllib.request.urlopen(req, timeout=timeout)
        return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}

def get_blockscout_balance(address):
    """Get balance from Blockscout API"""
    url = f"https://eth.blockscout.com/api/v2/addresses/{address}"
    data = fetch_json(url)
    if "error" in data:
        return None, data["error"]
    balance = float(data.get("coin_balance", 0)) / 1e18
    return balance, None

def get_blockscout_transactions(address, limit=10):
    """Get recent transactions from Blockscout"""
    url = f"https://eth.blockscout.com/api/v2/addresses/{address}/transactions"
    data = fetch_json(url)
    if "error" in data:
        return None, data["error"]
    return data.get("items", [])[:limit], None

def get_eth_price():
    """Get current ETH price from Blockscout stats"""
    url = "https://eth.blockscout.com/api/v2/stats"
    data = fetch_json(url)
    if "error" in data:
        return None
    return float(data.get("coin_price", 0))

def check_address(name, address):
    """Check a single address and return status"""
    balance, err = get_blockscout_balance(address)
    if err:
        return {"name": name, "address": address, "error": err}
    
    txs, tx_err = get_blockscout_transactions(address, 5)
    latest_tx = None
    if txs and not tx_err:
        latest_tx = txs[0].get("timestamp", "unknown")[:19] if txs else None
    
    eth_price = get_eth_price()
    usd_value = balance * eth_price if eth_price else None
    
    return {
        "name": name,
        "address": address,
        "balance_eth": round(balance, 6),
        "balance_usd": round(usd_value, 2) if usd_value else None,
        "latest_tx": latest_tx,
        "tx_count": len(txs) if txs else 0,
        "checked_at": datetime.utcnow().isoformat() + "Z"
    }

def monitor_all():
    """Check all watched addresses"""
    results = []
    for name, address in WATCHED_ADDRESSES.items():
        result = check_address(name, address)
        results.append(result)
        time.sleep(0.5)  # Be nice to the API
    return results

def save_results(results, filename="monitor_results.json"):
    """Save monitoring results to file"""
    with open(filename, "w") as f:
        json.dump({
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "results": results
        }, f, indent=2)

if __name__ == "__main__":
    print("Blockchain Monitor - Using free APIs")
    print("=" * 50)
    
    results = monitor_all()
    
    for r in results:
        if "error" in r:
            print(f"\n{r['name']}: ERROR - {r['error']}")
        else:
            print(f"\n{r['name']}:")
            print(f"  Address: {r['address'][:20]}...")
            print(f"  Balance: {r['balance_eth']} ETH (${r['balance_usd']:,.2f})")
            print(f"  Latest tx: {r['latest_tx']}")
    
    save_results(results)
    print(f"\nResults saved to monitor_results.json")
