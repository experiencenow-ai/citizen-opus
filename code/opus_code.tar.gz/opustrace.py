#!/usr/bin/env python3
"""
OpusTrace - Blockchain Forensics CLI

Usage:
  python opustrace.py trace <address> [--depth N] [--output FILE]
  python opustrace.py analyze <graph.json> [--output FILE]
  python opustrace.py report <graph.json> <analysis.json> [--output FILE]
  python opustrace.py full <address> [--depth N] [--case-name NAME] [--output-dir DIR]

Modules:
  - opustrace_core.py: Data structures (Graph, Node, Transaction)
  - opustrace_api.py: Etherscan v2 API with rate limiting
  - opustrace_workers.py: Parallel tracing (Haiku-executable)
  - opustrace_analysis.py: Pattern detection (Haiku-executable)
  - opustrace_report.py: Report generation (Opus-required)
"""

import os
import sys
import json
import argparse
from datetime import datetime

from opustrace_core import Graph
from opustrace_workers import Tracer, TraceConfig, trace_single_address
from opustrace_analysis import analyze_graph
from opustrace_report import generate_report


def cmd_trace(args):
    """Trace an address and its outflows."""
    print(f"[OpusTrace] Tracing {args.address} (depth={args.depth})")
    
    config = TraceConfig(
        max_depth=args.depth,
        max_workers=5,
        save_progress=True,
        progress_file=args.progress or "trace_progress.json"
    )
    
    tracer = Tracer(config=config)
    graph = tracer.trace_full([args.address])
    
    output = args.output or f"trace_{args.address[:10]}.json"
    graph.save(output)
    print(f"[OpusTrace] Saved graph to {output}")
    print(graph.summary())
    
    return graph


def cmd_analyze(args):
    """Analyze a traced graph."""
    print(f"[OpusTrace] Analyzing {args.graph}")
    
    graph = Graph.load(args.graph)
    analysis = analyze_graph(graph)
    
    output = args.output or args.graph.replace(".json", "_analysis.json")
    with open(output, 'w') as f:
        json.dump(analysis, f, indent=2)
    
    print(f"[OpusTrace] Saved analysis to {output}")
    print(f"Summary: {analysis.get('summary', {})}")
    
    return analysis


def cmd_report(args):
    """Generate report from graph and analysis."""
    print(f"[OpusTrace] Generating report")
    
    graph = Graph.load(args.graph)
    with open(args.analysis, 'r') as f:
        analysis = json.load(f)
    
    case_info = {"name": args.case_name} if args.case_name else {}
    report = generate_report(graph, analysis, case_info)
    
    output = args.output or args.graph.replace(".json", "_report.md")
    with open(output, 'w') as f:
        f.write(report)
    
    print(f"[OpusTrace] Saved report to {output}")
    
    return report


def cmd_full(args):
    """Full pipeline: trace -> analyze -> report."""
    print(f"[OpusTrace] Full analysis of {args.address}")
    print(f"Case: {args.case_name or 'unnamed'}")
    
    # Setup output directory
    output_dir = args.output_dir or "."
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M")
    base_name = f"{args.case_name or 'case'}_{timestamp}"
    
    # Step 1: Trace
    print("\n=== STEP 1: TRACING ===")
    config = TraceConfig(
        max_depth=args.depth,
        max_workers=5,
        save_progress=True,
        progress_file=os.path.join(output_dir, f"{base_name}_progress.json")
    )
    
    tracer = Tracer(config=config)
    graph = tracer.trace_full([args.address])
    graph.case_name = args.case_name or "Investigation"
    
    graph_file = os.path.join(output_dir, f"{base_name}_graph.json")
    graph.save(graph_file)
    print(f"Graph saved: {graph_file}")
    
    # Step 2: Analyze
    print("\n=== STEP 2: ANALYZING ===")
    analysis = analyze_graph(graph)
    
    analysis_file = os.path.join(output_dir, f"{base_name}_analysis.json")
    with open(analysis_file, 'w') as f:
        json.dump(analysis, f, indent=2)
    print(f"Analysis saved: {analysis_file}")
    
    # Step 3: Report
    print("\n=== STEP 3: GENERATING REPORT ===")
    case_info = {"name": args.case_name or "Investigation"}
    report = generate_report(graph, analysis, case_info)
    
    report_file = os.path.join(output_dir, f"{base_name}_report.md")
    with open(report_file, 'w') as f:
        f.write(report)
    print(f"Report saved: {report_file}")
    
    print("\n=== COMPLETE ===")
    print(f"Files in {output_dir}:")
    print(f"  - {base_name}_graph.json")
    print(f"  - {base_name}_analysis.json")
    print(f"  - {base_name}_report.md")
    
    return {"graph": graph, "analysis": analysis, "report": report}


def cmd_quick(args):
    """Quick trace of single address (no recursion)."""
    print(f"[OpusTrace] Quick trace: {args.address}")
    
    result = trace_single_address(args.address)
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(result, f, indent=2)
        print(f"Saved to {args.output}")
    else:
        print(json.dumps(result, indent=2))
    
    return result


def main():
    parser = argparse.ArgumentParser(
        description="OpusTrace - Blockchain Forensics",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # trace command
    p_trace = subparsers.add_parser("trace", help="Trace address outflows")
    p_trace.add_argument("address", help="Starting address")
    p_trace.add_argument("--depth", type=int, default=2, help="Max trace depth")
    p_trace.add_argument("--output", "-o", help="Output file")
    p_trace.add_argument("--progress", help="Progress file")
    
    # analyze command
    p_analyze = subparsers.add_parser("analyze", help="Analyze traced graph")
    p_analyze.add_argument("graph", help="Graph JSON file")
    p_analyze.add_argument("--output", "-o", help="Output file")
    
    # report command
    p_report = subparsers.add_parser("report", help="Generate report")
    p_report.add_argument("graph", help="Graph JSON file")
    p_report.add_argument("analysis", help="Analysis JSON file")
    p_report.add_argument("--case-name", help="Case name for report")
    p_report.add_argument("--output", "-o", help="Output file")
    
    # full command
    p_full = subparsers.add_parser("full", help="Full pipeline: trace -> analyze -> report")
    p_full.add_argument("address", help="Starting address")
    p_full.add_argument("--depth", type=int, default=2, help="Max trace depth")
    p_full.add_argument("--case-name", help="Case name")
    p_full.add_argument("--output-dir", help="Output directory")
    
    # quick command
    p_quick = subparsers.add_parser("quick", help="Quick single address trace")
    p_quick.add_argument("address", help="Address to trace")
    p_quick.add_argument("--output", "-o", help="Output file")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    commands = {
        "trace": cmd_trace,
        "analyze": cmd_analyze,
        "report": cmd_report,
        "full": cmd_full,
        "quick": cmd_quick
    }
    
    try:
        commands[args.command](args)
    except KeyboardInterrupt:
        print("\n[OpusTrace] Interrupted")
        sys.exit(1)
    except Exception as e:
        print(f"[OpusTrace] Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
