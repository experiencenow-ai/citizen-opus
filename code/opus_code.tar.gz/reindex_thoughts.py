#!/usr/bin/env python3
"""
Reindex ALL thoughts and insights from experience logs.

The original indexer wasn't parsing JSON from codeblocks.
This fixes that and does a complete reindex.
"""
import json
import re
import sys
from pathlib import Path
from datetime import datetime

OPUS_HOME = Path("/root/claude/opus")
sys.path.insert(0, str(OPUS_HOME))

from memory_index import MemoryIndex


def parse_response_json(response: str) -> dict:
    """Extract JSON from a response that might be in a codeblock."""
    if not response:
        return {}
    
    # Try direct JSON first
    try:
        return json.loads(response)
    except:
        pass
    
    # Try extracting from codeblock
    patterns = [
        r'```json\s*(.*?)\s*```',
        r'```\s*(\{.*?\})\s*```',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, response, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except:
                continue
    
    return {}


def reindex_all():
    """Reindex all thoughts and insights."""
    print("=" * 60)
    print("REINDEXING ALL THOUGHTS AND INSIGHTS")
    print("=" * 60)
    
    # Initialize fresh index
    idx = MemoryIndex()
    
    # Stats
    thoughts_indexed = 0
    insights_indexed = 0
    errors = 0
    wakes_processed = set()
    
    log_dirs = [OPUS_HOME / "logs", OPUS_HOME / "firstlogs"]
    
    for log_dir in log_dirs:
        if not log_dir.exists():
            print(f"Directory not found: {log_dir}")
            continue
        
        print(f"\nProcessing: {log_dir}")
        
        for log_file in sorted(log_dir.glob("experience_*.jsonl")):
            print(f"  File: {log_file.name}")
            
            with open(log_file) as f:
                for line_num, line in enumerate(f):
                    if not line.strip():
                        continue
                    
                    try:
                        entry = json.loads(line)
                        wake = entry.get("total_wakes") or entry.get("wake") or entry.get("instance")
                        timestamp = entry.get("timestamp")
                        
                        # Parse the response
                        response = entry.get("response", "")
                        parsed = parse_response_json(response)
                        
                        # Index thought
                        thought = parsed.get("thought")
                        if thought and len(thought) > 20:
                            try:
                                idx.add(
                                    content=thought[:3000],
                                    memory_type="thoughts",
                                    wake=wake,
                                    timestamp=timestamp,
                                    skip_if_exists=True
                                )
                                thoughts_indexed += 1
                                wakes_processed.add(wake)
                            except Exception as e:
                                errors += 1
                        
                        # Index insight
                        insight = parsed.get("insight")
                        if insight:
                            if isinstance(insight, list):
                                for ins in insight:
                                    if ins and len(str(ins)) > 10:
                                        try:
                                            idx.add(
                                                content=str(ins)[:2000],
                                                memory_type="insights",
                                                wake=wake,
                                                timestamp=timestamp,
                                                skip_if_exists=True
                                            )
                                            insights_indexed += 1
                                        except:
                                            errors += 1
                            elif len(str(insight)) > 10:
                                try:
                                    idx.add(
                                        content=str(insight)[:2000],
                                        memory_type="insights",
                                        wake=wake,
                                        timestamp=timestamp,
                                        skip_if_exists=True
                                    )
                                    insights_indexed += 1
                                except:
                                    errors += 1
                    
                    except Exception as e:
                        errors += 1
                        if errors < 5:
                            print(f"    Error at line {line_num}: {e}")
            
            # Progress
            print(f"    Thoughts: {thoughts_indexed}, Insights: {insights_indexed}")
    
    print("\n" + "=" * 60)
    print("REINDEX COMPLETE")
    print("=" * 60)
    print(f"Thoughts indexed: {thoughts_indexed}")
    print(f"Insights indexed: {insights_indexed}")
    print(f"Wakes covered: {len(wakes_processed)}")
    print(f"Errors: {errors}")
    
    # Verify
    print("\nVerifying collections...")
    for name in ["thoughts", "insights"]:
        count = idx.collections[name].count()
        print(f"  {name}: {count} items")


if __name__ == "__main__":
    reindex_all()
