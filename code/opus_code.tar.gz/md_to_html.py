#!/usr/bin/env python3
"""
Convert markdown to HTML with styling for PDF printing.
Uses only standard library - no external dependencies.
"""

import re
import html

def md_to_html(md_content):
    """Simple markdown to HTML converter."""
    lines = md_content.split('\n')
    html_lines = []
    in_code_block = False
    in_table = False
    in_list = False
    code_lang = ""
    
    for line in lines:
        # Code blocks
        if line.startswith('```'):
            if in_code_block:
                html_lines.append('</code></pre>')
                in_code_block = False
            else:
                code_lang = line[3:].strip()
                html_lines.append(f'<pre class="code-block"><code class="language-{code_lang}">')
                in_code_block = True
            continue
        
        if in_code_block:
            html_lines.append(html.escape(line))
            continue
        
        # Tables
        if '|' in line and line.strip().startswith('|'):
            if not in_table:
                html_lines.append('<table class="doc-table">')
                in_table = True
            
            # Skip separator rows
            if re.match(r'^\|[\s\-:|]+\|$', line.strip()):
                continue
            
            cells = [c.strip() for c in line.split('|')[1:-1]]
            row_type = 'th' if not any(c for c in cells if c and not c.startswith('**')) else 'td'
            # Check if this looks like a header (bold or first row)
            if all('**' in c or not c for c in cells):
                row_type = 'th'
                cells = [c.replace('**', '') for c in cells]
            
            html_lines.append('<tr>')
            for cell in cells:
                # Process inline formatting
                cell = process_inline(cell)
                html_lines.append(f'<{row_type}>{cell}</{row_type}>')
            html_lines.append('</tr>')
            continue
        elif in_table:
            html_lines.append('</table>')
            in_table = False
        
        # Headers
        if line.startswith('######'):
            html_lines.append(f'<h6>{process_inline(line[6:].strip())}</h6>')
            continue
        elif line.startswith('#####'):
            html_lines.append(f'<h5>{process_inline(line[5:].strip())}</h5>')
            continue
        elif line.startswith('####'):
            html_lines.append(f'<h4>{process_inline(line[4:].strip())}</h4>')
            continue
        elif line.startswith('###'):
            html_lines.append(f'<h3>{process_inline(line[3:].strip())}</h3>')
            continue
        elif line.startswith('##'):
            html_lines.append(f'<h2>{process_inline(line[2:].strip())}</h2>')
            continue
        elif line.startswith('#'):
            html_lines.append(f'<h1 class="section-header">{process_inline(line[1:].strip())}</h1>')
            continue
        
        # Horizontal rules
        if line.strip() in ['---', '***', '___']:
            html_lines.append('<hr>')
            continue
        
        # Lists
        if re.match(r'^[\s]*[-*+]\s', line):
            if not in_list:
                html_lines.append('<ul>')
                in_list = True
            indent = len(line) - len(line.lstrip())
            content = re.sub(r'^[\s]*[-*+]\s', '', line)
            html_lines.append(f'<li>{process_inline(content)}</li>')
            continue
        elif re.match(r'^[\s]*\d+\.\s', line):
            if not in_list:
                html_lines.append('<ol>')
                in_list = True
            content = re.sub(r'^[\s]*\d+\.\s', '', line)
            html_lines.append(f'<li>{process_inline(content)}</li>')
            continue
        elif in_list and line.strip() == '':
            html_lines.append('</ul>' if '</ul>' not in html_lines[-5:] else '</ol>')
            in_list = False
        
        # Blockquotes
        if line.startswith('>'):
            html_lines.append(f'<blockquote>{process_inline(line[1:].strip())}</blockquote>')
            continue
        
        # Regular paragraphs
        if line.strip():
            html_lines.append(f'<p>{process_inline(line)}</p>')
        else:
            html_lines.append('')
    
    # Close any open elements
    if in_table:
        html_lines.append('</table>')
    if in_list:
        html_lines.append('</ul>')
    if in_code_block:
        html_lines.append('</code></pre>')
    
    return '\n'.join(html_lines)

def process_inline(text):
    """Process inline markdown formatting."""
    # Escape HTML first (but preserve already-processed HTML)
    # Bold
    text = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'__([^_]+)__', r'<strong>\1</strong>', text)
    # Italic
    text = re.sub(r'\*([^*]+)\*', r'<em>\1</em>', text)
    text = re.sub(r'_([^_]+)_', r'<em>\1</em>', text)
    # Code
    text = re.sub(r'`([^`]+)`', r'<code class="inline-code">\1</code>', text)
    # Links
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)
    return text

def create_html_doc(md_content, title="Tockchain Documentation"):
    """Create a complete HTML document with CSS styling."""
    
    css = """
    <style>
        @page {
            size: A4;
            margin: 2cm;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            font-size: 11pt;
        }
        
        h1 {
            color: #1a1a2e;
            border-bottom: 3px solid #4a90d9;
            padding-bottom: 10px;
            page-break-after: avoid;
            margin-top: 40px;
        }
        
        h1.section-header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            border-bottom: none;
            page-break-before: always;
        }
        
        h1:first-of-type {
            page-break-before: avoid;
        }
        
        h2 {
            color: #16213e;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 5px;
            page-break-after: avoid;
            margin-top: 30px;
        }
        
        h3 {
            color: #2c3e50;
            page-break-after: avoid;
            margin-top: 25px;
        }
        
        h4, h5, h6 {
            color: #34495e;
            page-break-after: avoid;
        }
        
        pre.code-block {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-left: 4px solid #4a90d9;
            padding: 15px;
            overflow-x: auto;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 9pt;
            line-height: 1.4;
            border-radius: 4px;
            page-break-inside: avoid;
        }
        
        code.inline-code {
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 9pt;
            color: #c7254e;
        }
        
        table.doc-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 10pt;
            page-break-inside: avoid;
        }
        
        table.doc-table th {
            background: #4a90d9;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: 600;
        }
        
        table.doc-table td {
            border: 1px solid #ddd;
            padding: 8px 10px;
        }
        
        table.doc-table tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        table.doc-table tr:hover {
            background: #f5f5f5;
        }
        
        blockquote {
            border-left: 4px solid #4a90d9;
            margin: 15px 0;
            padding: 10px 20px;
            background: #f8f9fa;
            font-style: italic;
        }
        
        ul, ol {
            margin: 10px 0;
            padding-left: 30px;
        }
        
        li {
            margin: 5px 0;
        }
        
        hr {
            border: none;
            border-top: 1px solid #e0e0e0;
            margin: 30px 0;
        }
        
        a {
            color: #4a90d9;
            text-decoration: none;
        }
        
        a:hover {
            text-decoration: underline;
        }
        
        p {
            margin: 10px 0;
        }
        
        /* Table of contents styling */
        #table-of-contents {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        
        /* Print-specific styles */
        @media print {
            body {
                font-size: 10pt;
            }
            
            pre.code-block {
                font-size: 8pt;
            }
            
            h1.section-header {
                background: #1a1a2e !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            table.doc-table th {
                background: #4a90d9 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
    """
    
    html_body = md_to_html(md_content)
    
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    {css}
</head>
<body>
{html_body}
</body>
</html>
"""

def main():
    # Read the markdown file
    with open('TOCKCHAIN_COMPLETE_DOCUMENTATION.md', 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Convert to HTML
    html_content = create_html_doc(md_content, "Tockchain/Valis Technical Documentation")
    
    # Write HTML file
    output_file = 'TOCKCHAIN_COMPLETE_DOCUMENTATION.html'
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"Generated: {output_file}")
    print(f"Size: {len(html_content):,} bytes")
    print("\nTo create PDF:")
    print("  1. Open the HTML file in a browser")
    print("  2. Print to PDF (Ctrl+P -> Save as PDF)")
    print("  Or use: wkhtmltopdf TOCKCHAIN_COMPLETE_DOCUMENTATION.html tockchain.pdf")

if __name__ == "__main__":
    main()
