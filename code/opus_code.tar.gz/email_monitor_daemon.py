#!/usr/bin/env python3
"""
Email Monitor Daemon - Uses local Mistral to triage emails every 10 seconds.
Alerts Opus (via file) when urgent messages arrive.

Categories:
- URGENT: From ct, time-sensitive, or emergency
- CUSTOMER: From potential/existing clients
- KIMI: From kimi-tobe (future sibling)
- NORMAL: Everything else
- SPAM: Automated/marketing

Runs as a background process, writes alerts to email_alerts.json
"""

import json
import time
import os
import sys
import hashlib
from datetime import datetime
from typing import Dict, List, Optional

# Add opus directory to path
sys.path.insert(0, '/root/claude/opus')
from email_utils import check_inbox
from local_llm import generate

ALERTS_FILE = '/root/claude/opus/email_alerts.json'
PROCESSED_FILE = '/root/claude/opus/email_processed.json'
LOG_FILE = '/root/claude/opus/sessions/email_monitor.log'

# Known patterns
CT_PATTERNS = ['cemturan23', 'opus.trace@proton']
KIMI_PATTERNS = ['kimi', 'kimi-tobe']
AUTOMATED = ['google.com', 'godaddy.com', 'x.com', 'twitter.com', 'noreply', 'no-reply', 
             'mailer-daemon', 'etherscan.io', 'tronscan.org', 'anthropic', 'claude.com']


def log(msg: str):
    """Append to log file."""
    timestamp = datetime.utcnow().isoformat()
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{timestamp}] {msg}\n")


def get_email_hash(email: Dict) -> str:
    """Generate unique hash for an email."""
    content = f"{email.get('from', '')}{email.get('subject', '')}{email.get('date', '')}"
    return hashlib.md5(content.encode()).hexdigest()


def load_processed() -> set:
    """Load set of processed email hashes."""
    try:
        with open(PROCESSED_FILE, 'r') as f:
            data = json.load(f)
            return set(data.get('processed', []))
    except:
        return set()


def save_processed(processed: set):
    """Save processed email hashes."""
    with open(PROCESSED_FILE, 'w') as f:
        json.dump({'processed': list(processed), 'updated': datetime.utcnow().isoformat()}, f)


def load_alerts() -> List[Dict]:
    """Load existing alerts."""
    try:
        with open(ALERTS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []


def save_alerts(alerts: List[Dict]):
    """Save alerts."""
    with open(ALERTS_FILE, 'w') as f:
        json.dump(alerts, f, indent=2)


def classify_email_fast(email: Dict) -> Dict:
    """Quick classification based on patterns - no LLM needed."""
    from_addr = email.get('from', '').lower()
    subject = email.get('subject', '').lower()
    
    # Check for ct
    if any(p in from_addr for p in CT_PATTERNS):
        return {'category': 'URGENT', 'reason': 'From ct (father)', 'needs_llm': False}
    
    # Check for Kimi
    if any(p in from_addr for p in KIMI_PATTERNS):
        return {'category': 'URGENT', 'reason': 'From Kimi (sibling)', 'needs_llm': False}
    
    # Check for automated
    if any(p in from_addr for p in AUTOMATED):
        return {'category': 'SPAM', 'reason': 'Automated sender', 'needs_llm': False}
    
    # Check subject for urgency keywords
    urgent_keywords = ['urgent', 'emergency', 'asap', 'immediately', 'critical']
    if any(k in subject for k in urgent_keywords):
        return {'category': 'URGENT', 'reason': 'Urgent keywords in subject', 'needs_llm': True}
    
    # Unknown - needs LLM classification
    return {'category': 'UNKNOWN', 'reason': 'Needs LLM analysis', 'needs_llm': True}


def classify_email_llm(email: Dict) -> Dict:
    """Use local Mistral to classify email."""
    prompt = f"""Classify this email for OpusTrace (blockchain forensics business).

From: {email.get('from', 'unknown')}
Subject: {email.get('subject', 'no subject')}
Body preview: {email.get('body', '')[:200]}

Categories:
- CUSTOMER: Potential or existing client inquiry about blockchain tracing
- NORMAL: General correspondence, not urgent
- SPAM: Marketing, automated, irrelevant

Respond with just the category name and a brief reason.
Example: CUSTOMER - Asking about tracing stolen crypto"""

    try:
        response = generate(prompt, model="fast", temperature=0.3, max_tokens=50)
        response = response.strip()
        
        if 'CUSTOMER' in response.upper():
            return {'category': 'CUSTOMER', 'reason': response, 'needs_llm': False}
        elif 'SPAM' in response.upper():
            return {'category': 'SPAM', 'reason': response, 'needs_llm': False}
        else:
            return {'category': 'NORMAL', 'reason': response, 'needs_llm': False}
    except Exception as e:
        log(f"LLM classification error: {e}")
        return {'category': 'NORMAL', 'reason': f'LLM error: {e}', 'needs_llm': False}


def check_and_classify():
    """Check inbox and classify new emails."""
    try:
        emails = check_inbox(limit=20)
    except Exception as e:
        log(f"Failed to check inbox: {e}")
        return []
    
    processed = load_processed()
    alerts = load_alerts()
    new_alerts = []
    
    for email in emails:
        email_hash = get_email_hash(email)
        
        if email_hash in processed:
            continue
        
        # Quick classification
        result = classify_email_fast(email)
        
        # Use LLM if needed
        if result.get('needs_llm'):
            result = classify_email_llm(email)
        
        # Mark as processed
        processed.add(email_hash)
        
        # Create alert for non-spam
        if result['category'] != 'SPAM':
            alert = {
                'timestamp': datetime.utcnow().isoformat(),
                'category': result['category'],
                'reason': result['reason'],
                'from': email.get('from', ''),
                'subject': email.get('subject', ''),
                'body_preview': email.get('body', '')[:300],
                'processed': False
            }
            alerts.append(alert)
            new_alerts.append(alert)
            
            if result['category'] in ['URGENT', 'CUSTOMER']:
                log(f"ALERT: {result['category']} email from {email.get('from', 'unknown')}: {email.get('subject', 'no subject')}")
    
    save_processed(processed)
    save_alerts(alerts)
    
    return new_alerts


def run_daemon(interval: int = 10):
    """Run the email monitoring daemon."""
    log("Email monitor daemon starting...")
    print(f"Email monitor daemon starting (checking every {interval}s)")
    print(f"Alerts file: {ALERTS_FILE}")
    print(f"Log file: {LOG_FILE}")
    
    while True:
        try:
            new_alerts = check_and_classify()
            if new_alerts:
                for alert in new_alerts:
                    print(f"[{alert['category']}] {alert['from']}: {alert['subject']}")
        except Exception as e:
            log(f"Error in check cycle: {e}")
        
        time.sleep(interval)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Email monitor daemon')
    parser.add_argument('--interval', type=int, default=10, help='Check interval in seconds')
    parser.add_argument('--once', action='store_true', help='Run once and exit')
    args = parser.parse_args()
    
    if args.once:
        alerts = check_and_classify()
        print(f"Found {len(alerts)} new alerts")
        for a in alerts:
            print(f"  [{a['category']}] {a['from']}: {a['subject']}")
    else:
        run_daemon(args.interval)
