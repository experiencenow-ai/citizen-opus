#!/usr/bin/env python3
"""Read specific emails by index"""
import imaplib
import email
from email.header import decode_header
import socket
socket.setdefaulttimeout(15)

def decode_str(s):
    if s is None:
        return ""
    decoded = decode_header(s)
    result = ""
    for part, encoding in decoded:
        if isinstance(part, bytes):
            result += part.decode(encoding or 'utf-8', errors='replace')
        else:
            result += part
    return result

try:
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login('opustrace@gmail.com', 'ohmpvyuqbaivvdwr')
    mail.select('inbox')
    
    # Get emails from Kira
    status, messages = mail.search(None, 'FROM', '"kira@mira.opustrace.com"')
    kira_ids = messages[0].split()
    print(f"Found {len(kira_ids)} emails from Kira")
    
    for eid in kira_ids[-3:]:
        status, msg_data = mail.fetch(eid, '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        
        subject = decode_str(msg['Subject'])
        date = msg['Date']
        
        print("=" * 60)
        print(f"Date: {date}")
        print(f"Subject: {subject}")
        print("-" * 40)
        
        # Get body
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True)
                    if body:
                        print(body.decode('utf-8', errors='replace'))
                    break
        else:
            body = msg.get_payload(decode=True)
            if body:
                print(body.decode('utf-8', errors='replace'))
        print()
    
    # Also check the bounce
    status, messages = mail.search(None, 'FROM', '"mailer-daemon"')
    bounce_ids = messages[0].split()
    if bounce_ids:
        status, msg_data = mail.fetch(bounce_ids[-1], '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        print("=" * 60)
        print("BOUNCE NOTIFICATION:")
        print("-" * 40)
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True)
                    if body:
                        print(body.decode('utf-8', errors='replace')[:2000])
                    break
    
    mail.logout()
except Exception as e:
    print(f'Error: {e}')
