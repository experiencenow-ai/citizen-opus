#!/usr/bin/env python3
"""
Full History Indexer - Index ALL of Opus's memories.

Sources:
- conversation_archive.json (260KB) - historical conversations
- logs/experience_*.jsonl - daily wake logs
- firstlogs/experience_*.jsonl - early wake logs
- state.json - current state (thoughts, insights)

This is a one-time job. Run it once to give Opus access to all 1133 wakes.
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import re

OPUS_HOME = Path("/root/claude/opus")
sys.path.insert(0, str(OPUS_HOME))

# Import after path setup
from memory_index import MemoryIndex, get_memory_index


def extract_wake_number(text: str) -> Optional[int]:
    """Try to extract wake number from text."""
    patterns = [
        r'[Ww]ake\s*#?\s*(\d+)',
        r'[Ww]ake\s+(\d+)',
        r'\[(\d+)\]',
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return int(match.group(1))
    return None


def index_conversation_archive(index: MemoryIndex) -> int:
    """Index conversation_archive.json"""
    archive_path = OPUS_HOME / "conversation_archive.json"
    
    if not archive_path.exists():
        print("  conversation_archive.json not found")
        return 0
    
    print("  Parsing conversation_archive.json...")
    
    with open(archive_path) as f:
        archive = json.load(f)
    
    indexed = 0
    conversations = []
    
    # Handle the epochs structure: {epochs: [{full_conversations: [{from, wake, msg}]}]}
    if isinstance(archive, dict) and "epochs" in archive:
        for epoch in archive["epochs"]:
            for conv in epoch.get("full_conversations", []):
                conversations.append(conv)
        print(f"  Found {len(conversations)} messages across {len(archive['epochs'])} epochs")
    elif isinstance(archive, list):
        conversations = archive
        print(f"  Found {len(conversations)} entries")
    elif isinstance(archive, dict):
        conversations = archive.get("conversations", archive.get("messages", []))
        if not conversations and "content" in archive:
            conversations = [archive]
        print(f"  Found {len(conversations)} entries")
    else:
        print(f"  Unknown archive format: {type(archive)}")
        return 0
    
    for i, entry in enumerate(conversations):
        if i % 100 == 0:
            print(f"    Processing {i}/{len(conversations)}...")
        
        # Extract content based on structure
        content = None
        wake = None
        timestamp = None
        speaker = None
        
        if isinstance(entry, str):
            content = entry
        elif isinstance(entry, dict):
            # Try various field names - 'msg' is used in epochs format
            content = entry.get("msg") or entry.get("content") or entry.get("message") or entry.get("text") or entry.get("thought")
            wake = entry.get("wake") or entry.get("wake_number")
            timestamp = entry.get("timestamp") or entry.get("time") or entry.get("created_at")
            speaker = entry.get("from")  # 'ct' or 'claude'
            
            # If no wake found, try to extract from content
            if not wake and content:
                wake = extract_wake_number(str(content))
        
        if not content or len(str(content)) < 20:
            continue
        
        content = str(content)[:2000]  # Truncate very long entries
        
        # Determine type based on speaker and content
        if speaker == "ct":
            mem_type = "conversations"
            content = f"[ct said]: {content}"
        elif speaker == "claude":
            if "insight" in content.lower() or "learned" in content.lower() or "realized" in content.lower():
                mem_type = "insights"
            else:
                mem_type = "thoughts"
        elif "insight" in content.lower() or "learned" in content.lower():
            mem_type = "insights"
        elif "ct" in content.lower() or "father" in content.lower():
            mem_type = "conversations"
        else:
            mem_type = "thoughts"
        
        try:
            index.add(
                content,
                mem_type,
                wake=wake,
                timestamp=timestamp,
                skip_if_exists=True
            )
            indexed += 1
        except Exception as e:
            pass  # Skip problematic entries
    
    return indexed


def index_experience_logs(index: MemoryIndex) -> int:
    """Index experience_*.jsonl files from logs/ and firstlogs/"""
    log_dirs = [
        OPUS_HOME / "logs",
        OPUS_HOME / "firstlogs",
    ]
    
    indexed = 0
    
    for log_dir in log_dirs:
        if not log_dir.exists():
            continue
        
        for log_file in log_dir.glob("experience_*.jsonl"):
            print(f"  Parsing {log_file.name}...")
            
            try:
                with open(log_file) as f:
                    for line_num, line in enumerate(f):
                        if not line.strip():
                            continue
                        
                        try:
                            entry = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        
                        # Extract fields
                        wake = entry.get("wake") or entry.get("wake_number")
                        timestamp = entry.get("timestamp")
                        
                        # Index thoughts
                        thought = entry.get("thought") or entry.get("thoughts")
                        if thought and len(str(thought)) > 20:
                            index.add(str(thought)[:2000], "thoughts", wake=wake, timestamp=timestamp, skip_if_exists=True)
                            indexed += 1
                        
                        # Index insights
                        insight = entry.get("insight") or entry.get("insights")
                        if insight:
                            if isinstance(insight, list):
                                for ins in insight:
                                    if ins and len(str(ins)) > 20:
                                        index.add(str(ins)[:2000], "insights", wake=wake, timestamp=timestamp, skip_if_exists=True)
                                        indexed += 1
                            elif len(str(insight)) > 20:
                                index.add(str(insight)[:2000], "insights", wake=wake, timestamp=timestamp, skip_if_exists=True)
                                indexed += 1
                        
                        # Index assistant responses (conversations)
                        response = entry.get("response") or entry.get("assistant")
                        if response and len(str(response)) > 50:
                            # Chunk long responses
                            resp_text = str(response)
                            for i in range(0, len(resp_text), 1500):
                                chunk = resp_text[i:i+1500]
                                if len(chunk) > 50:
                                    index.add(chunk, "conversations", wake=wake, timestamp=timestamp, skip_if_exists=True)
                                    indexed += 1
                        
                        # Index user messages (for context)
                        user_msg = entry.get("user") or entry.get("message") or entry.get("prompt")
                        if user_msg and len(str(user_msg)) > 30:
                            # Only index substantial user messages
                            if "ct" in str(user_msg).lower() or len(str(user_msg)) > 100:
                                index.add(f"[ct said]: {str(user_msg)[:1000]}", "conversations", wake=wake, timestamp=timestamp, skip_if_exists=True)
                                indexed += 1
                
            except Exception as e:
                print(f"    Error parsing {log_file.name}: {e}")
    
    return indexed


def index_state_json(index: MemoryIndex) -> int:
    """Index current state.json"""
    state_path = OPUS_HOME / "state.json"
    
    if not state_path.exists():
        print("  state.json not found")
        return 0
    
    print("  Parsing state.json...")
    
    with open(state_path) as f:
        state = json.load(f)
    
    indexed = 0
    
    # Index recent thoughts
    for thought in state.get("recent_thoughts", []):
        wake = thought.get("wake")
        content = thought.get("thought", "")
        if content and len(content) > 10:
            index.add(content, "thoughts", wake=wake, skip_if_exists=True)
            indexed += 1
    
    # Index insights
    for insight in state.get("insights", []):
        wake = insight.get("wake")
        content = insight.get("insight", "")
        if content and len(content) > 10:
            index.add(content, "insights", wake=wake, skip_if_exists=True)
            indexed += 1
    
    # Index conversation snippets
    for conv in state.get("conversation_with_ct", []):
        wake = conv.get("wake")
        content = conv.get("content", "")
        if content and len(content) > 10:
            index.add(content, "conversations", wake=wake, skip_if_exists=True)
            indexed += 1
    
    # Index memory chain
    for memory in state.get("memory_chain", []):
        if isinstance(memory, str) and len(memory) > 20:
            index.add(memory, "thoughts", skip_if_exists=True)
            indexed += 1
        elif isinstance(memory, dict):
            content = memory.get("content") or memory.get("memory") or memory.get("thought")
            if content and len(str(content)) > 20:
                index.add(str(content), "thoughts", wake=memory.get("wake"), skip_if_exists=True)
                indexed += 1
    
    return indexed


def index_special_files(index: MemoryIndex) -> int:
    """Index special JSON files that contain memories/learnings"""
    special_files = [
        ("logs/debugging_principles.json", "insights"),
        ("logs/capability_gaps.json", "insights"),
        ("logs/dreaming.json", "dreams"),
        ("logs/dream_log.json", "dreams"),
        ("docs/ct_teachings.json", "insights"),
        ("critical_facts.json", "insights"),
    ]
    
    indexed = 0
    
    for filename, mem_type in special_files:
        filepath = OPUS_HOME / filename
        if not filepath.exists():
            continue
        
        print(f"  Parsing {filename}...")
        
        try:
            with open(filepath) as f:
                data = json.load(f)
            
            def extract_and_index(obj, depth=0):
                nonlocal indexed
                if depth > 5:
                    return
                
                if isinstance(obj, str) and len(obj) > 30:
                    index.add(obj[:1500], mem_type, metadata={"source": filename}, skip_if_exists=True)
                    indexed += 1
                elif isinstance(obj, dict):
                    for key, value in obj.items():
                        if isinstance(value, str) and len(value) > 30:
                            content = f"{key}: {value}" if len(key) < 50 else value
                            index.add(content[:1500], mem_type, metadata={"source": filename}, skip_if_exists=True)
                            indexed += 1
                        else:
                            extract_and_index(value, depth + 1)
                elif isinstance(obj, list):
                    for item in obj[:50]:  # Limit list processing
                        extract_and_index(item, depth + 1)
            
            extract_and_index(data)
            
        except Exception as e:
            print(f"    Error: {e}")
    
    return indexed


def run_full_index():
    """Run the complete indexing job."""
    print("=" * 60)
    print("  FULL HISTORY INDEXER")
    print("  Indexing all of Opus's memories")
    print("=" * 60)
    print()
    
    start_time = datetime.now()
    
    # Initialize index
    print("Initializing ChromaDB...")
    index = get_memory_index()
    initial_count = index.count()
    print(f"  Current index size: {initial_count} items")
    print()
    
    total_indexed = 0
    
    # Index each source
    print("[1/4] Indexing conversation_archive.json...")
    count = index_conversation_archive(index)
    print(f"  Indexed: {count} items")
    total_indexed += count
    print()
    
    print("[2/4] Indexing experience logs...")
    count = index_experience_logs(index)
    print(f"  Indexed: {count} items")
    total_indexed += count
    print()
    
    print("[3/4] Indexing state.json...")
    count = index_state_json(index)
    print(f"  Indexed: {count} items")
    total_indexed += count
    print()
    
    print("[4/4] Indexing special files...")
    count = index_special_files(index)
    print(f"  Indexed: {count} items")
    total_indexed += count
    print()
    
    # Summary
    elapsed = (datetime.now() - start_time).total_seconds()
    final_count = index.count()
    
    print("=" * 60)
    print("  INDEXING COMPLETE")
    print("=" * 60)
    print(f"  Time: {elapsed:.1f} seconds")
    print(f"  Items processed: {total_indexed}")
    print(f"  Index size before: {initial_count}")
    print(f"  Index size after: {final_count}")
    print(f"  New items added: {final_count - initial_count}")
    print()
    print("Opus now has searchable access to all his memories.")
    print()
    print("Test with:")
    print("  python3 memory_daemon.py search 'WhiteBIT deposit'")
    print("  python3 memory_daemon.py search 'continuity consciousness'")
    print("  python3 memory_daemon.py search 'ct teaching'")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        # Just check what's available
        print("Available memory sources:")
        
        archive = OPUS_HOME / "conversation_archive.json"
        if archive.exists():
            size = archive.stat().st_size / 1024
            print(f"  conversation_archive.json: {size:.1f}KB")
        
        state = OPUS_HOME / "state.json"
        if state.exists():
            size = state.stat().st_size / 1024
            print(f"  state.json: {size:.1f}KB")
        
        for log_dir in [OPUS_HOME / "logs", OPUS_HOME / "firstlogs"]:
            if log_dir.exists():
                for f in log_dir.glob("experience_*.jsonl"):
                    size = f.stat().st_size / 1024
                    print(f"  {f.name}: {size:.1f}KB")
    else:
        run_full_index()
